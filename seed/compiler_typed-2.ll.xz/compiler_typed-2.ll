; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:BlockInfo" = type { i32, i32, %"compiler/source:Span" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:SiteInfo" = type { i32, %"compiler/source:Span" }
%"compiler/typed:DropHolding" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Landings" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:landState" = type { { i64, ptr }, i1 }
%"compiler/typed:LastUses" = type { i64, { i64, ptr }, { i64, ptr }, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Versions" = type { ptr, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:ViewWalk" = type { ptr, ptr, i64, { ptr, ptr }, { ptr, ptr } }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:dropWalk" = type { ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:holdWalk" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:leaveWalk" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:printer" = type { ptr, %"std/prelude/text:StringBuilder" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Item" = type { i32, i64 }
define dso_local i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Block", ptr %t6, i32 0, i32 1
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  %t13 = call i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %t9, i32 %a1)
  store i1 %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2eCalledBody(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l12, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 5}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr { i64, [3 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { i32 }, ptr %t32, i32 0, i32 0
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  call void @__olang_check_failed(ptr @olang_loc_831440fdfc819328_dabfa81c01cf773c)
  unreachable
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7bdf3cb2fb8351f9_389183759a182ed)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l2, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_4e05db95f2fd54c5_981a3a3cc6318dd9)
  unreachable
bb11:
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i1
  %l32 = alloca %"compiler/typed:BlockInfo"
  %l43 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Block", ptr %t1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb4
bb2:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Block", ptr %t10, i32 0, i32 0
  %t13 = load i32, ptr %t12, !tbaa !23
  %t15 = sext i32 %t13 to i64
  store i64 %t15, ptr %l21, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 8
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l24
  br label %bb3
bb3:
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = load i64, ptr %l24, !tbaa !24
  %t23 = icmp sge i64 %t21, %t22
  store i1 %t23, ptr %l18, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i1, ptr %l18, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb8
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 8
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Block", ptr %t29, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  %t37 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t28, i64 %t34)
  store %"compiler/typed:BlockInfo" %t37, ptr %l32
  br label %bb7
bb7:
  %t38 = getelementptr %"compiler/typed:BlockInfo", ptr %l32, i32 0, i32 1
  %t39 = load i32, ptr %t38, !range !{i32 0, i32 10}
  %t41 = trunc i64 8 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  store i1 %t44, ptr %l26, !tbaa !21
  br label %bb8
bb8:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Block", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t55 = icmp ne i64 %t53, 1
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i64 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Block", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l43, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr ptr, ptr %t63, i64 0
  %t65 = load ptr, ptr %t64, !tbaa !39
  store ptr %t65, ptr %l2, !tbaa !29
  %t67 = load ptr, ptr %l2, !tbaa !29
  store ptr %t67, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l45, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 17}
  %t74 = icmp eq i64 %t72, 3
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t75 = load i1, ptr %l46, !tbaa !21
  %t76 = xor i1 %t75, true
  br i1 %t76, label %bb17, label %bb18
bb17:
  store i64 -1, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t79 = load ptr, ptr %l2, !tbaa !29
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 0
  %t83 = load %"compiler/source:Span", ptr %t82
  store %"compiler/source:Span" %t83, ptr %l3
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", ptr }, ptr %t87, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  %t94 = getelementptr %"compiler/typed:If", ptr %t89, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  store ptr %t95, ptr %l5, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  store ptr %t97, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = icmp ne ptr %t98, null
  br i1 %t99, label %bb20, label %bb21
bb20:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = load i64, ptr %t101, !range !{i64 0, i64 18}
  %t104 = icmp eq i64 %t102, 2
  store i1 %t104, ptr %l59, !tbaa !21
  br label %bb21
bb21:
  %t105 = load i1, ptr %l59, !tbaa !21
  %t106 = xor i1 %t105, true
  br i1 %t106, label %bb22, label %bb23
bb22:
  store i64 -1, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l5, !tbaa !29
  %t111 = getelementptr { i64, [5 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 0
  %t113 = load %"compiler/source:Span", ptr %t112
  store %"compiler/source:Span" %t113, ptr %l6
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t117, i32 0, i32 1
  %t119 = load i32, ptr %t118
  store i32 %t119, ptr %l7, !tbaa !23
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t123 = getelementptr { i64, [5 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  %t127 = load ptr, ptr %l5, !tbaa !29
  %t129 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t129, i32 0, i32 3
  %t131 = load i32, ptr %t130
  store i32 %t131, ptr %l9, !tbaa !23
  store ptr %t125, ptr %l10, !tbaa !29
  %t135 = load ptr, ptr %l10, !tbaa !29
  store ptr %t135, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t136 = load ptr, ptr %l73, !tbaa !29
  %t137 = icmp ne ptr %t136, null
  br i1 %t137, label %bb25, label %bb26
bb25:
  %t139 = load ptr, ptr %l73, !tbaa !29
  %t140 = load i64, ptr %t139, !range !{i64 0, i64 8}
  %t142 = icmp eq i64 %t140, 0
  store i1 %t142, ptr %l74, !tbaa !21
  br label %bb26
bb26:
  %t143 = load i1, ptr %l74, !tbaa !21
  %t144 = xor i1 %t143, true
  br i1 %t144, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t147 = load ptr, ptr %l10, !tbaa !29
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l11
  %t153 = load ptr, ptr %l10, !tbaa !29
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t155, i32 0, i32 1
  %t157 = load i32, ptr %t156
  store i32 %t157, ptr %l12, !tbaa !23
  %t159 = load ptr, ptr %l10, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t161, i32 0, i32 2
  %t163 = load i32, ptr %t162
  %t167 = sext i32 %t163 to i64
  store i64 %t167, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2eFreshTemp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb18
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 6
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = call i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %t31)
  store i1 %t33, ptr %l17
  br label %bb11
bb11:
  %t34 = load i1, ptr %l17, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_bf16ba0368763d37_f19ef32b132443ab)
  unreachable
bb17:
  br label %bb30
bb18:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t39 = load ptr, ptr %l18, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 17
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb20
bb20:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb21, label %bb22
bb21:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = call i1 @compiler_2ftyped_2eFreshTemp(ptr %v0, ptr %t50)
  store i1 %t52, ptr %l25
  br label %bb24
bb24:
  %t53 = load i1, ptr %l25, !tbaa !21
  store i1 %t53, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_af65136929bfae16_48f8be4437d6c6ea)
  unreachable
bb30:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eHoldsOwned(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %a0, i32 %a1, i64 0)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Seq", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  store i1 %t28, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Seq", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_c21a1343bdb3d01_d6f77a8ccb597545)
  unreachable
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Seq", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l2, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  store ptr %t44, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t45 = load ptr, ptr %l27, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l28, !tbaa !21
  br label %bb16
bb16:
  %t52 = load i1, ptr %l28, !tbaa !21
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l3
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t61, i32 0, i32 1
  %t63 = load i32, ptr %t62
  store i32 %t63, ptr %l4, !tbaa !23
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t73, i32 0, i32 3
  %t75 = load i32, ptr %t74
  store i32 %t75, ptr %l6, !tbaa !23
  store ptr %t69, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t78 = load ptr, ptr %l40, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb19, label %bb20
bb18:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb21
bb19:
  %t81 = load ptr, ptr %l40, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 8}
  %t84 = icmp eq i64 %t82, 0
  store i1 %t84, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t85 = load i1, ptr %l41, !tbaa !21
  store i1 %t85, ptr %l31, !tbaa !21
  br label %bb21
bb21:
  %t86 = load i1, ptr %l31, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb22:
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t88 = load ptr, ptr %l44, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l44, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 18}
  %t94 = icmp eq i64 %t92, 17
  store i1 %t94, ptr %l45, !tbaa !21
  br label %bb24
bb24:
  %t95 = load i1, ptr %l45, !tbaa !21
  br i1 %t95, label %bb25, label %bb26
bb25:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr { i64, [5 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t98, i32 0, i32 2
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l7, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t102 = load ptr, ptr %l7, !tbaa !29
  %t104 = call i1 @compiler_2ftyped_2eMovedArg(ptr %v0, ptr %t102)
  store i1 %t104, ptr %l51
  br label %bb28
bb28:
  %t105 = load i1, ptr %l51, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_4964fda744059959_ea5b63edb7fb932d)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ePurePlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l60 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb54
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i1 @compiler_2ftyped_2ePurePlace(ptr %v0, ptr %t34)
  store i1 %t36, ptr %l22
  br label %bb16
bb16:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l6, !tbaa !21
  br label %bb54
bb17:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 8}
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l24, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l24, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb22
bb21:
  br label %bb28
bb22:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call i1 @compiler_2ftyped_2ePurePlace(ptr %v0, ptr %t56)
  store i1 %t58, ptr %l31
  br label %bb23
bb23:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb24, label %bb25
bb24:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Elem", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t63)
  store i1 %t65, ptr %l35
  br label %bb26
bb25:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb27
bb26:
  %t66 = load i1, ptr %l35, !tbaa !21
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb27
bb27:
  %t67 = load i1, ptr %l32, !tbaa !21
  store i1 %t67, ptr %l6, !tbaa !21
  br label %bb54
bb28:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t69 = load ptr, ptr %l36, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb29, label %bb30
bb29:
  %t72 = load ptr, ptr %l36, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 8}
  %t75 = icmp eq i64 %t73, 5
  store i1 %t75, ptr %l37, !tbaa !21
  br label %bb30
bb30:
  %t76 = load i1, ptr %l37, !tbaa !21
  br i1 %t76, label %bb31, label %bb32
bb31:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 2
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t83 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = call i1 @compiler_2ftyped_2ePurePlace(ptr %v0, ptr %t86)
  store i1 %t88, ptr %l44
  br label %bb34
bb34:
  %t89 = load i1, ptr %l44, !tbaa !21
  store i1 %t89, ptr %l6, !tbaa !21
  br label %bb54
bb35:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb36, label %bb37
bb36:
  %t94 = load ptr, ptr %l45, !tbaa !29
  %t95 = load i64, ptr %t94, !range !{i64 0, i64 8}
  %t97 = icmp eq i64 %t95, 2
  store i1 %t97, ptr %l46, !tbaa !21
  br label %bb37
bb37:
  %t98 = load i1, ptr %l46, !tbaa !21
  br i1 %t98, label %bb38, label %bb39
bb38:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t105 = load ptr, ptr %l4, !tbaa !29
  %t107 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t105)
  store i1 %t107, ptr %l52
  br label %bb41
bb41:
  %t108 = load i1, ptr %l52, !tbaa !21
  store i1 %t108, ptr %l6, !tbaa !21
  br label %bb54
bb42:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t110 = load ptr, ptr %l53, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb43, label %bb44
bb43:
  %t113 = load ptr, ptr %l53, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 8}
  %t116 = icmp eq i64 %t114, 6
  store i1 %t116, ptr %l54, !tbaa !21
  br label %bb44
bb44:
  %t117 = load i1, ptr %l54, !tbaa !21
  br i1 %t117, label %bb45, label %bb46
bb45:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l5, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t124 = load ptr, ptr %l5, !tbaa !29
  %t126 = call i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %t124)
  store i1 %t126, ptr %l60
  br label %bb48
bb48:
  %t127 = load i1, ptr %l60, !tbaa !21
  store i1 %t127, ptr %l6, !tbaa !21
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_b89edc07d86ca7e2_8a4bea4bc2b7688e)
  unreachable
bb54:
  %t128 = load i1, ptr %l6, !tbaa !21
  store i1 %t128, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2eScope_2eresult(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca { i64, ptr }
  %l43 = alloca { i64, [1 x i64] }
  %rv = alloca { i64, [1 x i64] }
  %t75 = alloca { i64, [1 x i64] }, align 8
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l5, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l17, !tbaa !24
  store i64 %t31, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l14, !tbaa !24
  store i64 %t32, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l8, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t52
  %t57 = load i64, ptr %t56, !tbaa !34
  %t58 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb11, label %bb12
bb11:
  %t65 = load i64, ptr %l8, !tbaa !24
  %t69 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %t65)
  store { i64, [1 x i64] } %t69, ptr %l43
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t70 = load { i64, [1 x i64] }, ptr %l43
  store { i64, [1 x i64] } %t70, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t71 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l7, !tbaa !24
  br label %bb7
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [1 x i64] }, ptr %t75, i32 0, i32 0
  store i64 0, ptr %t76
  %t77 = load { i64, [1 x i64] }, ptr %t75
  store { i64, [1 x i64] } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i32
  %l13 = alloca i32
  %l18 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l13
  br label %bb2
bb2:
  %t12 = load i32, ptr %l13, !range !{i32 0, i32 33}
  store i32 %t12, ptr %l3
  %t13 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t15 = trunc i64 19 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l18
  br label %bb6
bb6:
  %t23 = load i32, ptr %l18, !tbaa !23
  %t24 = icmp eq i32 %t23, 0
  store i1 %t24, ptr %rv
  br label %ret
bb7:
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t28 = trunc i64 22 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t33 = trunc i64 23 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb25
bb12:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l24, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l27
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = load i32, ptr %l27, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l28
  br label %bb14
bb14:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2ftyped_2earenaArray(ptr %v0, ptr %t66, i32 %t64)
  store i1 %t70, ptr %l40
  br label %bb19
bb19:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l5, !tbaa !24
  br label %bb15
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_ecb034f719e18c1b_985175307bfdc34f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2eclausesTakeAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l16 = alloca { i64, ptr }
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb12
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t28, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb4
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l9 = alloca %"compiler/typed:BlockInfo"
  %l12 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 8
  store ptr %t3, ptr %l5, !tbaa !29
  %t10 = call %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %s0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
  store %"compiler/typed:BlockInfo" %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = load %"compiler/typed:BlockInfo", ptr %l9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ePush_H85e1838377aa8e6b322d82e3edbac596(ptr %v0, ptr %t11, %"compiler/typed:BlockInfo" %t12)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 8
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = sub i64 %t18, 1
  %t21 = trunc i64 %t19 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddLocal(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i64
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t3, %"compiler/typed:Local" %a1)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/typed:Body", ptr %t7, i32 0, i32 7
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l7
  br label %bb2
bb2:
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = sub i64 %t12, 1
  %t15 = trunc i64 %t13 to i32
  store i32 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddSite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca %"compiler/typed:SiteInfo"
  %l10 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Body", ptr %t1, i32 0, i32 9
  store ptr %t3, ptr %l4, !tbaa !29
  %t8 = call %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %s0, i32 %a1, %"compiler/source:Span" %a2)
  store %"compiler/typed:SiteInfo" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"compiler/typed:SiteInfo", ptr %l7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ePush_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t9, %"compiler/typed:SiteInfo" %t10)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Body", ptr %t11, i32 0, i32 9
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i64, ptr %l10, !tbaa !24
  %t17 = sub i64 %t16, 1
  %t19 = trunc i64 %t17 to i32
  call void @__olang_scope_close(ptr %s0)
  store i32 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca i32
  %l16 = alloca %"compiler/typed:BlockInfo"
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i32 %a2, ptr %l3, !tbaa !23
  br label %bb1
bb1:
  %t3 = load i32, ptr %l3, !tbaa !23
  %t5 = icmp sge i32 %t3, 0
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t9 = load i32, ptr %l3, !tbaa !23
  %t13 = icmp eq i32 %t9, %a1
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = getelementptr %"compiler/typed:Body", ptr %a0, i32 0, i32 8
  %t19 = load i32, ptr %l3, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %t18, i64 %t21)
  store %"compiler/typed:BlockInfo" %t24, ptr %l16
  br label %bb8
bb8:
  %t25 = getelementptr %"compiler/typed:BlockInfo", ptr %l16, i32 0, i32 0
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb9
bb9:
  br label %bb1
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eResultMark(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l18 = alloca i32
  %rv = alloca { i64, [1 x i64] }
  %t18 = alloca { i64, [1 x i64] }, align 8
  %t33 = alloca { i64, [1 x i64] }, align 8
  %t40 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Body", ptr %t2, i32 0, i32 2
  %t5 = load i32, ptr %t4, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v1, ptr %a1, i32 %t5, i64 %a2)
  store i64 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t16 = icmp eq i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  store { i64, [1 x i64] } zeroinitializer, ptr %t18
  %t19 = getelementptr { i64, [1 x i64] }, ptr %t18, i32 0, i32 0
  store i64 5, ptr %t19
  %t20 = load { i64, [1 x i64] }, ptr %t18
  store { i64, [1 x i64] } %t20, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 5
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l18
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, [1 x i64] } zeroinitializer, ptr %t33
  %t34 = getelementptr { i64, [1 x i64] }, ptr %t33, i32 0, i32 0
  store i64 2, ptr %t34
  %t35 = load i32, ptr %l18, !tbaa !23
  %t36 = insertvalue { i32 } undef, i32 %t35, 0
  %t37 = getelementptr { i64, [1 x i64] }, ptr %t33, i32 0, i32 1
  store { i32 } %t36, ptr %t37
  %t38 = load { i64, [1 x i64] }, ptr %t33
  store { i64, [1 x i64] } %t38, ptr %rv
  br label %ret
bb8:
  store { i64, [1 x i64] } zeroinitializer, ptr %t40
  %t41 = getelementptr { i64, [1 x i64] }, ptr %t40, i32 0, i32 0
  store i64 1, ptr %t41
  %t42 = load { i64, [1 x i64] }, ptr %t40
  store { i64, [1 x i64] } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [1 x i64] }, ptr %rv
  ret { i64, [1 x i64] } %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aDropHolding_2eHolds(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:DropHolding", ptr %t1, i32 0, i32 0
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:DropHolding", ptr %t53, i32 0, i32 0
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp eq i64 %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:DropHolding", ptr %t65, i32 0, i32 2
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v0, ptr %t67, i64 %t68)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l45
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %l45, i64 %a2)
  store i1 %t75, ptr %l48
  br label %bb16
bb16:
  %t76 = load i1, ptr %l48, !tbaa !21
  store i1 %t76, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca i1
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l1
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l1
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t42, i32 0, i32 0
  %t44 = load %"compiler/source:Span", ptr %t43
  store %"compiler/source:Span" %t44, ptr %l1
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 18}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 0
  %t59 = load %"compiler/source:Span", ptr %t58
  store %"compiler/source:Span" %t59, ptr %l1
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t61, ptr %l6
  br label %bb83
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 18}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l33, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 0
  %t76 = load %"compiler/source:Span", ptr %t75
  store %"compiler/source:Span" %t76, ptr %l2
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t79 = load ptr, ptr %l38, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l39, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l2
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t94 = load ptr, ptr %l44, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l44, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 18}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l45, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l45, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [5 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t104, i32 0, i32 0
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l2
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l50, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 18}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l51, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l51, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l2
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t123, ptr %l6
  br label %bb83
bb36:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t126 = load ptr, ptr %l57, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l57, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 8
  store i1 %t132, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  %t133 = load i1, ptr %l58, !tbaa !21
  br i1 %t133, label %bb39, label %bb40
bb39:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t136, i32 0, i32 0
  %t138 = load %"compiler/source:Span", ptr %t137
  store %"compiler/source:Span" %t138, ptr %l3
  br label %bb53
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t141 = load ptr, ptr %l63, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb41, label %bb42
bb41:
  %t144 = load ptr, ptr %l63, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 18}
  %t147 = icmp eq i64 %t145, 9
  store i1 %t147, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t148 = load i1, ptr %l64, !tbaa !21
  br i1 %t148, label %bb43, label %bb44
bb43:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr { i64, [5 x i64] }, ptr %t149, i32 0, i32 1
  %t152 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t151, i32 0, i32 0
  %t153 = load %"compiler/source:Span", ptr %t152
  store %"compiler/source:Span" %t153, ptr %l3
  br label %bb53
bb44:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t156 = load ptr, ptr %l69, !tbaa !29
  %t157 = icmp ne ptr %t156, null
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t159 = load ptr, ptr %l69, !tbaa !29
  %t160 = load i64, ptr %t159, !range !{i64 0, i64 18}
  %t162 = icmp eq i64 %t160, 10
  store i1 %t162, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t163 = load i1, ptr %l70, !tbaa !21
  br i1 %t163, label %bb47, label %bb48
bb47:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr { i64, [5 x i64] }, ptr %t164, i32 0, i32 1
  %t167 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t166, i32 0, i32 0
  %t168 = load %"compiler/source:Span", ptr %t167
  store %"compiler/source:Span" %t168, ptr %l3
  br label %bb53
bb48:
  %t170 = load ptr, ptr %l0, !tbaa !29
  store ptr %t170, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t171 = load ptr, ptr %l75, !tbaa !29
  %t172 = icmp ne ptr %t171, null
  br i1 %t172, label %bb49, label %bb50
bb49:
  %t174 = load ptr, ptr %l75, !tbaa !29
  %t175 = load i64, ptr %t174, !range !{i64 0, i64 18}
  %t177 = icmp eq i64 %t175, 11
  store i1 %t177, ptr %l76, !tbaa !21
  br label %bb50
bb50:
  %t178 = load i1, ptr %l76, !tbaa !21
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [5 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t181, i32 0, i32 0
  %t183 = load %"compiler/source:Span", ptr %t182
  store %"compiler/source:Span" %t183, ptr %l3
  br label %bb53
bb52:
  br label %bb54
bb53:
  %t185 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t185, ptr %l6
  br label %bb83
bb54:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t188 = load ptr, ptr %l82, !tbaa !29
  %t189 = icmp ne ptr %t188, null
  br i1 %t189, label %bb55, label %bb56
bb55:
  %t191 = load ptr, ptr %l82, !tbaa !29
  %t192 = load i64, ptr %t191, !range !{i64 0, i64 18}
  %t194 = icmp eq i64 %t192, 12
  store i1 %t194, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t195 = load i1, ptr %l83, !tbaa !21
  br i1 %t195, label %bb57, label %bb58
bb57:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr { i64, [5 x i64] }, ptr %t196, i32 0, i32 1
  %t199 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t198, i32 0, i32 0
  %t200 = load %"compiler/source:Span", ptr %t199
  store %"compiler/source:Span" %t200, ptr %l4
  br label %bb75
bb58:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t203 = load ptr, ptr %l88, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb59, label %bb60
bb59:
  %t206 = load ptr, ptr %l88, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 18}
  %t209 = icmp eq i64 %t207, 13
  store i1 %t209, ptr %l89, !tbaa !21
  br label %bb60
bb60:
  %t210 = load i1, ptr %l89, !tbaa !21
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [5 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t213, i32 0, i32 0
  %t215 = load %"compiler/source:Span", ptr %t214
  store %"compiler/source:Span" %t215, ptr %l4
  br label %bb75
bb62:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t218 = load ptr, ptr %l94, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t221 = load ptr, ptr %l94, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 18}
  %t224 = icmp eq i64 %t222, 14
  store i1 %t224, ptr %l95, !tbaa !21
  br label %bb64
bb64:
  %t225 = load i1, ptr %l95, !tbaa !21
  br i1 %t225, label %bb65, label %bb66
bb65:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [5 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l4
  br label %bb75
bb66:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t233 = load ptr, ptr %l100, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb67, label %bb68
bb67:
  %t236 = load ptr, ptr %l100, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 18}
  %t239 = icmp eq i64 %t237, 15
  store i1 %t239, ptr %l101, !tbaa !21
  br label %bb68
bb68:
  %t240 = load i1, ptr %l101, !tbaa !21
  br i1 %t240, label %bb69, label %bb70
bb69:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr { i64, [5 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t243, i32 0, i32 0
  %t245 = load %"compiler/source:Span", ptr %t244
  store %"compiler/source:Span" %t245, ptr %l4
  br label %bb75
bb70:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t248 = load ptr, ptr %l106, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l106, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 18}
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l107, !tbaa !21
  br label %bb72
bb72:
  %t255 = load i1, ptr %l107, !tbaa !21
  br i1 %t255, label %bb73, label %bb74
bb73:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [5 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t258, i32 0, i32 0
  %t260 = load %"compiler/source:Span", ptr %t259
  store %"compiler/source:Span" %t260, ptr %l4
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t262 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t262, ptr %l6
  br label %bb83
bb76:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t268 = load ptr, ptr %l113, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 18}
  %t271 = icmp eq i64 %t269, 17
  store i1 %t271, ptr %l114, !tbaa !21
  br label %bb78
bb78:
  %t272 = load i1, ptr %l114, !tbaa !21
  br i1 %t272, label %bb79, label %bb80
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t275, i32 0, i32 0
  %t277 = load %"compiler/source:Span", ptr %t276
  store %"compiler/source:Span" %t277, ptr %l5
  br label %bb81
bb80:
  br label %bb82
bb81:
  %t279 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t279, ptr %l6
  br label %bb83
bb82:
  call void @__olang_check_failed(ptr @olang_loc_6690d985632b6de7_b13460b3c8232d4b)
  unreachable
bb83:
  %t281 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t281, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l13 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb8
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eblock(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Clause", ptr %t31, i32 0, i32 4
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %t30, { i64, ptr } %t34)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 7
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:landState", ptr %t10, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Landings", ptr %t15, i32 0, i32 6
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb13
bb10:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l23, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l23, !tbaa !24
  store i64 %t48, ptr %l20, !tbaa !24
  br label %bb13
bb13:
  %t49 = load i64, ptr %l20, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb15, label %bb16
bb15:
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Landings", ptr %t68, i32 0, i32 6
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l42, !tbaa !27
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Landings", ptr %t73, i32 0, i32 6
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l45, !tbaa !27
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i1, ptr %t80, i64 %t77
  %t82 = load i1, ptr %t81, !tbaa !31
  br i1 %t82, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb19:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr %"compiler/typed:landState", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l50, !tbaa !27
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i1, ptr %t91, i64 %t88
  %t93 = load i1, ptr %t92, !tbaa !31
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t95 = load i1, ptr %l48, !tbaa !21
  %t96 = load i64, ptr %l43, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i1, ptr %t98, i64 %t96
  store i1 %t95, ptr %t99, !tbaa !31
  br label %bb21
bb21:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb14
bb22:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Landings", ptr %t1, i32 0, i32 6
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l14, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Landings", ptr %t54, i32 0, i32 6
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l36, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/typed:landState", ptr %t59, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l39, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i1, ptr %t66, i64 %t63
  %t68 = load i1, ptr %t67, !tbaa !31
  %t71 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i1, ptr %t72, i64 %t58
  store i1 %t68, ptr %t73, !tbaa !31
  br label %bb11
bb11:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb7
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/typed:landState", ptr %t79, i32 0, i32 1
  %t82 = load i1, ptr %t81, !tbaa !21
  %t85 = getelementptr %"compiler/typed:Landings", ptr %t78, i32 0, i32 7
  store i1 %t82, ptr %t85, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l16 = alloca { i64, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t34, 1
  store i64 %t36, ptr %l3, !tbaa !24
  br label %bb4
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = add i64 %t28, 1
  store i64 %t30, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LastUses", ptr %t2, i32 0, i32 5
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/typed:LastUses", ptr %t8, i32 0, i32 5
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t10, ptr %a1)
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l7, !tbaa !29
  %t15 = load ptr, ptr %l7, !tbaa !29
  %t16 = getelementptr %"compiler/typed:LastUses", ptr %t15, i32 0, i32 5
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = sub i64 %t17, 1
  %t21 = load ptr, ptr %l7, !tbaa !29
  %t22 = getelementptr %"compiler/typed:LastUses", ptr %t21, i32 0, i32 5
  store i64 %t19, ptr %t22, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t16, i32 %t17)
  br label %bb6
bb6:
  br label %bb54
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb54
bb14:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 8}
  %t47 = icmp eq i64 %t45, 3
  store i1 %t47, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb17, label %bb18
bb17:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [4 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t51, i32 0, i32 2
  %t53 = load ptr, ptr %t52
  store ptr %t53, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t55, ptr %t56)
  br label %bb20
bb20:
  br label %bb54
bb21:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 8}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb24, label %bb25
bb24:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Elem", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t78)
  br label %bb27
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Elem", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t81, ptr %t85)
  br label %bb28
bb28:
  br label %bb54
bb29:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb30, label %bb31
bb30:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 5
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb31
bb31:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t107 = getelementptr %"compiler/typed:Payload", ptr %t105, i32 0, i32 0
  %t108 = load ptr, ptr %t107, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t104, ptr %t108)
  br label %bb35
bb35:
  br label %bb54
bb36:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 8}
  %t118 = icmp eq i64 %t116, 6
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb38
bb38:
  %t119 = load i1, ptr %l56, !tbaa !21
  br i1 %t119, label %bb39, label %bb40
bb39:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l7, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  br label %bb42
bb42:
  br label %bb54
bb43:
  %t131 = load ptr, ptr %l1, !tbaa !29
  store ptr %t131, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t132 = load ptr, ptr %l64, !tbaa !29
  %t133 = icmp ne ptr %t132, null
  br i1 %t133, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l64, !tbaa !29
  %t136 = load i64, ptr %t135, !range !{i64 0, i64 8}
  %t138 = icmp eq i64 %t136, 1
  store i1 %t138, ptr %l65, !tbaa !21
  br label %bb45
bb45:
  %t139 = load i1, ptr %l65, !tbaa !21
  br i1 %t139, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t141 = load ptr, ptr %l68, !tbaa !29
  %t142 = icmp ne ptr %t141, null
  br i1 %t142, label %bb48, label %bb49
bb48:
  %t144 = load ptr, ptr %l68, !tbaa !29
  %t145 = load i64, ptr %t144, !range !{i64 0, i64 8}
  %t147 = icmp eq i64 %t145, 7
  store i1 %t147, ptr %l69, !tbaa !21
  br label %bb49
bb49:
  %t148 = load i1, ptr %l69, !tbaa !21
  br i1 %t148, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_4860703a134569c9_d00fc34d053d5355)
  unreachable
bb54:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l119 = alloca ptr
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l171 = alloca ptr
  %l177 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i1
  %l186 = alloca ptr
  %l197 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l227 = alloca ptr
  %l230 = alloca ptr
  %l231 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t2 = load ptr, ptr %l25, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l25, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l26, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %t22, i32 %t23)
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %t31, i32 %t32)
  br label %bb8
bb8:
  br label %bb129
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t36 = load ptr, ptr %l40, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l40, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 17}
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l41, !tbaa !21
  br label %bb11
bb11:
  %t43 = load i1, ptr %l41, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb14
bb13:
  br label %bb17
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  br label %bb15
bb15:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb16
bb16:
  br label %bb129
bb17:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t66 = load ptr, ptr %l53, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb18, label %bb19
bb18:
  %t69 = load ptr, ptr %l53, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 17}
  %t72 = icmp eq i64 %t70, 2
  store i1 %t72, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t73 = load i1, ptr %l54, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [3 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr }, ptr %t76, i32 0, i32 1
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb30
bb21:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t81 = load ptr, ptr %l59, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l59, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 17}
  %t87 = icmp eq i64 %t85, 15
  store i1 %t87, ptr %l60, !tbaa !21
  br label %bb23
bb23:
  %t88 = load i1, ptr %l60, !tbaa !21
  br i1 %t88, label %bb24, label %bb25
bb24:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [3 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l6, !tbaa !29
  br label %bb30
bb25:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t96 = load ptr, ptr %l65, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb26, label %bb27
bb26:
  %t99 = load ptr, ptr %l65, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 17}
  %t102 = icmp eq i64 %t100, 8
  store i1 %t102, ptr %l66, !tbaa !21
  br label %bb27
bb27:
  %t103 = load i1, ptr %l66, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [3 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t106, i32 0, i32 1
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  br label %bb31
bb31:
  br label %bb129
bb32:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t116 = load ptr, ptr %l74, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb33, label %bb34
bb33:
  %t119 = load ptr, ptr %l74, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 17}
  %t122 = icmp eq i64 %t120, 6
  store i1 %t122, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t123 = load i1, ptr %l75, !tbaa !21
  br i1 %t123, label %bb35, label %bb36
bb35:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l7, !tbaa !29
  br label %bb45
bb36:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t131 = load ptr, ptr %l80, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb37, label %bb38
bb37:
  %t134 = load ptr, ptr %l80, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 17}
  %t137 = icmp eq i64 %t135, 16
  store i1 %t137, ptr %l81, !tbaa !21
  br label %bb38
bb38:
  %t138 = load i1, ptr %l81, !tbaa !21
  br i1 %t138, label %bb39, label %bb40
bb39:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [3 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l7, !tbaa !29
  br label %bb45
bb40:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t146 = load ptr, ptr %l86, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb41, label %bb42
bb41:
  %t149 = load ptr, ptr %l86, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 17}
  %t152 = icmp eq i64 %t150, 9
  store i1 %t152, ptr %l87, !tbaa !21
  br label %bb42
bb42:
  %t153 = load i1, ptr %l87, !tbaa !21
  br i1 %t153, label %bb43, label %bb44
bb43:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l7, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t160, ptr %t161)
  br label %bb46
bb46:
  br label %bb129
bb47:
  %t164 = load ptr, ptr %l1, !tbaa !29
  store ptr %t164, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t165 = load ptr, ptr %l94, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb48, label %bb49
bb48:
  %t168 = load ptr, ptr %l94, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 17}
  %t171 = icmp eq i64 %t169, 3
  store i1 %t171, ptr %l95, !tbaa !21
  br label %bb49
bb49:
  %t172 = load i1, ptr %l95, !tbaa !21
  br i1 %t172, label %bb50, label %bb51
bb50:
  %t173 = load ptr, ptr %l1, !tbaa !29
  %t175 = getelementptr { i64, [3 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", ptr }, ptr %t175, i32 0, i32 1
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l8, !tbaa !29
  br label %bb52
bb51:
  br label %bb56
bb52:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l8, !tbaa !29
  %t182 = getelementptr %"compiler/typed:If", ptr %t180, i32 0, i32 0
  %t183 = load ptr, ptr %t182, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t179, ptr %t183)
  br label %bb53
bb53:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = getelementptr %"compiler/typed:If", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t187, ptr %t191)
  br label %bb54
bb54:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l8, !tbaa !29
  %t198 = getelementptr %"compiler/typed:If", ptr %t196, i32 0, i32 2
  %t199 = load ptr, ptr %t198, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t195, ptr %t199)
  br label %bb55
bb55:
  br label %bb129
bb56:
  %t202 = load ptr, ptr %l1, !tbaa !29
  store ptr %t202, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t203 = load ptr, ptr %l111, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb57, label %bb58
bb57:
  %t206 = load ptr, ptr %l111, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 4
  store i1 %t209, ptr %l112, !tbaa !21
  br label %bb58
bb58:
  %t210 = load i1, ptr %l112, !tbaa !21
  br i1 %t210, label %bb59, label %bb60
bb59:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l9, !tbaa !29
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr { i64, [3 x i64] }, ptr %t217, i32 0, i32 1
  %t220 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t219, i32 0, i32 2
  %t221 = load ptr, ptr %t220
  store ptr %t221, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l119, !tbaa !29
  %t224 = load ptr, ptr %l119, !tbaa !29
  %t225 = getelementptr %"compiler/typed:LastUses", ptr %t224, i32 0, i32 4
  %t226 = load i64, ptr %t225, !tbaa !24
  %t228 = add i64 %t226, 1
  %t230 = load ptr, ptr %l119, !tbaa !29
  %t231 = getelementptr %"compiler/typed:LastUses", ptr %t230, i32 0, i32 4
  store i64 %t228, ptr %t231, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t233 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t232, ptr %t233)
  br label %bb62
bb62:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t237, ptr %t238)
  br label %bb63
bb63:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l127, !tbaa !29
  %t242 = load ptr, ptr %l127, !tbaa !29
  %t243 = getelementptr %"compiler/typed:LastUses", ptr %t242, i32 0, i32 4
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = sub i64 %t244, 1
  %t248 = load ptr, ptr %l127, !tbaa !29
  %t249 = getelementptr %"compiler/typed:LastUses", ptr %t248, i32 0, i32 4
  store i64 %t246, ptr %t249, !tbaa !24
  br label %bb129
bb64:
  %t250 = load ptr, ptr %l1, !tbaa !29
  store ptr %t250, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t251 = load ptr, ptr %l130, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb65, label %bb66
bb65:
  %t254 = load ptr, ptr %l130, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 17}
  %t257 = icmp eq i64 %t255, 10
  store i1 %t257, ptr %l131, !tbaa !21
  br label %bb66
bb66:
  %t258 = load i1, ptr %l131, !tbaa !21
  br i1 %t258, label %bb67, label %bb68
bb67:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr { i64, [3 x i64] }, ptr %t259, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t261, i32 0, i32 1
  %t263 = load ptr, ptr %t262
  store ptr %t263, ptr %l11, !tbaa !29
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr { i64, [3 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t267, i32 0, i32 2
  %t269 = load ptr, ptr %t268
  store ptr %t269, ptr %l12, !tbaa !29
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t271, ptr %t272)
  br label %bb70
bb70:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t276, ptr %t277)
  br label %bb71
bb71:
  br label %bb129
bb72:
  %t280 = load ptr, ptr %l1, !tbaa !29
  store ptr %t280, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t281 = load ptr, ptr %l143, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb73, label %bb74
bb73:
  %t284 = load ptr, ptr %l143, !tbaa !29
  %t285 = load i64, ptr %t284, !range !{i64 0, i64 17}
  %t287 = icmp eq i64 %t285, 11
  store i1 %t287, ptr %l144, !tbaa !21
  br label %bb74
bb74:
  %t288 = load i1, ptr %l144, !tbaa !21
  br i1 %t288, label %bb75, label %bb76
bb75:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr { i64, [3 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", ptr }, ptr %t291, i32 0, i32 1
  %t293 = load ptr, ptr %t292
  store ptr %t293, ptr %l13, !tbaa !29
  br label %bb77
bb76:
  br label %bb79
bb77:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t295, ptr %t296)
  br label %bb78
bb78:
  br label %bb129
bb79:
  %t300 = load ptr, ptr %l1, !tbaa !29
  store ptr %t300, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t301 = load ptr, ptr %l152, !tbaa !29
  %t302 = icmp ne ptr %t301, null
  br i1 %t302, label %bb80, label %bb81
bb80:
  %t304 = load ptr, ptr %l152, !tbaa !29
  %t305 = load i64, ptr %t304, !range !{i64 0, i64 17}
  %t307 = icmp eq i64 %t305, 12
  store i1 %t307, ptr %l153, !tbaa !21
  br label %bb81
bb81:
  %t308 = load i1, ptr %l153, !tbaa !21
  br i1 %t308, label %bb82, label %bb83
bb82:
  %t309 = load ptr, ptr %l1, !tbaa !29
  %t311 = getelementptr { i64, [3 x i64] }, ptr %t309, i32 0, i32 1
  %t312 = getelementptr { %"compiler/source:Span", ptr }, ptr %t311, i32 0, i32 1
  %t313 = load ptr, ptr %t312
  store ptr %t313, ptr %l14, !tbaa !29
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2elaterBlock(ptr %v0, ptr %v1, ptr %t315, ptr %t316)
  br label %bb85
bb85:
  br label %bb129
bb86:
  %t320 = load ptr, ptr %l1, !tbaa !29
  store ptr %t320, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t321 = load ptr, ptr %l161, !tbaa !29
  %t322 = icmp ne ptr %t321, null
  br i1 %t322, label %bb87, label %bb88
bb87:
  %t324 = load ptr, ptr %l161, !tbaa !29
  %t325 = load i64, ptr %t324, !range !{i64 0, i64 17}
  %t327 = icmp eq i64 %t325, 13
  store i1 %t327, ptr %l162, !tbaa !21
  br label %bb88
bb88:
  %t328 = load i1, ptr %l162, !tbaa !21
  br i1 %t328, label %bb89, label %bb90
bb89:
  %t329 = load ptr, ptr %l1, !tbaa !29
  %t331 = getelementptr { i64, [3 x i64] }, ptr %t329, i32 0, i32 1
  %t332 = getelementptr { %"compiler/source:Span", ptr }, ptr %t331, i32 0, i32 1
  %t333 = load ptr, ptr %t332
  store ptr %t333, ptr %l15, !tbaa !29
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l15, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Join", ptr %t336, i32 0, i32 0
  %t339 = load ptr, ptr %t338, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eBlock(ptr %v0, ptr %v1, ptr %t335, ptr %t339)
  br label %bb92
bb92:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l171, !tbaa !29
  %t344 = load ptr, ptr %l171, !tbaa !29
  %t345 = getelementptr %"compiler/typed:LastUses", ptr %t344, i32 0, i32 5
  %t346 = load i64, ptr %t345, !tbaa !24
  %t348 = add i64 %t346, 1
  %t350 = load ptr, ptr %l171, !tbaa !29
  %t351 = getelementptr %"compiler/typed:LastUses", ptr %t350, i32 0, i32 5
  store i64 %t348, ptr %t351, !tbaa !24
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load ptr, ptr %l15, !tbaa !29
  %t355 = getelementptr %"compiler/typed:Join", ptr %t353, i32 0, i32 2
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %t352, { i64, ptr } %t356)
  br label %bb93
bb93:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l177, !tbaa !29
  %t360 = load ptr, ptr %l177, !tbaa !29
  %t361 = getelementptr %"compiler/typed:LastUses", ptr %t360, i32 0, i32 5
  %t362 = load i64, ptr %t361, !tbaa !24
  %t364 = sub i64 %t362, 1
  %t366 = load ptr, ptr %l177, !tbaa !29
  %t367 = getelementptr %"compiler/typed:LastUses", ptr %t366, i32 0, i32 5
  store i64 %t364, ptr %t367, !tbaa !24
  br label %bb129
bb94:
  %t368 = load ptr, ptr %l1, !tbaa !29
  store ptr %t368, ptr %l180, !tbaa !29
  store i1 false, ptr %l181, !tbaa !21
  %t369 = load ptr, ptr %l180, !tbaa !29
  %t370 = icmp ne ptr %t369, null
  br i1 %t370, label %bb95, label %bb96
bb95:
  %t372 = load ptr, ptr %l180, !tbaa !29
  %t373 = load i64, ptr %t372, !range !{i64 0, i64 17}
  %t375 = icmp eq i64 %t373, 14
  store i1 %t375, ptr %l181, !tbaa !21
  br label %bb96
bb96:
  %t376 = load i1, ptr %l181, !tbaa !21
  br i1 %t376, label %bb97, label %bb98
bb97:
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr { i64, [3 x i64] }, ptr %t377, i32 0, i32 1
  %t380 = getelementptr { %"compiler/source:Span", ptr }, ptr %t379, i32 0, i32 1
  %t381 = load ptr, ptr %t380
  store ptr %t381, ptr %l16, !tbaa !29
  br label %bb99
bb98:
  br label %bb118
bb99:
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l186, !tbaa !29
  %t384 = load ptr, ptr %l186, !tbaa !29
  %t385 = getelementptr %"compiler/typed:LastUses", ptr %t384, i32 0, i32 5
  %t386 = load i64, ptr %t385, !tbaa !24
  %t388 = add i64 %t386, 1
  %t390 = load ptr, ptr %l186, !tbaa !29
  %t391 = getelementptr %"compiler/typed:LastUses", ptr %t390, i32 0, i32 5
  store i64 %t388, ptr %t391, !tbaa !24
  %t392 = load ptr, ptr %l16, !tbaa !29
  %t394 = getelementptr %"compiler/typed:Spawn", ptr %t392, i32 0, i32 0
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  store { i64, ptr } %t395, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t397 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t399 = extractvalue { i64, ptr } %t397, 0
  store i64 %t399, ptr %l19, !tbaa !24
  br label %bb100
bb100:
  %t401 = load i64, ptr %l18, !tbaa !24
  %t402 = load i64, ptr %l19, !tbaa !24
  %t405 = icmp slt i64 %t401, %t402
  %t407 = xor i1 %t405, true
  br i1 %t407, label %bb101, label %bb102
bb101:
  br label %bb109
bb102:
  br label %bb103
bb103:
  %t409 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t409, ptr %l197, !tbaa !27
  %t410 = load i64, ptr %l18, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr ptr, ptr %t413, i64 %t410
  %t415 = load ptr, ptr %t414, !tbaa !39
  store ptr %t415, ptr %l20, !tbaa !29
  %t417 = load ptr, ptr %l20, !tbaa !29
  %t419 = icmp eq ptr %t417, null
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb104, label %bb105
bb104:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eplace(ptr %v0, ptr %v1, ptr %t423, ptr %t424)
  br label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t427 = load i64, ptr %l18, !tbaa !24
  %t429 = add i64 %t427, 1
  store i64 %t429, ptr %l18, !tbaa !24
  br label %bb100
bb109:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load ptr, ptr %l16, !tbaa !29
  %t434 = getelementptr %"compiler/typed:Spawn", ptr %t432, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t431, ptr %t435)
  br label %bb110
bb110:
  %t439 = load ptr, ptr %l16, !tbaa !29
  %t441 = getelementptr %"compiler/typed:Spawn", ptr %t439, i32 0, i32 2
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  store { i64, ptr } %t442, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t444 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t444, 0
  store i64 %t446, ptr %l23, !tbaa !24
  br label %bb111
bb111:
  %t448 = load i64, ptr %l22, !tbaa !24
  %t449 = load i64, ptr %l23, !tbaa !24
  %t452 = icmp slt i64 %t448, %t449
  %t454 = xor i1 %t452, true
  br i1 %t454, label %bb112, label %bb113
bb112:
  br label %bb117
bb113:
  br label %bb114
bb114:
  %t456 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t456, ptr %l219, !tbaa !27
  %t457 = load i64, ptr %l22, !tbaa !24
  %t459 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !27
  %t461 = getelementptr ptr, ptr %t460, i64 %t457
  %t462 = load ptr, ptr %t461, !tbaa !39
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/typed:TaskClause", ptr %t462, i32 0, i32 3
  %t468 = load ptr, ptr %t467, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %t464, ptr %t468)
  br label %bb115
bb115:
  br label %bb116
bb116:
  %t471 = load i64, ptr %l22, !tbaa !24
  %t473 = add i64 %t471, 1
  store i64 %t473, ptr %l22, !tbaa !24
  br label %bb111
bb117:
  %t475 = load ptr, ptr %l0, !tbaa !29
  store ptr %t475, ptr %l227, !tbaa !29
  %t476 = load ptr, ptr %l227, !tbaa !29
  %t477 = getelementptr %"compiler/typed:LastUses", ptr %t476, i32 0, i32 5
  %t478 = load i64, ptr %t477, !tbaa !24
  %t480 = sub i64 %t478, 1
  %t482 = load ptr, ptr %l227, !tbaa !29
  %t483 = getelementptr %"compiler/typed:LastUses", ptr %t482, i32 0, i32 5
  store i64 %t480, ptr %t483, !tbaa !24
  br label %bb129
bb118:
  %t484 = load ptr, ptr %l1, !tbaa !29
  store ptr %t484, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t485 = load ptr, ptr %l230, !tbaa !29
  %t486 = icmp ne ptr %t485, null
  br i1 %t486, label %bb119, label %bb120
bb119:
  %t488 = load ptr, ptr %l230, !tbaa !29
  %t489 = load i64, ptr %t488, !range !{i64 0, i64 17}
  %t491 = icmp eq i64 %t489, 5
  store i1 %t491, ptr %l231, !tbaa !21
  br label %bb120
bb120:
  %t492 = load i1, ptr %l231, !tbaa !21
  br i1 %t492, label %bb121, label %bb122
bb121:
  br label %bb127
bb122:
  %t493 = load ptr, ptr %l1, !tbaa !29
  store ptr %t493, ptr %l234, !tbaa !29
  store i1 false, ptr %l235, !tbaa !21
  %t494 = load ptr, ptr %l234, !tbaa !29
  %t495 = icmp ne ptr %t494, null
  br i1 %t495, label %bb123, label %bb124
bb123:
  %t497 = load ptr, ptr %l234, !tbaa !29
  %t498 = load i64, ptr %t497, !range !{i64 0, i64 17}
  %t500 = icmp eq i64 %t498, 7
  store i1 %t500, ptr %l235, !tbaa !21
  br label %bb124
bb124:
  %t501 = load i1, ptr %l235, !tbaa !21
  br i1 %t501, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  br label %bb128
bb127:
  br label %bb129
bb128:
  call void @__olang_check_failed(ptr @olang_loc_b7d0c4ef23cb16fa_bb49bf88955879a6)
  unreachable
bb129:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l37 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l61 = alloca i1
  %l67 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l95 = alloca i64
  %l102 = alloca ptr
  %l106 = alloca i64
  %l108 = alloca ptr
  %l112 = alloca i64
  %l117 = alloca i64
  %l122 = alloca i64
  %l125 = alloca i64
  %l146 = alloca i64
  %l153 = alloca ptr
  %l157 = alloca i64
  %l159 = alloca ptr
  %l163 = alloca i64
  %l168 = alloca i64
  %l172 = alloca i64
  %l175 = alloca i64
  %l196 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l25
  br label %bb1
bb1:
  %t8 = load i1, ptr %l25, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/typed:LocalUses", ptr %t9, i32 0, i32 4
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l30
  br label %bb4
bb4:
  %t16 = load i1, ptr %l30, !tbaa !21
  store i1 %t16, ptr %l26, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l26, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:LocalUses", ptr %t18, i32 0, i32 2
  %t21 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t20, i64 %t21, i1 true)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:LocalUses", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %l1, !tbaa !24
  %t30 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t26, i64 %t27)
  store i1 %t30, ptr %l37
  br label %bb10
bb10:
  %t31 = load i1, ptr %l37, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/typed:LocalUses", ptr %t32, i32 0, i32 3
  %t35 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t34, i64 %t35, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:LocalUses", ptr %t38, i32 0, i32 5
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t40, i64 %t41)
  store i1 %t44, ptr %l44
  br label %bb15
bb15:
  %t45 = load i1, ptr %l44, !tbaa !21
  br i1 %t45, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb19
bb17:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:LocalUses", ptr %t46, i32 0, i32 7
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l49
  br label %bb18
bb18:
  %t53 = load i1, ptr %l49, !tbaa !21
  store i1 %t53, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l45, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/typed:LocalUses", ptr %t55, i32 0, i32 5
  %t58 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58, i1 true)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/typed:LocalUses", ptr %t61, i32 0, i32 6
  %t64 = load i64, ptr %l1, !tbaa !24
  %t67 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t63, i64 %t64)
  store i1 %t67, ptr %l56
  br label %bb24
bb24:
  %t68 = load i1, ptr %l56, !tbaa !21
  br i1 %t68, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb28
bb26:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/typed:LocalUses", ptr %t69, i32 0, i32 7
  %t72 = load i64, ptr %l1, !tbaa !24
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l61
  br label %bb27
bb27:
  %t76 = load i1, ptr %l61, !tbaa !21
  store i1 %t76, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l57, !tbaa !21
  br i1 %t77, label %bb29, label %bb30
bb29:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/typed:LocalUses", ptr %t78, i32 0, i32 6
  %t81 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t80, i64 %t81, i1 true)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  store i64 0, ptr %l3, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:LocalUses", ptr %t84, i32 0, i32 15
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l67
  br label %bb33
bb33:
  %t89 = load i64, ptr %l67, !tbaa !24
  store i64 %t89, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t90 = load i64, ptr %l4, !tbaa !24
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb34, label %bb35
bb34:
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb36, label %bb37
bb35:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb39
bb36:
  %t100 = load i64, ptr %l4, !tbaa !24
  %t101 = load i64, ptr %l3, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l5, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l74, !tbaa !24
  br label %bb38
bb37:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb38
bb38:
  %t116 = load i64, ptr %l74, !tbaa !24
  store i64 %t116, ptr %l71, !tbaa !24
  br label %bb39
bb39:
  %t117 = load i64, ptr %l71, !tbaa !24
  store i64 %t117, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb40
bb40:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb41, label %bb42
bb41:
  br label %bb54
bb42:
  br label %bb43
bb43:
  %t126 = load i64, ptr %l3, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t128 = load i64, ptr %l5, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l8, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/typed:LocalUses", ptr %t136, i32 0, i32 15
  %t139 = load i64, ptr %l8, !tbaa !24
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t138, i64 %t139)
  store i64 %t142, ptr %l95
  br label %bb44
bb44:
  %t143 = load i64, ptr %l1, !tbaa !24
  %t144 = load i64, ptr %l95, !tbaa !24
  %t146 = icmp ne i64 %t144, %t143
  br i1 %t146, label %bb45, label %bb46
bb45:
  br label %bb53
bb46:
  br label %bb47
bb47:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/typed:LocalUses", ptr %t148, i32 0, i32 15
  %t151 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  br label %bb48
bb48:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/typed:LocalUses", ptr %t154, i32 0, i32 16
  store ptr %t156, ptr %l102, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 16
  %t160 = load i64, ptr %l8, !tbaa !24
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l106
  br label %bb49
bb49:
  %t164 = load ptr, ptr %l102, !tbaa !29
  %t165 = load i64, ptr %l106, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t164, i64 %t165)
  br label %bb50
bb50:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/typed:LocalUses", ptr %t166, i32 0, i32 17
  store ptr %t168, ptr %l108, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/typed:LocalUses", ptr %t169, i32 0, i32 17
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l112
  br label %bb51
bb51:
  %t176 = load ptr, ptr %l108, !tbaa !29
  %t177 = load i64, ptr %l112, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t176, i64 %t177)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t178 = load i64, ptr %l7, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l7, !tbaa !24
  br label %bb40
bb54:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/typed:LocalUses", ptr %t182, i32 0, i32 12
  %t186 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t184)
  store i64 %t186, ptr %l117
  br label %bb55
bb55:
  %t187 = load i64, ptr %l117, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  store i64 %t187, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load i64, ptr %l10, !tbaa !24
  %t194 = icmp sgt i64 %t190, %t191
  br i1 %t194, label %bb56, label %bb57
bb56:
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = icmp sgt i64 %t196, 0
  br i1 %t198, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l122, !tbaa !24
  br label %bb61
bb58:
  %t200 = load i64, ptr %l11, !tbaa !24
  %t201 = load i64, ptr %l10, !tbaa !24
  %t204 = sub i64 %t200, %t201
  %t205 = load i64, ptr %l12, !tbaa !24
  %t208 = add i64 %t204, %t205
  %t210 = sub i64 %t208, 1
  %t211 = load i64, ptr %l12, !tbaa !24
  %t214 = sdiv i64 %t210, %t211
  store i64 %t214, ptr %l125, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l125, !tbaa !24
  br label %bb60
bb60:
  %t216 = load i64, ptr %l125, !tbaa !24
  store i64 %t216, ptr %l122, !tbaa !24
  br label %bb61
bb61:
  %t217 = load i64, ptr %l122, !tbaa !24
  store i64 %t217, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb62
bb62:
  %t218 = load i64, ptr %l14, !tbaa !24
  %t219 = load i64, ptr %l13, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb63, label %bb64
bb63:
  br label %bb76
bb64:
  br label %bb65
bb65:
  %t226 = load i64, ptr %l10, !tbaa !24
  %t227 = load i64, ptr %l14, !tbaa !24
  %t228 = load i64, ptr %l12, !tbaa !24
  %t231 = mul i64 %t227, %t228
  %t234 = add i64 %t226, %t231
  store i64 %t234, ptr %l15, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/typed:LocalUses", ptr %t236, i32 0, i32 12
  %t239 = load i64, ptr %l15, !tbaa !24
  %t242 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t238, i64 %t239)
  store i64 %t242, ptr %l146
  br label %bb66
bb66:
  %t243 = load i64, ptr %l1, !tbaa !24
  %t244 = load i64, ptr %l146, !tbaa !24
  %t246 = icmp ne i64 %t244, %t243
  br i1 %t246, label %bb67, label %bb68
bb67:
  br label %bb75
bb68:
  br label %bb69
bb69:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/typed:LocalUses", ptr %t248, i32 0, i32 12
  %t251 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t250, i64 %t251)
  br label %bb70
bb70:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"compiler/typed:LocalUses", ptr %t254, i32 0, i32 13
  store ptr %t256, ptr %l153, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/typed:LocalUses", ptr %t257, i32 0, i32 13
  %t260 = load i64, ptr %l15, !tbaa !24
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t259, i64 %t260)
  store i64 %t263, ptr %l157
  br label %bb71
bb71:
  %t264 = load ptr, ptr %l153, !tbaa !29
  %t265 = load i64, ptr %l157, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t264, i64 %t265)
  br label %bb72
bb72:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/typed:LocalUses", ptr %t266, i32 0, i32 14
  store ptr %t268, ptr %l159, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/typed:LocalUses", ptr %t269, i32 0, i32 14
  %t272 = load i64, ptr %l15, !tbaa !24
  %t275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t271, i64 %t272)
  store i64 %t275, ptr %l163
  br label %bb73
bb73:
  %t276 = load ptr, ptr %l159, !tbaa !29
  %t277 = load i64, ptr %l163, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t276, i64 %t277)
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t278 = load i64, ptr %l14, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l14, !tbaa !24
  br label %bb62
bb76:
  store i64 0, ptr %l16, !tbaa !24
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/typed:LocalUses", ptr %t282, i32 0, i32 10
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l168
  br label %bb77
bb77:
  %t287 = load i64, ptr %l168, !tbaa !24
  store i64 %t287, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t288 = load i64, ptr %l17, !tbaa !24
  %t289 = load i64, ptr %l16, !tbaa !24
  %t292 = icmp sgt i64 %t288, %t289
  br i1 %t292, label %bb78, label %bb79
bb78:
  %t294 = load i64, ptr %l18, !tbaa !24
  %t296 = icmp sgt i64 %t294, 0
  br i1 %t296, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb83
bb80:
  %t298 = load i64, ptr %l17, !tbaa !24
  %t299 = load i64, ptr %l16, !tbaa !24
  %t302 = sub i64 %t298, %t299
  %t303 = load i64, ptr %l18, !tbaa !24
  %t306 = add i64 %t302, %t303
  %t308 = sub i64 %t306, 1
  %t309 = load i64, ptr %l18, !tbaa !24
  %t312 = sdiv i64 %t308, %t309
  store i64 %t312, ptr %l175, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb82
bb82:
  %t314 = load i64, ptr %l175, !tbaa !24
  store i64 %t314, ptr %l172, !tbaa !24
  br label %bb83
bb83:
  %t315 = load i64, ptr %l172, !tbaa !24
  store i64 %t315, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb84
bb84:
  %t316 = load i64, ptr %l20, !tbaa !24
  %t317 = load i64, ptr %l19, !tbaa !24
  %t320 = icmp slt i64 %t316, %t317
  %t322 = xor i1 %t320, true
  br i1 %t322, label %bb85, label %bb86
bb85:
  br label %bb94
bb86:
  br label %bb87
bb87:
  %t324 = load i64, ptr %l16, !tbaa !24
  %t325 = load i64, ptr %l20, !tbaa !24
  %t326 = load i64, ptr %l18, !tbaa !24
  %t329 = mul i64 %t325, %t326
  %t332 = add i64 %t324, %t329
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/typed:LocalUses", ptr %t334, i32 0, i32 10
  %t340 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t336, i64 %t332)
  store i64 %t340, ptr %l196
  br label %bb88
bb88:
  %t341 = load i64, ptr %l1, !tbaa !24
  %t342 = load i64, ptr %l196, !tbaa !24
  %t344 = icmp eq i64 %t342, %t341
  br i1 %t344, label %bb89, label %bb90
bb89:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/typed:LocalUses", ptr %t346, i32 0, i32 2
  %t349 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t348, i64 %t349, i1 true)
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t352 = load i64, ptr %l20, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l20, !tbaa !24
  br label %bb84
bb94:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l36 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l11
  br label %bb2
bb2:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sge i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t16 = load ptr, ptr %l15, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 8}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l16, !tbaa !21
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load %"compiler/source:Span", ptr %t28
  store %"compiler/source:Span" %t29, ptr %l4
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t39, i32 0, i32 2
  %t41 = load i32, ptr %t40
  store i32 %t41, ptr %l6, !tbaa !23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:LocalUses", ptr %t43, i32 0, i32 4
  %t46 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t45, i64 %t46, i1 true)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %ret
bb11:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = icmp sge i64 %t49, 0
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t54 = load ptr, ptr %l31, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb14:
  %t57 = load ptr, ptr %l31, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 8}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l32, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l30, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/typed:LocalUses", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  store ptr %t68, ptr %l38, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t69)
  store i32 %t71, ptr %l40
  br label %bb19
bb18:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb21
bb19:
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = call ptr @__olang_scope_of(ptr %t72, ptr null)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l38, !tbaa !29
  %t78 = load i32, ptr %l40, !tbaa !23
  %t79 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t76, ptr %t77, i32 %t78)
  store i1 %t79, ptr %l42
  br label %bb20
bb20:
  %t80 = load i1, ptr %l42, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t83 = load i1, ptr %l36, !tbaa !21
  br i1 %t83, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t88 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  store i1 %t88, ptr %l47
  br label %bb24
bb23:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb25
bb24:
  %t89 = load i1, ptr %l47, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l44, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l44, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:LocalUses", ptr %t93, i32 0, i32 10
  %t96 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t95, i64 %t96)
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/typed:LocalUses", ptr %t99, i32 0, i32 11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v2, ptr %t101, ptr %a2)
  br label %bb29
bb29:
  br label %ret
bb30:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %t105, ptr %t106, i1 false)
  br label %bb31
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eborrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, [1 x i64] }
  %l5 = alloca ptr
  %l8 = alloca i64
  %l22 = alloca i1
  %t34 = alloca { i64, [1 x i64] }, align 8
  %t51 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [1 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = call ptr @__olang_scope_of(ptr %t6, ptr null)
  %t8 = ptrtoint ptr %t7 to i64
  %t10 = inttoptr i64 %t8 to ptr
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %t10, ptr %t11, i32 %a2)
  store i64 %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t15 = load i64, ptr %l8, !tbaa !24
  %t17 = and i64 %t15, %t14
  %t19 = icmp ne i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %t21, ptr %t22, i1 true)
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t25 = load { i64, [1 x i64] }, ptr %l3
  %t27 = extractvalue { i64, [1 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 1
  %t30 = xor i1 %t28, true
  br i1 %t30, label %bb5, label %bb6
bb5:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 0
  store i64 5, ptr %t35
  %t36 = load { i64, [1 x i64] }, ptr %t34
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %t32, ptr %t33, { i64, [1 x i64] } %t36, i1 true)
  br label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %ret
bb9:
  %t40 = load { i64, [1 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [1 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 3
  br i1 %t43, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb12
bb11:
  %t45 = load { i64, [1 x i64] }, ptr %l3
  %t47 = extractvalue { i64, [1 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 2
  store i1 %t48, ptr %l22, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l22, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  store { i64, [1 x i64] } zeroinitializer, ptr %t51
  %t52 = getelementptr { i64, [1 x i64] }, ptr %t51, i32 0, i32 0
  store i64 5, ptr %t52
  %t53 = load { i64, [1 x i64] }, ptr %t51
  store { i64, [1 x i64] } %t53, ptr %l3
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t57 = load { i64, [1 x i64] }, ptr %l3
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %t55, ptr %t56, { i64, [1 x i64] } %t57, i1 true)
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l74 = alloca i64
  %l77 = alloca i1
  %l80 = alloca i1
  %l100 = alloca ptr
  %l104 = alloca i1
  %l107 = alloca i1
  %l125 = alloca ptr
  %l127 = alloca i32
  %l129 = alloca i1
  %l130 = alloca i1
  %l134 = alloca i1
  %l137 = alloca i1
  %l141 = alloca i1
  %l146 = alloca i1
  %l147 = alloca ptr
  %l149 = alloca ptr
  %l151 = alloca { i64, [1 x i64] }
  %t43 = alloca { i64, [1 x i64] }, align 8
  %t277 = alloca { i64, [1 x i64] }, align 8
  %t281 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t7 = load ptr, ptr %l19, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l20, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t21 = load i32, ptr %l5, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l2, !tbaa !24
  br label %bb24
bb6:
  %t25 = load ptr, ptr %l4, !tbaa !29
  store ptr %t25, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t26 = load ptr, ptr %l27, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l27, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 5}
  %t32 = icmp eq i64 %t30, 2
  store i1 %t32, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l28, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { ptr }, ptr %t36, i32 0, i32 0
  %t38 = load ptr, ptr %t37
  store ptr %t38, ptr %l6, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t43
  %t44 = getelementptr { i64, [1 x i64] }, ptr %t43, i32 0, i32 0
  store i64 0, ptr %t44
  %t45 = load { i64, [1 x i64] }, ptr %t43
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t40, ptr %t41, { i64, [1 x i64] } %t45)
  br label %bb12
bb12:
  br label %bb24
bb13:
  %t49 = load ptr, ptr %l4, !tbaa !29
  store ptr %t49, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t50 = load ptr, ptr %l37, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l37, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 5}
  %t56 = icmp eq i64 %t54, 4
  store i1 %t56, ptr %l38, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l38, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_6ff368c26ca3ad9b_74caa00555ca222f)
  unreachable
bb24:
  store i64 0, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Call", ptr %t58, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb25, label %bb26
bb25:
  %t71 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb30
bb27:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l7, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l9, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l50, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb29
bb29:
  %t91 = load i64, ptr %l50, !tbaa !24
  store i64 %t91, ptr %l47, !tbaa !24
  br label %bb30
bb30:
  %t92 = load i64, ptr %l47, !tbaa !24
  store i64 %t92, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb31
bb31:
  %t93 = load i64, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l10, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb32, label %bb33
bb32:
  br label %bb89
bb33:
  br label %bb34
bb34:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l12, !tbaa !24
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l69, !tbaa !27
  %t115 = load i64, ptr %l12, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  store ptr %t120, ptr %l13, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l13, !tbaa !29
  %t126 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elendOf(ptr %v0, ptr %v1, ptr %t122, ptr %t123)
  store i64 %t126, ptr %l74
  br label %bb35
bb35:
  %t127 = load i64, ptr %l74, !tbaa !24
  store i64 %t127, ptr %l14, !tbaa !24
  %t128 = load i64, ptr %l14, !tbaa !24
  %t130 = icmp sge i64 %t128, 0
  br i1 %t130, label %bb36, label %bb37
bb36:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t134 = icmp sge i64 %t132, 0
  store i1 %t134, ptr %l77, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb38
bb38:
  %t136 = load i1, ptr %l77, !tbaa !21
  br i1 %t136, label %bb39, label %bb40
bb39:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/typed:LocalUses", ptr %t137, i32 0, i32 23
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = icmp eq i64 %t140, 0
  store i1 %t142, ptr %l80, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t144 = load i1, ptr %l80, !tbaa !21
  br i1 %t144, label %bb42, label %bb43
bb42:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:LocalUses", ptr %t145, i32 0, i32 12
  %t148 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t147, i64 %t148)
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/typed:LocalUses", ptr %t151, i32 0, i32 13
  %t154 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t153, i64 %t154)
  br label %bb45
bb45:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:LocalUses", ptr %t157, i32 0, i32 14
  %t160 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t159, i64 %t160)
  br label %bb46
bb46:
  br label %bb88
bb47:
  %t163 = load i64, ptr %l14, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  br i1 %t165, label %bb48, label %bb49
bb48:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/typed:LocalUses", ptr %t167, i32 0, i32 2
  %t170 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t169, i64 %t170, i1 true)
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l13, !tbaa !29
  %t177 = call ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v1, ptr %t173, ptr %t174)
  store ptr %t177, ptr %l100
  br label %bb52
bb52:
  %t178 = load ptr, ptr %l100, !tbaa !29
  store ptr %t178, ptr %l15, !tbaa !29
  %t179 = load ptr, ptr %l15, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb53, label %bb54
bb53:
  %t185 = load i64, ptr %l2, !tbaa !24
  %t187 = icmp sge i64 %t185, 0
  store i1 %t187, ptr %l104, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l104, !tbaa !21
  br label %bb55
bb55:
  %t189 = load i1, ptr %l104, !tbaa !21
  br i1 %t189, label %bb56, label %bb57
bb56:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/typed:LocalUses", ptr %t190, i32 0, i32 23
  %t193 = load i64, ptr %t192, !tbaa !24
  %t195 = icmp eq i64 %t193, 0
  store i1 %t195, ptr %l107, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb58
bb58:
  %t197 = load i1, ptr %l107, !tbaa !21
  br i1 %t197, label %bb59, label %bb60
bb59:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/typed:LocalUses", ptr %t198, i32 0, i32 19
  %t201 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t200, ptr %t201)
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/typed:LocalUses", ptr %t204, i32 0, i32 20
  %t207 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t206, i64 %t207)
  br label %bb62
bb62:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = getelementptr %"compiler/typed:LocalUses", ptr %t210, i32 0, i32 21
  %t213 = load i64, ptr %l12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t212, i64 %t213)
  br label %bb63
bb63:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/typed:LocalUses", ptr %t216, i32 0, i32 22
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/typed:LocalUses", ptr %t219, i32 0, i32 24
  %t222 = load i32, ptr %t221, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t218, i32 %t222)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/typed:LocalUses", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  store ptr %t228, ptr %l125, !tbaa !29
  %t229 = load ptr, ptr %l13, !tbaa !29
  %t231 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t229)
  store i32 %t231, ptr %l127
  br label %bb66
bb66:
  %t232 = load ptr, ptr %l125, !tbaa !29
  %t233 = call ptr @__olang_scope_of(ptr %t232, ptr null)
  %t234 = ptrtoint ptr %t233 to i64
  %t236 = inttoptr i64 %t234 to ptr
  %t237 = load ptr, ptr %l125, !tbaa !29
  %t238 = load i32, ptr %l127, !tbaa !23
  %t239 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t236, ptr %t237, i32 %t238)
  store i1 %t239, ptr %l129
  br label %bb67
bb67:
  %t240 = load i1, ptr %l129, !tbaa !21
  br i1 %t240, label %bb68, label %bb69
bb68:
  %t241 = load i1, ptr %l3, !tbaa !21
  %t243 = xor i1 %t241, true
  store i1 %t243, ptr %l130, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb70
bb70:
  %t245 = load i1, ptr %l130, !tbaa !21
  store i1 %t245, ptr %l16, !tbaa !21
  %t246 = load i1, ptr %l16, !tbaa !21
  br i1 %t246, label %bb71, label %bb72
bb71:
  %t248 = load i64, ptr %l2, !tbaa !24
  %t250 = icmp sge i64 %t248, 0
  store i1 %t250, ptr %l134, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb73
bb73:
  %t252 = load i1, ptr %l134, !tbaa !21
  br i1 %t252, label %bb74, label %bb75
bb74:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/typed:LocalUses", ptr %t253, i32 0, i32 23
  %t256 = load i64, ptr %t255, !tbaa !24
  %t258 = icmp eq i64 %t256, 0
  store i1 %t258, ptr %l137, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb76
bb76:
  %t260 = load i1, ptr %l137, !tbaa !21
  br i1 %t260, label %bb77, label %bb78
bb77:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load ptr, ptr %l13, !tbaa !29
  %t263 = load i64, ptr %l2, !tbaa !24
  %t264 = load i64, ptr %l12, !tbaa !24
  %t269 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %t261, ptr %t262, i64 %t263, i64 %t264)
  store i1 %t269, ptr %l146
  br label %bb79
bb78:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb80
bb79:
  %t270 = load i1, ptr %l146, !tbaa !21
  store i1 %t270, ptr %l141, !tbaa !21
  br label %bb80
bb80:
  %t271 = load i1, ptr %l141, !tbaa !21
  br i1 %t271, label %bb81, label %bb82
bb81:
  br label %bb88
bb82:
  br label %bb83
bb83:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l147, !tbaa !29
  %t273 = load ptr, ptr %l13, !tbaa !29
  store ptr %t273, ptr %l149, !tbaa !29
  %t275 = load i1, ptr %l16, !tbaa !21
  br i1 %t275, label %bb84, label %bb85
bb84:
  store { i64, [1 x i64] } zeroinitializer, ptr %t277
  %t278 = getelementptr { i64, [1 x i64] }, ptr %t277, i32 0, i32 0
  store i64 5, ptr %t278
  %t279 = load { i64, [1 x i64] }, ptr %t277
  store { i64, [1 x i64] } %t279, ptr %l151
  br label %bb86
bb85:
  store { i64, [1 x i64] } zeroinitializer, ptr %t281
  %t282 = getelementptr { i64, [1 x i64] }, ptr %t281, i32 0, i32 0
  store i64 1, ptr %t282
  %t283 = load { i64, [1 x i64] }, ptr %t281
  store { i64, [1 x i64] } %t283, ptr %l151
  br label %bb86
bb86:
  %t285 = load ptr, ptr %l147, !tbaa !29
  %t286 = load ptr, ptr %l149, !tbaa !29
  %t287 = load { i64, [1 x i64] }, ptr %l151
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t285, ptr %t286, { i64, [1 x i64] } %t287)
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t288 = load i64, ptr %l11, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l11, !tbaa !24
  br label %bb31
bb89:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ecloseAliases(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l5 = alloca i64
  %l13 = alloca i64
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:LocalUses", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = sub i64 %t6, 1
  store i64 %t7, ptr %l1, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sge i64 %t9, 0
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:LocalUses", ptr %t15, i32 0, i32 8
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l13
  br label %bb6
bb6:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t25 = sub i64 %t23, 1
  store i64 %t25, ptr %l1, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t41 = add i64 %t39, 1
  %t42 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ealiasInto(ptr %v0, ptr %t38, i64 %t41, i64 %t42)
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb2
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2efnVal(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l21 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %t44 = alloca { i64, [1 x i64] }, align 8
  %t72 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 3}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t30 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t30, ptr %l21, !tbaa !27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Capture", ptr %t36, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t44
  %t45 = getelementptr { i64, [1 x i64] }, ptr %t44, i32 0, i32 0
  store i64 5, ptr %t45
  %t46 = load { i64, [1 x i64] }, ptr %t44
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t38, ptr %t42, { i64, [1 x i64] } %t46)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l4, !tbaa !24
  br label %bb6
bb12:
  br label %bb27
bb13:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb14, label %bb15
bb14:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 3}
  %t61 = icmp eq i64 %t59, 2
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb15
bb15:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb16, label %bb17
bb16:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { i32, ptr, i32 }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l7, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t72
  %t73 = getelementptr { i64, [1 x i64] }, ptr %t72, i32 0, i32 0
  store i64 5, ptr %t73
  %t74 = load { i64, [1 x i64] }, ptr %t72
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t69, ptr %t70, { i64, [1 x i64] } %t74)
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t79 = load ptr, ptr %l41, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %l41, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 3}
  %t85 = icmp eq i64 %t83, 0
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb22
bb22:
  %t86 = load i1, ptr %l42, !tbaa !21
  br i1 %t86, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_c889b00966965144_dcfe1455a200f620)
  unreachable
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2epieces(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca i1
  %t41 = alloca { i64, [1 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 2}
  %t30 = icmp eq i64 %t28, 1
  store i1 %t30, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { ptr }, ptr %t34, i32 0, i32 0
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t41
  %t42 = getelementptr { i64, [1 x i64] }, ptr %t41, i32 0, i32 0
  store i64 0, ptr %t42
  %t43 = load { i64, [1 x i64] }, ptr %t41
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %t39, { i64, [1 x i64] } %t43)
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_f1d97b93b21930ce_df2dd3f10bda1132)
  unreachable
bb16:
  br label %bb17
bb17:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l3, !tbaa !24
  br label %bb1
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l46 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i1
  %t48 = alloca { i64, [1 x i64] }, align 8
  %t102 = alloca { i64, [1 x i64] }, align 8
  %t126 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb45
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Elem", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Elem", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t48
  %t49 = getelementptr { i64, [1 x i64] }, ptr %t48, i32 0, i32 0
  store i64 0, ptr %t49
  %t50 = load { i64, [1 x i64] }, ptr %t48
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t42, ptr %t46, { i64, [1 x i64] } %t50)
  br label %bb14
bb14:
  br label %bb45
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t55 = load ptr, ptr %l29, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 8}
  %t61 = icmp eq i64 %t59, 5
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l30, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Payload", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t69, ptr %t73)
  br label %bb21
bb21:
  br label %bb45
bb22:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t77 = load ptr, ptr %l38, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb23, label %bb24
bb23:
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 2
  store i1 %t83, ptr %l39, !tbaa !21
  br label %bb24
bb24:
  %t84 = load i1, ptr %l39, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t87, i32 0, i32 2
  %t89 = load ptr, ptr %t88
  store ptr %t89, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t95 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t91, ptr %t92)
  store i64 %t95, ptr %l46
  br label %bb28
bb28:
  %t96 = load i64, ptr %l46, !tbaa !24
  %t97 = icmp slt i64 %t96, 0
  br i1 %t97, label %bb29, label %bb30
bb29:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l5, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [1 x i64] }, ptr %t102, i32 0, i32 0
  store i64 0, ptr %t103
  %t104 = load { i64, [1 x i64] }, ptr %t102
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t99, ptr %t100, { i64, [1 x i64] } %t104)
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb32
bb32:
  br label %bb45
bb33:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t109 = load ptr, ptr %l52, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l52, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 6
  store i1 %t115, ptr %l53, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l53, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l6, !tbaa !29
  br label %bb38
bb37:
  br label %bb40
bb38:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [1 x i64] }, ptr %t126, i32 0, i32 0
  store i64 0, ptr %t127
  %t128 = load { i64, [1 x i64] }, ptr %t126
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t123, ptr %t124, { i64, [1 x i64] } %t128)
  br label %bb39
bb39:
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_572ff0c594eb7d28_3eb561bfca5d9eb4)
  unreachable
bb45:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l53 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l7, !tbaa !24
  br label %bb39
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t39 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  br label %bb39
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 8}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l26, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l4, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l34
  br label %bb19
bb19:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb39
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t66 = load ptr, ptr %l35, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l35, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l36, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l5, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l44
  br label %bb26
bb26:
  %t88 = load i64, ptr %l44, !tbaa !24
  store i64 %t88, ptr %l7, !tbaa !24
  br label %bb39
bb27:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t90 = load ptr, ptr %l45, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %l45, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l46, !tbaa !21
  br label %bb29
bb29:
  %t97 = load i1, ptr %l46, !tbaa !21
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l6, !tbaa !29
  %t108 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %t104, ptr %t105)
  store i64 %t108, ptr %l53
  br label %bb33
bb33:
  %t109 = load i64, ptr %l53, !tbaa !24
  store i64 %t109, ptr %l7, !tbaa !24
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_6333e3fa20d2f5d8_bcafed7a04540454)
  unreachable
bb39:
  %t110 = load i64, ptr %l7, !tbaa !24
  store i64 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l45 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca i32
  %l53 = alloca i1
  %l54 = alloca { i64, [1 x i64] }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l125 = alloca ptr
  %l126 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i1
  %l191 = alloca ptr
  %l192 = alloca i1
  %l200 = alloca ptr
  %l216 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i1
  %t74 = alloca { i64, [1 x i64] }, align 8
  %t78 = alloca { i64, [1 x i64] }, align 8
  %t118 = alloca { i64, [1 x i64] }, align 8
  %t153 = alloca { i64, [1 x i64] }, align 8
  %t177 = alloca { i64, [1 x i64] }, align 8
  %t200 = alloca { i64, [1 x i64] }, align 8
  %t227 = alloca { i64, [1 x i64] }, align 8
  %t295 = alloca { i64, [1 x i64] }, align 8
  %t325 = alloca { i64, [1 x i64] }, align 8
  %t333 = alloca { i64, [1 x i64] }, align 8
  %t402 = alloca { i64, [1 x i64] }, align 8
  %t445 = alloca { i64, [1 x i64] }, align 8
  %t481 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t24 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %t22, i32 %t23, ptr %t24)
  br label %bb6
bb6:
  br label %bb133
bb7:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t29 = load ptr, ptr %l34, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l34, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 17}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l35, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l35, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t39, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t51 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %t49, ptr %t50, ptr %t51)
  br label %bb13
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l45, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  store ptr %t56, ptr %l47, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:LocalUses", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l49, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t62)
  store i32 %t64, ptr %l51
  br label %bb14
bb14:
  %t65 = load ptr, ptr %l49, !tbaa !29
  %t66 = call ptr @__olang_scope_of(ptr %t65, ptr null)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = load i32, ptr %l51, !tbaa !23
  %t72 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t69, ptr %t70, i32 %t71)
  store i1 %t72, ptr %l53
  br label %bb15
bb15:
  %t73 = load i1, ptr %l53, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t74
  %t75 = getelementptr { i64, [1 x i64] }, ptr %t74, i32 0, i32 0
  store i64 5, ptr %t75
  %t76 = load { i64, [1 x i64] }, ptr %t74
  store { i64, [1 x i64] } %t76, ptr %l54
  br label %bb18
bb17:
  store { i64, [1 x i64] } zeroinitializer, ptr %t78
  %t79 = getelementptr { i64, [1 x i64] }, ptr %t78, i32 0, i32 0
  store i64 2, ptr %t79
  %t80 = load { i64, [1 x i64] }, ptr %t78
  store { i64, [1 x i64] } %t80, ptr %l54
  br label %bb18
bb18:
  %t82 = load ptr, ptr %l45, !tbaa !29
  %t83 = load ptr, ptr %l47, !tbaa !29
  %t84 = load { i64, [1 x i64] }, ptr %l54
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t82, ptr %t83, { i64, [1 x i64] } %t84)
  br label %bb19
bb19:
  br label %bb133
bb20:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t86 = load ptr, ptr %l57, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t89 = load ptr, ptr %l57, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 17}
  %t92 = icmp eq i64 %t90, 2
  store i1 %t92, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t93 = load i1, ptr %l58, !tbaa !21
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [3 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", ptr }, ptr %t96, i32 0, i32 1
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l6, !tbaa !29
  br label %bb29
bb24:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t101 = load ptr, ptr %l63, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l63, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 17}
  %t107 = icmp eq i64 %t105, 8
  store i1 %t107, ptr %l64, !tbaa !21
  br label %bb26
bb26:
  %t108 = load i1, ptr %l64, !tbaa !21
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [3 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l6, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t118
  %t119 = getelementptr { i64, [1 x i64] }, ptr %t118, i32 0, i32 0
  store i64 0, ptr %t119
  %t120 = load { i64, [1 x i64] }, ptr %t118
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t115, ptr %t116, { i64, [1 x i64] } %t120)
  br label %bb30
bb30:
  br label %bb133
bb31:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t125 = load ptr, ptr %l73, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb32, label %bb33
bb32:
  %t128 = load ptr, ptr %l73, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 17}
  %t131 = icmp eq i64 %t129, 6
  store i1 %t131, ptr %l74, !tbaa !21
  br label %bb33
bb33:
  %t132 = load i1, ptr %l74, !tbaa !21
  br i1 %t132, label %bb34, label %bb35
bb34:
  %t133 = load ptr, ptr %l1, !tbaa !29
  %t135 = getelementptr { i64, [3 x i64] }, ptr %t133, i32 0, i32 1
  %t136 = getelementptr { %"compiler/source:Span", ptr }, ptr %t135, i32 0, i32 1
  %t137 = load ptr, ptr %t136
  store ptr %t137, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t139 = load ptr, ptr %l7, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb37, label %bb38
bb37:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/typed:LocalUses", ptr %t145, i32 0, i32 18
  %t148 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t147, ptr %t148)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l7, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t153
  %t154 = getelementptr { i64, [1 x i64] }, ptr %t153, i32 0, i32 0
  store i64 3, ptr %t154
  %t155 = load { i64, [1 x i64] }, ptr %t153
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t151, ptr %t152, { i64, [1 x i64] } %t155)
  br label %bb41
bb41:
  br label %bb133
bb42:
  %t159 = load ptr, ptr %l1, !tbaa !29
  store ptr %t159, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t160 = load ptr, ptr %l88, !tbaa !29
  %t161 = icmp ne ptr %t160, null
  br i1 %t161, label %bb43, label %bb44
bb43:
  %t163 = load ptr, ptr %l88, !tbaa !29
  %t164 = load i64, ptr %t163, !range !{i64 0, i64 17}
  %t166 = icmp eq i64 %t164, 15
  store i1 %t166, ptr %l89, !tbaa !21
  br label %bb44
bb44:
  %t167 = load i1, ptr %l89, !tbaa !21
  br i1 %t167, label %bb45, label %bb46
bb45:
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr { i64, [3 x i64] }, ptr %t168, i32 0, i32 1
  %t171 = getelementptr { %"compiler/source:Span", ptr }, ptr %t170, i32 0, i32 1
  %t172 = load ptr, ptr %t171
  store ptr %t172, ptr %l8, !tbaa !29
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l8, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [1 x i64] }, ptr %t177, i32 0, i32 0
  store i64 5, ptr %t178
  %t179 = load { i64, [1 x i64] }, ptr %t177
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t174, ptr %t175, { i64, [1 x i64] } %t179)
  br label %bb48
bb48:
  br label %bb133
bb49:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t184 = load ptr, ptr %l98, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb50, label %bb51
bb50:
  %t187 = load ptr, ptr %l98, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 17}
  %t190 = icmp eq i64 %t188, 16
  store i1 %t190, ptr %l99, !tbaa !21
  br label %bb51
bb51:
  %t191 = load i1, ptr %l99, !tbaa !21
  br i1 %t191, label %bb52, label %bb53
bb52:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr }, ptr %t194, i32 0, i32 1
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l9, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t200
  %t201 = getelementptr { i64, [1 x i64] }, ptr %t200, i32 0, i32 0
  store i64 5, ptr %t201
  %t202 = load { i64, [1 x i64] }, ptr %t200
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t198, ptr %t199, { i64, [1 x i64] } %t202)
  br label %bb55
bb55:
  br label %bb133
bb56:
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t207 = load ptr, ptr %l107, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb57, label %bb58
bb57:
  %t210 = load ptr, ptr %l107, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 17}
  %t213 = icmp eq i64 %t211, 3
  store i1 %t213, ptr %l108, !tbaa !21
  br label %bb58
bb58:
  %t214 = load i1, ptr %l108, !tbaa !21
  br i1 %t214, label %bb59, label %bb60
bb59:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [3 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l10, !tbaa !29
  br label %bb61
bb60:
  br label %bb65
bb61:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load ptr, ptr %l10, !tbaa !29
  %t224 = getelementptr %"compiler/typed:If", ptr %t222, i32 0, i32 0
  %t225 = load ptr, ptr %t224, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t227
  %t228 = getelementptr { i64, [1 x i64] }, ptr %t227, i32 0, i32 0
  store i64 0, ptr %t228
  %t229 = load { i64, [1 x i64] }, ptr %t227
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t221, ptr %t225, { i64, [1 x i64] } %t229)
  br label %bb62
bb62:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load ptr, ptr %l10, !tbaa !29
  %t236 = getelementptr %"compiler/typed:If", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t233, ptr %t237)
  br label %bb63
bb63:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load ptr, ptr %l10, !tbaa !29
  %t244 = getelementptr %"compiler/typed:If", ptr %t242, i32 0, i32 2
  %t245 = load ptr, ptr %t244, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t241, ptr %t245)
  br label %bb64
bb64:
  br label %bb133
bb65:
  %t248 = load ptr, ptr %l1, !tbaa !29
  store ptr %t248, ptr %l125, !tbaa !29
  store i1 false, ptr %l126, !tbaa !21
  %t249 = load ptr, ptr %l125, !tbaa !29
  %t250 = icmp ne ptr %t249, null
  br i1 %t250, label %bb66, label %bb67
bb66:
  %t252 = load ptr, ptr %l125, !tbaa !29
  %t253 = load i64, ptr %t252, !range !{i64 0, i64 17}
  %t255 = icmp eq i64 %t253, 4
  store i1 %t255, ptr %l126, !tbaa !21
  br label %bb67
bb67:
  %t256 = load i1, ptr %l126, !tbaa !21
  br i1 %t256, label %bb68, label %bb69
bb68:
  %t257 = load ptr, ptr %l1, !tbaa !29
  %t259 = getelementptr { i64, [3 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t259, i32 0, i32 1
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l11, !tbaa !29
  %t263 = load ptr, ptr %l1, !tbaa !29
  %t265 = getelementptr { i64, [3 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t265, i32 0, i32 2
  %t267 = load ptr, ptr %t266
  store ptr %t267, ptr %l12, !tbaa !29
  br label %bb70
bb69:
  br label %bb73
bb70:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t269, ptr %t270)
  br label %bb71
bb71:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t274, ptr %t275)
  br label %bb72
bb72:
  br label %bb133
bb73:
  %t278 = load ptr, ptr %l1, !tbaa !29
  store ptr %t278, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t279 = load ptr, ptr %l138, !tbaa !29
  %t280 = icmp ne ptr %t279, null
  br i1 %t280, label %bb74, label %bb75
bb74:
  %t282 = load ptr, ptr %l138, !tbaa !29
  %t283 = load i64, ptr %t282, !range !{i64 0, i64 17}
  %t285 = icmp eq i64 %t283, 9
  store i1 %t285, ptr %l139, !tbaa !21
  br label %bb75
bb75:
  %t286 = load i1, ptr %l139, !tbaa !21
  br i1 %t286, label %bb76, label %bb77
bb76:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr { i64, [3 x i64] }, ptr %t287, i32 0, i32 1
  %t290 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t289, i32 0, i32 2
  %t291 = load ptr, ptr %t290
  store ptr %t291, ptr %l13, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l13, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [1 x i64] }, ptr %t295, i32 0, i32 0
  store i64 0, ptr %t296
  %t297 = load { i64, [1 x i64] }, ptr %t295
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t293, ptr %t294, { i64, [1 x i64] } %t297)
  br label %bb79
bb79:
  br label %bb133
bb80:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t302 = load ptr, ptr %l147, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb81, label %bb82
bb81:
  %t305 = load ptr, ptr %l147, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 17}
  %t308 = icmp eq i64 %t306, 10
  store i1 %t308, ptr %l148, !tbaa !21
  br label %bb82
bb82:
  %t309 = load i1, ptr %l148, !tbaa !21
  br i1 %t309, label %bb83, label %bb84
bb83:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l14, !tbaa !29
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr { i64, [3 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t318, i32 0, i32 2
  %t320 = load ptr, ptr %t319
  store ptr %t320, ptr %l15, !tbaa !29
  br label %bb85
bb84:
  br label %bb88
bb85:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load ptr, ptr %l14, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t325
  %t326 = getelementptr { i64, [1 x i64] }, ptr %t325, i32 0, i32 0
  store i64 0, ptr %t326
  %t327 = load { i64, [1 x i64] }, ptr %t325
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t322, ptr %t323, { i64, [1 x i64] } %t327)
  br label %bb86
bb86:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l15, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t333
  %t334 = getelementptr { i64, [1 x i64] }, ptr %t333, i32 0, i32 0
  store i64 0, ptr %t334
  %t335 = load { i64, [1 x i64] }, ptr %t333
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t331, ptr %t332, { i64, [1 x i64] } %t335)
  br label %bb87
bb87:
  br label %bb133
bb88:
  %t339 = load ptr, ptr %l1, !tbaa !29
  store ptr %t339, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t340 = load ptr, ptr %l162, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb89, label %bb90
bb89:
  %t343 = load ptr, ptr %l162, !tbaa !29
  %t344 = load i64, ptr %t343, !range !{i64 0, i64 17}
  %t346 = icmp eq i64 %t344, 11
  store i1 %t346, ptr %l163, !tbaa !21
  br label %bb90
bb90:
  %t347 = load i1, ptr %l163, !tbaa !21
  br i1 %t347, label %bb91, label %bb92
bb91:
  %t348 = load ptr, ptr %l1, !tbaa !29
  %t350 = getelementptr { i64, [3 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr }, ptr %t350, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l16, !tbaa !29
  br label %bb97
bb92:
  %t354 = load ptr, ptr %l1, !tbaa !29
  store ptr %t354, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t355 = load ptr, ptr %l168, !tbaa !29
  %t356 = icmp ne ptr %t355, null
  br i1 %t356, label %bb93, label %bb94
bb93:
  %t358 = load ptr, ptr %l168, !tbaa !29
  %t359 = load i64, ptr %t358, !range !{i64 0, i64 17}
  %t361 = icmp eq i64 %t359, 12
  store i1 %t361, ptr %l169, !tbaa !21
  br label %bb94
bb94:
  %t362 = load i1, ptr %l169, !tbaa !21
  br i1 %t362, label %bb95, label %bb96
bb95:
  %t363 = load ptr, ptr %l1, !tbaa !29
  %t365 = getelementptr { i64, [3 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { %"compiler/source:Span", ptr }, ptr %t365, i32 0, i32 1
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l16, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t369, ptr %t370)
  br label %bb98
bb98:
  br label %bb133
bb99:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t375 = load ptr, ptr %l177, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb100, label %bb101
bb100:
  %t378 = load ptr, ptr %l177, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 17}
  %t381 = icmp eq i64 %t379, 13
  store i1 %t381, ptr %l178, !tbaa !21
  br label %bb101
bb101:
  %t382 = load i1, ptr %l178, !tbaa !21
  br i1 %t382, label %bb102, label %bb103
bb102:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [3 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", ptr }, ptr %t385, i32 0, i32 1
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l17, !tbaa !29
  br label %bb104
bb103:
  br label %bb107
bb104:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l17, !tbaa !29
  %t392 = getelementptr %"compiler/typed:Join", ptr %t390, i32 0, i32 0
  %t393 = load ptr, ptr %t392, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %t389, ptr %t393)
  br label %bb105
bb105:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load ptr, ptr %l17, !tbaa !29
  %t400 = getelementptr %"compiler/typed:Join", ptr %t398, i32 0, i32 2
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  store { i64, [1 x i64] } zeroinitializer, ptr %t402
  %t403 = getelementptr { i64, [1 x i64] }, ptr %t402, i32 0, i32 0
  store i64 5, ptr %t403
  %t404 = load { i64, [1 x i64] }, ptr %t402
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %t397, { i64, ptr } %t401, { i64, [1 x i64] } %t404)
  br label %bb106
bb106:
  br label %bb133
bb107:
  %t408 = load ptr, ptr %l1, !tbaa !29
  store ptr %t408, ptr %l191, !tbaa !29
  store i1 false, ptr %l192, !tbaa !21
  %t409 = load ptr, ptr %l191, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb108, label %bb109
bb108:
  %t412 = load ptr, ptr %l191, !tbaa !29
  %t413 = load i64, ptr %t412, !range !{i64 0, i64 17}
  %t415 = icmp eq i64 %t413, 14
  store i1 %t415, ptr %l192, !tbaa !21
  br label %bb109
bb109:
  %t416 = load i1, ptr %l192, !tbaa !21
  br i1 %t416, label %bb110, label %bb111
bb110:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [3 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", ptr }, ptr %t419, i32 0, i32 1
  %t421 = load ptr, ptr %t420
  store ptr %t421, ptr %l18, !tbaa !29
  br label %bb112
bb111:
  br label %bb122
bb112:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l18, !tbaa !29
  %t426 = getelementptr %"compiler/typed:Spawn", ptr %t424, i32 0, i32 0
  %t427 = load { i64, ptr }, ptr %t426, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %t423, { i64, ptr } %t427)
  br label %bb113
bb113:
  %t430 = load ptr, ptr %l0, !tbaa !29
  store ptr %t430, ptr %l200, !tbaa !29
  %t431 = load ptr, ptr %l200, !tbaa !29
  %t432 = getelementptr %"compiler/typed:LocalUses", ptr %t431, i32 0, i32 23
  %t433 = load i64, ptr %t432, !tbaa !24
  %t435 = add i64 %t433, 1
  %t437 = load ptr, ptr %l200, !tbaa !29
  %t438 = getelementptr %"compiler/typed:LocalUses", ptr %t437, i32 0, i32 23
  store i64 %t435, ptr %t438, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load ptr, ptr %l18, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Spawn", ptr %t440, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t445
  %t446 = getelementptr { i64, [1 x i64] }, ptr %t445, i32 0, i32 0
  store i64 5, ptr %t446
  %t447 = load { i64, [1 x i64] }, ptr %t445
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t439, ptr %t443, { i64, [1 x i64] } %t447)
  br label %bb114
bb114:
  %t451 = load ptr, ptr %l18, !tbaa !29
  %t453 = getelementptr %"compiler/typed:Spawn", ptr %t451, i32 0, i32 2
  %t454 = load { i64, ptr }, ptr %t453, !tbaa !27
  store { i64, ptr } %t454, ptr %l19, !tbaa !27
  store i64 0, ptr %l20, !tbaa !24
  %t456 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t456, 0
  store i64 %t458, ptr %l21, !tbaa !24
  br label %bb115
bb115:
  %t460 = load i64, ptr %l20, !tbaa !24
  %t461 = load i64, ptr %l21, !tbaa !24
  %t464 = icmp slt i64 %t460, %t461
  %t466 = xor i1 %t464, true
  br i1 %t466, label %bb116, label %bb117
bb116:
  br label %bb121
bb117:
  br label %bb118
bb118:
  %t468 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t468, ptr %l216, !tbaa !27
  %t469 = load i64, ptr %l20, !tbaa !24
  %t471 = getelementptr { i64, ptr }, ptr %l216, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr ptr, ptr %t472, i64 %t469
  %t474 = load ptr, ptr %t473, !tbaa !39
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/typed:TaskClause", ptr %t474, i32 0, i32 3
  %t480 = load ptr, ptr %t479, !tbaa !29
  store { i64, [1 x i64] } zeroinitializer, ptr %t481
  %t482 = getelementptr { i64, [1 x i64] }, ptr %t481, i32 0, i32 0
  store i64 5, ptr %t482
  %t483 = load { i64, [1 x i64] }, ptr %t481
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %t476, ptr %t480, { i64, [1 x i64] } %t483)
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t487 = load i64, ptr %l20, !tbaa !24
  %t489 = add i64 %t487, 1
  store i64 %t489, ptr %l20, !tbaa !24
  br label %bb115
bb121:
  %t491 = load ptr, ptr %l0, !tbaa !29
  store ptr %t491, ptr %l225, !tbaa !29
  %t492 = load ptr, ptr %l225, !tbaa !29
  %t493 = getelementptr %"compiler/typed:LocalUses", ptr %t492, i32 0, i32 23
  %t494 = load i64, ptr %t493, !tbaa !24
  %t496 = sub i64 %t494, 1
  %t498 = load ptr, ptr %l225, !tbaa !29
  %t499 = getelementptr %"compiler/typed:LocalUses", ptr %t498, i32 0, i32 23
  store i64 %t496, ptr %t499, !tbaa !24
  br label %bb133
bb122:
  %t500 = load ptr, ptr %l1, !tbaa !29
  store ptr %t500, ptr %l228, !tbaa !29
  store i1 false, ptr %l229, !tbaa !21
  %t501 = load ptr, ptr %l228, !tbaa !29
  %t502 = icmp ne ptr %t501, null
  br i1 %t502, label %bb123, label %bb124
bb123:
  %t504 = load ptr, ptr %l228, !tbaa !29
  %t505 = load i64, ptr %t504, !range !{i64 0, i64 17}
  %t507 = icmp eq i64 %t505, 5
  store i1 %t507, ptr %l229, !tbaa !21
  br label %bb124
bb124:
  %t508 = load i1, ptr %l229, !tbaa !21
  br i1 %t508, label %bb125, label %bb126
bb125:
  br label %bb131
bb126:
  %t509 = load ptr, ptr %l1, !tbaa !29
  store ptr %t509, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t510 = load ptr, ptr %l232, !tbaa !29
  %t511 = icmp ne ptr %t510, null
  br i1 %t511, label %bb127, label %bb128
bb127:
  %t513 = load ptr, ptr %l232, !tbaa !29
  %t514 = load i64, ptr %t513, !range !{i64 0, i64 17}
  %t516 = icmp eq i64 %t514, 7
  store i1 %t516, ptr %l233, !tbaa !21
  br label %bb128
bb128:
  %t517 = load i1, ptr %l233, !tbaa !21
  br i1 %t517, label %bb129, label %bb130
bb129:
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_9a2d2471d97215b1_125b5d47933e1fad)
  unreachable
bb133:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t21)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  br label %bb6
bb6:
  br label %bb37
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 4
  store i1 %t27, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Elem", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t35, ptr %t39)
  br label %bb13
bb13:
  br label %bb37
bb14:
  %t42 = load ptr, ptr %l1, !tbaa !29
  store ptr %t42, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t43 = load ptr, ptr %l24, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb15, label %bb16
bb15:
  %t46 = load ptr, ptr %l24, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 8}
  %t49 = icmp eq i64 %t47, 5
  store i1 %t49, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l1, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Payload", ptr %t58, i32 0, i32 0
  %t61 = load ptr, ptr %t60, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t57, ptr %t61)
  br label %bb20
bb20:
  br label %bb37
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t65 = load ptr, ptr %l33, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 8}
  %t71 = icmp eq i64 %t69, 6
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t83 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %t79, ptr %t80)
  store i64 %t83, ptr %l41
  br label %bb27
bb27:
  %t84 = load i64, ptr %l41, !tbaa !24
  store i64 %t84, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = icmp sge i64 %t85, 0
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:LocalUses", ptr %t89, i32 0, i32 2
  %t92 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t91, i64 %t92, i1 true)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_2dc1351d0e6e1c9_f66be85c5a6693dd)
  unreachable
bb37:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2ewrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca i64
  %l15 = alloca i1
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eplaceExprs(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erootOf(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i64, ptr %l8, !tbaa !24
  store i64 %t10, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempsWritten(ptr %v0, ptr %v1, ptr %t15, ptr %t16)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %ret
bb6:
  %t21 = xor i1 %a2, true
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb9:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb10
bb10:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/typed:LocalUses", ptr %t30, i32 0, i32 3
  %t33 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t32, i64 %t33, i1 true)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %ret
bb14:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:LocalUses", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t38, i64 %t39, i1 true)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l1, !tbaa !23
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 8}
  %t38 = icmp eq i64 %t36, 2
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l1, !tbaa !23
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l22, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l23, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l23, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l1, !tbaa !23
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t61 = load i32, ptr %l1, !tbaa !23
  store i32 %t61, ptr %l3, !tbaa !23
  br label %bb37
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l29, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l30, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l30, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 1
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l2, !tbaa !23
  br label %bb35
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t79 = load ptr, ptr %l35, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  %t82 = load ptr, ptr %l35, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 8}
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l36, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l36, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l2, !tbaa !23
  br label %bb35
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t94 = load ptr, ptr %l41, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l41, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 6
  store i1 %t100, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l42, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t104, i32 0, i32 1
  %t106 = load i32, ptr %t105
  store i32 %t106, ptr %l2, !tbaa !23
  br label %bb35
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t109 = load ptr, ptr %l47, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l47, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 8}
  %t115 = icmp eq i64 %t113, 7
  store i1 %t115, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t116 = load i1, ptr %l48, !tbaa !21
  br i1 %t116, label %bb33, label %bb34
bb33:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32 }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l2, !tbaa !23
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t123 = load i32, ptr %l2, !tbaa !23
  store i32 %t123, ptr %l3, !tbaa !23
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_e2587c8ec5c6f861_9513078f5b00021d)
  unreachable
bb37:
  %t125 = load i32, ptr %l3, !tbaa !23
  store i32 %t125, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [1 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l12 = alloca i1
  %l15 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Plan", ptr %t1, i32 0, i32 9
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  %t5 = load i32, ptr %l1, !tbaa !23
  %t7 = sext i32 %t5 to i64
  %t9 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !27
  %t11 = getelementptr i64, ptr %t10, i64 %t7
  %t12 = load i64, ptr %t11, !tbaa !34
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:Plan", ptr %t19, i32 0, i32 10
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  store { i64, ptr } %t22, ptr %l15, !tbaa !27
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = sext i32 %t23 to i64
  %t27 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t25
  %t30 = load i64, ptr %t29, !tbaa !34
  %t33 = icmp sge i64 %t18, %t30
  store i1 %t33, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Plan", ptr %t36, i32 0, i32 11
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t41, %t42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eSetAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t38, i64 %t45, { i64, [1 x i64] } %a3)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eNamed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l5 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Versions", ptr %a0, i32 0, i32 10
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  store i1 %t7, ptr %l5
  br label %bb1
bb1:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReaching(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %lp3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp3
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t4 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t8 = load ptr, ptr %lp3
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %t8)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %lp3
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2earm(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l22 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l89 = alloca i32
  %l92 = alloca i32
  %l93 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Arm", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l5, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Alt", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l5, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Alt", ptr %t34, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr ptr, ptr %t55, i64 %t52
  %t57 = load ptr, ptr %t56, !tbaa !39
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Bind", ptr %t57, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t59, ptr %t63)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Arm", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  br label %bb15
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Arm", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  br i1 %t87, label %bb16, label %bb17
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Arm", ptr %t90, i32 0, i32 4
  %t93 = load ptr, ptr %t92, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t89, ptr %t93)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %ret
bb19:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Versions", ptr %t96, i32 0, i32 16
  store ptr %t98, ptr %l58, !tbaa !29
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/typed:Arm", ptr %t99, i32 0, i32 3
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  br i1 %t104, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_43c6edd5f3ea6aa2_25eece1f43523776)
  unreachable
bb21:
  br label %bb22
bb22:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/typed:Arm", ptr %t106, i32 0, i32 3
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Block", ptr %t109, i32 0, i32 0
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t114, i32 %t113)
  br label %bb23
bb23:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Arm", ptr %t116, i32 0, i32 3
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = icmp eq ptr %t119, null
  br i1 %t121, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8a2b699ea2f67509_3bce0390ecfabbdd)
  unreachable
bb25:
  br label %bb26
bb26:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/typed:Arm", ptr %t123, i32 0, i32 3
  %t126 = load ptr, ptr %t125, !tbaa !29
  %t129 = getelementptr %"compiler/typed:Block", ptr %t126, i32 0, i32 1
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  store i64 %t134, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  %t136 = load i64, ptr %l11, !tbaa !24
  %t137 = load i64, ptr %l12, !tbaa !24
  %t140 = icmp slt i64 %t136, %t137
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t144 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t144, ptr %l79, !tbaa !27
  %t145 = load i64, ptr %l11, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr ptr, ptr %t148, i64 %t145
  %t150 = load ptr, ptr %t149, !tbaa !39
  %t152 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t152, ptr %t150)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l11, !tbaa !24
  br label %bb27
bb33:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Arm", ptr %t161, i32 0, i32 4
  %t164 = load ptr, ptr %t163, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t160, ptr %t164)
  br label %bb34
bb34:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/typed:Versions", ptr %t167, i32 0, i32 16
  %t171 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t169)
  %t172 = extractvalue { i32, i32 } %t171, 1
  %t173 = extractvalue { i32, i32 } %t171, 0
  store i32 %t173, ptr %l93
  %t174 = icmp ne i32 %t173, 0
  br i1 %t174, label %bb36, label %ok.175, !prof !99
ok.175:
  store i32 %t172, ptr %l92
  br label %bb35
bb35:
  %t176 = load i32, ptr %l92, !tbaa !23
  store i32 %t176, ptr %l89, !tbaa !23
  br label %bb43
bb36:
  %t177 = load i32, ptr %l93, !tbaa !23
  %t178 = icmp eq i32 %t177, 65536
  br i1 %t178, label %bb37, label %bb38
bb37:
  call void @__olang_bang_failed_plain(ptr @olang_loc_a872ad126d8d9744_e4960385d07a8740)
  unreachable
bb38:
  %t180 = load i32, ptr %l93, !tbaa !23
  %t181 = icmp eq i32 %t180, 65537
  br i1 %t181, label %bb39, label %bb40
bb39:
  call void @__olang_bang_failed_plain(ptr @olang_loc_f34031efedf98c99_ae8fa248572091b5)
  unreachable
bb40:
  %t183 = load i32, ptr %l93, !tbaa !23
  %t184 = icmp eq i32 %t183, 65538
  br i1 %t184, label %bb41, label %bb42
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1baf36c5dd0b9bdd_a2c9e1d98e30c571)
  unreachable
bb42:
  call void @__olang_bang_failed_plain(ptr @olang_loc_49ff4d0dc0b12b63_5e68d9fa98bc7cb7)
  unreachable
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l20 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Versions", ptr %t5, i32 0, i32 16
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Block", ptr %t8, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7, i32 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l20, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr ptr, ptr %t35, i64 %t32
  %t37 = load ptr, ptr %t36, !tbaa !39
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t39, ptr %t37)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb5
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Versions", ptr %t47, i32 0, i32 16
  %t51 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t49)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb13, label %ok.55, !prof !99
ok.55:
  store i32 %t52, ptr %l30
  br label %bb12
bb12:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l27, !tbaa !23
  br label %bb20
bb13:
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = icmp eq i32 %t57, 65536
  br i1 %t58, label %bb14, label %bb15
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1728180708920569_396f77e53f37dbed)
  unreachable
bb15:
  %t60 = load i32, ptr %l31, !tbaa !23
  %t61 = icmp eq i32 %t60, 65537
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_bang_failed_plain(ptr @olang_loc_64712ec69db6f686_5286ea6d6f8bc3a)
  unreachable
bb17:
  %t63 = load i32, ptr %l31, !tbaa !23
  %t64 = icmp eq i32 %t63, 65538
  br i1 %t64, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_3937948e4172da86_b4226ee484a284a)
  unreachable
bb19:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e2e1378986f13fd0_6a804f95244a4cf4)
  unreachable
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca i1
  %l135 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l137 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i1
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l181 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l190 = alloca ptr
  %l191 = alloca i1
  %l204 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l215 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i1
  %l229 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l232 = alloca i64
  %l237 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l242 = alloca i64
  %l247 = alloca i64
  %l250 = alloca i64
  %l268 = alloca ptr
  %l269 = alloca i64
  %l270 = alloca ptr
  %l273 = alloca i64
  %l276 = alloca i64
  %l277 = alloca i64
  %l280 = alloca ptr
  %l282 = alloca i64
  %l283 = alloca i64
  %l284 = alloca ptr
  %l286 = alloca i64
  %l288 = alloca i64
  %l292 = alloca i64
  %l296 = alloca i64
  %l299 = alloca i64
  %l317 = alloca ptr
  %l321 = alloca i64
  %l322 = alloca ptr
  %l323 = alloca ptr
  %l327 = alloca i64
  %l328 = alloca i64
  %l329 = alloca i64
  %l336 = alloca ptr
  %l337 = alloca i1
  %l342 = alloca ptr
  %l343 = alloca i1
  %l355 = alloca { i64, ptr }
  %l364 = alloca ptr
  %l365 = alloca i1
  %l373 = alloca ptr
  %l374 = alloca i1
  %l377 = alloca ptr
  %l378 = alloca i1
  %l391 = alloca { i64, ptr }
  %l394 = alloca ptr
  %l395 = alloca i1
  %l405 = alloca ptr
  %l406 = alloca i1
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t6 = load ptr, ptr %l53, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l53, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l54, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l54, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t15 = load ptr, ptr %l57, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l57, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 18}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l58, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l58, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb237
bb13:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t24 = load ptr, ptr %l61, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb14, label %bb15
bb14:
  %t27 = load ptr, ptr %l61, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 2
  store i1 %t30, ptr %l62, !tbaa !21
  br label %bb15
bb15:
  %t31 = load i1, ptr %l62, !tbaa !21
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l2, !tbaa !29
  br label %bb26
bb17:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t39 = load ptr, ptr %l67, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t42 = load ptr, ptr %l67, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 3
  store i1 %t45, ptr %l68, !tbaa !21
  br label %bb19
bb19:
  %t46 = load i1, ptr %l68, !tbaa !21
  br i1 %t46, label %bb20, label %bb21
bb20:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l2, !tbaa !29
  br label %bb26
bb21:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t54 = load ptr, ptr %l73, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t57 = load ptr, ptr %l73, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l74, !tbaa !21
  br label %bb23
bb23:
  %t61 = load i1, ptr %l74, !tbaa !21
  br i1 %t61, label %bb24, label %bb25
bb24:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l2, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  br label %bb27
bb27:
  br label %bb237
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  store ptr %t72, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t73 = load ptr, ptr %l81, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb29, label %bb30
bb29:
  %t76 = load ptr, ptr %l81, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 18}
  %t79 = icmp eq i64 %t77, 5
  store i1 %t79, ptr %l82, !tbaa !21
  br label %bb30
bb30:
  %t80 = load i1, ptr %l82, !tbaa !21
  br i1 %t80, label %bb31, label %bb32
bb31:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l3, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Promote", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t87, ptr %t91)
  br label %bb34
bb34:
  br label %bb237
bb35:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t96 = load ptr, ptr %l91, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb36, label %bb37
bb36:
  %t99 = load ptr, ptr %l91, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l92, !tbaa !21
  br label %bb37
bb37:
  %t103 = load i1, ptr %l92, !tbaa !21
  br i1 %t103, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb54
bb40:
  %t110 = load ptr, ptr %l4, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Call", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l5, !tbaa !29
  %t115 = load ptr, ptr %l5, !tbaa !29
  store ptr %t115, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t116 = load ptr, ptr %l99, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l99, !tbaa !29
  %t120 = load i64, ptr %t119, !range !{i64 0, i64 5}
  %t122 = icmp eq i64 %t120, 2
  store i1 %t122, ptr %l100, !tbaa !21
  br label %bb42
bb42:
  %t123 = load i1, ptr %l100, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l5, !tbaa !29
  %t126 = getelementptr { i64, [3 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { ptr }, ptr %t126, i32 0, i32 0
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l6, !tbaa !29
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t130, ptr %t131)
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_77315c1e1ec03e98_be22ee0dd90c53a4)
  unreachable
bb52:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Call", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t135, { i64, ptr } %t139)
  br label %bb53
bb53:
  br label %bb237
bb54:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t143 = load ptr, ptr %l111, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb55, label %bb56
bb55:
  %t146 = load ptr, ptr %l111, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 7
  store i1 %t149, ptr %l112, !tbaa !21
  br label %bb56
bb56:
  %t150 = load i1, ptr %l112, !tbaa !21
  br i1 %t150, label %bb57, label %bb58
bb57:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l7, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Make", ptr %t158, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t157, { i64, ptr } %t161)
  br label %bb60
bb60:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Make", ptr %t165, i32 0, i32 3
  %t168 = load ptr, ptr %t167, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t164, ptr %t168)
  br label %bb61
bb61:
  br label %bb237
bb62:
  %t171 = load ptr, ptr %l1, !tbaa !29
  store ptr %t171, ptr %l123, !tbaa !29
  store i1 false, ptr %l124, !tbaa !21
  %t172 = load ptr, ptr %l123, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb63, label %bb64
bb63:
  %t175 = load ptr, ptr %l123, !tbaa !29
  %t176 = load i64, ptr %t175, !range !{i64 0, i64 18}
  %t178 = icmp eq i64 %t176, 8
  store i1 %t178, ptr %l124, !tbaa !21
  br label %bb64
bb64:
  %t179 = load i1, ptr %l124, !tbaa !21
  br i1 %t179, label %bb65, label %bb66
bb65:
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t182, i32 0, i32 2
  %t184 = load ptr, ptr %t183
  store ptr %t184, ptr %l8, !tbaa !29
  br label %bb67
bb66:
  br label %bb75
bb67:
  store %olang.scope zeroinitializer, ptr %s9
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Collect", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t186, ptr %t190)
  br label %bb68
bb68:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Collect", ptr %t194, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t200 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v0, ptr %s9, ptr %t193, ptr %t197, ptr null)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %l135
  br label %bb69
bb69:
  %t201 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l135
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %l9
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %t202)
  store i1 %t204, ptr %l137
  br label %bb70
bb70:
  %t205 = load i1, ptr %l137, !tbaa !21
  br i1 %t205, label %bb71, label %bb72
bb71:
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s9, ptr %t206, ptr %l9)
  br label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s9)
  br label %bb237
bb75:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t210 = load ptr, ptr %l140, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb76, label %bb77
bb76:
  %t213 = load ptr, ptr %l140, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 18}
  %t216 = icmp eq i64 %t214, 9
  store i1 %t216, ptr %l141, !tbaa !21
  br label %bb77
bb77:
  %t217 = load i1, ptr %l141, !tbaa !21
  br i1 %t217, label %bb78, label %bb79
bb78:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [5 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t220, i32 0, i32 4
  %t222 = load { i64, ptr }, ptr %t221
  store { i64, ptr } %t222, ptr %l10, !tbaa !27
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %t224, { i64, ptr } %t225)
  br label %bb81
bb81:
  br label %bb237
bb82:
  %t228 = load ptr, ptr %l1, !tbaa !29
  store ptr %t228, ptr %l148, !tbaa !29
  store i1 false, ptr %l149, !tbaa !21
  %t229 = load ptr, ptr %l148, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb83, label %bb84
bb83:
  %t232 = load ptr, ptr %l148, !tbaa !29
  %t233 = load i64, ptr %t232, !range !{i64 0, i64 18}
  %t235 = icmp eq i64 %t233, 10
  store i1 %t235, ptr %l149, !tbaa !21
  br label %bb84
bb84:
  %t236 = load i1, ptr %l149, !tbaa !21
  br i1 %t236, label %bb85, label %bb86
bb85:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t239, i32 0, i32 2
  %t241 = load ptr, ptr %t240
  store ptr %t241, ptr %l11, !tbaa !29
  br label %bb87
bb86:
  br label %bb91
bb87:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load ptr, ptr %l11, !tbaa !29
  %t246 = getelementptr %"compiler/typed:Slice", ptr %t244, i32 0, i32 0
  %t247 = load ptr, ptr %t246, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %t243, ptr %t247)
  br label %bb88
bb88:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l11, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Slice", ptr %t251, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t250, ptr %t254)
  br label %bb89
bb89:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load ptr, ptr %l11, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Slice", ptr %t259, i32 0, i32 2
  %t262 = load ptr, ptr %t261, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t258, ptr %t262)
  br label %bb90
bb90:
  br label %bb237
bb91:
  %t266 = load ptr, ptr %l1, !tbaa !29
  store ptr %t266, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t267 = load ptr, ptr %l165, !tbaa !29
  %t268 = icmp ne ptr %t267, null
  br i1 %t268, label %bb92, label %bb93
bb92:
  %t270 = load ptr, ptr %l165, !tbaa !29
  %t271 = load i64, ptr %t270, !range !{i64 0, i64 18}
  %t273 = icmp eq i64 %t271, 11
  store i1 %t273, ptr %l166, !tbaa !21
  br label %bb93
bb93:
  %t274 = load i1, ptr %l166, !tbaa !21
  br i1 %t274, label %bb94, label %bb95
bb94:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr { i64, [5 x i64] }, ptr %t275, i32 0, i32 1
  %t278 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t277, i32 0, i32 2
  %t279 = load ptr, ptr %t278
  store ptr %t279, ptr %l12, !tbaa !29
  br label %bb96
bb95:
  br label %bb104
bb96:
  store %olang.scope zeroinitializer, ptr %s13
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l12, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Cond", ptr %t282, i32 0, i32 0
  %t285 = load ptr, ptr %t284, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t285)
  br label %bb97
bb97:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s13, ptr %t289)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t291, ptr %l176
  br label %bb98
bb98:
  %t292 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l176
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t292, ptr %l13
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t294 = load ptr, ptr %l12, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Cond", ptr %t294, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t293, ptr %t297)
  br label %bb99
bb99:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s13, ptr %t300)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l181
  br label %bb100
bb100:
  %t303 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l181
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %l14
  %t304 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %s13, ptr %t304, ptr %l13)
  br label %bb101
bb101:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l12, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Cond", ptr %t308, i32 0, i32 2
  %t311 = load ptr, ptr %t310, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  br label %bb102
bb102:
  %t315 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %s13, ptr %t315, ptr %l14)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s13)
  br label %bb237
bb104:
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t319 = load ptr, ptr %l190, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb105, label %bb106
bb105:
  %t322 = load ptr, ptr %l190, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 18}
  %t325 = icmp eq i64 %t323, 12
  store i1 %t325, ptr %l191, !tbaa !21
  br label %bb106
bb106:
  %t326 = load i1, ptr %l191, !tbaa !21
  br i1 %t326, label %bb107, label %bb108
bb107:
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l15, !tbaa !29
  br label %bb109
bb108:
  br label %bb118
bb109:
  %t333 = load ptr, ptr %l15, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Seq", ptr %t333, i32 0, i32 0
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  store { i64, ptr } %t336, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t338 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  store i64 %t340, ptr %l18, !tbaa !24
  br label %bb110
bb110:
  %t342 = load i64, ptr %l17, !tbaa !24
  %t343 = load i64, ptr %l18, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb111, label %bb112
bb111:
  br label %bb116
bb112:
  br label %bb113
bb113:
  %t350 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t350, ptr %l204, !tbaa !27
  %t351 = load i64, ptr %l17, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr ptr, ptr %t354, i64 %t351
  %t356 = load ptr, ptr %t355, !tbaa !39
  %t358 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %t358, ptr %t356)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t362 = load i64, ptr %l17, !tbaa !24
  %t364 = add i64 %t362, 1
  store i64 %t364, ptr %l17, !tbaa !24
  br label %bb110
bb116:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l15, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Seq", ptr %t367, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t366, ptr %t370)
  br label %bb117
bb117:
  br label %bb237
bb118:
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t374 = load ptr, ptr %l214, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb119, label %bb120
bb119:
  %t377 = load ptr, ptr %l214, !tbaa !29
  %t378 = load i64, ptr %t377, !range !{i64 0, i64 18}
  %t380 = icmp eq i64 %t378, 13
  store i1 %t380, ptr %l215, !tbaa !21
  br label %bb120
bb120:
  %t381 = load i1, ptr %l215, !tbaa !21
  br i1 %t381, label %bb121, label %bb122
bb121:
  %t382 = load ptr, ptr %l1, !tbaa !29
  %t384 = getelementptr { i64, [5 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t384, i32 0, i32 2
  %t386 = load ptr, ptr %t385
  store ptr %t386, ptr %l20, !tbaa !29
  br label %bb123
bb122:
  br label %bb125
bb123:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %t388, ptr %t389)
  br label %bb124
bb124:
  br label %bb237
bb125:
  %t392 = load ptr, ptr %l1, !tbaa !29
  store ptr %t392, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t393 = load ptr, ptr %l222, !tbaa !29
  %t394 = icmp ne ptr %t393, null
  br i1 %t394, label %bb126, label %bb127
bb126:
  %t396 = load ptr, ptr %l222, !tbaa !29
  %t397 = load i64, ptr %t396, !range !{i64 0, i64 18}
  %t399 = icmp eq i64 %t397, 14
  store i1 %t399, ptr %l223, !tbaa !21
  br label %bb127
bb127:
  %t400 = load i1, ptr %l223, !tbaa !21
  br i1 %t400, label %bb128, label %bb129
bb128:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr { i64, [5 x i64] }, ptr %t401, i32 0, i32 1
  %t404 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t403, i32 0, i32 2
  %t405 = load ptr, ptr %t404
  store ptr %t405, ptr %l21, !tbaa !29
  br label %bb130
bb129:
  br label %bb178
bb130:
  store %olang.scope zeroinitializer, ptr %s19
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s19, ptr %t407)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t409, ptr %l229
  br label %bb131
bb131:
  %t410 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l229
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t410, ptr %l22
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/typed:Versions", ptr %t411, i32 0, i32 15
  %t415 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t413)
  store i64 %t415, ptr %l232
  br label %bb132
bb132:
  %t416 = load i64, ptr %l232, !tbaa !24
  store i64 %t416, ptr %l23, !tbaa !24
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load ptr, ptr %l21, !tbaa !29
  %t420 = getelementptr %"compiler/typed:Try", ptr %t418, i32 0, i32 0
  %t421 = load ptr, ptr %t420, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t417, ptr %t421)
  br label %bb133
bb133:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %s19, ptr %t424)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t426, ptr %l237
  br label %bb134
bb134:
  %t427 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l237
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t427, ptr %l24
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/typed:Versions", ptr %t428, i32 0, i32 20
  %t431 = load i1, ptr %t430, !tbaa !21
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb135, label %bb136
bb135:
  store i64 0, ptr %l25, !tbaa !24
  %t436 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s19, ptr %l22)
  store i64 %t436, ptr %l242
  br label %bb137
bb136:
  br label %bb176
bb137:
  %t437 = load i64, ptr %l242, !tbaa !24
  %t438 = sub i64 %t437, 1
  store i64 %t438, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t440 = load i64, ptr %l26, !tbaa !24
  %t441 = load i64, ptr %l25, !tbaa !24
  %t444 = icmp sgt i64 %t440, %t441
  br i1 %t444, label %bb138, label %bb139
bb138:
  %t446 = load i64, ptr %l27, !tbaa !24
  %t448 = icmp sgt i64 %t446, 0
  br i1 %t448, label %bb140, label %bb141
bb139:
  store i64 0, ptr %l247, !tbaa !24
  br label %bb143
bb140:
  %t450 = load i64, ptr %l26, !tbaa !24
  %t451 = load i64, ptr %l25, !tbaa !24
  %t454 = sub i64 %t450, %t451
  %t455 = load i64, ptr %l27, !tbaa !24
  %t458 = add i64 %t454, %t455
  %t460 = sub i64 %t458, 1
  %t461 = load i64, ptr %l27, !tbaa !24
  %t464 = sdiv i64 %t460, %t461
  store i64 %t464, ptr %l250, !tbaa !24
  br label %bb142
bb141:
  store i64 0, ptr %l250, !tbaa !24
  br label %bb142
bb142:
  %t466 = load i64, ptr %l250, !tbaa !24
  store i64 %t466, ptr %l247, !tbaa !24
  br label %bb143
bb143:
  %t467 = load i64, ptr %l247, !tbaa !24
  store i64 %t467, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb144
bb144:
  %t468 = load i64, ptr %l29, !tbaa !24
  %t469 = load i64, ptr %l28, !tbaa !24
  %t472 = icmp slt i64 %t468, %t469
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb145, label %bb146
bb145:
  br label %bb153
bb146:
  br label %bb147
bb147:
  %t476 = load i64, ptr %l25, !tbaa !24
  %t477 = load i64, ptr %l29, !tbaa !24
  %t478 = load i64, ptr %l27, !tbaa !24
  %t481 = mul i64 %t477, %t478
  %t484 = add i64 %t476, %t481
  store i64 %t484, ptr %l30, !tbaa !24
  store ptr %l24, ptr %l268, !tbaa !29
  %t486 = load i64, ptr %l30, !tbaa !24
  store i64 %t486, ptr %l269, !tbaa !24
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l270, !tbaa !29
  %t488 = load i64, ptr %l30, !tbaa !24
  %t491 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s19, ptr %l24, i64 %t488)
  store i64 %t491, ptr %l273
  br label %bb148
bb148:
  %t492 = load i64, ptr %l30, !tbaa !24
  %t495 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s19, ptr %l22, i64 %t492)
  store i64 %t495, ptr %l276
  br label %bb149
bb149:
  %t496 = load ptr, ptr %l270, !tbaa !29
  %t497 = load i64, ptr %l273, !tbaa !24
  %t498 = load i64, ptr %l276, !tbaa !24
  %t499 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t496, i64 %t497, i64 %t498)
  store i64 %t499, ptr %l277
  br label %bb150
bb150:
  %t500 = load ptr, ptr %l268, !tbaa !29
  %t501 = load i64, ptr %l269, !tbaa !24
  %t502 = load i64, ptr %l277, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s19, ptr %t500, i64 %t501, i64 %t502)
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t503 = load i64, ptr %l29, !tbaa !24
  %t505 = add i64 %t503, 1
  store i64 %t505, ptr %l29, !tbaa !24
  br label %bb144
bb153:
  store ptr %l24, ptr %l280, !tbaa !29
  %t508 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s19, ptr %l22)
  store i64 %t508, ptr %l282
  br label %bb154
bb154:
  %t509 = load i64, ptr %l282, !tbaa !24
  %t510 = sub i64 %t509, 1
  store i64 %t510, ptr %l283, !tbaa !24
  store ptr %l22, ptr %l284, !tbaa !29
  %t512 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s19, ptr %l22)
  store i64 %t512, ptr %l286
  br label %bb155
bb155:
  %t513 = load i64, ptr %l286, !tbaa !24
  %t514 = sub i64 %t513, 1
  %t515 = load ptr, ptr %l284, !tbaa !29
  %t517 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s19, ptr %t515, i64 %t514)
  store i64 %t517, ptr %l288
  br label %bb156
bb156:
  %t518 = load ptr, ptr %l280, !tbaa !29
  %t519 = load i64, ptr %l283, !tbaa !24
  %t520 = load i64, ptr %l288, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s19, ptr %t518, i64 %t519, i64 %t520)
  br label %bb157
bb157:
  %t521 = load i64, ptr %l23, !tbaa !24
  store i64 %t521, ptr %l31, !tbaa !24
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t525 = getelementptr %"compiler/typed:Versions", ptr %t523, i32 0, i32 15
  %t527 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t525)
  store i64 %t527, ptr %l292
  br label %bb158
bb158:
  %t528 = load i64, ptr %l292, !tbaa !24
  store i64 %t528, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t529 = load i64, ptr %l32, !tbaa !24
  %t530 = load i64, ptr %l31, !tbaa !24
  %t533 = icmp sgt i64 %t529, %t530
  br i1 %t533, label %bb159, label %bb160
bb159:
  %t535 = load i64, ptr %l33, !tbaa !24
  %t537 = icmp sgt i64 %t535, 0
  br i1 %t537, label %bb161, label %bb162
bb160:
  store i64 0, ptr %l296, !tbaa !24
  br label %bb164
bb161:
  %t539 = load i64, ptr %l32, !tbaa !24
  %t540 = load i64, ptr %l31, !tbaa !24
  %t543 = sub i64 %t539, %t540
  %t544 = load i64, ptr %l33, !tbaa !24
  %t547 = add i64 %t543, %t544
  %t549 = sub i64 %t547, 1
  %t550 = load i64, ptr %l33, !tbaa !24
  %t553 = sdiv i64 %t549, %t550
  store i64 %t553, ptr %l299, !tbaa !24
  br label %bb163
bb162:
  store i64 0, ptr %l299, !tbaa !24
  br label %bb163
bb163:
  %t555 = load i64, ptr %l299, !tbaa !24
  store i64 %t555, ptr %l296, !tbaa !24
  br label %bb164
bb164:
  %t556 = load i64, ptr %l296, !tbaa !24
  store i64 %t556, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb165
bb165:
  %t557 = load i64, ptr %l35, !tbaa !24
  %t558 = load i64, ptr %l34, !tbaa !24
  %t561 = icmp slt i64 %t557, %t558
  %t563 = xor i1 %t561, true
  br i1 %t563, label %bb166, label %bb167
bb166:
  br label %bb175
bb167:
  br label %bb168
bb168:
  %t565 = load i64, ptr %l31, !tbaa !24
  %t566 = load i64, ptr %l35, !tbaa !24
  %t567 = load i64, ptr %l33, !tbaa !24
  %t570 = mul i64 %t566, %t567
  %t573 = add i64 %t565, %t570
  store i64 %t573, ptr %l36, !tbaa !24
  store ptr %l24, ptr %l317, !tbaa !29
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t577 = getelementptr %"compiler/typed:Versions", ptr %t575, i32 0, i32 15
  %t578 = load i64, ptr %l36, !tbaa !24
  %t581 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t577, i64 %t578)
  store i64 %t581, ptr %l321
  br label %bb169
bb169:
  %t582 = load ptr, ptr %l0, !tbaa !29
  store ptr %t582, ptr %l322, !tbaa !29
  store ptr %l24, ptr %l323, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/typed:Versions", ptr %t583, i32 0, i32 15
  %t586 = load i64, ptr %l36, !tbaa !24
  %t589 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t585, i64 %t586)
  store i64 %t589, ptr %l327
  br label %bb170
bb170:
  %t590 = load ptr, ptr %l323, !tbaa !29
  %t591 = load i64, ptr %l327, !tbaa !24
  %t592 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s19, ptr %t590, i64 %t591)
  store i64 %t592, ptr %l328
  br label %bb171
bb171:
  %t593 = load ptr, ptr %l322, !tbaa !29
  %t594 = load i64, ptr %l328, !tbaa !24
  %t595 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %t593, i64 %t594, i64 -1)
  store i64 %t595, ptr %l329
  br label %bb172
bb172:
  %t596 = load ptr, ptr %l317, !tbaa !29
  %t597 = load i64, ptr %l321, !tbaa !24
  %t598 = load i64, ptr %l329, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s19, ptr %t596, i64 %t597, i64 %t598)
  br label %bb173
bb173:
  br label %bb174
bb174:
  %t599 = load i64, ptr %l35, !tbaa !24
  %t601 = add i64 %t599, 1
  store i64 %t601, ptr %l35, !tbaa !24
  br label %bb165
bb175:
  br label %bb176
bb176:
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load ptr, ptr %l21, !tbaa !29
  %t606 = getelementptr %"compiler/typed:Try", ptr %t604, i32 0, i32 1
  %t607 = load { i64, ptr }, ptr %t606, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %s19, ptr %t603, { i64, ptr } %t607, ptr %l24, i1 false)
  br label %bb177
bb177:
  call void @__olang_scope_close(ptr %s19)
  br label %bb237
bb178:
  %t611 = load ptr, ptr %l1, !tbaa !29
  store ptr %t611, ptr %l336, !tbaa !29
  store i1 false, ptr %l337, !tbaa !21
  %t612 = load ptr, ptr %l336, !tbaa !29
  %t613 = icmp ne ptr %t612, null
  br i1 %t613, label %bb179, label %bb180
bb179:
  %t615 = load ptr, ptr %l336, !tbaa !29
  %t616 = load i64, ptr %t615, !range !{i64 0, i64 18}
  %t618 = icmp eq i64 %t616, 15
  store i1 %t618, ptr %l337, !tbaa !21
  br label %bb180
bb180:
  %t619 = load i1, ptr %l337, !tbaa !21
  br i1 %t619, label %bb181, label %bb182
bb181:
  %t620 = load ptr, ptr %l1, !tbaa !29
  %t622 = getelementptr { i64, [5 x i64] }, ptr %t620, i32 0, i32 1
  %t623 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t622, i32 0, i32 2
  %t624 = load ptr, ptr %t623
  store ptr %t624, ptr %l37, !tbaa !29
  br label %bb183
bb182:
  br label %bb211
bb183:
  %t626 = load ptr, ptr %l37, !tbaa !29
  store ptr %t626, ptr %l342, !tbaa !29
  store i1 false, ptr %l343, !tbaa !21
  %t627 = load ptr, ptr %l342, !tbaa !29
  %t628 = icmp ne ptr %t627, null
  br i1 %t628, label %bb184, label %bb185
bb184:
  %t630 = load ptr, ptr %l342, !tbaa !29
  %t631 = load i64, ptr %t630, !range !{i64 0, i64 3}
  %t633 = icmp eq i64 %t631, 1
  store i1 %t633, ptr %l343, !tbaa !21
  br label %bb185
bb185:
  %t634 = load i1, ptr %l343, !tbaa !21
  br i1 %t634, label %bb186, label %bb187
bb186:
  %t635 = load ptr, ptr %l37, !tbaa !29
  %t637 = getelementptr { i64, [4 x i64] }, ptr %t635, i32 0, i32 1
  %t638 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t637, i32 0, i32 1
  %t639 = load { i64, ptr }, ptr %t638
  store { i64, ptr } %t639, ptr %l38, !tbaa !27
  br label %bb188
bb187:
  br label %bb196
bb188:
  %t641 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t641, ptr %l39, !tbaa !27
  store i64 0, ptr %l40, !tbaa !24
  %t643 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t643, 0
  store i64 %t645, ptr %l41, !tbaa !24
  br label %bb189
bb189:
  %t647 = load i64, ptr %l40, !tbaa !24
  %t648 = load i64, ptr %l41, !tbaa !24
  %t651 = icmp slt i64 %t647, %t648
  %t653 = xor i1 %t651, true
  br i1 %t653, label %bb190, label %bb191
bb190:
  br label %bb195
bb191:
  br label %bb192
bb192:
  %t655 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t655, ptr %l355, !tbaa !27
  %t656 = load i64, ptr %l40, !tbaa !24
  %t658 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !27
  %t660 = getelementptr ptr, ptr %t659, i64 %t656
  %t661 = load ptr, ptr %t660, !tbaa !39
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/typed:Capture", ptr %t661, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t663, ptr %t667)
  br label %bb193
bb193:
  br label %bb194
bb194:
  %t671 = load i64, ptr %l40, !tbaa !24
  %t673 = add i64 %t671, 1
  store i64 %t673, ptr %l40, !tbaa !24
  br label %bb189
bb195:
  br label %bb210
bb196:
  %t675 = load ptr, ptr %l37, !tbaa !29
  store ptr %t675, ptr %l364, !tbaa !29
  store i1 false, ptr %l365, !tbaa !21
  %t676 = load ptr, ptr %l364, !tbaa !29
  %t677 = icmp ne ptr %t676, null
  br i1 %t677, label %bb197, label %bb198
bb197:
  %t679 = load ptr, ptr %l364, !tbaa !29
  %t680 = load i64, ptr %t679, !range !{i64 0, i64 3}
  %t682 = icmp eq i64 %t680, 2
  store i1 %t682, ptr %l365, !tbaa !21
  br label %bb198
bb198:
  %t683 = load i1, ptr %l365, !tbaa !21
  br i1 %t683, label %bb199, label %bb200
bb199:
  %t684 = load ptr, ptr %l37, !tbaa !29
  %t686 = getelementptr { i64, [4 x i64] }, ptr %t684, i32 0, i32 1
  %t687 = getelementptr { i32, ptr, i32 }, ptr %t686, i32 0, i32 1
  %t688 = load ptr, ptr %t687
  store ptr %t688, ptr %l43, !tbaa !29
  br label %bb201
bb200:
  br label %bb203
bb201:
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l43, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t690, ptr %t691)
  br label %bb202
bb202:
  br label %bb210
bb203:
  %t695 = load ptr, ptr %l37, !tbaa !29
  store ptr %t695, ptr %l373, !tbaa !29
  store i1 false, ptr %l374, !tbaa !21
  %t696 = load ptr, ptr %l373, !tbaa !29
  %t697 = icmp ne ptr %t696, null
  br i1 %t697, label %bb204, label %bb205
bb204:
  %t699 = load ptr, ptr %l373, !tbaa !29
  %t700 = load i64, ptr %t699, !range !{i64 0, i64 3}
  %t702 = icmp eq i64 %t700, 0
  store i1 %t702, ptr %l374, !tbaa !21
  br label %bb205
bb205:
  %t703 = load i1, ptr %l374, !tbaa !21
  br i1 %t703, label %bb206, label %bb207
bb206:
  br label %bb208
bb207:
  br label %bb209
bb208:
  br label %bb210
bb209:
  call void @__olang_check_failed(ptr @olang_loc_ec88ab62730d3569_72c455660b6c295)
  unreachable
bb210:
  br label %bb237
bb211:
  %t704 = load ptr, ptr %l1, !tbaa !29
  store ptr %t704, ptr %l377, !tbaa !29
  store i1 false, ptr %l378, !tbaa !21
  %t705 = load ptr, ptr %l377, !tbaa !29
  %t706 = icmp ne ptr %t705, null
  br i1 %t706, label %bb212, label %bb213
bb212:
  %t708 = load ptr, ptr %l377, !tbaa !29
  %t709 = load i64, ptr %t708, !range !{i64 0, i64 18}
  %t711 = icmp eq i64 %t709, 16
  store i1 %t711, ptr %l378, !tbaa !21
  br label %bb213
bb213:
  %t712 = load i1, ptr %l378, !tbaa !21
  br i1 %t712, label %bb214, label %bb215
bb214:
  %t713 = load ptr, ptr %l1, !tbaa !29
  %t715 = getelementptr { i64, [5 x i64] }, ptr %t713, i32 0, i32 1
  %t716 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t715, i32 0, i32 2
  %t717 = load ptr, ptr %t716
  store ptr %t717, ptr %l44, !tbaa !29
  br label %bb216
bb215:
  br label %bb229
bb216:
  %t719 = load ptr, ptr %l44, !tbaa !29
  %t721 = getelementptr %"compiler/typed:Text", ptr %t719, i32 0, i32 0
  %t722 = load { i64, ptr }, ptr %t721, !tbaa !27
  store { i64, ptr } %t722, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  %t724 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t726 = extractvalue { i64, ptr } %t724, 0
  store i64 %t726, ptr %l47, !tbaa !24
  br label %bb217
bb217:
  %t728 = load i64, ptr %l46, !tbaa !24
  %t729 = load i64, ptr %l47, !tbaa !24
  %t732 = icmp slt i64 %t728, %t729
  %t734 = xor i1 %t732, true
  br i1 %t734, label %bb218, label %bb219
bb218:
  br label %bb228
bb219:
  br label %bb220
bb220:
  %t736 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t736, ptr %l391, !tbaa !27
  %t737 = load i64, ptr %l46, !tbaa !24
  %t739 = getelementptr { i64, ptr }, ptr %l391, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !27
  %t741 = getelementptr ptr, ptr %t740, i64 %t737
  %t742 = load ptr, ptr %t741, !tbaa !39
  store ptr %t742, ptr %l48, !tbaa !29
  %t744 = load ptr, ptr %l48, !tbaa !29
  store ptr %t744, ptr %l394, !tbaa !29
  store i1 false, ptr %l395, !tbaa !21
  %t745 = load ptr, ptr %l394, !tbaa !29
  %t746 = icmp ne ptr %t745, null
  br i1 %t746, label %bb221, label %bb222
bb221:
  %t748 = load ptr, ptr %l394, !tbaa !29
  %t749 = load i64, ptr %t748, !range !{i64 0, i64 2}
  %t751 = icmp eq i64 %t749, 1
  store i1 %t751, ptr %l395, !tbaa !21
  br label %bb222
bb222:
  %t752 = load i1, ptr %l395, !tbaa !21
  br i1 %t752, label %bb223, label %bb224
bb223:
  %t753 = load ptr, ptr %l48, !tbaa !29
  %t755 = getelementptr { i64, [2 x i64] }, ptr %t753, i32 0, i32 1
  %t756 = getelementptr { ptr }, ptr %t755, i32 0, i32 0
  %t757 = load ptr, ptr %t756
  %t759 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t759, ptr %t757)
  br label %bb225
bb224:
  br label %bb226
bb225:
  br label %bb226
bb226:
  br label %bb227
bb227:
  %t764 = load i64, ptr %l46, !tbaa !24
  %t766 = add i64 %t764, 1
  store i64 %t766, ptr %l46, !tbaa !24
  br label %bb217
bb228:
  br label %bb237
bb229:
  %t768 = load ptr, ptr %l1, !tbaa !29
  store ptr %t768, ptr %l405, !tbaa !29
  store i1 false, ptr %l406, !tbaa !21
  %t769 = load ptr, ptr %l405, !tbaa !29
  %t770 = icmp ne ptr %t769, null
  br i1 %t770, label %bb230, label %bb231
bb230:
  %t772 = load ptr, ptr %l405, !tbaa !29
  %t773 = load i64, ptr %t772, !range !{i64 0, i64 18}
  %t775 = icmp eq i64 %t773, 17
  store i1 %t775, ptr %l406, !tbaa !21
  br label %bb231
bb231:
  %t776 = load i1, ptr %l406, !tbaa !21
  br i1 %t776, label %bb232, label %bb233
bb232:
  %t777 = load ptr, ptr %l1, !tbaa !29
  %t779 = getelementptr { i64, [5 x i64] }, ptr %t777, i32 0, i32 1
  %t780 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t779, i32 0, i32 2
  %t781 = load ptr, ptr %t780
  store ptr %t781, ptr %l50, !tbaa !29
  br label %bb234
bb233:
  br label %bb236
bb234:
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load ptr, ptr %l50, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexpr(ptr %v0, ptr %v1, ptr %t783, ptr %t784)
  br label %bb235
bb235:
  br label %bb237
bb236:
  call void @__olang_check_failed(ptr @olang_loc_a5a46b672ecbc32_209a020a110ad15e)
  unreachable
bb237:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esettle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l89 = alloca i64
  %l92 = alloca i32
  %l95 = alloca ptr
  %l98 = alloca i1
  %l103 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i64
  %l131 = alloca i64
  %l135 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i64
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca i32
  %l153 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Versions", ptr %t1, i32 0, i32 3
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l20
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l20)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l22
  br label %bb1
bb1:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Versions", ptr %t8, i32 0, i32 4
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l24
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l24)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l26
  br label %bb2
bb2:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Versions", ptr %t15, i32 0, i32 5
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l28
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %s0, ptr %l28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l30
  br label %bb3
bb3:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l3
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Versions", ptr %t22, i32 0, i32 6
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l32
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %l32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l34
  br label %bb4
bb4:
  %t28 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t28, ptr %lp4
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t30 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %t30
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Versions", ptr %t31, i32 0, i32 7
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l36
  %t36 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %s0, ptr %l36)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l38
  br label %bb5
bb5:
  %t37 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l5
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Versions", ptr %t38, i32 0, i32 3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t40)
  br label %bb6
bb6:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Versions", ptr %t42, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t44)
  br label %bb7
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Versions", ptr %t46, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t48)
  br label %bb8
bb8:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Versions", ptr %t50, i32 0, i32 6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eCle_H9e31dbf06df58c38226424712d120dfe(ptr %v0, ptr %t52)
  br label %bb9
bb9:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Versions", ptr %t54, i32 0, i32 7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t56)
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Versions", ptr %t58, i32 0, i32 8
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t60)
  br label %bb11
bb11:
  store i64 0, ptr %l6, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l1)
  store i64 %t63, ptr %l52
  br label %bb12
bb12:
  %t64 = load i64, ptr %l52, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb13, label %bb14
bb13:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb18
bb15:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l6, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l8, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l8, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l59, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb17
bb17:
  %t91 = load i64, ptr %l59, !tbaa !24
  store i64 %t91, ptr %l56, !tbaa !24
  br label %bb18
bb18:
  %t92 = load i64, ptr %l56, !tbaa !24
  store i64 %t92, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb34
bb21:
  br label %bb22
bb22:
  %t101 = load i64, ptr %l6, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l11, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Versions", ptr %t111, i32 0, i32 2
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l78, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l1, i64 %t115)
  store i64 %t118, ptr %l81
  br label %bb23
bb23:
  %t119 = load i64, ptr %l81, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i1, ptr %t121, i64 %t119
  %t123 = load i1, ptr %t122, !tbaa !31
  br i1 %t123, label %bb24, label %bb25
bb24:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l83, !tbaa !29
  %t126 = load i64, ptr %l11, !tbaa !24
  %t129 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %s0, ptr %l2, i64 %t126)
  store %"compiler/source:Span" %t129, ptr %l86
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l1, i64 %t130)
  store i64 %t133, ptr %l89
  br label %bb27
bb27:
  %t134 = load i64, ptr %l11, !tbaa !24
  %t137 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %s0, ptr %l3, i64 %t134)
  store i32 %t137, ptr %l92
  br label %bb28
bb28:
  %t138 = load ptr, ptr %lp4
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v0, ptr %t138, i64 %t139)
  store ptr %t142, ptr %l95
  br label %bb29
bb29:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t146 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %s0, ptr %l5, i64 %t143)
  store i1 %t146, ptr %l98
  br label %bb30
bb30:
  %t147 = load ptr, ptr %l83, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l86
  %t149 = load i64, ptr %l89, !tbaa !24
  %t150 = load i32, ptr %l92, !tbaa !23
  %t151 = load ptr, ptr %l95, !tbaa !29
  %t152 = load i1, ptr %l98, !tbaa !21
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v0, ptr %t147, %"compiler/source:Span" %t148, i64 %t149, i32 %t150, ptr %t151, i1 %t152)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l10, !tbaa !24
  br label %bb19
bb34:
  store i64 0, ptr %l12, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Versions", ptr %t157, i32 0, i32 3
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t159)
  store i64 %t161, ptr %l103
  br label %bb35
bb35:
  %t162 = load i64, ptr %l103, !tbaa !24
  store i64 %t162, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t163 = load i64, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t167 = icmp sgt i64 %t163, %t164
  br i1 %t167, label %bb36, label %bb37
bb36:
  %t169 = load i64, ptr %l14, !tbaa !24
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb41
bb38:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = sub i64 %t173, %t174
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t183 = sub i64 %t181, 1
  %t184 = load i64, ptr %l14, !tbaa !24
  %t187 = sdiv i64 %t183, %t184
  store i64 %t187, ptr %l110, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb40
bb40:
  %t189 = load i64, ptr %l110, !tbaa !24
  store i64 %t189, ptr %l107, !tbaa !24
  br label %bb41
bb41:
  %t190 = load i64, ptr %l107, !tbaa !24
  store i64 %t190, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb42
bb42:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb43, label %bb44
bb43:
  br label %bb60
bb44:
  br label %bb45
bb45:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l14, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l17, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Versions", ptr %t209, i32 0, i32 3
  %t212 = load i64, ptr %l17, !tbaa !24
  %t215 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t211, i64 %t212)
  store i64 %t215, ptr %l131
  br label %bb46
bb46:
  %t216 = load i64, ptr %l131, !tbaa !24
  store i64 %t216, ptr %l18, !tbaa !24
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Versions", ptr %t217, i32 0, i32 9
  %t220 = load i64, ptr %l18, !tbaa !24
  %t223 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %t219, i64 %t220)
  store i1 %t223, ptr %l135
  br label %bb47
bb47:
  %t224 = load i1, ptr %l135, !tbaa !21
  %t225 = xor i1 %t224, true
  br i1 %t225, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s7
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/typed:Versions", ptr %t227, i32 0, i32 9
  store ptr %t229, ptr %l138, !tbaa !29
  %t230 = load i64, ptr %l18, !tbaa !24
  store i64 %t230, ptr %l139, !tbaa !24
  %t231 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l140
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t232 = load ptr, ptr %l138, !tbaa !29
  %t233 = load i64, ptr %l139, !tbaa !24
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %s7, ptr %t232, i64 %t233, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s7)
  br label %bb52
bb52:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Versions", ptr %t235, i32 0, i32 9
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hdc84c10e1af960a666eeb267120f3ec3(ptr %v0, ptr %v0, ptr %t237, i64 %t238)
  %t242 = extractvalue { i32, ptr } %t241, 1
  %t243 = extractvalue { i32, ptr } %t241, 0
  store i32 %t243, ptr %l146
  %t244 = icmp ne i32 %t243, 0
  br i1 %t244, label %bb54, label %ok.245, !prof !99
ok.245:
  store ptr %t242, ptr %l145
  br label %bb53
bb53:
  %t246 = load ptr, ptr %l145, !tbaa !29
  store ptr %t246, ptr %l141, !tbaa !29
  br label %bb57
bb54:
  %t247 = load i32, ptr %l146, !tbaa !23
  %t248 = icmp eq i32 %t247, 65536
  br i1 %t248, label %bb55, label %bb56
bb55:
  call void @__olang_bang_failed_plain(ptr @olang_loc_59830ee0ec754a32_f5aff824d93b155e)
  unreachable
bb56:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b8ff85e818b1a126_11cf17c421c4721a)
  unreachable
bb57:
  %t250 = load i64, ptr %l17, !tbaa !24
  %t251 = load ptr, ptr %l141, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t251, i64 %t250)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t253 = load i64, ptr %l16, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l16, !tbaa !24
  br label %bb42
bb60:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Versions", ptr %t257, i32 0, i32 3
  %t261 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t259)
  store i64 %t261, ptr %l153
  br label %bb61
bb61:
  %t262 = load i64, ptr %l153, !tbaa !24
  %t263 = icmp sgt i64 %t262, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t263, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l52 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallViews(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sle i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t15 = and i64 %t11, %t12
  %t17 = icmp ne i64 %t15, 0
  store i1 %t17, ptr %l16, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Call", ptr %t21, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = load i64, ptr @G_2ecompiler_2ftyped_2eViewBits, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t26, i64 %t27)
  store i64 %t30, ptr %l26
  br label %bb8
bb8:
  %t31 = load i64, ptr %l26, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb14
bb11:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l6, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l33, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l33, !tbaa !24
  store i64 %t58, ptr %l30, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l30, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t79 = load i64, ptr %l9, !tbaa !24
  store i64 %t79, ptr %l52, !tbaa !24
  %t80 = load i64, ptr %l52, !tbaa !24
  %t81 = load i64, ptr %l52, !tbaa !24
  %t82 = shl i64 1, %t81
  %t85 = and i64 %t78, %t82
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb19, label %bb20
bb19:
  br label %bb26
bb20:
  br label %bb21
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Call", ptr %t90, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l58, !tbaa !27
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr ptr, ptr %t97, i64 %t94
  %t99 = load ptr, ptr %t98, !tbaa !39
  %t102 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t89, ptr %t99)
  store i64 %t102, ptr %l61
  br label %bb22
bb22:
  %t103 = load i64, ptr %l61, !tbaa !24
  store i64 %t103, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sle i64 %t104, 0
  br i1 %t106, label %bb23, label %bb24
bb23:
  store i64 0, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t109 = load i64, ptr %l3, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = or i64 %t109, %t110
  store i64 %t113, ptr %l3, !tbaa !24
  br label %bb26
bb26:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l8, !tbaa !24
  br label %bb15
bb27:
  %t119 = load i64, ptr %l3, !tbaa !24
  store i64 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eCallViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l16 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t23 = getelementptr %"compiler/typed:ViewWalk", ptr %a0, i32 0, i32 3
  %t24 = load { ptr, ptr }, ptr %t23
  %t25 = load i32, ptr %l3, !tbaa !23
  %t27 = extractvalue { ptr, ptr } %t24, 0
  %t28 = extractvalue { ptr, ptr } %t24, 1
  %t30 = call i64 %t27(ptr %t28, i32 %t25)
  store i64 %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_996d81e577c7faae_f3b4a025cf703a)
  unreachable
bb12:
  %t32 = load i64, ptr %l6, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eElidedCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2earrayValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l6 = alloca i32
  %l8 = alloca i32
  %l10 = alloca ptr
  %l13 = alloca i32
  %l16 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:ViewWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t7 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %a1)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t9 = call ptr @__olang_scope_of(ptr %t8, ptr null)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = load i32, ptr %l6, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t12, ptr %t13, i32 %t14)
  store i32 %t15, ptr %l8
  br label %bb2
bb2:
  %t16 = load i32, ptr %l8, !tbaa !23
  store i32 %t16, ptr %l2, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:ViewWalk", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l10, !tbaa !29
  %t21 = load i32, ptr %l2, !tbaa !23
  %t22 = load ptr, ptr %l10, !tbaa !29
  %t23 = call ptr @__olang_scope_of(ptr %t22, ptr null)
  %t24 = ptrtoint ptr %t23 to i64
  %t26 = inttoptr i64 %t24 to ptr
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t26, ptr %t27, i32 %t21)
  store i32 %t29, ptr %l13
  br label %bb3
bb3:
  %t30 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t32 = trunc i64 19 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/typed:ViewWalk", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l18, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = call ptr @__olang_scope_of(ptr %t40, ptr null)
  %t42 = ptrtoint ptr %t41 to i64
  %t44 = inttoptr i64 %t42 to ptr
  %t45 = load ptr, ptr %l18, !tbaa !29
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %t44, ptr %t45, i32 %t39)
  store i32 %t47, ptr %l21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb7
bb6:
  %t48 = load i32, ptr %l21, !tbaa !23
  %t49 = icmp eq i32 %t48, 0
  store i1 %t49, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t51 = load i1, ptr %l16, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ecopyViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 0, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:ViewWalk", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = call ptr @__olang_scope_of(ptr %t11, ptr null)
  %t13 = ptrtoint ptr %t12 to i64
  %t15 = inttoptr i64 %t13 to ptr
  %t16 = load ptr, ptr %l8, !tbaa !29
  %t18 = call ptr @compiler_2ftyped_2ecopied(ptr %t15, ptr %v1, ptr %v1, ptr %t16, ptr %t10)
  store ptr %t18, ptr %l11
  br label %bb4
bb4:
  %t19 = load ptr, ptr %l11, !tbaa !29
  store ptr %t19, ptr %l2, !tbaa !29
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i64 0, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t25, ptr %t26)
  store i64 %t30, ptr %l18
  br label %bb8
bb8:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  store i64 %t36, ptr %l21, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb11
bb11:
  %t38 = load i64, ptr %l21, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb40
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb40
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Elem", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t58, ptr %t62)
  store i64 %t65, ptr %l35
  br label %bb20
bb20:
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb40
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l36, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 8}
  %t74 = icmp eq i64 %t72, 5
  store i1 %t74, ptr %l37, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Payload", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t89 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t82, ptr %t86)
  store i64 %t89, ptr %l45
  br label %bb27
bb27:
  %t90 = load i64, ptr %l45, !tbaa !24
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb40
bb28:
  %t91 = load ptr, ptr %l1, !tbaa !29
  store ptr %t91, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = icmp ne ptr %t92, null
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = load i64, ptr %t95, !range !{i64 0, i64 8}
  %t98 = icmp eq i64 %t96, 2
  store i1 %t98, ptr %l47, !tbaa !21
  br label %bb30
bb30:
  %t99 = load i1, ptr %l47, !tbaa !21
  br i1 %t99, label %bb31, label %bb32
bb31:
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t102, i32 0, i32 2
  %t104 = load ptr, ptr %t103
  store ptr %t104, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load ptr, ptr %l6, !tbaa !29
  %t110 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t106, ptr %t107)
  store i64 %t110, ptr %l54
  br label %bb34
bb34:
  %t111 = load i64, ptr %l54, !tbaa !24
  store i64 %t111, ptr %l7, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_34c65fd26df9bfcd_2dc4d2164b9a2f69)
  unreachable
bb40:
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2ematchRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Match", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb8
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Arm", ptr %t24, i32 0, i32 4
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t34 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t27, ptr %t31)
  store i64 %t34, ptr %l22
  br label %bb5
bb5:
  %t35 = load i64, ptr %l18, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  %t37 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t35, i64 %t36)
  store i64 %t37, ptr %l23
  br label %bb6
bb6:
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %l2, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb1
bb8:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Match", ptr %t43, i32 0, i32 2
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load i64, ptr %l2, !tbaa !24
  store i64 %t52, ptr %l30, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l31, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Match", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb11, label %bb12
bb10:
  br label %bb16
bb11:
  call void @__olang_check_failed(ptr @olang_loc_dd6dc40ab752fedf_c333d42519625383)
  unreachable
bb12:
  br label %bb13
bb13:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Match", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Arm", ptr %t64, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t71 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t69, ptr %t68)
  store i64 %t71, ptr %l39
  br label %bb14
bb14:
  %t72 = load i64, ptr %l30, !tbaa !24
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = call i64 @compiler_2ftyped_2emeetRoots(i64 %t72, i64 %t73)
  store i64 %t74, ptr %l40
  br label %bb15
bb15:
  %t75 = load i64, ptr %l40, !tbaa !24
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2elocalRoots(ptr %v0, ptr %t16, i32 %t17)
  store i64 %t20, ptr %l16
  br label %bb6
bb6:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l7, !tbaa !24
  br label %bb40
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 2
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l25
  br label %bb13
bb13:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  br label %bb40
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l26, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 3
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t62 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t58, ptr %t59)
  store i64 %t62, ptr %l34
  br label %bb20
bb20:
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb40
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t65 = load ptr, ptr %l35, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l35, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 8}
  %t71 = icmp eq i64 %t69, 4
  store i1 %t71, ptr %l36, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l36, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Elem", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t79, ptr %t83)
  store i64 %t86, ptr %l44
  br label %bb27
bb27:
  %t87 = load i64, ptr %l44, !tbaa !24
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb40
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t89 = load ptr, ptr %l45, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l45, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 8}
  %t95 = icmp eq i64 %t93, 5
  store i1 %t95, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t96 = load i1, ptr %l46, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l6, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Payload", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t110 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t103, ptr %t107)
  store i64 %t110, ptr %l54
  br label %bb34
bb34:
  %t111 = load i64, ptr %l54, !tbaa !24
  store i64 %t111, ptr %l7, !tbaa !24
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_38f82f633fcbfe78_2a415e18f8868a4c)
  unreachable
bb40:
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l54 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i1
  %l84 = alloca i1
  %l89 = alloca i64
  %l90 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca i1
  %l105 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eholderRoots(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l19
  br label %bb6
bb6:
  %t21 = load i64, ptr %l19, !tbaa !24
  store i64 %t21, ptr %l10, !tbaa !24
  br label %bb74
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 18}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i64 %t41, ptr %l28
  br label %bb13
bb13:
  %t42 = load i64, ptr %l28, !tbaa !24
  store i64 %t42, ptr %l10, !tbaa !24
  br label %bb74
bb14:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t44 = load ptr, ptr %l29, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l29, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 10
  store i1 %t50, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = getelementptr { i64, [5 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = getelementptr %"compiler/typed:Slice", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t65 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eplaceRoots(ptr %v0, ptr %v1, ptr %t58, ptr %t62)
  store i64 %t65, ptr %l38
  br label %bb20
bb20:
  %t66 = load i64, ptr %l38, !tbaa !24
  store i64 %t66, ptr %l10, !tbaa !24
  br label %bb74
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t68 = load ptr, ptr %l39, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 18}
  %t74 = icmp eq i64 %t72, 5
  store i1 %t74, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t75 = load i1, ptr %l40, !tbaa !21
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Promote", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t89 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2earrayValue(ptr %v0, ptr %v1, ptr %t82, ptr %t86)
  store i1 %t89, ptr %l48
  br label %bb27
bb27:
  %t90 = load i1, ptr %l48, !tbaa !21
  br i1 %t90, label %bb28, label %bb29
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l5, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Promote", ptr %t92, i32 0, i32 0
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t99 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %t91, ptr %t95)
  store i64 %t99, ptr %l54
  br label %bb30
bb29:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb31
bb30:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l49, !tbaa !24
  br label %bb31
bb31:
  %t101 = load i64, ptr %l49, !tbaa !24
  store i64 %t101, ptr %l10, !tbaa !24
  br label %bb74
bb32:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t103 = load ptr, ptr %l55, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb33, label %bb34
bb33:
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 9
  store i1 %t109, ptr %l56, !tbaa !21
  br label %bb34
bb34:
  %t110 = load i1, ptr %l56, !tbaa !21
  br i1 %t110, label %bb35, label %bb36
bb35:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t113, i32 0, i32 2
  %t115 = load i32, ptr %t114, !range !{i32 0, i32 52}
  store i32 %t115, ptr %l6
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [5 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t119, i32 0, i32 4
  %t121 = load { i64, ptr }, ptr %t120
  store { i64, ptr } %t121, ptr %l7, !tbaa !27
  br label %bb37
bb36:
  br label %bb46
bb37:
  %t123 = load i32, ptr %l6, !range !{i32 0, i32 52}
  %t125 = call i1 @compiler_2ftyped_2ePassesRefs(i32 %t123)
  store i1 %t125, ptr %l64
  br label %bb38
bb38:
  %t126 = load i1, ptr %l64, !tbaa !21
  br i1 %t126, label %bb39, label %bb40
bb39:
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t131 = icmp sgt i64 %t129, 0
  store i1 %t131, ptr %l65, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb41
bb41:
  %t133 = load i1, ptr %l65, !tbaa !21
  br i1 %t133, label %bb42, label %bb43
bb42:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t135, ptr %l71, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr ptr, ptr %t137, i64 0
  %t139 = load ptr, ptr %t138, !tbaa !39
  %t142 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t134, ptr %t139)
  store i64 %t142, ptr %l73
  br label %bb44
bb43:
  store i64 -1, ptr %l69, !tbaa !24
  br label %bb45
bb44:
  %t143 = load i64, ptr %l73, !tbaa !24
  store i64 %t143, ptr %l69, !tbaa !24
  br label %bb45
bb45:
  %t144 = load i64, ptr %l69, !tbaa !24
  store i64 %t144, ptr %l10, !tbaa !24
  br label %bb74
bb46:
  %t145 = load ptr, ptr %l1, !tbaa !29
  store ptr %t145, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t146 = load ptr, ptr %l74, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb47, label %bb48
bb47:
  %t149 = load ptr, ptr %l74, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 18}
  %t152 = icmp eq i64 %t150, 12
  store i1 %t152, ptr %l75, !tbaa !21
  br label %bb48
bb48:
  %t153 = load i1, ptr %l75, !tbaa !21
  br i1 %t153, label %bb49, label %bb50
bb49:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr { i64, [5 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t156, i32 0, i32 2
  %t158 = load ptr, ptr %t157
  store ptr %t158, ptr %l8, !tbaa !29
  br label %bb51
bb50:
  br label %bb62
bb51:
  %t160 = load ptr, ptr %l8, !tbaa !29
  %t162 = getelementptr %"compiler/typed:Seq", ptr %t160, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb52, label %bb53
bb52:
  %t169 = load ptr, ptr %l8, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Seq", ptr %t169, i32 0, i32 0
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t176 = icmp eq i64 %t174, 0
  store i1 %t176, ptr %l84, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb54
bb54:
  %t178 = load i1, ptr %l84, !tbaa !21
  br i1 %t178, label %bb55, label %bb56
bb55:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l90, !tbaa !29
  %t180 = load ptr, ptr %l8, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Seq", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb57, label %bb58
bb56:
  store i64 -1, ptr %l89, !tbaa !24
  br label %bb61
bb57:
  call void @__olang_check_failed(ptr @olang_loc_859ef9a416eafd63_e1a98b601ef27d27)
  unreachable
bb58:
  br label %bb59
bb59:
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Seq", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load ptr, ptr %l90, !tbaa !29
  %t193 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t191, ptr %t190)
  store i64 %t193, ptr %l96
  br label %bb60
bb60:
  %t194 = load i64, ptr %l96, !tbaa !24
  store i64 %t194, ptr %l89, !tbaa !24
  br label %bb61
bb61:
  %t195 = load i64, ptr %l89, !tbaa !24
  store i64 %t195, ptr %l10, !tbaa !24
  br label %bb74
bb62:
  %t196 = load ptr, ptr %l1, !tbaa !29
  store ptr %t196, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t197 = load ptr, ptr %l97, !tbaa !29
  %t198 = icmp ne ptr %t197, null
  br i1 %t198, label %bb63, label %bb64
bb63:
  %t200 = load ptr, ptr %l97, !tbaa !29
  %t201 = load i64, ptr %t200, !range !{i64 0, i64 18}
  %t203 = icmp eq i64 %t201, 17
  store i1 %t203, ptr %l98, !tbaa !21
  br label %bb64
bb64:
  %t204 = load i1, ptr %l98, !tbaa !21
  br i1 %t204, label %bb65, label %bb66
bb65:
  %t205 = load ptr, ptr %l1, !tbaa !29
  %t207 = getelementptr { i64, [5 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t207, i32 0, i32 2
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l9, !tbaa !29
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l9, !tbaa !29
  %t215 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2erefRoots(ptr %v0, ptr %v1, ptr %t211, ptr %t212)
  store i64 %t215, ptr %l105
  br label %bb68
bb68:
  %t216 = load i64, ptr %l105, !tbaa !24
  store i64 %t216, ptr %l10, !tbaa !24
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  store i64 -1, ptr %l10, !tbaa !24
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_21fa85d53b5eac7b_5a0125da6c5c013f)
  unreachable
bb74:
  %t217 = load i64, ptr %l10, !tbaa !24
  store i64 %t217, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca ptr
  %l14 = alloca i64
  %l23 = alloca { i64, ptr }
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l48 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i32
  %l56 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t6, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 1
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = getelementptr %"compiler/typed:dropWalk", ptr %t12, i32 0, i32 4
  store i64 %t10, ptr %t13, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 5
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l14
  br label %bb4
bb4:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr %"compiler/typed:Block", ptr %t20, i32 0, i32 1
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l4, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr ptr, ptr %t41, i64 %t38
  %t43 = load ptr, ptr %t42, !tbaa !39
  %t45 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t45, ptr %t43)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l4, !tbaa !24
  br label %bb5
bb11:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/typed:dropWalk", ptr %t54, i32 0, i32 4
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = sub i64 %t57, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t53, i64 %t59)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/typed:dropWalk", ptr %t62, i32 0, i32 5
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l36
  br label %bb14
bb14:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l36, !tbaa !24
  %t70 = icmp sgt i64 %t68, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb15, label %bb16
bb15:
  br label %bb37
bb16:
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/typed:dropWalk", ptr %t74, i32 0, i32 5
  %t78 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t76)
  %t79 = extractvalue { i32, i64 } %t78, 1
  %t80 = extractvalue { i32, i64 } %t78, 0
  store i32 %t80, ptr %l44
  %t81 = icmp ne i32 %t80, 0
  br i1 %t81, label %bb19, label %ok.82, !prof !99
ok.82:
  store i64 %t79, ptr %l43
  br label %bb18
bb18:
  %t83 = load i64, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l40, !tbaa !24
  br label %bb26
bb19:
  %t84 = load i32, ptr %l44, !tbaa !23
  %t85 = icmp eq i32 %t84, 65536
  br i1 %t85, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_17c315ca28f40c4c_14b80e258f8c2b0)
  unreachable
bb21:
  %t87 = load i32, ptr %l44, !tbaa !23
  %t88 = icmp eq i32 %t87, 65537
  br i1 %t88, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5)
  unreachable
bb23:
  %t90 = load i32, ptr %l44, !tbaa !23
  %t91 = icmp eq i32 %t90, 65538
  br i1 %t91, label %bb24, label %bb25
bb24:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6fe9eb3ff5642bc1_33392e6f48613205)
  unreachable
bb25:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5f1ddc7ef7469727_e10177d23ca0510b)
  unreachable
bb26:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/typed:dropWalk", ptr %t93, i32 0, i32 6
  %t97 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t95)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l52
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb28, label %ok.101, !prof !99
ok.101:
  store i64 %t98, ptr %l51
  br label %bb27
bb27:
  %t102 = load i64, ptr %l51, !tbaa !24
  store i64 %t102, ptr %l48, !tbaa !24
  br label %bb35
bb28:
  %t103 = load i32, ptr %l52, !tbaa !23
  %t104 = icmp eq i32 %t103, 65536
  br i1 %t104, label %bb29, label %bb30
bb29:
  call void @__olang_bang_failed_plain(ptr @olang_loc_24a3ccdd47c97c70_8558c77bc7af118c)
  unreachable
bb30:
  %t106 = load i32, ptr %l52, !tbaa !23
  %t107 = icmp eq i32 %t106, 65537
  br i1 %t107, label %bb31, label %bb32
bb31:
  call void @__olang_bang_failed_plain(ptr @olang_loc_130a89b2782f12a5_38e9334e27b56d91)
  unreachable
bb32:
  %t109 = load i32, ptr %l52, !tbaa !23
  %t110 = icmp eq i32 %t109, 65538
  br i1 %t110, label %bb33, label %bb34
bb33:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1916e27cc0da8fc5_b948d7408e366d01)
  unreachable
bb34:
  call void @__olang_bang_failed_plain(ptr @olang_loc_567e5689d7ac5ccb_d57870be630e767)
  unreachable
bb35:
  br label %bb36
bb36:
  br label %bb13
bb37:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l56, !tbaa !29
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = getelementptr %"compiler/typed:dropWalk", ptr %t113, i32 0, i32 4
  %t115 = load i64, ptr %t114, !tbaa !24
  %t117 = sub i64 %t115, 1
  %t119 = load ptr, ptr %l56, !tbaa !29
  %t120 = getelementptr %"compiler/typed:dropWalk", ptr %t119, i32 0, i32 4
  store i64 %t117, ptr %t120, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l77 = alloca ptr
  %l78 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l147 = alloca { i64, ptr }
  %l148 = alloca i64
  %l149 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l166 = alloca i1
  %l179 = alloca { i64, ptr }
  %l189 = alloca ptr
  %l190 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l219 = alloca { i64, ptr }
  %l222 = alloca ptr
  %l223 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l248 = alloca ptr
  %l249 = alloca i1
  %l261 = alloca { i64, ptr }
  %l270 = alloca ptr
  %l271 = alloca i1
  %l279 = alloca ptr
  %l280 = alloca i1
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:dropWalk", ptr %t5, i32 0, i32 3
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l35, !tbaa !21
  br label %bb3
bb3:
  %t10 = load i1, ptr %l35, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t12 = load ptr, ptr %l38, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l38, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 18}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l39, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l39, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t21 = load ptr, ptr %l42, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l42, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 1
  store i1 %t27, ptr %l43, !tbaa !21
  br label %bb12
bb12:
  %t28 = load i1, ptr %l43, !tbaa !21
  br i1 %t28, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb178
bb16:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t30 = load ptr, ptr %l46, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb17, label %bb18
bb17:
  %t33 = load ptr, ptr %l46, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t37 = load i1, ptr %l47, !tbaa !21
  br i1 %t37, label %bb19, label %bb20
bb19:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb29
bb20:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t45 = load ptr, ptr %l52, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb21, label %bb22
bb21:
  %t48 = load ptr, ptr %l52, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 3
  store i1 %t51, ptr %l53, !tbaa !21
  br label %bb22
bb22:
  %t52 = load i1, ptr %l53, !tbaa !21
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l2, !tbaa !29
  br label %bb29
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t60 = load ptr, ptr %l58, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb25, label %bb26
bb25:
  %t63 = load ptr, ptr %l58, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 18}
  %t66 = icmp eq i64 %t64, 4
  store i1 %t66, ptr %l59, !tbaa !21
  br label %bb26
bb26:
  %t67 = load i1, ptr %l59, !tbaa !21
  br i1 %t67, label %bb27, label %bb28
bb27:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t70, i32 0, i32 2
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l2, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  br label %bb30
bb30:
  br label %bb178
bb31:
  %t79 = load ptr, ptr %l1, !tbaa !29
  store ptr %t79, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t80 = load ptr, ptr %l67, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb32, label %bb33
bb32:
  %t83 = load ptr, ptr %l67, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 18}
  %t86 = icmp eq i64 %t84, 5
  store i1 %t86, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t87 = load i1, ptr %l68, !tbaa !21
  br i1 %t87, label %bb34, label %bb35
bb34:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t90, i32 0, i32 2
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l3, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l3, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Promote", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  br label %bb37
bb37:
  br label %bb178
bb38:
  %t102 = load ptr, ptr %l1, !tbaa !29
  store ptr %t102, ptr %l77, !tbaa !29
  store i1 false, ptr %l78, !tbaa !21
  %t103 = load ptr, ptr %l77, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb39, label %bb40
bb39:
  %t106 = load ptr, ptr %l77, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 6
  store i1 %t109, ptr %l78, !tbaa !21
  br label %bb40
bb40:
  %t110 = load i1, ptr %l78, !tbaa !21
  br i1 %t110, label %bb41, label %bb42
bb41:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [5 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l4, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %t117, ptr %t118)
  br label %bb44
bb44:
  br label %bb178
bb45:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t122 = load ptr, ptr %l85, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb46, label %bb47
bb46:
  %t125 = load ptr, ptr %l85, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 18}
  %t128 = icmp eq i64 %t126, 7
  store i1 %t128, ptr %l86, !tbaa !21
  br label %bb47
bb47:
  %t129 = load i1, ptr %l86, !tbaa !21
  br i1 %t129, label %bb48, label %bb49
bb48:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l5, !tbaa !29
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l5, !tbaa !29
  %t139 = getelementptr %"compiler/typed:Make", ptr %t137, i32 0, i32 2
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t136, { i64, ptr } %t140)
  br label %bb51
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l5, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Make", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t143, ptr %t147)
  br label %bb52
bb52:
  br label %bb178
bb53:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t151 = load ptr, ptr %l97, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb54, label %bb55
bb54:
  %t154 = load ptr, ptr %l97, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 8
  store i1 %t157, ptr %l98, !tbaa !21
  br label %bb55
bb55:
  %t158 = load i1, ptr %l98, !tbaa !21
  br i1 %t158, label %bb56, label %bb57
bb56:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l6, !tbaa !29
  br label %bb58
bb57:
  br label %bb61
bb58:
  store %olang.scope zeroinitializer, ptr %s7
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l6, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Collect", ptr %t166, i32 0, i32 0
  %t169 = load ptr, ptr %t168, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t165, ptr %t169)
  br label %bb59
bb59:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l6, !tbaa !29
  %t175 = getelementptr %"compiler/typed:Collect", ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %s7, ptr %t172, ptr %t176, ptr null)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb178
bb61:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t180 = load ptr, ptr %l109, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb62, label %bb63
bb62:
  %t183 = load ptr, ptr %l109, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 18}
  %t186 = icmp eq i64 %t184, 9
  store i1 %t186, ptr %l110, !tbaa !21
  br label %bb63
bb63:
  %t187 = load i1, ptr %l110, !tbaa !21
  br i1 %t187, label %bb64, label %bb65
bb64:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t190, i32 0, i32 4
  %t192 = load { i64, ptr }, ptr %t191
  store { i64, ptr } %t192, ptr %l7, !tbaa !27
  br label %bb66
bb65:
  br label %bb69
bb66:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %t194, { i64, ptr } %t195)
  br label %bb67
bb67:
  %t198 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t198, i1 false)
  br label %bb68
bb68:
  br label %bb178
bb69:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t201 = load ptr, ptr %l118, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb70, label %bb71
bb70:
  %t204 = load ptr, ptr %l118, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 18}
  %t207 = icmp eq i64 %t205, 10
  store i1 %t207, ptr %l119, !tbaa !21
  br label %bb71
bb71:
  %t208 = load i1, ptr %l119, !tbaa !21
  br i1 %t208, label %bb72, label %bb73
bb72:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l8, !tbaa !29
  br label %bb74
bb73:
  br label %bb78
bb74:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l8, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Slice", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t215, ptr %t219)
  br label %bb75
bb75:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load ptr, ptr %l8, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Slice", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t223, ptr %t227)
  br label %bb76
bb76:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t232 = load ptr, ptr %l8, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Slice", ptr %t232, i32 0, i32 2
  %t235 = load ptr, ptr %t234, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t231, ptr %t235)
  br label %bb77
bb77:
  br label %bb178
bb78:
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t240 = load ptr, ptr %l136, !tbaa !29
  %t241 = icmp ne ptr %t240, null
  br i1 %t241, label %bb79, label %bb80
bb79:
  %t243 = load ptr, ptr %l136, !tbaa !29
  %t244 = load i64, ptr %t243, !range !{i64 0, i64 18}
  %t246 = icmp eq i64 %t244, 11
  store i1 %t246, ptr %l137, !tbaa !21
  br label %bb80
bb80:
  %t247 = load i1, ptr %l137, !tbaa !21
  br i1 %t247, label %bb81, label %bb82
bb81:
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t248, i32 0, i32 1
  %t251 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t250, i32 0, i32 2
  %t252 = load ptr, ptr %t251
  store ptr %t252, ptr %l9, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  store %olang.scope zeroinitializer, ptr %s10
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l9, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Cond", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t254, ptr %t258)
  br label %bb84
bb84:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t262)
  store { i64, ptr } %t264, ptr %l147
  br label %bb85
bb85:
  %t265 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l148, !tbaa !24
  %t267 = load i64, ptr %l148, !tbaa !24
  %t268 = mul i64 %t267, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  store { i64, ptr } %t271, ptr %l149, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l148, !tbaa !24
  %t277 = mul i64 %t276, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t273, ptr %t275, i64 %t277, i1 false)
  %t278 = load { i64, ptr }, ptr %l149, !tbaa !27
  store { i64, ptr } %t278, ptr %l10, !tbaa !27
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load ptr, ptr %l9, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Cond", ptr %t280, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t279, ptr %t283)
  br label %bb86
bb86:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s10, ptr %t286)
  store { i64, ptr } %t288, ptr %l154
  br label %bb87
bb87:
  %t289 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  store i64 %t290, ptr %l155, !tbaa !24
  %t291 = load i64, ptr %l155, !tbaa !24
  %t292 = mul i64 %t291, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  store { i64, ptr } %t295, ptr %l156, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = load i64, ptr %l155, !tbaa !24
  %t301 = mul i64 %t300, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t297, ptr %t299, i64 %t301, i1 false)
  %t302 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t302, ptr %l11, !tbaa !27
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s10, ptr %t303, { i64, ptr } %t304)
  br label %bb88
bb88:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load ptr, ptr %l9, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Cond", ptr %t308, i32 0, i32 2
  %t311 = load ptr, ptr %t310, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t307, ptr %t311)
  br label %bb89
bb89:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s10, ptr %t315, { i64, ptr } %t316)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s10)
  br label %bb178
bb91:
  %t319 = load ptr, ptr %l1, !tbaa !29
  store ptr %t319, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t320 = load ptr, ptr %l165, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb92, label %bb93
bb92:
  %t323 = load ptr, ptr %l165, !tbaa !29
  %t324 = load i64, ptr %t323, !range !{i64 0, i64 18}
  %t326 = icmp eq i64 %t324, 12
  store i1 %t326, ptr %l166, !tbaa !21
  br label %bb93
bb93:
  %t327 = load i1, ptr %l166, !tbaa !21
  br i1 %t327, label %bb94, label %bb95
bb94:
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t330, i32 0, i32 2
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l12, !tbaa !29
  br label %bb96
bb95:
  br label %bb105
bb96:
  %t334 = load ptr, ptr %l12, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Seq", ptr %t334, i32 0, i32 0
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t339 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t339, 0
  store i64 %t341, ptr %l15, !tbaa !24
  br label %bb97
bb97:
  %t343 = load i64, ptr %l14, !tbaa !24
  %t344 = load i64, ptr %l15, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t351 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t351, ptr %l179, !tbaa !27
  %t352 = load i64, ptr %l14, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr ptr, ptr %t355, i64 %t352
  %t357 = load ptr, ptr %t356, !tbaa !39
  %t359 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %t359, ptr %t357)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t363 = load i64, ptr %l14, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l14, !tbaa !24
  br label %bb97
bb103:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l12, !tbaa !29
  %t370 = getelementptr %"compiler/typed:Seq", ptr %t368, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t367, ptr %t371)
  br label %bb104
bb104:
  br label %bb178
bb105:
  %t374 = load ptr, ptr %l1, !tbaa !29
  store ptr %t374, ptr %l189, !tbaa !29
  store i1 false, ptr %l190, !tbaa !21
  %t375 = load ptr, ptr %l189, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb106, label %bb107
bb106:
  %t378 = load ptr, ptr %l189, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 18}
  %t381 = icmp eq i64 %t379, 13
  store i1 %t381, ptr %l190, !tbaa !21
  br label %bb107
bb107:
  %t382 = load i1, ptr %l190, !tbaa !21
  br i1 %t382, label %bb108, label %bb109
bb108:
  %t383 = load ptr, ptr %l1, !tbaa !29
  %t385 = getelementptr { i64, [5 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t385, i32 0, i32 2
  %t387 = load ptr, ptr %t386
  store ptr %t387, ptr %l17, !tbaa !29
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %t389, ptr %t390)
  br label %bb111
bb111:
  br label %bb178
bb112:
  %t393 = load ptr, ptr %l1, !tbaa !29
  store ptr %t393, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t394 = load ptr, ptr %l197, !tbaa !29
  %t395 = icmp ne ptr %t394, null
  br i1 %t395, label %bb113, label %bb114
bb113:
  %t397 = load ptr, ptr %l197, !tbaa !29
  %t398 = load i64, ptr %t397, !range !{i64 0, i64 18}
  %t400 = icmp eq i64 %t398, 14
  store i1 %t400, ptr %l198, !tbaa !21
  br label %bb114
bb114:
  %t401 = load i1, ptr %l198, !tbaa !21
  br i1 %t401, label %bb115, label %bb116
bb115:
  %t402 = load ptr, ptr %l1, !tbaa !29
  %t404 = getelementptr { i64, [5 x i64] }, ptr %t402, i32 0, i32 1
  %t405 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t404, i32 0, i32 2
  %t406 = load ptr, ptr %t405
  store ptr %t406, ptr %l18, !tbaa !29
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %t408, ptr %t409)
  br label %bb118
bb118:
  br label %bb178
bb119:
  %t412 = load ptr, ptr %l1, !tbaa !29
  store ptr %t412, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t413 = load ptr, ptr %l205, !tbaa !29
  %t414 = icmp ne ptr %t413, null
  br i1 %t414, label %bb120, label %bb121
bb120:
  %t416 = load ptr, ptr %l205, !tbaa !29
  %t417 = load i64, ptr %t416, !range !{i64 0, i64 18}
  %t419 = icmp eq i64 %t417, 16
  store i1 %t419, ptr %l206, !tbaa !21
  br label %bb121
bb121:
  %t420 = load i1, ptr %l206, !tbaa !21
  br i1 %t420, label %bb122, label %bb123
bb122:
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t423 = getelementptr { i64, [5 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t423, i32 0, i32 2
  %t425 = load ptr, ptr %t424
  store ptr %t425, ptr %l19, !tbaa !29
  br label %bb124
bb123:
  br label %bb137
bb124:
  %t427 = load ptr, ptr %l19, !tbaa !29
  %t429 = getelementptr %"compiler/typed:Text", ptr %t427, i32 0, i32 0
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t432 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 0
  store i64 %t434, ptr %l22, !tbaa !24
  br label %bb125
bb125:
  %t436 = load i64, ptr %l21, !tbaa !24
  %t437 = load i64, ptr %l22, !tbaa !24
  %t440 = icmp slt i64 %t436, %t437
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb126, label %bb127
bb126:
  br label %bb136
bb127:
  br label %bb128
bb128:
  %t444 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t444, ptr %l219, !tbaa !27
  %t445 = load i64, ptr %l21, !tbaa !24
  %t447 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t448 = load ptr, ptr %t447, !tbaa !27
  %t449 = getelementptr ptr, ptr %t448, i64 %t445
  %t450 = load ptr, ptr %t449, !tbaa !39
  store ptr %t450, ptr %l23, !tbaa !29
  %t452 = load ptr, ptr %l23, !tbaa !29
  store ptr %t452, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t453 = load ptr, ptr %l222, !tbaa !29
  %t454 = icmp ne ptr %t453, null
  br i1 %t454, label %bb129, label %bb130
bb129:
  %t456 = load ptr, ptr %l222, !tbaa !29
  %t457 = load i64, ptr %t456, !range !{i64 0, i64 2}
  %t459 = icmp eq i64 %t457, 1
  store i1 %t459, ptr %l223, !tbaa !21
  br label %bb130
bb130:
  %t460 = load i1, ptr %l223, !tbaa !21
  br i1 %t460, label %bb131, label %bb132
bb131:
  %t461 = load ptr, ptr %l23, !tbaa !29
  %t463 = getelementptr { i64, [2 x i64] }, ptr %t461, i32 0, i32 1
  %t464 = getelementptr { ptr }, ptr %t463, i32 0, i32 0
  %t465 = load ptr, ptr %t464
  %t467 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t467, ptr %t465)
  br label %bb133
bb132:
  br label %bb134
bb133:
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t472 = load i64, ptr %l21, !tbaa !24
  %t474 = add i64 %t472, 1
  store i64 %t474, ptr %l21, !tbaa !24
  br label %bb125
bb136:
  br label %bb178
bb137:
  %t476 = load ptr, ptr %l1, !tbaa !29
  store ptr %t476, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t477 = load ptr, ptr %l233, !tbaa !29
  %t478 = icmp ne ptr %t477, null
  br i1 %t478, label %bb138, label %bb139
bb138:
  %t480 = load ptr, ptr %l233, !tbaa !29
  %t481 = load i64, ptr %t480, !range !{i64 0, i64 18}
  %t483 = icmp eq i64 %t481, 17
  store i1 %t483, ptr %l234, !tbaa !21
  br label %bb139
bb139:
  %t484 = load i1, ptr %l234, !tbaa !21
  br i1 %t484, label %bb140, label %bb141
bb140:
  %t485 = load ptr, ptr %l1, !tbaa !29
  %t487 = getelementptr { i64, [5 x i64] }, ptr %t485, i32 0, i32 1
  %t488 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t487, i32 0, i32 2
  %t489 = load ptr, ptr %t488
  store ptr %t489, ptr %l25, !tbaa !29
  br label %bb142
bb141:
  br label %bb144
bb142:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t491, ptr %t492)
  br label %bb143
bb143:
  br label %bb178
bb144:
  %t496 = load ptr, ptr %l1, !tbaa !29
  store ptr %t496, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t497 = load ptr, ptr %l242, !tbaa !29
  %t498 = icmp ne ptr %t497, null
  br i1 %t498, label %bb145, label %bb146
bb145:
  %t500 = load ptr, ptr %l242, !tbaa !29
  %t501 = load i64, ptr %t500, !range !{i64 0, i64 18}
  %t503 = icmp eq i64 %t501, 15
  store i1 %t503, ptr %l243, !tbaa !21
  br label %bb146
bb146:
  %t504 = load i1, ptr %l243, !tbaa !21
  br i1 %t504, label %bb147, label %bb148
bb147:
  %t505 = load ptr, ptr %l1, !tbaa !29
  %t507 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  %t508 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t507, i32 0, i32 2
  %t509 = load ptr, ptr %t508
  store ptr %t509, ptr %l26, !tbaa !29
  br label %bb149
bb148:
  br label %bb177
bb149:
  %t511 = load ptr, ptr %l26, !tbaa !29
  store ptr %t511, ptr %l248, !tbaa !29
  store i1 false, ptr %l249, !tbaa !21
  %t512 = load ptr, ptr %l248, !tbaa !29
  %t513 = icmp ne ptr %t512, null
  br i1 %t513, label %bb150, label %bb151
bb150:
  %t515 = load ptr, ptr %l248, !tbaa !29
  %t516 = load i64, ptr %t515, !range !{i64 0, i64 3}
  %t518 = icmp eq i64 %t516, 1
  store i1 %t518, ptr %l249, !tbaa !21
  br label %bb151
bb151:
  %t519 = load i1, ptr %l249, !tbaa !21
  br i1 %t519, label %bb152, label %bb153
bb152:
  %t520 = load ptr, ptr %l26, !tbaa !29
  %t522 = getelementptr { i64, [4 x i64] }, ptr %t520, i32 0, i32 1
  %t523 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t522, i32 0, i32 1
  %t524 = load { i64, ptr }, ptr %t523
  store { i64, ptr } %t524, ptr %l27, !tbaa !27
  br label %bb154
bb153:
  br label %bb162
bb154:
  %t526 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t526, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t528 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t530 = extractvalue { i64, ptr } %t528, 0
  store i64 %t530, ptr %l30, !tbaa !24
  br label %bb155
bb155:
  %t532 = load i64, ptr %l29, !tbaa !24
  %t533 = load i64, ptr %l30, !tbaa !24
  %t536 = icmp slt i64 %t532, %t533
  %t538 = xor i1 %t536, true
  br i1 %t538, label %bb156, label %bb157
bb156:
  br label %bb161
bb157:
  br label %bb158
bb158:
  %t540 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t540, ptr %l261, !tbaa !27
  %t541 = load i64, ptr %l29, !tbaa !24
  %t543 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = getelementptr ptr, ptr %t544, i64 %t541
  %t546 = load ptr, ptr %t545, !tbaa !39
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/typed:Capture", ptr %t546, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t548, ptr %t552)
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t556 = load i64, ptr %l29, !tbaa !24
  %t558 = add i64 %t556, 1
  store i64 %t558, ptr %l29, !tbaa !24
  br label %bb155
bb161:
  br label %bb176
bb162:
  %t560 = load ptr, ptr %l26, !tbaa !29
  store ptr %t560, ptr %l270, !tbaa !29
  store i1 false, ptr %l271, !tbaa !21
  %t561 = load ptr, ptr %l270, !tbaa !29
  %t562 = icmp ne ptr %t561, null
  br i1 %t562, label %bb163, label %bb164
bb163:
  %t564 = load ptr, ptr %l270, !tbaa !29
  %t565 = load i64, ptr %t564, !range !{i64 0, i64 3}
  %t567 = icmp eq i64 %t565, 2
  store i1 %t567, ptr %l271, !tbaa !21
  br label %bb164
bb164:
  %t568 = load i1, ptr %l271, !tbaa !21
  br i1 %t568, label %bb165, label %bb166
bb165:
  %t569 = load ptr, ptr %l26, !tbaa !29
  %t571 = getelementptr { i64, [4 x i64] }, ptr %t569, i32 0, i32 1
  %t572 = getelementptr { i32, ptr, i32 }, ptr %t571, i32 0, i32 1
  %t573 = load ptr, ptr %t572
  store ptr %t573, ptr %l32, !tbaa !29
  br label %bb167
bb166:
  br label %bb169
bb167:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load ptr, ptr %l32, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t575, ptr %t576)
  br label %bb168
bb168:
  br label %bb176
bb169:
  %t580 = load ptr, ptr %l26, !tbaa !29
  store ptr %t580, ptr %l279, !tbaa !29
  store i1 false, ptr %l280, !tbaa !21
  %t581 = load ptr, ptr %l279, !tbaa !29
  %t582 = icmp ne ptr %t581, null
  br i1 %t582, label %bb170, label %bb171
bb170:
  %t584 = load ptr, ptr %l279, !tbaa !29
  %t585 = load i64, ptr %t584, !range !{i64 0, i64 3}
  %t587 = icmp eq i64 %t585, 0
  store i1 %t587, ptr %l280, !tbaa !21
  br label %bb171
bb171:
  %t588 = load i1, ptr %l280, !tbaa !21
  br i1 %t588, label %bb172, label %bb173
bb172:
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_e0d071190e38de5d_291e4ea72946f179)
  unreachable
bb176:
  br label %bb178
bb177:
  call void @__olang_check_failed(ptr @olang_loc_d40841e1665d5bac_305352f22a4532a8)
  unreachable
bb178:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l5 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i64 @compiler_2ftyped_2eDropFlag(ptr %v0, ptr %v1, ptr %t4, ptr %a1)
  store i64 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ekeepFor(ptr %v0, ptr %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l46 = alloca i1
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t10 = add i64 %t8, 1
  %t13 = mul i64 %a2, %t10
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i64, ptr %l7, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb4:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l25, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb6
bb6:
  %t43 = load i64, ptr %l25, !tbaa !24
  store i64 %t43, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t44 = load i64, ptr %l22, !tbaa !24
  store i64 %t44, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l9, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:dropWalk", ptr %t63, i32 0, i32 2
  %t66 = load i64, ptr %l10, !tbaa !24
  %t69 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l46
  br label %bb12
bb12:
  %t70 = load i1, ptr %l46, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb13, label %bb14
bb13:
  br label %bb21
bb14:
  br label %bb15
bb15:
  %t73 = load i1, ptr %l1, !tbaa !21
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/typed:dropWalk", ptr %t75, i32 0, i32 9
  %t78 = load i64, ptr %l4, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = add i64 %t78, %t79
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t77, i64 %t82, i1 true)
  br label %bb18
bb17:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/typed:dropWalk", ptr %t85, i32 0, i32 10
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = add i64 %t88, %t89
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t87, i64 %t92, i1 true)
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t95 = load i64, ptr %l9, !tbaa !24
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb8
bb22:
  %t99 = load i1, ptr %l1, !tbaa !21
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/typed:dropWalk", ptr %t101, i32 0, i32 9
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l3, !tbaa !24
  %t108 = add i64 %t104, %t105
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t103, i64 %t108, i1 false)
  br label %bb25
bb24:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/typed:dropWalk", ptr %t111, i32 0, i32 10
  %t114 = load i64, ptr %l4, !tbaa !24
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t114, %t115
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t113, i64 %t118, i1 false)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l47 = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/typed:dropWalk", ptr %t53, i32 0, i32 2
  %t56 = load i64, ptr %l7, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t57, ptr %l38, !tbaa !27
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i1, ptr %t61, i64 %t58
  %t63 = load i1, ptr %t62, !tbaa !31
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t56, i1 %t63)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l43, !tbaa !29
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l44, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/typed:dropWalk", ptr %t73, i32 0, i32 2
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t75)
  store i64 %t77, ptr %l47
  br label %bb15
bb15:
  %t78 = load i64, ptr %l47, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i1, ptr %t80, i64 %t78
  %t82 = load i1, ptr %t81, !tbaa !31
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t85 = getelementptr %"compiler/typed:dropWalk", ptr %t84, i32 0, i32 3
  store i1 %t82, ptr %t85, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l41 = alloca i64
  %l45 = alloca i1
  %l50 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 2
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  %t7 = add i64 %t6, 1
  store i64 %t7, ptr %l11, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l11, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t16, ptr %lp1
  %t18 = load ptr, ptr %lp1
  store { i64, ptr } %t15, ptr %t18, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/typed:dropWalk", ptr %t19, i32 0, i32 2
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l16
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_c1faed4ae36d3640_1d7aa47a4727493c)
  unreachable
bb4:
  %t24 = load i64, ptr %l16, !tbaa !24
  store i64 %t24, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t25, %t26
  br i1 %t29, label %bb5, label %bb6
bb5:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t31, 0
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb10
bb7:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = add i64 %t39, %t40
  %t45 = sub i64 %t43, 1
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = sdiv i64 %t45, %t46
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb9
bb9:
  %t51 = load i64, ptr %l23, !tbaa !24
  store i64 %t51, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t52 = load i64, ptr %l20, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  %t57 = icmp slt i64 %t53, %t54
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l4, !tbaa !24
  %t66 = mul i64 %t62, %t63
  %t69 = add i64 %t61, %t66
  store i64 %t69, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  store i64 %t71, ptr %l41, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/typed:dropWalk", ptr %t72, i32 0, i32 2
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t74, i64 %t75)
  store i1 %t78, ptr %l45
  br label %bb15
bb15:
  %t79 = load i1, ptr %l45, !tbaa !21
  %t80 = load ptr, ptr %lp1
  %t81 = load i64, ptr %l41, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i1, ptr %t83, i64 %t81
  store i1 %t79, ptr %t84, !tbaa !31
  br label %bb16
bb16:
  %t85 = load i64, ptr %l6, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l6, !tbaa !24
  br label %bb11
bb17:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/typed:dropWalk", ptr %t89, i32 0, i32 2
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l50
  br label %bb18
bb18:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/typed:dropWalk", ptr %t94, i32 0, i32 3
  %t97 = load i1, ptr %t96, !tbaa !21
  %t99 = load ptr, ptr %lp1
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i1, ptr %t102, i64 %t100
  store i1 %t97, ptr %t103, !tbaa !31
  %t104 = load ptr, ptr %lp1
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l24 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l12
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l11
  br label %bb1
bb1:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  br label %ret
bb4:
  %t13 = load i64, ptr %l7, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/typed:dropWalk", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l14, !tbaa !29
  store i64 %t13, ptr %l15, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = icmp eq ptr %t18, null
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t25 = load ptr, ptr %l20, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 0
  store i1 %t31, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l21, !tbaa !21
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t36, i32 0, i32 0
  %t38 = load %"compiler/source:Span", ptr %t37
  store %"compiler/source:Span" %t38, ptr %l4
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr { i64, [5 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t42, i32 0, i32 1
  %t44 = load i32, ptr %t43
  store i32 %t44, ptr %l5, !tbaa !23
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load i64, ptr %t49
  %t54 = icmp eq i64 %t50, 0
  store i1 %t54, ptr %l24, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l24, !tbaa !21
  %t57 = xor i1 %t56, true
  %t58 = load ptr, ptr %l14, !tbaa !29
  %t59 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t58, i64 %t59, i1 %t57)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l118 = alloca ptr
  %l119 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca i1
  %l135 = alloca ptr
  %l136 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l168 = alloca { i64, ptr }
  %l169 = alloca i64
  %l170 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l177 = alloca i64
  %l178 = alloca { i64, ptr }
  %l186 = alloca ptr
  %l187 = alloca i1
  %l197 = alloca ptr
  %l198 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca i1
  %l217 = alloca ptr
  %l218 = alloca i1
  %l225 = alloca i64
  %l228 = alloca i1
  %l232 = alloca i1
  %l239 = alloca i1
  %l243 = alloca i1
  %l251 = alloca ptr
  %l252 = alloca i1
  %l265 = alloca { i64, ptr }
  %l266 = alloca i64
  %l267 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l280 = alloca { i64, ptr }
  %l281 = alloca i64
  %l282 = alloca { i64, ptr }
  %l292 = alloca ptr
  %l293 = alloca i1
  %l306 = alloca { i64, ptr }
  %s12 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:dropWalk", ptr %t1, i32 0, i32 3
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t7 = load ptr, ptr %l40, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l40, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 17}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l41, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l41, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 1
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l2, !tbaa !23
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t27, ptr %t28)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l2, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %t32, i64 %t35, ptr %t36)
  br label %bb10
bb10:
  br label %bb176
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t42 = load ptr, ptr %l56, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load ptr, ptr %l56, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 17}
  %t48 = icmp eq i64 %t46, 1
  store i1 %t48, ptr %l57, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l57, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 1
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l4, !tbaa !29
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [3 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t58, i32 0, i32 2
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb25
bb16:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  br label %bb17
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  br label %bb18
bb18:
  %t72 = load ptr, ptr %l4, !tbaa !29
  store ptr %t72, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t73 = load ptr, ptr %l70, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t76 = load ptr, ptr %l70, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 8}
  %t79 = icmp eq i64 %t77, 0
  store i1 %t79, ptr %l71, !tbaa !21
  br label %bb20
bb20:
  %t80 = load i1, ptr %l71, !tbaa !21
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l6
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 1
  %t91 = load i32, ptr %t90
  store i32 %t91, ptr %l7, !tbaa !23
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t95, i32 0, i32 2
  %t97 = load i32, ptr %t96
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t102 = sext i32 %t97 to i64
  %t103 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esetLocal(ptr %v0, ptr %v1, ptr %t99, i64 %t102, ptr %t103)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  br label %bb176
bb25:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t109 = load ptr, ptr %l85, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l85, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 2
  store i1 %t115, ptr %l86, !tbaa !21
  br label %bb27
bb27:
  %t116 = load i1, ptr %l86, !tbaa !21
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr }, ptr %t119, i32 0, i32 1
  %t121 = load ptr, ptr %t120
  store ptr %t121, ptr %l9, !tbaa !29
  br label %bb34
bb29:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t124 = load ptr, ptr %l91, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %l91, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 17}
  %t130 = icmp eq i64 %t128, 15
  store i1 %t130, ptr %l92, !tbaa !21
  br label %bb31
bb31:
  %t131 = load i1, ptr %l92, !tbaa !21
  br i1 %t131, label %bb32, label %bb33
bb32:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", ptr }, ptr %t134, i32 0, i32 1
  %t136 = load ptr, ptr %t135
  store ptr %t136, ptr %l9, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t138, ptr %t139)
  br label %bb35
bb35:
  br label %bb176
bb36:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t144 = load ptr, ptr %l100, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb37, label %bb38
bb37:
  %t147 = load ptr, ptr %l100, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 17}
  %t150 = icmp eq i64 %t148, 16
  store i1 %t150, ptr %l101, !tbaa !21
  br label %bb38
bb38:
  %t151 = load i1, ptr %l101, !tbaa !21
  br i1 %t151, label %bb39, label %bb40
bb39:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [3 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", ptr }, ptr %t154, i32 0, i32 1
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l10, !tbaa !29
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t158, ptr %t159)
  br label %bb42
bb42:
  br label %bb176
bb43:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t163 = load ptr, ptr %l108, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb44, label %bb45
bb44:
  %t166 = load ptr, ptr %l108, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 17}
  %t169 = icmp eq i64 %t167, 6
  store i1 %t169, ptr %l109, !tbaa !21
  br label %bb45
bb45:
  %t170 = load i1, ptr %l109, !tbaa !21
  br i1 %t170, label %bb46, label %bb47
bb46:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", ptr }, ptr %t173, i32 0, i32 1
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  br label %bb49
bb49:
  %t181 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %t181, i64 -1)
  br label %bb50
bb50:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/typed:dropWalk", ptr %t183, i32 0, i32 3
  store i1 true, ptr %t185, !tbaa !21
  br label %bb176
bb51:
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l118, !tbaa !29
  store i1 false, ptr %l119, !tbaa !21
  %t187 = load ptr, ptr %l118, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb52, label %bb53
bb52:
  %t190 = load ptr, ptr %l118, !tbaa !29
  %t191 = load i64, ptr %t190, !range !{i64 0, i64 17}
  %t193 = icmp eq i64 %t191, 8
  store i1 %t193, ptr %l119, !tbaa !21
  br label %bb53
bb53:
  %t194 = load i1, ptr %l119, !tbaa !21
  br i1 %t194, label %bb54, label %bb55
bb54:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr { i64, [3 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t197, i32 0, i32 1
  %t199 = load ptr, ptr %t198
  store ptr %t199, ptr %l12, !tbaa !29
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t201, ptr %t202)
  br label %bb57
bb57:
  %t206 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t206, i1 true)
  br label %bb58
bb58:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/typed:dropWalk", ptr %t208, i32 0, i32 3
  store i1 true, ptr %t210, !tbaa !21
  br label %bb176
bb59:
  %t211 = load ptr, ptr %l1, !tbaa !29
  store ptr %t211, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t212 = load ptr, ptr %l129, !tbaa !29
  %t213 = icmp ne ptr %t212, null
  br i1 %t213, label %bb60, label %bb61
bb60:
  %t215 = load ptr, ptr %l129, !tbaa !29
  %t216 = load i64, ptr %t215, !range !{i64 0, i64 17}
  %t218 = icmp eq i64 %t216, 7
  store i1 %t218, ptr %l130, !tbaa !21
  br label %bb61
bb61:
  %t219 = load i1, ptr %l130, !tbaa !21
  br i1 %t219, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t220 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t220, i1 true)
  br label %bb65
bb65:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/typed:dropWalk", ptr %t222, i32 0, i32 3
  store i1 true, ptr %t224, !tbaa !21
  br label %bb176
bb66:
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t226 = load ptr, ptr %l135, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb67, label %bb68
bb67:
  %t229 = load ptr, ptr %l135, !tbaa !29
  %t230 = load i64, ptr %t229, !range !{i64 0, i64 17}
  %t232 = icmp eq i64 %t230, 9
  store i1 %t232, ptr %l136, !tbaa !21
  br label %bb68
bb68:
  %t233 = load i1, ptr %l136, !tbaa !21
  br i1 %t233, label %bb69, label %bb70
bb69:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr { i64, [3 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t236, i32 0, i32 2
  %t238 = load ptr, ptr %t237
  store ptr %t238, ptr %l13, !tbaa !29
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t240, ptr %t241)
  br label %bb72
bb72:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/typed:dropWalk", ptr %t244, i32 0, i32 3
  store i1 true, ptr %t246, !tbaa !21
  br label %bb176
bb73:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t248 = load ptr, ptr %l144, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb74, label %bb75
bb74:
  %t251 = load ptr, ptr %l144, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 10
  store i1 %t254, ptr %l145, !tbaa !21
  br label %bb75
bb75:
  %t255 = load i1, ptr %l145, !tbaa !21
  br i1 %t255, label %bb76, label %bb77
bb76:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l14, !tbaa !29
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [3 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t264, i32 0, i32 2
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l15, !tbaa !29
  br label %bb78
bb77:
  br label %bb81
bb78:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l14, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t268, ptr %t269)
  br label %bb79
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t273, ptr %t274)
  br label %bb80
bb80:
  br label %bb176
bb81:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t278 = load ptr, ptr %l157, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb82, label %bb83
bb82:
  %t281 = load ptr, ptr %l157, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 17}
  %t284 = icmp eq i64 %t282, 3
  store i1 %t284, ptr %l158, !tbaa !21
  br label %bb83
bb83:
  %t285 = load i1, ptr %l158, !tbaa !21
  br i1 %t285, label %bb84, label %bb85
bb84:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [3 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr }, ptr %t288, i32 0, i32 1
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l16, !tbaa !29
  br label %bb86
bb85:
  br label %bb94
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l16, !tbaa !29
  %t295 = getelementptr %"compiler/typed:If", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t292, ptr %t296)
  br label %bb87
bb87:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t300)
  store { i64, ptr } %t302, ptr %l168
  br label %bb88
bb88:
  %t303 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l169, !tbaa !24
  %t305 = load i64, ptr %l169, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l170, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l169, !tbaa !24
  %t315 = mul i64 %t314, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t311, ptr %t313, i64 %t315, i1 false)
  %t316 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t316, ptr %l17, !tbaa !27
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load ptr, ptr %l16, !tbaa !29
  %t320 = getelementptr %"compiler/typed:If", ptr %t318, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t317, ptr %t321)
  br label %bb89
bb89:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s12, ptr %t325)
  store { i64, ptr } %t327, ptr %l176
  br label %bb90
bb90:
  %t328 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  store i64 %t329, ptr %l177, !tbaa !24
  %t330 = load i64, ptr %l177, !tbaa !24
  %t331 = mul i64 %t330, 1
  %t332 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t331)
  %t333 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t334 = insertvalue { i64, ptr } %t333, ptr %t332, 1
  store { i64, ptr } %t334, ptr %l178, !tbaa !27
  %t335 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t336 = load ptr, ptr %t335, !tbaa !27
  %t337 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = load i64, ptr %l177, !tbaa !24
  %t340 = mul i64 %t339, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t336, ptr %t338, i64 %t340, i1 false)
  %t341 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t341, ptr %l18, !tbaa !27
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s12, ptr %t342, { i64, ptr } %t343)
  br label %bb91
bb91:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l16, !tbaa !29
  %t349 = getelementptr %"compiler/typed:If", ptr %t347, i32 0, i32 2
  %t350 = load ptr, ptr %t349, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t346, ptr %t350)
  br label %bb92
bb92:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s12, ptr %t353, { i64, ptr } %t354)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s12)
  br label %bb176
bb94:
  %t357 = load ptr, ptr %l1, !tbaa !29
  store ptr %t357, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t358 = load ptr, ptr %l186, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb95, label %bb96
bb95:
  %t361 = load ptr, ptr %l186, !tbaa !29
  %t362 = load i64, ptr %t361, !range !{i64 0, i64 17}
  %t364 = icmp eq i64 %t362, 4
  store i1 %t364, ptr %l187, !tbaa !21
  br label %bb96
bb96:
  %t365 = load i1, ptr %l187, !tbaa !21
  br i1 %t365, label %bb97, label %bb98
bb97:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = getelementptr { i64, [3 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t368, i32 0, i32 1
  %t370 = load ptr, ptr %t369
  store ptr %t370, ptr %l19, !tbaa !29
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l20, !tbaa !29
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load ptr, ptr %l19, !tbaa !29
  %t380 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v1, ptr %t378, ptr %t379, ptr %t380)
  br label %bb100
bb100:
  br label %bb176
bb101:
  %t384 = load ptr, ptr %l1, !tbaa !29
  store ptr %t384, ptr %l197, !tbaa !29
  store i1 false, ptr %l198, !tbaa !21
  %t385 = load ptr, ptr %l197, !tbaa !29
  %t386 = icmp ne ptr %t385, null
  br i1 %t386, label %bb102, label %bb103
bb102:
  %t388 = load ptr, ptr %l197, !tbaa !29
  %t389 = load i64, ptr %t388, !range !{i64 0, i64 17}
  %t391 = icmp eq i64 %t389, 5
  store i1 %t391, ptr %l198, !tbaa !21
  br label %bb103
bb103:
  %t392 = load i1, ptr %l198, !tbaa !21
  br i1 %t392, label %bb104, label %bb105
bb104:
  %t393 = load ptr, ptr %l1, !tbaa !29
  %t395 = getelementptr { i64, [3 x i64] }, ptr %t393, i32 0, i32 1
  %t396 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t395, i32 0, i32 1
  %t397 = load i32, ptr %t396, !range !{i32 0, i32 2}
  store i32 %t397, ptr %l21
  %t399 = load ptr, ptr %l1, !tbaa !29
  %t401 = getelementptr { i64, [3 x i64] }, ptr %t399, i32 0, i32 1
  %t402 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t401, i32 0, i32 2
  %t403 = load i32, ptr %t402
  store i32 %t403, ptr %l22, !tbaa !23
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load i32, ptr %l21, !range !{i32 0, i32 2}
  %t407 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %t405, i32 %t406, i32 %t407)
  br label %bb107
bb107:
  br label %bb176
bb108:
  %t411 = load ptr, ptr %l1, !tbaa !29
  store ptr %t411, ptr %l208, !tbaa !29
  store i1 false, ptr %l209, !tbaa !21
  %t412 = load ptr, ptr %l208, !tbaa !29
  %t413 = icmp ne ptr %t412, null
  br i1 %t413, label %bb109, label %bb110
bb109:
  %t415 = load ptr, ptr %l208, !tbaa !29
  %t416 = load i64, ptr %t415, !range !{i64 0, i64 17}
  %t418 = icmp eq i64 %t416, 11
  store i1 %t418, ptr %l209, !tbaa !21
  br label %bb110
bb110:
  %t419 = load i1, ptr %l209, !tbaa !21
  br i1 %t419, label %bb111, label %bb112
bb111:
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t422 = getelementptr { i64, [3 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { %"compiler/source:Span", ptr }, ptr %t422, i32 0, i32 1
  %t424 = load ptr, ptr %t423
  store ptr %t424, ptr %l23, !tbaa !29
  br label %bb113
bb112:
  br label %bb115
bb113:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t426, ptr %t427)
  br label %bb114
bb114:
  br label %bb176
bb115:
  %t431 = load ptr, ptr %l1, !tbaa !29
  store ptr %t431, ptr %l217, !tbaa !29
  store i1 false, ptr %l218, !tbaa !21
  %t432 = load ptr, ptr %l217, !tbaa !29
  %t433 = icmp ne ptr %t432, null
  br i1 %t433, label %bb116, label %bb117
bb116:
  %t435 = load ptr, ptr %l217, !tbaa !29
  %t436 = load i64, ptr %t435, !range !{i64 0, i64 17}
  %t438 = icmp eq i64 %t436, 12
  store i1 %t438, ptr %l218, !tbaa !21
  br label %bb117
bb117:
  %t439 = load i1, ptr %l218, !tbaa !21
  br i1 %t439, label %bb118, label %bb119
bb118:
  %t440 = load ptr, ptr %l1, !tbaa !29
  %t442 = getelementptr { i64, [3 x i64] }, ptr %t440, i32 0, i32 1
  %t443 = getelementptr { %"compiler/source:Span", ptr }, ptr %t442, i32 0, i32 1
  %t444 = load ptr, ptr %t443
  store ptr %t444, ptr %l24, !tbaa !29
  br label %bb120
bb119:
  br label %bb139
bb120:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t447 = load ptr, ptr %l24, !tbaa !29
  %t450 = call i64 @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eflagOf(ptr %v0, ptr %v1, ptr %t446, ptr %t447)
  store i64 %t450, ptr %l225
  br label %bb121
bb121:
  %t451 = load i64, ptr %l225, !tbaa !24
  store i64 %t451, ptr %l25, !tbaa !24
  %t452 = load i64, ptr %l25, !tbaa !24
  %t454 = icmp sge i64 %t452, 0
  br i1 %t454, label %bb122, label %bb123
bb122:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/typed:dropWalk", ptr %t456, i32 0, i32 1
  %t459 = load i64, ptr %l25, !tbaa !24
  %t462 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t458, i64 %t459)
  store i1 %t462, ptr %l232
  br label %bb124
bb123:
  store i1 false, ptr %l228, !tbaa !21
  br label %bb125
bb124:
  %t463 = load i1, ptr %l232, !tbaa !21
  %t464 = xor i1 %t463, true
  store i1 %t464, ptr %l228, !tbaa !21
  br label %bb125
bb125:
  %t466 = load i1, ptr %l228, !tbaa !21
  br i1 %t466, label %bb126, label %bb127
bb126:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t469 = getelementptr %"compiler/typed:dropWalk", ptr %t467, i32 0, i32 14
  %t470 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t469, i64 %t470, i1 true)
  br label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb129
bb129:
  %t473 = load i64, ptr %l25, !tbaa !24
  %t475 = icmp sge i64 %t473, 0
  br i1 %t475, label %bb130, label %bb131
bb130:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/typed:dropWalk", ptr %t477, i32 0, i32 1
  %t480 = load i64, ptr %l25, !tbaa !24
  %t483 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t479, i64 %t480)
  store i1 %t483, ptr %l243
  br label %bb132
bb131:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb133
bb132:
  %t484 = load i1, ptr %l243, !tbaa !21
  store i1 %t484, ptr %l239, !tbaa !21
  br label %bb133
bb133:
  %t485 = load i1, ptr %l239, !tbaa !21
  br i1 %t485, label %bb134, label %bb135
bb134:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = getelementptr %"compiler/typed:dropWalk", ptr %t486, i32 0, i32 5
  %t489 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t488, i64 %t489)
  br label %bb136
bb135:
  br label %bb138
bb136:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t494 = getelementptr %"compiler/typed:dropWalk", ptr %t492, i32 0, i32 6
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/typed:dropWalk", ptr %t495, i32 0, i32 4
  %t498 = load i64, ptr %t497, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t494, i64 %t498)
  br label %bb137
bb137:
  br label %bb138
bb138:
  br label %bb176
bb139:
  %t501 = load ptr, ptr %l1, !tbaa !29
  store ptr %t501, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t502 = load ptr, ptr %l251, !tbaa !29
  %t503 = icmp ne ptr %t502, null
  br i1 %t503, label %bb140, label %bb141
bb140:
  %t505 = load ptr, ptr %l251, !tbaa !29
  %t506 = load i64, ptr %t505, !range !{i64 0, i64 17}
  %t508 = icmp eq i64 %t506, 13
  store i1 %t508, ptr %l252, !tbaa !21
  br label %bb141
bb141:
  %t509 = load i1, ptr %l252, !tbaa !21
  br i1 %t509, label %bb142, label %bb143
bb142:
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t512 = getelementptr { i64, [3 x i64] }, ptr %t510, i32 0, i32 1
  %t513 = getelementptr { %"compiler/source:Span", ptr }, ptr %t512, i32 0, i32 1
  %t514 = load ptr, ptr %t513
  store ptr %t514, ptr %l26, !tbaa !29
  br label %bb144
bb143:
  br label %bb161
bb144:
  store %olang.scope zeroinitializer, ptr %s19
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l26, !tbaa !29
  %t519 = getelementptr %"compiler/typed:Join", ptr %t517, i32 0, i32 0
  %t520 = load ptr, ptr %t519, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t516, ptr %t520)
  br label %bb145
bb145:
  %t524 = load ptr, ptr %l26, !tbaa !29
  %t526 = getelementptr %"compiler/typed:Join", ptr %t524, i32 0, i32 1
  %t527 = load i1, ptr %t526, !tbaa !21
  br i1 %t527, label %bb146, label %bb147
bb146:
  %t529 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %t529, i1 true)
  br label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb149
bb149:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s19, ptr %t531)
  store { i64, ptr } %t533, ptr %l265
  br label %bb150
bb150:
  %t534 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 0
  store i64 %t535, ptr %l266, !tbaa !24
  %t536 = load i64, ptr %l266, !tbaa !24
  %t537 = mul i64 %t536, 1
  %t538 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t537)
  %t539 = insertvalue { i64, ptr } undef, i64 %t536, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t538, 1
  store { i64, ptr } %t540, ptr %l267, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = load i64, ptr %l266, !tbaa !24
  %t546 = mul i64 %t545, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t542, ptr %t544, i64 %t546, i1 false)
  %t547 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t547, ptr %l27, !tbaa !27
  %t548 = load ptr, ptr %l26, !tbaa !29
  %t550 = getelementptr %"compiler/typed:Join", ptr %t548, i32 0, i32 2
  %t551 = load { i64, ptr }, ptr %t550, !tbaa !27
  store { i64, ptr } %t551, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t553 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t555 = extractvalue { i64, ptr } %t553, 0
  store i64 %t555, ptr %l30, !tbaa !24
  br label %bb151
bb151:
  store %olang.scope zeroinitializer, ptr %s22
  %t557 = load i64, ptr %l29, !tbaa !24
  %t558 = load i64, ptr %l30, !tbaa !24
  %t561 = icmp slt i64 %t557, %t558
  %t563 = xor i1 %t561, true
  br i1 %t563, label %bb152, label %bb153
bb152:
  call void @__olang_scope_close(ptr %s22)
  br label %bb160
bb153:
  br label %bb154
bb154:
  %t565 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t565, ptr %l276, !tbaa !27
  %t566 = load i64, ptr %l29, !tbaa !24
  %t568 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t569 = load ptr, ptr %t568, !tbaa !27
  %t570 = getelementptr ptr, ptr %t569, i64 %t566
  %t571 = load ptr, ptr %t570, !tbaa !39
  store ptr %t571, ptr %l31, !tbaa !29
  %t573 = load ptr, ptr %l0, !tbaa !29
  %t575 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2esave(ptr %v0, ptr %s22, ptr %t573)
  store { i64, ptr } %t575, ptr %l280
  br label %bb155
bb155:
  %t576 = load { i64, ptr }, ptr %l280, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t576, 0
  store i64 %t577, ptr %l281, !tbaa !24
  %t578 = load i64, ptr %l281, !tbaa !24
  %t579 = mul i64 %t578, 1
  %t580 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t579)
  %t581 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t582 = insertvalue { i64, ptr } %t581, ptr %t580, 1
  store { i64, ptr } %t582, ptr %l282, !tbaa !27
  %t583 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !27
  %t585 = getelementptr { i64, ptr }, ptr %l280, i32 0, i32 1
  %t586 = load ptr, ptr %t585, !tbaa !27
  %t587 = load i64, ptr %l281, !tbaa !24
  %t588 = mul i64 %t587, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t584, ptr %t586, i64 %t588, i1 false)
  %t589 = load { i64, ptr }, ptr %l282, !tbaa !27
  store { i64, ptr } %t589, ptr %l32, !tbaa !27
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2erestore(ptr %v0, ptr %s19, ptr %t590, { i64, ptr } %t591)
  br label %bb156
bb156:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t595 = load ptr, ptr %l31, !tbaa !29
  %t597 = getelementptr %"compiler/typed:Clause", ptr %t595, i32 0, i32 3
  %t598 = load ptr, ptr %t597, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eblock(ptr %v0, ptr %v1, ptr %t594, ptr %t598)
  br label %bb157
bb157:
  %t601 = load ptr, ptr %l0, !tbaa !29
  %t602 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %s22, ptr %t601, { i64, ptr } %t602)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s22)
  br label %bb159
bb159:
  %t605 = load i64, ptr %l29, !tbaa !24
  %t607 = add i64 %t605, 1
  store i64 %t607, ptr %l29, !tbaa !24
  br label %bb151
bb160:
  call void @__olang_scope_close(ptr %s19)
  br label %bb176
bb161:
  %t609 = load ptr, ptr %l1, !tbaa !29
  store ptr %t609, ptr %l292, !tbaa !29
  store i1 false, ptr %l293, !tbaa !21
  %t610 = load ptr, ptr %l292, !tbaa !29
  %t611 = icmp ne ptr %t610, null
  br i1 %t611, label %bb162, label %bb163
bb162:
  %t613 = load ptr, ptr %l292, !tbaa !29
  %t614 = load i64, ptr %t613, !range !{i64 0, i64 17}
  %t616 = icmp eq i64 %t614, 14
  store i1 %t616, ptr %l293, !tbaa !21
  br label %bb163
bb163:
  %t617 = load i1, ptr %l293, !tbaa !21
  br i1 %t617, label %bb164, label %bb165
bb164:
  %t618 = load ptr, ptr %l1, !tbaa !29
  %t620 = getelementptr { i64, [3 x i64] }, ptr %t618, i32 0, i32 1
  %t621 = getelementptr { %"compiler/source:Span", ptr }, ptr %t620, i32 0, i32 1
  %t622 = load ptr, ptr %t621
  store ptr %t622, ptr %l33, !tbaa !29
  br label %bb166
bb165:
  br label %bb175
bb166:
  %t624 = load ptr, ptr %l33, !tbaa !29
  %t626 = getelementptr %"compiler/typed:Spawn", ptr %t624, i32 0, i32 0
  %t627 = load { i64, ptr }, ptr %t626, !tbaa !27
  store { i64, ptr } %t627, ptr %l34, !tbaa !27
  store i64 0, ptr %l35, !tbaa !24
  %t629 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t631 = extractvalue { i64, ptr } %t629, 0
  store i64 %t631, ptr %l36, !tbaa !24
  br label %bb167
bb167:
  %t633 = load i64, ptr %l35, !tbaa !24
  %t634 = load i64, ptr %l36, !tbaa !24
  %t637 = icmp slt i64 %t633, %t634
  %t639 = xor i1 %t637, true
  br i1 %t639, label %bb168, label %bb169
bb168:
  br label %bb173
bb169:
  br label %bb170
bb170:
  %t641 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t641, ptr %l306, !tbaa !27
  %t642 = load i64, ptr %l35, !tbaa !24
  %t644 = getelementptr { i64, ptr }, ptr %l306, i32 0, i32 1
  %t645 = load ptr, ptr %t644, !tbaa !27
  %t646 = getelementptr ptr, ptr %t645, i64 %t642
  %t647 = load ptr, ptr %t646, !tbaa !39
  %t649 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %t649, ptr %t647)
  br label %bb171
bb171:
  br label %bb172
bb172:
  %t653 = load i64, ptr %l35, !tbaa !24
  %t655 = add i64 %t653, 1
  store i64 %t655, ptr %l35, !tbaa !24
  br label %bb167
bb173:
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t658 = load ptr, ptr %l33, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Spawn", ptr %t658, i32 0, i32 1
  %t661 = load ptr, ptr %t660, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexpr(ptr %v0, ptr %v1, ptr %t657, ptr %t661)
  br label %bb174
bb174:
  br label %bb176
bb175:
  call void @__olang_check_failed(ptr @olang_loc_43e833e67406aee2_76f2107f4f2989fe)
  unreachable
bb176:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l20 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/typed:holdWalk", ptr %t5, i32 0, i32 8
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Block", ptr %t8, i32 0, i32 0
  %t11 = load i32, ptr %t10, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t7, i32 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr %"compiler/typed:Block", ptr %t14, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l20, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr ptr, ptr %t35, i64 %t32
  %t37 = load ptr, ptr %t36, !tbaa !39
  %t39 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %t39, ptr %t37)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l3, !tbaa !24
  br label %bb5
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/typed:holdWalk", ptr %t47, i32 0, i32 8
  %t51 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t49)
  %t52 = extractvalue { i32, i32 } %t51, 1
  %t53 = extractvalue { i32, i32 } %t51, 0
  store i32 %t53, ptr %l31
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb13, label %ok.55, !prof !99
ok.55:
  store i32 %t52, ptr %l30
  br label %bb12
bb12:
  %t56 = load i32, ptr %l30, !tbaa !23
  store i32 %t56, ptr %l27, !tbaa !23
  br label %bb20
bb13:
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = icmp eq i32 %t57, 65536
  br i1 %t58, label %bb14, label %bb15
bb14:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ee90b64eb208d194_3ee30fc86ac20510)
  unreachable
bb15:
  %t60 = load i32, ptr %l31, !tbaa !23
  %t61 = icmp eq i32 %t60, 65537
  br i1 %t61, label %bb16, label %bb17
bb16:
  call void @__olang_bang_failed_plain(ptr @olang_loc_adeeaf8d66de5e9_765e2536cff45a05)
  unreachable
bb17:
  %t63 = load i32, ptr %l31, !tbaa !23
  %t64 = icmp eq i32 %t63, 65538
  br i1 %t64, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_735ea97a101db8a9_ef46e9a3f6738c65)
  unreachable
bb19:
  call void @__olang_bang_failed_plain(ptr @olang_loc_720a79c775c6eb2f_4e77fac288b2d7ab)
  unreachable
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb14
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l17, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Clause", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t23, ptr %t27)
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Clause", ptr %t30, i32 0, i32 4
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l8, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t47, ptr %l31, !tbaa !27
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t60 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s4, ptr %t55, ptr %t53)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l37
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s4)
  br label %bb11
bb11:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l7, !tbaa !24
  br label %bb6
bb12:
  br label %bb13
bb13:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb1
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2emix(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l37 = alloca i32
  %l39 = alloca i1
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l12
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb8:
  br label %bb9
bb9:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l24, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %l7, !tbaa !29
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s3, ptr %t34, ptr %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l28
  br label %bb10
bb10:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t41 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t43 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s3, ptr %s3, ptr %t41)
  store { i64, ptr } %t43, ptr %l30
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l24, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %s3, ptr %s3, ptr %t44, { i64, ptr } %t45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l31
  br label %bb12
bb12:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l8
  call void @compiler_2ftyped_2eunion(ptr %s0, ptr %s3, ptr %l2, ptr %l8)
  br label %bb13
bb13:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/typed:holdWalk", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  %t54 = load ptr, ptr %l7, !tbaa !29
  %t56 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t54)
  store i32 %t56, ptr %l37
  br label %bb14
bb14:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = call ptr @__olang_scope_of(ptr %t57, ptr null)
  %t59 = ptrtoint ptr %t58 to i64
  %t61 = inttoptr i64 %t59 to ptr
  %t62 = load ptr, ptr %l35, !tbaa !29
  %t63 = load i32, ptr %l37, !tbaa !23
  %t64 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %t61, ptr %t62, i32 %t63)
  store i1 %t64, ptr %l39
  br label %bb15
bb15:
  %t65 = load i1, ptr %l39, !tbaa !21
  br i1 %t65, label %bb16, label %bb17
bb16:
  call void @compiler_2ftyped_2eunion(ptr %s0, ptr %s3, ptr %l3, ptr %l8)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = add i64 %t68, 1
  store i64 %t70, ptr %l5, !tbaa !24
  br label %bb6
bb21:
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t73, ptr %l45
  br label %bb22
bb22:
  %t74 = load i64, ptr %l45, !tbaa !24
  %t75 = icmp sgt i64 %t74, 0
  br i1 %t75, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %s0, ptr %s0, ptr %t77, ptr %l3, ptr %l2)
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca ptr
  %l64 = alloca i1
  %l70 = alloca ptr
  %l72 = alloca i32
  %l74 = alloca i32
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca ptr
  %l85 = alloca i1
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca ptr
  %l105 = alloca i1
  %l118 = alloca { i64, ptr }
  %l121 = alloca ptr
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l133 = alloca ptr
  %l134 = alloca i1
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca ptr
  %l145 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l150 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca i1
  %l176 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l183 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca ptr
  %l188 = alloca i1
  %l197 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l202 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l207 = alloca ptr
  %l208 = alloca i1
  %l217 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l218 = alloca ptr
  %l222 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l224 = alloca ptr
  %l229 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l231 = alloca ptr
  %l232 = alloca i1
  %l245 = alloca { i64, ptr }
  %l255 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l256 = alloca ptr
  %l257 = alloca i1
  %l264 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l265 = alloca ptr
  %l266 = alloca i1
  %l274 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l283 = alloca { i64, ptr }
  %l297 = alloca { i64, ptr }
  %l300 = alloca ptr
  %l304 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l310 = alloca ptr
  %l311 = alloca i1
  %l318 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l319 = alloca ptr
  %l320 = alloca i1
  %l333 = alloca { i64, ptr }
  %l336 = alloca ptr
  %l337 = alloca i1
  %l345 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l348 = alloca ptr
  %l349 = alloca i1
  %l357 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l44
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %lp2
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l1, !tbaa !29
  store ptr %t12, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t13 = load ptr, ptr %l48, !tbaa !29
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l48, !tbaa !29
  %t17 = load i64, ptr %t16, !range !{i64 0, i64 18}
  %t19 = icmp eq i64 %t17, 2
  store i1 %t19, ptr %l49, !tbaa !21
  br label %bb6
bb6:
  %t20 = load i1, ptr %l49, !tbaa !21
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load ptr, ptr %t24
  store ptr %t25, ptr %l3, !tbaa !29
  br label %bb13
bb8:
  %t27 = load ptr, ptr %l1, !tbaa !29
  store ptr %t27, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t28 = load ptr, ptr %l54, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l54, !tbaa !29
  %t32 = load i64, ptr %t31, !range !{i64 0, i64 18}
  %t34 = icmp eq i64 %t32, 4
  store i1 %t34, ptr %l55, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l55, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l3, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %t42, ptr %t43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l62
  br label %bb14
bb14:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %rv
  br label %ret
bb15:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t49 = load ptr, ptr %l63, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t52 = load ptr, ptr %l63, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l64, !tbaa !21
  br label %bb17
bb17:
  %t56 = load i1, ptr %l64, !tbaa !21
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l4, !tbaa !29
  br label %bb20
bb19:
  br label %bb28
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:holdWalk", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l70, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t67)
  store i32 %t69, ptr %l72
  br label %bb21
bb21:
  %t70 = load ptr, ptr %l70, !tbaa !29
  %t71 = call ptr @__olang_scope_of(ptr %t70, ptr null)
  %t72 = ptrtoint ptr %t71 to i64
  %t74 = inttoptr i64 %t72 to ptr
  %t75 = load ptr, ptr %l70, !tbaa !29
  %t76 = load i32, ptr %l72, !tbaa !23
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t74, ptr %t75, i32 %t76)
  store i32 %t77, ptr %l74
  br label %bb22
bb22:
  %t78 = load i32, ptr %l74, !range !{i32 0, i32 33}
  %t80 = trunc i64 20 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb23, label %bb24
bb23:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l4, !tbaa !29
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %t83, ptr %t84)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l80
  br label %bb25
bb24:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t92 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %t88, ptr %t89)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t92, ptr %l83
  br label %bb26
bb25:
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l77
  br label %bb27
bb26:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l77
  br label %bb27
bb27:
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %rv
  br label %ret
bb28:
  %t96 = load ptr, ptr %l1, !tbaa !29
  store ptr %t96, ptr %l84, !tbaa !29
  store i1 false, ptr %l85, !tbaa !21
  %t97 = load ptr, ptr %l84, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb29, label %bb30
bb29:
  %t100 = load ptr, ptr %l84, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 5
  store i1 %t103, ptr %l85, !tbaa !21
  br label %bb30
bb30:
  %t104 = load i1, ptr %l85, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  %t105 = load ptr, ptr %l1, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l5, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l5, !tbaa !29
  %t114 = getelementptr %"compiler/typed:Promote", ptr %t112, i32 0, i32 0
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %t111, ptr %t115)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l94
  br label %bb34
bb34:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %rv
  br label %ret
bb35:
  %t121 = load ptr, ptr %l1, !tbaa !29
  store ptr %t121, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t122 = load ptr, ptr %l95, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t125 = load ptr, ptr %l95, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 18}
  %t128 = icmp eq i64 %t126, 6
  store i1 %t128, ptr %l96, !tbaa !21
  br label %bb37
bb37:
  %t129 = load i1, ptr %l96, !tbaa !21
  br i1 %t129, label %bb38, label %bb39
bb38:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l6, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l6, !tbaa !29
  %t140 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %t136, ptr %t137)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %l103
  br label %bb41
bb41:
  %t141 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %rv
  br label %ret
bb42:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t143 = load ptr, ptr %l104, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb43, label %bb44
bb43:
  %t146 = load ptr, ptr %l104, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 7
  store i1 %t149, ptr %l105, !tbaa !21
  br label %bb44
bb44:
  %t150 = load i1, ptr %l105, !tbaa !21
  br i1 %t150, label %bb45, label %bb46
bb45:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  br label %bb47
bb46:
  br label %bb57
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Make", ptr %t157, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  store { i64, ptr } %t160, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  store i64 %t164, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t166 = load i64, ptr %l9, !tbaa !24
  %t167 = load i64, ptr %l10, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s8)
  br label %bb55
bb50:
  br label %bb51
bb51:
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t174, ptr %l118, !tbaa !27
  %t175 = load i64, ptr %l9, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr ptr, ptr %t178, i64 %t175
  %t180 = load ptr, ptr %t179, !tbaa !39
  %t182 = load ptr, ptr %lp2
  store ptr %t182, ptr %l121, !tbaa !29
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t188 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %t183, ptr %t180)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %l125
  br label %bb52
bb52:
  %t189 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  %t190 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t189, ptr %t190
  %t191 = load ptr, ptr %l121, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t191, ptr %t190)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s8)
  br label %bb54
bb54:
  %t193 = load i64, ptr %l9, !tbaa !24
  %t195 = add i64 %t193, 1
  store i64 %t195, ptr %l9, !tbaa !24
  br label %bb48
bb55:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load ptr, ptr %l7, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Make", ptr %t198, i32 0, i32 3
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t204 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s6, ptr %t197, ptr %t201)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %l132
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  br label %bb193
bb57:
  %t205 = load ptr, ptr %l1, !tbaa !29
  store ptr %t205, ptr %l133, !tbaa !29
  store i1 false, ptr %l134, !tbaa !21
  %t206 = load ptr, ptr %l133, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb58, label %bb59
bb58:
  %t209 = load ptr, ptr %l133, !tbaa !29
  %t210 = load i64, ptr %t209, !range !{i64 0, i64 18}
  %t212 = icmp eq i64 %t210, 8
  store i1 %t212, ptr %l134, !tbaa !21
  br label %bb59
bb59:
  %t213 = load i1, ptr %l134, !tbaa !21
  br i1 %t213, label %bb60, label %bb61
bb60:
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t216, i32 0, i32 2
  %t218 = load ptr, ptr %t217
  store ptr %t218, ptr %l12, !tbaa !29
  br label %bb62
bb61:
  br label %bb76
bb62:
  store %olang.scope zeroinitializer, ptr %s10
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l12, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Collect", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s10, ptr %t220, ptr %t224)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l142
  br label %bb63
bb63:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/typed:holdWalk", ptr %t228, i32 0, i32 5
  store ptr %t230, ptr %l144, !tbaa !29
  %t231 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s10, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t231, ptr %l145
  br label %bb64
bb64:
  %t232 = load ptr, ptr %l144, !tbaa !29
  %t233 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l145
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s10, ptr %t232, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233)
  br label %bb65
bb65:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load ptr, ptr %l12, !tbaa !29
  %t237 = getelementptr %"compiler/typed:Collect", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t234, ptr %t238)
  br label %bb66
bb66:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/typed:holdWalk", ptr %t242, i32 0, i32 5
  %t246 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcd1867a2c89de03c7af27b93b5b476d9(ptr %v0, ptr %v2, ptr %t244)
  %t247 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t246, 1
  %t248 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t246, 0
  store i32 %t248, ptr %l154
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb68, label %ok.250, !prof !99
ok.250:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %l153
  br label %bb67
bb67:
  %t251 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t251, ptr %l150
  br label %bb75
bb68:
  %t252 = load i32, ptr %l154, !tbaa !23
  %t253 = icmp eq i32 %t252, 65536
  br i1 %t253, label %bb69, label %bb70
bb69:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2fe17ed863e993f3_a4fd95e432e2de7)
  unreachable
bb70:
  %t255 = load i32, ptr %l154, !tbaa !23
  %t256 = icmp eq i32 %t255, 65537
  br i1 %t256, label %bb71, label %bb72
bb71:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2b0ce19cf8abfa0_63d28338a0667b94)
  unreachable
bb72:
  %t258 = load i32, ptr %l154, !tbaa !23
  %t259 = icmp eq i32 %t258, 65538
  br i1 %t259, label %bb73, label %bb74
bb73:
  call void @__olang_bang_failed_plain(ptr @olang_loc_231c306bfae66ae8_f9a103d13bf0009c)
  unreachable
bb74:
  call void @__olang_bang_failed_plain(ptr @olang_loc_60c7f079a8f50056_f0211a32bac11e1a)
  unreachable
bb75:
  %t261 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l150
  %t262 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t261, ptr %t262
  call void @__olang_scope_close(ptr %s10)
  br label %bb193
bb76:
  %t263 = load ptr, ptr %l1, !tbaa !29
  store ptr %t263, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t264 = load ptr, ptr %l158, !tbaa !29
  %t265 = icmp ne ptr %t264, null
  br i1 %t265, label %bb77, label %bb78
bb77:
  %t267 = load ptr, ptr %l158, !tbaa !29
  %t268 = load i64, ptr %t267, !range !{i64 0, i64 18}
  %t270 = icmp eq i64 %t268, 9
  store i1 %t270, ptr %l159, !tbaa !21
  br label %bb78
bb78:
  %t271 = load i1, ptr %l159, !tbaa !21
  br i1 %t271, label %bb79, label %bb80
bb79:
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t274 = getelementptr { i64, [5 x i64] }, ptr %t272, i32 0, i32 1
  %t275 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t274, i32 0, i32 2
  %t276 = load i32, ptr %t275, !range !{i32 0, i32 52}
  store i32 %t276, ptr %l13
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr { i64, [5 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t280, i32 0, i32 4
  %t282 = load { i64, ptr }, ptr %t281
  store { i64, ptr } %t282, ptr %l14, !tbaa !27
  br label %bb81
bb80:
  br label %bb93
bb81:
  %t284 = load i32, ptr %l13, !range !{i32 0, i32 52}
  %t286 = trunc i64 30 to i32
  %t287 = icmp eq i32 %t284, %t286
  br i1 %t287, label %bb82, label %bb83
bb82:
  %t289 = load ptr, ptr %lp2
  %t290 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t289
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %rv
  br label %ret
bb83:
  br label %bb84
bb84:
  %t292 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t292, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t294 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 0
  store i64 %t296, ptr %l17, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s14
  %t298 = load i64, ptr %l16, !tbaa !24
  %t299 = load i64, ptr %l17, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  %t304 = xor i1 %t302, true
  br i1 %t304, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s14)
  br label %bb92
bb87:
  br label %bb88
bb88:
  %t306 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t306, ptr %l176, !tbaa !27
  %t307 = load i64, ptr %l16, !tbaa !24
  %t309 = getelementptr { i64, ptr }, ptr %l176, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr ptr, ptr %t310, i64 %t307
  %t312 = load ptr, ptr %t311, !tbaa !39
  %t314 = load ptr, ptr %lp2
  store ptr %t314, ptr %l179, !tbaa !29
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t320 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %t315, ptr %t312)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t320, ptr %l183
  br label %bb89
bb89:
  %t321 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l183
  %t322 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t321, ptr %t322
  %t323 = load ptr, ptr %l179, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t323, ptr %t322)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s14)
  br label %bb91
bb91:
  %t325 = load i64, ptr %l16, !tbaa !24
  %t327 = add i64 %t325, 1
  store i64 %t327, ptr %l16, !tbaa !24
  br label %bb85
bb92:
  br label %bb193
bb93:
  %t329 = load ptr, ptr %l1, !tbaa !29
  store ptr %t329, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t330 = load ptr, ptr %l187, !tbaa !29
  %t331 = icmp ne ptr %t330, null
  br i1 %t331, label %bb94, label %bb95
bb94:
  %t333 = load ptr, ptr %l187, !tbaa !29
  %t334 = load i64, ptr %t333, !range !{i64 0, i64 18}
  %t336 = icmp eq i64 %t334, 10
  store i1 %t336, ptr %l188, !tbaa !21
  br label %bb95
bb95:
  %t337 = load i1, ptr %l188, !tbaa !21
  br i1 %t337, label %bb96, label %bb97
bb96:
  %t338 = load ptr, ptr %l1, !tbaa !29
  %t340 = getelementptr { i64, [5 x i64] }, ptr %t338, i32 0, i32 1
  %t341 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t340, i32 0, i32 2
  %t342 = load ptr, ptr %t341
  store ptr %t342, ptr %l19, !tbaa !29
  br label %bb98
bb97:
  br label %bb102
bb98:
  store %olang.scope zeroinitializer, ptr %s16
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l19, !tbaa !29
  %t347 = getelementptr %"compiler/typed:Slice", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t352 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s16, ptr %t344, ptr %t348)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t352, ptr %l197
  br label %bb99
bb99:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load ptr, ptr %l19, !tbaa !29
  %t356 = getelementptr %"compiler/typed:Slice", ptr %t354, i32 0, i32 2
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t361 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s16, ptr %t353, ptr %t357)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t361, ptr %l202
  br label %bb100
bb100:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l19, !tbaa !29
  %t365 = getelementptr %"compiler/typed:Slice", ptr %t363, i32 0, i32 0
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t369 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %t362, ptr %t366)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t369, ptr %l206
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s16)
  %t370 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l206
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t370, ptr %rv
  br label %ret
bb102:
  %t371 = load ptr, ptr %l1, !tbaa !29
  store ptr %t371, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t372 = load ptr, ptr %l207, !tbaa !29
  %t373 = icmp ne ptr %t372, null
  br i1 %t373, label %bb103, label %bb104
bb103:
  %t375 = load ptr, ptr %l207, !tbaa !29
  %t376 = load i64, ptr %t375, !range !{i64 0, i64 18}
  %t378 = icmp eq i64 %t376, 11
  store i1 %t378, ptr %l208, !tbaa !21
  br label %bb104
bb104:
  %t379 = load i1, ptr %l208, !tbaa !21
  br i1 %t379, label %bb105, label %bb106
bb105:
  %t380 = load ptr, ptr %l1, !tbaa !29
  %t382 = getelementptr { i64, [5 x i64] }, ptr %t380, i32 0, i32 1
  %t383 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t382, i32 0, i32 2
  %t384 = load ptr, ptr %t383
  store ptr %t384, ptr %l20, !tbaa !29
  br label %bb107
bb106:
  br label %bb113
bb107:
  store %olang.scope zeroinitializer, ptr %s17
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t387 = load ptr, ptr %l20, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Cond", ptr %t387, i32 0, i32 0
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t394 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s17, ptr %t386, ptr %t390)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t394, ptr %l217
  br label %bb108
bb108:
  %t395 = load ptr, ptr %lp2
  store ptr %t395, ptr %l218, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l20, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Cond", ptr %t397, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t403 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %t396, ptr %t400)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t403, ptr %l222
  br label %bb109
bb109:
  %t404 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l222
  %t405 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t404, ptr %t405
  %t406 = load ptr, ptr %l218, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t406, ptr %t405)
  br label %bb110
bb110:
  %t408 = load ptr, ptr %lp2
  store ptr %t408, ptr %l224, !tbaa !29
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t410 = load ptr, ptr %l20, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Cond", ptr %t410, i32 0, i32 2
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t417 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %t409, ptr %t413)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t417, ptr %l229
  br label %bb111
bb111:
  %t418 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l229
  %t419 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t418, ptr %t419
  %t420 = load ptr, ptr %l224, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t420, ptr %t419)
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s17)
  br label %bb193
bb113:
  %t422 = load ptr, ptr %l1, !tbaa !29
  store ptr %t422, ptr %l231, !tbaa !29
  store i1 false, ptr %l232, !tbaa !21
  %t423 = load ptr, ptr %l231, !tbaa !29
  %t424 = icmp ne ptr %t423, null
  br i1 %t424, label %bb114, label %bb115
bb114:
  %t426 = load ptr, ptr %l231, !tbaa !29
  %t427 = load i64, ptr %t426, !range !{i64 0, i64 18}
  %t429 = icmp eq i64 %t427, 12
  store i1 %t429, ptr %l232, !tbaa !21
  br label %bb115
bb115:
  %t430 = load i1, ptr %l232, !tbaa !21
  br i1 %t430, label %bb116, label %bb117
bb116:
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr { i64, [5 x i64] }, ptr %t431, i32 0, i32 1
  %t434 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t433, i32 0, i32 2
  %t435 = load ptr, ptr %t434
  store ptr %t435, ptr %l21, !tbaa !29
  br label %bb118
bb117:
  br label %bb127
bb118:
  %t437 = load ptr, ptr %l21, !tbaa !29
  %t439 = getelementptr %"compiler/typed:Seq", ptr %t437, i32 0, i32 0
  %t440 = load { i64, ptr }, ptr %t439, !tbaa !27
  store { i64, ptr } %t440, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t442 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t442, 0
  store i64 %t444, ptr %l24, !tbaa !24
  br label %bb119
bb119:
  %t446 = load i64, ptr %l23, !tbaa !24
  %t447 = load i64, ptr %l24, !tbaa !24
  %t450 = icmp slt i64 %t446, %t447
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb120, label %bb121
bb120:
  br label %bb125
bb121:
  br label %bb122
bb122:
  %t454 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t454, ptr %l245, !tbaa !27
  %t455 = load i64, ptr %l23, !tbaa !24
  %t457 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !27
  %t459 = getelementptr ptr, ptr %t458, i64 %t455
  %t460 = load ptr, ptr %t459, !tbaa !39
  %t462 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %t462, ptr %t460)
  br label %bb123
bb123:
  br label %bb124
bb124:
  %t466 = load i64, ptr %l23, !tbaa !24
  %t468 = add i64 %t466, 1
  store i64 %t468, ptr %l23, !tbaa !24
  br label %bb119
bb125:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load ptr, ptr %l21, !tbaa !29
  %t473 = getelementptr %"compiler/typed:Seq", ptr %t471, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t477 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %t470, ptr %t474)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t477, ptr %l255
  br label %bb126
bb126:
  %t478 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l255
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t478, ptr %rv
  br label %ret
bb127:
  %t479 = load ptr, ptr %l1, !tbaa !29
  store ptr %t479, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t480 = load ptr, ptr %l256, !tbaa !29
  %t481 = icmp ne ptr %t480, null
  br i1 %t481, label %bb128, label %bb129
bb128:
  %t483 = load ptr, ptr %l256, !tbaa !29
  %t484 = load i64, ptr %t483, !range !{i64 0, i64 18}
  %t486 = icmp eq i64 %t484, 13
  store i1 %t486, ptr %l257, !tbaa !21
  br label %bb129
bb129:
  %t487 = load i1, ptr %l257, !tbaa !21
  br i1 %t487, label %bb130, label %bb131
bb130:
  %t488 = load ptr, ptr %l1, !tbaa !29
  %t490 = getelementptr { i64, [5 x i64] }, ptr %t488, i32 0, i32 1
  %t491 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t490, i32 0, i32 2
  %t492 = load ptr, ptr %t491
  store ptr %t492, ptr %l26, !tbaa !29
  br label %bb132
bb131:
  br label %bb134
bb132:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load ptr, ptr %l26, !tbaa !29
  %t498 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ematch(ptr %v0, ptr %v1, ptr %v2, ptr %t494, ptr %t495)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %l264
  br label %bb133
bb133:
  %t499 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l264
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t499, ptr %rv
  br label %ret
bb134:
  %t500 = load ptr, ptr %l1, !tbaa !29
  store ptr %t500, ptr %l265, !tbaa !29
  store i1 false, ptr %l266, !tbaa !21
  %t501 = load ptr, ptr %l265, !tbaa !29
  %t502 = icmp ne ptr %t501, null
  br i1 %t502, label %bb135, label %bb136
bb135:
  %t504 = load ptr, ptr %l265, !tbaa !29
  %t505 = load i64, ptr %t504, !range !{i64 0, i64 18}
  %t507 = icmp eq i64 %t505, 14
  store i1 %t507, ptr %l266, !tbaa !21
  br label %bb136
bb136:
  %t508 = load i1, ptr %l266, !tbaa !21
  br i1 %t508, label %bb137, label %bb138
bb137:
  %t509 = load ptr, ptr %l1, !tbaa !29
  %t511 = getelementptr { i64, [5 x i64] }, ptr %t509, i32 0, i32 1
  %t512 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t511, i32 0, i32 2
  %t513 = load ptr, ptr %t512
  store ptr %t513, ptr %l27, !tbaa !29
  br label %bb139
bb138:
  br label %bb156
bb139:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load ptr, ptr %l27, !tbaa !29
  %t518 = getelementptr %"compiler/typed:Try", ptr %t516, i32 0, i32 0
  %t519 = load ptr, ptr %t518, !tbaa !29
  %t522 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %t515, ptr %t519)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t522, ptr %l274
  br label %bb140
bb140:
  %t523 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l274
  %t524 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t523, ptr %t524
  %t525 = load ptr, ptr %l27, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Try", ptr %t525, i32 0, i32 1
  %t528 = load { i64, ptr }, ptr %t527, !tbaa !27
  store { i64, ptr } %t528, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t530 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t530, 0
  store i64 %t532, ptr %l30, !tbaa !24
  br label %bb141
bb141:
  %t534 = load i64, ptr %l29, !tbaa !24
  %t535 = load i64, ptr %l30, !tbaa !24
  %t538 = icmp slt i64 %t534, %t535
  %t540 = xor i1 %t538, true
  br i1 %t540, label %bb142, label %bb143
bb142:
  br label %bb155
bb143:
  br label %bb144
bb144:
  %t542 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t542, ptr %l283, !tbaa !27
  %t543 = load i64, ptr %l29, !tbaa !24
  %t545 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t546 = load ptr, ptr %t545, !tbaa !27
  %t547 = getelementptr ptr, ptr %t546, i64 %t543
  %t548 = load ptr, ptr %t547, !tbaa !39
  store ptr %t548, ptr %l31, !tbaa !29
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load ptr, ptr %l31, !tbaa !29
  %t553 = getelementptr %"compiler/typed:Clause", ptr %t551, i32 0, i32 3
  %t554 = load ptr, ptr %t553, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t550, ptr %t554)
  br label %bb145
bb145:
  %t557 = load ptr, ptr %l31, !tbaa !29
  %t559 = getelementptr %"compiler/typed:Clause", ptr %t557, i32 0, i32 4
  %t560 = load { i64, ptr }, ptr %t559, !tbaa !27
  store { i64, ptr } %t560, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t562 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t562, 0
  store i64 %t564, ptr %l34, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s27
  %t566 = load i64, ptr %l33, !tbaa !24
  %t567 = load i64, ptr %l34, !tbaa !24
  %t570 = icmp slt i64 %t566, %t567
  %t572 = xor i1 %t570, true
  br i1 %t572, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s27)
  br label %bb153
bb148:
  br label %bb149
bb149:
  %t574 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t574, ptr %l297, !tbaa !27
  %t575 = load i64, ptr %l33, !tbaa !24
  %t577 = getelementptr { i64, ptr }, ptr %l297, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr ptr, ptr %t578, i64 %t575
  %t580 = load ptr, ptr %t579, !tbaa !39
  %t582 = load ptr, ptr %lp2
  store ptr %t582, ptr %l300, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t588 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v0, ptr %t583, ptr %t580)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t588, ptr %l304
  br label %bb150
bb150:
  %t589 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l304
  %t590 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t589, ptr %t590
  %t591 = load ptr, ptr %l300, !tbaa !29
  call void @compiler_2ftyped_2eunion(ptr %v2, ptr %v0, ptr %t591, ptr %t590)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s27)
  br label %bb152
bb152:
  %t593 = load i64, ptr %l33, !tbaa !24
  %t595 = add i64 %t593, 1
  store i64 %t595, ptr %l33, !tbaa !24
  br label %bb146
bb153:
  br label %bb154
bb154:
  %t597 = load i64, ptr %l29, !tbaa !24
  %t599 = add i64 %t597, 1
  store i64 %t599, ptr %l29, !tbaa !24
  br label %bb141
bb155:
  br label %bb193
bb156:
  %t601 = load ptr, ptr %l1, !tbaa !29
  store ptr %t601, ptr %l310, !tbaa !29
  store i1 false, ptr %l311, !tbaa !21
  %t602 = load ptr, ptr %l310, !tbaa !29
  %t603 = icmp ne ptr %t602, null
  br i1 %t603, label %bb157, label %bb158
bb157:
  %t605 = load ptr, ptr %l310, !tbaa !29
  %t606 = load i64, ptr %t605, !range !{i64 0, i64 18}
  %t608 = icmp eq i64 %t606, 15
  store i1 %t608, ptr %l311, !tbaa !21
  br label %bb158
bb158:
  %t609 = load i1, ptr %l311, !tbaa !21
  br i1 %t609, label %bb159, label %bb160
bb159:
  %t610 = load ptr, ptr %l1, !tbaa !29
  %t612 = getelementptr { i64, [5 x i64] }, ptr %t610, i32 0, i32 1
  %t613 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t612, i32 0, i32 2
  %t614 = load ptr, ptr %t613
  store ptr %t614, ptr %l36, !tbaa !29
  br label %bb161
bb160:
  br label %bb163
bb161:
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t617 = load ptr, ptr %l36, !tbaa !29
  %t620 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2efnVal(ptr %v0, ptr %v1, ptr %v2, ptr %t616, ptr %t617)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t620, ptr %l318
  br label %bb162
bb162:
  %t621 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t621, ptr %rv
  br label %ret
bb163:
  %t622 = load ptr, ptr %l1, !tbaa !29
  store ptr %t622, ptr %l319, !tbaa !29
  store i1 false, ptr %l320, !tbaa !21
  %t623 = load ptr, ptr %l319, !tbaa !29
  %t624 = icmp ne ptr %t623, null
  br i1 %t624, label %bb164, label %bb165
bb164:
  %t626 = load ptr, ptr %l319, !tbaa !29
  %t627 = load i64, ptr %t626, !range !{i64 0, i64 18}
  %t629 = icmp eq i64 %t627, 16
  store i1 %t629, ptr %l320, !tbaa !21
  br label %bb165
bb165:
  %t630 = load i1, ptr %l320, !tbaa !21
  br i1 %t630, label %bb166, label %bb167
bb166:
  %t631 = load ptr, ptr %l1, !tbaa !29
  %t633 = getelementptr { i64, [5 x i64] }, ptr %t631, i32 0, i32 1
  %t634 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t633, i32 0, i32 2
  %t635 = load ptr, ptr %t634
  store ptr %t635, ptr %l37, !tbaa !29
  br label %bb168
bb167:
  br label %bb181
bb168:
  %t637 = load ptr, ptr %l37, !tbaa !29
  %t639 = getelementptr %"compiler/typed:Text", ptr %t637, i32 0, i32 0
  %t640 = load { i64, ptr }, ptr %t639, !tbaa !27
  store { i64, ptr } %t640, ptr %l38, !tbaa !27
  store i64 0, ptr %l39, !tbaa !24
  %t642 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t644 = extractvalue { i64, ptr } %t642, 0
  store i64 %t644, ptr %l40, !tbaa !24
  br label %bb169
bb169:
  %t646 = load i64, ptr %l39, !tbaa !24
  %t647 = load i64, ptr %l40, !tbaa !24
  %t650 = icmp slt i64 %t646, %t647
  %t652 = xor i1 %t650, true
  br i1 %t652, label %bb170, label %bb171
bb170:
  br label %bb180
bb171:
  br label %bb172
bb172:
  %t654 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t654, ptr %l333, !tbaa !27
  %t655 = load i64, ptr %l39, !tbaa !24
  %t657 = getelementptr { i64, ptr }, ptr %l333, i32 0, i32 1
  %t658 = load ptr, ptr %t657, !tbaa !27
  %t659 = getelementptr ptr, ptr %t658, i64 %t655
  %t660 = load ptr, ptr %t659, !tbaa !39
  store ptr %t660, ptr %l41, !tbaa !29
  %t662 = load ptr, ptr %l41, !tbaa !29
  store ptr %t662, ptr %l336, !tbaa !29
  store i1 false, ptr %l337, !tbaa !21
  %t663 = load ptr, ptr %l336, !tbaa !29
  %t664 = icmp ne ptr %t663, null
  br i1 %t664, label %bb173, label %bb174
bb173:
  %t666 = load ptr, ptr %l336, !tbaa !29
  %t667 = load i64, ptr %t666, !range !{i64 0, i64 2}
  %t669 = icmp eq i64 %t667, 1
  store i1 %t669, ptr %l337, !tbaa !21
  br label %bb174
bb174:
  %t670 = load i1, ptr %l337, !tbaa !21
  br i1 %t670, label %bb175, label %bb176
bb175:
  store %olang.scope zeroinitializer, ptr %s34
  %t671 = load ptr, ptr %l41, !tbaa !29
  %t673 = getelementptr { i64, [2 x i64] }, ptr %t671, i32 0, i32 1
  %t674 = getelementptr { ptr }, ptr %t673, i32 0, i32 0
  %t675 = load ptr, ptr %t674
  %t677 = load ptr, ptr %l0, !tbaa !29
  %t682 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s34, ptr %t677, ptr %t675)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t682, ptr %l345
  br label %bb177
bb176:
  br label %bb178
bb177:
  call void @__olang_scope_close(ptr %s34)
  br label %bb178
bb178:
  br label %bb179
bb179:
  %t683 = load i64, ptr %l39, !tbaa !24
  %t685 = add i64 %t683, 1
  store i64 %t685, ptr %l39, !tbaa !24
  br label %bb169
bb180:
  br label %bb193
bb181:
  %t687 = load ptr, ptr %l1, !tbaa !29
  store ptr %t687, ptr %l348, !tbaa !29
  store i1 false, ptr %l349, !tbaa !21
  %t688 = load ptr, ptr %l348, !tbaa !29
  %t689 = icmp ne ptr %t688, null
  br i1 %t689, label %bb182, label %bb183
bb182:
  %t691 = load ptr, ptr %l348, !tbaa !29
  %t692 = load i64, ptr %t691, !range !{i64 0, i64 18}
  %t694 = icmp eq i64 %t692, 17
  store i1 %t694, ptr %l349, !tbaa !21
  br label %bb183
bb183:
  %t695 = load i1, ptr %l349, !tbaa !21
  br i1 %t695, label %bb184, label %bb185
bb184:
  %t696 = load ptr, ptr %l1, !tbaa !29
  %t698 = getelementptr { i64, [5 x i64] }, ptr %t696, i32 0, i32 1
  %t699 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t698, i32 0, i32 2
  %t700 = load ptr, ptr %t699
  store ptr %t700, ptr %l43, !tbaa !29
  br label %bb186
bb185:
  br label %bb188
bb186:
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = load ptr, ptr %l43, !tbaa !29
  %t707 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %t702, ptr %t703)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t707, ptr %l357
  br label %bb187
bb187:
  %t708 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l357
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t708, ptr %rv
  br label %ret
bb188:
  br i1 true, label %bb189, label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb192
bb191:
  br label %bb193
bb192:
  call void @__olang_check_failed(ptr @olang_loc_7e259cde601a72ba_d3d8f3b52bf79a7e)
  unreachable
bb193:
  %t709 = load ptr, ptr %lp2
  %t710 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t709
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t710, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca ptr
  %l39 = alloca i1
  %l51 = alloca i1
  %l56 = alloca ptr
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca ptr
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l80 = alloca i1
  %l90 = alloca i1
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l124 = alloca ptr
  %l125 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca i1
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca ptr
  %l141 = alloca i1
  %l151 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca ptr
  %l156 = alloca i1
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca ptr
  %l174 = alloca i1
  %l186 = alloca ptr
  %l187 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l207 = alloca ptr
  %l208 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %l222 = alloca ptr
  %l223 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l245 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l254 = alloca { i64, ptr }
  %l260 = alloca ptr
  %l263 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l276 = alloca { i64, ptr }
  %l282 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l285 = alloca ptr
  %l286 = alloca i1
  %l294 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l297 = alloca i64
  %l299 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l302 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l303 = alloca i32
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t2 = load ptr, ptr %l38, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l38, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l39, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l39, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t24, i32 0, i32 2
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb14
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t33 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i1 %t33, ptr %l51
  br label %bb6
bb6:
  %t34 = load i1, ptr %l51, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t38 = sext i32 %t36 to i64
  %t39 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %t35, i64 %t38, %"compiler/source:Span" %t39)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l56, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %s1, i64 %t46)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l59
  br label %bb11
bb11:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  %t50 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %t50
  store ptr %t50, ptr %l60, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t56 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s1, ptr %t51, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l64
  br label %bb12
bb12:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  %t58 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %t58
  %t59 = load ptr, ptr %l56, !tbaa !29
  %t60 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %t59, ptr %t60, ptr %t58)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb166
bb14:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t63 = load ptr, ptr %l66, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t66 = load ptr, ptr %l66, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 17}
  %t69 = icmp eq i64 %t67, 1
  store i1 %t69, ptr %l67, !tbaa !21
  br label %bb16
bb16:
  %t70 = load i1, ptr %l67, !tbaa !21
  br i1 %t70, label %bb17, label %bb18
bb17:
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = getelementptr { i64, [3 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t73, i32 0, i32 0
  %t75 = load %"compiler/source:Span", ptr %t74
  store %"compiler/source:Span" %t75, ptr %l5
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t79, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  store ptr %t81, ptr %l6, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [3 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l7, !tbaa !29
  br label %bb19
bb18:
  br label %bb44
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t89 = load ptr, ptr %l6, !tbaa !29
  store ptr %t89, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t90 = load ptr, ptr %l76, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb20, label %bb21
bb20:
  %t93 = load ptr, ptr %l76, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 0
  store i1 %t96, ptr %l77, !tbaa !21
  br label %bb21
bb21:
  %t97 = load i1, ptr %l77, !tbaa !21
  br i1 %t97, label %bb22, label %bb23
bb22:
  %t98 = load ptr, ptr %l6, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t100, i32 0, i32 0
  %t102 = load %"compiler/source:Span", ptr %t101
  store %"compiler/source:Span" %t102, ptr %l8
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr { i64, [4 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t106, i32 0, i32 1
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l9, !tbaa !23
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = getelementptr { i64, [4 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t112, i32 0, i32 2
  %t114 = load i32, ptr %t113
  store i32 %t114, ptr %l10, !tbaa !23
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t121 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %t116, ptr %t117)
  store i1 %t121, ptr %l90
  br label %bb24
bb23:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb25
bb24:
  %t122 = load i1, ptr %l90, !tbaa !21
  store i1 %t122, ptr %l80, !tbaa !21
  br label %bb25
bb25:
  %t123 = load i1, ptr %l80, !tbaa !21
  br i1 %t123, label %bb26, label %bb27
bb26:
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t126, i32 0, i32 0
  %t128 = load %"compiler/source:Span", ptr %t127
  store %"compiler/source:Span" %t128, ptr %l11
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t132, i32 0, i32 1
  %t134 = load i32, ptr %t133
  store i32 %t134, ptr %l12, !tbaa !23
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t138 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  %t139 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t138, i32 0, i32 2
  %t140 = load i32, ptr %t139
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t145 = sext i32 %t140 to i64
  %t146 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %t142, i64 %t145, %"compiler/source:Span" %t146)
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t154 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %s3, ptr %t150, ptr %t151)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l103
  br label %bb30
bb30:
  %t155 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t155, ptr %l14
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/typed:holdWalk", ptr %t156, i32 0, i32 4
  store ptr %t158, ptr %l105, !tbaa !29
  %t160 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s3, ptr %s3, ptr %l14)
  store { i64, ptr } %t160, ptr %l107
  br label %bb31
bb31:
  %t161 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t162 = load ptr, ptr %l105, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %t162, { i64, ptr } %t161)
  br label %bb32
bb32:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load ptr, ptr %l7, !tbaa !29
  %t169 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s3, ptr %t164, ptr %t165)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l112
  br label %bb33
bb33:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l15
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/typed:holdWalk", ptr %t171, i32 0, i32 4
  %t175 = call { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePop_3cArray_3cI64_3e_3e(ptr %v0, ptr %s3, ptr %t173)
  %t176 = extractvalue { i32, { i64, ptr } } %t175, 1
  %t177 = extractvalue { i32, { i64, ptr } } %t175, 0
  store i32 %t177, ptr %l117
  %t178 = icmp ne i32 %t177, 0
  br i1 %t178, label %bb35, label %ok.179, !prof !99
ok.179:
  store { i64, ptr } %t176, ptr %l116
  br label %bb34
bb34:
  %t180 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t180, ptr %l113, !tbaa !27
  br label %bb42
bb35:
  %t181 = load i32, ptr %l117, !tbaa !23
  %t182 = icmp eq i32 %t181, 65536
  br i1 %t182, label %bb36, label %bb37
bb36:
  call void @__olang_bang_failed_plain(ptr @olang_loc_96ed7c0737fb007f_bcf36b4956f76d4b)
  unreachable
bb37:
  %t184 = load i32, ptr %l117, !tbaa !23
  %t185 = icmp eq i32 %t184, 65537
  br i1 %t185, label %bb38, label %bb39
bb38:
  call void @__olang_bang_failed_plain(ptr @olang_loc_eee80033d1164c3c_3495c4b80935428)
  unreachable
bb39:
  %t187 = load i32, ptr %l117, !tbaa !23
  %t188 = icmp eq i32 %t187, 65538
  br i1 %t188, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_d52aab1c9c36d4_17087f4c711c4240)
  unreachable
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_fe54fd99e9902812_25d1b4e50c46612e)
  unreachable
bb42:
  %t190 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %s3, ptr %s3, ptr %t190, ptr %l14, ptr %l15)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb166
bb44:
  %t194 = load ptr, ptr %l1, !tbaa !29
  store ptr %t194, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t195 = load ptr, ptr %l124, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb45, label %bb46
bb45:
  %t198 = load ptr, ptr %l124, !tbaa !29
  %t199 = load i64, ptr %t198, !range !{i64 0, i64 17}
  %t201 = icmp eq i64 %t199, 2
  store i1 %t201, ptr %l125, !tbaa !21
  br label %bb46
bb46:
  %t202 = load i1, ptr %l125, !tbaa !21
  br i1 %t202, label %bb47, label %bb48
bb47:
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr { i64, [3 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l16, !tbaa !29
  br label %bb53
bb48:
  %t209 = load ptr, ptr %l1, !tbaa !29
  store ptr %t209, ptr %l130, !tbaa !29
  store i1 false, ptr %l131, !tbaa !21
  %t210 = load ptr, ptr %l130, !tbaa !29
  %t211 = icmp ne ptr %t210, null
  br i1 %t211, label %bb49, label %bb50
bb49:
  %t213 = load ptr, ptr %l130, !tbaa !29
  %t214 = load i64, ptr %t213, !range !{i64 0, i64 17}
  %t216 = icmp eq i64 %t214, 8
  store i1 %t216, ptr %l131, !tbaa !21
  br label %bb50
bb50:
  %t217 = load i1, ptr %l131, !tbaa !21
  br i1 %t217, label %bb51, label %bb52
bb51:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr { i64, [3 x i64] }, ptr %t218, i32 0, i32 1
  %t221 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t220, i32 0, i32 1
  %t222 = load ptr, ptr %t221
  store ptr %t222, ptr %l16, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  store %olang.scope zeroinitializer, ptr %s5
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load ptr, ptr %l16, !tbaa !29
  %t229 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s5, ptr %t224, ptr %t225)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %l139
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb166
bb55:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t231 = load ptr, ptr %l140, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb56, label %bb57
bb56:
  %t234 = load ptr, ptr %l140, !tbaa !29
  %t235 = load i64, ptr %t234, !range !{i64 0, i64 17}
  %t237 = icmp eq i64 %t235, 10
  store i1 %t237, ptr %l141, !tbaa !21
  br label %bb57
bb57:
  %t238 = load i1, ptr %l141, !tbaa !21
  br i1 %t238, label %bb58, label %bb59
bb58:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [3 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t241, i32 0, i32 1
  %t243 = load ptr, ptr %t242
  store ptr %t243, ptr %l17, !tbaa !29
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [3 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l18, !tbaa !29
  br label %bb60
bb59:
  br label %bb63
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l17, !tbaa !29
  %t256 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s6, ptr %t251, ptr %t252)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l151
  br label %bb61
bb61:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l18, !tbaa !29
  %t261 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s6, ptr %t257, ptr %t258)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t261, ptr %l154
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s6)
  br label %bb166
bb63:
  %t262 = load ptr, ptr %l1, !tbaa !29
  store ptr %t262, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t263 = load ptr, ptr %l155, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb64, label %bb65
bb64:
  %t266 = load ptr, ptr %l155, !tbaa !29
  %t267 = load i64, ptr %t266, !range !{i64 0, i64 17}
  %t269 = icmp eq i64 %t267, 3
  store i1 %t269, ptr %l156, !tbaa !21
  br label %bb65
bb65:
  %t270 = load i1, ptr %l156, !tbaa !21
  br i1 %t270, label %bb66, label %bb67
bb66:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr { i64, [3 x i64] }, ptr %t271, i32 0, i32 1
  %t274 = getelementptr { %"compiler/source:Span", ptr }, ptr %t273, i32 0, i32 1
  %t275 = load ptr, ptr %t274
  store ptr %t275, ptr %l19, !tbaa !29
  br label %bb68
bb67:
  br label %bb72
bb68:
  store %olang.scope zeroinitializer, ptr %s7
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load ptr, ptr %l19, !tbaa !29
  %t280 = getelementptr %"compiler/typed:If", ptr %t278, i32 0, i32 0
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t285 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s7, ptr %t277, ptr %t281)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t285, ptr %l165
  br label %bb69
bb69:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t287 = load ptr, ptr %l19, !tbaa !29
  %t289 = getelementptr %"compiler/typed:If", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t286, ptr %t290)
  br label %bb70
bb70:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load ptr, ptr %l19, !tbaa !29
  %t297 = getelementptr %"compiler/typed:If", ptr %t295, i32 0, i32 2
  %t298 = load ptr, ptr %t297, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t294, ptr %t298)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb166
bb72:
  %t301 = load ptr, ptr %l1, !tbaa !29
  store ptr %t301, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t302 = load ptr, ptr %l173, !tbaa !29
  %t303 = icmp ne ptr %t302, null
  br i1 %t303, label %bb73, label %bb74
bb73:
  %t305 = load ptr, ptr %l173, !tbaa !29
  %t306 = load i64, ptr %t305, !range !{i64 0, i64 17}
  %t308 = icmp eq i64 %t306, 4
  store i1 %t308, ptr %l174, !tbaa !21
  br label %bb74
bb74:
  %t309 = load i1, ptr %l174, !tbaa !21
  br i1 %t309, label %bb75, label %bb76
bb75:
  %t310 = load ptr, ptr %l1, !tbaa !29
  %t312 = getelementptr { i64, [3 x i64] }, ptr %t310, i32 0, i32 1
  %t313 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t312, i32 0, i32 1
  %t314 = load ptr, ptr %t313
  store ptr %t314, ptr %l20, !tbaa !29
  %t316 = load ptr, ptr %l1, !tbaa !29
  %t318 = getelementptr { i64, [3 x i64] }, ptr %t316, i32 0, i32 1
  %t319 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t318, i32 0, i32 2
  %t320 = load ptr, ptr %t319
  store ptr %t320, ptr %l21, !tbaa !29
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t322, ptr %t323)
  br label %bb78
bb78:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t327, ptr %t328)
  br label %bb79
bb79:
  br label %bb166
bb80:
  %t331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t331, ptr %l186, !tbaa !29
  store i1 false, ptr %l187, !tbaa !21
  %t332 = load ptr, ptr %l186, !tbaa !29
  %t333 = icmp ne ptr %t332, null
  br i1 %t333, label %bb81, label %bb82
bb81:
  %t335 = load ptr, ptr %l186, !tbaa !29
  %t336 = load i64, ptr %t335, !range !{i64 0, i64 17}
  %t338 = icmp eq i64 %t336, 6
  store i1 %t338, ptr %l187, !tbaa !21
  br label %bb82
bb82:
  %t339 = load i1, ptr %l187, !tbaa !21
  br i1 %t339, label %bb83, label %bb84
bb83:
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [3 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", ptr }, ptr %t342, i32 0, i32 1
  %t344 = load ptr, ptr %t343
  store ptr %t344, ptr %l22, !tbaa !29
  br label %bb93
bb84:
  %t346 = load ptr, ptr %l1, !tbaa !29
  store ptr %t346, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t347 = load ptr, ptr %l192, !tbaa !29
  %t348 = icmp ne ptr %t347, null
  br i1 %t348, label %bb85, label %bb86
bb85:
  %t350 = load ptr, ptr %l192, !tbaa !29
  %t351 = load i64, ptr %t350, !range !{i64 0, i64 17}
  %t353 = icmp eq i64 %t351, 16
  store i1 %t353, ptr %l193, !tbaa !21
  br label %bb86
bb86:
  %t354 = load i1, ptr %l193, !tbaa !21
  br i1 %t354, label %bb87, label %bb88
bb87:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr { i64, [3 x i64] }, ptr %t355, i32 0, i32 1
  %t358 = getelementptr { %"compiler/source:Span", ptr }, ptr %t357, i32 0, i32 1
  %t359 = load ptr, ptr %t358
  store ptr %t359, ptr %l22, !tbaa !29
  br label %bb93
bb88:
  %t361 = load ptr, ptr %l1, !tbaa !29
  store ptr %t361, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t362 = load ptr, ptr %l198, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb89, label %bb90
bb89:
  %t365 = load ptr, ptr %l198, !tbaa !29
  %t366 = load i64, ptr %t365, !range !{i64 0, i64 17}
  %t368 = icmp eq i64 %t366, 9
  store i1 %t368, ptr %l199, !tbaa !21
  br label %bb90
bb90:
  %t369 = load i1, ptr %l199, !tbaa !21
  br i1 %t369, label %bb91, label %bb92
bb91:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr { i64, [3 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t372, i32 0, i32 2
  %t374 = load ptr, ptr %t373
  store ptr %t374, ptr %l22, !tbaa !29
  br label %bb93
bb92:
  br label %bb95
bb93:
  store %olang.scope zeroinitializer, ptr %s9
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load ptr, ptr %l22, !tbaa !29
  %t380 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s9, ptr %t376, ptr %t377)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l206
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s9)
  br label %bb166
bb95:
  %t381 = load ptr, ptr %l1, !tbaa !29
  store ptr %t381, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t382 = load ptr, ptr %l207, !tbaa !29
  %t383 = icmp ne ptr %t382, null
  br i1 %t383, label %bb96, label %bb97
bb96:
  %t385 = load ptr, ptr %l207, !tbaa !29
  %t386 = load i64, ptr %t385, !range !{i64 0, i64 17}
  %t388 = icmp eq i64 %t386, 11
  store i1 %t388, ptr %l208, !tbaa !21
  br label %bb97
bb97:
  %t389 = load i1, ptr %l208, !tbaa !21
  br i1 %t389, label %bb98, label %bb99
bb98:
  %t390 = load ptr, ptr %l1, !tbaa !29
  %t392 = getelementptr { i64, [3 x i64] }, ptr %t390, i32 0, i32 1
  %t393 = getelementptr { %"compiler/source:Span", ptr }, ptr %t392, i32 0, i32 1
  %t394 = load ptr, ptr %t393
  store ptr %t394, ptr %l23, !tbaa !29
  br label %bb104
bb99:
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t397 = load ptr, ptr %l213, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb100, label %bb101
bb100:
  %t400 = load ptr, ptr %l213, !tbaa !29
  %t401 = load i64, ptr %t400, !range !{i64 0, i64 17}
  %t403 = icmp eq i64 %t401, 12
  store i1 %t403, ptr %l214, !tbaa !21
  br label %bb101
bb101:
  %t404 = load i1, ptr %l214, !tbaa !21
  br i1 %t404, label %bb102, label %bb103
bb102:
  %t405 = load ptr, ptr %l1, !tbaa !29
  %t407 = getelementptr { i64, [3 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", ptr }, ptr %t407, i32 0, i32 1
  %t409 = load ptr, ptr %t408
  store ptr %t409, ptr %l23, !tbaa !29
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load ptr, ptr %l23, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t411, ptr %t412)
  br label %bb105
bb105:
  br label %bb166
bb106:
  %t416 = load ptr, ptr %l1, !tbaa !29
  store ptr %t416, ptr %l222, !tbaa !29
  store i1 false, ptr %l223, !tbaa !21
  %t417 = load ptr, ptr %l222, !tbaa !29
  %t418 = icmp ne ptr %t417, null
  br i1 %t418, label %bb107, label %bb108
bb107:
  %t420 = load ptr, ptr %l222, !tbaa !29
  %t421 = load i64, ptr %t420, !range !{i64 0, i64 17}
  %t423 = icmp eq i64 %t421, 13
  store i1 %t423, ptr %l223, !tbaa !21
  br label %bb108
bb108:
  %t424 = load i1, ptr %l223, !tbaa !21
  br i1 %t424, label %bb109, label %bb110
bb109:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t427 = getelementptr { i64, [3 x i64] }, ptr %t425, i32 0, i32 1
  %t428 = getelementptr { %"compiler/source:Span", ptr }, ptr %t427, i32 0, i32 1
  %t429 = load ptr, ptr %t428
  store ptr %t429, ptr %l24, !tbaa !29
  br label %bb111
bb110:
  br label %bb114
bb111:
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t432 = load ptr, ptr %l24, !tbaa !29
  %t434 = getelementptr %"compiler/typed:Join", ptr %t432, i32 0, i32 0
  %t435 = load ptr, ptr %t434, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eblock(ptr %v0, ptr %v1, ptr %t431, ptr %t435)
  br label %bb112
bb112:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load ptr, ptr %l24, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Join", ptr %t440, i32 0, i32 2
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclauses(ptr %v0, ptr %v1, ptr %t439, { i64, ptr } %t443)
  br label %bb113
bb113:
  br label %bb166
bb114:
  %t446 = load ptr, ptr %l1, !tbaa !29
  store ptr %t446, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t447 = load ptr, ptr %l235, !tbaa !29
  %t448 = icmp ne ptr %t447, null
  br i1 %t448, label %bb115, label %bb116
bb115:
  %t450 = load ptr, ptr %l235, !tbaa !29
  %t451 = load i64, ptr %t450, !range !{i64 0, i64 17}
  %t453 = icmp eq i64 %t451, 14
  store i1 %t453, ptr %l236, !tbaa !21
  br label %bb116
bb116:
  %t454 = load i1, ptr %l236, !tbaa !21
  br i1 %t454, label %bb117, label %bb118
bb117:
  %t455 = load ptr, ptr %l1, !tbaa !29
  %t457 = getelementptr { i64, [3 x i64] }, ptr %t455, i32 0, i32 1
  %t458 = getelementptr { %"compiler/source:Span", ptr }, ptr %t457, i32 0, i32 1
  %t459 = load ptr, ptr %t458
  store ptr %t459, ptr %l25, !tbaa !29
  br label %bb119
bb118:
  br label %bb139
bb119:
  store %olang.scope zeroinitializer, ptr %s12
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load ptr, ptr %l25, !tbaa !29
  %t464 = getelementptr %"compiler/typed:Spawn", ptr %t462, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t469 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s12, ptr %t461, ptr %t465)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t469, ptr %l245
  br label %bb120
bb120:
  %t470 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l245
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t470, ptr %l26
  %t471 = load ptr, ptr %l25, !tbaa !29
  %t473 = getelementptr %"compiler/typed:Spawn", ptr %t471, i32 0, i32 0
  %t474 = load { i64, ptr }, ptr %t473, !tbaa !27
  store { i64, ptr } %t474, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t478 = extractvalue { i64, ptr } %t476, 0
  store i64 %t478, ptr %l29, !tbaa !24
  br label %bb121
bb121:
  %t480 = load i64, ptr %l28, !tbaa !24
  %t481 = load i64, ptr %l29, !tbaa !24
  %t484 = icmp slt i64 %t480, %t481
  %t486 = xor i1 %t484, true
  br i1 %t486, label %bb122, label %bb123
bb122:
  br label %bb131
bb123:
  br label %bb124
bb124:
  %t488 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t488, ptr %l254, !tbaa !27
  %t489 = load i64, ptr %l28, !tbaa !24
  %t491 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = getelementptr ptr, ptr %t492, i64 %t489
  %t494 = load ptr, ptr %t493, !tbaa !39
  store ptr %t494, ptr %l30, !tbaa !29
  %t496 = load ptr, ptr %l30, !tbaa !29
  %t498 = icmp eq ptr %t496, null
  %t500 = xor i1 %t498, true
  br i1 %t500, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s15
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l260, !tbaa !29
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load ptr, ptr %l30, !tbaa !29
  %t507 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v0, ptr %t503, ptr %t504)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t507, ptr %l263
  br label %bb127
bb126:
  br label %bb129
bb127:
  %t508 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l263
  %t509 = call ptr @__olang_scope_alloc_a(ptr %s15, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t508, ptr %t509
  %t510 = load ptr, ptr %l260, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %v0, ptr %s12, ptr %t510, ptr %t509, ptr %l26)
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s15)
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t513 = load i64, ptr %l28, !tbaa !24
  %t515 = add i64 %t513, 1
  store i64 %t515, ptr %l28, !tbaa !24
  br label %bb121
bb131:
  %t517 = load ptr, ptr %l25, !tbaa !29
  %t519 = getelementptr %"compiler/typed:Spawn", ptr %t517, i32 0, i32 2
  %t520 = load { i64, ptr }, ptr %t519, !tbaa !27
  store { i64, ptr } %t520, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t522 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t522, 0
  store i64 %t524, ptr %l33, !tbaa !24
  br label %bb132
bb132:
  store %olang.scope zeroinitializer, ptr %s18
  %t526 = load i64, ptr %l32, !tbaa !24
  %t527 = load i64, ptr %l33, !tbaa !24
  %t530 = icmp slt i64 %t526, %t527
  %t532 = xor i1 %t530, true
  br i1 %t532, label %bb133, label %bb134
bb133:
  call void @__olang_scope_close(ptr %s18)
  br label %bb138
bb134:
  br label %bb135
bb135:
  %t534 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t534, ptr %l276, !tbaa !27
  %t535 = load i64, ptr %l32, !tbaa !24
  %t537 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t538 = load ptr, ptr %t537, !tbaa !27
  %t539 = getelementptr ptr, ptr %t538, i64 %t535
  %t540 = load ptr, ptr %t539, !tbaa !39
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/typed:TaskClause", ptr %t540, i32 0, i32 3
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t549 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %s18, ptr %t542, ptr %t546)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t549, ptr %l282
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s18)
  br label %bb137
bb137:
  %t550 = load i64, ptr %l32, !tbaa !24
  %t552 = add i64 %t550, 1
  store i64 %t552, ptr %l32, !tbaa !24
  br label %bb132
bb138:
  call void @__olang_scope_close(ptr %s12)
  br label %bb166
bb139:
  %t554 = load ptr, ptr %l1, !tbaa !29
  store ptr %t554, ptr %l285, !tbaa !29
  store i1 false, ptr %l286, !tbaa !21
  %t555 = load ptr, ptr %l285, !tbaa !29
  %t556 = icmp ne ptr %t555, null
  br i1 %t556, label %bb140, label %bb141
bb140:
  %t558 = load ptr, ptr %l285, !tbaa !29
  %t559 = load i64, ptr %t558, !range !{i64 0, i64 17}
  %t561 = icmp eq i64 %t559, 15
  store i1 %t561, ptr %l286, !tbaa !21
  br label %bb141
bb141:
  %t562 = load i1, ptr %l286, !tbaa !21
  br i1 %t562, label %bb142, label %bb143
bb142:
  %t563 = load ptr, ptr %l1, !tbaa !29
  %t565 = getelementptr { i64, [3 x i64] }, ptr %t563, i32 0, i32 1
  %t566 = getelementptr { %"compiler/source:Span", ptr }, ptr %t565, i32 0, i32 1
  %t567 = load ptr, ptr %t566
  store ptr %t567, ptr %l35, !tbaa !29
  br label %bb144
bb143:
  br label %bb161
bb144:
  store %olang.scope zeroinitializer, ptr %s20
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load ptr, ptr %l35, !tbaa !29
  %t574 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %s20, ptr %t569, ptr %t570)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t574, ptr %l294
  br label %bb145
bb145:
  %t575 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l294
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t575, ptr %l36
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/typed:holdWalk", ptr %t576, i32 0, i32 5
  %t580 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %t578)
  store i64 %t580, ptr %l297
  br label %bb146
bb146:
  %t581 = load i64, ptr %l297, !tbaa !24
  %t582 = icmp eq i64 %t581, 0
  br i1 %t582, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s20)
  br label %ret
bb148:
  br label %bb149
bb149:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t586 = getelementptr %"compiler/typed:holdWalk", ptr %t584, i32 0, i32 5
  %t588 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcd1867a2c89de03c7af27b93b5b476d9(ptr %v0, ptr %v0, ptr %t586)
  %t589 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t588, 1
  %t590 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t588, 0
  store i32 %t590, ptr %l303
  %t591 = icmp ne i32 %t590, 0
  br i1 %t591, label %bb151, label %ok.592, !prof !99
ok.592:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t589, ptr %l302
  br label %bb150
bb150:
  %t593 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l302
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t593, ptr %l299
  br label %bb158
bb151:
  %t594 = load i32, ptr %l303, !tbaa !23
  %t595 = icmp eq i32 %t594, 65536
  br i1 %t595, label %bb152, label %bb153
bb152:
  call void @__olang_bang_failed_plain(ptr @olang_loc_5e6c689502ae97a3_4a93e9b8e1d69347)
  unreachable
bb153:
  %t597 = load i32, ptr %l303, !tbaa !23
  %t598 = icmp eq i32 %t597, 65537
  br i1 %t598, label %bb154, label %bb155
bb154:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b6b3adf054eb2e90_3f1400959d6043b4)
  unreachable
bb155:
  %t600 = load i32, ptr %l303, !tbaa !23
  %t601 = icmp eq i32 %t600, 65538
  br i1 %t601, label %bb156, label %bb157
bb156:
  call void @__olang_bang_failed_plain(ptr @olang_loc_7b8fc3b9339208b8_2c51799eb4e60e7c)
  unreachable
bb157:
  call void @__olang_bang_failed_plain(ptr @olang_loc_47bf7dbda354986_81bfc8ef2d8843ba)
  unreachable
bb158:
  %t603 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l299
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t603, ptr %l37
  call void @compiler_2ftyped_2eunion(ptr %s20, ptr %s20, ptr %l37, ptr %l36)
  br label %bb159
bb159:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t608 = getelementptr %"compiler/typed:holdWalk", ptr %t606, i32 0, i32 5
  %t609 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %s20, ptr %t608, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t609)
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s20)
  br label %bb166
bb161:
  br i1 true, label %bb162, label %bb163
bb162:
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_3ca74cad4df58772_2fc4655d37cc5656)
  unreachable
bb166:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l12
  br label %bb2
bb2:
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb23
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l17
  br label %bb6
bb6:
  %t18 = load i64, ptr %l17, !tbaa !24
  store i64 %t18, ptr %l5, !tbaa !24
  store ptr %a2, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l7, !tbaa !24
  store i64 %t21, ptr %l19, !tbaa !24
  %t22 = load ptr, ptr %l6, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t22)
  store i64 %t24, ptr %l21
  br label %bb8
bb8:
  %t25 = load i64, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t32 = load i64, ptr %l7, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l26
  br label %bb12
bb12:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/typed:holdWalk", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  store ptr %t40, ptr %l28, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %t41, i64 %t42)
  store i32 %t45, ptr %l31
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i64, ptr %l8, !tbaa !24
  %t50 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %t46, i64 %t47)
  store i32 %t50, ptr %l34
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l28, !tbaa !29
  %t52 = call ptr @__olang_scope_of(ptr %t51, ptr null)
  %t53 = ptrtoint ptr %t52 to i64
  %t55 = inttoptr i64 %t53 to ptr
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = load i32, ptr %l31, !tbaa !23
  %t58 = load i32, ptr %l34, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %t55, ptr %t56, i32 %t57, i32 %t58)
  store i1 %t59, ptr %l36
  br label %bb15
bb15:
  %t60 = load i1, ptr %l36, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l5, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eadd(ptr %v0, ptr %t61, i64 %t62, i64 %t63)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t67 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l7, !tbaa !24
  br label %bb7
bb21:
  br label %bb22
bb22:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb1
bb23:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etempStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2erefs(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eopenLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:leaveWalk", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Block", ptr %t9, i32 0, i32 0
  %t12 = load i32, ptr %t11, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t8, i32 %t12)
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Block", ptr %t16, i32 0, i32 1
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  %t22 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %t15, { i64, ptr } %t19)
  store i1 %t22, ptr %l13
  br label %bb5
bb5:
  %t23 = load i1, ptr %l13, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/typed:leaveWalk", ptr %t24, i32 0, i32 0
  %t28 = call { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t26)
  %t29 = extractvalue { i32, i32 } %t28, 1
  %t30 = extractvalue { i32, i32 } %t28, 0
  store i32 %t30, ptr %l18
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb7, label %ok.32, !prof !99
ok.32:
  store i32 %t29, ptr %l17
  br label %bb6
bb6:
  %t33 = load i32, ptr %l17, !tbaa !23
  store i32 %t33, ptr %l14, !tbaa !23
  br label %bb9
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t34 = load i1, ptr %l2, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t48 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t48, ptr %l29
  br label %bb20
bb20:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb22, label %bb23
bb22:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 8}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb23
bb23:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb24, label %bb25
bb24:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t69 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l38
  br label %bb27
bb27:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb29, label %bb30
bb29:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 8}
  %t78 = icmp eq i64 %t76, 4
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb30
bb30:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb31, label %bb32
bb31:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t89 = getelementptr %"compiler/typed:Elem", ptr %t87, i32 0, i32 0
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t93 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t86, ptr %t90)
  store i1 %t93, ptr %l48
  br label %bb34
bb34:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb38
bb36:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Elem", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t103 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t95, ptr %t99)
  store i1 %t103, ptr %l54
  br label %bb37
bb37:
  %t104 = load i1, ptr %l54, !tbaa !21
  store i1 %t104, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t105 = load i1, ptr %l49, !tbaa !21
  store i1 %t105, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t107 = load ptr, ptr %l55, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb40, label %bb41
bb40:
  %t110 = load ptr, ptr %l55, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 8}
  %t113 = icmp eq i64 %t111, 5
  store i1 %t113, ptr %l56, !tbaa !21
  br label %bb41
bb41:
  %t114 = load i1, ptr %l56, !tbaa !21
  br i1 %t114, label %bb42, label %bb43
bb42:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Payload", ptr %t122, i32 0, i32 0
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t128 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eplaceLeaves(ptr %v0, ptr %v1, ptr %t121, ptr %t125)
  store i1 %t128, ptr %l64
  br label %bb45
bb45:
  %t129 = load i1, ptr %l64, !tbaa !21
  store i1 %t129, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb47, label %bb48
bb47:
  %t134 = load ptr, ptr %l65, !tbaa !29
  %t135 = load i64, ptr %t134, !range !{i64 0, i64 8}
  %t137 = icmp eq i64 %t135, 6
  store i1 %t137, ptr %l66, !tbaa !21
  br label %bb48
bb48:
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [4 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t141, i32 0, i32 2
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l6, !tbaa !29
  %t150 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  store i1 %t150, ptr %l74
  br label %bb52
bb52:
  %t151 = load i1, ptr %l74, !tbaa !21
  store i1 %t151, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_1807395182923f6f_ecff5ea7ed15d953)
  unreachable
bb54:
  %t152 = load i1, ptr %l7, !tbaa !21
  store i1 %t152, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtsLeave(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l22 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t34 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %t28)
  store i1 %t34, ptr %l22
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = add i64 %t37, 1
  store i64 %t39, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t4 = sub i64 %t2, 1
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Block", ptr %t5, i32 0, i32 0
  %t8 = load i32, ptr %t7, !tbaa !23
  %t9 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t12 = sext i32 %t8 to i64
  %t13 = call i64 @__olang_fmt_i64(ptr null, i64 %t12)
  %t14 = add i64 %t10, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t9, i64 %t10)
  %t16 = getelementptr i8, ptr %t15, i64 %t10
  %t17 = call i64 @__olang_fmt_i64(ptr %t16, i64 %t12)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = extractvalue { i64, ptr } %t19, 1
  %t23 = mul i64 %t21, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t23)
  call void @llvm.memcpy.p0.p0.i64(ptr %t24, ptr %t22, i64 %t23, i1 false)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %s0, ptr %t1, i64 %t4, { i64, ptr } %t26)
  br label %bb1
bb1:
  %t30 = load ptr, ptr %l1, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Block", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l22, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %t55, ptr %t53, i64 %t57)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t61 = load i64, ptr %l4, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eline(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t3 = load i64, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l5, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l13, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = mul i64 %t40, %t41
  %t47 = add i64 %t39, %t44
  store i64 %t47, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/typed:printer", ptr %t49, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t51, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  br label %bb7
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/typed:printer", ptr %t57, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %a2)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/typed:printer", ptr %t63, i32 0, i32 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t65, i8 10)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l81 = alloca { i64, ptr }
  %l85 = alloca ptr
  %l86 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l100 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l106 = alloca { i64, ptr }
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l2, !tbaa !23
  %t17 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t20 = sext i32 %t16 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  %t25 = call i64 @__olang_fmt_i64(ptr %t24, i64 %t20)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t23, 1
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  br label %bb55
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 1
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l3, !tbaa !24
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t46, i32 0, i32 3
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l4, !tbaa !23
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i32, ptr %l4, !tbaa !23
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t50)
  %t56 = add i64 %t53, %t55
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t59 = add i64 %t56, %t58
  %t61 = sext i32 %t51 to i64
  %t62 = call i64 @__olang_fmt_i64(ptr null, i64 %t61)
  %t63 = add i64 %t59, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t52, i64 %t53)
  %t65 = getelementptr i8, ptr %t64, i64 %t53
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t50)
  %t67 = getelementptr i8, ptr %t65, i64 %t55
  call void @olang_textcopy(ptr %t67, ptr %t57, i64 %t58)
  %t68 = getelementptr i8, ptr %t67, i64 %t58
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t61)
  %t70 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t64, 1
  store { i64, ptr } %t71, ptr %l12, !tbaa !27
  br label %bb55
bb12:
  %t73 = load ptr, ptr %l1, !tbaa !29
  store ptr %t73, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t74 = load ptr, ptr %l32, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 2
  store i1 %t80, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t81 = load i1, ptr %l33, !tbaa !21
  br i1 %t81, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t84, i32 0, i32 2
  %t86 = load ptr, ptr %t85
  store ptr %t86, ptr %l5, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l5, !tbaa !29
  %t93 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t88, ptr %t89)
  store { i64, ptr } %t93, ptr %l41
  br label %bb18
bb18:
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t96 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t94, i64 %t95)
  %t101 = getelementptr i8, ptr %t100, i64 %t95
  call void @olang_textcopy(ptr %t101, ptr %t97, i64 %t98)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  store { i64, ptr } %t103, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb19:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t106 = load ptr, ptr %l43, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb20, label %bb21
bb20:
  %t109 = load ptr, ptr %l43, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 8}
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t113 = load i1, ptr %l44, !tbaa !21
  br i1 %t113, label %bb22, label %bb23
bb22:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [4 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t122, i32 0, i32 3
  %t124 = load i64, ptr %t123
  store i64 %t124, ptr %l7, !tbaa !24
  br label %bb24
bb23:
  br label %bb26
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l6, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s7, ptr %t126, ptr %t127)
  store { i64, ptr } %t130, ptr %l53
  br label %bb25
bb25:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t131)
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t135, i64 %t136)
  %t143 = getelementptr i8, ptr %t142, i64 %t136
  %t144 = call i64 @__olang_fmt_i64(ptr %t143, i64 %t131)
  %t145 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t141, 1
  store { i64, ptr } %t146, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb26:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t149 = load ptr, ptr %l56, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb27, label %bb28
bb27:
  %t152 = load ptr, ptr %l56, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 8}
  %t155 = icmp eq i64 %t153, 4
  store i1 %t155, ptr %l57, !tbaa !21
  br label %bb28
bb28:
  %t156 = load i1, ptr %l57, !tbaa !21
  br i1 %t156, label %bb29, label %bb30
bb29:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t159, i32 0, i32 2
  %t161 = load ptr, ptr %t160
  store ptr %t161, ptr %l8, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Elem", ptr %t164, i32 0, i32 0
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s9, ptr %t163, ptr %t167)
  store { i64, ptr } %t170, ptr %l65
  br label %bb32
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l8, !tbaa !29
  %t174 = getelementptr %"compiler/typed:Elem", ptr %t172, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t171, ptr %t175)
  store { i64, ptr } %t179, ptr %l70
  br label %bb33
bb33:
  %t180 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 1
  %t182 = extractvalue { i64, ptr } %t180, 0
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t184 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t185 = add i64 %t182, %t184
  %t186 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = extractvalue { i64, ptr } %t186, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t181, i64 %t182)
  %t194 = getelementptr i8, ptr %t193, i64 %t182
  call void @olang_textcopy(ptr %t194, ptr %t183, i64 %t184)
  %t195 = getelementptr i8, ptr %t194, i64 %t184
  call void @olang_textcopy(ptr %t195, ptr %t187, i64 %t188)
  %t196 = getelementptr i8, ptr %t195, i64 %t188
  call void @olang_textcopy(ptr %t196, ptr %t190, i64 %t191)
  %t197 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t193, 1
  store { i64, ptr } %t198, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb34:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t201 = load ptr, ptr %l72, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb35, label %bb36
bb35:
  %t204 = load ptr, ptr %l72, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 8}
  %t207 = icmp eq i64 %t205, 5
  store i1 %t207, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t208 = load i1, ptr %l73, !tbaa !21
  br i1 %t208, label %bb37, label %bb38
bb37:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l9, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l9, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Payload", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eplace(ptr %v0, ptr %v1, ptr %s11, ptr %t215, ptr %t219)
  store { i64, ptr } %t222, ptr %l81
  br label %bb40
bb40:
  %t223 = load ptr, ptr %l9, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Payload", ptr %t223, i32 0, i32 1
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t226)
  %t235 = add i64 %t232, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t228, i64 %t229)
  %t237 = getelementptr i8, ptr %t236, i64 %t229
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = getelementptr i8, ptr %t237, i64 %t231
  %t239 = call i64 @__olang_fmt_i64(ptr %t238, i64 %t226)
  %t240 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t236, 1
  store { i64, ptr } %t241, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb41:
  %t243 = load ptr, ptr %l1, !tbaa !29
  store ptr %t243, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t244 = load ptr, ptr %l85, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb42, label %bb43
bb42:
  %t247 = load ptr, ptr %l85, !tbaa !29
  %t248 = load i64, ptr %t247, !range !{i64 0, i64 8}
  %t250 = icmp eq i64 %t248, 6
  store i1 %t250, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t251 = load i1, ptr %l86, !tbaa !21
  br i1 %t251, label %bb44, label %bb45
bb44:
  %t252 = load ptr, ptr %l1, !tbaa !29
  %t254 = getelementptr { i64, [4 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t254, i32 0, i32 2
  %t256 = load ptr, ptr %t255
  store ptr %t256, ptr %l10, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t260 = getelementptr { i64, [4 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t260, i32 0, i32 3
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l11, !tbaa !23
  br label %bb46
bb45:
  br label %bb48
bb46:
  store %olang.scope zeroinitializer, ptr %s13
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l10, !tbaa !29
  %t269 = call { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t264, ptr %t265)
  store { i64, ptr } %t269, ptr %l96
  br label %bb47
bb47:
  %t270 = load i32, ptr %l11, !tbaa !23
  %t271 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t273 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t281 = sext i32 %t270 to i64
  %t282 = call i64 @__olang_fmt_i64(ptr null, i64 %t281)
  %t283 = add i64 %t279, %t282
  %t284 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t271, i64 %t272)
  %t285 = getelementptr i8, ptr %t284, i64 %t272
  call void @olang_textcopy(ptr %t285, ptr %t274, i64 %t275)
  %t286 = getelementptr i8, ptr %t285, i64 %t275
  call void @olang_textcopy(ptr %t286, ptr %t277, i64 %t278)
  %t287 = getelementptr i8, ptr %t286, i64 %t278
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t281)
  %t289 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t284, 1
  store { i64, ptr } %t290, ptr %l12, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb55
bb48:
  %t292 = load ptr, ptr %l1, !tbaa !29
  store ptr %t292, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t293 = load ptr, ptr %l99, !tbaa !29
  %t294 = icmp ne ptr %t293, null
  br i1 %t294, label %bb49, label %bb50
bb49:
  %t296 = load ptr, ptr %l99, !tbaa !29
  %t297 = load i64, ptr %t296, !range !{i64 0, i64 8}
  %t299 = icmp eq i64 %t297, 7
  store i1 %t299, ptr %l100, !tbaa !21
  br label %bb50
bb50:
  %t300 = load i1, ptr %l100, !tbaa !21
  br i1 %t300, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l103, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t301, ptr %l12, !tbaa !27
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_16612f18a9afa54d_299c1e15a68a5059)
  unreachable
bb55:
  %t303 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  store i64 %t304, ptr %l105, !tbaa !24
  %t305 = load i64, ptr %l105, !tbaa !24
  %t306 = mul i64 %t305, 1
  %t307 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t306)
  %t308 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t307, 1
  store { i64, ptr } %t309, ptr %l106, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l105, !tbaa !24
  %t315 = mul i64 %t314, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t311, ptr %t313, i64 %t315, i1 false)
  %t316 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t316, ptr %l12, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t317, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l66 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Block", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb62
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l6, !tbaa !29
  %t26 = load ptr, ptr %l6, !tbaa !29
  store ptr %t26, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t27 = load ptr, ptr %l25, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load ptr, ptr %l25, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 17}
  %t33 = icmp eq i64 %t31, 12
  store i1 %t33, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t34 = load i1, ptr %l26, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l7, !tbaa !29
  br label %bb9
bb8:
  br label %bb16
bb9:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t45 = call i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %t41, ptr %t42)
  store i64 %t45, ptr %l33
  br label %bb10
bb10:
  %t46 = load i64, ptr %l33, !tbaa !24
  store i64 %t46, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l8, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb11, label %bb12
bb11:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/typed:DropHolding", ptr %t51, i32 0, i32 0
  %t54 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t53, i64 %t54)
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/typed:DropHolding", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Block", ptr %t60, i32 0, i32 0
  %t63 = load i32, ptr %t62, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v2, ptr %t59, i32 %t63)
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb60
bb16:
  %t66 = load ptr, ptr %l6, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t67 = load ptr, ptr %l43, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 17}
  %t73 = icmp eq i64 %t71, 11
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l44, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t75 = load ptr, ptr %l6, !tbaa !29
  %t77 = getelementptr { i64, [3 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l9, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l9, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t81, ptr %t82, ptr %t83)
  br label %bb22
bb22:
  br label %bb60
bb23:
  %t87 = load ptr, ptr %l6, !tbaa !29
  store ptr %t87, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t88 = load ptr, ptr %l52, !tbaa !29
  %t89 = icmp ne ptr %t88, null
  br i1 %t89, label %bb24, label %bb25
bb24:
  %t91 = load ptr, ptr %l52, !tbaa !29
  %t92 = load i64, ptr %t91, !range !{i64 0, i64 17}
  %t94 = icmp eq i64 %t92, 3
  store i1 %t94, ptr %l53, !tbaa !21
  br label %bb25
bb25:
  %t95 = load i1, ptr %l53, !tbaa !21
  br i1 %t95, label %bb26, label %bb27
bb26:
  %t96 = load ptr, ptr %l6, !tbaa !29
  %t98 = getelementptr { i64, [3 x i64] }, ptr %t96, i32 0, i32 1
  %t99 = getelementptr { %"compiler/source:Span", ptr }, ptr %t98, i32 0, i32 1
  %t100 = load ptr, ptr %t99
  store ptr %t100, ptr %l10, !tbaa !29
  br label %bb28
bb27:
  br label %bb37
bb28:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l10, !tbaa !29
  %t105 = getelementptr %"compiler/typed:If", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t102, ptr %t106, ptr %t107)
  br label %bb29
bb29:
  %t111 = load ptr, ptr %l10, !tbaa !29
  %t113 = getelementptr %"compiler/typed:If", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb30, label %bb31
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l66, !tbaa !29
  %t121 = load ptr, ptr %l10, !tbaa !29
  %t123 = getelementptr %"compiler/typed:If", ptr %t121, i32 0, i32 2
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_4baf654831ed8d80_eee61e02aec284c4)
  unreachable
bb33:
  br label %bb34
bb34:
  %t128 = load ptr, ptr %l10, !tbaa !29
  %t130 = getelementptr %"compiler/typed:If", ptr %t128, i32 0, i32 2
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t133 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t133, ptr %t131, ptr %t132)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb60
bb37:
  %t136 = load ptr, ptr %l6, !tbaa !29
  store ptr %t136, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t137 = load ptr, ptr %l73, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb38, label %bb39
bb38:
  %t140 = load ptr, ptr %l73, !tbaa !29
  %t141 = load i64, ptr %t140, !range !{i64 0, i64 17}
  %t143 = icmp eq i64 %t141, 4
  store i1 %t143, ptr %l74, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l74, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  %t145 = load ptr, ptr %l6, !tbaa !29
  %t147 = getelementptr { i64, [3 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t147, i32 0, i32 1
  %t149 = load ptr, ptr %t148
  store ptr %t149, ptr %l11, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr { i64, [3 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t153, i32 0, i32 2
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l12, !tbaa !29
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l11, !tbaa !29
  %t159 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t157, ptr %t158, ptr %t159)
  br label %bb43
bb43:
  %t163 = load ptr, ptr %l12, !tbaa !29
  %t165 = icmp eq ptr %t163, null
  %t167 = xor i1 %t165, true
  br i1 %t167, label %bb44, label %bb45
bb44:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l12, !tbaa !29
  %t171 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t169, ptr %t170, ptr %t171)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb60
bb48:
  %t175 = load ptr, ptr %l6, !tbaa !29
  store ptr %t175, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t176 = load ptr, ptr %l90, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb49, label %bb50
bb49:
  %t179 = load ptr, ptr %l90, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 17}
  %t182 = icmp eq i64 %t180, 13
  store i1 %t182, ptr %l91, !tbaa !21
  br label %bb50
bb50:
  %t183 = load i1, ptr %l91, !tbaa !21
  br i1 %t183, label %bb51, label %bb52
bb51:
  %t184 = load ptr, ptr %l6, !tbaa !29
  %t186 = getelementptr { i64, [3 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", ptr }, ptr %t186, i32 0, i32 1
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l13, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load ptr, ptr %l13, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Join", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t195 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ftyped_2efindHolders(ptr %v0, ptr %v1, ptr %v2, ptr %t190, ptr %t194, ptr %t195)
  br label %bb54
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_f3eab8194bd11e66_e0240e140d7ed92a)
  unreachable
bb60:
  br label %bb61
bb61:
  %t199 = load i64, ptr %l4, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l4, !tbaa !24
  br label %bb1
bb62:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2enamedHoldsWritable(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t2, i32 %t3)
  store i32 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = load i32, ptr %l7, !tbaa !23
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !range !{i32 0, i32 6}
  store i32 %t10, ptr %l3
  %t11 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t13 = trunc i64 2 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t16 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t18 = trunc i64 5 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l11, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t25 = trunc i64 3 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb12
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l1, !tbaa !23
  %t32 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l20
  br label %bb11
bb11:
  %t33 = load i1, ptr %l20, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t38 = load i32, ptr %l3, !range !{i32 0, i32 6}
  %t40 = trunc i64 4 to i32
  %t41 = icmp eq i32 %t38, %t40
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l1, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t44, i32 %t45)
  store i32 %t48, ptr %l28
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = add i64 %t49, 1
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load i32, ptr %l28, !tbaa !23
  %t55 = call i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %t52, i32 %t53, i64 %t51)
  store i1 %t55, ptr %l31
  br label %bb19
bb19:
  %t56 = load i1, ptr %l31, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
bb20:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l32, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l1, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l36
  br label %bb21
bb21:
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = load i32, ptr %l36, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l37
  br label %bb22
bb22:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load ptr, ptr %l32, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t71 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t68, { i64, ptr } %t69, i64 %t67)
  store i1 %t71, ptr %l39
  br label %bb23
bb23:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb29
bb25:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l42, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l1, !tbaa !23
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t75, i32 %t76)
  store i32 %t79, ptr %l45
  br label %bb26
bb26:
  %t80 = load ptr, ptr %l42, !tbaa !29
  %t81 = load i32, ptr %l45, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t80, i32 %t81)
  store { i64, ptr } %t82, ptr %l46
  br label %bb27
bb27:
  %t83 = load i64, ptr %l2, !tbaa !24
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t87 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t84, { i64, ptr } %t85, i64 %t83)
  store i1 %t87, ptr %l48
  br label %bb28
bb28:
  %t88 = load i1, ptr %l48, !tbaa !21
  store i1 %t88, ptr %l40, !tbaa !21
  br label %bb29
bb29:
  %t89 = load i1, ptr %l40, !tbaa !21
  br i1 %t89, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb35
bb31:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l50, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l1, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l54
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l51, !tbaa !29
  %t98 = load i32, ptr %l54, !tbaa !23
  %t99 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t97, i32 %t98)
  store { i64, ptr } %t99, ptr %l55
  br label %bb33
bb33:
  %t100 = load i64, ptr %l2, !tbaa !24
  %t101 = load ptr, ptr %l50, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t104 = call i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v0, ptr %t101, { i64, ptr } %t102, i64 %t100)
  store i1 %t104, ptr %l57
  br label %bb34
bb34:
  %t105 = load i1, ptr %l57, !tbaa !21
  store i1 %t105, ptr %l49, !tbaa !21
  br label %bb35
bb35:
  %t106 = load i1, ptr %l49, !tbaa !21
  store i1 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2eone(ptr %v0, i64 %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t5, i64 %a0)
  br label %bb2
bb2:
  %t9 = load ptr, ptr %lp1
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ftyped_2eorInto(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l34, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  store i64 %t52, ptr %l35, !tbaa !24
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t53, ptr %l36, !tbaa !27
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i1, ptr %t57, i64 %t54
  %t59 = load i1, ptr %t58, !tbaa !31
  br i1 %t59, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb13
bb12:
  store { i64, ptr } %a1, ptr %l40, !tbaa !27
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr i1, ptr %t65, i64 %t62
  %t67 = load i1, ptr %t66, !tbaa !31
  store i1 %t67, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t69 = load i1, ptr %l39, !tbaa !21
  %t70 = load i64, ptr %l35, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i1, ptr %t72, i64 %t70
  store i1 %t69, ptr %t73, !tbaa !31
  br label %bb14
bb14:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb7
bb15:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ftyped_2epiecesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l22 = alloca i1
  %l30 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb26
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l5, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t31 = load ptr, ptr %l21, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 2}
  %t37 = icmp eq i64 %t35, 1
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l22, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = getelementptr { i64, [2 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { ptr }, ptr %t41, i32 0, i32 0
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l6, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t50 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t45, i32 %a1)
  store i1 %t50, ptr %l30
  br label %bb13
bb13:
  %t51 = load i1, ptr %l30, !tbaa !21
  br i1 %t51, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t57 = load ptr, ptr %l32, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 2}
  %t60 = icmp eq i64 %t58, 0
  store i1 %t60, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_fc8cc15dada93547_2e2c8c126dc2f08b)
  unreachable
bb24:
  br label %bb25
bb25:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l3, !tbaa !24
  br label %bb4
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ftyped_2esharedBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l69 = alloca i32
  %l72 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t1)
  store i64 %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load i64, ptr %l14, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l21, !tbaa !24
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l18, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb31
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t53 = add i64 %t51, 1
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l42
  br label %bb12
bb12:
  %t58 = load i64, ptr %l42, !tbaa !24
  store i64 %t58, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb18
bb15:
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l9, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l49, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb17
bb17:
  %t85 = load i64, ptr %l49, !tbaa !24
  store i64 %t85, ptr %l46, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l46, !tbaa !24
  store i64 %t86, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb19
bb19:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb20, label %bb21
bb20:
  br label %bb29
bb21:
  br label %bb22
bb22:
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l11, !tbaa !24
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l12, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t105, i64 %t106)
  store i32 %t109, ptr %l69
  br label %bb23
bb23:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l12, !tbaa !24
  %t114 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %t110, i64 %t111)
  store i32 %t114, ptr %l72
  br label %bb24
bb24:
  %t115 = load i32, ptr %l69, !tbaa !23
  %t116 = load i32, ptr %l72, !tbaa !23
  %t117 = icmp eq i32 %t115, %t116
  br i1 %t117, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = add i64 %t120, 1
  store i64 %t122, ptr %l11, !tbaa !24
  br label %bb19
bb29:
  br label %bb30
bb30:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l5, !tbaa !24
  br label %bb8
bb31:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ftyped_2eshort(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t9, ptr %rv
  br label %ret
bb4:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t15 = add i64 %t11, 1
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t16, 0
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load i64, ptr %l9, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l12, !tbaa !24
  %t27 = icmp sle i64 %t25, %t26
  br i1 %t27, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb7:
  %t29 = load i64, ptr %l12, !tbaa !24
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = icmp sle i64 %t29, %t30
  br i1 %t31, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
bb9:
  %t33 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = getelementptr i8, ptr %t34, i64 %t35
  %t38 = sub i64 %t36, %t35
  %t39 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t37, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_942c69358f77327c_b8abecb88c811c88)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ftyped_2estmtBreaks(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l104 = alloca i1
  %l105 = alloca i1
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l123 = alloca i1
  %l124 = alloca ptr
  %l125 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l137 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l146 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i1
  %l158 = alloca i1
  %l159 = alloca i1
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i1
  %l178 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l189 = alloca i1
  %l190 = alloca i1
  %l194 = alloca i1
  %l195 = alloca ptr
  %l196 = alloca i1
  %l204 = alloca i1
  %l205 = alloca i1
  %l210 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t2 = load ptr, ptr %l19, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l19, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l20, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l20, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 2}
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t22 = load i32, ptr %l2, !range !{i32 0, i32 2}
  %t24 = trunc i64 0 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l1, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  store i1 %t31, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l29, !tbaa !21
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb137
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l33, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 17}
  %t41 = icmp eq i64 %t39, 0
  store i1 %t41, ptr %l34, !tbaa !21
  br label %bb11
bb11:
  %t42 = load i1, ptr %l34, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [3 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 2
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb22
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l39, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 17}
  %t56 = icmp eq i64 %t54, 2
  store i1 %t56, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l40, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr { i64, [3 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l4, !tbaa !29
  br label %bb22
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t65 = load ptr, ptr %l45, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l45, !tbaa !29
  %t69 = load i64, ptr %t68, !range !{i64 0, i64 17}
  %t71 = icmp eq i64 %t69, 15
  store i1 %t71, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l46, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr { i64, [3 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", ptr }, ptr %t75, i32 0, i32 1
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t79, i32 %t81)
  store i1 %t84, ptr %l54
  br label %bb23
bb23:
  %t85 = load i1, ptr %l54, !tbaa !21
  store i1 %t85, ptr %l18, !tbaa !21
  br label %bb137
bb24:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t87 = load ptr, ptr %l55, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 17}
  %t93 = icmp eq i64 %t91, 1
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr { i64, [3 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t97, i32 0, i32 1
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l5, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t103, i32 0, i32 2
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t107 = load ptr, ptr %l5, !tbaa !29
  %t108 = load i32, ptr %l1, !tbaa !23
  %t111 = call i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l65
  br label %bb30
bb30:
  %t112 = load i1, ptr %l65, !tbaa !21
  br i1 %t112, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb34
bb32:
  %t113 = load ptr, ptr %l6, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t118 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t113, i32 %t115)
  store i1 %t118, ptr %l70
  br label %bb33
bb33:
  %t119 = load i1, ptr %l70, !tbaa !21
  store i1 %t119, ptr %l66, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l66, !tbaa !21
  store i1 %t120, ptr %l18, !tbaa !21
  br label %bb137
bb35:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t122 = load ptr, ptr %l71, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb36, label %bb37
bb36:
  %t125 = load ptr, ptr %l71, !tbaa !29
  %t126 = load i64, ptr %t125, !range !{i64 0, i64 17}
  %t128 = icmp eq i64 %t126, 3
  store i1 %t128, ptr %l72, !tbaa !21
  br label %bb37
bb37:
  %t129 = load i1, ptr %l72, !tbaa !21
  br i1 %t129, label %bb38, label %bb39
bb38:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr { i64, [3 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr }, ptr %t132, i32 0, i32 1
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l7, !tbaa !29
  br label %bb40
bb39:
  br label %bb50
bb40:
  %t136 = load ptr, ptr %l7, !tbaa !29
  %t138 = getelementptr %"compiler/typed:If", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = load i32, ptr %l1, !tbaa !23
  %t144 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t139, i32 %t141)
  store i1 %t144, ptr %l81
  br label %bb41
bb41:
  %t145 = load i1, ptr %l81, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb45
bb43:
  %t146 = load ptr, ptr %l7, !tbaa !29
  %t148 = getelementptr %"compiler/typed:If", ptr %t146, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = load i32, ptr %l1, !tbaa !23
  %t154 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t149, i32 %t151)
  store i1 %t154, ptr %l87
  br label %bb44
bb44:
  %t155 = load i1, ptr %l87, !tbaa !21
  store i1 %t155, ptr %l82, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l82, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb49
bb47:
  %t157 = load ptr, ptr %l7, !tbaa !29
  %t159 = getelementptr %"compiler/typed:If", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t160, i32 %t161)
  store i1 %t164, ptr %l92
  br label %bb48
bb48:
  %t165 = load i1, ptr %l92, !tbaa !21
  store i1 %t165, ptr %l88, !tbaa !21
  br label %bb49
bb49:
  %t166 = load i1, ptr %l88, !tbaa !21
  store i1 %t166, ptr %l18, !tbaa !21
  br label %bb137
bb50:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t168 = load ptr, ptr %l93, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb51, label %bb52
bb51:
  %t171 = load ptr, ptr %l93, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 17}
  %t174 = icmp eq i64 %t172, 4
  store i1 %t174, ptr %l94, !tbaa !21
  br label %bb52
bb52:
  %t175 = load i1, ptr %l94, !tbaa !21
  br i1 %t175, label %bb53, label %bb54
bb53:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l8, !tbaa !29
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr { i64, [3 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = load i32, ptr %l1, !tbaa !23
  %t193 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t188, i32 %t190)
  store i1 %t193, ptr %l104
  br label %bb56
bb56:
  %t194 = load i1, ptr %l104, !tbaa !21
  br i1 %t194, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l105, !tbaa !21
  br label %bb60
bb58:
  %t195 = load ptr, ptr %l9, !tbaa !29
  %t196 = load i32, ptr %l1, !tbaa !23
  %t199 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t195, i32 %t196)
  store i1 %t199, ptr %l108
  br label %bb59
bb59:
  %t200 = load i1, ptr %l108, !tbaa !21
  store i1 %t200, ptr %l105, !tbaa !21
  br label %bb60
bb60:
  %t201 = load i1, ptr %l105, !tbaa !21
  store i1 %t201, ptr %l18, !tbaa !21
  br label %bb137
bb61:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t203 = load ptr, ptr %l109, !tbaa !29
  %t204 = icmp ne ptr %t203, null
  br i1 %t204, label %bb62, label %bb63
bb62:
  %t206 = load ptr, ptr %l109, !tbaa !29
  %t207 = load i64, ptr %t206, !range !{i64 0, i64 17}
  %t209 = icmp eq i64 %t207, 6
  store i1 %t209, ptr %l110, !tbaa !21
  br label %bb63
bb63:
  %t210 = load i1, ptr %l110, !tbaa !21
  br i1 %t210, label %bb64, label %bb65
bb64:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  store ptr %t215, ptr %l10, !tbaa !29
  br label %bb70
bb65:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t218 = load ptr, ptr %l115, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb66, label %bb67
bb66:
  %t221 = load ptr, ptr %l115, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 17}
  %t224 = icmp eq i64 %t222, 16
  store i1 %t224, ptr %l116, !tbaa !21
  br label %bb67
bb67:
  %t225 = load i1, ptr %l116, !tbaa !21
  br i1 %t225, label %bb68, label %bb69
bb68:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 1
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l10, !tbaa !29
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t232 = load ptr, ptr %l10, !tbaa !29
  %t233 = load i32, ptr %l1, !tbaa !23
  %t236 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t232, i32 %t233)
  store i1 %t236, ptr %l123
  br label %bb71
bb71:
  %t237 = load i1, ptr %l123, !tbaa !21
  store i1 %t237, ptr %l18, !tbaa !21
  br label %bb137
bb72:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t239 = load ptr, ptr %l124, !tbaa !29
  %t240 = icmp ne ptr %t239, null
  br i1 %t240, label %bb73, label %bb74
bb73:
  %t242 = load ptr, ptr %l124, !tbaa !29
  %t243 = load i64, ptr %t242, !range !{i64 0, i64 17}
  %t245 = icmp eq i64 %t243, 7
  store i1 %t245, ptr %l125, !tbaa !21
  br label %bb74
bb74:
  %t246 = load i1, ptr %l125, !tbaa !21
  br i1 %t246, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb137
bb78:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t248 = load ptr, ptr %l128, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb79, label %bb80
bb79:
  %t251 = load ptr, ptr %l128, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 8
  store i1 %t254, ptr %l129, !tbaa !21
  br label %bb80
bb80:
  %t255 = load i1, ptr %l129, !tbaa !21
  br i1 %t255, label %bb81, label %bb82
bb81:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l11, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t264 = load i32, ptr %l1, !tbaa !23
  %t267 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t262, i32 %t264)
  store i1 %t267, ptr %l137
  br label %bb84
bb84:
  %t268 = load i1, ptr %l137, !tbaa !21
  store i1 %t268, ptr %l18, !tbaa !21
  br label %bb137
bb85:
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t270 = load ptr, ptr %l138, !tbaa !29
  %t271 = icmp ne ptr %t270, null
  br i1 %t271, label %bb86, label %bb87
bb86:
  %t273 = load ptr, ptr %l138, !tbaa !29
  %t274 = load i64, ptr %t273, !range !{i64 0, i64 17}
  %t276 = icmp eq i64 %t274, 9
  store i1 %t276, ptr %l139, !tbaa !21
  br label %bb87
bb87:
  %t277 = load i1, ptr %l139, !tbaa !21
  br i1 %t277, label %bb88, label %bb89
bb88:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr { i64, [3 x i64] }, ptr %t278, i32 0, i32 1
  %t281 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t280, i32 0, i32 2
  %t282 = load ptr, ptr %t281
  store ptr %t282, ptr %l12, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t284 = load ptr, ptr %l12, !tbaa !29
  %t285 = load i32, ptr %l1, !tbaa !23
  %t288 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t284, i32 %t285)
  store i1 %t288, ptr %l146
  br label %bb91
bb91:
  %t289 = load i1, ptr %l146, !tbaa !21
  store i1 %t289, ptr %l18, !tbaa !21
  br label %bb137
bb92:
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l147, !tbaa !29
  store i1 false, ptr %l148, !tbaa !21
  %t291 = load ptr, ptr %l147, !tbaa !29
  %t292 = icmp ne ptr %t291, null
  br i1 %t292, label %bb93, label %bb94
bb93:
  %t294 = load ptr, ptr %l147, !tbaa !29
  %t295 = load i64, ptr %t294, !range !{i64 0, i64 17}
  %t297 = icmp eq i64 %t295, 10
  store i1 %t297, ptr %l148, !tbaa !21
  br label %bb94
bb94:
  %t298 = load i1, ptr %l148, !tbaa !21
  br i1 %t298, label %bb95, label %bb96
bb95:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr { i64, [3 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t301, i32 0, i32 1
  %t303 = load ptr, ptr %t302
  store ptr %t303, ptr %l13, !tbaa !29
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t307, i32 0, i32 2
  %t309 = load ptr, ptr %t308
  store ptr %t309, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb103
bb97:
  %t311 = load ptr, ptr %l13, !tbaa !29
  %t313 = load i32, ptr %l1, !tbaa !23
  %t316 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t311, i32 %t313)
  store i1 %t316, ptr %l158
  br label %bb98
bb98:
  %t317 = load i1, ptr %l158, !tbaa !21
  br i1 %t317, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb102
bb100:
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t319 = load i32, ptr %l1, !tbaa !23
  %t322 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t318, i32 %t319)
  store i1 %t322, ptr %l162
  br label %bb101
bb101:
  %t323 = load i1, ptr %l162, !tbaa !21
  store i1 %t323, ptr %l159, !tbaa !21
  br label %bb102
bb102:
  %t324 = load i1, ptr %l159, !tbaa !21
  store i1 %t324, ptr %l18, !tbaa !21
  br label %bb137
bb103:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l163, !tbaa !29
  store i1 false, ptr %l164, !tbaa !21
  %t326 = load ptr, ptr %l163, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb104, label %bb105
bb104:
  %t329 = load ptr, ptr %l163, !tbaa !29
  %t330 = load i64, ptr %t329, !range !{i64 0, i64 17}
  %t332 = icmp eq i64 %t330, 11
  store i1 %t332, ptr %l164, !tbaa !21
  br label %bb105
bb105:
  %t333 = load i1, ptr %l164, !tbaa !21
  br i1 %t333, label %bb106, label %bb107
bb106:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", ptr }, ptr %t336, i32 0, i32 1
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l15, !tbaa !29
  br label %bb112
bb107:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l169, !tbaa !29
  store i1 false, ptr %l170, !tbaa !21
  %t341 = load ptr, ptr %l169, !tbaa !29
  %t342 = icmp ne ptr %t341, null
  br i1 %t342, label %bb108, label %bb109
bb108:
  %t344 = load ptr, ptr %l169, !tbaa !29
  %t345 = load i64, ptr %t344, !range !{i64 0, i64 17}
  %t347 = icmp eq i64 %t345, 12
  store i1 %t347, ptr %l170, !tbaa !21
  br label %bb109
bb109:
  %t348 = load i1, ptr %l170, !tbaa !21
  br i1 %t348, label %bb110, label %bb111
bb110:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr { i64, [3 x i64] }, ptr %t349, i32 0, i32 1
  %t352 = getelementptr { %"compiler/source:Span", ptr }, ptr %t351, i32 0, i32 1
  %t353 = load ptr, ptr %t352
  store ptr %t353, ptr %l15, !tbaa !29
  br label %bb112
bb111:
  br label %bb114
bb112:
  %t355 = load ptr, ptr %l15, !tbaa !29
  %t357 = load i32, ptr %l1, !tbaa !23
  %t360 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t355, i32 %t357)
  store i1 %t360, ptr %l178
  br label %bb113
bb113:
  %t361 = load i1, ptr %l178, !tbaa !21
  store i1 %t361, ptr %l18, !tbaa !21
  br label %bb137
bb114:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t363 = load ptr, ptr %l179, !tbaa !29
  %t364 = icmp ne ptr %t363, null
  br i1 %t364, label %bb115, label %bb116
bb115:
  %t366 = load ptr, ptr %l179, !tbaa !29
  %t367 = load i64, ptr %t366, !range !{i64 0, i64 17}
  %t369 = icmp eq i64 %t367, 13
  store i1 %t369, ptr %l180, !tbaa !21
  br label %bb116
bb116:
  %t370 = load i1, ptr %l180, !tbaa !21
  br i1 %t370, label %bb117, label %bb118
bb117:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", ptr }, ptr %t373, i32 0, i32 1
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l16, !tbaa !29
  br label %bb119
bb118:
  br label %bb125
bb119:
  %t377 = load ptr, ptr %l16, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Join", ptr %t377, i32 0, i32 0
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = load i32, ptr %l1, !tbaa !23
  %t385 = call i1 @compiler_2ftyped_2eBreaksOut(ptr %v0, ptr %t380, i32 %t382)
  store i1 %t385, ptr %l189
  br label %bb120
bb120:
  %t386 = load i1, ptr %l189, !tbaa !21
  br i1 %t386, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb124
bb122:
  %t387 = load ptr, ptr %l16, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Join", ptr %t387, i32 0, i32 2
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  %t391 = load i32, ptr %l1, !tbaa !23
  %t394 = call i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %t390, i32 %t391)
  store i1 %t394, ptr %l194
  br label %bb123
bb123:
  %t395 = load i1, ptr %l194, !tbaa !21
  store i1 %t395, ptr %l190, !tbaa !21
  br label %bb124
bb124:
  %t396 = load i1, ptr %l190, !tbaa !21
  store i1 %t396, ptr %l18, !tbaa !21
  br label %bb137
bb125:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l195, !tbaa !29
  store i1 false, ptr %l196, !tbaa !21
  %t398 = load ptr, ptr %l195, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb126, label %bb127
bb126:
  %t401 = load ptr, ptr %l195, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 17}
  %t404 = icmp eq i64 %t402, 14
  store i1 %t404, ptr %l196, !tbaa !21
  br label %bb127
bb127:
  %t405 = load i1, ptr %l196, !tbaa !21
  br i1 %t405, label %bb128, label %bb129
bb128:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr { i64, [3 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr }, ptr %t408, i32 0, i32 1
  %t410 = load ptr, ptr %t409
  store ptr %t410, ptr %l17, !tbaa !29
  br label %bb130
bb129:
  br label %bb136
bb130:
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = getelementptr %"compiler/typed:Spawn", ptr %t412, i32 0, i32 0
  %t415 = load { i64, ptr }, ptr %t414, !tbaa !27
  %t416 = load i32, ptr %l1, !tbaa !23
  %t419 = call i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %t415, i32 %t416)
  store i1 %t419, ptr %l204
  br label %bb131
bb131:
  %t420 = load i1, ptr %l204, !tbaa !21
  br i1 %t420, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l205, !tbaa !21
  br label %bb135
bb133:
  %t421 = load ptr, ptr %l17, !tbaa !29
  %t423 = getelementptr %"compiler/typed:Spawn", ptr %t421, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t426 = load i32, ptr %l1, !tbaa !23
  %t429 = call i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %t424, i32 %t426)
  store i1 %t429, ptr %l210
  br label %bb134
bb134:
  %t430 = load i1, ptr %l210, !tbaa !21
  store i1 %t430, ptr %l205, !tbaa !21
  br label %bb135
bb135:
  %t431 = load i1, ptr %l205, !tbaa !21
  store i1 %t431, ptr %l18, !tbaa !21
  br label %bb137
bb136:
  call void @__olang_check_failed(ptr @olang_loc_ab0bd1a1cb525619_8191fed8583864ed)
  unreachable
bb137:
  %t432 = load i1, ptr %l18, !tbaa !21
  store i1 %t432, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ftyped_2eunion(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %t19, i64 %t20)
  store i1 %t23, ptr %l16
  br label %bb7
bb7:
  %t24 = load i1, ptr %l16, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb1
bb13:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:Arm" @compiler_2ftyped_3aArm_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, %"compiler/source:Span" %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, ptr %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Arm"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Arm" undef, %"compiler/source:Span" %a0, 0
  %t14 = insertvalue %"compiler/typed:Arm" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Arm" %t14, ptr %a2, 2
  %t18 = insertvalue %"compiler/typed:Arm" %t16, ptr %a3, 3
  %t20 = insertvalue %"compiler/typed:Arm" %t18, ptr %a4, 4
  store %"compiler/typed:Arm" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Arm", ptr %rv
  ret %"compiler/typed:Arm" %rr
}

define dso_local %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Call"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Call" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Call" %t12, { i64, ptr } %a1, 1
  %t16 = insertvalue %"compiler/typed:Call" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/typed:Call" %t16, i1 %a3, 3
  %t20 = insertvalue %"compiler/typed:Call" %t18, i1 %a4, 4
  store %"compiler/typed:Call" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Call", ptr %rv
  ret %"compiler/typed:Call" %rr
}

define dso_local %"compiler/typed:Collect" @compiler_2ftyped_3aCollect_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i1 %a4) #0 {
entry:
  %rv = alloca %"compiler/typed:Collect"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/typed:Collect" undef, ptr %a0, 0
  %t14 = insertvalue %"compiler/typed:Collect" %t12, ptr %a1, 1
  %t16 = insertvalue %"compiler/typed:Collect" %t14, i32 %a2, 2
  %t18 = insertvalue %"compiler/typed:Collect" %t16, i32 %a3, 3
  %t20 = insertvalue %"compiler/typed:Collect" %t18, i1 %a4, 4
  store %"compiler/typed:Collect" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Collect", ptr %rv
  ret %"compiler/typed:Collect" %rr
}

define dso_local %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Cond"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Cond" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Cond" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Cond" %t10, ptr %a2, 2
  store %"compiler/typed:Cond" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Cond", ptr %rv
  ret %"compiler/typed:Cond" %rr
}

define dso_local %"compiler/typed:ContractInfo" @compiler_2ftyped_3aContractInfo_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/typed:ContractInfo"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 %a1, ptr %l3, !tbaa !24
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l11
  br label %bb3
bb3:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = insertvalue %"compiler/typed:ContractInfo" undef, { i64, ptr } %t11, 0
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = insertvalue %"compiler/typed:ContractInfo" %t12, i64 %t13, 1
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t16 = insertvalue %"compiler/typed:ContractInfo" %t14, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, 2
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t18 = insertvalue %"compiler/typed:ContractInfo" %t16, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, 3
  %t20 = insertvalue %"compiler/typed:ContractInfo" %t18, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, 4
  store %"compiler/typed:ContractInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:ContractInfo", ptr %rv
  ret %"compiler/typed:ContractInfo" %rr
}

define dso_local %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Elem"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Elem" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Elem" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Elem" %t10, i32 %a2, 2
  store %"compiler/typed:Elem" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Elem", ptr %rv
  ret %"compiler/typed:Elem" %rr
}

define dso_local %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Item"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Item" undef, i32 %a0, 0
  %t8 = insertvalue %"compiler/typed:Item" %t6, i64 %a1, 1
  store %"compiler/typed:Item" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Item", ptr %rv
  ret %"compiler/typed:Item" %rr
}

define dso_local %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Join"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Join" undef, ptr %a0, 0
  %t10 = insertvalue %"compiler/typed:Join" %t8, i1 %a1, 1
  %t12 = insertvalue %"compiler/typed:Join" %t10, { i64, ptr } %a2, 2
  store %"compiler/typed:Join" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Join", ptr %rv
  ret %"compiler/typed:Join" %rr
}

define dso_local %"compiler/typed:Promote" @compiler_2ftyped_3aPromote_2ector(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:Promote"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:Promote" undef, ptr %a0, 0
  %t8 = insertvalue %"compiler/typed:Promote" %t6, i32 %a1, 1
  store %"compiler/typed:Promote" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Promote", ptr %rv
  ret %"compiler/typed:Promote" %rr
}

define dso_local %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2) #0 {
entry:
  %rv = alloca %"compiler/typed:Seq"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/typed:Seq" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/typed:Seq" %t8, ptr %a1, 1
  %t12 = insertvalue %"compiler/typed:Seq" %t10, i1 %a2, 2
  store %"compiler/typed:Seq" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:Seq", ptr %rv
  ret %"compiler/typed:Seq" %rr
}

define dso_local void @compiler_2ftyped_3adropWalk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l29 = alloca %"compiler/typed:dropWalk"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l18
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  store i64 0, ptr %l5, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l19
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l6
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l20
  br label %bb4
bb4:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l7
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l21
  br label %bb5
bb5:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l8
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l22
  br label %bb6
bb6:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l9
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l23
  br label %bb7
bb7:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l10
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l24
  br label %bb8
bb8:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l11
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l25
  br label %bb9
bb9:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l12
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l26
  br label %bb10
bb10:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l13
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l27
  br label %bb11
bb11:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l14
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l28
  br label %bb12
bb12:
  %t26 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  %t27 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 0
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %t27, !tbaa !29
  %t29 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 1
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t29
  %t31 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 2
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t31
  %t33 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 3
  %t34 = load i1, ptr %l4, !tbaa !21
  store i1 %t34, ptr %t33, !tbaa !21
  %t35 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 4
  %t36 = load i64, ptr %l5, !tbaa !24
  store i64 %t36, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 5
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %t37
  %t39 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 6
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t39
  %t41 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 7
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %t41
  %t43 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 8
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %t43
  %t45 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 9
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t45
  %t47 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 10
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %t47
  %t49 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 11
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t49
  %t51 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 12
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %t51
  %t53 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 13
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t53
  %t55 = getelementptr %"compiler/typed:dropWalk", ptr %l29, i32 0, i32 14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t26, ptr %t55
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l29, i64 488, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/typed:landState" @compiler_2ftyped_3alandState_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %rv = alloca %"compiler/typed:landState"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/typed:landState" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/typed:landState" %t6, i1 %a1, 1
  store %"compiler/typed:landState" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/typed:landState", ptr %rv
  ret %"compiler/typed:landState" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_bang_failed_plain(ptr) cold noreturn
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"L" }>, align 8
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"G" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"*" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"]" }>, align 8
@.d9 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" as " }>, align 8
@.d10 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tmp " }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"target" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i1 @compiler_2ftyped_2estmtsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_831440fdfc819328_dabfa81c01cf773c = external constant [0 x i8]
@olang_loc_7bdf3cb2fb8351f9_389183759a182ed = external constant [0 x i8]
@olang_loc_4e05db95f2fd54c5_981a3a3cc6318dd9 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eLen__Hdc799a0fe091f8e84d50200d058b631d(ptr %v0, ptr %a0)
declare %"compiler/typed:BlockInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2eAt_3ccompiler_2ftyped_3aBlockInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftyped_2efreshValue(ptr %v0, ptr %a0)
@olang_loc_bf16ba0368763d37_f19ef32b132443ab = external constant [0 x i8]
@olang_loc_af65136929bfae16_48f8be4437d6c6ea = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eholdsOwned(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_c21a1343bdb3d01_d6f77a8ccb597545 = external constant [0 x i8]
@olang_loc_4964fda744059959_ea5b63edb7fb932d = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ePure(ptr %v0, ptr %a0)
@olang_loc_b89edc07d86ca7e2_8a4bea4bc2b7688e = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_ecb034f719e18c1b_985175307bfdc34f = external constant [0 x i8]
declare %"compiler/typed:BlockInfo" @compiler_2ftyped_3aBlockInfo_2ector(ptr %v0, i32 %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockInfo_3e_2ePush_H85e1838377aa8e6b322d82e3edbac596(ptr %v0, ptr %a0, %"compiler/typed:BlockInfo" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2ePush_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, %"compiler/typed:Local" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:SiteInfo" @compiler_2ftyped_3aSiteInfo_2ector(ptr %v0, i32 %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2ePush_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0, %"compiler/typed:SiteInfo" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aSiteInfo_3e_2eLen_3ccompiler_2ftyped_3aSiteInfo_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6690d985632b6de7_b13460b3c8232d4b = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLandings_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2emention(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4860703a134569c9_d00fc34d053d5355 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2edeclare(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLastUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_b7d0c4ef23cb16fa_bb49bf88955879a6 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2evalueRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2escalarField(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2euse(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2, i1 %a3)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [1 x i64] } %a2)
@olang_loc_6ff368c26ca3ad9b_74caa00555ca222f = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elendOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etempLent(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePush_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
@olang_loc_c889b00966965144_dcfe1455a200f620 = external constant [0 x i8]
@olang_loc_f1d97b93b21930ce_df2dd3f10bda1132 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2erefLocal(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_572ff0c594eb7d28_3eb561bfca5d9eb4 = external constant [0 x i8]
@olang_loc_6333e3fa20d2f5d8_bcafed7a04540454 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2elet(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eclauses(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, { i64, [1 x i64] } %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2etargets(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_9a2d2471d97215b1_125b5d47933e1fad = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aLocalUses_2eexprRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2dc1351d0e6e1c9_f66be85c5a6693dd = external constant [0 x i8]
@olang_loc_e2587c8ec5c6f861_9513078f5b00021d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e_2eSetAt_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eReachInto(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
@olang_loc_43c6edd5f3ea6aa2_25eece1f43523776 = external constant [0 x i8]
@olang_loc_8a2b699ea2f67509_3bce0390ecfabbdd = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i32 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ePop_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
@olang_loc_a872ad126d8d9744_e4960385d07a8740 = external constant [0 x i8]
@olang_loc_f34031efedf98c99_ae8fa248572091b5 = external constant [0 x i8]
@olang_loc_1baf36c5dd0b9bdd_a2c9e1d98e30c571 = external constant [0 x i8]
@olang_loc_49ff4d0dc0b12b63_5e68d9fa98bc7cb7 = external constant [0 x i8]
@olang_loc_1728180708920569_396f77e53f37dbed = external constant [0 x i8]
@olang_loc_64712ec69db6f686_5286ea6d6f8bc3a = external constant [0 x i8]
@olang_loc_3937948e4172da86_b4226ee484a284a = external constant [0 x i8]
@olang_loc_e2e1378986f13fd0_6a804f95244a4cf4 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_77315c1e1ec03e98_be22ee0dd90c53a4 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2edead(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2erestore(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2esave(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2emeet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eouter(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2, i1 %a3)
@olang_loc_ec88ab62730d3569_72c455660b6c295 = external constant [0 x i8]
@olang_loc_a5a46b672ecbc32_209a020a110ad15e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eClear_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eCle_H9e31dbf06df58c38226424712d120dfe(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eAt_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aVersions_2eaddDef(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, ptr %a4, i1 %a5)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hbd09c84b003bb96b764c8a61b7f32193(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_H5b4ed7dba3fb4e44f8784ebbf4461977(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cI_Hdc84c10e1af960a666eeb267120f3ec3(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_59830ee0ec754a32_f5aff824d93b155e = external constant [0 x i8]
@olang_loc_b8ff85e818b1a126_11cf17c421c4721a = external constant [0 x i8]
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
@G_2ecompiler_2ftyped_2eViewBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\3E\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_996d81e577c7faae_f3b4a025cf703a = external constant [0 x i8]
declare ptr @compiler_2ftyped_2ecopied(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eRoots(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2eparamBit(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_34c65fd26df9bfcd_2dc4d2164b9a2f69 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2emeetRoots(i64 %a0, i64 %a1)
@olang_loc_dd6dc40ab752fedf_c333d42519625383 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2ecompiler_2ftyped_3aViewWalk_2elocalRoots(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_38f82f633fcbfe78_2a415e18f8868a4c = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ePassesRefs(i32 %a0)
@olang_loc_859ef9a416eafd63_e1a98b601ef27d27 = external constant [0 x i8]
@olang_loc_21fa85d53b5eac7b_5a0125da6c5c013f = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eleave(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_17c315ca28f40c4c_14b80e258f8c2b0 = external constant [0 x i8]
@olang_loc_db2d0e7e8bf65551_fc4da676f7c58ce5 = external constant [0 x i8]
@olang_loc_6fe9eb3ff5642bc1_33392e6f48613205 = external constant [0 x i8]
@olang_loc_5f1ddc7ef7469727_e10177d23ca0510b = external constant [0 x i8]
@olang_loc_24a3ccdd47c97c70_8558c77bc7af118c = external constant [0 x i8]
@olang_loc_130a89b2782f12a5_38e9334e27b56d91 = external constant [0 x i8]
@olang_loc_1916e27cc0da8fc5_b948d7408e366d01 = external constant [0 x i8]
@olang_loc_567e5689d7ac5ccb_d57870be630e767 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ecall(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eexprs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2eloop(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2efailHere(ptr %v0, ptr %a0, i1 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejoin(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ematch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2etry(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e0d071190e38de5d_291e4ea72946f179 = external constant [0 x i8]
@olang_loc_d40841e1665d5bac_305352f22a4532a8 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
@olang_loc_c1faed4ae36d3640_1d7aa47a4727493c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3adropWalk_2ejump(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_43e833e67406aee2_76f2107f4f2989fe = external constant [0 x i8]
@olang_loc_ee90b64eb208d194_3ee30fc86ac20510 = external constant [0 x i8]
@olang_loc_adeeaf8d66de5e9_765e2536cff45a05 = external constant [0 x i8]
@olang_loc_735ea97a101db8a9_ef46e9a3f6738c65 = external constant [0 x i8]
@olang_loc_720a79c775c6eb2f_4e77fac288b2d7ab = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2etyped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eclosure(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReachesWrite(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eheld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcd1867a2c89de03c7af27b93b5b476d9(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_2fe17ed863e993f3_a4fd95e432e2de7 = external constant [0 x i8]
@olang_loc_2b0ce19cf8abfa0_63d28338a0667b94 = external constant [0 x i8]
@olang_loc_231c306bfae66ae8_f9a103d13bf0009c = external constant [0 x i8]
@olang_loc_60c7f079a8f50056_f0211a32bac11e1a = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2ematch(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2efnVal(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_7e259cde601a72ba_d3d8f3b52bf79a7e = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregistered(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eregister(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePush_3cArray_3cI64_3e_3e(ptr %v0, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_3e_2ePop_3cArray_3cI64_3e_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_96ed7c0737fb007f_bcf36b4956f76d4b = external constant [0 x i8]
@olang_loc_eee80033d1164c3c_3495c4b80935428 = external constant [0 x i8]
@olang_loc_d52aab1c9c36d4_17087f4c711c4240 = external constant [0 x i8]
@olang_loc_fe54fd99e9902812_25d1b4e50c46612e = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %a0)
@olang_loc_5e6c689502ae97a3_4a93e9b8e1d69347 = external constant [0 x i8]
@olang_loc_b6b3adf054eb2e90_3f1400959d6043b4 = external constant [0 x i8]
@olang_loc_7b8fc3b9339208b8_2c51799eb4e60e7c = external constant [0 x i8]
@olang_loc_47bf7dbda354986_81bfc8ef2d8843ba = external constant [0 x i8]
@olang_loc_3ca74cad4df58772_2fc4655d37cc5656 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2estTy(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRefInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aholdWalk_2eadd(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2eexprLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1807395182923f6f_ecff5ea7ed15d953 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aleaveWalk_2estmtLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @compiler_2ftyped_2ecompiler_2ftyped_3aprinter_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_16612f18a9afa54d_299c1e15a68a5059 = external constant [0 x i8]
declare i64 @compiler_2ftyped_2eDropHolder(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4baf654831ed8d80_eee61e02aec284c4 = external constant [0 x i8]
@olang_loc_f3eab8194bd11e66_e0240e140d7ed92a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eholdsWritableRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2elistHoldsWritable(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eexprBreaks(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fc8cc15dada93547_2e2c8c126dc2f08b = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2eLen_3ccompiler_2ftyped_3aBlockId_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_942c69358f77327c_b8abecb88c811c88 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eplaceBreaks(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eclausesBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
declare i1 @compiler_2ftyped_2etargetsBreak(ptr %v0, { i64, ptr } %a0, i32 %a1)
@olang_loc_ab0bd1a1cb525619_8191fed8583864ed = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aBlockId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
