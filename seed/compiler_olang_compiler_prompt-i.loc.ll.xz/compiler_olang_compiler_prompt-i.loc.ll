; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3f3bc101190353f2_26f746d3af9ade56 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_4fc39c8d8d28436_673e50bbc924552a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_78ddbf306d67d33d_b84f185edfa21af1 = weak_odr constant [54 x i8] c"std/prelude/map.olang:122: array length out of range\0A\00"
@olang_loc_aa8941cf4bee6004_4844088c08deeac8 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_bf9b043839607ab3_dacd54bb811ad2f = weak_odr constant [54 x i8] c"std/prelude/map.olang:102: slice bounds out of range\0A\00"
@olang_loc_c031e2555dd50556_a2d5d39ecda034b2 = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: slice bounds out of range\0A\00"
@olang_loc_ede795e8e037ede5_beb49384ccaaa231 = weak_odr constant [54 x i8] c"std/prelude/map.olang:111: array length out of range\0A\00"
