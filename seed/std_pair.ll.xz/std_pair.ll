; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"std/pair:Pair<I32, std/prelude/text:String&>" = type { i32, { i64, ptr } }
@G_2estd_2fpair_2ePairOfTextBaked = global i1 zeroinitializer
define dso_local void @olang_2einit_2estd_2fpair() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fpair_2ePairOfTextBaked_2einit()
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fpair_2ePairOfTextBaked_2einit() #0 {
entry:
  %l0 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @std_2fpair_2epairOfText(i32 0)
  store i1 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i1, ptr %l0
  store i1 %t2, ptr @G_2estd_2fpair_2ePairOfTextBaked
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fpair_2epairOfText(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"std/pair:Pair<I32, std/prelude/text:String&>"
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/pair:Pair<I32, std/prelude/text:String&>"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca %"std/pair:Pair<I32, std/prelude/text:String&>"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/pair:Pair<I32, std/prelude/text:String&>"
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l4
  %t2 = load i32, ptr %l4
  %t3 = add i32 1, %t2
  store i32 %t3, ptr %l5
  %t4 = load i32, ptr %l5
  %t5 = call %"std/pair:Pair<I32, std/prelude/text:String&>" @std_2fpair_3aPair_3cI32_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, ptr %s0, i32 %t4, { i64, ptr } { i64 1, ptr @.d0 })
  store %"std/pair:Pair<I32, std/prelude/text:String&>" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load %"std/pair:Pair<I32, std/prelude/text:String&>", ptr %l6
  store %"std/pair:Pair<I32, std/prelude/text:String&>" %t6, ptr %l1
  store { i64, ptr } { i64 2, ptr @.d1 }, ptr %l7
  %t7 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t7, ptr %l8
  %t8 = load { i64, ptr }, ptr %l8
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l9
  %t10 = load i64, ptr %l9
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l10
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  %t19 = load i64, ptr %l9
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t21, ptr %l2
  %t22 = load i32, ptr %l0
  store i32 %t22, ptr %l11
  %t23 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t23, ptr %l12
  %t24 = load i32, ptr %l11
  %t25 = load { i64, ptr }, ptr %l12
  %t26 = call %"std/pair:Pair<I32, std/prelude/text:String&>" @std_2fpair_3aPair_3cI32_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, ptr %s0, i32 %t24, { i64, ptr } %t25)
  store %"std/pair:Pair<I32, std/prelude/text:String&>" %t26, ptr %l13
  br label %bb2
bb2:
  %t27 = load %"std/pair:Pair<I32, std/prelude/text:String&>", ptr %l13
  store %"std/pair:Pair<I32, std/prelude/text:String&>" %t27, ptr %l3
  %t28 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  %t30 = getelementptr i8, ptr %t29, i64 0
  store i8 122, ptr %t30
  %t31 = getelementptr %"std/pair:Pair<I32, std/prelude/text:String&>", ptr %l1, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31
  store { i64, ptr } %t32, ptr %l14
  %t33 = load { i64, ptr }, ptr %l14
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 1, ptr @.d2 })
  store i1 %t34, ptr %l15
  br label %bb3
bb3:
  %t35 = load i1, ptr %l15
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t36 = getelementptr %"std/pair:Pair<I32, std/prelude/text:String&>", ptr %l3, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36
  store { i64, ptr } %t37, ptr %l17
  %t38 = load { i64, ptr }, ptr %l17
  %t39 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t38, { i64, ptr } { i64 2, ptr @.d3 })
  store i1 %t39, ptr %l18
  br label %bb6
bb5:
  store i1 false, ptr %l16
  br label %bb7
bb6:
  %t40 = load i1, ptr %l18
  store i1 %t40, ptr %l16
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l16
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_scope_close(ptr)
@.d0 = private constant [1 x i8] c"x"
@.d1 = private constant [2 x i8] c"ab"
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant [1 x i8] c"x"
@.d3 = private constant [2 x i8] c"zb"
declare %"std/pair:Pair<I32, std/prelude/text:String&>" @std_2fpair_3aPair_3cI32_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
