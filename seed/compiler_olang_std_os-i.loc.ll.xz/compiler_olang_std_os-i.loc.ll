; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_2431ff86e0d3474d_a0bb781bcb02eb79 = weak_odr constant [56 x i8] c"std/prelude/array.olang:265: array length out of range\0A\00"
@olang_loc_3d3d06b97b9ec6df_f3ec63d915fe66ab = weak_odr constant [56 x i8] c"std/prelude/array.olang:234: slice bounds out of range\0A\00"
@olang_loc_c9c09b06fcbd774a_f45ee1c9959a1c2e = weak_odr constant [56 x i8] c"std/prelude/array.olang:229: array length out of range\0A\00"
