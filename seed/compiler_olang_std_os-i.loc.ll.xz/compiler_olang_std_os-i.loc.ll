; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_32b4dd57063daccc_20299270f57c1810 = weak_odr constant [56 x i8] c"std/prelude/array.olang:270: array length out of range\0A\00"
@olang_loc_bd57bfee552aaf80_4db8901b79077054 = weak_odr constant [56 x i8] c"std/prelude/array.olang:239: slice bounds out of range\0A\00"
@olang_loc_f5954356a94cfd1d_57c8a908dd11d469 = weak_odr constant [56 x i8] c"std/prelude/array.olang:234: array length out of range\0A\00"
