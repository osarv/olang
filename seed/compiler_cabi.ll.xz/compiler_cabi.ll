; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cabi:Way" = type { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/cabi:Scalar" = type { i64, i64, { i64, ptr }, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cabi:Regs" = type { i64, i64 }
define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/cabi:Scalar"
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca %"compiler/cabi:Scalar"
  %l40 = alloca { { i64, ptr }, i64 }
  %l42 = alloca i64
  %l45 = alloca i64
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca i1
  %l56 = alloca i64
  %l58 = alloca i1
  %l60 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i32
  %l76 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca i64
  %l84 = alloca %"compiler/cabi:Scalar"
  %l94 = alloca %"compiler/cabi:Scalar"
  %l97 = alloca %"std/prelude/text:StringBuilder"
  %l100 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l133 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l138 = alloca i64
  %l143 = alloca ptr
  %l145 = alloca i64
  %l147 = alloca %"compiler/cabi:Scalar"
  %l154 = alloca %"compiler/cabi:Way"
  %l158 = alloca i32
  %l164 = alloca %"compiler/cabi:Way"
  %l167 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l176 = alloca ptr
  %l178 = alloca i64
  %l187 = alloca %"compiler/cabi:Way"
  %l190 = alloca i1
  %l194 = alloca i32
  %l200 = alloca %"compiler/cabi:Way"
  %l207 = alloca i64
  %l210 = alloca i64
  %l233 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca i32
  %l246 = alloca { i64, ptr }
  %l252 = alloca i1
  %l266 = alloca { { i64, ptr }, i64 }
  %l269 = alloca { { i64, ptr }, i64 }
  %l273 = alloca { { i64, ptr }, i64 }
  %l274 = alloca { i64, ptr }
  %l275 = alloca i64
  %l276 = alloca { i64, ptr }
  %l292 = alloca %"compiler/cabi:Way"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l45
  br label %bb1
bb1:
  %t6 = load i64, ptr %l45, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l46
  br label %bb2
bb2:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l5
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %s0, ptr %t10, i32 %t11, i64 0, ptr %l5)
  br label %bb3
bb3:
  %t15 = load ptr, ptr @__olang_prog_scope
  %t16 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t15)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l50
  br label %bb4
bb4:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t17, ptr %lp6
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  %t19 = load ptr, ptr %lp6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %t19
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t20)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l51
  br label %bb5
bb5:
  %t22 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t22, ptr %lp7
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  %t24 = load ptr, ptr %lp7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %t24
  %t25 = load ptr, ptr @__olang_prog_scope
  %t26 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t25)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l52
  br label %bb6
bb6:
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t27, ptr %lp8
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  %t29 = load ptr, ptr %lp8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %t29
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } { i64 7, ptr @.d0 })
  store i1 %t32, ptr %l54
  br label %bb7
bb7:
  %t33 = load i1, ptr %l54, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t35 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t35, ptr %l56
  br label %bb10
bb9:
  br label %bb96
bb10:
  %t36 = load i64, ptr %l56, !tbaa !24
  %t37 = icmp sge i64 %t36, 1
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t40 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t40, ptr %l60
  br label %bb13
bb12:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb14
bb13:
  %t41 = load i64, ptr %l60, !tbaa !24
  %t42 = icmp sle i64 %t41, 4
  store i1 %t42, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t44 = load i1, ptr %l58, !tbaa !21
  store i1 %t44, ptr %l9, !tbaa !21
  store ptr %l5, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = load ptr, ptr %l10, !tbaa !29
  %t47 = load i64, ptr %l11, !tbaa !24
  %t50 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eRunFrom_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, { i64, ptr } } %t50, 1
  %t52 = extractvalue { i32, { i64, ptr } } %t50, 0
  store i32 %t52, ptr %l67
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54
ok.54:
  store { i64, ptr } %t51, ptr %l66
  br label %bb16
bb16:
  %t55 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t55, ptr %l63, !tbaa !27
  br label %bb21
bb17:
  %t56 = load i32, ptr %l67, !tbaa !23
  %t57 = ashr i32 %t56, 16
  %t59 = icmp eq i32 %t57, 1
  br i1 %t59, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_79829e3e8c3b3142_ec3a884d14270446)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb21:
  %t61 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t61, ptr %l12, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  store i64 %t64, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load i64, ptr %l14, !tbaa !24
  %t67 = load i64, ptr %l13, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb24:
  br label %bb25
bb25:
  %t74 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t74, ptr %l76, !tbaa !27
  %t75 = load i64, ptr %l14, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"compiler/cabi:Scalar", ptr %t78, i64 %t75
  %t80 = load %"compiler/cabi:Scalar", ptr %t79
  store %"compiler/cabi:Scalar" %t80, ptr %l15
  %t82 = getelementptr %"compiler/cabi:Scalar", ptr %l15, i32 0, i32 3
  %t83 = load i1, ptr %t82, !tbaa !21
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb29
bb27:
  %t87 = getelementptr %"compiler/cabi:Scalar", ptr %l15, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  store i64 %t88, ptr %l82, !tbaa !24
  %t90 = call %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s4, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t90, ptr %l84
  br label %bb28
bb28:
  %t91 = getelementptr %"compiler/cabi:Scalar", ptr %l84, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = load i64, ptr %l82, !tbaa !24
  %t95 = icmp ne i64 %t93, %t92
  store i1 %t95, ptr %l81, !tbaa !21
  br label %bb29
bb29:
  %t97 = load i1, ptr %l81, !tbaa !21
  br i1 %t97, label %bb30, label %bb31
bb30:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  %t98 = load i64, ptr %l14, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l14, !tbaa !24
  br label %bb22
bb34:
  %t102 = load i64, ptr %l11, !tbaa !24
  %t103 = load i64, ptr %l13, !tbaa !24
  %t106 = add i64 %t102, %t103
  store i64 %t106, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  br label %bb15
bb36:
  %t108 = load i1, ptr %l9, !tbaa !21
  br i1 %t108, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t111 = call %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t111, ptr %l94
  br label %bb39
bb38:
  br label %bb73
bb39:
  %t112 = getelementptr %"compiler/cabi:Scalar", ptr %l94, i32 0, i32 2
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l16, !tbaa !27
  %t115 = load i1, ptr %l3, !tbaa !21
  br i1 %t115, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t117 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s8)
  store %"std/prelude/text:StringBuilder" %t117, ptr %l97
  br label %bb42
bb41:
  %t118 = load ptr, ptr %lp6
  store ptr %t118, ptr %l136, !tbaa !29
  %t120 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t120, ptr %l138
  br label %bb65
bb42:
  %t121 = load %"std/prelude/text:StringBuilder", ptr %l97
  store %"std/prelude/text:StringBuilder" %t121, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s8, ptr %s8, ptr %l17, { i64, ptr } { i64 2, ptr @.d1 })
  br label %bb43
bb43:
  store i64 0, ptr %l18, !tbaa !24
  %t124 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t124, ptr %l100
  br label %bb44
bb44:
  %t125 = load i64, ptr %l100, !tbaa !24
  store i64 %t125, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t126 = load i64, ptr %l19, !tbaa !24
  %t127 = load i64, ptr %l18, !tbaa !24
  %t130 = icmp sgt i64 %t126, %t127
  br i1 %t130, label %bb45, label %bb46
bb45:
  %t132 = load i64, ptr %l20, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb50
bb47:
  %t136 = load i64, ptr %l19, !tbaa !24
  %t137 = load i64, ptr %l18, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l20, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l20, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l107, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb49
bb49:
  %t152 = load i64, ptr %l107, !tbaa !24
  store i64 %t152, ptr %l104, !tbaa !24
  br label %bb50
bb50:
  %t153 = load i64, ptr %l104, !tbaa !24
  store i64 %t153, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t154 = load i64, ptr %l22, !tbaa !24
  %t155 = load i64, ptr %l21, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb53:
  br label %bb54
bb54:
  %t162 = load i64, ptr %l18, !tbaa !24
  %t163 = load i64, ptr %l22, !tbaa !24
  %t164 = load i64, ptr %l20, !tbaa !24
  %t167 = mul i64 %t163, %t164
  %t170 = add i64 %t162, %t167
  %t174 = icmp sgt i64 %t170, 0
  br i1 %t174, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s8, ptr %s11, ptr %l17, { i64, ptr } { i64 2, ptr @.d2 })
  br label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t177 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s8, ptr %s0, ptr %l17, { i64, ptr } %t177)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  br label %bb60
bb60:
  %t180 = load i64, ptr %l22, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l22, !tbaa !24
  br label %bb51
bb61:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s8, ptr %s8, ptr %l17, { i64, ptr } { i64 2, ptr @.d3 })
  br label %bb62
bb62:
  %t185 = load ptr, ptr %lp6
  store ptr %t185, ptr %l133, !tbaa !29
  %t187 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s8, ptr %v2, ptr %l17)
  store { i64, ptr } %t187, ptr %l135
  br label %bb63
bb63:
  %t188 = load ptr, ptr %l133, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l135, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t188, { i64, ptr } %t189)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s8)
  br label %bb67
bb65:
  %t190 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 1
  %t192 = extractvalue { i64, ptr } { i64 1, ptr @.d4 }, 0
  %t193 = load i64, ptr %l138, !tbaa !24
  %t194 = call i64 @__olang_fmt_i64(ptr null, i64 %t193)
  %t195 = add i64 %t192, %t194
  %t196 = extractvalue { i64, ptr } { i64 3, ptr @.d5 }, 1
  %t197 = extractvalue { i64, ptr } { i64 3, ptr @.d5 }, 0
  %t198 = add i64 %t195, %t197
  %t200 = extractvalue { i64, ptr } %t190, 1
  %t201 = extractvalue { i64, ptr } %t190, 0
  %t202 = add i64 %t198, %t201
  %t203 = extractvalue { i64, ptr } { i64 15, ptr @.d6 }, 1
  %t204 = extractvalue { i64, ptr } { i64 15, ptr @.d6 }, 0
  %t205 = add i64 %t202, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t191, i64 %t192)
  %t207 = getelementptr i8, ptr %t206, i64 %t192
  %t208 = call i64 @__olang_fmt_i64(ptr %t207, i64 %t193)
  %t209 = getelementptr i8, ptr %t207, i64 %t194
  call void @olang_textcopy(ptr %t209, ptr %t196, i64 %t197)
  %t210 = getelementptr i8, ptr %t209, i64 %t197
  call void @olang_textcopy(ptr %t210, ptr %t200, i64 %t201)
  %t211 = getelementptr i8, ptr %t210, i64 %t201
  call void @olang_textcopy(ptr %t211, ptr %t203, i64 %t204)
  %t212 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t206, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = mul i64 %t215, 1
  %t218 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t217)
  call void @llvm.memcpy.p0.p0.i64(ptr %t218, ptr %t216, i64 %t217, i1 false)
  %t219 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t218, 1
  %t221 = load ptr, ptr %l136, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t221, { i64, ptr } %t220)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t223 = load ptr, ptr %lp7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t223, i64 0)
  br label %bb68
bb68:
  %t225 = load ptr, ptr %lp8
  store ptr %t225, ptr %l143, !tbaa !29
  %t227 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t227, ptr %l145
  br label %bb69
bb69:
  %t229 = call %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s7, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t229, ptr %l147
  br label %bb70
bb70:
  %t230 = getelementptr %"compiler/cabi:Scalar", ptr %l147, i32 0, i32 1
  %t231 = load i64, ptr %t230, !tbaa !24
  %t232 = load i64, ptr %l145, !tbaa !24
  %t234 = mul i64 %t232, %t231
  %t235 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t235, i64 %t234)
  br label %bb71
bb71:
  %t237 = load ptr, ptr %lp6
  %t238 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t237
  %t239 = load ptr, ptr %lp7
  %t240 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t239
  %t241 = load ptr, ptr %lp8
  %t242 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t241
  %t247 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t238, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t242, { i64, ptr } { i64 0, ptr @.d7 })
  store %"compiler/cabi:Way" %t247, ptr %l154
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t248 = load %"compiler/cabi:Way", ptr %l154
  store %"compiler/cabi:Way" %t248, ptr %rv
  br label %ret
bb73:
  %t249 = load i64, ptr %l4, !tbaa !24
  %t251 = icmp sgt i64 %t249, 16
  br i1 %t251, label %bb74, label %bb75
bb74:
  %t253 = load i1, ptr %l3, !tbaa !21
  br i1 %t253, label %bb76, label %bb77
bb75:
  br label %bb80
bb76:
  store i32 4, ptr %l158
  br label %bb78
bb77:
  store i32 3, ptr %l158
  br label %bb78
bb78:
  %t257 = load ptr, ptr %lp6
  %t258 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t257
  %t259 = load ptr, ptr %lp7
  %t260 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t259
  %t261 = load ptr, ptr %lp8
  %t262 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t261
  %t263 = load i32, ptr %l158
  %t267 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t263, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t258, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t260, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t262, { i64, ptr } { i64 0, ptr @.d8 })
  store %"compiler/cabi:Way" %t267, ptr %l164
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s0)
  %t268 = load %"compiler/cabi:Way", ptr %l164
  store %"compiler/cabi:Way" %t268, ptr %rv
  br label %ret
bb80:
  %t269 = load i64, ptr %l4, !tbaa !24
  %t271 = icmp sle i64 %t269, 8
  br i1 %t271, label %bb81, label %bb82
bb81:
  %t273 = load ptr, ptr %lp6
  store ptr %t273, ptr %l167, !tbaa !29
  %t274 = load i1, ptr %l3, !tbaa !21
  br i1 %t274, label %bb83, label %bb84
bb82:
  %t276 = load ptr, ptr %lp6
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t276, { i64, ptr } { i64 9, ptr @.d9 })
  br label %bb91
bb83:
  %t278 = load i64, ptr %l4, !tbaa !24
  %t280 = mul i64 %t278, 8
  %t281 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 1
  %t282 = extractvalue { i64, ptr } { i64 1, ptr @.d10 }, 0
  %t284 = call i64 @__olang_fmt_i64(ptr null, i64 %t280)
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t281, i64 %t282)
  %t287 = getelementptr i8, ptr %t286, i64 %t282
  %t288 = call i64 @__olang_fmt_i64(ptr %t287, i64 %t280)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t286, 1
  store { i64, ptr } %t290, ptr %l169, !tbaa !27
  br label %bb85
bb84:
  store { i64, ptr } { i64 3, ptr @.d11 }, ptr %l173, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t292, ptr %l169, !tbaa !27
  br label %bb85
bb85:
  %t294 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  %t296 = extractvalue { i64, ptr } %t294, 1
  %t297 = mul i64 %t295, 1
  %t298 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t298, ptr %t296, i64 %t297, i1 false)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t301 = load ptr, ptr %l167, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t301, { i64, ptr } %t300)
  br label %bb86
bb86:
  %t303 = load ptr, ptr %lp8
  store ptr %t303, ptr %l176, !tbaa !29
  %t304 = load i1, ptr %l3, !tbaa !21
  br i1 %t304, label %bb87, label %bb88
bb87:
  %t306 = load i64, ptr %l4, !tbaa !24
  store i64 %t306, ptr %l178, !tbaa !24
  br label %bb89
bb88:
  store i64 8, ptr %l178, !tbaa !24
  br label %bb89
bb89:
  %t308 = load ptr, ptr %l176, !tbaa !29
  %t309 = load i64, ptr %l178, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t308, i64 %t309)
  br label %bb90
bb90:
  br label %bb93
bb91:
  %t310 = load ptr, ptr %lp8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t310, i64 16)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t312 = load ptr, ptr %lp7
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t312, i64 0)
  br label %bb94
bb94:
  %t314 = load ptr, ptr %lp6
  %t315 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t314
  %t316 = load ptr, ptr %lp7
  %t317 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t316
  %t318 = load ptr, ptr %lp8
  %t319 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t318
  %t324 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t315, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t317, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t319, { i64, ptr } { i64 0, ptr @.d12 })
  store %"compiler/cabi:Way" %t324, ptr %l187
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s0)
  %t325 = load %"compiler/cabi:Way", ptr %l187
  store %"compiler/cabi:Way" %t325, ptr %rv
  br label %ret
bb96:
  %t326 = load i64, ptr %l4, !tbaa !24
  %t328 = icmp sgt i64 %t326, 16
  br i1 %t328, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb99
bb98:
  %t330 = load i64, ptr %l4, !tbaa !24
  %t332 = icmp eq i64 %t330, 0
  store i1 %t332, ptr %l190, !tbaa !21
  br label %bb99
bb99:
  %t334 = load i1, ptr %l190, !tbaa !21
  br i1 %t334, label %bb100, label %bb101
bb100:
  %t335 = load i1, ptr %l3, !tbaa !21
  br i1 %t335, label %bb102, label %bb103
bb101:
  br label %bb106
bb102:
  store i32 4, ptr %l194
  br label %bb104
bb103:
  store i32 2, ptr %l194
  br label %bb104
bb104:
  %t339 = load ptr, ptr %lp6
  %t340 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t339
  %t341 = load ptr, ptr %lp7
  %t342 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t341
  %t343 = load ptr, ptr %lp8
  %t344 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t343
  %t345 = load i32, ptr %l194
  %t349 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t345, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t340, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t342, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t344, { i64, ptr } { i64 0, ptr @.d13 })
  store %"compiler/cabi:Way" %t349, ptr %l200
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s0)
  %t350 = load %"compiler/cabi:Way", ptr %l200
  store %"compiler/cabi:Way" %t350, ptr %rv
  br label %ret
bb106:
  store i64 0, ptr %l24, !tbaa !24
  %t351 = load i64, ptr %l4, !tbaa !24
  %t353 = add i64 %t351, 7
  %t355 = sdiv i64 %t353, 8
  store i64 %t355, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t357 = load i64, ptr %l25, !tbaa !24
  %t358 = load i64, ptr %l24, !tbaa !24
  %t361 = icmp sgt i64 %t357, %t358
  br i1 %t361, label %bb107, label %bb108
bb107:
  %t363 = load i64, ptr %l26, !tbaa !24
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb109, label %bb110
bb108:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb112
bb109:
  %t367 = load i64, ptr %l25, !tbaa !24
  %t368 = load i64, ptr %l24, !tbaa !24
  %t371 = sub i64 %t367, %t368
  %t372 = load i64, ptr %l26, !tbaa !24
  %t375 = add i64 %t371, %t372
  %t377 = sub i64 %t375, 1
  %t378 = load i64, ptr %l26, !tbaa !24
  %t381 = sdiv i64 %t377, %t378
  store i64 %t381, ptr %l210, !tbaa !24
  br label %bb111
bb110:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb111
bb111:
  %t383 = load i64, ptr %l210, !tbaa !24
  store i64 %t383, ptr %l207, !tbaa !24
  br label %bb112
bb112:
  %t384 = load i64, ptr %l207, !tbaa !24
  store i64 %t384, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  store %olang.scope zeroinitializer, ptr %s21
  %t385 = load i64, ptr %l28, !tbaa !24
  %t386 = load i64, ptr %l27, !tbaa !24
  %t389 = icmp slt i64 %t385, %t386
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s21)
  br label %bb153
bb115:
  br label %bb116
bb116:
  %t393 = load i64, ptr %l24, !tbaa !24
  %t394 = load i64, ptr %l28, !tbaa !24
  %t395 = load i64, ptr %l26, !tbaa !24
  %t398 = mul i64 %t394, %t395
  %t401 = add i64 %t393, %t398
  %t405 = mul i64 %t401, 8
  store i64 %t405, ptr %l30, !tbaa !24
  %t407 = load i64, ptr %l30, !tbaa !24
  %t409 = add i64 %t407, 8
  store i64 %t409, ptr %l31, !tbaa !24
  store i1 true, ptr %l32, !tbaa !21
  store i1 false, ptr %l33, !tbaa !21
  store ptr %l5, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb117
bb117:
  store %olang.scope zeroinitializer, ptr %s23
  %t412 = load ptr, ptr %l34, !tbaa !29
  %t413 = load i64, ptr %l35, !tbaa !24
  %t416 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eRunFrom_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t412, i64 %t413)
  %t417 = extractvalue { i32, { i64, ptr } } %t416, 1
  %t418 = extractvalue { i32, { i64, ptr } } %t416, 0
  store i32 %t418, ptr %l237
  %t419 = icmp ne i32 %t418, 0
  br i1 %t419, label %bb119, label %ok.420
ok.420:
  store { i64, ptr } %t417, ptr %l236
  br label %bb118
bb118:
  %t421 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t421, ptr %l233, !tbaa !27
  br label %bb123
bb119:
  %t422 = load i32, ptr %l237, !tbaa !23
  %t423 = ashr i32 %t422, 16
  %t425 = icmp eq i32 %t423, 1
  br i1 %t425, label %bb120, label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_b57f445a57eb78c3_b306b1059f9e7a27)
  unreachable
bb122:
  call void @__olang_scope_close(ptr %s23)
  br label %bb140
bb123:
  %t427 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t427, ptr %l36, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  store i64 %t430, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb124
bb124:
  store %olang.scope zeroinitializer, ptr %s24
  %t432 = load i64, ptr %l38, !tbaa !24
  %t433 = load i64, ptr %l37, !tbaa !24
  %t436 = icmp slt i64 %t432, %t433
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb125, label %bb126
bb125:
  call void @__olang_scope_close(ptr %s24)
  br label %bb138
bb126:
  br label %bb127
bb127:
  %t440 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t440, ptr %l246, !tbaa !27
  %t441 = load i64, ptr %l38, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr %"compiler/cabi:Scalar", ptr %t444, i64 %t441
  %t446 = load %"compiler/cabi:Scalar", ptr %t445
  store %"compiler/cabi:Scalar" %t446, ptr %l39
  %t448 = getelementptr %"compiler/cabi:Scalar", ptr %l39, i32 0, i32 0
  %t449 = load i64, ptr %t448, !tbaa !24
  %t450 = load i64, ptr %l30, !tbaa !24
  %t453 = icmp sge i64 %t449, %t450
  br i1 %t453, label %bb128, label %bb129
bb128:
  %t455 = getelementptr %"compiler/cabi:Scalar", ptr %l39, i32 0, i32 0
  %t456 = load i64, ptr %t455, !tbaa !24
  %t457 = load i64, ptr %l31, !tbaa !24
  %t460 = icmp slt i64 %t456, %t457
  store i1 %t460, ptr %l252, !tbaa !21
  br label %bb130
bb129:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb130
bb130:
  %t462 = load i1, ptr %l252, !tbaa !21
  br i1 %t462, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l33, !tbaa !21
  %t463 = getelementptr %"compiler/cabi:Scalar", ptr %l39, i32 0, i32 3
  %t464 = load i1, ptr %t463, !tbaa !21
  %t466 = xor i1 %t464, true
  br i1 %t466, label %bb133, label %bb134
bb132:
  br label %bb136
bb133:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb135
bb134:
  br label %bb135
bb135:
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s24)
  br label %bb137
bb137:
  %t468 = load i64, ptr %l38, !tbaa !24
  %t470 = add i64 %t468, 1
  store i64 %t470, ptr %l38, !tbaa !24
  br label %bb124
bb138:
  %t472 = load i64, ptr %l35, !tbaa !24
  %t473 = load i64, ptr %l37, !tbaa !24
  %t476 = add i64 %t472, %t473
  store i64 %t476, ptr %l35, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb139
bb139:
  br label %bb117
bb140:
  %t478 = load i1, ptr %l33, !tbaa !21
  %t480 = xor i1 %t478, true
  br i1 %t480, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s21)
  br label %bb152
bb142:
  br label %bb143
bb143:
  %t482 = load i1, ptr %l32, !tbaa !21
  br i1 %t482, label %bb144, label %bb145
bb144:
  %t484 = load i64, ptr %l30, !tbaa !24
  %t487 = call { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %s0, ptr %s21, ptr %l5, i64 %t484)
  store { { i64, ptr }, i64 } %t487, ptr %l269
  br label %bb146
bb145:
  %t488 = load i64, ptr %l30, !tbaa !24
  %t489 = load i64, ptr %l4, !tbaa !24
  %t493 = call { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %s0, ptr %s21, ptr %l5, i64 %t488, i64 %t489)
  store { { i64, ptr }, i64 } %t493, ptr %l273
  br label %bb147
bb146:
  %t494 = load { { i64, ptr }, i64 }, ptr %l269
  store { { i64, ptr }, i64 } %t494, ptr %l266
  br label %bb148
bb147:
  %t495 = load { { i64, ptr }, i64 }, ptr %l273
  store { { i64, ptr }, i64 } %t495, ptr %l266
  br label %bb148
bb148:
  %t496 = load { { i64, ptr }, i64 }, ptr %l266
  store { { i64, ptr }, i64 } %t496, ptr %l40
  %t497 = getelementptr { { i64, ptr }, i64 }, ptr %l40, i32 0, i32 0
  %t498 = load { i64, ptr }, ptr %t497, !tbaa !27
  store { i64, ptr } %t498, ptr %l274, !tbaa !27
  %t499 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t499, 0
  store i64 %t500, ptr %l275, !tbaa !24
  %t501 = load i64, ptr %l275, !tbaa !24
  %t502 = mul i64 %t501, 1
  %t503 = call ptr @__olang_scope_alloc_zeroed(ptr %s21, i64 %t502)
  %t504 = insertvalue { i64, ptr } undef, i64 %t501, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t503, 1
  store { i64, ptr } %t505, ptr %l276, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = load i64, ptr %l275, !tbaa !24
  %t511 = mul i64 %t510, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t507, ptr %t509, i64 %t511, i1 false)
  %t512 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t513 = getelementptr { { i64, ptr }, i64 }, ptr %l40, i32 0, i32 1
  %t514 = load i64, ptr %t513, !tbaa !24
  store i64 %t514, ptr %l42, !tbaa !24
  %t516 = load ptr, ptr %lp6
  %t519 = extractvalue { i64, ptr } %t512, 1
  %t520 = extractvalue { i64, ptr } %t512, 0
  %t521 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t520)
  call void @olang_textcopy(ptr %t521, ptr %t519, i64 %t520)
  %t522 = insertvalue { i64, ptr } undef, i64 %t520, 0
  %t523 = insertvalue { i64, ptr } %t522, ptr %t521, 1
  %t525 = extractvalue { i64, ptr } %t523, 0
  %t526 = extractvalue { i64, ptr } %t523, 1
  %t527 = mul i64 %t525, 1
  %t528 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t527)
  call void @llvm.memcpy.p0.p0.i64(ptr %t528, ptr %t526, i64 %t527, i1 false)
  %t529 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t528, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t516, { i64, ptr } %t530)
  br label %bb149
bb149:
  %t533 = load ptr, ptr %lp7
  %t534 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t533, i64 %t534)
  br label %bb150
bb150:
  %t537 = load ptr, ptr %lp8
  %t538 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t537, i64 %t538)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s21)
  br label %bb152
bb152:
  %t541 = load i64, ptr %l28, !tbaa !24
  %t543 = add i64 %t541, 1
  store i64 %t543, ptr %l28, !tbaa !24
  br label %bb113
bb153:
  %t545 = load ptr, ptr %lp6
  %t546 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t545
  %t547 = load ptr, ptr %lp7
  %t548 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t547
  %t549 = load ptr, ptr %lp8
  %t550 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t549
  %t555 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t546, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t548, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t550, { i64, ptr } { i64 0, ptr @.d14 })
  store %"compiler/cabi:Way" %t555, ptr %l292
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s0)
  %t556 = load %"compiler/cabi:Way", ptr %l292
  store %"compiler/cabi:Way" %t556, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } { i64 6, ptr @.d15 })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d16 }, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %a2)
  store i32 %t27, ptr %l13
  br label %bb5
bb5:
  %t28 = load i32, ptr %l13, !tbaa !23
  store i32 %t28, ptr %l3, !tbaa !23
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr @.d17 }, ptr %l17, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %l18, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l19, !tbaa !24
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l20, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l19, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t49, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l23
  br label %bb9
bb9:
  %t56 = load i1, ptr %l23, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l28
  br label %bb12
bb12:
  %t64 = load i64, ptr %l28, !tbaa !24
  %t65 = icmp sge i64 %t64, 32
  store i1 %t65, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l25, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr @.d18 }, ptr %l30, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l32, !tbaa !24
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l33, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l32, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t82, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l36
  br label %bb17
bb17:
  %t89 = load i1, ptr %l36, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 7, ptr @.d19 }, ptr %l38, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t90, ptr %l37, !tbaa !27
  br label %bb20
bb19:
  store { i64, ptr } { i64 7, ptr @.d20 }, ptr %l40, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t92, ptr %l37, !tbaa !27
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l43, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l42, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t107, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t108 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i32
  %l31 = alloca ptr
  %l33 = alloca %"compiler/cabi:Scalar"
  %l36 = alloca i32
  %l41 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l94 = alloca i32
  %l97 = alloca i1
  %l98 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l118 = alloca i64
  %l121 = alloca i64
  %l140 = alloca { i64, ptr }
  %l152 = alloca i64
  %l156 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i64
  %l164 = alloca i64
  %l167 = alloca { i64, ptr }
  %l170 = alloca i1
  %l171 = alloca %"compiler/cabi:Scalar"
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l25
  br label %bb1
bb1:
  %t6 = load i32, ptr %l25, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l28
  br label %bb2
bb2:
  %t12 = load i32, ptr %l28
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l3, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t18, i64 8, { i64, ptr } { i64 3, ptr @.d21 }, i1 false)
  store %"compiler/cabi:Scalar" %t20, ptr %l33
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l31, !tbaa !29
  %t22 = load %"compiler/cabi:Scalar", ptr %l33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t21, %"compiler/cabi:Scalar" %t22)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l36
  br label %bb8
bb8:
  %t28 = load i32, ptr %l36
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l41
  br label %bb11
bb10:
  br label %bb33
bb11:
  %t38 = load i32, ptr %l41, !tbaa !23
  store i32 %t38, ptr %l5, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l42, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l45
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l42, !tbaa !29
  %t46 = load i32, ptr %l45, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l46
  br label %bb13
bb13:
  %t48 = load i32, ptr %l46
  %t50 = trunc i64 26 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l53
  br label %bb16
bb15:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb18
bb16:
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = load i32, ptr %l53, !tbaa !23
  %t61 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t61, ptr %l54
  br label %bb17
bb17:
  %t62 = load i64, ptr %l54, !tbaa !24
  store i64 %t62, ptr %l49, !tbaa !24
  br label %bb18
bb18:
  %t63 = load i64, ptr %l49, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb24
bb21:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l62, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l62, !tbaa !24
  store i64 %t92, ptr %l59, !tbaa !24
  br label %bb24
bb24:
  %t93 = load i64, ptr %l59, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l80, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  store i32 %t113, ptr %l81, !tbaa !23
  %t114 = load i64, ptr %l2, !tbaa !24
  store i64 %t114, ptr %l82, !tbaa !24
  store i64 %t110, ptr %l83, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t116, i32 %t117)
  store i64 %t120, ptr %l86
  br label %bb29
bb29:
  %t121 = load i64, ptr %l83, !tbaa !24
  %t122 = load i64, ptr %l86, !tbaa !24
  %t123 = mul i64 %t121, %t122
  %t124 = load i64, ptr %l82, !tbaa !24
  %t126 = add i64 %t124, %t123
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load ptr, ptr %l80, !tbaa !29
  %t129 = load i32, ptr %l81, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %t128, i32 %t129, i64 %t126, ptr %t127)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l11, !tbaa !24
  br label %bb25
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l94
  br label %bb34
bb34:
  %t141 = load i32, ptr %l94
  %t143 = trunc i64 18 to i32
  %t144 = icmp eq i32 %t141, %t143
  br i1 %t144, label %bb35, label %bb36
bb35:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l98, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l4, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l101
  br label %bb37
bb36:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb39
bb37:
  %t152 = load ptr, ptr %l98, !tbaa !29
  %t153 = load i32, ptr %l101, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l102
  br label %bb38
bb38:
  %t155 = load i32, ptr %l102
  %t157 = trunc i64 0 to i32
  %t158 = icmp eq i32 %t155, %t157
  store i1 %t158, ptr %l97, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l97, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l105, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l4, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l108
  br label %bb42
bb41:
  br label %bb58
bb42:
  %t167 = load ptr, ptr %l105, !tbaa !29
  %t168 = load i32, ptr %l108, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t167, i32 %t168)
  store { i64, ptr } %t169, ptr %l109
  br label %bb43
bb43:
  %t170 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t170, ptr %l13, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l4, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s6, ptr %t171, i32 %t172)
  store { i64, ptr } %t175, ptr %l112
  br label %bb44
bb44:
  %t176 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t176, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t181 = load i64, ptr %l16, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = icmp sgt i64 %t181, %t182
  br i1 %t185, label %bb45, label %bb46
bb45:
  %t187 = load i64, ptr %l17, !tbaa !24
  %t189 = icmp sgt i64 %t187, 0
  br i1 %t189, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb50
bb47:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = sub i64 %t191, %t192
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = add i64 %t195, %t196
  %t201 = sub i64 %t199, 1
  %t202 = load i64, ptr %l17, !tbaa !24
  %t205 = sdiv i64 %t201, %t202
  store i64 %t205, ptr %l121, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb49
bb49:
  %t207 = load i64, ptr %l121, !tbaa !24
  store i64 %t207, ptr %l118, !tbaa !24
  br label %bb50
bb50:
  %t208 = load i64, ptr %l118, !tbaa !24
  store i64 %t208, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t209 = load i64, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l18, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s8)
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t217 = load i64, ptr %l15, !tbaa !24
  %t218 = load i64, ptr %l19, !tbaa !24
  %t219 = load i64, ptr %l17, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t225 = add i64 %t217, %t222
  store i64 %t225, ptr %l20, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t228, ptr %l140, !tbaa !27
  %t229 = load i64, ptr %l20, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i32, ptr %t232, i64 %t229
  %t234 = load i32, ptr %t233, !tbaa !33
  %t235 = load i64, ptr %l2, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i64, ptr %t239, i64 %t236
  %t241 = load i64, ptr %t240, !tbaa !34
  %t244 = add i64 %t235, %t241
  %t245 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %t227, i32 %t234, i64 %t244, ptr %t245)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t252 = add i64 %t250, 1
  store i64 %t252, ptr %l19, !tbaa !24
  br label %bb51
bb57:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb58:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i32, ptr %l4, !tbaa !23
  %t258 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t254, i32 %t255)
  store i64 %t258, ptr %l152
  br label %bb59
bb59:
  %t259 = load i64, ptr %l152, !tbaa !24
  store i64 %t259, ptr %l21, !tbaa !24
  %t260 = load i32, ptr %l4, !tbaa !23
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t264 = icmp eq i32 %t260, %t261
  br i1 %t264, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 2, ptr @.d22 }, ptr %l156, !tbaa !27
  br label %bb63
bb61:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l4, !tbaa !23
  %t270 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t266, i32 %t267)
  store { i64, ptr } %t270, ptr %l159
  br label %bb62
bb62:
  %t271 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t272, i64 %t273)
  %t275 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = extractvalue { i64, ptr } %t276, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l156, !tbaa !27
  br label %bb63
bb63:
  %t285 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t286 = load ptr, ptr %l3, !tbaa !29
  store ptr %t286, ptr %l162, !tbaa !29
  %t287 = load i64, ptr %l2, !tbaa !24
  store i64 %t287, ptr %l163, !tbaa !24
  %t288 = load i64, ptr %l21, !tbaa !24
  store i64 %t288, ptr %l164, !tbaa !24
  %t291 = extractvalue { i64, ptr } %t285, 1
  %t292 = extractvalue { i64, ptr } %t285, 0
  %t293 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t291, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = extractvalue { i64, ptr } %t295, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l167, !tbaa !27
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l4, !tbaa !23
  %t307 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t303, i32 %t304)
  store i1 %t307, ptr %l170
  br label %bb64
bb64:
  %t308 = load i64, ptr %l163, !tbaa !24
  %t309 = load i64, ptr %l164, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t311 = load i1, ptr %l170, !tbaa !21
  %t312 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t308, i64 %t309, { i64, ptr } %t310, i1 %t311)
  store %"compiler/cabi:Scalar" %t312, ptr %l171
  br label %bb65
bb65:
  %t313 = load ptr, ptr %l162, !tbaa !29
  %t314 = load %"compiler/cabi:Scalar", ptr %l171
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t313, %"compiler/cabi:Scalar" %t314)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i32, ptr %l16
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l11, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca { i64, ptr }
  %l39 = alloca %"compiler/cabi:Way"
  %l43 = alloca %"compiler/cabi:Way"
  %l45 = alloca i1
  %l46 = alloca i1
  %l50 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l81 = alloca i1
  %l86 = alloca i32
  %l87 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"compiler/cabi:Way"
  %l91 = alloca ptr
  %l95 = alloca ptr
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load i1, ptr %l16, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l20
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t14 = load i32, ptr %l20, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t15, i32 %t14)
  store i1 %t19, ptr %l23
  br label %bb5
bb5:
  %t20 = load i1, ptr %l23, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l24, !tbaa !29
  %t22 = load ptr, ptr %l24, !tbaa !29
  %t23 = getelementptr %"compiler/cabi:Regs", ptr %t22, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = sub i64 %t24, 1
  %t28 = load ptr, ptr %l24, !tbaa !29
  %t29 = getelementptr %"compiler/cabi:Regs", ptr %t28, i32 0, i32 1
  store i64 %t26, ptr %t29, !tbaa !24
  br label %bb8
bb7:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l27, !tbaa !29
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = getelementptr %"compiler/cabi:Regs", ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = sub i64 %t33, 1
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = getelementptr %"compiler/cabi:Regs", ptr %t37, i32 0, i32 0
  store i64 %t35, ptr %t38, !tbaa !24
  br label %bb8
bb8:
  store i32 0, ptr %l30
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l31
  br label %bb9
bb9:
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l32
  br label %bb10
bb10:
  %t41 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l33
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = load i32, ptr %l2, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v3, ptr %t42, { i64, ptr } %t43, i32 %t44)
  store { i64, ptr } %t48, ptr %l37
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load i32, ptr %l30
  %t57 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l33
  %t61 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t56, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, { i64, ptr } %t55)
  store %"compiler/cabi:Way" %t61, ptr %l39
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load %"compiler/cabi:Way", ptr %l39
  store %"compiler/cabi:Way" %t62, ptr %rv
  br label %ret
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = load i32, ptr %l2, !tbaa !23
  %t69 = call %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v3, ptr %t63, { i64, ptr } %t64, i32 %t65, i1 false)
  store %"compiler/cabi:Way" %t69, ptr %l43
  br label %bb15
bb15:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store ptr %t70, ptr %lp5
  %t71 = load %"compiler/cabi:Way", ptr %l43
  %t72 = load ptr, ptr %lp5
  store %"compiler/cabi:Way" %t71, ptr %t72
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 6, ptr @.d23 })
  store i1 %t75, ptr %l45
  br label %bb16
bb16:
  %t76 = load i1, ptr %l45, !tbaa !21
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t77 = load ptr, ptr %lp5
  %t78 = getelementptr %"compiler/cabi:Way", ptr %t77, i32 0, i32 0
  %t79 = load i32, ptr %t78
  %t81 = trunc i64 1 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l46, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t85 = load ptr, ptr %lp5
  %t86 = getelementptr %"compiler/cabi:Way", ptr %t85, i32 0, i32 1
  store ptr %t86, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb21:
  br label %bb51
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t88, i64 %t89)
  %t93 = extractvalue { i32, { i64, ptr } } %t92, 1
  %t94 = extractvalue { i32, { i64, ptr } } %t92, 0
  store i32 %t94, ptr %l54
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb24, label %ok.96
ok.96:
  store { i64, ptr } %t93, ptr %l53
  br label %bb23
bb23:
  %t97 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t97, ptr %l50, !tbaa !27
  br label %bb28
bb24:
  %t98 = load i32, ptr %l54, !tbaa !23
  %t99 = ashr i32 %t98, 16
  %t101 = icmp eq i32 %t99, 1
  br i1 %t101, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b020d45a7b7622c7_3ee4736776830c7b)
  unreachable
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb40
bb28:
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t103, ptr %l10, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t108 = load i64, ptr %l12, !tbaa !24
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s7)
  br label %bb38
bb31:
  br label %bb32
bb32:
  %t116 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t116, ptr %l63, !tbaa !27
  %t117 = load i64, ptr %l12, !tbaa !24
  %t119 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %t120, i64 %t117
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !37
  %t126 = call i1 @compiler_2fcabi_2einSse(ptr %v3, { i64, ptr } %t122)
  store i1 %t126, ptr %l67
  br label %bb33
bb33:
  %t127 = load i1, ptr %l67, !tbaa !21
  br i1 %t127, label %bb34, label %bb35
bb34:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb36
bb35:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  %t136 = load i64, ptr %l12, !tbaa !24
  %t138 = add i64 %t136, 1
  store i64 %t138, ptr %l12, !tbaa !24
  br label %bb29
bb38:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l11, !tbaa !24
  %t144 = add i64 %t140, %t141
  store i64 %t144, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  br label %bb22
bb40:
  %t146 = load i64, ptr %l6, !tbaa !24
  %t147 = load ptr, ptr %l3, !tbaa !29
  %t149 = getelementptr %"compiler/cabi:Regs", ptr %t147, i32 0, i32 0
  %t150 = load i64, ptr %t149, !tbaa !24
  %t153 = icmp sgt i64 %t146, %t150
  br i1 %t153, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb43
bb42:
  %t155 = load i64, ptr %l7, !tbaa !24
  %t156 = load ptr, ptr %l3, !tbaa !29
  %t158 = getelementptr %"compiler/cabi:Regs", ptr %t156, i32 0, i32 1
  %t159 = load i64, ptr %t158, !tbaa !24
  %t162 = icmp sgt i64 %t155, %t159
  store i1 %t162, ptr %l81, !tbaa !21
  br label %bb43
bb43:
  %t164 = load i1, ptr %l81, !tbaa !21
  br i1 %t164, label %bb44, label %bb45
bb44:
  store i32 2, ptr %l86
  %t165 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t165, ptr %l87
  br label %bb46
bb45:
  br label %bb50
bb46:
  %t166 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t166, ptr %l88
  br label %bb47
bb47:
  %t167 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t167, ptr %l89
  br label %bb48
bb48:
  %t168 = load i32, ptr %l86
  %t169 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  %t170 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  %t171 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  %t172 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t168, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t169, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t171, { i64, ptr } { i64 0, ptr @.d24 })
  store %"compiler/cabi:Way" %t172, ptr %l90
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  %t173 = load %"compiler/cabi:Way", ptr %l90
  store %"compiler/cabi:Way" %t173, ptr %rv
  br label %ret
bb50:
  %t174 = load ptr, ptr %l3, !tbaa !29
  store ptr %t174, ptr %l91, !tbaa !29
  %t175 = load ptr, ptr %l91, !tbaa !29
  %t176 = getelementptr %"compiler/cabi:Regs", ptr %t175, i32 0, i32 0
  %t177 = load i64, ptr %t176, !tbaa !24
  %t178 = load i64, ptr %l6, !tbaa !24
  %t181 = sub i64 %t177, %t178
  %t183 = load ptr, ptr %l91, !tbaa !29
  %t184 = getelementptr %"compiler/cabi:Regs", ptr %t183, i32 0, i32 0
  store i64 %t181, ptr %t184, !tbaa !24
  %t185 = load ptr, ptr %l3, !tbaa !29
  store ptr %t185, ptr %l95, !tbaa !29
  %t186 = load ptr, ptr %l95, !tbaa !29
  %t187 = getelementptr %"compiler/cabi:Regs", ptr %t186, i32 0, i32 1
  %t188 = load i64, ptr %t187, !tbaa !24
  %t189 = load i64, ptr %l7, !tbaa !24
  %t192 = sub i64 %t188, %t189
  %t194 = load ptr, ptr %l95, !tbaa !29
  %t195 = getelementptr %"compiler/cabi:Regs", ptr %t194, i32 0, i32 1
  store i64 %t192, ptr %t195, !tbaa !24
  br label %bb51
bb51:
  %t196 = load ptr, ptr %lp5
  %t197 = load %"compiler/cabi:Way", ptr %t196
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cabi:Way" %t197, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l27 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = getelementptr %"compiler/cabi:Way", ptr %a0, i32 0, i32 1
  store ptr %t5, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t7, i64 %t8)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l17
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb4, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l16
  br label %bb3
bb3:
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  br label %bb8
bb4:
  %t17 = load i32, ptr %l17, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d6d32328f8c9b316_757e781aa691239a)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb8:
  %t22 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  store i64 %t25, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load i64, ptr %l7, !tbaa !24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l27, !tbaa !27
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  store { i64, ptr } %t43, ptr %l9, !tbaa !27
  %t47 = icmp sgt i64 %t35, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l1, { i64, ptr } { i64 2, ptr @.d25 })
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  %t50 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t50)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t53, 1
  store i64 %t55, ptr %l7, !tbaa !24
  %t57 = load i64, ptr %l4, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l4, !tbaa !24
  br label %bb9
bb19:
  %t61 = load i64, ptr %l3, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = add i64 %t61, %t62
  store i64 %t65, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb2
bb21:
  %t68 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t68, ptr %l43
  br label %bb22
bb22:
  %t69 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t69, ptr %l44, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l45, !tbaa !24
  %t72 = load i64, ptr %l45, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l46, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l45, !tbaa !24
  %t82 = mul i64 %t81, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t83, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l36 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cabi:Way", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/cabi:Way", ptr %t9, i32 0, i32 1
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s1, ptr %t11, i64 0)
  store { i64, ptr } %t13, ptr %l16
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t15, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb5:
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l18
  store %"std/prelude/text:StringBuilder" %t22, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr @.d26 })
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/cabi:Way", ptr %t24, i32 0, i32 1
  store ptr %t26, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l26
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb10, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l25
  br label %bb9
bb9:
  %t37 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t37, ptr %l22, !tbaa !27
  br label %bb14
bb10:
  %t38 = load i32, ptr %l26, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_c372cedf46a70b82_c606a425c6276e06)
  unreachable
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb14:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t43, ptr %l5, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb17:
  br label %bb18
bb18:
  %t56 = load i64, ptr %l4, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t58, ptr %l36, !tbaa !27
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %t62, i64 %t59
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !37
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t68 = icmp sgt i64 %t56, 0
  br i1 %t68, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l1, { i64, ptr } { i64 2, ptr @.d27 })
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  br label %bb22
bb22:
  %t71 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t71)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l7, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l4, !tbaa !24
  br label %bb15
bb25:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t83 = load i64, ptr %l6, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  br label %bb8
bb27:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr @.d28 })
  br label %bb28
bb28:
  %t90 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t90, ptr %l53
  br label %bb29
bb29:
  %t91 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t91, ptr %l54, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l55, !tbaa !24
  %t94 = load i64, ptr %l55, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l56, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l55, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t105, ptr %l54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t106 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/cabi:Way"
  %l20 = alloca %"compiler/cabi:Way"
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %l7
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l8
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l9
  br label %bb5
bb5:
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l10
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v2, ptr %t12, { i64, ptr } %t13, i32 %t14)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb7:
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t26 = load i32, ptr %l7
  %t27 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t31 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t26, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, { i64, ptr } %t25)
  store %"compiler/cabi:Way" %t31, ptr %l16
  br label %bb8
bb8:
  %t32 = load %"compiler/cabi:Way", ptr %l16
  store %"compiler/cabi:Way" %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = load i32, ptr %l2, !tbaa !23
  %t39 = call %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %t33, { i64, ptr } %t34, i32 %t35, i1 true)
  store %"compiler/cabi:Way" %t39, ptr %l20
  br label %bb10
bb10:
  %t40 = load %"compiler/cabi:Way", ptr %l20
  store %"compiler/cabi:Way" %t40, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/cabi:Way", ptr %t7, i32 0, i32 1
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l22, !tbaa !24
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/cabi:Way", ptr %t59, i32 0, i32 2
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l43
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/cabi:Way", ptr %t66, i32 0, i32 3
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb14
bb14:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l47, !tbaa !24
  %t75 = add i64 %t73, %t74
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = icmp sgt i64 %t75, %t76
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/cabi:Way", ptr %t81, i32 0, i32 2
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l54
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/cabi:Way", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l58
  br label %bb18
bb18:
  %t95 = load i64, ptr %l54, !tbaa !24
  %t96 = load i64, ptr %l58, !tbaa !24
  %t97 = add i64 %t95, %t96
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb9
bb21:
  %t103 = load i64, ptr %l3, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcabi_2eat(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/cabi:Scalar"
  %l11 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l25 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = load i64, ptr %l3, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eRunFrom_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l15
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l14
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l15, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_956e89f8b1f053a3_10449dd8dd9de7f)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb7:
  %t18 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/cabi:Scalar", ptr %t37, i64 %t34
  %t39 = load %"compiler/cabi:Scalar", ptr %t38
  store %"compiler/cabi:Scalar" %t39, ptr %l9
  %t41 = getelementptr %"compiler/cabi:Scalar", ptr %l9, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t46 = icmp eq i64 %t42, %a1
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load i64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i64 %t48, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t50, 1
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l4, !tbaa !24
  br label %bb8
bb16:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t58, %t59
  store i64 %t62, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb1
bb18:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcabi_2edata(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/cabi:Scalar"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l23 = alloca { i64, ptr }
  %l29 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eRunFrom_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l14
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11
ok.11:
  store { i64, ptr } %t8, ptr %l13
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t12, ptr %l10, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l14, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_756af84321ba00a4_2e2bba04a262b028)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb7:
  %t18 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t18, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 0
  store i64 %t21, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = icmp slt i64 %t23, %t24
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t31, ptr %l23, !tbaa !27
  %t32 = load i64, ptr %l7, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/cabi:Scalar", ptr %t35, i64 %t32
  %t37 = load %"compiler/cabi:Scalar", ptr %t36
  store %"compiler/cabi:Scalar" %t37, ptr %l8
  %t39 = getelementptr %"compiler/cabi:Scalar", ptr %l8, i32 0, i32 0
  %t40 = load i64, ptr %t39, !tbaa !24
  %t44 = icmp slt i64 %t40, %a2
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = getelementptr %"compiler/cabi:Scalar", ptr %l8, i32 0, i32 0
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = getelementptr %"compiler/cabi:Scalar", ptr %l8, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t52 = add i64 %t47, %t49
  %t56 = icmp sgt i64 %t52, %a1
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t58 = load i1, ptr %l29, !tbaa !21
  br i1 %t58, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t60 = load i64, ptr %l7, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb8
bb19:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = add i64 %t64, %t65
  store i64 %t68, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb1
bb21:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcabi_2einSse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 5, ptr @.d29 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 6, ptr @.d30 })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 4, ptr @.d31 })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 6, ptr @.d32 })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 1, ptr @.d33 })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l12, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/cabi:Scalar"
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca %"compiler/cabi:Scalar"
  %l20 = alloca %"compiler/cabi:Scalar"
  %l22 = alloca i1
  %l23 = alloca i1
  %l35 = alloca i1
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store %"compiler/cabi:Scalar" %t27, ptr %l20
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t28 = load %"compiler/cabi:Scalar", ptr %l20
  store %"compiler/cabi:Scalar" %t28, ptr %l4
  %t29 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 3, ptr @.d34 })
  store i1 %t32, ptr %l22
  br label %bb9
bb9:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t34 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp eq i64 %t35, 8
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t47, 0
  %t50 = insertvalue { { i64, ptr }, i64 } %t49, i64 8, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t50, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = add i64 %t53, %t55
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = add i64 %t59, 8
  %t65 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t52, i64 %t58, i64 %t61)
  store i1 %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i1, ptr %l35, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t69 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = mul i64 %t70, 8
  %t73 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr @.d35 }, 0
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t72)
  %t77 = add i64 %t74, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t73, i64 %t74)
  %t79 = getelementptr i8, ptr %t78, i64 %t74
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t72)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t78, 1
  %t83 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t82, 0
  %t88 = insertvalue { { i64, ptr }, i64 } %t86, i64 %t84, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t88, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = sub i64 %a2, %t91
  %t96 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t94, i64 8)
  store i64 %t96, ptr %l45
  br label %bb21
bb21:
  %t97 = load i64, ptr %l45, !tbaa !24
  store i64 %t97, ptr %l5, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = mul i64 %t98, 8
  %t101 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  %t104 = call i64 @__olang_fmt_i64(ptr null, i64 %t100)
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t101, i64 %t102)
  %t107 = getelementptr i8, ptr %t106, i64 %t102
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t100)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t106, 1
  %t111 = load i64, ptr %l5, !tbaa !24
  %t113 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t110, 0
  %t115 = insertvalue { { i64, ptr }, i64 } %t113, i64 %t111, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/cabi:Scalar"
  %l11 = alloca i64
  %l14 = alloca i64
  %l17 = alloca { i64, ptr }
  %l21 = alloca %"compiler/cabi:Scalar"
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i32
  %l41 = alloca { i64, ptr }
  %l47 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l61 = alloca i64
  %l73 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i1
  %l85 = alloca i1
  %l97 = alloca i1
  %l105 = alloca i64
  %l107 = alloca i1
  %l108 = alloca i1
  %l111 = alloca i1
  %l115 = alloca %"compiler/cabi:Scalar"
  %l117 = alloca i1
  %l118 = alloca { i64, ptr }
  %l120 = alloca { { i64, ptr }, i64 }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l21
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr @.d37 }, ptr %l17, !tbaa !27
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l21, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d38 }, ptr %l23, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t21, ptr %l24, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l25, !tbaa !24
  %t24 = load i64, ptr %l25, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l26, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l25, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l5, !tbaa !29
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eRunFrom_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t38, i64 %t39)
  %t43 = extractvalue { i32, { i64, ptr } } %t42, 1
  %t44 = extractvalue { i32, { i64, ptr } } %t42, 0
  store i32 %t44, ptr %l32
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb8, label %ok.46
ok.46:
  store { i64, ptr } %t43, ptr %l31
  br label %bb7
bb7:
  %t47 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t47, ptr %l28, !tbaa !27
  br label %bb12
bb8:
  %t48 = load i32, ptr %l32, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  br i1 %t51, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_97af6e75bfc7a40_89048eb08157a06c)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb12:
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t53, ptr %l7, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l9, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb15:
  br label %bb16
bb16:
  %t66 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t66, ptr %l41, !tbaa !27
  %t67 = load i64, ptr %l9, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr %"compiler/cabi:Scalar", ptr %t70, i64 %t67
  %t72 = load %"compiler/cabi:Scalar", ptr %t71
  store %"compiler/cabi:Scalar" %t72, ptr %l10
  %t74 = getelementptr %"compiler/cabi:Scalar", ptr %l10, i32 0, i32 0
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = load i64, ptr %l1, !tbaa !24
  %t79 = icmp sge i64 %t75, %t76
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = getelementptr %"compiler/cabi:Scalar", ptr %l10, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load i64, ptr %l1, !tbaa !24
  %t85 = add i64 %t83, 8
  %t88 = icmp slt i64 %t82, %t85
  store i1 %t88, ptr %l47, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb19
bb19:
  %t90 = load i1, ptr %l47, !tbaa !21
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t91 = getelementptr %"compiler/cabi:Scalar", ptr %l10, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t94 = icmp eq i64 %t92, 2
  store i1 %t94, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t96 = load i1, ptr %l52, !tbaa !21
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t97 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s3, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr @.d39 })
  store i1 %t99, ptr %l57
  br label %bb25
bb24:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb26
bb25:
  %t100 = load i1, ptr %l57, !tbaa !21
  store i1 %t100, ptr %l55, !tbaa !21
  br label %bb26
bb26:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb27, label %bb28
bb27:
  %t102 = getelementptr %"compiler/cabi:Scalar", ptr %l10, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 1
  %t106 = extractvalue { i64, ptr } %t103, 0
  %t107 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t106)
  call void @olang_textcopy(ptr %t107, ptr %t105, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l59, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  store i64 %t113, ptr %l61, !tbaa !24
  %t115 = load i64, ptr %l61, !tbaa !24
  %t116 = icmp eq i64 %t111, %t115
  br i1 %t116, label %bb29, label %bb30
bb28:
  br label %bb32
bb29:
  %t118 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = load i64, ptr %l61, !tbaa !24
  %t123 = mul i64 %t122, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t119, ptr %t121, i64 %t123, i1 false)
  br label %bb31
bb30:
  %t124 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t124, ptr %l4, !tbaa !27
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb33:
  %t125 = load i64, ptr %l9, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l9, !tbaa !24
  br label %bb13
bb34:
  %t129 = load i64, ptr %l6, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = add i64 %t129, %t130
  store i64 %t133, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  br label %bb6
bb36:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i64, ptr %l1, !tbaa !24
  %t138 = add i64 %t136, 4
  %t139 = load i64, ptr %l1, !tbaa !24
  %t141 = add i64 %t139, 8
  %t145 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t135, i64 %t138, i64 %t141)
  store i1 %t145, ptr %l73
  br label %bb37
bb37:
  %t146 = load i1, ptr %l73, !tbaa !21
  %t147 = xor i1 %t146, true
  br i1 %t147, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t149 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t151 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t149, { i64, ptr } { i64 4, ptr @.d40 })
  store i1 %t151, ptr %l76
  br label %bb40
bb39:
  br label %bb52
bb40:
  %t152 = load i1, ptr %l76, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb44
bb42:
  %t153 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t153, { i64, ptr } { i64 6, ptr @.d41 })
  store i1 %t155, ptr %l79
  br label %bb43
bb43:
  %t156 = load i1, ptr %l79, !tbaa !21
  store i1 %t156, ptr %l77, !tbaa !21
  br label %bb44
bb44:
  %t157 = load i1, ptr %l77, !tbaa !21
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l1, !tbaa !24
  %t161 = add i64 %t159, 2
  %t162 = load i64, ptr %l1, !tbaa !24
  %t164 = add i64 %t162, 4
  %t168 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t158, i64 %t161, i64 %t164)
  store i1 %t168, ptr %l85
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t169 = load i1, ptr %l85, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb48, label %bb49
bb48:
  %t172 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t172, 1
  %t175 = extractvalue { i64, ptr } %t172, 0
  %t176 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t174, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  %t180 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t178, 0
  %t181 = insertvalue { { i64, ptr }, i64 } %t180, i64 2, 1
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t181, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t183 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t184 = extractvalue { i64, ptr } { i64 5, ptr @.d42 }, 1
  %t185 = extractvalue { i64, ptr } { i64 5, ptr @.d42 }, 0
  %t187 = extractvalue { i64, ptr } %t183, 1
  %t188 = extractvalue { i64, ptr } %t183, 0
  %t189 = add i64 %t185, %t188
  %t190 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 1
  %t191 = extractvalue { i64, ptr } { i64 1, ptr @.d43 }, 0
  %t192 = add i64 %t189, %t191
  %t193 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t192)
  call void @olang_textcopy(ptr %t193, ptr %t184, i64 %t185)
  %t194 = getelementptr i8, ptr %t193, i64 %t185
  call void @olang_textcopy(ptr %t194, ptr %t187, i64 %t188)
  %t195 = getelementptr i8, ptr %t194, i64 %t188
  call void @olang_textcopy(ptr %t195, ptr %t190, i64 %t191)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t193, 1
  %t199 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t197, 0
  %t200 = insertvalue { { i64, ptr }, i64 } %t199, i64 4, 1
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t200, ptr %rv
  br label %ret
bb51:
  %t202 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 1
  %t205 = extractvalue { i64, ptr } %t202, 0
  %t206 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t204, i64 %t205)
  %t207 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t206, 1
  %t210 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t208, 0
  %t211 = insertvalue { { i64, ptr }, i64 } %t210, i64 4, 1
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t211, ptr %rv
  br label %ret
bb52:
  %t213 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t215 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t213, { i64, ptr } { i64 0, ptr @.d44 })
  store i1 %t215, ptr %l97
  br label %bb53
bb53:
  %t216 = load i1, ptr %l97, !tbaa !21
  %t217 = xor i1 %t216, true
  br i1 %t217, label %bb54, label %bb55
bb54:
  %t219 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t220 = extractvalue { i64, ptr } { i64 5, ptr @.d45 }, 1
  %t221 = extractvalue { i64, ptr } { i64 5, ptr @.d45 }, 0
  %t223 = extractvalue { i64, ptr } %t219, 1
  %t224 = extractvalue { i64, ptr } %t219, 0
  %t225 = add i64 %t221, %t224
  %t226 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t227 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  %t228 = add i64 %t225, %t227
  %t229 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t228)
  call void @olang_textcopy(ptr %t229, ptr %t220, i64 %t221)
  %t230 = getelementptr i8, ptr %t229, i64 %t221
  call void @olang_textcopy(ptr %t230, ptr %t223, i64 %t224)
  %t231 = getelementptr i8, ptr %t230, i64 %t224
  call void @olang_textcopy(ptr %t231, ptr %t226, i64 %t227)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t229, 1
  %t235 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t233, 0
  %t236 = insertvalue { { i64, ptr }, i64 } %t235, i64 8, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t236, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i64, ptr %l1, !tbaa !24
  %t241 = add i64 %t239, 4
  %t244 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t238, i64 %t241)
  store i64 %t244, ptr %l105
  br label %bb57
bb57:
  %t245 = load i64, ptr %l105, !tbaa !24
  store i64 %t245, ptr %l11, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t248 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t246, { i64, ptr } { i64 5, ptr @.d47 })
  store i1 %t248, ptr %l107
  br label %bb58
bb58:
  %t249 = load i1, ptr %l107, !tbaa !21
  br i1 %t249, label %bb59, label %bb60
bb59:
  %t250 = load i64, ptr %l11, !tbaa !24
  %t252 = icmp sge i64 %t250, 0
  store i1 %t252, ptr %l108, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb61
bb61:
  %t254 = load i1, ptr %l108, !tbaa !21
  br i1 %t254, label %bb62, label %bb63
bb62:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = load i64, ptr %l11, !tbaa !24
  %t260 = call %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t255, i64 %t257)
  store %"compiler/cabi:Scalar" %t260, ptr %l115
  br label %bb64
bb63:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb66
bb64:
  %t261 = getelementptr %"compiler/cabi:Scalar", ptr %l115, i32 0, i32 2
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t264 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t262, { i64, ptr } { i64 5, ptr @.d48 })
  store i1 %t264, ptr %l117
  br label %bb65
bb65:
  %t265 = load i1, ptr %l117, !tbaa !21
  store i1 %t265, ptr %l111, !tbaa !21
  br label %bb66
bb66:
  %t266 = load i1, ptr %l111, !tbaa !21
  br i1 %t266, label %bb67, label %bb68
bb67:
  store { i64, ptr } { i64 11, ptr @.d49 }, ptr %l118, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t269 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t267, 0
  %t270 = insertvalue { { i64, ptr }, i64 } %t269, i64 8, 1
  store { { i64, ptr }, i64 } %t270, ptr %l120
  %t271 = getelementptr { { i64, ptr }, i64 }, ptr %l120, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271, !tbaa !27
  store { i64, ptr } %t272, ptr %l121, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  store i64 %t274, ptr %l122, !tbaa !24
  %t275 = load i64, ptr %l122, !tbaa !24
  %t276 = mul i64 %t275, 1
  %t277 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t276)
  %t278 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  store { i64, ptr } %t279, ptr %l123, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = load i64, ptr %l122, !tbaa !24
  %t285 = mul i64 %t284, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t281, ptr %t283, i64 %t285, i1 false)
  %t286 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t287 = getelementptr { { i64, ptr }, i64 }, ptr %l120, i32 0, i32 0
  store { i64, ptr } %t286, ptr %t287, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t288 = load { { i64, ptr }, i64 }, ptr %l120
  store { { i64, ptr }, i64 } %t288, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t289 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t289, 1
  %t292 = extractvalue { i64, ptr } %t289, 0
  %t293 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t291, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t297 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t295, 0
  %t298 = insertvalue { { i64, ptr }, i64 } %t297, i64 8, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t298, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2etestDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca %"compiler/cabi:Regs"
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"compiler/cabi:Way"
  %l9 = alloca i32
  %l13 = alloca %"compiler/cabi:Way"
  %l14 = alloca %"compiler/cabi:Regs"
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l39 = alloca %"compiler/cabi:Way"
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %s0, ptr %t1, { i64, ptr } %t2, i32 %t3)
  store %"compiler/cabi:Way" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"compiler/cabi:Way", ptr %l13
  store %"compiler/cabi:Way" %t8, ptr %l3
  %t9 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"compiler/cabi:Regs", ptr %l14
  store %"compiler/cabi:Regs" %t10, ptr %l4
  %t11 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t12 = load i32, ptr %t11
  store i32 %t12, ptr %l5
  %t14 = load i32, ptr %l5
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l21
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l16, !tbaa !27
  br label %bb17
bb7:
  %t31 = load i32, ptr %l5
  %t33 = trunc i64 1 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t37 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t37, ptr %l26
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 4, ptr @.d50 }, ptr %l27, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9727aebca4df1374_94c7225b64063378)
  unreachable
bb17:
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t42, ptr %l29
  br label %bb18
bb18:
  %t43 = load %"std/prelude/text:StringBuilder", ptr %l29
  store %"std/prelude/text:StringBuilder" %t43, ptr %l7
  %t44 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44
  %t47 = trunc i64 4 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l7, { i64, ptr } { i64 6, ptr @.d51 })
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t51 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t54 = sub i64 %t52, 1
  %t56 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  store i64 %t54, ptr %t56, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t59 = load i32, ptr %l2, !tbaa !23
  %t64 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t57, { i64, ptr } %t58, i32 %t59, ptr %l4)
  store %"compiler/cabi:Way" %t64, ptr %l39
  br label %bb23
bb23:
  %t65 = load %"compiler/cabi:Way", ptr %l39
  store %"compiler/cabi:Way" %t65, ptr %l8
  store ptr %l7, ptr %l40, !tbaa !29
  %t66 = getelementptr %"compiler/cabi:Way", ptr %l8, i32 0, i32 0
  %t67 = load i32, ptr %t66
  store i32 %t67, ptr %l9
  %t69 = load i32, ptr %l9
  %t71 = trunc i64 0 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t78, ptr %l47
  br label %bb27
bb27:
  %t79 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l42, !tbaa !27
  br label %bb46
bb28:
  %t93 = load i32, ptr %l9
  %t95 = trunc i64 1 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t99 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t99, ptr %l53
  br label %bb32
bb32:
  %t100 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  br label %bb46
bb33:
  %t108 = load i32, ptr %l9
  %t110 = trunc i64 2 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store { i64, ptr } { i64 5, ptr @.d52 }, ptr %l42, !tbaa !27
  br label %bb46
bb37:
  %t113 = load i32, ptr %l9
  %t115 = trunc i64 3 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store { i64, ptr } { i64 3, ptr @.d53 }, ptr %l42, !tbaa !27
  br label %bb46
bb41:
  %t118 = load i32, ptr %l9
  %t120 = trunc i64 4 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store { i64, ptr } { i64 1, ptr @.d54 }, ptr %l42, !tbaa !27
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_8f84916f6bbe2da5_8f456227b094de49)
  unreachable
bb46:
  %t123 = load ptr, ptr %l40, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t123, { i64, ptr } %t124)
  br label %bb47
bb47:
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l61, !tbaa !27
  %t127 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t127, ptr %l63
  br label %bb48
bb48:
  %t128 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr @.d55 }, 0
  %t133 = add i64 %t130, %t132
  %t134 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr @.d56 }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr @.d56 }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t129, i64 %t130)
  %t142 = getelementptr i8, ptr %t141, i64 %t130
  call void @olang_textcopy(ptr %t142, ptr %t131, i64 %t132)
  %t143 = getelementptr i8, ptr %t142, i64 %t132
  call void @olang_textcopy(ptr %t143, ptr %t135, i64 %t136)
  %t144 = getelementptr i8, ptr %t143, i64 %t136
  call void @olang_textcopy(ptr %t144, ptr %t138, i64 %t139)
  %t145 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t141, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcabi_2etestStruct(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca i1
  %l39 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t7 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %a1, { i64, ptr } %a2)
  store i32 %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = load i32, ptr %l13, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %t8, i64 0, i32 %t9, i32 0, i32 0)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i32, ptr %l15, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t12, i32 %t13, i32 0)
  store i32 %t14, ptr %l16
  br label %bb3
bb3:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  %t17 = load i32, ptr %l4, !tbaa !23
  store i32 %t17, ptr %l18, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v3, ptr %t18, { i64, ptr } %t19)
  store i32 %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i32, ptr %l18, !tbaa !23
  %t25 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %t23, i32 %t24, i32 %t25, i1 false)
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l29, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i32, ptr %t44, i64 %t41
  %t46 = load i32, ptr %t45, !tbaa !33
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t48, i32 %t46)
  store i1 %t52, ptr %l34
  br label %bb10
bb10:
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_a86104d23e08732a_9d2c801d66b156c6)
  unreachable
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb6
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l39
  br label %bb15
bb15:
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load i32, ptr %l4, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_986d0e35626c2b45_4bacbe643940ac11)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/cabi:Regs"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/cabi:Regs" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/cabi:Regs" %t6, i64 %a1, 1
  store %"compiler/cabi:Regs" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Regs", ptr %rv
  ret %"compiler/cabi:Regs" %rr
}

define dso_local %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/cabi:Scalar"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/cabi:Scalar" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/cabi:Scalar" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/cabi:Scalar" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/cabi:Scalar" %t14, i1 %a3, 3
  store %"compiler/cabi:Scalar" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Scalar", ptr %rv
  ret %"compiler/cabi:Scalar" %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/cabi:Way"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/cabi:Way" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/cabi:Way" %t12, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, 1
  %t16 = insertvalue %"compiler/cabi:Way" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, 2
  %t18 = insertvalue %"compiler/cabi:Way" %t16, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, 3
  %t20 = insertvalue %"compiler/cabi:Way" %t18, { i64, ptr } %a4, 4
  store %"compiler/cabi:Way" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d0 = private constant [7 x i8] c"aarch64"
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant [2 x i8] c"{ "
@.d2 = private constant [2 x i8] c", "
@.d3 = private constant [2 x i8] c" }"
@.d4 = private constant [1 x i8] c"["
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant [3 x i8] c" x "
@.d6 = private constant [15 x i8] c"] alignstack(8)"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant [0 x i8] c""
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [9 x i8] c"[2 x i64]"
@.d10 = private constant [1 x i8] c"i"
@.d11 = private constant [3 x i8] c"i64"
@.d12 = private constant [0 x i8] c""
@.d13 = private constant [0 x i8] c""
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d14 = private constant [0 x i8] c""
@.d15 = private constant [6 x i8] c"x86_64"
@.d16 = private constant [0 x i8] c""
@.d17 = private constant [7 x i8] c"zeroext"
@.d18 = private constant [0 x i8] c""
@.d19 = private constant [7 x i8] c"zeroext"
@.d20 = private constant [7 x i8] c"signext"
@.d21 = private constant [3 x i8] c"ptr"
@.d22 = private constant [2 x i8] c"i8"
@.d23 = private constant [6 x i8] c"x86_64"
@.d24 = private constant [0 x i8] c""
@.d25 = private constant [2 x i8] c", "
@.d26 = private constant [2 x i8] c"{ "
@.d27 = private constant [2 x i8] c", "
@.d28 = private constant [2 x i8] c" }"
@.d29 = private constant [5 x i8] c"float"
@.d30 = private constant [6 x i8] c"double"
@.d31 = private constant [4 x i8] c"half"
@.d32 = private constant [6 x i8] c"bfloat"
@.d33 = private constant [1 x i8] c"<"
@.d34 = private constant [3 x i8] c"ptr"
@.d35 = private constant [1 x i8] c"i"
@.d36 = private constant [1 x i8] c"i"
@.d37 = private constant [6 x i8] c"double"
@.d38 = private constant [0 x i8] c""
@.d39 = private constant [0 x i8] c""
@.d40 = private constant [4 x i8] c"half"
@.d41 = private constant [6 x i8] c"bfloat"
@.d42 = private constant [5 x i8] c"<2 x "
@.d43 = private constant [1 x i8] c">"
@.d44 = private constant [0 x i8] c""
@.d45 = private constant [5 x i8] c"<4 x "
@.d46 = private constant [1 x i8] c">"
@.d47 = private constant [5 x i8] c"float"
@.d48 = private constant [5 x i8] c"float"
@.d49 = private constant [11 x i8] c"<2 x float>"
@.d50 = private constant [4 x i8] c"void"
@.d51 = private constant [6 x i8] c"sret, "
@.d52 = private constant [5 x i8] c"byval"
@.d53 = private constant [3 x i8] c"ptr"
@.d54 = private constant [1 x i8] c"?"
@.d55 = private constant [1 x i8] c"("
@.d56 = private constant [1 x i8] c")"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eRunFrom_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_79829e3e8c3b3142_ec3a884d14270446 = external constant [0 x i8]
declare %"compiler/cabi:Scalar" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b57f445a57eb78c3_b306b1059f9e7a27 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/cabi:Scalar" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b020d45a7b7622c7_3ee4736776830c7b = external constant [0 x i8]
@olang_loc_d6d32328f8c9b316_757e781aa691239a = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_c372cedf46a70b82_c606a425c6276e06 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_956e89f8b1f053a3_10449dd8dd9de7f = external constant [0 x i8]
@olang_loc_756af84321ba00a4_2e2bba04a262b028 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_97af6e75bfc7a40_89048eb08157a06c = external constant [0 x i8]
@olang_loc_9727aebca4df1374_94c7225b64063378 = external constant [0 x i8]
@olang_loc_8f84916f6bbe2da5_8f456227b094de49 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a86104d23e08732a_9d2c801d66b156c6 = external constant [0 x i8]
@olang_loc_986d0e35626c2b45_4bacbe643940ac11 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
