; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/cabi:Scalar" = type { i64, i64, { i64, ptr }, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cabi:Regs" = type { i64, i64 }
define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/cabi:Scalar"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/cabi:Scalar"
  %l34 = alloca { { i64, ptr }, i64 }
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/cabi:Scalar"
  %l67 = alloca i1
  %l68 = alloca i64
  %l70 = alloca %"compiler/cabi:Scalar"
  %l77 = alloca %"compiler/cabi:Scalar"
  %l80 = alloca %"std/prelude/text:StringBuilder"
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l116 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l121 = alloca i64
  %l126 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca %"compiler/cabi:Scalar"
  %l133 = alloca i32
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l139 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca %"compiler/cabi:Way"
  %l145 = alloca %"compiler/cabi:Way"
  %l149 = alloca i32
  %l152 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l155 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l157 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l158 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l160 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l161 = alloca %"compiler/cabi:Way"
  %l163 = alloca %"compiler/cabi:Way"
  %l166 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l177 = alloca i64
  %l182 = alloca i32
  %l183 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l185 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l186 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l188 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l189 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l191 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l192 = alloca %"compiler/cabi:Way"
  %l194 = alloca %"compiler/cabi:Way"
  %l197 = alloca i1
  %l201 = alloca i32
  %l204 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l207 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l209 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l212 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l213 = alloca %"compiler/cabi:Way"
  %l215 = alloca %"compiler/cabi:Way"
  %l222 = alloca i64
  %l225 = alloca i64
  %l248 = alloca i64
  %l250 = alloca i64
  %l255 = alloca %"compiler/cabi:Scalar"
  %l259 = alloca i1
  %l270 = alloca { { i64, ptr }, i64 }
  %l273 = alloca { { i64, ptr }, i64 }
  %l277 = alloca { { i64, ptr }, i64 }
  %l290 = alloca i32
  %l291 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l293 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l294 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l296 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l297 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l299 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l300 = alloca %"compiler/cabi:Way"
  %l302 = alloca %"compiler/cabi:Way"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l39
  br label %bb1
bb1:
  %t6 = load i64, ptr %l39, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l40
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %s0, ptr %t9, i32 %t10, i64 0, ptr %l5)
  br label %bb3
bb3:
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l44
  br label %bb4
bb4:
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t15, ptr %lp6
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t17 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l45
  br label %bb5
bb5:
  %t19 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t19, ptr %lp7
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t21 = load ptr, ptr %lp7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l46
  br label %bb6
bb6:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t23, ptr %lp8
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  %t25 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t25
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t28, ptr %l48
  br label %bb7
bb7:
  %t29 = load i1, ptr %l48, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t31, ptr %l50
  br label %bb10
bb9:
  br label %bb101
bb10:
  %t32 = load i64, ptr %l50, !tbaa !24
  %t33 = icmp sge i64 %t32, 1
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t36, ptr %l54
  br label %bb13
bb12:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb14
bb13:
  %t37 = load i64, ptr %l54, !tbaa !24
  %t38 = icmp sle i64 %t37, 4
  store i1 %t38, ptr %l52, !tbaa !21
  br label %bb14
bb14:
  %t40 = load i1, ptr %l52, !tbaa !21
  store i1 %t40, ptr %l9, !tbaa !21
  store ptr %l5, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i64, ptr %l11, !tbaa !24
  store i64 %t42, ptr %l57, !tbaa !24
  %t43 = load ptr, ptr %l10, !tbaa !29
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t43)
  store i64 %t45, ptr %l59
  br label %bb16
bb16:
  %t46 = load i64, ptr %l57, !tbaa !24
  %t47 = load i64, ptr %l59, !tbaa !24
  %t48 = icmp slt i64 %t46, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb18:
  br label %bb19
bb19:
  %t52 = load ptr, ptr %l10, !tbaa !29
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %t52, i64 %t53)
  store %"compiler/cabi:Scalar" %t56, ptr %l64
  br label %bb20
bb20:
  %t57 = load %"compiler/cabi:Scalar", ptr %l64
  store %"compiler/cabi:Scalar" %t57, ptr %l12
  %t58 = getelementptr %"compiler/cabi:Scalar", ptr %l12, i32 0, i32 3
  %t59 = load i1, ptr %t58, !tbaa !21
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb24
bb22:
  %t63 = getelementptr %"compiler/cabi:Scalar", ptr %l12, i32 0, i32 1
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l68, !tbaa !24
  %t66 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s3, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t66, ptr %l70
  br label %bb23
bb23:
  %t67 = getelementptr %"compiler/cabi:Scalar", ptr %l70, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l68, !tbaa !24
  %t71 = icmp ne i64 %t69, %t68
  store i1 %t71, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l67, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t74 = load i64, ptr %l11, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l11, !tbaa !24
  br label %bb15
bb29:
  %t78 = load i1, ptr %l9, !tbaa !21
  br i1 %t78, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t81, ptr %l77
  br label %bb32
bb31:
  br label %bb70
bb32:
  %t82 = getelementptr %"compiler/cabi:Scalar", ptr %l77, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l13, !tbaa !27
  %t85 = load i1, ptr %l3, !tbaa !21
  br i1 %t85, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s7)
  store %"std/prelude/text:StringBuilder" %t87, ptr %l80
  br label %bb35
bb34:
  %t88 = load ptr, ptr %lp6
  store ptr %t88, ptr %l119, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t90, ptr %l121
  br label %bb58
bb35:
  %t91 = load %"std/prelude/text:StringBuilder", ptr %l80
  store %"std/prelude/text:StringBuilder" %t91, ptr %l14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb36
bb36:
  store i64 0, ptr %l15, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t94, ptr %l83
  br label %bb37
bb37:
  %t95 = load i64, ptr %l83, !tbaa !24
  store i64 %t95, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = load i64, ptr %l15, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb38, label %bb39
bb38:
  %t102 = load i64, ptr %l17, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb43
bb40:
  %t106 = load i64, ptr %l16, !tbaa !24
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = sub i64 %t106, %t107
  %t111 = load i64, ptr %l17, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t116 = sub i64 %t114, 1
  %t117 = load i64, ptr %l17, !tbaa !24
  %t120 = sdiv i64 %t116, %t117
  store i64 %t120, ptr %l90, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb42
bb42:
  %t122 = load i64, ptr %l90, !tbaa !24
  store i64 %t122, ptr %l87, !tbaa !24
  br label %bb43
bb43:
  %t123 = load i64, ptr %l87, !tbaa !24
  store i64 %t123, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb44
bb44:
  %t124 = load i64, ptr %l19, !tbaa !24
  %t125 = load i64, ptr %l18, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb45, label %bb46
bb45:
  br label %bb54
bb46:
  br label %bb47
bb47:
  %t132 = load i64, ptr %l15, !tbaa !24
  %t133 = load i64, ptr %l19, !tbaa !24
  %t134 = load i64, ptr %l17, !tbaa !24
  %t137 = mul i64 %t133, %t134
  %t140 = add i64 %t132, %t137
  %t144 = icmp sgt i64 %t140, 0
  br i1 %t144, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s10, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb51
bb51:
  %t147 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s0, ptr %l14, { i64, ptr } %t147)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t150 = load i64, ptr %l19, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l19, !tbaa !24
  br label %bb44
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb55
bb55:
  %t155 = load ptr, ptr %lp6
  store ptr %t155, ptr %l116, !tbaa !29
  %t157 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s7, ptr %v2, ptr %l14)
  store { i64, ptr } %t157, ptr %l118
  br label %bb56
bb56:
  %t158 = load ptr, ptr %l116, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l118, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t158, { i64, ptr } %t159)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb58:
  %t160 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t163 = load i64, ptr %l121, !tbaa !24
  %t164 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t165 = add i64 %t162, %t164
  %t166 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t170 = extractvalue { i64, ptr } %t160, 1
  %t171 = extractvalue { i64, ptr } %t160, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t161, i64 %t162)
  %t177 = getelementptr i8, ptr %t176, i64 %t162
  %t178 = call i64 @__olang_fmt_i64(ptr %t177, i64 %t163)
  %t179 = getelementptr i8, ptr %t177, i64 %t164
  call void @olang_textcopy(ptr %t179, ptr %t166, i64 %t167)
  %t180 = getelementptr i8, ptr %t179, i64 %t167
  call void @olang_textcopy(ptr %t180, ptr %t170, i64 %t171)
  %t181 = getelementptr i8, ptr %t180, i64 %t171
  call void @olang_textcopy(ptr %t181, ptr %t173, i64 %t174)
  %t182 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t176, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t191 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t191, { i64, ptr } %t190)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t193 = load ptr, ptr %lp7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t193, i64 0)
  br label %bb61
bb61:
  %t195 = load ptr, ptr %lp8
  store ptr %t195, ptr %l126, !tbaa !29
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t197, ptr %l128
  br label %bb62
bb62:
  %t199 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s6, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t199, ptr %l130
  br label %bb63
bb63:
  %t200 = getelementptr %"compiler/cabi:Scalar", ptr %l130, i32 0, i32 1
  %t201 = load i64, ptr %t200, !tbaa !24
  %t202 = load i64, ptr %l128, !tbaa !24
  %t204 = mul i64 %t202, %t201
  %t205 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t205, i64 %t204)
  br label %bb64
bb64:
  store i32 1, ptr %l133
  %t207 = load ptr, ptr %lp6
  %t208 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t207
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t208, ptr %l134
  %t210 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v2, ptr %l134)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %l136
  br label %bb65
bb65:
  %t211 = load ptr, ptr %lp7
  %t212 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t211
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %l137
  %t214 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l137)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %l139
  br label %bb66
bb66:
  %t215 = load ptr, ptr %lp8
  %t216 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t215
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216, ptr %l140
  %t218 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l140)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l142
  br label %bb67
bb67:
  %t219 = load i32, ptr %l133, !range !{i32 0, i32 5}
  %t220 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l136
  %t221 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l139
  %t222 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  %t223 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t219, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t220, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t221, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t222, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t223, ptr %l143
  br label %bb68
bb68:
  %t225 = call %"compiler/cabi:Way" @olang_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l143)
  store %"compiler/cabi:Way" %t225, ptr %l145
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t226 = load %"compiler/cabi:Way", ptr %l145
  store %"compiler/cabi:Way" %t226, ptr %rv
  br label %ret
bb70:
  %t227 = load i64, ptr %l4, !tbaa !24
  %t229 = icmp sgt i64 %t227, 16
  br i1 %t229, label %bb71, label %bb72
bb71:
  %t231 = load i1, ptr %l3, !tbaa !21
  br i1 %t231, label %bb73, label %bb74
bb72:
  br label %bb81
bb73:
  store i32 4, ptr %l149
  br label %bb75
bb74:
  store i32 3, ptr %l149
  br label %bb75
bb75:
  %t235 = load ptr, ptr %lp6
  %t236 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t235
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t236, ptr %l152
  %t238 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v2, ptr %l152)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %l154
  br label %bb76
bb76:
  %t239 = load ptr, ptr %lp7
  %t240 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t239
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t240, ptr %l155
  %t242 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l155)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t242, ptr %l157
  br label %bb77
bb77:
  %t243 = load ptr, ptr %lp8
  %t244 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t243
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l158
  %t246 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l158)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t246, ptr %l160
  br label %bb78
bb78:
  %t247 = load i32, ptr %l149, !range !{i32 0, i32 5}
  %t248 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l154
  %t249 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l157
  %t250 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l160
  %t251 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t247, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t249, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t250, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t251, ptr %l161
  br label %bb79
bb79:
  %t253 = call %"compiler/cabi:Way" @olang_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l161)
  store %"compiler/cabi:Way" %t253, ptr %l163
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s0)
  %t254 = load %"compiler/cabi:Way", ptr %l163
  store %"compiler/cabi:Way" %t254, ptr %rv
  br label %ret
bb81:
  %t255 = load i64, ptr %l4, !tbaa !24
  %t257 = icmp sle i64 %t255, 8
  br i1 %t257, label %bb82, label %bb83
bb82:
  %t259 = load ptr, ptr %lp6
  store ptr %t259, ptr %l166, !tbaa !29
  %t260 = load i1, ptr %l3, !tbaa !21
  br i1 %t260, label %bb84, label %bb85
bb83:
  %t262 = load ptr, ptr %lp6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t262, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb92
bb84:
  %t264 = load i64, ptr %l4, !tbaa !24
  %t266 = mul i64 %t264, 8
  %t267 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t268 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t270 = call i64 @__olang_fmt_i64(ptr null, i64 %t266)
  %t271 = add i64 %t268, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t267, i64 %t268)
  %t273 = getelementptr i8, ptr %t272, i64 %t268
  %t274 = call i64 @__olang_fmt_i64(ptr %t273, i64 %t266)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t272, 1
  store { i64, ptr } %t276, ptr %l168, !tbaa !27
  br label %bb86
bb85:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l172, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t278, ptr %l168, !tbaa !27
  br label %bb86
bb86:
  %t280 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  %t282 = extractvalue { i64, ptr } %t280, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  %t287 = load ptr, ptr %l166, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t287, { i64, ptr } %t286)
  br label %bb87
bb87:
  %t289 = load ptr, ptr %lp8
  store ptr %t289, ptr %l175, !tbaa !29
  %t290 = load i1, ptr %l3, !tbaa !21
  br i1 %t290, label %bb88, label %bb89
bb88:
  %t292 = load i64, ptr %l4, !tbaa !24
  store i64 %t292, ptr %l177, !tbaa !24
  br label %bb90
bb89:
  store i64 8, ptr %l177, !tbaa !24
  br label %bb90
bb90:
  %t294 = load ptr, ptr %l175, !tbaa !29
  %t295 = load i64, ptr %l177, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t294, i64 %t295)
  br label %bb91
bb91:
  br label %bb94
bb92:
  %t296 = load ptr, ptr %lp8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t296, i64 16)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t298 = load ptr, ptr %lp7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t298, i64 0)
  br label %bb95
bb95:
  store i32 1, ptr %l182
  %t300 = load ptr, ptr %lp6
  %t301 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t300
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t301, ptr %l183
  %t303 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v2, ptr %l183)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t303, ptr %l185
  br label %bb96
bb96:
  %t304 = load ptr, ptr %lp7
  %t305 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t304
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t305, ptr %l186
  %t307 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l186)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t307, ptr %l188
  br label %bb97
bb97:
  %t308 = load ptr, ptr %lp8
  %t309 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t308
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t309, ptr %l189
  %t311 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l189)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t311, ptr %l191
  br label %bb98
bb98:
  %t312 = load i32, ptr %l182, !range !{i32 0, i32 5}
  %t313 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l185
  %t314 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l188
  %t315 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l191
  %t316 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t312, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t313, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t314, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t315, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t316, ptr %l192
  br label %bb99
bb99:
  %t318 = call %"compiler/cabi:Way" @olang_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l192)
  store %"compiler/cabi:Way" %t318, ptr %l194
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s0)
  %t319 = load %"compiler/cabi:Way", ptr %l194
  store %"compiler/cabi:Way" %t319, ptr %rv
  br label %ret
bb101:
  %t320 = load i64, ptr %l4, !tbaa !24
  %t322 = icmp sgt i64 %t320, 16
  br i1 %t322, label %bb102, label %bb103
bb102:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb104
bb103:
  %t324 = load i64, ptr %l4, !tbaa !24
  %t326 = icmp eq i64 %t324, 0
  store i1 %t326, ptr %l197, !tbaa !21
  br label %bb104
bb104:
  %t328 = load i1, ptr %l197, !tbaa !21
  br i1 %t328, label %bb105, label %bb106
bb105:
  %t329 = load i1, ptr %l3, !tbaa !21
  br i1 %t329, label %bb107, label %bb108
bb106:
  br label %bb115
bb107:
  store i32 4, ptr %l201
  br label %bb109
bb108:
  store i32 2, ptr %l201
  br label %bb109
bb109:
  %t333 = load ptr, ptr %lp6
  %t334 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t333
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t334, ptr %l204
  %t336 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v2, ptr %l204)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t336, ptr %l206
  br label %bb110
bb110:
  %t337 = load ptr, ptr %lp7
  %t338 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t337
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t338, ptr %l207
  %t340 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l207)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t340, ptr %l209
  br label %bb111
bb111:
  %t341 = load ptr, ptr %lp8
  %t342 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t341
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t342, ptr %l210
  %t344 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l210)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %l212
  br label %bb112
bb112:
  %t345 = load i32, ptr %l201, !range !{i32 0, i32 5}
  %t346 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l206
  %t347 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l209
  %t348 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l212
  %t349 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t345, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t346, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t347, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t348, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t349, ptr %l213
  br label %bb113
bb113:
  %t351 = call %"compiler/cabi:Way" @olang_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l213)
  store %"compiler/cabi:Way" %t351, ptr %l215
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s0)
  %t352 = load %"compiler/cabi:Way", ptr %l215
  store %"compiler/cabi:Way" %t352, ptr %rv
  br label %ret
bb115:
  store i64 0, ptr %l21, !tbaa !24
  %t353 = load i64, ptr %l4, !tbaa !24
  %t355 = add i64 %t353, 7
  %t357 = sdiv i64 %t355, 8
  store i64 %t357, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t359 = load i64, ptr %l22, !tbaa !24
  %t360 = load i64, ptr %l21, !tbaa !24
  %t363 = icmp sgt i64 %t359, %t360
  br i1 %t363, label %bb116, label %bb117
bb116:
  %t365 = load i64, ptr %l23, !tbaa !24
  %t367 = icmp sgt i64 %t365, 0
  br i1 %t367, label %bb118, label %bb119
bb117:
  store i64 0, ptr %l222, !tbaa !24
  br label %bb121
bb118:
  %t369 = load i64, ptr %l22, !tbaa !24
  %t370 = load i64, ptr %l21, !tbaa !24
  %t373 = sub i64 %t369, %t370
  %t374 = load i64, ptr %l23, !tbaa !24
  %t377 = add i64 %t373, %t374
  %t379 = sub i64 %t377, 1
  %t380 = load i64, ptr %l23, !tbaa !24
  %t383 = sdiv i64 %t379, %t380
  store i64 %t383, ptr %l225, !tbaa !24
  br label %bb120
bb119:
  store i64 0, ptr %l225, !tbaa !24
  br label %bb120
bb120:
  %t385 = load i64, ptr %l225, !tbaa !24
  store i64 %t385, ptr %l222, !tbaa !24
  br label %bb121
bb121:
  %t386 = load i64, ptr %l222, !tbaa !24
  store i64 %t386, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb122
bb122:
  store %olang.scope zeroinitializer, ptr %s20
  %t387 = load i64, ptr %l25, !tbaa !24
  %t388 = load i64, ptr %l24, !tbaa !24
  %t391 = icmp slt i64 %t387, %t388
  %t393 = xor i1 %t391, true
  br i1 %t393, label %bb123, label %bb124
bb123:
  call void @__olang_scope_close(ptr %s20)
  br label %bb155
bb124:
  br label %bb125
bb125:
  %t395 = load i64, ptr %l21, !tbaa !24
  %t396 = load i64, ptr %l25, !tbaa !24
  %t397 = load i64, ptr %l23, !tbaa !24
  %t400 = mul i64 %t396, %t397
  %t403 = add i64 %t395, %t400
  %t407 = mul i64 %t403, 8
  store i64 %t407, ptr %l27, !tbaa !24
  %t409 = load i64, ptr %l27, !tbaa !24
  %t411 = add i64 %t409, 8
  store i64 %t411, ptr %l28, !tbaa !24
  store i1 true, ptr %l29, !tbaa !21
  store i1 false, ptr %l30, !tbaa !21
  store ptr %l5, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb126
bb126:
  %t414 = load i64, ptr %l32, !tbaa !24
  store i64 %t414, ptr %l248, !tbaa !24
  %t415 = load ptr, ptr %l31, !tbaa !29
  %t417 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t415)
  store i64 %t417, ptr %l250
  br label %bb127
bb127:
  %t418 = load i64, ptr %l248, !tbaa !24
  %t419 = load i64, ptr %l250, !tbaa !24
  %t420 = icmp slt i64 %t418, %t419
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb128, label %bb129
bb128:
  br label %bb142
bb129:
  br label %bb130
bb130:
  %t424 = load ptr, ptr %l31, !tbaa !29
  %t425 = load i64, ptr %l32, !tbaa !24
  %t428 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %t424, i64 %t425)
  store %"compiler/cabi:Scalar" %t428, ptr %l255
  br label %bb131
bb131:
  %t429 = load %"compiler/cabi:Scalar", ptr %l255
  store %"compiler/cabi:Scalar" %t429, ptr %l33
  %t430 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 0
  %t431 = load i64, ptr %t430, !tbaa !24
  %t432 = load i64, ptr %l27, !tbaa !24
  %t435 = icmp sge i64 %t431, %t432
  br i1 %t435, label %bb132, label %bb133
bb132:
  %t437 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 0
  %t438 = load i64, ptr %t437, !tbaa !24
  %t439 = load i64, ptr %l28, !tbaa !24
  %t442 = icmp slt i64 %t438, %t439
  store i1 %t442, ptr %l259, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l259, !tbaa !21
  br label %bb134
bb134:
  %t444 = load i1, ptr %l259, !tbaa !21
  br i1 %t444, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l30, !tbaa !21
  %t445 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 3
  %t446 = load i1, ptr %t445, !tbaa !21
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb137, label %bb138
bb136:
  br label %bb140
bb137:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb139
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t450 = load i64, ptr %l32, !tbaa !24
  %t452 = add i64 %t450, 1
  store i64 %t452, ptr %l32, !tbaa !24
  br label %bb126
bb142:
  %t454 = load i1, ptr %l30, !tbaa !21
  %t456 = xor i1 %t454, true
  br i1 %t456, label %bb143, label %bb144
bb143:
  call void @__olang_scope_close(ptr %s20)
  br label %bb154
bb144:
  br label %bb145
bb145:
  %t458 = load i1, ptr %l29, !tbaa !21
  br i1 %t458, label %bb146, label %bb147
bb146:
  %t460 = load i64, ptr %l27, !tbaa !24
  %t463 = call { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %s0, ptr %s20, ptr %l5, i64 %t460)
  store { { i64, ptr }, i64 } %t463, ptr %l273
  br label %bb148
bb147:
  %t464 = load i64, ptr %l27, !tbaa !24
  %t465 = load i64, ptr %l4, !tbaa !24
  %t469 = call { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %s0, ptr %s20, ptr %l5, i64 %t464, i64 %t465)
  store { { i64, ptr }, i64 } %t469, ptr %l277
  br label %bb149
bb148:
  %t470 = load { { i64, ptr }, i64 }, ptr %l273
  store { { i64, ptr }, i64 } %t470, ptr %l270
  br label %bb150
bb149:
  %t471 = load { { i64, ptr }, i64 }, ptr %l277
  store { { i64, ptr }, i64 } %t471, ptr %l270
  br label %bb150
bb150:
  %t472 = load { { i64, ptr }, i64 }, ptr %l270
  store { { i64, ptr }, i64 } %t472, ptr %l34
  %t473 = getelementptr { { i64, ptr }, i64 }, ptr %l34, i32 0, i32 0
  %t474 = load { i64, ptr }, ptr %t473, !tbaa !27
  %t476 = getelementptr { { i64, ptr }, i64 }, ptr %l34, i32 0, i32 1
  %t477 = load i64, ptr %t476, !tbaa !24
  store i64 %t477, ptr %l36, !tbaa !24
  %t479 = load ptr, ptr %lp6
  %t482 = extractvalue { i64, ptr } %t474, 1
  %t483 = extractvalue { i64, ptr } %t474, 0
  %t484 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t483)
  call void @olang_textcopy(ptr %t484, ptr %t482, i64 %t483)
  %t485 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = extractvalue { i64, ptr } %t486, 1
  %t490 = mul i64 %t488, 1
  %t491 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t490)
  call void @llvm.memcpy.p0.p0.i64(ptr %t491, ptr %t489, i64 %t490, i1 false)
  %t492 = insertvalue { i64, ptr } undef, i64 %t488, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t479, { i64, ptr } %t493)
  br label %bb151
bb151:
  %t496 = load ptr, ptr %lp7
  %t497 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t496, i64 %t497)
  br label %bb152
bb152:
  %t500 = load ptr, ptr %lp8
  %t501 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t500, i64 %t501)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s20)
  br label %bb154
bb154:
  %t504 = load i64, ptr %l25, !tbaa !24
  %t506 = add i64 %t504, 1
  store i64 %t506, ptr %l25, !tbaa !24
  br label %bb122
bb155:
  store i32 1, ptr %l290
  %t508 = load ptr, ptr %lp6
  %t509 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t508
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t509, ptr %l291
  %t511 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v2, ptr %l291)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t511, ptr %l293
  br label %bb156
bb156:
  %t512 = load ptr, ptr %lp7
  %t513 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t512
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t513, ptr %l294
  %t515 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l294)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t515, ptr %l296
  br label %bb157
bb157:
  %t516 = load ptr, ptr %lp8
  %t517 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t516
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t517, ptr %l297
  %t519 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l297)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t519, ptr %l299
  br label %bb158
bb158:
  %t520 = load i32, ptr %l290, !range !{i32 0, i32 5}
  %t521 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l293
  %t522 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l296
  %t523 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l299
  %t524 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t520, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t521, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t522, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t523, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t524, ptr %l300
  br label %bb159
bb159:
  %t526 = call %"compiler/cabi:Way" @olang_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v2, ptr %l300)
  store %"compiler/cabi:Way" %t526, ptr %l302
  br label %bb160
bb160:
  call void @__olang_scope_close(ptr %s0)
  %t527 = load %"compiler/cabi:Way", ptr %l302
  store %"compiler/cabi:Way" %t527, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %a2)
  store i32 %t27, ptr %l13
  br label %bb5
bb5:
  %t28 = load i32, ptr %l13, !tbaa !23
  store i32 %t28, ptr %l3, !tbaa !23
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %l18, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l19, !tbaa !24
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l20, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l19, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t49, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l23
  br label %bb9
bb9:
  %t56 = load i1, ptr %l23, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l28
  br label %bb12
bb12:
  %t64 = load i64, ptr %l28, !tbaa !24
  %t65 = icmp sge i64 %t64, 32
  store i1 %t65, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l25, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l32, !tbaa !24
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l33, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l32, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t82, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l36
  br label %bb17
bb17:
  %t89 = load i1, ptr %l36, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t90, ptr %l37, !tbaa !27
  br label %bb20
bb19:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t92, ptr %l37, !tbaa !27
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l43, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l42, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t107, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t108 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i32
  %l31 = alloca ptr
  %l33 = alloca %"compiler/cabi:Scalar"
  %l36 = alloca i32
  %l41 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l94 = alloca i32
  %l97 = alloca i1
  %l98 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l118 = alloca i64
  %l121 = alloca i64
  %l140 = alloca { i64, ptr }
  %l152 = alloca i64
  %l156 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i64
  %l164 = alloca i64
  %l167 = alloca { i64, ptr }
  %l170 = alloca i1
  %l171 = alloca %"compiler/cabi:Scalar"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l25
  br label %bb1
bb1:
  %t6 = load i32, ptr %l25, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l28
  br label %bb2
bb2:
  %t12 = load i32, ptr %l28, !range !{i32 0, i32 33}
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l3, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t18, i64 8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, i1 false)
  store %"compiler/cabi:Scalar" %t20, ptr %l33
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l31, !tbaa !29
  %t22 = load %"compiler/cabi:Scalar", ptr %l33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t21, %"compiler/cabi:Scalar" %t22)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l36
  br label %bb8
bb8:
  %t28 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l41
  br label %bb11
bb10:
  br label %bb33
bb11:
  %t38 = load i32, ptr %l41, !tbaa !23
  store i32 %t38, ptr %l5, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l42, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l45
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l42, !tbaa !29
  %t46 = load i32, ptr %l45, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l46
  br label %bb13
bb13:
  %t48 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t50 = trunc i64 26 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l53
  br label %bb16
bb15:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb18
bb16:
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = load i32, ptr %l53, !tbaa !23
  %t61 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t61, ptr %l54
  br label %bb17
bb17:
  %t62 = load i64, ptr %l54, !tbaa !24
  store i64 %t62, ptr %l49, !tbaa !24
  br label %bb18
bb18:
  %t63 = load i64, ptr %l49, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb24
bb21:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l62, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l62, !tbaa !24
  store i64 %t92, ptr %l59, !tbaa !24
  br label %bb24
bb24:
  %t93 = load i64, ptr %l59, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l80, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  store i32 %t113, ptr %l81, !tbaa !23
  %t114 = load i64, ptr %l2, !tbaa !24
  store i64 %t114, ptr %l82, !tbaa !24
  store i64 %t110, ptr %l83, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t116, i32 %t117)
  store i64 %t120, ptr %l86
  br label %bb29
bb29:
  %t121 = load i64, ptr %l83, !tbaa !24
  %t122 = load i64, ptr %l86, !tbaa !24
  %t123 = mul i64 %t121, %t122
  %t124 = load i64, ptr %l82, !tbaa !24
  %t126 = add i64 %t124, %t123
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load ptr, ptr %l80, !tbaa !29
  %t129 = load i32, ptr %l81, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %t128, i32 %t129, i64 %t126, ptr %t127)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l11, !tbaa !24
  br label %bb25
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l94
  br label %bb34
bb34:
  %t141 = load i32, ptr %l94, !range !{i32 0, i32 33}
  %t143 = trunc i64 18 to i32
  %t144 = icmp eq i32 %t141, %t143
  br i1 %t144, label %bb35, label %bb36
bb35:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l98, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l4, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l101
  br label %bb37
bb36:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb39
bb37:
  %t152 = load ptr, ptr %l98, !tbaa !29
  %t153 = load i32, ptr %l101, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l102
  br label %bb38
bb38:
  %t155 = load i32, ptr %l102, !range !{i32 0, i32 6}
  %t157 = trunc i64 0 to i32
  %t158 = icmp eq i32 %t155, %t157
  store i1 %t158, ptr %l97, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l97, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l105, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l4, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l108
  br label %bb42
bb41:
  br label %bb58
bb42:
  %t167 = load ptr, ptr %l105, !tbaa !29
  %t168 = load i32, ptr %l108, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t167, i32 %t168)
  store { i64, ptr } %t169, ptr %l109
  br label %bb43
bb43:
  %t170 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t170, ptr %l13, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l4, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s6, ptr %t171, i32 %t172)
  store { i64, ptr } %t175, ptr %l112
  br label %bb44
bb44:
  %t176 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t176, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t181 = load i64, ptr %l16, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = icmp sgt i64 %t181, %t182
  br i1 %t185, label %bb45, label %bb46
bb45:
  %t187 = load i64, ptr %l17, !tbaa !24
  %t189 = icmp sgt i64 %t187, 0
  br i1 %t189, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb50
bb47:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = sub i64 %t191, %t192
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = add i64 %t195, %t196
  %t201 = sub i64 %t199, 1
  %t202 = load i64, ptr %l17, !tbaa !24
  %t205 = sdiv i64 %t201, %t202
  store i64 %t205, ptr %l121, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb49
bb49:
  %t207 = load i64, ptr %l121, !tbaa !24
  store i64 %t207, ptr %l118, !tbaa !24
  br label %bb50
bb50:
  %t208 = load i64, ptr %l118, !tbaa !24
  store i64 %t208, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb51
bb51:
  %t209 = load i64, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l18, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb52, label %bb53
bb52:
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t217 = load i64, ptr %l15, !tbaa !24
  %t218 = load i64, ptr %l19, !tbaa !24
  %t219 = load i64, ptr %l17, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t225 = add i64 %t217, %t222
  store i64 %t225, ptr %l20, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t228, ptr %l140, !tbaa !27
  %t229 = load i64, ptr %l20, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i32, ptr %t232, i64 %t229
  %t234 = load i32, ptr %t233, !tbaa !33
  %t235 = load i64, ptr %l2, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i64, ptr %t239, i64 %t236
  %t241 = load i64, ptr %t240, !tbaa !34
  %t244 = add i64 %t235, %t241
  %t245 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %t227, i32 %t234, i64 %t244, ptr %t245)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t252 = add i64 %t250, 1
  store i64 %t252, ptr %l19, !tbaa !24
  br label %bb51
bb57:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb58:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i32, ptr %l4, !tbaa !23
  %t258 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t254, i32 %t255)
  store i64 %t258, ptr %l152
  br label %bb59
bb59:
  %t259 = load i64, ptr %l152, !tbaa !24
  store i64 %t259, ptr %l21, !tbaa !24
  %t260 = load i32, ptr %l4, !tbaa !23
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t264 = icmp eq i32 %t260, %t261
  br i1 %t264, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l156, !tbaa !27
  br label %bb63
bb61:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l4, !tbaa !23
  %t270 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s0, ptr %t266, i32 %t267)
  store { i64, ptr } %t270, ptr %l159
  br label %bb62
bb62:
  %t271 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t272, i64 %t273)
  %t275 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = extractvalue { i64, ptr } %t276, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l156, !tbaa !27
  br label %bb63
bb63:
  %t285 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t286 = load ptr, ptr %l3, !tbaa !29
  store ptr %t286, ptr %l162, !tbaa !29
  %t287 = load i64, ptr %l2, !tbaa !24
  store i64 %t287, ptr %l163, !tbaa !24
  %t288 = load i64, ptr %l21, !tbaa !24
  store i64 %t288, ptr %l164, !tbaa !24
  %t291 = extractvalue { i64, ptr } %t285, 1
  %t292 = extractvalue { i64, ptr } %t285, 0
  %t293 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t291, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = extractvalue { i64, ptr } %t295, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l167, !tbaa !27
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l4, !tbaa !23
  %t307 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t303, i32 %t304)
  store i1 %t307, ptr %l170
  br label %bb64
bb64:
  %t308 = load i64, ptr %l163, !tbaa !24
  %t309 = load i64, ptr %l164, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t311 = load i1, ptr %l170, !tbaa !21
  %t312 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t308, i64 %t309, { i64, ptr } %t310, i1 %t311)
  store %"compiler/cabi:Scalar" %t312, ptr %l171
  br label %bb65
bb65:
  %t313 = load ptr, ptr %l162, !tbaa !29
  %t314 = load %"compiler/cabi:Scalar", ptr %l171
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t313, %"compiler/cabi:Scalar" %t314)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8, !range !{i32 0, i32 33}
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i32, ptr %l16, !range !{i32 0, i32 6}
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l11, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/cabi:Way"
  %l40 = alloca %"compiler/cabi:Way"
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i32
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca %"compiler/cabi:Way"
  %l77 = alloca ptr
  %l81 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l17
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t15, i32 %t14)
  store i1 %t19, ptr %l20
  br label %bb5
bb5:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = getelementptr %"compiler/cabi:Regs", ptr %t22, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = sub i64 %t24, 1
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t29 = getelementptr %"compiler/cabi:Regs", ptr %t28, i32 0, i32 1
  store i64 %t26, ptr %t29, !tbaa !24
  br label %bb8
bb7:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l24, !tbaa !29
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = getelementptr %"compiler/cabi:Regs", ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = sub i64 %t33, 1
  %t37 = load ptr, ptr %l24, !tbaa !29
  %t38 = getelementptr %"compiler/cabi:Regs", ptr %t37, i32 0, i32 0
  store i64 %t35, ptr %t38, !tbaa !24
  br label %bb8
bb8:
  store i32 0, ptr %l27
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l28
  br label %bb9
bb9:
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l29
  br label %bb10
bb10:
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l30
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = load i32, ptr %l2, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v3, ptr %t42, { i64, ptr } %t43, i32 %t44)
  store { i64, ptr } %t48, ptr %l34
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load i32, ptr %l27, !range !{i32 0, i32 5}
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  %t61 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t56, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, { i64, ptr } %t55)
  store %"compiler/cabi:Way" %t61, ptr %l36
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load %"compiler/cabi:Way", ptr %l36
  store %"compiler/cabi:Way" %t62, ptr %rv
  br label %ret
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = load i32, ptr %l2, !tbaa !23
  %t69 = call %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v3, ptr %t63, { i64, ptr } %t64, i32 %t65, i1 false)
  store %"compiler/cabi:Way" %t69, ptr %l40
  br label %bb15
bb15:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 120, i64 8)
  store ptr %t70, ptr %lp5
  %t71 = load %"compiler/cabi:Way", ptr %l40
  %t72 = load ptr, ptr %lp5
  store %"compiler/cabi:Way" %t71, ptr %t72
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t75, ptr %l42
  br label %bb16
bb16:
  %t76 = load i1, ptr %l42, !tbaa !21
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t77 = load ptr, ptr %lp5
  %t78 = getelementptr %"compiler/cabi:Way", ptr %t77, i32 0, i32 0
  %t79 = load i32, ptr %t78, !range !{i32 0, i32 5}
  %t81 = trunc i64 1 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l43, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t85 = load ptr, ptr %lp5
  %t86 = getelementptr %"compiler/cabi:Way", ptr %t85, i32 0, i32 1
  store ptr %t86, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb21:
  br label %bb44
bb22:
  %t88 = load i64, ptr %l9, !tbaa !24
  store i64 %t88, ptr %l47, !tbaa !24
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t89)
  store i64 %t91, ptr %l49
  br label %bb23
bb23:
  %t92 = load i64, ptr %l47, !tbaa !24
  %t93 = load i64, ptr %l49, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb27
bb27:
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t106 = call i1 @compiler_2fcabi_2einSse(ptr %v3, { i64, ptr } %t103)
  store i1 %t106, ptr %l56
  br label %bb28
bb28:
  %t107 = load i1, ptr %l56, !tbaa !21
  br i1 %t107, label %bb29, label %bb30
bb29:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb31
bb30:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l6, !tbaa !24
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb22
bb33:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t121 = load ptr, ptr %l3, !tbaa !29
  %t123 = getelementptr %"compiler/cabi:Regs", ptr %t121, i32 0, i32 0
  %t124 = load i64, ptr %t123, !tbaa !24
  %t127 = icmp sgt i64 %t120, %t124
  br i1 %t127, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb36
bb35:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/cabi:Regs", ptr %t130, i32 0, i32 1
  %t133 = load i64, ptr %t132, !tbaa !24
  %t136 = icmp sgt i64 %t129, %t133
  store i1 %t136, ptr %l67, !tbaa !21
  br label %bb36
bb36:
  %t138 = load i1, ptr %l67, !tbaa !21
  br i1 %t138, label %bb37, label %bb38
bb37:
  store i32 2, ptr %l72
  %t139 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l73
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t140 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %l74
  br label %bb40
bb40:
  %t141 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %l75
  br label %bb41
bb41:
  %t142 = load i32, ptr %l72, !range !{i32 0, i32 5}
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  %t145 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  %t146 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t142, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t146, ptr %l76
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load %"compiler/cabi:Way", ptr %l76
  store %"compiler/cabi:Way" %t147, ptr %rv
  br label %ret
bb43:
  %t148 = load ptr, ptr %l3, !tbaa !29
  store ptr %t148, ptr %l77, !tbaa !29
  %t149 = load ptr, ptr %l77, !tbaa !29
  %t150 = getelementptr %"compiler/cabi:Regs", ptr %t149, i32 0, i32 0
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = sub i64 %t151, %t152
  %t157 = load ptr, ptr %l77, !tbaa !29
  %t158 = getelementptr %"compiler/cabi:Regs", ptr %t157, i32 0, i32 0
  store i64 %t155, ptr %t158, !tbaa !24
  %t159 = load ptr, ptr %l3, !tbaa !29
  store ptr %t159, ptr %l81, !tbaa !29
  %t160 = load ptr, ptr %l81, !tbaa !29
  %t161 = getelementptr %"compiler/cabi:Regs", ptr %t160, i32 0, i32 1
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr %l7, !tbaa !24
  %t166 = sub i64 %t162, %t163
  %t168 = load ptr, ptr %l81, !tbaa !29
  %t169 = getelementptr %"compiler/cabi:Regs", ptr %t168, i32 0, i32 1
  store i64 %t166, ptr %t169, !tbaa !24
  br label %bb44
bb44:
  %t170 = load ptr, ptr %lp5
  %t171 = load %"compiler/cabi:Way", ptr %t170
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cabi:Way" %t171, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l11 = alloca i64
  %l17 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = getelementptr %"compiler/cabi:Way", ptr %a0, i32 0, i32 1
  store ptr %t5, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l17
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t30)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t38 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t38, ptr %l26
  br label %bb15
bb15:
  %t39 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t39, ptr %l27, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t53, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l20 = alloca i64
  %l26 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cabi:Way", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/cabi:Way", ptr %t9, i32 0, i32 1
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s1, ptr %t11, i64 0)
  store { i64, ptr } %t13, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t15, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb5:
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l14
  br label %bb6
bb6:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t22, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/cabi:Way", ptr %t24, i32 0, i32 1
  store ptr %t26, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l18, !tbaa !24
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l20
  br label %bb9
bb9:
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store { i64, ptr } %t44, ptr %l26
  br label %bb13
bb13:
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t51)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb8
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb21
bb21:
  %t60 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t60, ptr %l36
  br label %bb22
bb22:
  %t61 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l38, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t75, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/cabi:Way"
  %l20 = alloca %"compiler/cabi:Way"
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %l7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l8
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l9
  br label %bb5
bb5:
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l10
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v2, ptr %t12, { i64, ptr } %t13, i32 %t14)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb7:
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t26 = load i32, ptr %l7, !range !{i32 0, i32 5}
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t31 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t26, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, { i64, ptr } %t25)
  store %"compiler/cabi:Way" %t31, ptr %l16
  br label %bb8
bb8:
  %t32 = load %"compiler/cabi:Way", ptr %l16
  store %"compiler/cabi:Way" %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = load i32, ptr %l2, !tbaa !23
  %t39 = call %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %t33, { i64, ptr } %t34, i32 %t35, i1 true)
  store %"compiler/cabi:Way" %t39, ptr %l20
  br label %bb10
bb10:
  %t40 = load %"compiler/cabi:Way", ptr %l20
  store %"compiler/cabi:Way" %t40, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/cabi:Way", ptr %t7, i32 0, i32 1
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l22, !tbaa !24
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/cabi:Way", ptr %t59, i32 0, i32 2
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l43
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/cabi:Way", ptr %t66, i32 0, i32 3
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb14
bb14:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l47, !tbaa !24
  %t75 = add i64 %t73, %t74
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = icmp sgt i64 %t75, %t76
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/cabi:Way", ptr %t81, i32 0, i32 2
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l54
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/cabi:Way", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l58
  br label %bb18
bb18:
  %t95 = load i64, ptr %l54, !tbaa !24
  %t96 = load i64, ptr %l58, !tbaa !24
  %t97 = add i64 %t95, %t96
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb9
bb21:
  %t103 = load i64, ptr %l3, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcabi_2eat(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/cabi:Scalar"
  %l7 = alloca i64
  %l9 = alloca i64
  %l15 = alloca %"compiler/cabi:Scalar"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/cabi:Scalar" %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load %"compiler/cabi:Scalar", ptr %l15
  store %"compiler/cabi:Scalar" %t20, ptr %l5
  %t21 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = icmp eq i64 %t22, %a1
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcabi_2edata(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/cabi:Scalar"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/cabi:Scalar"
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store %"compiler/cabi:Scalar" %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load %"compiler/cabi:Scalar", ptr %l14
  store %"compiler/cabi:Scalar" %t18, ptr %l5
  %t19 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t24 = icmp slt i64 %t20, %a2
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = add i64 %t27, %t29
  %t36 = icmp sgt i64 %t32, %a1
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcabi_2einSse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l12, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/cabi:Scalar"
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca %"compiler/cabi:Scalar"
  %l20 = alloca %"compiler/cabi:Scalar"
  %l22 = alloca i1
  %l23 = alloca i1
  %l35 = alloca i1
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store %"compiler/cabi:Scalar" %t27, ptr %l20
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t28 = load %"compiler/cabi:Scalar", ptr %l20
  store %"compiler/cabi:Scalar" %t28, ptr %l4
  %t29 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t32, ptr %l22
  br label %bb9
bb9:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t34 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp eq i64 %t35, 8
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t47, 0
  %t50 = insertvalue { { i64, ptr }, i64 } %t49, i64 8, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t50, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = add i64 %t53, %t55
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = add i64 %t59, 8
  %t65 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t52, i64 %t58, i64 %t61)
  store i1 %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i1, ptr %l35, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t69 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = mul i64 %t70, 8
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t72)
  %t77 = add i64 %t74, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t73, i64 %t74)
  %t79 = getelementptr i8, ptr %t78, i64 %t74
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t72)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t78, 1
  %t83 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t82, 0
  %t88 = insertvalue { { i64, ptr }, i64 } %t86, i64 %t84, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t88, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = sub i64 %a2, %t91
  %t96 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t94, i64 8)
  store i64 %t96, ptr %l45
  br label %bb21
bb21:
  %t97 = load i64, ptr %l45, !tbaa !24
  store i64 %t97, ptr %l5, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = mul i64 %t98, 8
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t104 = call i64 @__olang_fmt_i64(ptr null, i64 %t100)
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t101, i64 %t102)
  %t107 = getelementptr i8, ptr %t106, i64 %t102
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t100)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t106, 1
  %t111 = load i64, ptr %l5, !tbaa !24
  %t113 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t110, 0
  %t115 = insertvalue { { i64, ptr }, i64 } %t113, i64 %t111, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/cabi:Scalar"
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca %"compiler/cabi:Scalar"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/cabi:Scalar"
  %l36 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l59 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l71 = alloca i1
  %l83 = alloca i1
  %l91 = alloca i64
  %l93 = alloca i1
  %l94 = alloca i1
  %l97 = alloca i1
  %l101 = alloca %"compiler/cabi:Scalar"
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l106 = alloca { { i64, ptr }, i64 }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l18
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l18, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t21, ptr %l21, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l22, !tbaa !24
  %t24 = load i64, ptr %l22, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l23, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  store i64 %t38, ptr %l25, !tbaa !24
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l27
  br label %bb7
bb7:
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = load i64, ptr %l27, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/cabi:Scalar" %t52, ptr %l32
  br label %bb11
bb11:
  %t53 = load %"compiler/cabi:Scalar", ptr %l32
  store %"compiler/cabi:Scalar" %t53, ptr %l7
  %t54 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 0
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = icmp sge i64 %t55, %t56
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t61 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t65 = add i64 %t63, 8
  %t68 = icmp slt i64 %t62, %t65
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb15, label %bb16
bb15:
  %t71 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 1
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp eq i64 %t72, 2
  store i1 %t74, ptr %l41, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t77, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t79, ptr %l46
  br label %bb20
bb19:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb21
bb20:
  %t80 = load i1, ptr %l46, !tbaa !21
  store i1 %t80, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l44, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 1
  %t86 = extractvalue { i64, ptr } %t83, 0
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t85, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l48, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l50, !tbaa !24
  %t95 = load i64, ptr %l50, !tbaa !24
  %t96 = icmp eq i64 %t91, %t95
  br i1 %t96, label %bb24, label %bb25
bb23:
  br label %bb27
bb24:
  %t98 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l50, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  br label %bb26
bb25:
  %t104 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t104, ptr %l4, !tbaa !27
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l6, !tbaa !24
  br label %bb6
bb29:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i64, ptr %l1, !tbaa !24
  %t112 = add i64 %t110, 4
  %t113 = load i64, ptr %l1, !tbaa !24
  %t115 = add i64 %t113, 8
  %t119 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t109, i64 %t112, i64 %t115)
  store i1 %t119, ptr %l59
  br label %bb30
bb30:
  %t120 = load i1, ptr %l59, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t123, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t125, ptr %l62
  br label %bb33
bb32:
  br label %bb45
bb33:
  %t126 = load i1, ptr %l62, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb37
bb35:
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t127, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t129, ptr %l65
  br label %bb36
bb36:
  %t130 = load i1, ptr %l65, !tbaa !21
  store i1 %t130, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t131 = load i1, ptr %l63, !tbaa !21
  br i1 %t131, label %bb38, label %bb39
bb38:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t135 = add i64 %t133, 2
  %t136 = load i64, ptr %l1, !tbaa !24
  %t138 = add i64 %t136, 4
  %t142 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t132, i64 %t135, i64 %t138)
  store i1 %t142, ptr %l71
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t143 = load i1, ptr %l71, !tbaa !21
  %t144 = xor i1 %t143, true
  br i1 %t144, label %bb41, label %bb42
bb41:
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t148, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t152, 0
  %t155 = insertvalue { { i64, ptr }, i64 } %t154, i64 2, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t155, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t157 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t158 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t161 = extractvalue { i64, ptr } %t157, 1
  %t162 = extractvalue { i64, ptr } %t157, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t158, i64 %t159)
  %t168 = getelementptr i8, ptr %t167, i64 %t159
  call void @olang_textcopy(ptr %t168, ptr %t161, i64 %t162)
  %t169 = getelementptr i8, ptr %t168, i64 %t162
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t167, 1
  %t173 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t171, 0
  %t174 = insertvalue { { i64, ptr }, i64 } %t173, i64 4, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t174, ptr %rv
  br label %ret
bb44:
  %t176 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = extractvalue { i64, ptr } %t176, 0
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t178, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t184 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t182, 0
  %t185 = insertvalue { { i64, ptr }, i64 } %t184, i64 4, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t185, ptr %rv
  br label %ret
bb45:
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t187, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t189, ptr %l83
  br label %bb46
bb46:
  %t190 = load i1, ptr %l83, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb47, label %bb48
bb47:
  %t193 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t194 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t197 = extractvalue { i64, ptr } %t193, 1
  %t198 = extractvalue { i64, ptr } %t193, 0
  %t199 = add i64 %t195, %t198
  %t200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t194, i64 %t195)
  %t204 = getelementptr i8, ptr %t203, i64 %t195
  call void @olang_textcopy(ptr %t204, ptr %t197, i64 %t198)
  %t205 = getelementptr i8, ptr %t204, i64 %t198
  call void @olang_textcopy(ptr %t205, ptr %t200, i64 %t201)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t203, 1
  %t209 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t207, 0
  %t210 = insertvalue { { i64, ptr }, i64 } %t209, i64 8, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t210, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l1, !tbaa !24
  %t215 = add i64 %t213, 4
  %t218 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t212, i64 %t215)
  store i64 %t218, ptr %l91
  br label %bb50
bb50:
  %t219 = load i64, ptr %l91, !tbaa !24
  store i64 %t219, ptr %l8, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t220, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t222, ptr %l93
  br label %bb51
bb51:
  %t223 = load i1, ptr %l93, !tbaa !21
  br i1 %t223, label %bb52, label %bb53
bb52:
  %t224 = load i64, ptr %l8, !tbaa !24
  %t226 = icmp sge i64 %t224, 0
  store i1 %t226, ptr %l94, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb54
bb54:
  %t228 = load i1, ptr %l94, !tbaa !21
  br i1 %t228, label %bb55, label %bb56
bb55:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l8, !tbaa !24
  %t234 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t229, i64 %t231)
  store %"compiler/cabi:Scalar" %t234, ptr %l101
  br label %bb57
bb56:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb59
bb57:
  %t235 = getelementptr %"compiler/cabi:Scalar", ptr %l101, i32 0, i32 2
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t238 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t236, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t238, ptr %l103
  br label %bb58
bb58:
  %t239 = load i1, ptr %l103, !tbaa !21
  store i1 %t239, ptr %l97, !tbaa !21
  br label %bb59
bb59:
  %t240 = load i1, ptr %l97, !tbaa !21
  br i1 %t240, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t243 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t241, 0
  %t244 = insertvalue { { i64, ptr }, i64 } %t243, i64 8, 1
  store { { i64, ptr }, i64 } %t244, ptr %l106
  %t245 = getelementptr { { i64, ptr }, i64 }, ptr %l106, i32 0, i32 0
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  store { i64, ptr } %t246, ptr %l107, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 0
  store i64 %t248, ptr %l108, !tbaa !24
  %t249 = load i64, ptr %l108, !tbaa !24
  %t250 = mul i64 %t249, 1
  %t251 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t250)
  %t252 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t251, 1
  store { i64, ptr } %t253, ptr %l109, !tbaa !27
  %t254 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = load i64, ptr %l108, !tbaa !24
  %t259 = mul i64 %t258, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t255, ptr %t257, i64 %t259, i1 false)
  %t260 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t261 = getelementptr { { i64, ptr }, i64 }, ptr %l106, i32 0, i32 0
  store { i64, ptr } %t260, ptr %t261, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t262 = load { { i64, ptr }, i64 }, ptr %l106
  store { { i64, ptr }, i64 } %t262, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t263 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t266)
  call void @olang_textcopy(ptr %t267, ptr %t265, i64 %t266)
  %t268 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t271 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t269, 0
  %t272 = insertvalue { { i64, ptr }, i64 } %t271, i64 8, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t272, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2etestDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca %"compiler/cabi:Regs"
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"compiler/cabi:Way"
  %l9 = alloca i32
  %l13 = alloca %"compiler/cabi:Way"
  %l14 = alloca %"compiler/cabi:Regs"
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"std/prelude/text:StringBuilder"
  %l41 = alloca %"compiler/cabi:Way"
  %l42 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %s0, ptr %t1, { i64, ptr } %t2, i32 %t3)
  store %"compiler/cabi:Way" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"compiler/cabi:Way", ptr %l13
  store %"compiler/cabi:Way" %t8, ptr %l3
  %t9 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"compiler/cabi:Regs", ptr %l14
  store %"compiler/cabi:Regs" %t10, ptr %l4
  %t11 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t12 = load i32, ptr %t11, !range !{i32 0, i32 5}
  store i32 %t12, ptr %l5
  %t14 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s1, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l21
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l16, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb7:
  %t31 = load i32, ptr %l5, !range !{i32 0, i32 5}
  %t33 = trunc i64 1 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t37 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t37, ptr %l26
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9727aebca4df1374_94c7225b64063378)
  unreachable
bb17:
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l29, !tbaa !24
  %t44 = mul i64 %t43, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l30, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l29, !tbaa !24
  %t53 = mul i64 %t52, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t49, ptr %t51, i64 %t53, i1 false)
  %t54 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t54, ptr %l6, !tbaa !27
  %t55 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t55, ptr %l31
  br label %bb18
bb18:
  %t56 = load %"std/prelude/text:StringBuilder", ptr %l31
  store %"std/prelude/text:StringBuilder" %t56, ptr %l7
  %t57 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 5}
  %t60 = trunc i64 4 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t64 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = sub i64 %t65, 1
  %t69 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  store i64 %t67, ptr %t69, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = load i32, ptr %l2, !tbaa !23
  %t77 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t70, { i64, ptr } %t71, i32 %t72, ptr %l4)
  store %"compiler/cabi:Way" %t77, ptr %l41
  br label %bb23
bb23:
  %t78 = load %"compiler/cabi:Way", ptr %l41
  store %"compiler/cabi:Way" %t78, ptr %l8
  store ptr %l7, ptr %l42, !tbaa !29
  %t79 = getelementptr %"compiler/cabi:Way", ptr %l8, i32 0, i32 0
  %t80 = load i32, ptr %t79, !range !{i32 0, i32 5}
  store i32 %t80, ptr %l9
  %t82 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t84 = trunc i64 0 to i32
  %t85 = icmp eq i32 %t82, %t84
  br i1 %t85, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  store %olang.scope zeroinitializer, ptr %s6
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %s6, ptr %t87, i32 %t88)
  store { i64, ptr } %t91, ptr %l49
  br label %bb27
bb27:
  %t92 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t93, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb28:
  %t106 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t108 = trunc i64 1 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t112 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t112, ptr %l55
  br label %bb32
bb32:
  %t113 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = mul i64 %t114, 1
  %t117 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t116)
  call void @llvm.memcpy.p0.p0.i64(ptr %t117, ptr %t115, i64 %t116, i1 false)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l44, !tbaa !27
  br label %bb46
bb33:
  %t121 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t123 = trunc i64 2 to i32
  %t124 = icmp eq i32 %t121, %t123
  br i1 %t124, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb46
bb37:
  %t126 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t128 = trunc i64 3 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb46
bb41:
  %t131 = load i32, ptr %l9, !range !{i32 0, i32 5}
  %t133 = trunc i64 4 to i32
  %t134 = icmp eq i32 %t131, %t133
  br i1 %t134, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_8f84916f6bbe2da5_8f456227b094de49)
  unreachable
bb46:
  %t136 = load ptr, ptr %l42, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t136, { i64, ptr } %t137)
  br label %bb47
bb47:
  %t138 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  %t140 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t140, ptr %l65
  br label %bb48
bb48:
  %t141 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t146 = add i64 %t143, %t145
  %t147 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 1
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t150 = add i64 %t146, %t149
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t153 = add i64 %t150, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t142, i64 %t143)
  %t155 = getelementptr i8, ptr %t154, i64 %t143
  call void @olang_textcopy(ptr %t155, ptr %t144, i64 %t145)
  %t156 = getelementptr i8, ptr %t155, i64 %t145
  call void @olang_textcopy(ptr %t156, ptr %t148, i64 %t149)
  %t157 = getelementptr i8, ptr %t156, i64 %t149
  call void @olang_textcopy(ptr %t157, ptr %t151, i64 %t152)
  %t158 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t154, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t159, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcabi_2etestStruct(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca i1
  %l39 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t7 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %a1, { i64, ptr } %a2)
  store i32 %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = load i32, ptr %l13, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %t8, i64 0, i32 %t9, i32 0, i32 0)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i32, ptr %l15, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t12, i32 %t13, i32 0)
  store i32 %t14, ptr %l16
  br label %bb3
bb3:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  %t17 = load i32, ptr %l4, !tbaa !23
  store i32 %t17, ptr %l18, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v3, ptr %t18, { i64, ptr } %t19)
  store i32 %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i32, ptr %l18, !tbaa !23
  %t25 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %t23, i32 %t24, i32 %t25, i1 false)
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l29, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i32, ptr %t44, i64 %t41
  %t46 = load i32, ptr %t45, !tbaa !33
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t48, i32 %t46)
  store i1 %t52, ptr %l34
  br label %bb10
bb10:
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_a86104d23e08732a_9d2c801d66b156c6)
  unreachable
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb6
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l39
  br label %bb15
bb15:
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load i32, ptr %l4, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_986d0e35626c2b45_4bacbe643940ac11)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/cabi:Regs"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/cabi:Regs" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/cabi:Regs" %t6, i64 %a1, 1
  store %"compiler/cabi:Regs" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Regs", ptr %rv
  ret %"compiler/cabi:Regs" %rr
}

define dso_local %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/cabi:Scalar"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/cabi:Scalar" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/cabi:Scalar" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/cabi:Scalar" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/cabi:Scalar" %t14, i1 %a3, 3
  store %"compiler/cabi:Scalar" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Scalar", ptr %rv
  ret %"compiler/cabi:Scalar" %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/cabi:Way"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/cabi:Way" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/cabi:Way" %t12, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, 1
  %t16 = insertvalue %"compiler/cabi:Way" %t14, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, 2
  %t18 = insertvalue %"compiler/cabi:Way" %t16, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3, 3
  %t20 = insertvalue %"compiler/cabi:Way" %t18, { i64, ptr } %a4, 4
  store %"compiler/cabi:Way" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d6 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"] alignstack(8)" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"compiler/cabi:Way" @olang_2eHelperKind_2eCopy_2ecompiler_2fcabi_3aWay(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/cabi:Way"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/cabi:Way"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/cabi:Way", ptr %a0
  store %"compiler/cabi:Way" %t2, ptr %l1
  %t3 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l5
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t12 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %t12
  %t13 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 3
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t13)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l7
  br label %bb3
bb3:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t17 = getelementptr %"compiler/cabi:Way", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %t17
  %t18 = load %"compiler/cabi:Way", ptr %l1
  store %"compiler/cabi:Way" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"[2 x i64]" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d17 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"zeroext" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"zeroext" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"signext" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d42 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<2 x " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<4 x " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d48 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d49 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"<2 x float>" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d51 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"sret, " }>, align 8
@.d52 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"byval" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %a0)
declare %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/cabi:Scalar" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_9727aebca4df1374_94c7225b64063378 = external constant [0 x i8]
@olang_loc_8f84916f6bbe2da5_8f456227b094de49 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a86104d23e08732a_9d2c801d66b156c6 = external constant [0 x i8]
@olang_loc_986d0e35626c2b45_4bacbe643940ac11 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
