; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/cabi:Scalar" = type { i64, i64, { i64, ptr }, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/cabi:Regs" = type { i64, i64 }
define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/cabi:Scalar"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/cabi:Scalar"
  %l34 = alloca { { i64, ptr }, i64 }
  %l36 = alloca i64
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca i1
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca %"compiler/cabi:Scalar"
  %l67 = alloca i1
  %l68 = alloca i64
  %l70 = alloca %"compiler/cabi:Scalar"
  %l77 = alloca %"compiler/cabi:Scalar"
  %l80 = alloca %"std/prelude/text:StringBuilder"
  %l83 = alloca i64
  %l87 = alloca i64
  %l90 = alloca i64
  %l116 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l121 = alloca i64
  %l126 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca %"compiler/cabi:Scalar"
  %l137 = alloca %"compiler/cabi:Way"
  %l141 = alloca i32
  %l147 = alloca %"compiler/cabi:Way"
  %l150 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l161 = alloca i64
  %l170 = alloca %"compiler/cabi:Way"
  %l173 = alloca i1
  %l177 = alloca i32
  %l183 = alloca %"compiler/cabi:Way"
  %l190 = alloca i64
  %l193 = alloca i64
  %l216 = alloca i64
  %l218 = alloca i64
  %l223 = alloca %"compiler/cabi:Scalar"
  %l227 = alloca i1
  %l238 = alloca { { i64, ptr }, i64 }
  %l241 = alloca { { i64, ptr }, i64 }
  %l245 = alloca { { i64, ptr }, i64 }
  %l246 = alloca { i64, ptr }
  %l247 = alloca i64
  %l248 = alloca { i64, ptr }
  %l264 = alloca %"compiler/cabi:Way"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l39
  br label %bb1
bb1:
  %t6 = load i64, ptr %l39, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l40
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %s0, ptr %t9, i32 %t10, i64 0, ptr %l5)
  br label %bb3
bb3:
  %t14 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l44
  br label %bb4
bb4:
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t15, ptr %lp6
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  %t17 = load ptr, ptr %lp6
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %t17
  %t18 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l45
  br label %bb5
bb5:
  %t19 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t19, ptr %lp7
  %t20 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  %t21 = load ptr, ptr %lp7
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %t21
  %t22 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l46
  br label %bb6
bb6:
  %t23 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t23, ptr %lp8
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  %t25 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %t25
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i1 %t28, ptr %l48
  br label %bb7
bb7:
  %t29 = load i1, ptr %l48, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t31, ptr %l50
  br label %bb10
bb9:
  br label %bb89
bb10:
  %t32 = load i64, ptr %l50, !tbaa !24
  %t33 = icmp sge i64 %t32, 1
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t36, ptr %l54
  br label %bb13
bb12:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb14
bb13:
  %t37 = load i64, ptr %l54, !tbaa !24
  %t38 = icmp sle i64 %t37, 4
  store i1 %t38, ptr %l52, !tbaa !21
  br label %bb14
bb14:
  %t40 = load i1, ptr %l52, !tbaa !21
  store i1 %t40, ptr %l9, !tbaa !21
  store ptr %l5, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i64, ptr %l11, !tbaa !24
  store i64 %t42, ptr %l57, !tbaa !24
  %t43 = load ptr, ptr %l10, !tbaa !29
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t43)
  store i64 %t45, ptr %l59
  br label %bb16
bb16:
  %t46 = load i64, ptr %l57, !tbaa !24
  %t47 = load i64, ptr %l59, !tbaa !24
  %t48 = icmp slt i64 %t46, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb18:
  br label %bb19
bb19:
  %t52 = load ptr, ptr %l10, !tbaa !29
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %t52, i64 %t53)
  store %"compiler/cabi:Scalar" %t56, ptr %l64
  br label %bb20
bb20:
  %t57 = load %"compiler/cabi:Scalar", ptr %l64
  store %"compiler/cabi:Scalar" %t57, ptr %l12
  %t58 = getelementptr %"compiler/cabi:Scalar", ptr %l12, i32 0, i32 3
  %t59 = load i1, ptr %t58, !tbaa !21
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb24
bb22:
  %t63 = getelementptr %"compiler/cabi:Scalar", ptr %l12, i32 0, i32 1
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l68, !tbaa !24
  %t66 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s3, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t66, ptr %l70
  br label %bb23
bb23:
  %t67 = getelementptr %"compiler/cabi:Scalar", ptr %l70, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l68, !tbaa !24
  %t71 = icmp ne i64 %t69, %t68
  store i1 %t71, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t73 = load i1, ptr %l67, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t74 = load i64, ptr %l11, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l11, !tbaa !24
  br label %bb15
bb29:
  %t78 = load i1, ptr %l9, !tbaa !21
  br i1 %t78, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t81 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t81, ptr %l77
  br label %bb32
bb31:
  br label %bb66
bb32:
  %t82 = getelementptr %"compiler/cabi:Scalar", ptr %l77, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l13, !tbaa !27
  %t85 = load i1, ptr %l3, !tbaa !21
  br i1 %t85, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s7)
  store %"std/prelude/text:StringBuilder" %t87, ptr %l80
  br label %bb35
bb34:
  %t88 = load ptr, ptr %lp6
  store ptr %t88, ptr %l119, !tbaa !29
  %t90 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t90, ptr %l121
  br label %bb58
bb35:
  %t91 = load %"std/prelude/text:StringBuilder", ptr %l80
  store %"std/prelude/text:StringBuilder" %t91, ptr %l14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb36
bb36:
  store i64 0, ptr %l15, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t94, ptr %l83
  br label %bb37
bb37:
  %t95 = load i64, ptr %l83, !tbaa !24
  store i64 %t95, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t96 = load i64, ptr %l16, !tbaa !24
  %t97 = load i64, ptr %l15, !tbaa !24
  %t100 = icmp sgt i64 %t96, %t97
  br i1 %t100, label %bb38, label %bb39
bb38:
  %t102 = load i64, ptr %l17, !tbaa !24
  %t104 = icmp sgt i64 %t102, 0
  br i1 %t104, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb43
bb40:
  %t106 = load i64, ptr %l16, !tbaa !24
  %t107 = load i64, ptr %l15, !tbaa !24
  %t110 = sub i64 %t106, %t107
  %t111 = load i64, ptr %l17, !tbaa !24
  %t114 = add i64 %t110, %t111
  %t116 = sub i64 %t114, 1
  %t117 = load i64, ptr %l17, !tbaa !24
  %t120 = sdiv i64 %t116, %t117
  store i64 %t120, ptr %l90, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb42
bb42:
  %t122 = load i64, ptr %l90, !tbaa !24
  store i64 %t122, ptr %l87, !tbaa !24
  br label %bb43
bb43:
  %t123 = load i64, ptr %l87, !tbaa !24
  store i64 %t123, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb44
bb44:
  %t124 = load i64, ptr %l19, !tbaa !24
  %t125 = load i64, ptr %l18, !tbaa !24
  %t128 = icmp slt i64 %t124, %t125
  %t130 = xor i1 %t128, true
  br i1 %t130, label %bb45, label %bb46
bb45:
  br label %bb54
bb46:
  br label %bb47
bb47:
  %t132 = load i64, ptr %l15, !tbaa !24
  %t133 = load i64, ptr %l19, !tbaa !24
  %t134 = load i64, ptr %l17, !tbaa !24
  %t137 = mul i64 %t133, %t134
  %t140 = add i64 %t132, %t137
  %t144 = icmp sgt i64 %t140, 0
  br i1 %t144, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s10, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb51
bb51:
  %t147 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s0, ptr %l14, { i64, ptr } %t147)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t150 = load i64, ptr %l19, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l19, !tbaa !24
  br label %bb44
bb54:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l14, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb55
bb55:
  %t155 = load ptr, ptr %lp6
  store ptr %t155, ptr %l116, !tbaa !29
  %t157 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s7, ptr %v2, ptr %l14)
  store { i64, ptr } %t157, ptr %l118
  br label %bb56
bb56:
  %t158 = load ptr, ptr %l116, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l118, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t158, { i64, ptr } %t159)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb58:
  %t160 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t163 = load i64, ptr %l121, !tbaa !24
  %t164 = call i64 @__olang_fmt_i64(ptr null, i64 %t163)
  %t165 = add i64 %t162, %t164
  %t166 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t170 = extractvalue { i64, ptr } %t160, 1
  %t171 = extractvalue { i64, ptr } %t160, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t161, i64 %t162)
  %t177 = getelementptr i8, ptr %t176, i64 %t162
  %t178 = call i64 @__olang_fmt_i64(ptr %t177, i64 %t163)
  %t179 = getelementptr i8, ptr %t177, i64 %t164
  call void @olang_textcopy(ptr %t179, ptr %t166, i64 %t167)
  %t180 = getelementptr i8, ptr %t179, i64 %t167
  call void @olang_textcopy(ptr %t180, ptr %t170, i64 %t171)
  %t181 = getelementptr i8, ptr %t180, i64 %t171
  call void @olang_textcopy(ptr %t181, ptr %t173, i64 %t174)
  %t182 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t176, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t191 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t191, { i64, ptr } %t190)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t193 = load ptr, ptr %lp7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t193, i64 0)
  br label %bb61
bb61:
  %t195 = load ptr, ptr %lp8
  store ptr %t195, ptr %l126, !tbaa !29
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %l5)
  store i64 %t197, ptr %l128
  br label %bb62
bb62:
  %t199 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s6, ptr %l5, i64 0)
  store %"compiler/cabi:Scalar" %t199, ptr %l130
  br label %bb63
bb63:
  %t200 = getelementptr %"compiler/cabi:Scalar", ptr %l130, i32 0, i32 1
  %t201 = load i64, ptr %t200, !tbaa !24
  %t202 = load i64, ptr %l128, !tbaa !24
  %t204 = mul i64 %t202, %t201
  %t205 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t205, i64 %t204)
  br label %bb64
bb64:
  %t207 = load ptr, ptr %lp6
  %t208 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t207
  %t209 = load ptr, ptr %lp7
  %t210 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t209
  %t211 = load ptr, ptr %lp8
  %t212 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t211
  %t217 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t217, ptr %l137
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t218 = load %"compiler/cabi:Way", ptr %l137
  store %"compiler/cabi:Way" %t218, ptr %rv
  br label %ret
bb66:
  %t219 = load i64, ptr %l4, !tbaa !24
  %t221 = icmp sgt i64 %t219, 16
  br i1 %t221, label %bb67, label %bb68
bb67:
  %t223 = load i1, ptr %l3, !tbaa !21
  br i1 %t223, label %bb69, label %bb70
bb68:
  br label %bb73
bb69:
  store i32 4, ptr %l141
  br label %bb71
bb70:
  store i32 3, ptr %l141
  br label %bb71
bb71:
  %t227 = load ptr, ptr %lp6
  %t228 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t227
  %t229 = load ptr, ptr %lp7
  %t230 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t229
  %t231 = load ptr, ptr %lp8
  %t232 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t231
  %t233 = load i32, ptr %l141
  %t237 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t233, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t228, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t230, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t237, ptr %l147
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  %t238 = load %"compiler/cabi:Way", ptr %l147
  store %"compiler/cabi:Way" %t238, ptr %rv
  br label %ret
bb73:
  %t239 = load i64, ptr %l4, !tbaa !24
  %t241 = icmp sle i64 %t239, 8
  br i1 %t241, label %bb74, label %bb75
bb74:
  %t243 = load ptr, ptr %lp6
  store ptr %t243, ptr %l150, !tbaa !29
  %t244 = load i1, ptr %l3, !tbaa !21
  br i1 %t244, label %bb76, label %bb77
bb75:
  %t246 = load ptr, ptr %lp6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t246, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb84
bb76:
  %t248 = load i64, ptr %l4, !tbaa !24
  %t250 = mul i64 %t248, 8
  %t251 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t254 = call i64 @__olang_fmt_i64(ptr null, i64 %t250)
  %t255 = add i64 %t252, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t251, i64 %t252)
  %t257 = getelementptr i8, ptr %t256, i64 %t252
  %t258 = call i64 @__olang_fmt_i64(ptr %t257, i64 %t250)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t256, 1
  store { i64, ptr } %t260, ptr %l152, !tbaa !27
  br label %bb78
bb77:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l156, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t262, ptr %l152, !tbaa !27
  br label %bb78
bb78:
  %t264 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  %t266 = extractvalue { i64, ptr } %t264, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = load ptr, ptr %l150, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t271, { i64, ptr } %t270)
  br label %bb79
bb79:
  %t273 = load ptr, ptr %lp8
  store ptr %t273, ptr %l159, !tbaa !29
  %t274 = load i1, ptr %l3, !tbaa !21
  br i1 %t274, label %bb80, label %bb81
bb80:
  %t276 = load i64, ptr %l4, !tbaa !24
  store i64 %t276, ptr %l161, !tbaa !24
  br label %bb82
bb81:
  store i64 8, ptr %l161, !tbaa !24
  br label %bb82
bb82:
  %t278 = load ptr, ptr %l159, !tbaa !29
  %t279 = load i64, ptr %l161, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t278, i64 %t279)
  br label %bb83
bb83:
  br label %bb86
bb84:
  %t280 = load ptr, ptr %lp8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t280, i64 16)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t282 = load ptr, ptr %lp7
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t282, i64 0)
  br label %bb87
bb87:
  %t284 = load ptr, ptr %lp6
  %t285 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t284
  %t286 = load ptr, ptr %lp7
  %t287 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t286
  %t288 = load ptr, ptr %lp8
  %t289 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t288
  %t294 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t285, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t287, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t289, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t294, ptr %l170
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s0)
  %t295 = load %"compiler/cabi:Way", ptr %l170
  store %"compiler/cabi:Way" %t295, ptr %rv
  br label %ret
bb89:
  %t296 = load i64, ptr %l4, !tbaa !24
  %t298 = icmp sgt i64 %t296, 16
  br i1 %t298, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb92
bb91:
  %t300 = load i64, ptr %l4, !tbaa !24
  %t302 = icmp eq i64 %t300, 0
  store i1 %t302, ptr %l173, !tbaa !21
  br label %bb92
bb92:
  %t304 = load i1, ptr %l173, !tbaa !21
  br i1 %t304, label %bb93, label %bb94
bb93:
  %t305 = load i1, ptr %l3, !tbaa !21
  br i1 %t305, label %bb95, label %bb96
bb94:
  br label %bb99
bb95:
  store i32 4, ptr %l177
  br label %bb97
bb96:
  store i32 2, ptr %l177
  br label %bb97
bb97:
  %t309 = load ptr, ptr %lp6
  %t310 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t309
  %t311 = load ptr, ptr %lp7
  %t312 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t311
  %t313 = load ptr, ptr %lp8
  %t314 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t313
  %t315 = load i32, ptr %l177
  %t319 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t315, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t310, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t312, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t314, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t319, ptr %l183
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t320 = load %"compiler/cabi:Way", ptr %l183
  store %"compiler/cabi:Way" %t320, ptr %rv
  br label %ret
bb99:
  store i64 0, ptr %l21, !tbaa !24
  %t321 = load i64, ptr %l4, !tbaa !24
  %t323 = add i64 %t321, 7
  %t325 = sdiv i64 %t323, 8
  store i64 %t325, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t327 = load i64, ptr %l22, !tbaa !24
  %t328 = load i64, ptr %l21, !tbaa !24
  %t331 = icmp sgt i64 %t327, %t328
  br i1 %t331, label %bb100, label %bb101
bb100:
  %t333 = load i64, ptr %l23, !tbaa !24
  %t335 = icmp sgt i64 %t333, 0
  br i1 %t335, label %bb102, label %bb103
bb101:
  store i64 0, ptr %l190, !tbaa !24
  br label %bb105
bb102:
  %t337 = load i64, ptr %l22, !tbaa !24
  %t338 = load i64, ptr %l21, !tbaa !24
  %t341 = sub i64 %t337, %t338
  %t342 = load i64, ptr %l23, !tbaa !24
  %t345 = add i64 %t341, %t342
  %t347 = sub i64 %t345, 1
  %t348 = load i64, ptr %l23, !tbaa !24
  %t351 = sdiv i64 %t347, %t348
  store i64 %t351, ptr %l193, !tbaa !24
  br label %bb104
bb103:
  store i64 0, ptr %l193, !tbaa !24
  br label %bb104
bb104:
  %t353 = load i64, ptr %l193, !tbaa !24
  store i64 %t353, ptr %l190, !tbaa !24
  br label %bb105
bb105:
  %t354 = load i64, ptr %l190, !tbaa !24
  store i64 %t354, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s20
  %t355 = load i64, ptr %l25, !tbaa !24
  %t356 = load i64, ptr %l24, !tbaa !24
  %t359 = icmp slt i64 %t355, %t356
  %t361 = xor i1 %t359, true
  br i1 %t361, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s20)
  br label %bb139
bb108:
  br label %bb109
bb109:
  %t363 = load i64, ptr %l21, !tbaa !24
  %t364 = load i64, ptr %l25, !tbaa !24
  %t365 = load i64, ptr %l23, !tbaa !24
  %t368 = mul i64 %t364, %t365
  %t371 = add i64 %t363, %t368
  %t375 = mul i64 %t371, 8
  store i64 %t375, ptr %l27, !tbaa !24
  %t377 = load i64, ptr %l27, !tbaa !24
  %t379 = add i64 %t377, 8
  store i64 %t379, ptr %l28, !tbaa !24
  store i1 true, ptr %l29, !tbaa !21
  store i1 false, ptr %l30, !tbaa !21
  store ptr %l5, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb110
bb110:
  %t382 = load i64, ptr %l32, !tbaa !24
  store i64 %t382, ptr %l216, !tbaa !24
  %t383 = load ptr, ptr %l31, !tbaa !29
  %t385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %t383)
  store i64 %t385, ptr %l218
  br label %bb111
bb111:
  %t386 = load i64, ptr %l216, !tbaa !24
  %t387 = load i64, ptr %l218, !tbaa !24
  %t388 = icmp slt i64 %t386, %t387
  %t390 = xor i1 %t388, true
  br i1 %t390, label %bb112, label %bb113
bb112:
  br label %bb126
bb113:
  br label %bb114
bb114:
  %t392 = load ptr, ptr %l31, !tbaa !29
  %t393 = load i64, ptr %l32, !tbaa !24
  %t396 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %s0, ptr %s0, ptr %t392, i64 %t393)
  store %"compiler/cabi:Scalar" %t396, ptr %l223
  br label %bb115
bb115:
  %t397 = load %"compiler/cabi:Scalar", ptr %l223
  store %"compiler/cabi:Scalar" %t397, ptr %l33
  %t398 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 0
  %t399 = load i64, ptr %t398, !tbaa !24
  %t400 = load i64, ptr %l27, !tbaa !24
  %t403 = icmp sge i64 %t399, %t400
  br i1 %t403, label %bb116, label %bb117
bb116:
  %t405 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 0
  %t406 = load i64, ptr %t405, !tbaa !24
  %t407 = load i64, ptr %l28, !tbaa !24
  %t410 = icmp slt i64 %t406, %t407
  store i1 %t410, ptr %l227, !tbaa !21
  br label %bb118
bb117:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb118
bb118:
  %t412 = load i1, ptr %l227, !tbaa !21
  br i1 %t412, label %bb119, label %bb120
bb119:
  store i1 true, ptr %l30, !tbaa !21
  %t413 = getelementptr %"compiler/cabi:Scalar", ptr %l33, i32 0, i32 3
  %t414 = load i1, ptr %t413, !tbaa !21
  %t416 = xor i1 %t414, true
  br i1 %t416, label %bb121, label %bb122
bb120:
  br label %bb124
bb121:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb123
bb122:
  br label %bb123
bb123:
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t418 = load i64, ptr %l32, !tbaa !24
  %t420 = add i64 %t418, 1
  store i64 %t420, ptr %l32, !tbaa !24
  br label %bb110
bb126:
  %t422 = load i1, ptr %l30, !tbaa !21
  %t424 = xor i1 %t422, true
  br i1 %t424, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s20)
  br label %bb138
bb128:
  br label %bb129
bb129:
  %t426 = load i1, ptr %l29, !tbaa !21
  br i1 %t426, label %bb130, label %bb131
bb130:
  %t428 = load i64, ptr %l27, !tbaa !24
  %t431 = call { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %s0, ptr %s20, ptr %l5, i64 %t428)
  store { { i64, ptr }, i64 } %t431, ptr %l241
  br label %bb132
bb131:
  %t432 = load i64, ptr %l27, !tbaa !24
  %t433 = load i64, ptr %l4, !tbaa !24
  %t437 = call { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %s0, ptr %s20, ptr %l5, i64 %t432, i64 %t433)
  store { { i64, ptr }, i64 } %t437, ptr %l245
  br label %bb133
bb132:
  %t438 = load { { i64, ptr }, i64 }, ptr %l241
  store { { i64, ptr }, i64 } %t438, ptr %l238
  br label %bb134
bb133:
  %t439 = load { { i64, ptr }, i64 }, ptr %l245
  store { { i64, ptr }, i64 } %t439, ptr %l238
  br label %bb134
bb134:
  %t440 = load { { i64, ptr }, i64 }, ptr %l238
  store { { i64, ptr }, i64 } %t440, ptr %l34
  %t441 = getelementptr { { i64, ptr }, i64 }, ptr %l34, i32 0, i32 0
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  store { i64, ptr } %t442, ptr %l246, !tbaa !27
  %t443 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 0
  store i64 %t444, ptr %l247, !tbaa !24
  %t445 = load i64, ptr %l247, !tbaa !24
  %t446 = mul i64 %t445, 1
  %t447 = call ptr @__olang_scope_alloc_zeroed(ptr %s20, i64 %t446)
  %t448 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  store { i64, ptr } %t449, ptr %l248, !tbaa !27
  %t450 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !27
  %t454 = load i64, ptr %l247, !tbaa !24
  %t455 = mul i64 %t454, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t451, ptr %t453, i64 %t455, i1 false)
  %t456 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t457 = getelementptr { { i64, ptr }, i64 }, ptr %l34, i32 0, i32 1
  %t458 = load i64, ptr %t457, !tbaa !24
  store i64 %t458, ptr %l36, !tbaa !24
  %t460 = load ptr, ptr %lp6
  %t463 = extractvalue { i64, ptr } %t456, 1
  %t464 = extractvalue { i64, ptr } %t456, 0
  %t465 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t464)
  call void @olang_textcopy(ptr %t465, ptr %t463, i64 %t464)
  %t466 = insertvalue { i64, ptr } undef, i64 %t464, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = extractvalue { i64, ptr } %t467, 1
  %t471 = mul i64 %t469, 1
  %t472 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t471)
  call void @llvm.memcpy.p0.p0.i64(ptr %t472, ptr %t470, i64 %t471, i1 false)
  %t473 = insertvalue { i64, ptr } undef, i64 %t469, 0
  %t474 = insertvalue { i64, ptr } %t473, ptr %t472, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t460, { i64, ptr } %t474)
  br label %bb135
bb135:
  %t477 = load ptr, ptr %lp7
  %t478 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t477, i64 %t478)
  br label %bb136
bb136:
  %t481 = load ptr, ptr %lp8
  %t482 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t481, i64 %t482)
  br label %bb137
bb137:
  call void @__olang_scope_close(ptr %s20)
  br label %bb138
bb138:
  %t485 = load i64, ptr %l25, !tbaa !24
  %t487 = add i64 %t485, 1
  store i64 %t487, ptr %l25, !tbaa !24
  br label %bb106
bb139:
  %t489 = load ptr, ptr %lp6
  %t490 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t489
  %t491 = load ptr, ptr %lp7
  %t492 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t491
  %t493 = load ptr, ptr %lp8
  %t494 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t493
  %t499 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t490, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t492, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t494, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t499, ptr %l264
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s0)
  %t500 = load %"compiler/cabi:Way", ptr %l264
  store %"compiler/cabi:Way" %t500, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %a2)
  store i32 %t27, ptr %l13
  br label %bb5
bb5:
  %t28 = load i32, ptr %l13, !tbaa !23
  store i32 %t28, ptr %l3, !tbaa !23
  %t29 = load i32, ptr %l3, !tbaa !23
  %t30 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t33 = icmp eq i32 %t29, %t30
  br i1 %t33, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %l18, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l19, !tbaa !24
  %t38 = load i64, ptr %l19, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l20, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l19, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t49, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t51, i32 %t52)
  store i1 %t55, ptr %l23
  br label %bb9
bb9:
  %t56 = load i1, ptr %l23, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l28
  br label %bb12
bb12:
  %t64 = load i64, ptr %l28, !tbaa !24
  %t65 = icmp sge i64 %t64, 32
  store i1 %t65, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l25, !tbaa !21
  br i1 %t67, label %bb14, label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l30, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l32, !tbaa !24
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l33, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l32, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t82, ptr %l31, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t83 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t83, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l36
  br label %bb17
bb17:
  %t89 = load i1, ptr %l36, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t90, ptr %l37, !tbaa !27
  br label %bb20
bb19:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t92, ptr %l37, !tbaa !27
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l43, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l42, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t107, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t108 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t108, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i32
  %l31 = alloca ptr
  %l33 = alloca %"compiler/cabi:Scalar"
  %l36 = alloca i32
  %l41 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i32
  %l49 = alloca i64
  %l50 = alloca ptr
  %l53 = alloca i32
  %l54 = alloca i64
  %l59 = alloca i64
  %l62 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca i32
  %l82 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i64
  %l94 = alloca i32
  %l97 = alloca i1
  %l98 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i32
  %l105 = alloca ptr
  %l108 = alloca i32
  %l109 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l118 = alloca i64
  %l121 = alloca i64
  %l140 = alloca { i64, ptr }
  %l152 = alloca i64
  %l156 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l162 = alloca ptr
  %l163 = alloca i64
  %l164 = alloca i64
  %l167 = alloca { i64, ptr }
  %l170 = alloca i1
  %l171 = alloca %"compiler/cabi:Scalar"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l25
  br label %bb1
bb1:
  %t6 = load i32, ptr %l25, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l4, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l28
  br label %bb2
bb2:
  %t12 = load i32, ptr %l28
  %t14 = trunc i64 20 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l3, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t18, i64 8, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) }, i1 false)
  store %"compiler/cabi:Scalar" %t20, ptr %l33
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l31, !tbaa !29
  %t22 = load %"compiler/cabi:Scalar", ptr %l33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t21, %"compiler/cabi:Scalar" %t22)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l36
  br label %bb8
bb8:
  %t28 = load i32, ptr %l36
  %t30 = trunc i64 19 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l41
  br label %bb11
bb10:
  br label %bb33
bb11:
  %t38 = load i32, ptr %l41, !tbaa !23
  store i32 %t38, ptr %l5, !tbaa !23
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l42, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l4, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l45
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l42, !tbaa !29
  %t46 = load i32, ptr %l45, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t45, i32 %t46)
  store i32 %t47, ptr %l46
  br label %bb13
bb13:
  %t48 = load i32, ptr %l46
  %t50 = trunc i64 26 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l50, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l4, !tbaa !23
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t54, i32 %t55)
  store i32 %t58, ptr %l53
  br label %bb16
bb15:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb18
bb16:
  %t59 = load ptr, ptr %l50, !tbaa !29
  %t60 = load i32, ptr %l53, !tbaa !23
  %t61 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t61, ptr %l54
  br label %bb17
bb17:
  %t62 = load i64, ptr %l54, !tbaa !24
  store i64 %t62, ptr %l49, !tbaa !24
  br label %bb18
bb18:
  %t63 = load i64, ptr %l49, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = load i64, ptr %l9, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb24
bb21:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l7, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l62, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb23
bb23:
  %t92 = load i64, ptr %l62, !tbaa !24
  store i64 %t92, ptr %l59, !tbaa !24
  br label %bb24
bb24:
  %t93 = load i64, ptr %l59, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t94 = load i64, ptr %l11, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb26, label %bb27
bb26:
  br label %bb32
bb27:
  br label %bb28
bb28:
  %t102 = load i64, ptr %l7, !tbaa !24
  %t103 = load i64, ptr %l11, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l80, !tbaa !29
  %t113 = load i32, ptr %l5, !tbaa !23
  store i32 %t113, ptr %l81, !tbaa !23
  %t114 = load i64, ptr %l2, !tbaa !24
  store i64 %t114, ptr %l82, !tbaa !24
  store i64 %t110, ptr %l83, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load i32, ptr %l5, !tbaa !23
  %t120 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t116, i32 %t117)
  store i64 %t120, ptr %l86
  br label %bb29
bb29:
  %t121 = load i64, ptr %l83, !tbaa !24
  %t122 = load i64, ptr %l86, !tbaa !24
  %t123 = mul i64 %t121, %t122
  %t124 = load i64, ptr %l82, !tbaa !24
  %t126 = add i64 %t124, %t123
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t128 = load ptr, ptr %l80, !tbaa !29
  %t129 = load i32, ptr %l81, !tbaa !23
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %t128, i32 %t129, i64 %t126, ptr %t127)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t132 = load i64, ptr %l11, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l11, !tbaa !24
  br label %bb25
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  %t140 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t136, i32 %t137)
  store i32 %t140, ptr %l94
  br label %bb34
bb34:
  %t141 = load i32, ptr %l94
  %t143 = trunc i64 18 to i32
  %t144 = icmp eq i32 %t141, %t143
  br i1 %t144, label %bb35, label %bb36
bb35:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l98, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i32, ptr %l4, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l101
  br label %bb37
bb36:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb39
bb37:
  %t152 = load ptr, ptr %l98, !tbaa !29
  %t153 = load i32, ptr %l101, !tbaa !23
  %t154 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t154, ptr %l102
  br label %bb38
bb38:
  %t155 = load i32, ptr %l102
  %t157 = trunc i64 0 to i32
  %t158 = icmp eq i32 %t155, %t157
  store i1 %t158, ptr %l97, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l97, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l105, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t163 = load i32, ptr %l4, !tbaa !23
  %t166 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t162, i32 %t163)
  store i32 %t166, ptr %l108
  br label %bb42
bb41:
  br label %bb58
bb42:
  %t167 = load ptr, ptr %l105, !tbaa !29
  %t168 = load i32, ptr %l108, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t167, i32 %t168)
  store { i64, ptr } %t169, ptr %l109
  br label %bb43
bb43:
  %t170 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t170, ptr %l13, !tbaa !27
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l4, !tbaa !23
  %t175 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %s6, ptr %t171, i32 %t172)
  store { i64, ptr } %t175, ptr %l112
  br label %bb44
bb44:
  %t176 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t176, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  store i64 %t179, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t181 = load i64, ptr %l16, !tbaa !24
  %t182 = load i64, ptr %l15, !tbaa !24
  %t185 = icmp sgt i64 %t181, %t182
  br i1 %t185, label %bb45, label %bb46
bb45:
  %t187 = load i64, ptr %l17, !tbaa !24
  %t189 = icmp sgt i64 %t187, 0
  br i1 %t189, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb50
bb47:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = sub i64 %t191, %t192
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = add i64 %t195, %t196
  %t201 = sub i64 %t199, 1
  %t202 = load i64, ptr %l17, !tbaa !24
  %t205 = sdiv i64 %t201, %t202
  store i64 %t205, ptr %l121, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb49
bb49:
  %t207 = load i64, ptr %l121, !tbaa !24
  store i64 %t207, ptr %l118, !tbaa !24
  br label %bb50
bb50:
  %t208 = load i64, ptr %l118, !tbaa !24
  store i64 %t208, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb51
bb51:
  %t209 = load i64, ptr %l19, !tbaa !24
  %t210 = load i64, ptr %l18, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb52, label %bb53
bb52:
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t217 = load i64, ptr %l15, !tbaa !24
  %t218 = load i64, ptr %l19, !tbaa !24
  %t219 = load i64, ptr %l17, !tbaa !24
  %t222 = mul i64 %t218, %t219
  %t225 = add i64 %t217, %t222
  store i64 %t225, ptr %l20, !tbaa !24
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t228, ptr %l140, !tbaa !27
  %t229 = load i64, ptr %l20, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i32, ptr %t232, i64 %t229
  %t234 = load i32, ptr %t233, !tbaa !33
  %t235 = load i64, ptr %l2, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i64, ptr %t239, i64 %t236
  %t241 = load i64, ptr %t240, !tbaa !34
  %t244 = add i64 %t235, %t241
  %t245 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcabi_2eFlatten(ptr %v0, ptr %v1, ptr %t227, i32 %t234, i64 %t244, ptr %t245)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t252 = add i64 %t250, 1
  store i64 %t252, ptr %l19, !tbaa !24
  br label %bb51
bb57:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb58:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i32, ptr %l4, !tbaa !23
  %t258 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t254, i32 %t255)
  store i64 %t258, ptr %l152
  br label %bb59
bb59:
  %t259 = load i64, ptr %l152, !tbaa !24
  store i64 %t259, ptr %l21, !tbaa !24
  %t260 = load i32, ptr %l4, !tbaa !23
  %t261 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t264 = icmp eq i32 %t260, %t261
  br i1 %t264, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l156, !tbaa !27
  br label %bb63
bb61:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l4, !tbaa !23
  %t270 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t266, i32 %t267)
  store { i64, ptr } %t270, ptr %l159
  br label %bb62
bb62:
  %t271 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t272, i64 %t273)
  %t275 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = extractvalue { i64, ptr } %t276, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l156, !tbaa !27
  br label %bb63
bb63:
  %t285 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t286 = load ptr, ptr %l3, !tbaa !29
  store ptr %t286, ptr %l162, !tbaa !29
  %t287 = load i64, ptr %l2, !tbaa !24
  store i64 %t287, ptr %l163, !tbaa !24
  %t288 = load i64, ptr %l21, !tbaa !24
  store i64 %t288, ptr %l164, !tbaa !24
  %t291 = extractvalue { i64, ptr } %t285, 1
  %t292 = extractvalue { i64, ptr } %t285, 0
  %t293 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t291, i64 %t292)
  %t294 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = extractvalue { i64, ptr } %t295, 1
  %t299 = mul i64 %t297, 1
  %t300 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t299)
  call void @llvm.memcpy.p0.p0.i64(ptr %t300, ptr %t298, i64 %t299, i1 false)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l167, !tbaa !27
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l4, !tbaa !23
  %t307 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t303, i32 %t304)
  store i1 %t307, ptr %l170
  br label %bb64
bb64:
  %t308 = load i64, ptr %l163, !tbaa !24
  %t309 = load i64, ptr %l164, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t311 = load i1, ptr %l170, !tbaa !21
  %t312 = call %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v1, ptr %v1, i64 %t308, i64 %t309, { i64, ptr } %t310, i1 %t311)
  store %"compiler/cabi:Scalar" %t312, ptr %l171
  br label %bb65
bb65:
  %t313 = load ptr, ptr %l162, !tbaa !29
  %t314 = load %"compiler/cabi:Scalar", ptr %l171
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v1, ptr %v1, ptr %t313, %"compiler/cabi:Scalar" %t314)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1, i32 %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t7, i32 %t8)
  store i32 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i32, ptr %l8
  %t14 = trunc i64 18 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l2, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb5
bb4:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i32, ptr %l16
  %t28 = trunc i64 0 to i32
  %t29 = icmp eq i32 %t26, %t28
  store i1 %t29, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l11, !tbaa !21
  store i1 %t31, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l13 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l21 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca { i64, ptr }
  %l36 = alloca %"compiler/cabi:Way"
  %l40 = alloca %"compiler/cabi:Way"
  %l42 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca { i64, ptr }
  %l56 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i32
  %l73 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"compiler/cabi:Way"
  %l77 = alloca ptr
  %l81 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l2, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l17
  br label %bb4
bb3:
  br label %bb14
bb4:
  %t14 = load i32, ptr %l17, !tbaa !23
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t15, i32 %t14)
  store i1 %t19, ptr %l20
  br label %bb5
bb5:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  store ptr %t21, ptr %l21, !tbaa !29
  %t22 = load ptr, ptr %l21, !tbaa !29
  %t23 = getelementptr %"compiler/cabi:Regs", ptr %t22, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = sub i64 %t24, 1
  %t28 = load ptr, ptr %l21, !tbaa !29
  %t29 = getelementptr %"compiler/cabi:Regs", ptr %t28, i32 0, i32 1
  store i64 %t26, ptr %t29, !tbaa !24
  br label %bb8
bb7:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l24, !tbaa !29
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = getelementptr %"compiler/cabi:Regs", ptr %t31, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t35 = sub i64 %t33, 1
  %t37 = load ptr, ptr %l24, !tbaa !29
  %t38 = getelementptr %"compiler/cabi:Regs", ptr %t37, i32 0, i32 0
  store i64 %t35, ptr %t38, !tbaa !24
  br label %bb8
bb8:
  store i32 0, ptr %l27
  %t39 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l28
  br label %bb9
bb9:
  %t40 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l29
  br label %bb10
bb10:
  %t41 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l30
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t44 = load i32, ptr %l2, !tbaa !23
  %t48 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v3, ptr %t42, { i64, ptr } %t43, i32 %t44)
  store { i64, ptr } %t48, ptr %l34
  br label %bb12
bb12:
  %t49 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  %t56 = load i32, ptr %l27
  %t57 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  %t58 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  %t59 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  %t61 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t56, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, { i64, ptr } %t55)
  store %"compiler/cabi:Way" %t61, ptr %l36
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t62 = load %"compiler/cabi:Way", ptr %l36
  store %"compiler/cabi:Way" %t62, ptr %rv
  br label %ret
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t65 = load i32, ptr %l2, !tbaa !23
  %t69 = call %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v3, ptr %t63, { i64, ptr } %t64, i32 %t65, i1 false)
  store %"compiler/cabi:Way" %t69, ptr %l40
  br label %bb15
bb15:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store ptr %t70, ptr %lp5
  %t71 = load %"compiler/cabi:Way", ptr %l40
  %t72 = load ptr, ptr %lp5
  store %"compiler/cabi:Way" %t71, ptr %t72
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t75 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t73, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t75, ptr %l42
  br label %bb16
bb16:
  %t76 = load i1, ptr %l42, !tbaa !21
  br i1 %t76, label %bb17, label %bb18
bb17:
  %t77 = load ptr, ptr %lp5
  %t78 = getelementptr %"compiler/cabi:Way", ptr %t77, i32 0, i32 0
  %t79 = load i32, ptr %t78
  %t81 = trunc i64 1 to i32
  %t82 = icmp eq i32 %t79, %t81
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l43, !tbaa !21
  br i1 %t84, label %bb20, label %bb21
bb20:
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  %t85 = load ptr, ptr %lp5
  %t86 = getelementptr %"compiler/cabi:Way", ptr %t85, i32 0, i32 1
  store ptr %t86, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb22
bb21:
  br label %bb44
bb22:
  %t88 = load i64, ptr %l9, !tbaa !24
  store i64 %t88, ptr %l47, !tbaa !24
  %t89 = load ptr, ptr %l8, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t89)
  store i64 %t91, ptr %l49
  br label %bb23
bb23:
  %t92 = load i64, ptr %l47, !tbaa !24
  %t93 = load i64, ptr %l49, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t98 = load ptr, ptr %l8, !tbaa !29
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t98, i64 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb27
bb27:
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t106 = call i1 @compiler_2fcabi_2einSse(ptr %v3, { i64, ptr } %t103)
  store i1 %t106, ptr %l56
  br label %bb28
bb28:
  %t107 = load i1, ptr %l56, !tbaa !21
  br i1 %t107, label %bb29, label %bb30
bb29:
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb31
bb30:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t114 = add i64 %t112, 1
  store i64 %t114, ptr %l6, !tbaa !24
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l9, !tbaa !24
  br label %bb22
bb33:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t121 = load ptr, ptr %l3, !tbaa !29
  %t123 = getelementptr %"compiler/cabi:Regs", ptr %t121, i32 0, i32 0
  %t124 = load i64, ptr %t123, !tbaa !24
  %t127 = icmp sgt i64 %t120, %t124
  br i1 %t127, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb36
bb35:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load ptr, ptr %l3, !tbaa !29
  %t132 = getelementptr %"compiler/cabi:Regs", ptr %t130, i32 0, i32 1
  %t133 = load i64, ptr %t132, !tbaa !24
  %t136 = icmp sgt i64 %t129, %t133
  store i1 %t136, ptr %l67, !tbaa !21
  br label %bb36
bb36:
  %t138 = load i1, ptr %l67, !tbaa !21
  br i1 %t138, label %bb37, label %bb38
bb37:
  store i32 2, ptr %l72
  %t139 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t139, ptr %l73
  br label %bb39
bb38:
  br label %bb43
bb39:
  %t140 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %l74
  br label %bb40
bb40:
  %t141 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t141, ptr %l75
  br label %bb41
bb41:
  %t142 = load i32, ptr %l72
  %t143 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l73
  %t144 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  %t145 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  %t146 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %v3, i32 %t142, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t145, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store %"compiler/cabi:Way" %t146, ptr %l76
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load %"compiler/cabi:Way", ptr %l76
  store %"compiler/cabi:Way" %t147, ptr %rv
  br label %ret
bb43:
  %t148 = load ptr, ptr %l3, !tbaa !29
  store ptr %t148, ptr %l77, !tbaa !29
  %t149 = load ptr, ptr %l77, !tbaa !29
  %t150 = getelementptr %"compiler/cabi:Regs", ptr %t149, i32 0, i32 0
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr %l6, !tbaa !24
  %t155 = sub i64 %t151, %t152
  %t157 = load ptr, ptr %l77, !tbaa !29
  %t158 = getelementptr %"compiler/cabi:Regs", ptr %t157, i32 0, i32 0
  store i64 %t155, ptr %t158, !tbaa !24
  %t159 = load ptr, ptr %l3, !tbaa !29
  store ptr %t159, ptr %l81, !tbaa !29
  %t160 = load ptr, ptr %l81, !tbaa !29
  %t161 = getelementptr %"compiler/cabi:Regs", ptr %t160, i32 0, i32 1
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr %l7, !tbaa !24
  %t166 = sub i64 %t162, %t163
  %t168 = load ptr, ptr %l81, !tbaa !29
  %t169 = getelementptr %"compiler/cabi:Regs", ptr %t168, i32 0, i32 1
  store i64 %t166, ptr %t169, !tbaa !24
  br label %bb44
bb44:
  %t170 = load ptr, ptr %lp5
  %t171 = load %"compiler/cabi:Way", ptr %t170
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/cabi:Way" %t171, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca i64
  %l11 = alloca i64
  %l17 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t5 = getelementptr %"compiler/cabi:Way", ptr %a0, i32 0, i32 1
  store ptr %t5, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb14
bb5:
  br label %bb6
bb6:
  %t17 = load i64, ptr %l3, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l17
  br label %bb7
bb7:
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d25, i32 0, i32 1) })
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t30)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l3, !tbaa !24
  br label %bb2
bb14:
  %t38 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t38, ptr %l26
  br label %bb15
bb15:
  %t39 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t39, ptr %l27, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = mul i64 %t42, 1
  %t44 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t43)
  %t45 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  store { i64, ptr } %t46, ptr %l29, !tbaa !27
  %t47 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = mul i64 %t51, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %t50, i64 %t52, i1 false)
  %t53 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t53, ptr %l27, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca i64
  %l20 = alloca i64
  %l26 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/cabi:Way", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  %t7 = icmp eq i64 %t6, 1
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/cabi:Way", ptr %t9, i32 0, i32 1
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %s1, ptr %t11, i64 0)
  store { i64, ptr } %t13, ptr %l12
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  call void @olang_textcopy(ptr %t17, ptr %t15, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t19, ptr %rv
  br label %ret
bb5:
  %t21 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t21, ptr %l14
  br label %bb6
bb6:
  %t22 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t22, ptr %l1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) })
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/cabi:Way", ptr %t24, i32 0, i32 1
  store ptr %t26, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb8
bb8:
  %t28 = load i64, ptr %l3, !tbaa !24
  store i64 %t28, ptr %l18, !tbaa !24
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l20
  br label %bb9
bb9:
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb10, label %bb11
bb10:
  br label %bb20
bb11:
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l4, !tbaa !24
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t40, i64 %t41)
  store { i64, ptr } %t44, ptr %l26
  br label %bb13
bb13:
  %t45 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t45, ptr %l5, !tbaa !27
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t51)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t54 = load i64, ptr %l3, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l3, !tbaa !24
  br label %bb8
bb20:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb21
bb21:
  %t60 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t60, ptr %l36
  br label %bb22
bb22:
  %t61 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l38, !tbaa !24
  %t64 = load i64, ptr %l38, !tbaa !24
  %t65 = mul i64 %t64, 1
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l38, !tbaa !24
  %t74 = mul i64 %t73, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t75, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l5 = alloca i1
  %l7 = alloca i32
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/cabi:Way"
  %l20 = alloca %"compiler/cabi:Way"
  %rv = alloca %"compiler/cabi:Way"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcabi_2eIsStruct(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i32 0, ptr %l7
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l8
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l9
  br label %bb5
bb5:
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l10
  br label %bb6
bb6:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t14 = load i32, ptr %l2, !tbaa !23
  %t18 = call { i64, ptr } @compiler_2fcabi_2eExt(ptr %v0, ptr %v1, ptr %v2, ptr %t12, { i64, ptr } %t13, i32 %t14)
  store { i64, ptr } %t18, ptr %l14
  br label %bb7
bb7:
  %t19 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = mul i64 %t20, 1
  %t23 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t22)
  call void @llvm.memcpy.p0.p0.i64(ptr %t23, ptr %t21, i64 %t22, i1 false)
  %t24 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  %t26 = load i32, ptr %l7
  %t27 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t28 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t29 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t31 = call %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, ptr %v2, i32 %t26, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, { i64, ptr } %t25)
  store %"compiler/cabi:Way" %t31, ptr %l16
  br label %bb8
bb8:
  %t32 = load %"compiler/cabi:Way", ptr %l16
  store %"compiler/cabi:Way" %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t35 = load i32, ptr %l2, !tbaa !23
  %t39 = call %"compiler/cabi:Way" @compiler_2fcabi_2eClassify(ptr %v0, ptr %v1, ptr %v2, ptr %t33, { i64, ptr } %t34, i32 %t35, i1 true)
  store %"compiler/cabi:Way" %t39, ptr %l20
  br label %bb10
bb10:
  %t40 = load %"compiler/cabi:Way", ptr %l20
  store %"compiler/cabi:Way" %t40, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

define dso_local i64 @compiler_2fcabi_2eSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %rv = alloca i64
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = getelementptr %"compiler/cabi:Way", ptr %t7, i32 0, i32 1
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l22, !tbaa !24
  store i64 %t39, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l19, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb10, label %bb11
bb10:
  br label %bb21
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/cabi:Way", ptr %t59, i32 0, i32 2
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t61, i64 %t62)
  store i64 %t65, ptr %l43
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/cabi:Way", ptr %t66, i32 0, i32 3
  %t69 = load i64, ptr %l9, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l47
  br label %bb14
bb14:
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = load i64, ptr %l47, !tbaa !24
  %t75 = add i64 %t73, %t74
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = icmp sgt i64 %t75, %t76
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/cabi:Way", ptr %t81, i32 0, i32 2
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l54
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/cabi:Way", ptr %t88, i32 0, i32 3
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l58
  br label %bb18
bb18:
  %t95 = load i64, ptr %l54, !tbaa !24
  %t96 = load i64, ptr %l58, !tbaa !24
  %t97 = add i64 %t95, %t96
  store i64 %t97, ptr %l3, !tbaa !24
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t99 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb9
bb21:
  %t103 = load i64, ptr %l3, !tbaa !24
  store i64 %t103, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcabi_2eat(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/cabi:Scalar"
  %l7 = alloca i64
  %l9 = alloca i64
  %l15 = alloca %"compiler/cabi:Scalar"
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/cabi:Scalar" %t19, ptr %l15
  br label %bb6
bb6:
  %t20 = load %"compiler/cabi:Scalar", ptr %l15
  store %"compiler/cabi:Scalar" %t20, ptr %l5
  %t21 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = icmp eq i64 %t22, %a1
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcabi_2edata(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/cabi:Scalar"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca %"compiler/cabi:Scalar"
  %l18 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store %"compiler/cabi:Scalar" %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load %"compiler/cabi:Scalar", ptr %l14
  store %"compiler/cabi:Scalar" %t18, ptr %l5
  %t19 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  %t24 = icmp slt i64 %t20, %a2
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/cabi:Scalar", ptr %l5, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = add i64 %t27, %t29
  %t36 = icmp sgt i64 %t32, %a1
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb10, label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  br label %bb1
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcabi_2einSse(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb7:
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t12, ptr %l8
  br label %bb8
bb8:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb13
bb11:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t15, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t17, ptr %l11
  br label %bb12
bb12:
  %t18 = load i1, ptr %l11, !tbaa !21
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb13
bb13:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb17
bb15:
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t22, ptr %l14
  br label %bb16
bb16:
  %t23 = load i1, ptr %l14, !tbaa !21
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load i1, ptr %l12, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2eintAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/cabi:Scalar"
  %l5 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca %"compiler/cabi:Scalar"
  %l20 = alloca %"compiler/cabi:Scalar"
  %l22 = alloca i1
  %l23 = alloca i1
  %l35 = alloca i1
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l3, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %s0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  %t20 = xor i1 %t18, true
  store i1 %t20, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l11, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store %"compiler/cabi:Scalar" %t27, ptr %l20
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t28 = load %"compiler/cabi:Scalar", ptr %l20
  store %"compiler/cabi:Scalar" %t28, ptr %l4
  %t29 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t30, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t32, ptr %l22
  br label %bb9
bb9:
  %t33 = load i1, ptr %l22, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t34 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = icmp eq i64 %t35, 8
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t40 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t47, 0
  %t50 = insertvalue { { i64, ptr }, i64 } %t49, i64 8, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t50, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t54 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = add i64 %t53, %t55
  %t59 = load i64, ptr %l1, !tbaa !24
  %t61 = add i64 %t59, 8
  %t65 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t52, i64 %t58, i64 %t61)
  store i1 %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i1, ptr %l35, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t69 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = mul i64 %t70, 8
  %t73 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t76 = call i64 @__olang_fmt_i64(ptr null, i64 %t72)
  %t77 = add i64 %t74, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t73, i64 %t74)
  %t79 = getelementptr i8, ptr %t78, i64 %t74
  %t80 = call i64 @__olang_fmt_i64(ptr %t79, i64 %t72)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t78, 1
  %t83 = getelementptr %"compiler/cabi:Scalar", ptr %l4, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t82, 0
  %t88 = insertvalue { { i64, ptr }, i64 } %t86, i64 %t84, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t88, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  br label %bb20
bb20:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = sub i64 %a2, %t91
  %t96 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t94, i64 8)
  store i64 %t96, ptr %l45
  br label %bb21
bb21:
  %t97 = load i64, ptr %l45, !tbaa !24
  store i64 %t97, ptr %l5, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t100 = mul i64 %t98, 8
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t104 = call i64 @__olang_fmt_i64(ptr null, i64 %t100)
  %t105 = add i64 %t102, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t101, i64 %t102)
  %t107 = getelementptr i8, ptr %t106, i64 %t102
  %t108 = call i64 @__olang_fmt_i64(ptr %t107, i64 %t100)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t106, 1
  %t111 = load i64, ptr %l5, !tbaa !24
  %t113 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t110, 0
  %t115 = insertvalue { { i64, ptr }, i64 } %t113, i64 %t111, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t115, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fcabi_2esseAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/cabi:Scalar"
  %l8 = alloca i64
  %l11 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca %"compiler/cabi:Scalar"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"compiler/cabi:Scalar"
  %l36 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l46 = alloca i1
  %l48 = alloca { i64, ptr }
  %l50 = alloca i64
  %l59 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l71 = alloca i1
  %l83 = alloca i1
  %l91 = alloca i64
  %l93 = alloca i1
  %l94 = alloca i1
  %l97 = alloca i1
  %l101 = alloca %"compiler/cabi:Scalar"
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l106 = alloca { { i64, ptr }, i64 }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  store %"compiler/cabi:Scalar" %t16, ptr %l18
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l14, !tbaa !27
  br label %bb5
bb4:
  %t17 = getelementptr %"compiler/cabi:Scalar", ptr %l18, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t21, ptr %l21, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l22, !tbaa !24
  %t24 = load i64, ptr %l22, !tbaa !24
  %t25 = mul i64 %t24, 1
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l23, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load i64, ptr %l6, !tbaa !24
  store i64 %t38, ptr %l25, !tbaa !24
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %t39)
  store i64 %t41, ptr %l27
  br label %bb7
bb7:
  %t42 = load i64, ptr %l25, !tbaa !24
  %t43 = load i64, ptr %l27, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb9:
  br label %bb10
bb10:
  %t48 = load ptr, ptr %l5, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/cabi:Scalar" %t52, ptr %l32
  br label %bb11
bb11:
  %t53 = load %"compiler/cabi:Scalar", ptr %l32
  store %"compiler/cabi:Scalar" %t53, ptr %l7
  %t54 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 0
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = icmp sge i64 %t55, %t56
  br i1 %t59, label %bb12, label %bb13
bb12:
  %t61 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load i64, ptr %l1, !tbaa !24
  %t65 = add i64 %t63, 8
  %t68 = icmp slt i64 %t62, %t65
  store i1 %t68, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb15, label %bb16
bb15:
  %t71 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 1
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp eq i64 %t72, 2
  store i1 %t74, ptr %l41, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l41, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t77, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t79, ptr %l46
  br label %bb20
bb19:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb21
bb20:
  %t80 = load i1, ptr %l46, !tbaa !21
  store i1 %t80, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l44, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = getelementptr %"compiler/cabi:Scalar", ptr %l7, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 1
  %t86 = extractvalue { i64, ptr } %t83, 0
  %t87 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t85, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l48, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l50, !tbaa !24
  %t95 = load i64, ptr %l50, !tbaa !24
  %t96 = icmp eq i64 %t91, %t95
  br i1 %t96, label %bb24, label %bb25
bb23:
  br label %bb27
bb24:
  %t98 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l50, !tbaa !24
  %t103 = mul i64 %t102, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t99, ptr %t101, i64 %t103, i1 false)
  br label %bb26
bb25:
  %t104 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t104, ptr %l4, !tbaa !27
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l6, !tbaa !24
  br label %bb6
bb29:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i64, ptr %l1, !tbaa !24
  %t112 = add i64 %t110, 4
  %t113 = load i64, ptr %l1, !tbaa !24
  %t115 = add i64 %t113, 8
  %t119 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t109, i64 %t112, i64 %t115)
  store i1 %t119, ptr %l59
  br label %bb30
bb30:
  %t120 = load i1, ptr %l59, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t123, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t125, ptr %l62
  br label %bb33
bb32:
  br label %bb45
bb33:
  %t126 = load i1, ptr %l62, !tbaa !21
  br i1 %t126, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb37
bb35:
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t127, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t129, ptr %l65
  br label %bb36
bb36:
  %t130 = load i1, ptr %l65, !tbaa !21
  store i1 %t130, ptr %l63, !tbaa !21
  br label %bb37
bb37:
  %t131 = load i1, ptr %l63, !tbaa !21
  br i1 %t131, label %bb38, label %bb39
bb38:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t135 = add i64 %t133, 2
  %t136 = load i64, ptr %l1, !tbaa !24
  %t138 = add i64 %t136, 4
  %t142 = call i1 @compiler_2fcabi_2edata(ptr %v0, ptr %t132, i64 %t135, i64 %t138)
  store i1 %t142, ptr %l71
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t143 = load i1, ptr %l71, !tbaa !21
  %t144 = xor i1 %t143, true
  br i1 %t144, label %bb41, label %bb42
bb41:
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t148, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t152, 0
  %t155 = insertvalue { { i64, ptr }, i64 } %t154, i64 2, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t155, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t157 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t158 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t161 = extractvalue { i64, ptr } %t157, 1
  %t162 = extractvalue { i64, ptr } %t157, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t158, i64 %t159)
  %t168 = getelementptr i8, ptr %t167, i64 %t159
  call void @olang_textcopy(ptr %t168, ptr %t161, i64 %t162)
  %t169 = getelementptr i8, ptr %t168, i64 %t162
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t167, 1
  %t173 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t171, 0
  %t174 = insertvalue { { i64, ptr }, i64 } %t173, i64 4, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t174, ptr %rv
  br label %ret
bb44:
  %t176 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = extractvalue { i64, ptr } %t176, 0
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t178, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t184 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t182, 0
  %t185 = insertvalue { { i64, ptr }, i64 } %t184, i64 4, 1
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t185, ptr %rv
  br label %ret
bb45:
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t187, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t189, ptr %l83
  br label %bb46
bb46:
  %t190 = load i1, ptr %l83, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb47, label %bb48
bb47:
  %t193 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t194 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t197 = extractvalue { i64, ptr } %t193, 1
  %t198 = extractvalue { i64, ptr } %t193, 0
  %t199 = add i64 %t195, %t198
  %t200 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t194, i64 %t195)
  %t204 = getelementptr i8, ptr %t203, i64 %t195
  call void @olang_textcopy(ptr %t204, ptr %t197, i64 %t198)
  %t205 = getelementptr i8, ptr %t204, i64 %t198
  call void @olang_textcopy(ptr %t205, ptr %t200, i64 %t201)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t203, 1
  %t209 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t207, 0
  %t210 = insertvalue { { i64, ptr }, i64 } %t209, i64 8, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t210, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load i64, ptr %l1, !tbaa !24
  %t215 = add i64 %t213, 4
  %t218 = call i64 @compiler_2fcabi_2eat(ptr %v0, ptr %t212, i64 %t215)
  store i64 %t218, ptr %l91
  br label %bb50
bb50:
  %t219 = load i64, ptr %l91, !tbaa !24
  store i64 %t219, ptr %l8, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t220, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t222, ptr %l93
  br label %bb51
bb51:
  %t223 = load i1, ptr %l93, !tbaa !21
  br i1 %t223, label %bb52, label %bb53
bb52:
  %t224 = load i64, ptr %l8, !tbaa !24
  %t226 = icmp sge i64 %t224, 0
  store i1 %t226, ptr %l94, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb54
bb54:
  %t228 = load i1, ptr %l94, !tbaa !21
  br i1 %t228, label %bb55, label %bb56
bb55:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l8, !tbaa !24
  %t234 = call %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v0, ptr %t229, i64 %t231)
  store %"compiler/cabi:Scalar" %t234, ptr %l101
  br label %bb57
bb56:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb59
bb57:
  %t235 = getelementptr %"compiler/cabi:Scalar", ptr %l101, i32 0, i32 2
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t238 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t236, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t238, ptr %l103
  br label %bb58
bb58:
  %t239 = load i1, ptr %l103, !tbaa !21
  store i1 %t239, ptr %l97, !tbaa !21
  br label %bb59
bb59:
  %t240 = load i1, ptr %l97, !tbaa !21
  br i1 %t240, label %bb60, label %bb61
bb60:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t243 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t241, 0
  %t244 = insertvalue { { i64, ptr }, i64 } %t243, i64 8, 1
  store { { i64, ptr }, i64 } %t244, ptr %l106
  %t245 = getelementptr { { i64, ptr }, i64 }, ptr %l106, i32 0, i32 0
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  store { i64, ptr } %t246, ptr %l107, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t247, 0
  store i64 %t248, ptr %l108, !tbaa !24
  %t249 = load i64, ptr %l108, !tbaa !24
  %t250 = mul i64 %t249, 1
  %t251 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t250)
  %t252 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t253 = insertvalue { i64, ptr } %t252, ptr %t251, 1
  store { i64, ptr } %t253, ptr %l109, !tbaa !27
  %t254 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = load i64, ptr %l108, !tbaa !24
  %t259 = mul i64 %t258, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t255, ptr %t257, i64 %t259, i1 false)
  %t260 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t261 = getelementptr { { i64, ptr }, i64 }, ptr %l106, i32 0, i32 0
  store { i64, ptr } %t260, ptr %t261, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t262 = load { { i64, ptr }, i64 }, ptr %l106
  store { { i64, ptr }, i64 } %t262, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t263 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t263, 1
  %t266 = extractvalue { i64, ptr } %t263, 0
  %t267 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t266)
  call void @olang_textcopy(ptr %t267, ptr %t265, i64 %t266)
  %t268 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t271 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t269, 0
  %t272 = insertvalue { { i64, ptr }, i64 } %t271, i64 8, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t272, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2fcabi_2etestDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca %"compiler/cabi:Way"
  %l4 = alloca %"compiler/cabi:Regs"
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"compiler/cabi:Way"
  %l9 = alloca i32
  %l13 = alloca %"compiler/cabi:Way"
  %l14 = alloca %"compiler/cabi:Regs"
  %l16 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca %"std/prelude/text:StringBuilder"
  %l39 = alloca %"compiler/cabi:Way"
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/cabi:Way" @compiler_2fcabi_2eResult(ptr %v0, ptr %v1, ptr %s0, ptr %t1, { i64, ptr } %t2, i32 %t3)
  store %"compiler/cabi:Way" %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load %"compiler/cabi:Way", ptr %l13
  store %"compiler/cabi:Way" %t8, ptr %l3
  %t9 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t9, ptr %l14
  br label %bb2
bb2:
  %t10 = load %"compiler/cabi:Regs", ptr %l14
  store %"compiler/cabi:Regs" %t10, ptr %l4
  %t11 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t12 = load i32, ptr %t11
  store i32 %t12, ptr %l5
  %t14 = load i32, ptr %l5
  %t16 = trunc i64 0 to i32
  %t17 = icmp eq i32 %t14, %t16
  br i1 %t17, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l21
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 1
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l16, !tbaa !27
  br label %bb17
bb7:
  %t31 = load i32, ptr %l5
  %t33 = trunc i64 1 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t37 = call { i64, ptr } @compiler_2fcabi_2ePartsType(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t37, ptr %l26
  br label %bb11
bb11:
  %t38 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t38, ptr %l16, !tbaa !27
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t39, ptr %l16, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9727aebca4df1374_94c7225b64063378)
  unreachable
bb17:
  %t41 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  %t42 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t42, ptr %l29
  br label %bb18
bb18:
  %t43 = load %"std/prelude/text:StringBuilder", ptr %l29
  store %"std/prelude/text:StringBuilder" %t43, ptr %l7
  %t44 = getelementptr %"compiler/cabi:Way", ptr %l3, i32 0, i32 0
  %t45 = load i32, ptr %t44
  %t47 = trunc i64 4 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l7, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t51 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t54 = sub i64 %t52, 1
  %t56 = getelementptr %"compiler/cabi:Regs", ptr %l4, i32 0, i32 0
  store i64 %t54, ptr %t56, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t59 = load i32, ptr %l2, !tbaa !23
  %t64 = call %"compiler/cabi:Way" @compiler_2fcabi_2eParam(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t57, { i64, ptr } %t58, i32 %t59, ptr %l4)
  store %"compiler/cabi:Way" %t64, ptr %l39
  br label %bb23
bb23:
  %t65 = load %"compiler/cabi:Way", ptr %l39
  store %"compiler/cabi:Way" %t65, ptr %l8
  store ptr %l7, ptr %l40, !tbaa !29
  %t66 = getelementptr %"compiler/cabi:Way", ptr %l8, i32 0, i32 0
  %t67 = load i32, ptr %t66
  store i32 %t67, ptr %l9
  %t69 = load i32, ptr %l9
  %t71 = trunc i64 0 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t78, ptr %l47
  br label %bb27
bb27:
  %t79 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l42, !tbaa !27
  br label %bb46
bb28:
  %t93 = load i32, ptr %l9
  %t95 = trunc i64 1 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t99 = call { i64, ptr } @compiler_2fcabi_2ePartsList(ptr %s0, ptr %s0, ptr %l8)
  store { i64, ptr } %t99, ptr %l53
  br label %bb32
bb32:
  %t100 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  br label %bb46
bb33:
  %t108 = load i32, ptr %l9
  %t110 = trunc i64 2 to i32
  %t111 = icmp eq i32 %t108, %t110
  br i1 %t111, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb46
bb37:
  %t113 = load i32, ptr %l9
  %t115 = trunc i64 3 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb46
bb41:
  %t118 = load i32, ptr %l9
  %t120 = trunc i64 4 to i32
  %t121 = icmp eq i32 %t118, %t120
  br i1 %t121, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_8f84916f6bbe2da5_8f456227b094de49)
  unreachable
bb46:
  %t123 = load ptr, ptr %l40, !tbaa !29
  %t124 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t123, { i64, ptr } %t124)
  br label %bb47
bb47:
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l61, !tbaa !27
  %t127 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t127, ptr %l63
  br label %bb48
bb48:
  %t128 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t133 = add i64 %t130, %t132
  %t134 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t129, i64 %t130)
  %t142 = getelementptr i8, ptr %t141, i64 %t130
  call void @olang_textcopy(ptr %t142, ptr %t131, i64 %t132)
  %t143 = getelementptr i8, ptr %t142, i64 %t132
  call void @olang_textcopy(ptr %t143, ptr %t135, i64 %t136)
  %t144 = getelementptr i8, ptr %t143, i64 %t136
  call void @olang_textcopy(ptr %t144, ptr %t138, i64 %t139)
  %t145 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t141, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t146, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fcabi_2etestStruct(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca i32
  %l29 = alloca { i64, ptr }
  %l34 = alloca i1
  %l39 = alloca i1
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t7 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v1, ptr %v2, ptr %a1, { i64, ptr } %a2)
  store i32 %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = load i32, ptr %l13, !tbaa !23
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %t8, i64 0, i32 %t9, i32 0, i32 0)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l9, !tbaa !29
  %t13 = load i32, ptr %l15, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t12, i32 %t13, i32 0)
  store i32 %t14, ptr %l16
  br label %bb3
bb3:
  %t15 = load i32, ptr %l16, !tbaa !23
  store i32 %t15, ptr %l4, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l17, !tbaa !29
  %t17 = load i32, ptr %l4, !tbaa !23
  store i32 %t17, ptr %l18, !tbaa !23
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v3, ptr %t18, { i64, ptr } %t19)
  store i32 %t22, ptr %l21
  br label %bb4
bb4:
  %t23 = load ptr, ptr %l17, !tbaa !29
  %t24 = load i32, ptr %l18, !tbaa !23
  %t25 = load i32, ptr %l21, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %t23, i32 %t24, i32 %t25, i1 false)
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  store i64 %t30, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t36 = icmp slt i64 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb7, label %bb8
bb7:
  br label %bb14
bb8:
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t40, ptr %l29, !tbaa !27
  %t41 = load i64, ptr %l6, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i32, ptr %t44, i64 %t41
  %t46 = load i32, ptr %t45, !tbaa !33
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t48, i32 %t46)
  store i1 %t52, ptr %l34
  br label %bb10
bb10:
  %t53 = load i1, ptr %l34, !tbaa !21
  br i1 %t53, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_a86104d23e08732a_9d2c801d66b156c6)
  unreachable
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t56 = add i64 %t54, 1
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb6
bb14:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l39
  br label %bb15
bb15:
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t64 = load i32, ptr %l4, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
bb17:
  call void @__olang_check_failed(ptr @olang_loc_986d0e35626c2b45_4bacbe643940ac11)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/cabi:Regs"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/cabi:Regs" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/cabi:Regs" %t6, i64 %a1, 1
  store %"compiler/cabi:Regs" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Regs", ptr %rv
  ret %"compiler/cabi:Regs" %rr
}

define dso_local %"compiler/cabi:Scalar" @compiler_2fcabi_3aScalar_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %rv = alloca %"compiler/cabi:Scalar"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/cabi:Scalar" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/cabi:Scalar" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/cabi:Scalar" %t12, { i64, ptr } %a2, 2
  %t16 = insertvalue %"compiler/cabi:Scalar" %t14, i1 %a3, 3
  store %"compiler/cabi:Scalar" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Scalar", ptr %rv
  ret %"compiler/cabi:Scalar" %rr
}

define dso_local %"compiler/cabi:Way" @compiler_2fcabi_3aWay_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i32 %a0, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, { i64, ptr } %a4) #0 {
entry:
  %rv = alloca %"compiler/cabi:Way"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/cabi:Way" undef, i32 %a0, 0
  %t14 = insertvalue %"compiler/cabi:Way" %t12, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a1, 1
  %t16 = insertvalue %"compiler/cabi:Way" %t14, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a2, 2
  %t18 = insertvalue %"compiler/cabi:Way" %t16, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %a3, 3
  %t20 = insertvalue %"compiler/cabi:Way" %t18, { i64, ptr } %a4, 4
  store %"compiler/cabi:Way" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/cabi:Way", ptr %rv
  ret %"compiler/cabi:Way" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"aarch64" }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d3 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" x " }>, align 8
@.d6 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"] alignstack(8)" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"[2 x i64]" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d17 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"zeroext" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"zeroext" }>, align 8
@.d20 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"signext" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d22 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i8" }>, align 8
@.d23 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"x86_64" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{ " }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" }" }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d30 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d37 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"double" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"half" }>, align 8
@.d41 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d42 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<2 x " }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<4 x " }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d47 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d48 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d49 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"<2 x float>" }>, align 8
@.d50 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
declare void @__olang_check_failed(ptr)
@.d51 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"sret, " }>, align 8
@.d52 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"byval" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"?" }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eLen_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %a0)
declare %"compiler/cabi:Scalar" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2eAt_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcabi_3aScalar_3e_2ePush_3ccompiler_2fcabi_3aScalar_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/cabi:Scalar" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOffsets(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLlvm(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_9727aebca4df1374_94c7225b64063378 = external constant [0 x i8]
@olang_loc_8f84916f6bbe2da5_8f456227b094de49 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAddDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i32 %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetStructBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i1 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eComputeLayout(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_a86104d23e08732a_9d2c801d66b156c6 = external constant [0 x i8]
@olang_loc_986d0e35626c2b45_4bacbe643940ac11 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
