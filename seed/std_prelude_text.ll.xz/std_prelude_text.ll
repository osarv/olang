; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:decimal" = type { { i64, ptr }, { i64, ptr }, i64, i64, i1 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
@G_2estd_2fprelude_2ftext_2edecimalShifts = global { i64, ptr } zeroinitializer
@G_2estd_2fprelude_2ftext_2eexactPow10 = global { i64, ptr } zeroinitializer
@G_2estd_2fprelude_2ftext_2emask63 = global i64 zeroinitializer
@G_2estd_2fprelude_2ftext_2epow10Mant = global { i64, ptr } zeroinitializer
define dso_local void @olang_2einit_2estd_2fprelude_2ftext() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fprelude_2ftext_2eexactPow10_2einit()
  br label %bb1
bb1:
  call void @std_2fprelude_2ftext_2edecimalShifts_2einit()
  br label %bb2
bb2:
  call void @std_2fprelude_2ftext_2emask63_2einit()
  br label %bb3
bb3:
  call void @std_2fprelude_2ftext_2epow10Mant_2einit()
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2eI64_2eFormat(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2eformatSigned(ptr %v0, i64 %t3, i64 %t4)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i8 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = load i64, ptr %l3, !tbaa !24
  %t3 = call ptr @__olang_sb_room(ptr %s1, i64 24)
  %t4 = call i64 @__olang_fmt_i64(ptr %t3, i64 %t2)
  call void @__olang_sb_add(ptr %s1, i64 %t4)
  %t5 = load ptr, ptr %s1
  %t6 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t7 = load i64, ptr %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t5, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = mul i64 %t12, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t13, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l5, !tbaa !27
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  %t19 = load i8, ptr %l2, !tbaa !22
  store i8 %t19, ptr %l7, !tbaa !22
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t21 = load i64, ptr %l6, !tbaa !24
  %t22 = load i8, ptr %l7, !tbaa !22
  %t23 = call { i64, ptr } @std_2fprelude_2ftext_2epadNumber(ptr %v0, ptr %v0, { i64, ptr } %t20, i64 %t21, i8 %t22)
  store { i64, ptr } %t23, ptr %l8
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t24 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t24, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !64
  store i32 %t1, ptr %l2, !tbaa !64
  %t2 = load i32, ptr %l2, !tbaa !64
  %t3 = zext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !65
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !65
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = call { i64, ptr } @std_2fprelude_2ftext_2eformatDigits(ptr %v0, i64 %t5, i1 false, i64 %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !65
  store i64 %t1, ptr %l2, !tbaa !65
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !65
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2eformatDigits(ptr %v0, i64 %t3, i1 false, i64 %t4)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2eU8_2eFormat(ptr %v0, i8 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i8 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l2, !tbaa !22
  %t2 = load i8, ptr %l2, !tbaa !22
  %t3 = zext i8 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !65
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !65
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = call { i64, ptr } @std_2fprelude_2ftext_2eformatDigits(ptr %v0, i64 %t5, i1 false, i64 %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2ftext_2edecimalShifts_2einit() #0 {
entry:
  %l0 = alloca [9 x i64]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [9 x i64] undef, i64 1, 0
  %t2 = insertvalue [9 x i64] %t1, i64 3, 1
  %t3 = insertvalue [9 x i64] %t2, i64 6, 2
  %t4 = insertvalue [9 x i64] %t3, i64 9, 3
  %t5 = insertvalue [9 x i64] %t4, i64 13, 4
  %t6 = insertvalue [9 x i64] %t5, i64 16, 5
  %t7 = insertvalue [9 x i64] %t6, i64 19, 6
  %t8 = insertvalue [9 x i64] %t7, i64 23, 7
  %t9 = insertvalue [9 x i64] %t8, i64 26, 8
  store [9 x i64] %t9, ptr %l0
  %t10 = load [9 x i64], ptr %l0
  %t11 = load ptr, ptr @__olang_prog_scope
  %t12 = call ptr @__olang_scope_alloc(ptr %t11, i64 72)
  store [9 x i64] %t10, ptr %t12
  %t13 = insertvalue { i64, ptr } undef, i64 9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  %t15 = load { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2edecimalShifts, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l2, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp eq i64 %t19, %t20
  store i1 %t21, ptr %l4, !tbaa !21
  %t22 = load i1, ptr %l4, !tbaa !21
  br i1 %t22, label %bb1, label %bb2
bb1:
  %t23 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2edecimalShifts, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = mul i64 %t27, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %t26, i64 %t28, i1 false)
  br label %bb3
bb2:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr @G_2estd_2fprelude_2ftext_2edecimalShifts, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2ftext_2edigitWorth(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %l6 = alloca i8
  %l7 = alloca i8
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i8
  %l13 = alloca i1
  %l14 = alloca i8
  %l15 = alloca i8
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i8
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i8
  %l24 = alloca i8
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp uge i8 %t2, 48
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = icmp ule i8 %t6, 57
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load i8, ptr %l0, !tbaa !22
  store i8 %t10, ptr %l6, !tbaa !22
  %t11 = load i8, ptr %l6, !tbaa !22
  %t12 = sub i8 %t11, 48
  store i8 %t12, ptr %l7, !tbaa !22
  %t13 = load i8, ptr %l7, !tbaa !22
  %t14 = zext i8 %t13 to i64
  store i64 %t14, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load i8, ptr %l0, !tbaa !22
  store i8 %t16, ptr %l9, !tbaa !22
  %t17 = load i8, ptr %l9, !tbaa !22
  %t18 = icmp uge i8 %t17, 97
  store i1 %t18, ptr %l10, !tbaa !21
  %t19 = load i1, ptr %l10, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t20 = load i8, ptr %l0, !tbaa !22
  store i8 %t20, ptr %l12, !tbaa !22
  %t21 = load i8, ptr %l12, !tbaa !22
  %t22 = icmp ule i8 %t21, 122
  store i1 %t22, ptr %l13, !tbaa !21
  %t23 = load i1, ptr %l13, !tbaa !21
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i8, ptr %l0, !tbaa !22
  store i8 %t25, ptr %l14, !tbaa !22
  %t26 = load i8, ptr %l14, !tbaa !22
  %t27 = sub i8 %t26, 97
  store i8 %t27, ptr %l15, !tbaa !22
  %t28 = load i8, ptr %l15, !tbaa !22
  %t29 = zext i8 %t28 to i64
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load i64, ptr %l16, !tbaa !24
  %t31 = add i64 %t30, 10
  store i64 %t31, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t33 = load i8, ptr %l0, !tbaa !22
  store i8 %t33, ptr %l18, !tbaa !22
  %t34 = load i8, ptr %l18, !tbaa !22
  %t35 = icmp uge i8 %t34, 65
  store i1 %t35, ptr %l19, !tbaa !21
  %t36 = load i1, ptr %l19, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load i8, ptr %l0, !tbaa !22
  store i8 %t37, ptr %l21, !tbaa !22
  %t38 = load i8, ptr %l21, !tbaa !22
  %t39 = icmp ule i8 %t38, 90
  store i1 %t39, ptr %l22, !tbaa !21
  %t40 = load i1, ptr %l22, !tbaa !21
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l20, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i8, ptr %l0, !tbaa !22
  store i8 %t42, ptr %l23, !tbaa !22
  %t43 = load i8, ptr %l23, !tbaa !22
  %t44 = sub i8 %t43, 65
  store i8 %t44, ptr %l24, !tbaa !22
  %t45 = load i8, ptr %l24, !tbaa !22
  %t46 = zext i8 %t45 to i64
  store i64 %t46, ptr %l25, !tbaa !24
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = add i64 %t47, 10
  store i64 %t48, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i64, ptr %l26, !tbaa !24
  store i64 %t49, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  store i64 36, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i64, ptr %l27, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2eeiselLemire(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, i64 }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, i64 }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca { i64, i64 }
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i32
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i1
  %l107 = alloca i32
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i1
  %l123 = alloca i1
  %l124 = alloca i64
  %l125 = alloca i1
  %l126 = alloca i32
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l15, !tbaa !24
  %t2 = load i64, ptr %l15, !tbaa !24
  %t3 = icmp slt i64 %t2, -348
  store i1 %t3, ptr %l16, !tbaa !21
  %t4 = load i1, ptr %l16, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l18, !tbaa !24
  %t6 = load i64, ptr %l18, !tbaa !24
  %t7 = icmp sgt i64 %t6, 347
  store i1 %t7, ptr %l19, !tbaa !21
  %t8 = load i1, ptr %l19, !tbaa !21
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l20, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i32, ptr %l20, !tbaa !23
  %t11 = insertvalue { i32, i64 } zeroinitializer, i32 %t10, 0
  store { i32, i64 } %t11, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t12 = load i64, ptr %l0, !tbaa !65
  store i64 %t12, ptr %l21, !tbaa !65
  %t13 = load i64, ptr %l21, !tbaa !65
  %t14 = call i64 @std_2fprelude_2ftext_2eleadingZeros(i64 %t13)
  store i64 %t14, ptr %l22
  br label %bb7
bb7:
  %t15 = load i64, ptr %l22, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load i64, ptr %l0, !tbaa !65
  store i64 %t16, ptr %l23, !tbaa !65
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %l24, !tbaa !24
  %t18 = load i64, ptr %l24, !tbaa !24
  store i64 %t18, ptr %l25, !tbaa !65
  %t19 = load i64, ptr %l23, !tbaa !65
  %t20 = load i64, ptr %l25, !tbaa !65
  %t21 = load i64, ptr %l25, !tbaa !65
  %t22 = shl i64 %t19, %t21
  store i64 %t22, ptr %l26, !tbaa !65
  %t23 = load i64, ptr %l26, !tbaa !65
  store i64 %t23, ptr %l0, !tbaa !65
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l27, !tbaa !24
  %t25 = load i64, ptr %l27, !tbaa !24
  %t26 = mul i64 217706, %t25
  store i64 %t26, ptr %l28, !tbaa !24
  %t27 = load i64, ptr %l28, !tbaa !24
  %t28 = ashr i64 %t27, 16
  store i64 %t28, ptr %l29, !tbaa !24
  %t29 = load i64, ptr %l29, !tbaa !24
  %t30 = add i64 %t29, 64
  store i64 %t30, ptr %l30, !tbaa !24
  %t31 = load i64, ptr %l30, !tbaa !24
  %t32 = add i64 %t31, 1023
  store i64 %t32, ptr %l31, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %l32, !tbaa !24
  %t34 = load i64, ptr %l31, !tbaa !24
  %t35 = load i64, ptr %l32, !tbaa !24
  %t36 = sub i64 %t34, %t35
  store i64 %t36, ptr %l33, !tbaa !24
  %t37 = load i64, ptr %l33, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l34, !tbaa !24
  %t39 = load i64, ptr %l34, !tbaa !24
  %t40 = add i64 %t39, 348
  store i64 %t40, ptr %l35, !tbaa !24
  %t41 = load i64, ptr %l35, !tbaa !24
  %t42 = mul i64 %t41, 2
  store i64 %t42, ptr %l36, !tbaa !24
  %t43 = load i64, ptr %l36, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l0, !tbaa !65
  store i64 %t44, ptr %l37, !tbaa !65
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l38, !tbaa !24
  %t46 = load i64, ptr %l38, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2epow10Mant, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i64, ptr %t48, i64 %t46
  %t50 = load i64, ptr %t49, !tbaa !34
  store i64 %t50, ptr %l39, !tbaa !24
  %t51 = load i64, ptr %l39, !tbaa !24
  store i64 %t51, ptr %l40, !tbaa !65
  %t52 = load i64, ptr %l37, !tbaa !65
  %t53 = load i64, ptr %l40, !tbaa !65
  %t54 = call { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %t52, i64 %t53)
  store { i64, i64 } %t54, ptr %l41
  br label %bb8
bb8:
  %t55 = load { i64, i64 }, ptr %l41
  store { i64, i64 } %t55, ptr %l5
  %t56 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !65
  store i64 %t57, ptr %l42, !tbaa !65
  %t58 = load i64, ptr %l42, !tbaa !65
  store i64 %t58, ptr %l6, !tbaa !65
  %t59 = getelementptr { i64, i64 }, ptr %l5, i32 0, i32 1
  %t60 = load i64, ptr %t59, !tbaa !65
  store i64 %t60, ptr %l43, !tbaa !65
  %t61 = load i64, ptr %l43, !tbaa !65
  store i64 %t61, ptr %l7, !tbaa !65
  %t62 = load i64, ptr %l6, !tbaa !65
  store i64 %t62, ptr %l44, !tbaa !65
  %t63 = load i64, ptr %l44, !tbaa !65
  %t64 = and i64 %t63, 511
  store i64 %t64, ptr %l45, !tbaa !65
  %t65 = load i64, ptr %l45, !tbaa !65
  %t66 = icmp eq i64 %t65, 511
  store i1 %t66, ptr %l46, !tbaa !21
  %t67 = load i1, ptr %l46, !tbaa !21
  br i1 %t67, label %bb9, label %bb10
bb9:
  %t68 = load i64, ptr %l7, !tbaa !65
  store i64 %t68, ptr %l48, !tbaa !65
  %t69 = load i64, ptr %l0, !tbaa !65
  store i64 %t69, ptr %l49, !tbaa !65
  %t70 = load i64, ptr %l48, !tbaa !65
  %t71 = load i64, ptr %l49, !tbaa !65
  %t72 = add i64 %t70, %t71
  store i64 %t72, ptr %l50, !tbaa !65
  %t73 = load i64, ptr %l0, !tbaa !65
  store i64 %t73, ptr %l51, !tbaa !65
  %t74 = load i64, ptr %l50, !tbaa !65
  %t75 = load i64, ptr %l51, !tbaa !65
  %t76 = icmp ult i64 %t74, %t75
  store i1 %t76, ptr %l52, !tbaa !21
  %t77 = load i1, ptr %l52, !tbaa !21
  store i1 %t77, ptr %l47, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb11
bb11:
  %t78 = load i1, ptr %l47, !tbaa !21
  br i1 %t78, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load i64, ptr %l0, !tbaa !65
  store i64 %t79, ptr %l53, !tbaa !65
  %t80 = load i64, ptr %l4, !tbaa !24
  store i64 %t80, ptr %l54, !tbaa !24
  %t81 = load i64, ptr %l54, !tbaa !24
  %t82 = add i64 %t81, 1
  store i64 %t82, ptr %l55, !tbaa !24
  %t83 = load i64, ptr %l55, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2epow10Mant, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t83
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %l56, !tbaa !24
  %t88 = load i64, ptr %l56, !tbaa !24
  store i64 %t88, ptr %l57, !tbaa !65
  %t89 = load i64, ptr %l53, !tbaa !65
  %t90 = load i64, ptr %l57, !tbaa !65
  %t91 = call { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %t89, i64 %t90)
  store { i64, i64 } %t91, ptr %l58
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t92 = load { i64, i64 }, ptr %l58
  store { i64, i64 } %t92, ptr %l8
  %t93 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t94 = load i64, ptr %t93, !tbaa !65
  store i64 %t94, ptr %l59, !tbaa !65
  %t95 = load i64, ptr %l59, !tbaa !65
  store i64 %t95, ptr %l9, !tbaa !65
  %t96 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !65
  store i64 %t97, ptr %l60, !tbaa !65
  %t98 = load i64, ptr %l60, !tbaa !65
  store i64 %t98, ptr %l10, !tbaa !65
  %t99 = load i64, ptr %l6, !tbaa !65
  store i64 %t99, ptr %l61, !tbaa !65
  %t100 = load i64, ptr %l61, !tbaa !65
  store i64 %t100, ptr %l11, !tbaa !65
  %t101 = load i64, ptr %l7, !tbaa !65
  store i64 %t101, ptr %l62, !tbaa !65
  %t102 = load i64, ptr %l9, !tbaa !65
  store i64 %t102, ptr %l63, !tbaa !65
  %t103 = load i64, ptr %l62, !tbaa !65
  %t104 = load i64, ptr %l63, !tbaa !65
  %t105 = add i64 %t103, %t104
  store i64 %t105, ptr %l64, !tbaa !65
  %t106 = load i64, ptr %l64, !tbaa !65
  store i64 %t106, ptr %l12, !tbaa !65
  %t107 = load i64, ptr %l12, !tbaa !65
  store i64 %t107, ptr %l65, !tbaa !65
  %t108 = load i64, ptr %l7, !tbaa !65
  store i64 %t108, ptr %l66, !tbaa !65
  %t109 = load i64, ptr %l65, !tbaa !65
  %t110 = load i64, ptr %l66, !tbaa !65
  %t111 = icmp ult i64 %t109, %t110
  store i1 %t111, ptr %l67, !tbaa !21
  %t112 = load i1, ptr %l67, !tbaa !21
  br i1 %t112, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t113 = load i64, ptr %l11, !tbaa !65
  store i64 %t113, ptr %l68, !tbaa !65
  %t114 = load i64, ptr %l68, !tbaa !65
  %t115 = add i64 %t114, 1
  store i64 %t115, ptr %l69, !tbaa !65
  %t116 = load i64, ptr %l69, !tbaa !65
  store i64 %t116, ptr %l11, !tbaa !65
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb16:
  br label %bb17
bb17:
  %t117 = load i64, ptr %l11, !tbaa !65
  store i64 %t117, ptr %l70, !tbaa !65
  %t118 = load i64, ptr %l70, !tbaa !65
  %t119 = and i64 %t118, 511
  store i64 %t119, ptr %l71, !tbaa !65
  %t120 = load i64, ptr %l71, !tbaa !65
  %t121 = icmp eq i64 %t120, 511
  store i1 %t121, ptr %l72, !tbaa !21
  %t122 = load i1, ptr %l72, !tbaa !21
  br i1 %t122, label %bb18, label %bb19
bb18:
  %t123 = load i64, ptr %l12, !tbaa !65
  store i64 %t123, ptr %l74, !tbaa !65
  %t124 = load i64, ptr %l74, !tbaa !65
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l75, !tbaa !65
  %t126 = load i64, ptr %l75, !tbaa !65
  %t127 = icmp eq i64 %t126, 0
  store i1 %t127, ptr %l76, !tbaa !21
  %t128 = load i1, ptr %l76, !tbaa !21
  store i1 %t128, ptr %l73, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  %t129 = load i1, ptr %l73, !tbaa !21
  br i1 %t129, label %bb21, label %bb22
bb21:
  %t130 = load i64, ptr %l10, !tbaa !65
  store i64 %t130, ptr %l78, !tbaa !65
  %t131 = load i64, ptr %l0, !tbaa !65
  store i64 %t131, ptr %l79, !tbaa !65
  %t132 = load i64, ptr %l78, !tbaa !65
  %t133 = load i64, ptr %l79, !tbaa !65
  %t134 = add i64 %t132, %t133
  store i64 %t134, ptr %l80, !tbaa !65
  %t135 = load i64, ptr %l0, !tbaa !65
  store i64 %t135, ptr %l81, !tbaa !65
  %t136 = load i64, ptr %l80, !tbaa !65
  %t137 = load i64, ptr %l81, !tbaa !65
  %t138 = icmp ult i64 %t136, %t137
  store i1 %t138, ptr %l82, !tbaa !21
  %t139 = load i1, ptr %l82, !tbaa !21
  store i1 %t139, ptr %l77, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb23
bb23:
  %t140 = load i1, ptr %l77, !tbaa !21
  br i1 %t140, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 65536, ptr %l83, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l83, !tbaa !23
  %t142 = insertvalue { i32, i64 } zeroinitializer, i32 %t141, 0
  store { i32, i64 } %t142, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t143 = load i64, ptr %l11, !tbaa !65
  store i64 %t143, ptr %l84, !tbaa !65
  %t144 = load i64, ptr %l84, !tbaa !65
  store i64 %t144, ptr %l6, !tbaa !65
  %t145 = load i64, ptr %l12, !tbaa !65
  store i64 %t145, ptr %l85, !tbaa !65
  %t146 = load i64, ptr %l85, !tbaa !65
  store i64 %t146, ptr %l7, !tbaa !65
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t147 = load i64, ptr %l6, !tbaa !65
  store i64 %t147, ptr %l86, !tbaa !65
  %t148 = load i64, ptr %l86, !tbaa !65
  %t149 = lshr i64 %t148, 63
  store i64 %t149, ptr %l87, !tbaa !65
  %t150 = load i64, ptr %l87, !tbaa !65
  store i64 %t150, ptr %l13, !tbaa !65
  %t151 = load i64, ptr %l6, !tbaa !65
  store i64 %t151, ptr %l88, !tbaa !65
  %t152 = load i64, ptr %l13, !tbaa !65
  store i64 %t152, ptr %l89, !tbaa !65
  %t153 = load i64, ptr %l89, !tbaa !65
  %t154 = add i64 %t153, 9
  store i64 %t154, ptr %l90, !tbaa !65
  %t155 = load i64, ptr %l88, !tbaa !65
  %t156 = load i64, ptr %l90, !tbaa !65
  %t157 = load i64, ptr %l90, !tbaa !65
  %t158 = lshr i64 %t155, %t157
  store i64 %t158, ptr %l91, !tbaa !65
  %t159 = load i64, ptr %l91, !tbaa !65
  store i64 %t159, ptr %l14, !tbaa !65
  %t160 = load i64, ptr %l3, !tbaa !24
  store i64 %t160, ptr %l92, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !65
  store i64 %t161, ptr %l93, !tbaa !65
  %t162 = load i64, ptr %l93, !tbaa !65
  %t163 = xor i64 1, %t162
  store i64 %t163, ptr %l94, !tbaa !65
  %t164 = load i64, ptr %l94, !tbaa !65
  store i64 %t164, ptr %l95, !tbaa !24
  %t165 = load i64, ptr %l92, !tbaa !24
  %t166 = load i64, ptr %l95, !tbaa !24
  %t167 = sub i64 %t165, %t166
  store i64 %t167, ptr %l96, !tbaa !24
  %t168 = load i64, ptr %l96, !tbaa !24
  store i64 %t168, ptr %l3, !tbaa !24
  %t169 = load i64, ptr %l7, !tbaa !65
  store i64 %t169, ptr %l97, !tbaa !65
  %t170 = load i64, ptr %l97, !tbaa !65
  %t171 = icmp eq i64 %t170, 0
  store i1 %t171, ptr %l98, !tbaa !21
  %t172 = load i1, ptr %l98, !tbaa !21
  br i1 %t172, label %bb28, label %bb29
bb28:
  %t173 = load i64, ptr %l6, !tbaa !65
  store i64 %t173, ptr %l100, !tbaa !65
  %t174 = load i64, ptr %l100, !tbaa !65
  %t175 = and i64 %t174, 511
  store i64 %t175, ptr %l101, !tbaa !65
  %t176 = load i64, ptr %l101, !tbaa !65
  %t177 = icmp eq i64 %t176, 0
  store i1 %t177, ptr %l102, !tbaa !21
  %t178 = load i1, ptr %l102, !tbaa !21
  store i1 %t178, ptr %l99, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb30
bb30:
  %t179 = load i1, ptr %l99, !tbaa !21
  br i1 %t179, label %bb31, label %bb32
bb31:
  %t180 = load i64, ptr %l14, !tbaa !65
  store i64 %t180, ptr %l104, !tbaa !65
  %t181 = load i64, ptr %l104, !tbaa !65
  %t182 = and i64 %t181, 3
  store i64 %t182, ptr %l105, !tbaa !65
  %t183 = load i64, ptr %l105, !tbaa !65
  %t184 = icmp eq i64 %t183, 1
  store i1 %t184, ptr %l106, !tbaa !21
  %t185 = load i1, ptr %l106, !tbaa !21
  store i1 %t185, ptr %l103, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb33
bb33:
  %t186 = load i1, ptr %l103, !tbaa !21
  br i1 %t186, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 65536, ptr %l107, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t187 = load i32, ptr %l107, !tbaa !23
  %t188 = insertvalue { i32, i64 } zeroinitializer, i32 %t187, 0
  store { i32, i64 } %t188, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t189 = load i64, ptr %l14, !tbaa !65
  store i64 %t189, ptr %l108, !tbaa !65
  %t190 = load i64, ptr %l14, !tbaa !65
  store i64 %t190, ptr %l109, !tbaa !65
  %t191 = load i64, ptr %l109, !tbaa !65
  %t192 = and i64 %t191, 1
  store i64 %t192, ptr %l110, !tbaa !65
  %t193 = load i64, ptr %l108, !tbaa !65
  %t194 = load i64, ptr %l110, !tbaa !65
  %t195 = add i64 %t193, %t194
  store i64 %t195, ptr %l111, !tbaa !65
  %t196 = load i64, ptr %l111, !tbaa !65
  store i64 %t196, ptr %l14, !tbaa !65
  %t197 = load i64, ptr %l14, !tbaa !65
  store i64 %t197, ptr %l112, !tbaa !65
  %t198 = load i64, ptr %l112, !tbaa !65
  %t199 = lshr i64 %t198, 1
  store i64 %t199, ptr %l113, !tbaa !65
  %t200 = load i64, ptr %l113, !tbaa !65
  store i64 %t200, ptr %l14, !tbaa !65
  %t201 = load i64, ptr %l14, !tbaa !65
  store i64 %t201, ptr %l114, !tbaa !65
  %t202 = load i64, ptr %l114, !tbaa !65
  %t203 = lshr i64 %t202, 53
  store i64 %t203, ptr %l115, !tbaa !65
  %t204 = load i64, ptr %l115, !tbaa !65
  %t205 = icmp ugt i64 %t204, 0
  store i1 %t205, ptr %l116, !tbaa !21
  %t206 = load i1, ptr %l116, !tbaa !21
  br i1 %t206, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s6
  %t207 = load i64, ptr %l14, !tbaa !65
  store i64 %t207, ptr %l117, !tbaa !65
  %t208 = load i64, ptr %l117, !tbaa !65
  %t209 = lshr i64 %t208, 1
  store i64 %t209, ptr %l118, !tbaa !65
  %t210 = load i64, ptr %l118, !tbaa !65
  store i64 %t210, ptr %l14, !tbaa !65
  %t211 = load i64, ptr %l3, !tbaa !24
  store i64 %t211, ptr %l119, !tbaa !24
  %t212 = load i64, ptr %l119, !tbaa !24
  %t213 = add i64 %t212, 1
  store i64 %t213, ptr %l120, !tbaa !24
  %t214 = load i64, ptr %l120, !tbaa !24
  store i64 %t214, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t215 = load i64, ptr %l3, !tbaa !24
  store i64 %t215, ptr %l121, !tbaa !24
  %t216 = load i64, ptr %l121, !tbaa !24
  %t217 = icmp sle i64 %t216, 0
  store i1 %t217, ptr %l122, !tbaa !21
  %t218 = load i1, ptr %l122, !tbaa !21
  br i1 %t218, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb42
bb41:
  %t219 = load i64, ptr %l3, !tbaa !24
  store i64 %t219, ptr %l124, !tbaa !24
  %t220 = load i64, ptr %l124, !tbaa !24
  %t221 = icmp sge i64 %t220, 2047
  store i1 %t221, ptr %l125, !tbaa !21
  %t222 = load i1, ptr %l125, !tbaa !21
  store i1 %t222, ptr %l123, !tbaa !21
  br label %bb42
bb42:
  %t223 = load i1, ptr %l123, !tbaa !21
  br i1 %t223, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 65536, ptr %l126, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t224 = load i32, ptr %l126, !tbaa !23
  %t225 = insertvalue { i32, i64 } zeroinitializer, i32 %t224, 0
  store { i32, i64 } %t225, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t226 = load i64, ptr %l3, !tbaa !24
  store i64 %t226, ptr %l127, !tbaa !24
  %t227 = load i64, ptr %l127, !tbaa !24
  store i64 %t227, ptr %l128, !tbaa !65
  %t228 = load i64, ptr %l128, !tbaa !65
  %t229 = shl i64 %t228, 52
  store i64 %t229, ptr %l129, !tbaa !65
  %t230 = load i64, ptr %l14, !tbaa !65
  store i64 %t230, ptr %l130, !tbaa !65
  %t231 = load i64, ptr %l130, !tbaa !65
  %t232 = and i64 %t231, 4503599627370495
  store i64 %t232, ptr %l131, !tbaa !65
  %t233 = load i64, ptr %l129, !tbaa !65
  %t234 = load i64, ptr %l131, !tbaa !65
  %t235 = or i64 %t233, %t234
  store i64 %t235, ptr %l132, !tbaa !65
  call void @__olang_scope_close(ptr %s0)
  %t236 = load i64, ptr %l132, !tbaa !65
  %t237 = insertvalue { i32, i64 } zeroinitializer, i64 %t236, 1
  store { i32, i64 } %t237, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2ftext_2eexactPow10_2einit() #0 {
entry:
  %l0 = alloca [23 x double]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr [23 x double], ptr %l0, i64 0, i64 0
  store double 0x3ff0000000000000, ptr %t1
  %t2 = getelementptr [23 x double], ptr %l0, i64 0, i64 1
  store double 0x4024000000000000, ptr %t2
  %t3 = getelementptr [23 x double], ptr %l0, i64 0, i64 2
  store double 0x4059000000000000, ptr %t3
  %t4 = getelementptr [23 x double], ptr %l0, i64 0, i64 3
  store double 0x408f400000000000, ptr %t4
  %t5 = getelementptr [23 x double], ptr %l0, i64 0, i64 4
  store double 0x40c3880000000000, ptr %t5
  %t6 = getelementptr [23 x double], ptr %l0, i64 0, i64 5
  store double 0x40f86a0000000000, ptr %t6
  %t7 = getelementptr [23 x double], ptr %l0, i64 0, i64 6
  store double 0x412e848000000000, ptr %t7
  %t8 = getelementptr [23 x double], ptr %l0, i64 0, i64 7
  store double 0x416312d000000000, ptr %t8
  %t9 = getelementptr [23 x double], ptr %l0, i64 0, i64 8
  store double 0x4197d78400000000, ptr %t9
  %t10 = getelementptr [23 x double], ptr %l0, i64 0, i64 9
  store double 0x41cdcd6500000000, ptr %t10
  %t11 = getelementptr [23 x double], ptr %l0, i64 0, i64 10
  store double 0x4202a05f20000000, ptr %t11
  %t12 = getelementptr [23 x double], ptr %l0, i64 0, i64 11
  store double 0x42374876e8000000, ptr %t12
  %t13 = getelementptr [23 x double], ptr %l0, i64 0, i64 12
  store double 0x426d1a94a2000000, ptr %t13
  %t14 = getelementptr [23 x double], ptr %l0, i64 0, i64 13
  store double 0x42a2309ce5400000, ptr %t14
  %t15 = getelementptr [23 x double], ptr %l0, i64 0, i64 14
  store double 0x42d6bcc41e900000, ptr %t15
  %t16 = getelementptr [23 x double], ptr %l0, i64 0, i64 15
  store double 0x430c6bf526340000, ptr %t16
  %t17 = getelementptr [23 x double], ptr %l0, i64 0, i64 16
  store double 0x4341c37937e08000, ptr %t17
  %t18 = getelementptr [23 x double], ptr %l0, i64 0, i64 17
  store double 0x4376345785d8a000, ptr %t18
  %t19 = getelementptr [23 x double], ptr %l0, i64 0, i64 18
  store double 0x43abc16d674ec800, ptr %t19
  %t20 = getelementptr [23 x double], ptr %l0, i64 0, i64 19
  store double 0x43e158e460913d00, ptr %t20
  %t21 = getelementptr [23 x double], ptr %l0, i64 0, i64 20
  store double 0x4415af1d78b58c40, ptr %t21
  %t22 = getelementptr [23 x double], ptr %l0, i64 0, i64 21
  store double 0x444b1ae4d6e2ef50, ptr %t22
  %t23 = getelementptr [23 x double], ptr %l0, i64 0, i64 22
  store double 0x4480f0cf064dd592, ptr %t23
  %t24 = load [23 x double], ptr %l0
  %t25 = load ptr, ptr @__olang_prog_scope
  %t26 = call ptr @__olang_scope_alloc(ptr %t25, i64 184)
  store [23 x double] %t24, ptr %t26
  %t27 = insertvalue { i64, ptr } undef, i64 23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l1, !tbaa !27
  %t29 = load { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2eexactPow10, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp eq i64 %t33, %t34
  store i1 %t35, ptr %l4, !tbaa !21
  %t36 = load i1, ptr %l4, !tbaa !21
  br i1 %t36, label %bb1, label %bb2
bb1:
  %t37 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2eexactPow10, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = mul i64 %t41, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t38, ptr %t40, i64 %t42, i1 false)
  br label %bb3
bb2:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr @G_2estd_2fprelude_2ftext_2eexactPow10, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2eformatDigits(ptr %v0, i64 %a0, i1 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca [65 x i8]
  %l5 = alloca i64
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i8
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i8
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i1 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 36, ptr @.d0 }, ptr %l3, !tbaa !27
  store [65 x i8] zeroinitializer, ptr %l4
  store i64 65, ptr %l5, !tbaa !24
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l14, !tbaa !24
  %t2 = load i64, ptr %l14, !tbaa !24
  store i64 %t2, ptr %l15, !tbaa !24
  %t3 = load i64, ptr %l15, !tbaa !24
  %t4 = icmp ne i64 %t3, 0
  store i1 %t4, ptr %l16, !tbaa !21
  %t5 = load i1, ptr %l16, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = load i64, ptr %l2, !tbaa !24
  store i64 %t6, ptr %l18, !tbaa !24
  %t7 = load i64, ptr %l18, !tbaa !24
  store i64 %t7, ptr %l19, !tbaa !24
  %t8 = load i64, ptr %l19, !tbaa !24
  store i64 %t8, ptr %l20, !tbaa !65
  %t9 = load i64, ptr %l20, !tbaa !65
  store i64 %t9, ptr %l17, !tbaa !65
  br label %bb3
bb2:
  store i64 10, ptr %l17, !tbaa !65
  br label %bb3
bb3:
  %t10 = load i64, ptr %l17, !tbaa !65
  store i64 %t10, ptr %l6, !tbaa !65
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l21, !tbaa !24
  %t12 = load i64, ptr %l21, !tbaa !24
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %l22, !tbaa !24
  %t14 = load i64, ptr %l22, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  store i64 %t15, ptr %l23, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l24, !tbaa !27
  %t17 = load i64, ptr %l0, !tbaa !65
  store i64 %t17, ptr %l25, !tbaa !65
  %t18 = load i64, ptr %l6, !tbaa !65
  store i64 %t18, ptr %l26, !tbaa !65
  %t19 = load i64, ptr %l25, !tbaa !65
  %t20 = load i64, ptr %l26, !tbaa !65
  %t21 = urem i64 %t19, %t20
  store i64 %t21, ptr %l27, !tbaa !65
  %t22 = load i64, ptr %l27, !tbaa !65
  store i64 %t22, ptr %l28, !tbaa !24
  %t23 = load i64, ptr %l28, !tbaa !24
  %t24 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr i8, ptr %t25, i64 %t23
  %t27 = load i8, ptr %t26, !tbaa !32
  store i8 %t27, ptr %l29, !tbaa !22
  %t28 = load i8, ptr %l29, !tbaa !22
  %t29 = load i64, ptr %l23, !tbaa !24
  %t30 = getelementptr [65 x i8], ptr %l4, i64 0, i64 %t29
  store i8 %t28, ptr %t30, !tbaa !32
  %t31 = load i64, ptr %l0, !tbaa !65
  store i64 %t31, ptr %l30, !tbaa !65
  %t32 = load i64, ptr %l6, !tbaa !65
  store i64 %t32, ptr %l31, !tbaa !65
  %t33 = load i64, ptr %l30, !tbaa !65
  %t34 = load i64, ptr %l31, !tbaa !65
  %t35 = udiv i64 %t33, %t34
  store i64 %t35, ptr %l32, !tbaa !65
  %t36 = load i64, ptr %l32, !tbaa !65
  store i64 %t36, ptr %l0, !tbaa !65
  %t37 = load i64, ptr %l0, !tbaa !65
  store i64 %t37, ptr %l33, !tbaa !65
  %t38 = load i64, ptr %l33, !tbaa !65
  %t39 = icmp eq i64 %t38, 0
  store i1 %t39, ptr %l34, !tbaa !21
  %t40 = load i1, ptr %l34, !tbaa !21
  br i1 %t40, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb4
bb9:
  %t41 = load i1, ptr %l1, !tbaa !21
  store i1 %t41, ptr %l35, !tbaa !21
  %t42 = load i1, ptr %l35, !tbaa !21
  br i1 %t42, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load i64, ptr %l5, !tbaa !24
  store i64 %t43, ptr %l36, !tbaa !24
  %t44 = load i64, ptr %l36, !tbaa !24
  %t45 = sub i64 %t44, 1
  store i64 %t45, ptr %l37, !tbaa !24
  %t46 = load i64, ptr %l37, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  store i64 %t47, ptr %l38, !tbaa !24
  %t48 = load i64, ptr %l38, !tbaa !24
  %t49 = getelementptr [65 x i8], ptr %l4, i64 0, i64 %t48
  store i8 45, ptr %t49, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t50 = load i64, ptr %l5, !tbaa !24
  store i64 %t50, ptr %l39, !tbaa !24
  %t51 = load i64, ptr %l39, !tbaa !24
  %t52 = sub i64 65, %t51
  store i64 %t52, ptr %l40, !tbaa !24
  %t53 = load i64, ptr %l40, !tbaa !24
  %t54 = icmp sge i64 %t53, 0
  store i1 %t54, ptr %l41, !tbaa !21
  %t55 = load i1, ptr %l41, !tbaa !21
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t56 = load i64, ptr %l40, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l42, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t61, ptr %l43, !tbaa !27
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t62, ptr %lp7
  %t63 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t64 = load ptr, ptr %lp7
  store { i64, ptr } %t63, ptr %t64, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s4
  store i64 0, ptr %l8, !tbaa !24
  %t65 = load ptr, ptr %lp7
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l44, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l45, !tbaa !24
  %t69 = load i64, ptr %l45, !tbaa !24
  store i64 %t69, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  store i64 %t70, ptr %l46, !tbaa !24
  %t71 = load i64, ptr %l8, !tbaa !24
  store i64 %t71, ptr %l47, !tbaa !24
  %t72 = load i64, ptr %l46, !tbaa !24
  %t73 = load i64, ptr %l47, !tbaa !24
  %t74 = icmp sgt i64 %t72, %t73
  store i1 %t74, ptr %l48, !tbaa !21
  %t75 = load i1, ptr %l48, !tbaa !21
  br i1 %t75, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb15:
  %t76 = load i64, ptr %l10, !tbaa !24
  store i64 %t76, ptr %l50, !tbaa !24
  %t77 = load i64, ptr %l50, !tbaa !24
  %t78 = icmp sgt i64 %t77, 0
  store i1 %t78, ptr %l51, !tbaa !21
  %t79 = load i1, ptr %l51, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb20
bb17:
  %t80 = load i64, ptr %l9, !tbaa !24
  store i64 %t80, ptr %l53, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %l54, !tbaa !24
  %t82 = load i64, ptr %l53, !tbaa !24
  %t83 = load i64, ptr %l54, !tbaa !24
  %t84 = sub i64 %t82, %t83
  store i64 %t84, ptr %l55, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  store i64 %t85, ptr %l56, !tbaa !24
  %t86 = load i64, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l56, !tbaa !24
  %t88 = add i64 %t86, %t87
  store i64 %t88, ptr %l57, !tbaa !24
  %t89 = load i64, ptr %l57, !tbaa !24
  %t90 = sub i64 %t89, 1
  store i64 %t90, ptr %l58, !tbaa !24
  %t91 = load i64, ptr %l10, !tbaa !24
  store i64 %t91, ptr %l59, !tbaa !24
  %t92 = load i64, ptr %l58, !tbaa !24
  %t93 = load i64, ptr %l59, !tbaa !24
  %t94 = sdiv i64 %t92, %t93
  store i64 %t94, ptr %l60, !tbaa !24
  %t95 = load i64, ptr %l60, !tbaa !24
  store i64 %t95, ptr %l52, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb19
bb19:
  %t96 = load i64, ptr %l52, !tbaa !24
  store i64 %t96, ptr %l49, !tbaa !24
  br label %bb20
bb20:
  %t97 = load i64, ptr %l49, !tbaa !24
  store i64 %t97, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load i64, ptr %l12, !tbaa !24
  store i64 %t98, ptr %l61, !tbaa !24
  %t99 = load i64, ptr %l11, !tbaa !24
  store i64 %t99, ptr %l62, !tbaa !24
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = load i64, ptr %l62, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  store i1 %t102, ptr %l63, !tbaa !21
  %t103 = load i1, ptr %l63, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l64, !tbaa !21
  %t105 = load i1, ptr %l64, !tbaa !21
  br i1 %t105, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t106 = load i64, ptr %l8, !tbaa !24
  store i64 %t106, ptr %l65, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  store i64 %t107, ptr %l66, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  store i64 %t108, ptr %l67, !tbaa !24
  %t109 = load i64, ptr %l66, !tbaa !24
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = mul i64 %t109, %t110
  store i64 %t111, ptr %l68, !tbaa !24
  %t112 = load i64, ptr %l65, !tbaa !24
  %t113 = load i64, ptr %l68, !tbaa !24
  %t114 = add i64 %t112, %t113
  store i64 %t114, ptr %l69, !tbaa !24
  %t115 = load i64, ptr %l69, !tbaa !24
  store i64 %t115, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l13, !tbaa !24
  store i64 %t116, ptr %l70, !tbaa !24
  %t117 = load i64, ptr %l5, !tbaa !24
  store i64 %t117, ptr %l71, !tbaa !24
  %t118 = load i64, ptr %l13, !tbaa !24
  store i64 %t118, ptr %l72, !tbaa !24
  %t119 = load i64, ptr %l71, !tbaa !24
  %t120 = load i64, ptr %l72, !tbaa !24
  %t121 = add i64 %t119, %t120
  store i64 %t121, ptr %l73, !tbaa !24
  %t122 = load i64, ptr %l73, !tbaa !24
  %t123 = getelementptr [65 x i8], ptr %l4, i64 0, i64 %t122
  %t124 = load i8, ptr %t123, !tbaa !32
  store i8 %t124, ptr %l74, !tbaa !22
  %t125 = load i8, ptr %l74, !tbaa !22
  %t126 = load ptr, ptr %lp7
  %t127 = load i64, ptr %l70, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 %t127
  store i8 %t125, ptr %t130, !tbaa !32
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t131 = load i64, ptr %l12, !tbaa !24
  store i64 %t131, ptr %l75, !tbaa !24
  %t132 = load i64, ptr %l75, !tbaa !24
  %t133 = add i64 %t132, 1
  store i64 %t133, ptr %l76, !tbaa !24
  %t134 = load i64, ptr %l76, !tbaa !24
  store i64 %t134, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb21
bb26:
  call void @__olang_scope_close(ptr %s4)
  %t135 = load ptr, ptr %lp7
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l77, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2eformatSigned(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l0, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !65
  %t7 = load i64, ptr %l5, !tbaa !65
  %t8 = sub i64 0, %t7
  store i64 %t8, ptr %l6, !tbaa !65
  %t9 = load i64, ptr %l1, !tbaa !24
  store i64 %t9, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !65
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = call { i64, ptr } @std_2fprelude_2ftext_2eformatDigits(ptr %v0, i64 %t10, i1 true, i64 %t11)
  store { i64, ptr } %t12, ptr %l8
  br label %bb3
bb2:
  br label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
bb4:
  %t14 = load i64, ptr %l0, !tbaa !24
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  store i64 %t15, ptr %l10, !tbaa !65
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !65
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2ftext_2eformatDigits(ptr %v0, i64 %t17, i1 false, i64 %t18)
  store { i64, ptr } %t19, ptr %l12
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i8
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca i8
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i8
  %l12 = alloca i8
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i8
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i8
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i8
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp slt i64 %t4, 2
  store i1 %t5, ptr %l4, !tbaa !21
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  store i8 %t11, ptr %l7, !tbaa !22
  %t12 = load i8, ptr %l7, !tbaa !22
  %t13 = icmp ne i8 %t12, 48
  store i1 %t13, ptr %l8, !tbaa !21
  %t14 = load i1, ptr %l8, !tbaa !21
  store i1 %t14, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t16 = load i1, ptr %l9, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l10, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 1
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l11, !tbaa !22
  %t22 = load i8, ptr %l11, !tbaa !22
  store i8 %t22, ptr %l1, !tbaa !22
  %t23 = load i8, ptr %l1, !tbaa !22
  store i8 %t23, ptr %l12, !tbaa !22
  %t24 = load i8, ptr %l12, !tbaa !22
  %t25 = icmp eq i8 %t24, 120
  store i1 %t25, ptr %l13, !tbaa !21
  %t26 = load i1, ptr %l13, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb9
bb8:
  %t27 = load i8, ptr %l1, !tbaa !22
  store i8 %t27, ptr %l15, !tbaa !22
  %t28 = load i8, ptr %l15, !tbaa !22
  %t29 = icmp eq i8 %t28, 88
  store i1 %t29, ptr %l16, !tbaa !21
  %t30 = load i1, ptr %l16, !tbaa !21
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l14, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb12
bb11:
  %t32 = load i8, ptr %l1, !tbaa !22
  store i8 %t32, ptr %l18, !tbaa !22
  %t33 = load i8, ptr %l18, !tbaa !22
  %t34 = icmp eq i8 %t33, 98
  store i1 %t34, ptr %l19, !tbaa !21
  %t35 = load i1, ptr %l19, !tbaa !21
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l17, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb15
bb14:
  %t37 = load i8, ptr %l1, !tbaa !22
  store i8 %t37, ptr %l21, !tbaa !22
  %t38 = load i8, ptr %l21, !tbaa !22
  %t39 = icmp eq i8 %t38, 66
  store i1 %t39, ptr %l22, !tbaa !21
  %t40 = load i1, ptr %l22, !tbaa !21
  store i1 %t40, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l20, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2eisSpace(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i8
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i8
  %l6 = alloca i8
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i8
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i8
  %l14 = alloca i8
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  store i8 32, ptr %l2, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = load i8, ptr %l2, !tbaa !22
  %t4 = icmp eq i8 %t2, %t3
  store i1 %t4, ptr %l3, !tbaa !21
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i8, ptr %l0, !tbaa !22
  store i8 %t6, ptr %l5, !tbaa !22
  store i8 9, ptr %l6, !tbaa !22
  %t7 = load i8, ptr %l5, !tbaa !22
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = icmp eq i8 %t7, %t8
  store i1 %t9, ptr %l7, !tbaa !21
  %t10 = load i1, ptr %l7, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i8, ptr %l0, !tbaa !22
  store i8 %t12, ptr %l9, !tbaa !22
  store i8 10, ptr %l10, !tbaa !22
  %t13 = load i8, ptr %l9, !tbaa !22
  %t14 = load i8, ptr %l10, !tbaa !22
  %t15 = icmp eq i8 %t13, %t14
  store i1 %t15, ptr %l11, !tbaa !21
  %t16 = load i1, ptr %l11, !tbaa !21
  store i1 %t16, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l8, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i8, ptr %l0, !tbaa !22
  store i8 %t18, ptr %l13, !tbaa !22
  store i8 13, ptr %l14, !tbaa !22
  %t19 = load i8, ptr %l13, !tbaa !22
  %t20 = load i8, ptr %l14, !tbaa !22
  %t21 = icmp eq i8 %t19, %t20
  store i1 %t21, ptr %l15, !tbaa !21
  %t22 = load i1, ptr %l15, !tbaa !21
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fprelude_2ftext_2eleadingZeros(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !65
  store i64 %t1, ptr %l2, !tbaa !65
  %t2 = load i64, ptr %l2, !tbaa !65
  %t3 = icmp eq i64 %t2, 0
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 64, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  %t6 = load i64, ptr %l0, !tbaa !65
  store i64 %t6, ptr %l5, !tbaa !65
  %t7 = load i64, ptr %l5, !tbaa !65
  %t8 = lshr i64 %t7, 32
  store i64 %t8, ptr %l6, !tbaa !65
  %t9 = load i64, ptr %l6, !tbaa !65
  %t10 = icmp eq i64 %t9, 0
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i1, ptr %l7, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l8, !tbaa !24
  %t13 = load i64, ptr %l8, !tbaa !24
  %t14 = add i64 %t13, 32
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  store i64 %t15, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l0, !tbaa !65
  store i64 %t16, ptr %l10, !tbaa !65
  %t17 = load i64, ptr %l10, !tbaa !65
  %t18 = shl i64 %t17, 32
  store i64 %t18, ptr %l11, !tbaa !65
  %t19 = load i64, ptr %l11, !tbaa !65
  store i64 %t19, ptr %l0, !tbaa !65
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t20 = load i64, ptr %l0, !tbaa !65
  store i64 %t20, ptr %l12, !tbaa !65
  %t21 = load i64, ptr %l12, !tbaa !65
  %t22 = lshr i64 %t21, 48
  store i64 %t22, ptr %l13, !tbaa !65
  %t23 = load i64, ptr %l13, !tbaa !65
  %t24 = icmp eq i64 %t23, 0
  store i1 %t24, ptr %l14, !tbaa !21
  %t25 = load i1, ptr %l14, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l15, !tbaa !24
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = add i64 %t27, 16
  store i64 %t28, ptr %l16, !tbaa !24
  %t29 = load i64, ptr %l16, !tbaa !24
  store i64 %t29, ptr %l1, !tbaa !24
  %t30 = load i64, ptr %l0, !tbaa !65
  store i64 %t30, ptr %l17, !tbaa !65
  %t31 = load i64, ptr %l17, !tbaa !65
  %t32 = shl i64 %t31, 16
  store i64 %t32, ptr %l18, !tbaa !65
  %t33 = load i64, ptr %l18, !tbaa !65
  store i64 %t33, ptr %l0, !tbaa !65
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t34 = load i64, ptr %l0, !tbaa !65
  store i64 %t34, ptr %l19, !tbaa !65
  %t35 = load i64, ptr %l19, !tbaa !65
  %t36 = lshr i64 %t35, 56
  store i64 %t36, ptr %l20, !tbaa !65
  %t37 = load i64, ptr %l20, !tbaa !65
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l21, !tbaa !21
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t40 = load i64, ptr %l1, !tbaa !24
  store i64 %t40, ptr %l22, !tbaa !24
  %t41 = load i64, ptr %l22, !tbaa !24
  %t42 = add i64 %t41, 8
  store i64 %t42, ptr %l23, !tbaa !24
  %t43 = load i64, ptr %l23, !tbaa !24
  store i64 %t43, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l0, !tbaa !65
  store i64 %t44, ptr %l24, !tbaa !65
  %t45 = load i64, ptr %l24, !tbaa !65
  %t46 = shl i64 %t45, 8
  store i64 %t46, ptr %l25, !tbaa !65
  %t47 = load i64, ptr %l25, !tbaa !65
  store i64 %t47, ptr %l0, !tbaa !65
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t48 = load i64, ptr %l0, !tbaa !65
  store i64 %t48, ptr %l26, !tbaa !65
  %t49 = load i64, ptr %l26, !tbaa !65
  %t50 = lshr i64 %t49, 60
  store i64 %t50, ptr %l27, !tbaa !65
  %t51 = load i64, ptr %l27, !tbaa !65
  %t52 = icmp eq i64 %t51, 0
  store i1 %t52, ptr %l28, !tbaa !21
  %t53 = load i1, ptr %l28, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t54 = load i64, ptr %l1, !tbaa !24
  store i64 %t54, ptr %l29, !tbaa !24
  %t55 = load i64, ptr %l29, !tbaa !24
  %t56 = add i64 %t55, 4
  store i64 %t56, ptr %l30, !tbaa !24
  %t57 = load i64, ptr %l30, !tbaa !24
  store i64 %t57, ptr %l1, !tbaa !24
  %t58 = load i64, ptr %l0, !tbaa !65
  store i64 %t58, ptr %l31, !tbaa !65
  %t59 = load i64, ptr %l31, !tbaa !65
  %t60 = shl i64 %t59, 4
  store i64 %t60, ptr %l32, !tbaa !65
  %t61 = load i64, ptr %l32, !tbaa !65
  store i64 %t61, ptr %l0, !tbaa !65
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t62 = load i64, ptr %l0, !tbaa !65
  store i64 %t62, ptr %l33, !tbaa !65
  %t63 = load i64, ptr %l33, !tbaa !65
  %t64 = lshr i64 %t63, 62
  store i64 %t64, ptr %l34, !tbaa !65
  %t65 = load i64, ptr %l34, !tbaa !65
  %t66 = icmp eq i64 %t65, 0
  store i1 %t66, ptr %l35, !tbaa !21
  %t67 = load i1, ptr %l35, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %l36, !tbaa !24
  %t69 = load i64, ptr %l36, !tbaa !24
  %t70 = add i64 %t69, 2
  store i64 %t70, ptr %l37, !tbaa !24
  %t71 = load i64, ptr %l37, !tbaa !24
  store i64 %t71, ptr %l1, !tbaa !24
  %t72 = load i64, ptr %l0, !tbaa !65
  store i64 %t72, ptr %l38, !tbaa !65
  %t73 = load i64, ptr %l38, !tbaa !65
  %t74 = shl i64 %t73, 2
  store i64 %t74, ptr %l39, !tbaa !65
  %t75 = load i64, ptr %l39, !tbaa !65
  store i64 %t75, ptr %l0, !tbaa !65
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t76 = load i64, ptr %l0, !tbaa !65
  store i64 %t76, ptr %l40, !tbaa !65
  %t77 = load i64, ptr %l40, !tbaa !65
  %t78 = lshr i64 %t77, 63
  store i64 %t78, ptr %l41, !tbaa !65
  %t79 = load i64, ptr %l41, !tbaa !65
  %t80 = icmp eq i64 %t79, 0
  store i1 %t80, ptr %l42, !tbaa !21
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s7
  %t82 = load i64, ptr %l1, !tbaa !24
  store i64 %t82, ptr %l43, !tbaa !24
  %t83 = load i64, ptr %l43, !tbaa !24
  %t84 = add i64 %t83, 1
  store i64 %t84, ptr %l44, !tbaa !24
  %t85 = load i64, ptr %l44, !tbaa !24
  store i64 %t85, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t86 = load i64, ptr %l1, !tbaa !24
  store i64 %t86, ptr %l45, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i64, ptr %l45, !tbaa !24
  store i64 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2ftext_2emask63_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 9223372036854775807, ptr @G_2estd_2fprelude_2ftext_2emask63, !tbaa !65
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @std_2fprelude_2ftext_2emul128(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !65
  store i64 %t1, ptr %l10, !tbaa !65
  %t2 = load i64, ptr %l10, !tbaa !65
  %t3 = and i64 %t2, 4294967295
  store i64 %t3, ptr %l11, !tbaa !65
  %t4 = load i64, ptr %l11, !tbaa !65
  store i64 %t4, ptr %l2, !tbaa !65
  %t5 = load i64, ptr %l0, !tbaa !65
  store i64 %t5, ptr %l12, !tbaa !65
  %t6 = load i64, ptr %l12, !tbaa !65
  %t7 = lshr i64 %t6, 32
  store i64 %t7, ptr %l13, !tbaa !65
  %t8 = load i64, ptr %l13, !tbaa !65
  store i64 %t8, ptr %l3, !tbaa !65
  %t9 = load i64, ptr %l1, !tbaa !65
  store i64 %t9, ptr %l14, !tbaa !65
  %t10 = load i64, ptr %l14, !tbaa !65
  %t11 = and i64 %t10, 4294967295
  store i64 %t11, ptr %l15, !tbaa !65
  %t12 = load i64, ptr %l15, !tbaa !65
  store i64 %t12, ptr %l4, !tbaa !65
  %t13 = load i64, ptr %l1, !tbaa !65
  store i64 %t13, ptr %l16, !tbaa !65
  %t14 = load i64, ptr %l16, !tbaa !65
  %t15 = lshr i64 %t14, 32
  store i64 %t15, ptr %l17, !tbaa !65
  %t16 = load i64, ptr %l17, !tbaa !65
  store i64 %t16, ptr %l5, !tbaa !65
  %t17 = load i64, ptr %l2, !tbaa !65
  store i64 %t17, ptr %l18, !tbaa !65
  %t18 = load i64, ptr %l4, !tbaa !65
  store i64 %t18, ptr %l19, !tbaa !65
  %t19 = load i64, ptr %l18, !tbaa !65
  %t20 = load i64, ptr %l19, !tbaa !65
  %t21 = mul i64 %t19, %t20
  store i64 %t21, ptr %l20, !tbaa !65
  %t22 = load i64, ptr %l20, !tbaa !65
  store i64 %t22, ptr %l6, !tbaa !65
  %t23 = load i64, ptr %l3, !tbaa !65
  store i64 %t23, ptr %l21, !tbaa !65
  %t24 = load i64, ptr %l4, !tbaa !65
  store i64 %t24, ptr %l22, !tbaa !65
  %t25 = load i64, ptr %l21, !tbaa !65
  %t26 = load i64, ptr %l22, !tbaa !65
  %t27 = mul i64 %t25, %t26
  store i64 %t27, ptr %l23, !tbaa !65
  %t28 = load i64, ptr %l6, !tbaa !65
  store i64 %t28, ptr %l24, !tbaa !65
  %t29 = load i64, ptr %l24, !tbaa !65
  %t30 = lshr i64 %t29, 32
  store i64 %t30, ptr %l25, !tbaa !65
  %t31 = load i64, ptr %l23, !tbaa !65
  %t32 = load i64, ptr %l25, !tbaa !65
  %t33 = add i64 %t31, %t32
  store i64 %t33, ptr %l26, !tbaa !65
  %t34 = load i64, ptr %l26, !tbaa !65
  store i64 %t34, ptr %l7, !tbaa !65
  %t35 = load i64, ptr %l7, !tbaa !65
  store i64 %t35, ptr %l27, !tbaa !65
  %t36 = load i64, ptr %l27, !tbaa !65
  %t37 = and i64 %t36, 4294967295
  store i64 %t37, ptr %l28, !tbaa !65
  %t38 = load i64, ptr %l2, !tbaa !65
  store i64 %t38, ptr %l29, !tbaa !65
  %t39 = load i64, ptr %l5, !tbaa !65
  store i64 %t39, ptr %l30, !tbaa !65
  %t40 = load i64, ptr %l29, !tbaa !65
  %t41 = load i64, ptr %l30, !tbaa !65
  %t42 = mul i64 %t40, %t41
  store i64 %t42, ptr %l31, !tbaa !65
  %t43 = load i64, ptr %l28, !tbaa !65
  %t44 = load i64, ptr %l31, !tbaa !65
  %t45 = add i64 %t43, %t44
  store i64 %t45, ptr %l32, !tbaa !65
  %t46 = load i64, ptr %l32, !tbaa !65
  store i64 %t46, ptr %l8, !tbaa !65
  %t47 = load i64, ptr %l3, !tbaa !65
  store i64 %t47, ptr %l33, !tbaa !65
  %t48 = load i64, ptr %l5, !tbaa !65
  store i64 %t48, ptr %l34, !tbaa !65
  %t49 = load i64, ptr %l33, !tbaa !65
  %t50 = load i64, ptr %l34, !tbaa !65
  %t51 = mul i64 %t49, %t50
  store i64 %t51, ptr %l35, !tbaa !65
  %t52 = load i64, ptr %l7, !tbaa !65
  store i64 %t52, ptr %l36, !tbaa !65
  %t53 = load i64, ptr %l36, !tbaa !65
  %t54 = lshr i64 %t53, 32
  store i64 %t54, ptr %l37, !tbaa !65
  %t55 = load i64, ptr %l35, !tbaa !65
  %t56 = load i64, ptr %l37, !tbaa !65
  %t57 = add i64 %t55, %t56
  store i64 %t57, ptr %l38, !tbaa !65
  %t58 = load i64, ptr %l8, !tbaa !65
  store i64 %t58, ptr %l39, !tbaa !65
  %t59 = load i64, ptr %l39, !tbaa !65
  %t60 = lshr i64 %t59, 32
  store i64 %t60, ptr %l40, !tbaa !65
  %t61 = load i64, ptr %l38, !tbaa !65
  %t62 = load i64, ptr %l40, !tbaa !65
  %t63 = add i64 %t61, %t62
  store i64 %t63, ptr %l41, !tbaa !65
  %t64 = load i64, ptr %l41, !tbaa !65
  store i64 %t64, ptr %l9, !tbaa !65
  %t65 = load i64, ptr %l9, !tbaa !65
  store i64 %t65, ptr %l42, !tbaa !65
  %t66 = load i64, ptr %l0, !tbaa !65
  store i64 %t66, ptr %l43, !tbaa !65
  %t67 = load i64, ptr %l1, !tbaa !65
  store i64 %t67, ptr %l44, !tbaa !65
  %t68 = load i64, ptr %l43, !tbaa !65
  %t69 = load i64, ptr %l44, !tbaa !65
  %t70 = mul i64 %t68, %t69
  store i64 %t70, ptr %l45, !tbaa !65
  %t71 = load i64, ptr %l42, !tbaa !65
  %t72 = insertvalue { i64, i64 } undef, i64 %t71, 0
  %t73 = load i64, ptr %l45, !tbaa !65
  %t74 = insertvalue { i64, i64 } %t72, i64 %t73, 1
  store { i64, i64 } %t74, ptr %l46
  call void @__olang_scope_close(ptr %s0)
  %t75 = load { i64, i64 }, ptr %l46
  store { i64, i64 } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2epadNumber(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %l3 = alloca i8
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca i8
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i8
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i8 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l2, !tbaa !22
  store i8 %t1, ptr %l3, !tbaa !22
  %t2 = load i8, ptr %l3, !tbaa !22
  %t3 = icmp ne i8 %t2, 48
  store i1 %t3, ptr %l4, !tbaa !21
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr i8, ptr %t7, i64 0
  %t9 = load i8, ptr %t8, !tbaa !32
  store i8 %t9, ptr %l7, !tbaa !22
  %t10 = load i8, ptr %l7, !tbaa !22
  %t11 = icmp ne i8 %t10, 45
  store i1 %t11, ptr %l8, !tbaa !21
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l5, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l9, !tbaa !27
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l10, !tbaa !24
  %t16 = load i8, ptr %l2, !tbaa !22
  store i8 %t16, ptr %l11, !tbaa !22
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = load i8, ptr %l11, !tbaa !22
  %t20 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %t17, i64 %t18, i8 %t19)
  store { i64, ptr } %t20, ptr %l12
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t22, ptr %l13, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l14, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l16, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l17, !tbaa !24
  %t29 = icmp sge i64 1, 0
  store i1 %t29, ptr %l18, !tbaa !21
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = icmp sle i64 1, %t31
  store i1 %t32, ptr %l19, !tbaa !21
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb10:
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  store i1 %t36, ptr %l20, !tbaa !21
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb12:
  %t38 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l16, !tbaa !24
  %t41 = getelementptr i8, ptr %t39, i64 1
  %t42 = sub i64 %t40, 1
  %t43 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  store { i64, ptr } %t44, ptr %l21, !tbaa !27
  %t45 = load i64, ptr %l1, !tbaa !24
  store i64 %t45, ptr %l22, !tbaa !24
  %t46 = load i64, ptr %l22, !tbaa !24
  %t47 = sub i64 %t46, 1
  store i64 %t47, ptr %l23, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t49 = load i64, ptr %l23, !tbaa !24
  %t50 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %s0, { i64, ptr } %t48, i64 %t49, i8 48)
  store { i64, ptr } %t50, ptr %l24
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb14:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t51 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 1
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d3 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t51, i64 %t52)
  %t53 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  call void @__olang_sb_put(ptr %s2, ptr %t54, i64 %t55)
  %t56 = load ptr, ptr %s2
  %t57 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t58 = load i64, ptr %t57
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t56, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l25, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t62 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t62, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2ftext_2epow10Mant_2einit() #0 {
entry:
  %l0 = alloca [1392 x i64]
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 0
  store i64 -391859759250406776, ptr %t1
  %t2 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1
  store i64 1671618768450675795, ptr %t2
  %t3 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 2
  store i64 -7162441377172586091, ptr %t3
  %t4 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 3
  store i64 1044761730281672372, ptr %t4
  %t5 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 4
  store i64 -4341365703038344710, ptr %t5
  %t6 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 5
  store i64 5917638181279478369, ptr %t6
  %t7 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 6
  store i64 -815021110370542984, ptr %t7
  %t8 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 7
  store i64 -1826324310255427847, ptr %t8
  %t9 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 8
  store i64 -7426917221622671221, ptr %t9
  %t10 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 9
  store i64 -8058981721550724260, ptr %t10
  %t11 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 10
  store i64 -4671960508600951122, ptr %t11
  %t12 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 11
  store i64 8373016921771146291, ptr %t12
  %t13 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 12
  store i64 -1228264617323800998, ptr %t13
  %t14 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 13
  store i64 1242899115359157055, ptr %t14
  %t15 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 14
  store i64 -7685194413468457480, ptr %t15
  %t16 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 15
  store i64 5388497965526861063, ptr %t16
  %t17 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 16
  store i64 -4994806998408183946, ptr %t17
  %t18 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 17
  store i64 6735622456908576329, ptr %t18
  %t19 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 18
  store i64 -1631822729582842029, ptr %t19
  %t20 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 19
  store i64 -803843965719055396, ptr %t20
  %t21 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 20
  store i64 -7937418233630358124, ptr %t21
  %t22 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 21
  store i64 8720969558280366185, ptr %t22
  %t23 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 22
  store i64 -5310086773610559751, ptr %t23
  %t24 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 23
  store i64 -7545532125859093884, ptr %t24
  %t25 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 24
  store i64 -2025922448585811785, ptr %t25
  %t26 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 25
  store i64 -208543120469091547, ptr %t26
  %t27 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 26
  store i64 -8183730558007214222, ptr %t27
  %t28 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 27
  store i64 -130339450293182217, ptr %t28
  %t29 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 28
  store i64 -5617977179081629873, ptr %t29
  %t30 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 29
  store i64 -4774610331293865675, ptr %t30
  %t31 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 30
  store i64 -2410785455424649437, ptr %t31
  %t32 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 31
  store i64 -5968262914117332094, ptr %t32
  %t33 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 32
  store i64 -8424269937281487754, ptr %t33
  %t34 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 33
  store i64 5493207715531443249, ptr %t34
  %t35 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 34
  store i64 -5918651403174471789, ptr %t35
  %t36 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 35
  store i64 -2356862392440471747, ptr %t36
  %t37 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 36
  store i64 -2786628235540701832, ptr %t37
  %t38 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 37
  store i64 -2946077990550589683, ptr %t38
  %t39 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 38
  store i64 -8659171674854020501, ptr %t39
  %t40 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 39
  store i64 -8758827771735200408, ptr %t40
  %t41 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 40
  store i64 -6212278575140137722, ptr %t41
  %t42 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 41
  store i64 7498209359040551106, ptr %t42
  %t43 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 42
  store i64 -3153662200497784248, ptr %t43
  %t44 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 43
  store i64 149389661945913074, ptr %t44
  %t45 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 44
  store i64 -8888567902952197011, ptr %t45
  %t46 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 45
  store i64 93368538716195671, ptr %t46
  %t47 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 46
  store i64 -6499023860262858360, ptr %t47
  %t48 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 47
  store i64 4728396691822632493, ptr %t48
  %t49 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 48
  store i64 -3512093806901185046, ptr %t49
  %t50 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 49
  store i64 5910495864778290617, ptr %t50
  %t51 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 50
  store i64 -9112587656954322510, ptr %t51
  %t52 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 51
  store i64 8305745933913819539, ptr %t52
  %t53 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 52
  store i64 -6779048552765515233, ptr %t53
  %t54 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 53
  store i64 1158810380537498616, ptr %t54
  %t55 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 54
  store i64 -3862124672529506138, ptr %t55
  %t56 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 55
  store i64 -3163173042755514634, ptr %t56
  %t57 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 56
  store i64 -215969822234494768, ptr %t57
  %t58 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 57
  store i64 -8565652321871781196, ptr %t58
  %t59 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 58
  store i64 -7052510166537641086, ptr %t59
  %t60 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 59
  store i64 6175682344898606512, ptr %t60
  %t61 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 60
  store i64 -4203951689744663454, ptr %t61
  %t62 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 61
  store i64 -1503769105731517667, ptr %t62
  %t63 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 62
  store i64 -643253593753441413, ptr %t63
  %t64 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 63
  store i64 -6491397400591784988, ptr %t64
  %t65 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 64
  store i64 -7319562523736982739, ptr %t65
  %t66 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 65
  store i64 5166248661484910190, ptr %t66
  %t67 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 66
  store i64 -4537767136243840520, ptr %t67
  %t68 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 67
  store i64 -7377247228426025974, ptr %t68
  %t69 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 68
  store i64 -1060522901877412746, ptr %t69
  %t70 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 69
  store i64 -4609873017105144563, ptr %t70
  %t71 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 70
  store i64 -7580355841314464822, ptr %t71
  %t72 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 71
  store i64 4036358391950366504, ptr %t72
  %t73 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 72
  store i64 -4863758783215693124, ptr %t73
  %t74 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 73
  store i64 -4177924046916817678, ptr %t74
  %t75 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 74
  store i64 -1468012460592228501, ptr %t75
  %t76 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 75
  store i64 -610719040218634194, ptr %t76
  %t77 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 76
  store i64 -7835036815511224669, ptr %t77
  %t78 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 77
  store i64 8841672636718129437, ptr %t78
  %t79 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 78
  store i64 -5182110000961642932, ptr %t79
  %t80 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 79
  store i64 6440404777470273892, ptr %t80
  %t81 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 80
  store i64 -1865951482774665761, ptr %t81
  %t82 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 81
  store i64 8050505971837842365, ptr %t82
  %t83 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 82
  store i64 -8083748704375247957, ptr %t83
  %t84 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 83
  store i64 -6497648813669818282, ptr %t84
  %t85 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 84
  store i64 -5492999862041672042, ptr %t85
  %t86 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 85
  store i64 -8122061017087272852, ptr %t86
  %t87 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 86
  store i64 -2254563809124702148, ptr %t87
  %t88 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 87
  store i64 3682481783923072647, ptr %t88
  %t89 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 88
  store i64 -8326631408344020699, ptr %t89
  %t90 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 89
  store i64 -6921820921902855404, ptr %t90
  %t91 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 90
  store i64 -5796603242002637969, ptr %t91
  %t92 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 91
  store i64 571095884476206553, ptr %t92
  %t93 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 92
  store i64 -2634068034075909558, ptr %t93
  %t94 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 93
  store i64 -3897816162832129712, ptr %t94
  %t95 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 94
  store i64 -8563821548938525330, ptr %t95
  %t96 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 95
  store i64 -4741978110983775022, ptr %t96
  %t97 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 96
  store i64 -6093090917745768758, ptr %t97
  %t98 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 97
  store i64 7907585416552444934, ptr %t98
  %t99 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 98
  store i64 -3004677628754823043, ptr %t99
  %t100 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 99
  store i64 661109733835780360, ptr %t100
  %t101 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 100
  store i64 -8795452545612846258, ptr %t101
  %t102 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 101
  store i64 2719036592861056677, ptr %t102
  %t103 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 102
  store i64 -6382629663588669919, ptr %t103
  %t104 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 103
  store i64 -5824576295778454962, ptr %t104
  %t105 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 104
  store i64 -3366601061058449494, ptr %t105
  %t106 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 105
  store i64 1942651667131707105, ptr %t106
  %t107 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 106
  store i64 -9021654690802612790, ptr %t107
  %t108 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 107
  store i64 5825843310384704845, ptr %t108
  %t109 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 108
  store i64 -6665382345075878084, ptr %t109
  %t110 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 109
  store i64 -1941067898873894752, ptr %t110
  %t111 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 110
  store i64 -3720041912917459700, ptr %t111
  %t112 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 111
  store i64 2185351144835019464, ptr %t112
  %t113 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 112
  store i64 -38366372719436721, ptr %t113
  %t114 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 113
  store i64 2731688931043774330, ptr %t114
  %t115 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 114
  store i64 -6941508010590729807, ptr %t115
  %t116 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 115
  store i64 8624834609543440812, ptr %t116
  %t117 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 116
  store i64 -4065198994811024355, ptr %t117
  %t118 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 117
  store i64 -3054014793352862697, ptr %t118
  %t119 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 118
  store i64 -469812725086392539, ptr %t119
  %t120 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 119
  store i64 5405853545163697437, ptr %t120
  %t121 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 120
  store i64 -7211161980820077193, ptr %t121
  %t122 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 121
  store i64 5684501474941004850, ptr %t122
  %t123 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 122
  store i64 -4402266457597708587, ptr %t123
  %t124 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 123
  store i64 2493940825248868159, ptr %t124
  %t125 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 124
  store i64 -891147053569747830, ptr %t125
  %t126 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 125
  store i64 7729112049988473103, ptr %t126
  %t127 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 126
  store i64 -7474495936122174250, ptr %t127
  %t128 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 127
  store i64 -9004363024039368023, ptr %t128
  %t129 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 128
  store i64 -4731433901725329908, ptr %t129
  %t130 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 129
  store i64 2579604275232953683, ptr %t130
  %t131 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 130
  store i64 -1302606358729274481, ptr %t131
  %t132 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 131
  store i64 3224505344041192104, ptr %t132
  %t133 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 132
  store i64 -7731658001846878407, ptr %t133
  %t134 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 133
  store i64 8932844867666826921, ptr %t134
  %t135 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 134
  store i64 -5052886483881210105, ptr %t135
  %t136 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 135
  store i64 -2669001970698630061, ptr %t136
  %t137 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 136
  store i64 -1704422086424124727, ptr %t137
  %t138 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 137
  store i64 -3336252463373287576, ptr %t138
  %t139 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 138
  store i64 -7982792831656159810, ptr %t139
  %t140 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 139
  store i64 2526528228819083169, ptr %t140
  %t141 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 140
  store i64 -5366805021142811859, ptr %t141
  %t142 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 141
  store i64 -6065211750830921846, ptr %t142
  %t143 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 142
  store i64 -2096820258001126919, ptr %t143
  %t144 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 143
  store i64 1641857348316123500, ptr %t144
  %t145 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 144
  store i64 -8228041688891786181, ptr %t145
  %t146 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 145
  store i64 -5891368184943504669, ptr %t146
  %t147 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 146
  store i64 -5673366092687344822, ptr %t147
  %t148 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 147
  store i64 -7364210231179380836, ptr %t148
  %t149 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 148
  store i64 -2480021597431793123, ptr %t149
  %t150 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 149
  store i64 4629795266307937667, ptr %t150
  %t151 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 150
  store i64 -8467542526035952558, ptr %t151
  %t152 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 151
  store i64 5199465050656154994, ptr %t152
  %t153 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 152
  store i64 -5972742139117552794, ptr %t153
  %t154 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 153
  store i64 -2724040723534582065, ptr %t154
  %t155 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 154
  store i64 -2854241655469553088, ptr %t155
  %t156 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 155
  store i64 -8016736922845615486, ptr %t156
  %t157 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 156
  store i64 -8701430062309552536, ptr %t157
  %t158 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 157
  store i64 6518754469289960081, ptr %t158
  %t159 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 158
  store i64 -6265101559459552766, ptr %t159
  %t160 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 159
  store i64 8148443086612450102, ptr %t160
  %t161 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 160
  store i64 -3219690930897053053, ptr %t161
  %t162 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 161
  store i64 962181821410786819, ptr %t162
  %t163 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 162
  store i64 -8929835859451740015, ptr %t163
  %t164 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 163
  store i64 -1704479370831952190, ptr %t164
  %t165 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 164
  store i64 -6550608805887287114, ptr %t165
  %t166 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 165
  store i64 7092772823314835570, ptr %t166
  %t167 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 166
  store i64 -3576574988931720989, ptr %t167
  %t168 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 167
  store i64 -357406007711231345, ptr %t168
  %t169 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 168
  store i64 -9152888395723407474, ptr %t169
  %t170 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 169
  store i64 8999993282035256217, ptr %t170
  %t171 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 170
  store i64 -6829424476226871438, ptr %t171
  %t172 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 171
  store i64 2026619565689294464, ptr %t172
  %t173 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 172
  store i64 -3925094576856201394, ptr %t173
  %t174 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 173
  store i64 -6690097579743157728, ptr %t174
  %t175 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 174
  store i64 -294682202642863838, ptr %t175
  %t176 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 175
  store i64 5472436080603216552, ptr %t176
  %t177 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 176
  store i64 -7101705404292871755, ptr %t177
  %t178 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 177
  store i64 8031958568804398249, ptr %t178
  %t179 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 178
  store i64 -4265445736938701790, ptr %t179
  %t180 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 179
  store i64 -3795109844276665901, ptr %t180
  %t181 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 180
  store i64 -720121152745989333, ptr %t181
  %t182 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 181
  store i64 9091170749936331336, ptr %t182
  %t183 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 182
  store i64 -7367604748107325189, ptr %t183
  %t184 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 183
  store i64 3376138709496513133, ptr %t184
  %t185 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 184
  store i64 -4597819916706768583, ptr %t185
  %t186 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 185
  store i64 -391512631556746488, ptr %t186
  %t187 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 186
  store i64 -1135588877456072824, ptr %t187
  %t188 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 187
  store i64 8733981247408842698, ptr %t188
  %t189 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 188
  store i64 -7627272076051127371, ptr %t189
  %t190 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 189
  store i64 5458738279630526686, ptr %t190
  %t191 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 190
  store i64 -4922404076636521310, ptr %t191
  %t192 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 191
  store i64 -7011635205744005354, ptr %t192
  %t193 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 192
  store i64 -1541319077368263733, ptr %t193
  %t194 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 193
  store i64 5070514048102157020, ptr %t194
  %t195 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 194
  store i64 -7880853450996246689, ptr %t195
  %t196 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 195
  store i64 863228270850154185, ptr %t196
  %t197 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 196
  store i64 -5239380795317920458, ptr %t197
  %t198 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 197
  store i64 -3532650679864695173, ptr %t198
  %t199 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 198
  store i64 -1937539975720012668, ptr %t199
  %t200 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 199
  store i64 -9027499368258256870, ptr %t200
  %t201 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 200
  store i64 -8128491512466089774, ptr %t201
  %t202 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 201
  store i64 -3336344095947716592, ptr %t202
  %t203 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 202
  store i64 -5548928372155224313, ptr %t203
  %t204 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 203
  store i64 -8782116138362033643, ptr %t204
  %t205 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 204
  store i64 -2324474446766642487, ptr %t205
  %t206 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 205
  store i64 7469098900757009562, ptr %t206
  %t207 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 206
  store i64 -8370325556870233411, ptr %t207
  %t208 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 207
  store i64 -2249342214667950880, ptr %t208
  %t209 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 208
  store i64 -5851220927660403859, ptr %t209
  %t210 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 209
  store i64 6411694268519837208, ptr %t210
  %t211 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 210
  store i64 -2702340141148116920, ptr %t211
  %t212 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 211
  store i64 -5820440219632367202, ptr %t212
  %t213 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 212
  store i64 -8606491615858654931, ptr %t213
  %t214 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 213
  store i64 7891439908798240259, ptr %t214
  %t215 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 214
  store i64 -6146428501395930760, ptr %t215
  %t216 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 215
  store i64 -3970758169284363389, ptr %t216
  %t217 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 216
  store i64 -3071349608317525546, ptr %t217
  %t218 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 217
  store i64 -351761693178066332, ptr %t218
  %t219 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 218
  store i64 -8837122532839535322, ptr %t219
  %t220 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 219
  store i64 6697677969404790399, ptr %t220
  %t221 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 220
  store i64 -6434717147622031249, ptr %t221
  %t222 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 221
  store i64 -851274575098787810, ptr %t222
  %t223 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 222
  store i64 -3431710416100151157, ptr %t223
  %t224 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 223
  store i64 -1064093218873484762, ptr %t224
  %t225 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 224
  store i64 -9062348037703676329, ptr %t225
  %t226 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 225
  store i64 8558313775058847832, ptr %t226
  %t227 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 226
  store i64 -6716249028702207507, ptr %t227
  %t228 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 227
  store i64 6086206200396171886, ptr %t228
  %t229 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 228
  store i64 -3783625267450371480, ptr %t229
  %t230 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 229
  store i64 -6227300304786948855, ptr %t230
  %t231 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 230
  store i64 -117845565885576446, ptr %t231
  %t232 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 231
  store i64 -3172439362556298164, ptr %t232
  %t233 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 232
  store i64 -6991182506319567135, ptr %t233
  %t234 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 233
  store i64 -4288617610811380305, ptr %t234
  %t235 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 234
  store i64 -4127292114472071014, ptr %t235
  %t236 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 235
  store i64 3862600023340550427, ptr %t236
  %t237 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 236
  store i64 -547429124662700864, ptr %t237
  %t238 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 237
  store i64 -4395122007679087774, ptr %t238
  %t239 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 238
  store i64 -7259672230555269896, ptr %t239
  %t240 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 239
  store i64 8782263791269039901, ptr %t240
  %t241 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 240
  store i64 -4462904269766699466, ptr %t241
  %t242 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 241
  store i64 -7468914334623251740, ptr %t242
  %t243 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 242
  store i64 -966944318780986428, ptr %t243
  %t244 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 243
  store i64 4498915137003099037, ptr %t244
  %t245 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 244
  store i64 -7521869226879198374, ptr %t245
  %t246 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 245
  store i64 -6411550076227838910, ptr %t246
  %t247 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 246
  store i64 -4790650515171610063, ptr %t247
  %t248 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 247
  store i64 5820620459997365075, ptr %t248
  %t249 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 248
  store i64 -1376627125537124675, ptr %t249
  %t250 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 249
  store i64 -6559282480285457368, ptr %t250
  %t251 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 250
  store i64 -7777920981101784778, ptr %t251
  %t252 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 251
  store i64 -8711237568605798759, ptr %t252
  %t253 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 252
  store i64 -5110715207949843068, ptr %t253
  %t254 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 253
  store i64 2946011094524915263, ptr %t254
  %t255 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 254
  store i64 -1776707991509915931, ptr %t255
  %t256 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 255
  store i64 3682513868156144079, ptr %t256
  %t257 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 256
  store i64 -8027971522334779313, ptr %t257
  %t258 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 257
  store i64 4607414176811284001, ptr %t258
  %t259 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 258
  store i64 -5423278384491086237, ptr %t259
  %t260 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 259
  store i64 1147581702586717097, ptr %t260
  %t261 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 260
  store i64 -2167411962186469893, ptr %t261
  %t262 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 261
  store i64 -3177208890193991532, ptr %t262
  %t263 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 262
  store i64 -8272161504007625539, ptr %t263
  %t264 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 263
  store i64 7237616480483531100, ptr %t264
  %t265 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 264
  store i64 -5728515861582144020, ptr %t265
  %t266 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 265
  store i64 -4788037454677749837, ptr %t266
  %t267 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 266
  store i64 -2548958808550292121, ptr %t267
  %t268 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 267
  store i64 -1373360799919799392, ptr %t268
  %t269 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 268
  store i64 -8510628282985014432, ptr %t269
  %t270 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 269
  store i64 -858350499949874620, ptr %t270
  %t271 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 270
  store i64 -6026599335303880135, ptr %t271
  %t272 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 271
  store i64 3538747893490044629, ptr %t272
  %t273 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 272
  store i64 -2921563150702462265, ptr %t273
  %t274 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 273
  store i64 9035120885289943691, ptr %t274
  %t275 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 274
  store i64 -8743505996830120772, ptr %t275
  %t276 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 275
  store i64 -5882264492762254953, ptr %t276
  %t277 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 276
  store i64 -6317696477610263061, ptr %t277
  %t278 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 277
  store i64 -2741144597525430788, ptr %t278
  %t279 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 278
  store i64 -3285434578585440922, ptr %t279
  %t280 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 279
  store i64 -3426430746906788485, ptr %t280
  %t281 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 280
  store i64 -8970925639256982432, ptr %t281
  %t282 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 281
  store i64 4776009810824339053, ptr %t282
  %t283 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 282
  store i64 -6601971030643840136, ptr %t283
  %t284 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 283
  store i64 5970012263530423816, ptr %t284
  %t285 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 284
  store i64 -3640777769877412266, ptr %t285
  %t286 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 285
  store i64 7462515329413029771, ptr %t286
  %t287 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 286
  store i64 -9193015133814464522, ptr %t287
  %t288 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 287
  store i64 52386062455755702, ptr %t288
  %t289 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 288
  store i64 -6879582898840692749, ptr %t289
  %t290 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 289
  store i64 -9157889458785081180, ptr %t290
  %t291 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 290
  store i64 -3987792605123478032, ptr %t291
  %t292 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 291
  store i64 6999382250228200141, ptr %t292
  %t293 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 292
  store i64 -373054737976959636, ptr %t293
  %t294 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 293
  store i64 8749227812785250177, ptr %t294
  %t295 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 294
  store i64 -7150688238876681629, ptr %t295
  %t296 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 295
  store i64 -3755104653863994448, ptr %t296
  %t297 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 296
  store i64 -4326674280168464132, ptr %t297
  %t298 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 297
  store i64 -4693880817329993060, ptr %t298
  %t299 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 298
  store i64 -796656831783192261, ptr %t299
  %t300 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 299
  store i64 -1255665003235103420, ptr %t300
  %t301 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 300
  store i64 -7415439547505577019, ptr %t301
  %t302 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 301
  store i64 8438581409832836170, ptr %t302
  %t303 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 302
  store i64 -4657613415954583370, ptr %t303
  %t304 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 303
  store i64 -3286831292991118499, ptr %t304
  %t305 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 304
  store i64 -1210330751515841308, ptr %t305
  %t306 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 305
  store i64 -8720225134666286028, ptr %t306
  %t307 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 306
  store i64 -7673985747338482674, ptr %t307
  %t308 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 307
  store i64 -3144297699952734816, ptr %t308
  %t309 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 308
  store i64 -4980796165745715438, ptr %t309
  %t310 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 309
  store i64 -8542058143368306423, ptr %t310
  %t311 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 310
  store i64 -1614309188754756393, ptr %t311
  %t312 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 311
  store i64 3157485376071780683, ptr %t312
  %t313 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 312
  store i64 -7926472270612804602, ptr %t313
  %t314 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 313
  store i64 8890957387685944783, ptr %t314
  %t315 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 314
  store i64 -5296404319838617848, ptr %t315
  %t316 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 315
  store i64 1890324697752655170, ptr %t316
  %t317 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 316
  store i64 -2008819381370884406, ptr %t317
  %t318 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 317
  store i64 2362905872190818963, ptr %t318
  %t319 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 318
  store i64 -8173041140997884610, ptr %t319
  %t320 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 319
  store i64 6088502188546649756, ptr %t320
  %t321 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 320
  store i64 -5604615407819967859, ptr %t321
  %t322 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 321
  store i64 -1612744301171463613, ptr %t322
  %t323 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 322
  store i64 -2394083241347571919, ptr %t323
  %t324 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 323
  store i64 7207441660390446292, ptr %t324
  %t325 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 324
  store i64 -8413831053483314306, ptr %t325
  %t326 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 325
  store i64 -2412877989897052924, ptr %t326
  %t327 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 326
  store i64 -5905602798426754978, ptr %t327
  %t328 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 327
  store i64 -7627783505798704059, ptr %t328
  %t329 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 328
  store i64 -2770317479606055818, ptr %t329
  %t330 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 329
  store i64 4300328673033783639, ptr %t330
  %t331 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 330
  store i64 -8648977452394866743, ptr %t331
  %t332 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 331
  store i64 -1923980597781273130, ptr %t332
  %t333 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 332
  store i64 -6199535797066195524, ptr %t333
  %t334 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 333
  store i64 6818396289628184396, ptr %t334
  %t335 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 334
  store i64 -3137733727905356501, ptr %t335
  %t336 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 335
  store i64 8522995362035230495, ptr %t336
  %t337 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 336
  store i64 -8878612607581929669, ptr %t337
  %t338 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 337
  store i64 3021029092058325107, ptr %t338
  %t339 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 338
  store i64 -6486579741050024183, ptr %t339
  %t340 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 339
  store i64 -835399653354481520, ptr %t340
  %t341 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 340
  store i64 -3496538657885142324, ptr %t341
  %t342 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 341
  store i64 8179122470161673908, ptr %t342
  %t343 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 342
  store i64 -9102865688819295809, ptr %t343
  %t344 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 343
  store i64 -4111420493003729616, ptr %t344
  %t345 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 344
  store i64 -6766896092596731857, ptr %t345
  %t346 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 345
  store i64 -5139275616254662020, ptr %t346
  %t347 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 346
  store i64 -3846934097318526917, ptr %t347
  %t348 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 347
  store i64 -6424094520318327524, ptr %t348
  %t349 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 348
  store i64 -196981603220770742, ptr %t349
  %t350 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 349
  store i64 -8030118150397909405, ptr %t350
  %t351 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 350
  store i64 -7040642529654063570, ptr %t351
  %t352 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 351
  store i64 -7324666853212387330, ptr %t352
  %t353 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 352
  store i64 -4189117143640191558, ptr %t353
  %t354 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 353
  store i64 4679224488766679549, ptr %t354
  %t355 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 354
  store i64 -624710411122851544, ptr %t355
  %t356 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 355
  store i64 -3374341425896426372, ptr %t356
  %t357 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 356
  store i64 -7307973034592864071, ptr %t357
  %t358 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 357
  store i64 -9026492418826348338, ptr %t358
  %t359 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 358
  store i64 -4523280274813692185, ptr %t359
  %t360 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 359
  store i64 -2059743486678159615, ptr %t360
  %t361 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 360
  store i64 -1042414325089727327, ptr %t361
  %t362 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 361
  store i64 -2574679358347699519, ptr %t362
  %t363 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 362
  store i64 -7569037980822161435, ptr %t363
  %t364 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 363
  store i64 3002511419460075705, ptr %t364
  %t365 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 364
  store i64 -4849611457600313890, ptr %t365
  %t366 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 365
  store i64 8364825292752482535, ptr %t366
  %t367 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 366
  store i64 -1450328303573004458, ptr %t367
  %t368 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 367
  store i64 1232659579085827361, ptr %t368
  %t369 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 368
  store i64 -7823984217374209643, ptr %t369
  %t370 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 369
  store i64 -3841273781498745804, ptr %t370
  %t371 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 370
  store i64 -5168294253290374149, ptr %t371
  %t372 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 371
  store i64 4421779809981343554, ptr %t372
  %t373 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 372
  store i64 -1848681798185579782, ptr %t373
  %t374 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 373
  store i64 915538744049291538, ptr %t374
  %t375 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 374
  store i64 -8072955151507069220, ptr %t375
  %t376 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 375
  store i64 5183897733458195115, ptr %t376
  %t377 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 376
  store i64 -5479507920956448621, ptr %t377
  %t378 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 377
  store i64 6479872166822743894, ptr %t378
  %t379 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 378
  store i64 -2237698882768172872, ptr %t379
  %t380 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 379
  store i64 3488154190101041964, ptr %t380
  %t381 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 380
  store i64 -8316090829371189901, ptr %t381
  %t382 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 381
  store i64 2180096368813151227, ptr %t382
  %t383 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 382
  store i64 -5783427518286599473, ptr %t383
  %t384 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 383
  store i64 -1886565557410948870, ptr %t384
  %t385 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 384
  store i64 -2617598379430861437, ptr %t385
  %t386 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 385
  store i64 -2358206946763686087, ptr %t386
  %t387 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 386
  store i64 -8553528014785370254, ptr %t387
  %t388 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 387
  store i64 7749492695127472003, ptr %t388
  %t389 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 388
  store i64 -6080224000054324913, ptr %t389
  %t390 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 389
  store i64 463493832054564196, ptr %t390
  %t391 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 390
  store i64 -2988593981640518238, ptr %t391
  %t392 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 391
  store i64 -4032318728359182659, ptr %t392
  %t393 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 392
  store i64 -8785400266166405755, ptr %t393
  %t394 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 393
  store i64 -4826042214438183114, ptr %t394
  %t395 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 394
  store i64 -6370064314280619289, ptr %t395
  %t396 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 395
  store i64 3190819268807046916, ptr %t396
  %t397 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 396
  store i64 -3350894374423386208, ptr %t397
  %t398 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 397
  store i64 -623161932418579259, ptr %t398
  %t399 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 398
  store i64 -9011838011655698236, ptr %t399
  %t400 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 399
  store i64 -7307005235402693893, ptr %t400
  %t401 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 400
  store i64 -6653111496142234891, ptr %t401
  %t402 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 401
  store i64 -4522070525825979462, ptr %t402
  %t403 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 402
  store i64 -3704703351750405709, ptr %t403
  %t404 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 403
  store i64 3570783879572301480, ptr %t404
  %t405 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 404
  store i64 -19193171260619233, ptr %t405
  %t406 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 405
  store i64 -148206168962011054, ptr %t406
  %t407 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 406
  store i64 -6929524759678968877, ptr %t407
  %t408 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 407
  store i64 -92628855601256909, ptr %t408
  %t409 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 408
  store i64 -4050219931171323192, ptr %t409
  %t410 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 409
  store i64 -115786069501571136, ptr %t410
  %t411 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 410
  store i64 -451088895536766085, ptr %t411
  %t412 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 411
  store i64 4466953431550423984, ptr %t412
  %t413 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 412
  store i64 -7199459587351560659, ptr %t413
  %t414 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 413
  store i64 486002885505321038, ptr %t414
  %t415 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 414
  store i64 -4387638465762062920, ptr %t415
  %t416 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 415
  store i64 5219189625309039202, ptr %t416
  %t417 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 416
  store i64 -872862063775190746, ptr %t417
  %t418 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 417
  store i64 6523987031636299002, ptr %t418
  %t419 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 418
  store i64 -7463067817500576073, ptr %t419
  %t420 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 419
  store i64 -534194123654701028, ptr %t420
  %t421 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 420
  store i64 -4717148753448332187, ptr %t421
  %t422 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 421
  store i64 -667742654568376285, ptr %t422
  %t423 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 422
  store i64 -1284749923383027329, ptr %t423
  %t424 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 423
  store i64 8388693718644305452, ptr %t424
  %t425 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 424
  store i64 -7720497729755473937, ptr %t425
  %t426 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 425
  store i64 -6286281471915778852, ptr %t426
  %t427 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 426
  store i64 -5038936143766954517, ptr %t427
  %t428 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 427
  store i64 -7857851839894723565, ptr %t428
  %t429 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 428
  store i64 -1686984161281305242, ptr %t429
  %t430 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 429
  store i64 8624429273841147159, ptr %t430
  %t431 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 430
  store i64 -7971894128441897632, ptr %t431
  %t432 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 431
  store i64 778582277723329070, ptr %t432
  %t433 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 432
  store i64 -5353181642124984136, ptr %t433
  %t434 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 433
  store i64 973227847154161338, ptr %t434
  %t435 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 434
  store i64 -2079791034228842266, ptr %t435
  %t436 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 435
  store i64 1216534808942701673, ptr %t436
  %t437 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 436
  store i64 -8217398424034108273, ptr %t437
  %t438 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 437
  store i64 -3851351762838199359, ptr %t438
  %t439 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 438
  store i64 -5660062011615247437, ptr %t439
  %t440 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 439
  store i64 -4814189703547749198, ptr %t440
  %t441 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 440
  store i64 -2463391496091671392, ptr %t441
  %t442 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 441
  store i64 -6017737129434686498, ptr %t442
  %t443 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 442
  store i64 -8457148712698376476, ptr %t443
  %t444 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 443
  store i64 7768129340171790699, ptr %t444
  %t445 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 444
  store i64 -5959749872445582691, ptr %t445
  %t446 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 445
  store i64 -8736582398494813242, ptr %t446
  %t447 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 446
  store i64 -2838001322129590460, ptr %t447
  %t448 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 447
  store i64 -1697355961263740745, ptr %t448
  %t449 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 448
  store i64 -8691279853972075893, ptr %t449
  %t450 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 449
  store i64 1244995533423855986, ptr %t450
  %t451 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 450
  store i64 -6252413799037706963, ptr %t451
  %t452 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 451
  store i64 -3055441601647567921, ptr %t452
  %t453 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 452
  store i64 -3203831230369745799, ptr %t453
  %t454 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 453
  store i64 5404070034795315907, ptr %t454
  %t455 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 454
  store i64 -8919923546622172981, ptr %t455
  %t456 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 455
  store i64 -3539985255894009414, ptr %t456
  %t457 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 456
  store i64 -6538218414850328322, ptr %t457
  %t458 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 457
  store i64 -4424981569867511768, ptr %t458
  %t459 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 458
  store i64 -3561087000135522498, ptr %t459
  %t460 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 459
  store i64 8303831092947774002, ptr %t460
  %t461 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 460
  store i64 -9143208402725783417, ptr %t461
  %t462 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 461
  store i64 578208414664970847, ptr %t462
  %t463 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 462
  store i64 -6817324484979841368, ptr %t463
  %t464 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 463
  store i64 -3888925500096174345, ptr %t464
  %t465 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 464
  store i64 -3909969587797413806, ptr %t465
  %t466 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 465
  store i64 -249470856692830027, ptr %t466
  %t467 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 466
  store i64 -275775966319379353, ptr %t467
  %t468 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 467
  store i64 -4923524589293425438, ptr %t468
  %t469 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 468
  store i64 -7089889006590693952, ptr %t469
  %t470 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 469
  store i64 -3077202868308390899, ptr %t470
  %t471 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 470
  store i64 -4250675239810979535, ptr %t471
  %t472 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 471
  store i64 765182433041899281, ptr %t472
  %t473 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 472
  store i64 -701658031336336515, ptr %t473
  %t474 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 473
  store i64 5568164059729762005, ptr %t474
  %t475 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 474
  store i64 -7356065297226292178, ptr %t475
  %t476 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 475
  store i64 5785945546544795205, ptr %t476
  %t477 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 476
  store i64 -4583395603105477319, ptr %t477
  %t478 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 477
  store i64 -1990940103673781802, ptr %t478
  %t479 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 478
  store i64 -1117558485454458744, ptr %t479
  %t480 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 479
  store i64 6734696907262548556, ptr %t480
  %t481 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 480
  store i64 -7616003081050118571, ptr %t481
  %t482 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 481
  store i64 4209185567039092847, ptr %t482
  %t483 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 482
  store i64 -4908317832885260310, ptr %t483
  %t484 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 483
  store i64 -8573576096483297653, ptr %t484
  %t485 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 484
  store i64 -1523711272679187483, ptr %t485
  %t486 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 485
  store i64 3118087934678041646, ptr %t486
  %t487 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 486
  store i64 -7869848573065574033, ptr %t487
  %t488 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 487
  store i64 4254647968387469981, ptr %t488
  %t489 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 488
  store i64 -5225624697904579637, ptr %t489
  %t490 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 489
  store i64 706623942056949572, ptr %t490
  %t491 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 490
  store i64 -1920344853953336643, ptr %t491
  %t492 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 491
  store i64 -3728406090856200939, ptr %t492
  %t493 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 492
  store i64 -8117744561361917258, ptr %t493
  %t494 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 493
  store i64 -6941939825212513491, ptr %t494
  %t495 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 494
  store i64 -5535494683275008668, ptr %t495
  %t496 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 495
  store i64 5157633273766521849, ptr %t496
  %t497 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 496
  store i64 -2307682335666372931, ptr %t497
  %t498 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 497
  store i64 6447041592208152311, ptr %t498
  %t499 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 498
  store i64 -8359830487432564938, ptr %t499
  %t500 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 499
  store i64 6335244004343789146, ptr %t500
  %t501 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 500
  store i64 -5838102090863318269, ptr %t501
  %t502 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 501
  store i64 -1304317031425039375, ptr %t502
  %t503 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 502
  store i64 -2685941595151759932, ptr %t503
  %t504 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 503
  store i64 -1630396289281299219, ptr %t504
  %t505 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 504
  store i64 -8596242524610931813, ptr %t505
  %t506 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 505
  store i64 1286845328412881940, ptr %t506
  %t507 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 506
  store i64 -6133617137336276863, ptr %t507
  %t508 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 507
  store i64 -3003129357911285479, ptr %t508
  %t509 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 508
  store i64 -3055335403242958174, ptr %t509
  %t510 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 509
  store i64 5469460339465668959, ptr %t510
  %t511 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 510
  store i64 -8827113654667930715, ptr %t511
  %t512 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 511
  store i64 8030098730593431003, ptr %t512
  %t513 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 512
  store i64 -6422206049907525490, ptr %t513
  %t514 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 513
  store i64 -3797434642040374958, ptr %t514
  %t515 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 514
  store i64 -3416071543957018958, ptr %t515
  %t516 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 515
  store i64 9088264752731695015, ptr %t516
  %t517 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 516
  store i64 -9052573742614218705, ptr %t517
  %t518 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 517
  store i64 -8154892584824854328, ptr %t518
  %t519 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 518
  store i64 -6704031159840385477, ptr %t519
  %t520 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 519
  store i64 8253128342678483706, ptr %t520
  %t521 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 520
  store i64 -3768352931373093942, ptr %t521
  %t522 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 521
  store i64 5704724409920716729, ptr %t522
  %t523 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 522
  store i64 -98755145788979524, ptr %t523
  %t524 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 523
  store i64 -2092466524453879896, ptr %t524
  %t525 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 524
  store i64 -6979250993759194058, ptr %t525
  %t526 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 525
  store i64 998051431430019017, ptr %t526
  %t527 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 526
  store i64 -4112377723771604669, ptr %t527
  %t528 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 527
  store i64 -7975807747567252037, ptr %t528
  %t529 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 528
  store i64 -528786136287117932, ptr %t529
  %t530 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 529
  store i64 8476984389250486570, ptr %t530
  %t531 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 530
  store i64 -7248020362820530564, ptr %t531
  %t532 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 531
  store i64 -3925256793573221702, ptr %t532
  %t533 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 532
  store i64 -4448339435098275301, ptr %t533
  %t534 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 533
  store i64 -294884973539139224, ptr %t534
  %t535 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 534
  store i64 -948738275445456222, ptr %t535
  %t536 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 535
  store i64 -368606216923924029, ptr %t536
  %t537 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 536
  store i64 -7510490449794491995, ptr %t537
  %t538 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 537
  store i64 -2536221894791146470, ptr %t538
  %t539 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 538
  store i64 -4776427043815727089, ptr %t539
  %t540 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 539
  store i64 6053094668365842720, ptr %t540
  %t541 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 540
  store i64 -1358847786342270957, ptr %t541
  %t542 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 541
  store i64 2954682317029915496, ptr %t542
  %t543 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 542
  store i64 -7766808894105001205, ptr %t543
  %t544 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 543
  store i64 -459166561069996767, ptr %t544
  %t545 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 544
  store i64 -5096825099203863602, ptr %t545
  %t546 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 545
  store i64 -573958201337495959, ptr %t546
  %t547 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 546
  store i64 -1759345355577441598, ptr %t547
  %t548 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 547
  store i64 -5329133770099257852, ptr %t548
  %t549 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 548
  store i64 -8017119874876982855, ptr %t549
  %t550 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 549
  store i64 -5636551615525730110, ptr %t550
  %t551 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 550
  store i64 -5409713825168840664, ptr %t551
  %t552 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 551
  store i64 2177682517447613171, ptr %t552
  %t553 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 552
  store i64 -2150456263033662926, ptr %t553
  %t554 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 553
  store i64 2722103146809516464, ptr %t554
  %t555 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 554
  store i64 -8261564192037121185, ptr %t555
  %t556 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 555
  store i64 6313000485183335694, ptr %t556
  %t557 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 556
  store i64 -5715269221619013577, ptr %t557
  %t558 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 557
  store i64 3279564588051781713, ptr %t558
  %t559 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 558
  store i64 -2532400508596379068, ptr %t559
  %t560 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 559
  store i64 -512230283362660763, ptr %t560
  %t561 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 560
  store i64 -8500279345513818773, ptr %t561
  %t562 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 561
  store i64 1985699082112030975, ptr %t562
  %t563 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 562
  store i64 -6013663163464885563, ptr %t563
  %t564 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 563
  store i64 -2129562165787349185, ptr %t564
  %t565 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 564
  store i64 -2905392935903719049, ptr %t565
  %t566 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 565
  store i64 6561419329620589327, ptr %t566
  %t567 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 566
  store i64 -8733399612580906262, ptr %t567
  %t568 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 567
  store i64 -7428327965055601431, ptr %t568
  %t569 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 568
  store i64 -6305063497298744923, ptr %t569
  %t570 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 569
  store i64 4549648098962661924, ptr %t570
  %t571 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 570
  store i64 -3269643353196043250, ptr %t571
  %t572 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 571
  store i64 -8147997931578836307, ptr %t572
  %t573 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 572
  store i64 -8961056123388608887, ptr %t573
  %t574 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 573
  store i64 1825030320404309164, ptr %t574
  %t575 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 574
  store i64 -6589634135808373205, ptr %t575
  %t576 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 575
  store i64 6892973918932774359, ptr %t576
  %t577 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 576
  store i64 -3625356651333078602, ptr %t577
  %t578 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 577
  store i64 4004531380238580045, ptr %t578
  %t579 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 578
  store i64 -9183376934724255983, ptr %t579
  %t580 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 579
  store i64 -2108853905778275376, ptr %t580
  %t581 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 580
  store i64 -6867535149977932074, ptr %t581
  %t582 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 581
  store i64 6587304654631931588, ptr %t582
  %t583 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 582
  store i64 -3972732919045027189, ptr %t583
  %t584 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 583
  store i64 -989241218564861323, ptr %t584
  %t585 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 584
  store i64 -354230130378896082, ptr %t585
  %t586 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 585
  store i64 -1236551523206076654, ptr %t586
  %t587 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 586
  store i64 -7138922859127891907, ptr %t587
  %t588 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 587
  store i64 6144684325637283947, ptr %t588
  %t589 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 588
  store i64 -4311967555482476980, ptr %t589
  %t590 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 589
  store i64 -6154202648235558778, ptr %t590
  %t591 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 590
  store i64 -778273425925708321, ptr %t591
  %t592 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 591
  store i64 -3081067291867060568, ptr %t592
  %t593 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 592
  store i64 -7403949918844649557, ptr %t593
  %t594 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 593
  store i64 -1925667057416912855, ptr %t594
  %t595 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 594
  store i64 -4643251380128424042, ptr %t595
  %t596 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 595
  store i64 -2407083821771141069, ptr %t596
  %t597 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 596
  store i64 -1192378206733142148, ptr %t597
  %t598 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 597
  store i64 -7620540795641314240, ptr %t598
  %t599 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 598
  store i64 -7662765406849295699, ptr %t599
  %t600 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 599
  store i64 -2456994988062127448, ptr %t600
  %t601 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 600
  store i64 -4966770740134231719, ptr %t601
  %t602 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 601
  store i64 6152128301777116498, ptr %t602
  %t603 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 602
  store i64 -1596777406740401745, ptr %t603
  %t604 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 603
  store i64 -6144897678060768090, ptr %t604
  %t605 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 604
  store i64 -7915514906853832947, ptr %t605
  %t606 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 605
  store i64 -3840561048787980056, ptr %t606
  %t607 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 606
  store i64 -5282707615139903279, ptr %t607
  %t608 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 607
  store i64 4422670725869800738, ptr %t608
  %t609 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 608
  store i64 -1991698500497491195, ptr %t609
  %t610 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 609
  store i64 -8306719647944912790, ptr %t610
  %t611 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 610
  store i64 -8162340590452013853, ptr %t611
  %t612 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 611
  store i64 8643358275316593218, ptr %t612
  %t613 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 612
  store i64 -5591239719637629412, ptr %t613
  %t614 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 613
  store i64 6192511825718353619, ptr %t614
  %t615 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 614
  store i64 -2377363631119648861, ptr %t615
  %t616 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 615
  store i64 7740639782147942024, ptr %t616
  %t617 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 616
  store i64 -8403381297090862394, ptr %t617
  %t618 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 617
  store i64 2532056854628769813, ptr %t618
  %t619 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 618
  store i64 -5892540602936190089, ptr %t619
  %t620 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 619
  store i64 -6058300968568813542, ptr %t620
  %t621 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 620
  store i64 -2753989735242849707, ptr %t621
  %t622 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 621
  store i64 -7572876210711016927, ptr %t622
  %t623 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 622
  store i64 -8638772612167862923, ptr %t623
  %t624 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 623
  store i64 9102010423587778132, ptr %t624
  %t625 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 624
  store i64 -6186779746782440750, ptr %t625
  %t626 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 625
  store i64 -2457545025797441047, ptr %t626
  %t627 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 626
  store i64 -3121788665050663033, ptr %t627
  %t628 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 627
  store i64 -7683617300674189212, ptr %t628
  %t629 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 628
  store i64 -8868646943297746252, ptr %t629
  %t630 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 629
  store i64 -4802260812921368258, ptr %t630
  %t631 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 630
  store i64 -6474122660694794911, ptr %t631
  %t632 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 631
  store i64 -1391139997724322418, ptr %t632
  %t633 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 632
  store i64 -3480967307441105734, ptr %t633
  %t634 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 633
  store i64 7484447039699372786, ptr %t634
  %t635 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 634
  store i64 -9093133594791772940, ptr %t635
  %t636 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 635
  store i64 -9157278655470055721, ptr %t636
  %t637 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 636
  store i64 -6754730975062328271, ptr %t637
  %t638 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 637
  store i64 -6834912300910181747, ptr %t638
  %t639 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 638
  store i64 -3831727700400522434, ptr %t639
  %t640 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 639
  store i64 679731660717048624, ptr %t640
  %t641 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 640
  store i64 -177973607073265139, ptr %t641
  %t642 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 641
  store i64 -8373707460958465028, ptr %t642
  %t643 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 642
  store i64 -7028762532061872568, ptr %t643
  %t644 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 643
  store i64 8601490892183123069, ptr %t644
  %t645 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 644
  store i64 -4174267146649952806, ptr %t645
  %t646 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 645
  store i64 -7694880458480647779, ptr %t646
  %t647 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 646
  store i64 -606147914885053103, ptr %t647
  %t648 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 647
  store i64 4216457482181353988, ptr %t648
  %t649 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 648
  store i64 -7296371474444240046, ptr %t649
  %t650 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 649
  store i64 -4282243101277735614, ptr %t650
  %t651 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 650
  store i64 -4508778324627912153, ptr %t651
  %t652 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 651
  store i64 8482254178684994195, ptr %t652
  %t653 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 652
  store i64 -1024286887357502287, ptr %t653
  %t654 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 653
  store i64 5991131704928854840, ptr %t654
  %t655 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 654
  store i64 -7557708332239520786, ptr %t655
  %t656 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 655
  store i64 -3173071712060547581, ptr %t656
  %t657 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 656
  store i64 -4835449396872013078, ptr %t657
  %t658 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 657
  store i64 -8578025658503072380, ptr %t658
  %t659 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 658
  store i64 -1432625727662628443, ptr %t659
  %t660 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 659
  store i64 3112525982153323237, ptr %t660
  %t661 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 660
  store i64 -7812920107430224633, ptr %t661
  %t662 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 661
  store i64 4251171748059520975, ptr %t662
  %t663 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 662
  store i64 -5154464115860392887, ptr %t663
  %t664 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 663
  store i64 702278666647013314, ptr %t664
  %t665 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 664
  store i64 -1831394126398103205, ptr %t665
  %t666 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 665
  store i64 5489534351736154547, ptr %t666
  %t667 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 666
  store i64 -8062150356639896359, ptr %t667
  %t668 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 667
  store i64 1125115960621402640, ptr %t668
  %t669 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 668
  store i64 -5466001927372482545, ptr %t669
  %t670 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 669
  store i64 6018080969204141204, ptr %t670
  %t671 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 670
  store i64 -2220816390788215277, ptr %t671
  %t672 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 671
  store i64 2910915193077788601, ptr %t672
  %t673 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 672
  store i64 -8305539271883716405, ptr %t673
  %t674 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 673
  store i64 -486521013540076077, ptr %t674
  %t675 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 674
  store i64 -5770238071427257602, ptr %t675
  %t676 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 675
  store i64 -608151266925095096, ptr %t676
  %t677 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 676
  store i64 -2601111570856684098, ptr %t677
  %t678 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 677
  store i64 -5371875102083756773, ptr %t678
  %t679 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 678
  store i64 -8543223759426509417, ptr %t679
  %t680 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 679
  store i64 3560107088838733872, ptr %t680
  %t681 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 680
  store i64 -6067343680855748868, ptr %t681
  %t682 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 681
  store i64 -161552157378970563, ptr %t682
  %t683 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 682
  store i64 -2972493582642298180, ptr %t683
  %t684 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 683
  store i64 4409745821703674700, ptr %t684
  %t685 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 684
  store i64 -8775337516792518219, ptr %t685
  %t686 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 685
  store i64 -6467280898289979121, ptr %t686
  %t687 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 686
  store i64 -6357485877563259869, ptr %t687
  %t688 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 687
  store i64 1139270913992301907, ptr %t688
  %t689 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 688
  store i64 -3335171328526686933, ptr %t689
  %t690 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 689
  store i64 -3187597375937010520, ptr %t690
  %t691 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 690
  store i64 -9002011107970261189, ptr %t691
  %t692 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 691
  store i64 7231123676894144233, ptr %t692
  %t693 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 692
  store i64 -6640827866535438582, ptr %t693
  %t694 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 693
  store i64 4427218577690292387, ptr %t694
  %t695 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 694
  store i64 -3689348814741910324, ptr %t695
  %t696 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 695
  store i64 -3689348814741910324, ptr %t696
  %t697 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 696
  store i64 -9223372036854775808, ptr %t697
  %t698 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 697
  store i64 0, ptr %t698
  %t699 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 698
  store i64 -6917529027641081856, ptr %t699
  %t700 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 699
  store i64 0, ptr %t700
  %t701 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 700
  store i64 -4035225266123964416, ptr %t701
  %t702 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 701
  store i64 0, ptr %t702
  %t703 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 702
  store i64 -432345564227567616, ptr %t703
  %t704 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 703
  store i64 0, ptr %t704
  %t705 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 704
  store i64 -7187745005283311616, ptr %t705
  %t706 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 705
  store i64 0, ptr %t706
  %t707 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 706
  store i64 -4372995238176751616, ptr %t707
  %t708 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 707
  store i64 0, ptr %t708
  %t709 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 708
  store i64 -854558029293551616, ptr %t709
  %t710 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 709
  store i64 0, ptr %t710
  %t711 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 710
  store i64 -7451627795949551616, ptr %t711
  %t712 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 711
  store i64 0, ptr %t712
  %t713 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 712
  store i64 -4702848726509551616, ptr %t713
  %t714 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 713
  store i64 0, ptr %t714
  %t715 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 714
  store i64 -1266874889709551616, ptr %t715
  %t716 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 715
  store i64 0, ptr %t716
  %t717 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 716
  store i64 -7709325833709551616, ptr %t717
  %t718 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 717
  store i64 0, ptr %t718
  %t719 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 718
  store i64 -5024971273709551616, ptr %t719
  %t720 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 719
  store i64 0, ptr %t720
  %t721 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 720
  store i64 -1669528073709551616, ptr %t721
  %t722 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 721
  store i64 0, ptr %t722
  %t723 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 722
  store i64 -7960984073709551616, ptr %t723
  %t724 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 723
  store i64 0, ptr %t724
  %t725 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 724
  store i64 -5339544073709551616, ptr %t725
  %t726 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 725
  store i64 0, ptr %t726
  %t727 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 726
  store i64 -2062744073709551616, ptr %t727
  %t728 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 727
  store i64 0, ptr %t728
  %t729 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 728
  store i64 -8206744073709551616, ptr %t729
  %t730 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 729
  store i64 0, ptr %t730
  %t731 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 730
  store i64 -5646744073709551616, ptr %t731
  %t732 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 731
  store i64 0, ptr %t732
  %t733 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 732
  store i64 -2446744073709551616, ptr %t733
  %t734 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 733
  store i64 0, ptr %t734
  %t735 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 734
  store i64 -8446744073709551616, ptr %t735
  %t736 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 735
  store i64 0, ptr %t736
  %t737 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 736
  store i64 -5946744073709551616, ptr %t737
  %t738 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 737
  store i64 0, ptr %t738
  %t739 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 738
  store i64 -2821744073709551616, ptr %t739
  %t740 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 739
  store i64 0, ptr %t740
  %t741 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 740
  store i64 -8681119073709551616, ptr %t741
  %t742 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 741
  store i64 0, ptr %t742
  %t743 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 742
  store i64 -6239712823709551616, ptr %t743
  %t744 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 743
  store i64 0, ptr %t744
  %t745 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 744
  store i64 -3187955011209551616, ptr %t745
  %t746 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 745
  store i64 0, ptr %t746
  %t747 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 746
  store i64 -8910000909647051616, ptr %t747
  %t748 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 747
  store i64 0, ptr %t748
  %t749 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 748
  store i64 -6525815118631426616, ptr %t749
  %t750 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 749
  store i64 0, ptr %t750
  %t751 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 750
  store i64 -3545582879861895366, ptr %t751
  %t752 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 751
  store i64 0, ptr %t752
  %t753 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 752
  store i64 -9133518327554766460, ptr %t753
  %t754 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 753
  store i64 4611686018427387904, ptr %t754
  %t755 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 754
  store i64 -6805211891016070171, ptr %t755
  %t756 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 755
  store i64 5764607523034234880, ptr %t756
  %t757 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 756
  store i64 -3894828845342699810, ptr %t757
  %t758 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 757
  store i64 -6629298651489370112, ptr %t758
  %t759 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 758
  store i64 -256850038250986858, ptr %t759
  %t760 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 759
  store i64 5548434740920451072, ptr %t760
  %t761 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 760
  store i64 -7078060301547948643, ptr %t761
  %t762 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 761
  store i64 -1143914305352105984, ptr %t762
  %t763 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 762
  store i64 -4235889358507547899, ptr %t763
  %t764 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 763
  store i64 7793479155164643328, ptr %t764
  %t765 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 764
  store i64 -683175679707046970, ptr %t765
  %t766 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 765
  store i64 -4093209111326359552, ptr %t766
  %t767 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 766
  store i64 -7344513827457986212, ptr %t767
  %t768 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 767
  store i64 4359273333062107136, ptr %t768
  %t769 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 768
  store i64 -4568956265895094861, ptr %t769
  %t770 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 769
  store i64 5449091666327633920, ptr %t770
  %t771 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 770
  store i64 -1099509313941480672, ptr %t771
  %t772 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 771
  store i64 2199678564482154496, ptr %t772
  %t773 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 772
  store i64 -7604722348854507276, ptr %t773
  %t774 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 773
  store i64 1374799102801346560, ptr %t774
  %t775 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 774
  store i64 -4894216917640746191, ptr %t775
  %t776 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 775
  store i64 1718498878501683200, ptr %t776
  %t777 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 776
  store i64 -1506085128623544835, ptr %t777
  %t778 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 777
  store i64 6759809616554491904, ptr %t778
  %t779 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 778
  store i64 -7858832233030797378, ptr %t779
  %t780 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 779
  store i64 6530724019560251392, ptr %t780
  %t781 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 780
  store i64 -5211854272861108819, ptr %t781
  %t782 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 781
  store i64 -1059967012404461568, ptr %t782
  %t783 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 782
  store i64 -1903131822648998119, ptr %t783
  %t784 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 783
  store i64 7898413271349198848, ptr %t784
  %t785 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 784
  store i64 -8106986416796705681, ptr %t785
  %t786 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 785
  store i64 -1981020733047832576, ptr %t786
  %t787 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 786
  store i64 -5522047002568494197, ptr %t787
  %t788 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 787
  store i64 -2476275916309790720, ptr %t788
  %t789 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 788
  store i64 -2290872734783229842, ptr %t789
  %t790 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 789
  store i64 -3095344895387238400, ptr %t790
  %t791 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 790
  store i64 -8349324486880600507, ptr %t791
  %t792 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 791
  store i64 4982938468024057856, ptr %t792
  %t793 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 792
  store i64 -5824969590173362730, ptr %t793
  %t794 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 793
  store i64 -7606384970252091392, ptr %t794
  %t795 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 794
  store i64 -2669525969289315508, ptr %t795
  %t796 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 795
  store i64 4327076842467049472, ptr %t796
  %t797 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 796
  store i64 -8585982758446904049, ptr %t797
  %t798 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 797
  store i64 -6518949010312869888, ptr %t798
  %t799 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 798
  store i64 -6120792429631242157, ptr %t799
  %t800 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 799
  store i64 -8148686262891087360, ptr %t800
  %t801 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 800
  store i64 -3039304518611664792, ptr %t801
  %t802 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 801
  store i64 8260886245095692416, ptr %t802
  %t803 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 802
  store i64 -8817094351773372351, ptr %t803
  %t804 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 803
  store i64 5163053903184807760, ptr %t804
  %t805 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 804
  store i64 -6409681921289327535, ptr %t805
  %t806 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 805
  store i64 -7381240676301154012, ptr %t806
  %t807 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 806
  store i64 -3400416383184271515, ptr %t807
  %t808 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 807
  store i64 -3178808521666707, ptr %t808
  %t809 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 808
  store i64 -9042789267131251553, ptr %t809
  %t810 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 809
  store i64 -4613672773753429596, ptr %t810
  %t811 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 810
  store i64 -6691800565486676537, ptr %t811
  %t812 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 811
  store i64 -5767090967191786995, ptr %t812
  %t813 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 812
  store i64 -3753064688430957767, ptr %t813
  %t814 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 813
  store i64 -7208863708989733744, ptr %t814
  %t815 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 814
  store i64 -79644842111309304, ptr %t815
  %t816 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 815
  store i64 212292400617608628, ptr %t816
  %t817 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 816
  store i64 -6967307053960650171, ptr %t817
  %t818 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 817
  store i64 132682750386005392, ptr %t818
  %t819 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 818
  store i64 -4097447799023424810, ptr %t819
  %t820 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 819
  store i64 4777539456409894645, ptr %t820
  %t821 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 820
  store i64 -510123730351893109, ptr %t821
  %t822 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 821
  store i64 -3251447716342407502, ptr %t822
  %t823 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 822
  store i64 -7236356359111015049, ptr %t823
  %t824 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 823
  store i64 7191217214140771119, ptr %t824
  %t825 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 824
  store i64 -4433759430461380907, ptr %t825
  %t826 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 825
  store i64 4377335499248575995, ptr %t826
  %t827 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 826
  store i64 -930513269649338230, ptr %t827
  %t828 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 827
  store i64 -8363388681221443718, ptr %t828
  %t829 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 828
  store i64 -7499099821171918250, ptr %t829
  %t830 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 829
  store i64 -7532960934977096276, ptr %t830
  %t831 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 830
  store i64 -4762188758037509908, ptr %t831
  %t832 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 831
  store i64 4418856886560793367, ptr %t832
  %t833 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 832
  store i64 -1341049929119499481, ptr %t833
  %t834 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 833
  store i64 5523571108200991709, ptr %t834
  %t835 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 834
  store i64 -7755685233340769032, ptr %t835
  %t836 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 835
  store i64 -8076983103442849942, ptr %t836
  %t837 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 836
  store i64 -5082920523248573386, ptr %t837
  %t838 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 837
  store i64 -5484542860876174524, ptr %t838
  %t839 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 838
  store i64 -1741964635633328828, ptr %t839
  %t840 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 839
  store i64 6979379479186945558, ptr %t840
  %t841 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 840
  store i64 -8006256924911912374, ptr %t841
  %t842 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 841
  store i64 -4861259862362934835, ptr %t842
  %t843 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 842
  store i64 -5396135137712502563, ptr %t843
  %t844 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 843
  store i64 7758483227328495169, ptr %t844
  %t845 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 844
  store i64 -2133482903713240300, ptr %t845
  %t846 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 845
  store i64 -4136954021121544751, ptr %t846
  %t847 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 846
  store i64 -8250955842461857044, ptr %t847
  %t848 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 847
  store i64 -279753253987271518, ptr %t848
  %t849 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 848
  store i64 -5702008784649933400, ptr %t849
  %t850 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 849
  store i64 4261994450943298507, ptr %t850
  %t851 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 850
  store i64 -2515824962385028846, ptr %t851
  %t852 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 851
  store i64 5327493063679123134, ptr %t852
  %t853 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 852
  store i64 -8489919629131724885, ptr %t853
  %t854 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 853
  store i64 7941369183226839863, ptr %t854
  %t855 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 854
  store i64 -6000713517987268202, ptr %t855
  %t856 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 855
  store i64 5315025460606161924, ptr %t856
  %t857 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 856
  store i64 -2889205879056697349, ptr %t857
  %t858 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 857
  store i64 -2579590211097073402, ptr %t858
  %t859 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 858
  store i64 -8723282702051517699, ptr %t859
  %t860 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 859
  store i64 7611128154919104931, ptr %t860
  %t861 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 860
  store i64 -6292417359137009220, ptr %t861
  %t862 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 861
  store i64 -4321147861633282548, ptr %t862
  %t863 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 862
  store i64 -3253835680493873621, ptr %t863
  %t864 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 863
  store i64 -789748808614215280, ptr %t864
  %t865 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 864
  store i64 -8951176327949752869, ptr %t865
  %t866 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 865
  store i64 8729779031470891258, ptr %t866
  %t867 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 866
  store i64 -6577284391509803182, ptr %t867
  %t868 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 867
  store i64 6300537770911226168, ptr %t868
  %t869 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 868
  store i64 -3609919470959866074, ptr %t869
  %t870 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 869
  store i64 -1347699823215743098, ptr %t870
  %t871 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 870
  store i64 -9173728696990998152, ptr %t871
  %t872 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 871
  store i64 6075216638131242420, ptr %t872
  %t873 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 872
  store i64 -6855474852811359786, ptr %t873
  %t874 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 873
  store i64 7594020797664053025, ptr %t874
  %t875 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 874
  store i64 -3957657547586811828, ptr %t875
  %t876 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 875
  store i64 269153960225290473, ptr %t876
  %t877 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 876
  store i64 -335385916056126881, ptr %t877
  %t878 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 877
  store i64 336442450281613091, ptr %t878
  %t879 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 878
  store i64 -7127145225176161157, ptr %t879
  %t880 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 879
  store i64 7127805559067090038, ptr %t880
  %t881 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 880
  store i64 -4297245513042813542, ptr %t881
  %t882 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 881
  store i64 4298070930406474644, ptr %t882
  %t883 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 882
  store i64 -759870872876129024, ptr %t883
  %t884 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 883
  store i64 -3850783373846682503, ptr %t884
  %t885 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 884
  store i64 -7392448323188662496, ptr %t885
  %t886 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 885
  store i64 9122475437414293195, ptr %t886
  %t887 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 886
  store i64 -4628874385558440216, ptr %t887
  %t888 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 887
  store i64 -7043649776941685122, ptr %t888
  %t889 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 888
  store i64 -1174406963520662366, ptr %t889
  %t890 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 889
  store i64 -4192876202749718498, ptr %t890
  %t891 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 890
  store i64 -7651533379841495835, ptr %t891
  %t892 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 891
  store i64 -4926390635932268014, ptr %t892
  %t893 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 892
  store i64 -4952730706374481889, ptr %t893
  %t894 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 893
  store i64 3065383741939440791, ptr %t894
  %t895 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 894
  store i64 -1579227364540714458, ptr %t895
  %t896 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 895
  store i64 -779956341003086915, ptr %t896
  %t897 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 896
  store i64 -7904546130479028392, ptr %t897
  %t898 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 897
  store i64 6430056314514152534, ptr %t898
  %t899 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 898
  store i64 -5268996644671397586, ptr %t899
  %t900 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 899
  store i64 8037570393142690668, ptr %t900
  %t901 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 900
  store i64 -1974559787411859078, ptr %t901
  %t902 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 901
  store i64 823590954573587527, ptr %t902
  %t903 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 902
  store i64 -8151628894773493780, ptr %t903
  %t904 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 903
  store i64 5126430365035880108, ptr %t904
  %t905 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 904
  store i64 -5577850100039479321, ptr %t905
  %t906 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 905
  store i64 6408037956294850135, ptr %t906
  %t907 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 906
  store i64 -2360626606621961247, ptr %t907
  %t908 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 907
  store i64 3398361426941174765, ptr %t908
  %t909 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 908
  store i64 -8392920656779807636, ptr %t909
  %t910 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 909
  store i64 -4793553135802847628, ptr %t910
  %t911 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 910
  store i64 -5879464802547371641, ptr %t911
  %t912 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 911
  store i64 -1380255401326171631, ptr %t912
  %t913 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 912
  store i64 -2737644984756826647, ptr %t913
  %t914 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 913
  store i64 -1725319251657714539, ptr %t914
  %t915 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 914
  store i64 -8628557143114098510, ptr %t915
  %t916 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 915
  store i64 3533361486141316317, ptr %t916
  %t917 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 916
  store i64 -6174010410465235234, ptr %t917
  %t918 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 917
  store i64 -4806670179178130411, ptr %t918
  %t919 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 918
  store i64 -3105826994654156138, ptr %t919
  %t920 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 919
  store i64 7826720331309500698, ptr %t920
  %t921 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 920
  store i64 -8858670899299929442, ptr %t921
  %t922 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 921
  store i64 280014188641050032, ptr %t922
  %t923 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 922
  store i64 -6461652605697523899, ptr %t923
  %t924 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 923
  store i64 -8873354301053463268, ptr %t924
  %t925 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 924
  store i64 -3465379738694516970, ptr %t925
  %t926 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 925
  store i64 -1868320839462053277, ptr %t926
  %t927 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 926
  store i64 -9083391364325154962, ptr %t927
  %t928 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 927
  store i64 5749828502977298558, ptr %t928
  %t929 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 928
  store i64 -6742553186979055799, ptr %t929
  %t930 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 929
  store i64 -2036086408133152611, ptr %t930
  %t931 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 930
  store i64 -3816505465296431844, ptr %t931
  %t932 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 931
  store i64 6678264026688335045, ptr %t932
  %t933 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 932
  store i64 -158945813193151901, ptr %t933
  %t934 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 933
  store i64 8347830033360418806, ptr %t934
  %t935 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 934
  store i64 -7016870160886801794, ptr %t935
  %t936 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 935
  store i64 2911550761636567802, ptr %t936
  %t937 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 936
  store i64 -4159401682681114339, ptr %t937
  %t938 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 937
  store i64 -5583933584809066056, ptr %t938
  %t939 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 938
  store i64 -587566084924005019, ptr %t939
  %t940 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 939
  store i64 2243455055843443238, ptr %t940
  %t941 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 940
  store i64 -7284757830718584993, ptr %t941
  %t942 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 941
  store i64 3708002419115845976, ptr %t942
  %t943 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 942
  store i64 -4494261269970843337, ptr %t943
  %t944 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 943
  store i64 23317005467419566, ptr %t944
  %t945 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 944
  store i64 -1006140569036166268, ptr %t945
  %t946 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 945
  store i64 -4582539761593113446, ptr %t946
  %t947 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 946
  store i64 -7546366883288685774, ptr %t947
  %t948 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 947
  store i64 -558244341782001952, ptr %t948
  %t949 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 948
  store i64 -4821272585683469313, ptr %t949
  %t950 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 949
  store i64 -5309491445654890344, ptr %t950
  %t951 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 950
  store i64 -1414904713676948737, ptr %t951
  %t952 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 951
  store i64 -6636864307068612930, ptr %t952
  %t953 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 952
  store i64 -7801844473689174817, ptr %t953
  %t954 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 953
  store i64 -4148040191917883081, ptr %t954
  %t955 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 954
  store i64 -5140619573684080617, ptr %t955
  %t956 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 955
  store i64 -5185050239897353852, ptr %t956
  %t957 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 956
  store i64 -1814088448677712867, ptr %t957
  %t958 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 957
  store i64 -6481312799871692315, ptr %t958
  %t959 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 958
  store i64 -8051334308064652398, ptr %t959
  %t960 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 959
  store i64 -8662506518347195601, ptr %t960
  %t961 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 960
  store i64 -5452481866653427593, ptr %t961
  %t962 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 961
  store i64 3006924907348169211, ptr %t962
  %t963 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 962
  store i64 -2203916314889396588, ptr %t963
  %t964 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 963
  store i64 -853029884242176390, ptr %t964
  %t965 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 964
  store i64 -8294976724446954723, ptr %t965
  %t966 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 965
  store i64 1772699331562333708, ptr %t966
  %t967 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 966
  store i64 -5757034887131305500, ptr %t967
  %t968 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 967
  store i64 6827560182880305039, ptr %t968
  %t969 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 968
  store i64 -2584607590486743971, ptr %t969
  %t970 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 969
  store i64 8534450228600381299, ptr %t970
  %t971 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 970
  store i64 -8532908771695296838, ptr %t971
  %t972 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 971
  store i64 7639874402088932264, ptr %t972
  %t973 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 972
  store i64 -6054449946191733143, ptr %t973
  %t974 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 973
  store i64 326470965756389522, ptr %t974
  %t975 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 974
  store i64 -2956376414312278525, ptr %t975
  %t976 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 975
  store i64 5019774725622874806, ptr %t976
  %t977 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 976
  store i64 -8765264286586255934, ptr %t977
  %t978 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 977
  store i64 831516194300602802, ptr %t978
  %t979 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 978
  store i64 -6344894339805432014, ptr %t979
  %t980 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 979
  store i64 -8183976793979022306, ptr %t980
  %t981 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 980
  store i64 -3319431906329402113, ptr %t981
  %t982 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 981
  store i64 3605087062808385830, ptr %t982
  %t983 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 982
  store i64 -8992173969096958177, ptr %t983
  %t984 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 983
  store i64 9170708441896323000, ptr %t984
  %t985 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 984
  store i64 -6628531442943809817, ptr %t985
  %t986 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 985
  store i64 6851699533943015846, ptr %t986
  %t987 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 986
  store i64 -3673978285252374367, ptr %t987
  %t988 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 987
  store i64 3952938399001381903, ptr %t988
  %t989 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 988
  store i64 -9213765455923815836, ptr %t989
  %t990 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 989
  store i64 -4446942528265218167, ptr %t990
  %t991 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 990
  store i64 -6905520801477381891, ptr %t991
  %t992 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 991
  store i64 -946992141904134804, ptr %t992
  %t993 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 992
  store i64 -4020214983419339459, ptr %t993
  %t994 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 993
  store i64 8039631859474607303, ptr %t994
  %t995 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 994
  store i64 -413582710846786420, ptr %t995
  %t996 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 995
  store i64 -3785518230938904583, ptr %t996
  %t997 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 996
  store i64 -7176018221920323369, ptr %t997
  %t998 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 997
  store i64 -60105885123121413, ptr %t998
  %t999 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 998
  store i64 -4358336758973016307, ptr %t999
  %t1000 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 999
  store i64 -75132356403901766, ptr %t1000
  %t1001 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1000
  store i64 -836234930288882479, ptr %t1001
  %t1002 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1001
  store i64 9129456591349898601, ptr %t1002
  %t1003 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1002
  store i64 -7440175859071633406, ptr %t1003
  %t1004 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1003
  store i64 -1211618658047395231, ptr %t1004
  %t1005 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1004
  store i64 -4688533805412153853, ptr %t1005
  %t1006 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1005
  store i64 -6126209340986631942, ptr %t1006
  %t1007 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1006
  store i64 -1248981238337804412, ptr %t1007
  %t1008 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1007
  store i64 -7657761676233289928, ptr %t1008
  %t1009 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1008
  store i64 -7698142301602209614, ptr %t1009
  %t1010 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1009
  store i64 -2480258038432112253, ptr %t1010
  %t1011 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1010
  store i64 -5010991858575374113, ptr %t1011
  %t1012 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1011
  store i64 -7712008566467528220, ptr %t1012
  %t1013 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1012
  store i64 -1652053804791829737, ptr %t1013
  %t1014 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1013
  store i64 8806733365625141341, ptr %t1014
  %t1015 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1014
  store i64 -7950062655635975442, ptr %t1015
  %t1016 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1015
  store i64 -6025006692552756422, ptr %t1016
  %t1017 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1016
  store i64 -5325892301117581398, ptr %t1017
  %t1018 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1017
  store i64 6303799689591218185, ptr %t1018
  %t1019 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1018
  store i64 -2045679357969588844, ptr %t1019
  %t1020 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1019
  store i64 -1343622424865753077, ptr %t1020
  %t1021 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1020
  store i64 -8196078626372074883, ptr %t1021
  %t1022 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1021
  store i64 1466078993672598279, ptr %t1022
  %t1023 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1022
  store i64 -5633412264537705700, ptr %t1023
  %t1024 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1023
  store i64 6444284760518135752, ptr %t1024
  %t1025 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1024
  store i64 -2430079312244744221, ptr %t1025
  %t1026 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1025
  store i64 8055355950647669691, ptr %t1026
  %t1027 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1026
  store i64 -8436328597794046994, ptr %t1027
  %t1028 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1027
  store i64 2728754459941099604, ptr %t1028
  %t1029 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1028
  store i64 -5933724728815170839, ptr %t1029
  %t1030 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1029
  store i64 -5812428961928401302, ptr %t1030
  %t1031 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1030
  store i64 -2805469892591575644, ptr %t1031
  %t1032 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1031
  store i64 1957835834444274180, ptr %t1032
  %t1033 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1032
  store i64 -8670947710510816634, ptr %t1033
  %t1034 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1033
  store i64 -7999724640327104446, ptr %t1034
  %t1035 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1034
  store i64 -6226998619711132888, ptr %t1035
  %t1036 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1035
  store i64 3835402254873283155, ptr %t1036
  %t1037 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1036
  store i64 -3172062256211528206, ptr %t1037
  %t1038 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1037
  store i64 4794252818591603944, ptr %t1038
  %t1039 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1038
  store i64 -8900067937773286985, ptr %t1039
  %t1040 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1039
  store i64 7608094030047140369, ptr %t1040
  %t1041 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1040
  store i64 -6513398903789220827, ptr %t1041
  %t1042 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1041
  store i64 4898431519131537557, ptr %t1042
  %t1043 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1042
  store i64 -3530062611309138130, ptr %t1043
  %t1044 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1043
  store i64 -7712018656367741765, ptr %t1044
  %t1045 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1044
  store i64 -9123818159709293187, ptr %t1045
  %t1046 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1045
  store i64 2097517367411243253, ptr %t1046
  %t1047 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1046
  store i64 -6793086681209228580, ptr %t1047
  %t1048 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1047
  store i64 7233582727691441970, ptr %t1048
  %t1049 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1048
  store i64 -3879672333084147821, ptr %t1049
  %t1050 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1049
  store i64 9041978409614302462, ptr %t1050
  %t1051 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1050
  store i64 -237904397927796872, ptr %t1051
  %t1052 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1051
  store i64 6690786993590490174, ptr %t1052
  %t1053 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1052
  store i64 -7066219276345954901, ptr %t1053
  %t1054 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1053
  store i64 4181741870994056359, ptr %t1054
  %t1055 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1054
  store i64 -4221088077005055722, ptr %t1055
  %t1056 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1055
  store i64 615491320315182544, ptr %t1056
  %t1057 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1056
  store i64 -664674077828931749, ptr %t1057
  %t1058 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1057
  store i64 -8454007886460797627, ptr %t1058
  %t1059 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1058
  store i64 -7332950326284164199, ptr %t1059
  %t1060 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1059
  store i64 3939617107816777291, ptr %t1060
  %t1061 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1060
  store i64 -4554501889427817345, ptr %t1061
  %t1062 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1061
  store i64 -8910536670511192099, ptr %t1062
  %t1063 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1062
  store i64 -1081441343357383777, ptr %t1063
  %t1064 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1063
  store i64 7308573235570561493, ptr %t1064
  %t1065 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1064
  store i64 -7593429867239446717, ptr %t1065
  %t1066 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1065
  store i64 -6961356773836868827, ptr %t1066
  %t1067 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1066
  store i64 -4880101315621920492, ptr %t1067
  %t1068 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1067
  store i64 -8701695967296086034, ptr %t1068
  %t1069 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1068
  store i64 -1488440626100012711, ptr %t1069
  %t1070 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1069
  store i64 -6265433940692719638, ptr %t1070
  %t1071 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1070
  store i64 -7847804418953589800, ptr %t1071
  %t1072 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1071
  store i64 695789805494438130, ptr %t1072
  %t1073 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1072
  store i64 -5198069505264599346, ptr %t1073
  %t1074 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1073
  store i64 869737256868047663, ptr %t1074
  %t1075 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1074
  store i64 -1885900863153361279, ptr %t1075
  %t1076 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1075
  store i64 -8136200465769716230, ptr %t1076
  %t1077 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1076
  store i64 -8096217067111932656, ptr %t1077
  %t1078 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1077
  store i64 -473439272678684740, ptr %t1078
  %t1079 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1078
  store i64 -5508585315462527915, ptr %t1079
  %t1080 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1079
  store i64 4019886927579031980, ptr %t1080
  %t1081 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1080
  store i64 -2274045625900771990, ptr %t1081
  %t1082 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1081
  store i64 -8810199395808373737, ptr %t1082
  %t1083 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1082
  store i64 -8338807543829064350, ptr %t1083
  %t1084 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1083
  store i64 -7812217631593927538, ptr %t1084
  %t1085 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1084
  store i64 -5811823411358942533, ptr %t1085
  %t1086 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1085
  store i64 4069786015789754290, ptr %t1086
  %t1087 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1086
  store i64 -2653093245771290262, ptr %t1087
  %t1088 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1087
  store i64 475546501309804958, ptr %t1088
  %t1089 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1088
  store i64 -8575712306248138270, ptr %t1089
  %t1090 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1089
  store i64 4908902581746016003, ptr %t1090
  %t1091 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1090
  store i64 -6107954364382784934, ptr %t1091
  %t1092 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1091
  store i64 -3087243809672255805, ptr %t1092
  %t1093 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1092
  store i64 -3023256937051093263, ptr %t1093
  %t1094 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1093
  store i64 -8470740780517707660, ptr %t1094
  %t1095 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1094
  store i64 -8807064613298015146, ptr %t1095
  %t1096 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1095
  store i64 -682526969396179383, ptr %t1096
  %t1097 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1096
  store i64 -6397144748195131028, ptr %t1097
  %t1098 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1097
  store i64 -5464844730172612133, ptr %t1098
  %t1099 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1098
  store i64 -3384744916816525881, ptr %t1099
  %t1100 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1099
  store i64 -2219369894288377262, ptr %t1100
  %t1101 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1100
  store i64 -9032994600651410532, ptr %t1101
  %t1102 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1101
  store i64 -1387106183930235789, ptr %t1102
  %t1103 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1102
  store i64 -6679557232386875260, ptr %t1103
  %t1104 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1103
  store i64 2877803288514593168, ptr %t1104
  %t1105 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1104
  store i64 -3737760522056206171, ptr %t1105
  %t1106 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1105
  store i64 3597254110643241460, ptr %t1106
  %t1107 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1106
  store i64 -60514634142869810, ptr %t1107
  %t1108 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1107
  store i64 9108253656731439729, ptr %t1108
  %t1109 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1108
  store i64 -6955350673980375487, ptr %t1109
  %t1110 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1109
  store i64 1080972517029761926, ptr %t1110
  %t1111 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1110
  store i64 -4082502324048081455, ptr %t1111
  %t1112 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1111
  store i64 5962901664714590312, ptr %t1112
  %t1113 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1112
  store i64 -491441886632713915, ptr %t1113
  %t1114 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1113
  store i64 -6381430974388925822, ptr %t1114
  %t1115 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1114
  store i64 -7224680206786528053, ptr %t1115
  %t1116 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1115
  store i64 -8600080377420466543, ptr %t1116
  %t1117 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1116
  store i64 -4419164240055772162, ptr %t1117
  %t1118 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1117
  store i64 7696643601933968437, ptr %t1118
  %t1119 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1118
  store i64 -912269281642327298, ptr %t1119
  %t1120 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1119
  store i64 397432465562684739, ptr %t1120
  %t1121 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1120
  store i64 -7487697328667536418, ptr %t1121
  %t1122 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1121
  store i64 -4363290727450709942, ptr %t1122
  %t1123 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1122
  store i64 -4747935642407032618, ptr %t1123
  %t1124 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1123
  store i64 8380944645968776284, ptr %t1124
  %t1125 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1124
  store i64 -1323233534581402868, ptr %t1125
  %t1126 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1125
  store i64 1252808770606194547, ptr %t1126
  %t1127 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1126
  store i64 -7744549986754458649, ptr %t1127
  %t1128 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1127
  store i64 -8440366555225904216, ptr %t1128
  %t1129 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1128
  store i64 -5069001465015685407, ptr %t1129
  %t1130 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1129
  store i64 7896285879677171346, ptr %t1130
  %t1131 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1130
  store i64 -1724565812842218855, ptr %t1131
  %t1132 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1131
  store i64 -3964700705685699529, ptr %t1132
  %t1133 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1132
  store i64 -7995382660667468640, ptr %t1133
  %t1134 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1133
  store i64 2133748077373825698, ptr %t1134
  %t1135 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1134
  store i64 -5382542307406947896, ptr %t1135
  %t1136 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1135
  store i64 2667185096717282123, ptr %t1136
  %t1137 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1136
  store i64 -2116491865831296966, ptr %t1137
  %t1138 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1137
  store i64 3333981370896602653, ptr %t1138
  %t1139 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1138
  store i64 -8240336443785642460, ptr %t1139
  %t1140 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1139
  store i64 6695424375237764562, ptr %t1140
  %t1141 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1140
  store i64 -5688734536304665171, ptr %t1141
  %t1142 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1141
  store i64 8369280469047205703, ptr %t1142
  %t1143 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1142
  store i64 -2499232151953443560, ptr %t1143
  %t1144 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1143
  store i64 -3373457468973156583, ptr %t1144
  %t1145 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1144
  store i64 -8479549122611984081, ptr %t1145
  %t1146 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1145
  store i64 -9025939945749304721, ptr %t1146
  %t1147 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1146
  store i64 -5987750384837592197, ptr %t1147
  %t1148 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1147
  store i64 7164319141522920715, ptr %t1148
  %t1149 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1148
  store i64 -2873001962619602342, ptr %t1149
  %t1150 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1149
  store i64 4343712908476262990, ptr %t1150
  %t1151 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1150
  store i64 -8713155254278333320, ptr %t1151
  %t1152 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1151
  store i64 7326506586225052273, ptr %t1152
  %t1153 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1152
  store i64 -6279758049420528746, ptr %t1153
  %t1154 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1153
  store i64 9158133232781315341, ptr %t1154
  %t1155 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1154
  store i64 -3238011543348273028, ptr %t1155
  %t1156 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1155
  store i64 2224294504121868368, ptr %t1156
  %t1157 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1156
  store i64 -8941286242233752499, ptr %t1157
  %t1158 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1157
  store i64 -7833187971778608078, ptr %t1158
  %t1159 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1158
  store i64 -6564921784364802720, ptr %t1159
  %t1160 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1159
  store i64 -568112927868484289, ptr %t1160
  %t1161 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1160
  store i64 -3594466212028615495, ptr %t1161
  %t1162 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1161
  store i64 3901544858591782542, ptr %t1162
  %t1163 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1162
  store i64 -9164070410158966541, ptr %t1163
  %t1164 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1163
  store i64 -4479063491021217767, ptr %t1164
  %t1165 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1164
  store i64 -6843401994271320272, ptr %t1165
  %t1166 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1165
  store i64 -5598829363776522209, ptr %t1166
  %t1167 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1166
  store i64 -3942566474411762436, ptr %t1167
  %t1168 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1167
  store i64 -2386850686293264857, ptr %t1168
  %t1169 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1168
  store i64 -316522074587315140, ptr %t1169
  %t1170 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1169
  store i64 1628122660560806833, ptr %t1170
  %t1171 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1170
  store i64 -7115355324258153819, ptr %t1171
  %t1172 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1171
  store i64 -8205795374004271538, ptr %t1172
  %t1173 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1172
  store i64 -4282508136895304370, ptr %t1173
  %t1174 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1173
  store i64 -1033872180650563614, ptr %t1174
  %t1175 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1174
  store i64 -741449152691742558, ptr %t1175
  %t1176 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1175
  store i64 -5904026244240592421, ptr %t1176
  %t1177 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1176
  store i64 -7380934748073420955, ptr %t1177
  %t1178 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1177
  store i64 -5995859411864064215, ptr %t1178
  %t1179 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1178
  store i64 -4614482416664388289, ptr %t1179
  %t1180 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1179
  store i64 1728547772024695539, ptr %t1180
  %t1181 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1180
  store i64 -1156417002403097458, ptr %t1181
  %t1182 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1181
  store i64 -2451001303396518480, ptr %t1182
  %t1183 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1182
  store i64 -7640289654143017767, ptr %t1183
  %t1184 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1183
  store i64 5385653213018257806, ptr %t1184
  %t1185 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1184
  store i64 -4938676049251384305, ptr %t1185
  %t1186 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1185
  store i64 -7102991539009341455, ptr %t1186
  %t1187 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1186
  store i64 -1561659043136842477, ptr %t1187
  %t1188 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1187
  store i64 -8878739423761676819, ptr %t1188
  %t1189 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1188
  store i64 -7893565929601608404, ptr %t1189
  %t1190 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1189
  store i64 3674159897003727796, ptr %t1190
  %t1191 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1190
  store i64 -5255271393574622601, ptr %t1191
  %t1192 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1191
  store i64 4592699871254659745, ptr %t1192
  %t1193 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1192
  store i64 -1957403223540890347, ptr %t1193
  %t1194 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1193
  store i64 1129188820640936778, ptr %t1194
  %t1195 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1194
  store i64 -8140906042354138323, ptr %t1195
  %t1196 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1195
  store i64 3011586022114279438, ptr %t1196
  %t1197 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1196
  store i64 -5564446534515285000, ptr %t1197
  %t1198 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1197
  store i64 8376168546070237202, ptr %t1198
  %t1199 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1198
  store i64 -2343872149716718346, ptr %t1199
  %t1200 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1199
  store i64 -7976533391121755114, ptr %t1200
  %t1201 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1200
  store i64 -8382449121214030822, ptr %t1201
  %t1202 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1201
  store i64 1932195658189984910, ptr %t1202
  %t1203 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1202
  store i64 -5866375383090150624, ptr %t1203
  %t1204 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1203
  store i64 -6808127464117294671, ptr %t1204
  %t1205 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1204
  store i64 -2721283210435300376, ptr %t1205
  %t1206 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1205
  store i64 -3898473311719230434, ptr %t1206
  %t1207 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1206
  store i64 -8618331034163144591, ptr %t1207
  %t1208 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1207
  store i64 9092669226243950738, ptr %t1208
  %t1209 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1208
  store i64 -6161227774276542835, ptr %t1209
  %t1210 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1209
  store i64 -2469221522477225289, ptr %t1210
  %t1211 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1210
  store i64 -3089848699418290639, ptr %t1211
  %t1212 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1211
  store i64 6136845133758244197, ptr %t1212
  %t1213 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1212
  store i64 -8848684464777513506, ptr %t1213
  %t1214 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1213
  store i64 -3082000819042179233, ptr %t1214
  %t1215 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1214
  store i64 -6449169562544503978, ptr %t1215
  %t1216 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1215
  store i64 -8464187042230111945, ptr %t1216
  %t1217 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1216
  store i64 -3449775934753242068, ptr %t1217
  %t1218 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1217
  store i64 3254824252494523781, ptr %t1218
  %t1219 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1218
  store i64 -9073638986861858149, ptr %t1219
  %t1220 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1219
  store i64 -7189106879045698445, ptr %t1220
  %t1221 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1220
  store i64 -6730362715149934782, ptr %t1221
  %t1222 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1221
  store i64 -8986383598807123057, ptr %t1222
  %t1223 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1222
  store i64 -3801267375510030573, ptr %t1223
  %t1224 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1223
  store i64 2602078556773259891, ptr %t1224
  %t1225 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1224
  store i64 -139898200960150313, ptr %t1225
  %t1226 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1225
  store i64 -1359087822460813040, ptr %t1226
  %t1227 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1226
  store i64 -7004965403241175802, ptr %t1227
  %t1228 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1227
  store i64 -849429889038008150, ptr %t1228
  %t1229 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1228
  store i64 -4144520735624081848, ptr %t1229
  %t1230 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1229
  store i64 -5673473379724898091, ptr %t1230
  %t1231 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1230
  store i64 -568964901102714406, ptr %t1231
  %t1232 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1231
  store i64 -2480155706228734710, ptr %t1232
  %t1233 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1232
  store i64 -7273132090830278360, ptr %t1233
  %t1234 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1233
  store i64 -3855940325606653146, ptr %t1234
  %t1235 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1234
  store i64 -4479729095110460046, ptr %t1235
  %t1236 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1235
  store i64 -208239388580928528, ptr %t1236
  %t1237 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1236
  store i64 -987975350460687153, ptr %t1237
  %t1238 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1237
  store i64 -4871985254153548564, ptr %t1238
  %t1239 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1238
  store i64 -7535013621679011327, ptr %t1239
  %t1240 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1239
  store i64 -3044990783845967853, ptr %t1240
  %t1241 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1240
  store i64 -4807081008671376254, ptr %t1241
  %t1242 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1241
  store i64 5417133557047315992, ptr %t1242
  %t1243 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1242
  store i64 -1397165242411832414, ptr %t1243
  %t1244 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1243
  store i64 -2451955090545630818, ptr %t1244
  %t1245 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1244
  store i64 -7790757304148477115, ptr %t1245
  %t1246 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1245
  store i64 -3838314940804713213, ptr %t1246
  %t1247 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1246
  store i64 -5126760611758208489, ptr %t1247
  %t1248 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1247
  store i64 4425478360848884291, ptr %t1248
  %t1249 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1248
  store i64 -1796764746270372707, ptr %t1249
  %t1250 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1249
  store i64 920161932633717460, ptr %t1250
  %t1251 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1250
  store i64 -8040506994060064798, ptr %t1251
  %t1252 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1251
  store i64 2880944217109767365, ptr %t1252
  %t1253 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1252
  store i64 -5438947724147693094, ptr %t1253
  %t1254 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1253
  store i64 -5622191765467566602, ptr %t1254
  %t1255 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1254
  store i64 -2186998636757228463, ptr %t1255
  %t1256 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1255
  store i64 6807318348447705459, ptr %t1256
  %t1257 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1256
  store i64 -8284403175614349646, ptr %t1257
  %t1258 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1257
  store i64 -2662955059861265944, ptr %t1258
  %t1259 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1258
  store i64 -5743817951090549153, ptr %t1259
  %t1260 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1259
  store i64 -7940379843253970334, ptr %t1260
  %t1261 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1260
  store i64 -2568086420435798537, ptr %t1261
  %t1262 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1261
  store i64 8521269269642088699, ptr %t1262
  %t1263 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1262
  store i64 -8522583040413455942, ptr %t1263
  %t1264 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1263
  store i64 -6203421752542164323, ptr %t1264
  %t1265 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1264
  store i64 -6041542782089432023, ptr %t1265
  %t1266 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1265
  store i64 6080780864604458308, ptr %t1266
  %t1267 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1266
  store i64 -2940242459184402125, ptr %t1267
  %t1268 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1267
  store i64 -6234081974526590827, ptr %t1268
  %t1269 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1268
  store i64 -8755180564631333184, ptr %t1269
  %t1270 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1269
  store i64 5327070802775656541, ptr %t1270
  %t1271 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1270
  store i64 -6332289687361778576, ptr %t1271
  %t1272 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1271
  store i64 6658838503469570676, ptr %t1272
  %t1273 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1272
  store i64 -3303676090774835316, ptr %t1273
  %t1274 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1273
  store i64 8323548129336963345, ptr %t1274
  %t1275 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1274
  store i64 -8982326584375353929, ptr %t1275
  %t1276 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1275
  store i64 -4021154456019173717, ptr %t1276
  %t1277 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1276
  store i64 -6616222212041804507, ptr %t1277
  %t1278 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1277
  store i64 -5026443070023967147, ptr %t1278
  %t1279 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1278
  store i64 -3658591746624867729, ptr %t1279
  %t1280 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1279
  store i64 2940318199324816875, ptr %t1280
  %t1281 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1280
  store i64 -9204148869281624187, ptr %t1281
  %t1282 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1281
  store i64 8755227902219092403, ptr %t1282
  %t1283 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1282
  store i64 -6893500068174642330, ptr %t1283
  %t1284 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1283
  store i64 -2891023177508298209, ptr %t1284
  %t1285 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1284
  store i64 -4005189066790915008, ptr %t1285
  %t1286 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1285
  store i64 -8225464990312760665, ptr %t1286
  %t1287 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1286
  store i64 -394800315061255856, ptr %t1287
  %t1288 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1287
  store i64 -5670145219463562927, ptr %t1288
  %t1289 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1288
  store i64 -7164279224554366766, ptr %t1289
  %t1290 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1289
  store i64 7985374283903742931, ptr %t1290
  %t1291 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1290
  store i64 -4343663012265570553, ptr %t1291
  %t1292 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1291
  store i64 758345818024902856, ptr %t1292
  %t1293 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1292
  store i64 -817892746904575288, ptr %t1293
  %t1294 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1293
  store i64 -3663753745896259334, ptr %t1294
  %t1295 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1294
  store i64 -7428711994456441411, ptr %t1295
  %t1296 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1295
  store i64 -9207375118826243940, ptr %t1296
  %t1297 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1296
  store i64 -4674203974643163860, ptr %t1297
  %t1298 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1297
  store i64 -2285846861678029117, ptr %t1298
  %t1299 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1298
  store i64 -1231068949876566920, ptr %t1299
  %t1300 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1299
  store i64 1754377441329851508, ptr %t1300
  %t1301 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1300
  store i64 -7686947121313936181, ptr %t1301
  %t1302 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1301
  store i64 1096485900831157192, ptr %t1302
  %t1303 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1302
  store i64 -4996997883215032323, ptr %t1303
  %t1304 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1303
  store i64 -3241078642388441414, ptr %t1304
  %t1305 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1304
  store i64 -1634561335591402499, ptr %t1305
  %t1306 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1305
  store i64 5172023733869224041, ptr %t1306
  %t1307 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1306
  store i64 -7939129862385708418, ptr %t1307
  %t1308 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1307
  store i64 5538357842881958977, ptr %t1308
  %t1309 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1308
  store i64 -5312226309554747619, ptr %t1309
  %t1310 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1309
  store i64 -2300424733252327086, ptr %t1310
  %t1311 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1310
  store i64 -2028596868516046619, ptr %t1311
  %t1312 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1311
  store i64 6347841120289366950, ptr %t1312
  %t1313 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1312
  store i64 -8185402070463610993, ptr %t1313
  %t1314 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1313
  store i64 6273243709394548296, ptr %t1314
  %t1315 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1314
  store i64 -5620066569652125837, ptr %t1315
  %t1316 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1315
  store i64 3229868618315797466, ptr %t1316
  %t1317 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1316
  store i64 -2413397193637769393, ptr %t1317
  %t1318 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1317
  store i64 -574350245532641071, ptr %t1318
  %t1319 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1318
  store i64 -8425902273664687727, ptr %t1319
  %t1320 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1319
  store i64 -358968903457900670, ptr %t1320
  %t1321 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1320
  store i64 -5920691823653471754, ptr %t1321
  %t1322 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1321
  store i64 8774660907532399971, ptr %t1322
  %t1323 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1322
  store i64 -2789178761139451788, ptr %t1323
  %t1324 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1323
  store i64 1744954097560724156, ptr %t1324
  %t1325 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1324
  store i64 -8660765753353239224, ptr %t1325
  %t1326 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1325
  store i64 -8132775725879323211, ptr %t1326
  %t1327 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1326
  store i64 -6214271173264161126, ptr %t1327
  %t1328 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1327
  store i64 -5554283638921766110, ptr %t1328
  %t1329 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1328
  store i64 -3156152948152813503, ptr %t1329
  %t1330 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1329
  store i64 6892203506629956075, ptr %t1330
  %t1331 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1330
  store i64 -8890124620236590296, ptr %t1331
  %t1332 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1331
  store i64 -2609901835997359309, ptr %t1332
  %t1333 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1332
  store i64 -6500969756868349965, ptr %t1333
  %t1334 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1333
  store i64 1349308723430688768, ptr %t1334
  %t1335 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1334
  store i64 -3514526177658049553, ptr %t1335
  %t1336 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1335
  store i64 -2925050114139026944, ptr %t1336
  %t1337 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1336
  store i64 -9114107888677362827, ptr %t1337
  %t1338 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1337
  store i64 -1828156321336891840, ptr %t1338
  %t1339 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1338
  store i64 -6780948842419315629, ptr %t1339
  %t1340 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1339
  store i64 6938176635183661008, ptr %t1340
  %t1341 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1340
  store i64 -3864500034596756632, ptr %t1341
  %t1342 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1341
  store i64 4061034775552188356, ptr %t1342
  %t1343 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1342
  store i64 -218939024818557886, ptr %t1343
  %t1344 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1343
  store i64 5076293469440235445, ptr %t1344
  %t1345 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1344
  store i64 -7054365918152680535, ptr %t1345
  %t1346 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1345
  store i64 7784369436827535057, ptr %t1346
  %t1347 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1346
  store i64 -4206271379263462765, ptr %t1347
  %t1348 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1347
  store i64 -4104596259247744891, ptr %t1348
  %t1349 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1348
  store i64 -646153205651940552, ptr %t1349
  %t1350 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1349
  store i64 -5130745324059681113, ptr %t1350
  %t1351 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1350
  store i64 -7321374781173544701, ptr %t1351
  %t1352 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1351
  store i64 8322499218531169064, ptr %t1352
  %t1353 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1352
  store i64 -4540032458039542972, ptr %t1353
  %t1354 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1353
  store i64 5791438004736573426, ptr %t1354
  %t1355 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1354
  store i64 -1063354554122040811, ptr %t1355
  %t1356 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1355
  store i64 7239297505920716783, ptr %t1356
  %t1357 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1356
  store i64 -7582125623967357363, ptr %t1357
  %t1358 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1357
  store i64 6830403950414141941, ptr %t1358
  %t1359 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1358
  store i64 -4865971011531808800, ptr %t1359
  %t1360 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1359
  store i64 -5297053117264486286, ptr %t1360
  %t1361 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1360
  store i64 -1470777745987373096, ptr %t1361
  %t1362 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1361
  store i64 -2009630378153219953, ptr %t1362
  %t1363 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1362
  store i64 -7836765118883190041, ptr %t1363
  %t1364 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1363
  store i64 -8173548013986844327, ptr %t1364
  %t1365 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1364
  store i64 -5184270380176599647, ptr %t1365
  %t1366 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1365
  store i64 8229809056225996208, ptr %t1366
  %t1367 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1366
  store i64 -1868651956793361655, ptr %t1367
  %t1368 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1367
  store i64 -3547796734999668452, ptr %t1368
  %t1369 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1368
  store i64 -8085436500636932890, ptr %t1369
  %t1370 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1369
  store i64 2394313059052595121, ptr %t1370
  %t1371 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1370
  store i64 -5495109607368778209, ptr %t1371
  %t1372 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1371
  store i64 -6230480713039031907, ptr %t1372
  %t1373 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1372
  store i64 -2257200990783584857, ptr %t1373
  %t1374 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1373
  store i64 -7788100891298789883, ptr %t1374
  %t1375 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1374
  store i64 -8328279646880822392, ptr %t1375
  %t1376 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1375
  store i64 -4867563057061743677, ptr %t1376
  %t1377 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1376
  store i64 -5798663540173640086, ptr %t1377
  %t1378 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1377
  store i64 -1472767802899791692, ptr %t1378
  %t1379 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1378
  store i64 -2636643406789662203, ptr %t1379
  %t1380 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1379
  store i64 -6452645772052127519, ptr %t1380
  %t1381 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1380
  store i64 -8565431156884620733, ptr %t1381
  %t1382 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1381
  store i64 -8644589625959967604, ptr %t1382
  %t1383 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1382
  store i64 -6095102927678388012, ptr %t1383
  %t1384 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1383
  store i64 7641007041259592112, ptr %t1384
  %t1385 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1384
  store i64 -3007192641170597111, ptr %t1385
  %t1386 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1385
  store i64 -8895485272135061476, ptr %t1386
  %t1387 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1386
  store i64 -8797024428372705051, ptr %t1387
  %t1388 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1387
  store i64 -947992276657025519, ptr %t1388
  %t1389 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1388
  store i64 -6384594517038493409, ptr %t1389
  %t1390 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1389
  store i64 8038381691033493909, ptr %t1390
  %t1391 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1390
  store i64 -3369057127870728857, ptr %t1391
  %t1392 = getelementptr [1392 x i64], ptr %l0, i64 0, i64 1391
  store i64 5436291095364479483, ptr %t1392
  %t1393 = load [1392 x i64], ptr %l0
  %t1394 = load ptr, ptr @__olang_prog_scope
  %t1395 = call ptr @__olang_scope_alloc(ptr %t1394, i64 11136)
  store [1392 x i64] %t1393, ptr %t1395
  %t1396 = insertvalue { i64, ptr } undef, i64 1392, 0
  %t1397 = insertvalue { i64, ptr } %t1396, ptr %t1395, 1
  store { i64, ptr } %t1397, ptr %l1, !tbaa !27
  %t1398 = load { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2epow10Mant, !tbaa !27
  %t1399 = extractvalue { i64, ptr } %t1398, 0
  store i64 %t1399, ptr %l2, !tbaa !24
  %t1400 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t1401 = extractvalue { i64, ptr } %t1400, 0
  store i64 %t1401, ptr %l3, !tbaa !24
  %t1402 = load i64, ptr %l2, !tbaa !24
  %t1403 = load i64, ptr %l3, !tbaa !24
  %t1404 = icmp eq i64 %t1402, %t1403
  store i1 %t1404, ptr %l4, !tbaa !21
  %t1405 = load i1, ptr %l4, !tbaa !21
  br i1 %t1405, label %bb1, label %bb2
bb1:
  %t1406 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2epow10Mant, i32 0, i32 1
  %t1407 = load ptr, ptr %t1406, !tbaa !27
  %t1408 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t1409 = load ptr, ptr %t1408, !tbaa !27
  %t1410 = load i64, ptr %l3, !tbaa !24
  %t1411 = mul i64 %t1410, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1407, ptr %t1409, i64 %t1411, i1 false)
  br label %bb3
bb2:
  %t1412 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1412, ptr @G_2estd_2fprelude_2ftext_2epow10Mant, !tbaa !27
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i8
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i8
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca i8
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i8
  %l76 = alloca i8
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i8
  %l90 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i32
  %l98 = alloca i8
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i1
  %l103 = alloca i32
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i1
  %l109 = alloca i1
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i1
  %l117 = alloca i32
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l18, !tbaa !24
  %t2 = load i64, ptr %l18, !tbaa !24
  store i64 %t2, ptr %l19, !tbaa !24
  %t3 = load i64, ptr %l19, !tbaa !24
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l20, !tbaa !24
  %t5 = load i64, ptr %l20, !tbaa !24
  store i64 %t5, ptr %l21, !tbaa !24
  %t6 = load i64, ptr %l21, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l22, !tbaa !21
  %t8 = load i1, ptr %l22, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 10, ptr %l3, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l23, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t10)
  store i1 %t11, ptr %l24
  br label %bb3
bb2:
  br label %bb13
bb3:
  %t12 = load i1, ptr %l24, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l25, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 1
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l26, !tbaa !22
  %t18 = load i8, ptr %l26, !tbaa !22
  %t19 = icmp eq i8 %t18, 120
  store i1 %t19, ptr %l27, !tbaa !21
  %t20 = load i1, ptr %l27, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb5:
  br label %bb12
bb6:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb8
bb7:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t21, ptr %l29, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 1
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l30, !tbaa !22
  %t26 = load i8, ptr %l30, !tbaa !22
  %t27 = icmp eq i8 %t26, 88
  store i1 %t27, ptr %l31, !tbaa !21
  %t28 = load i1, ptr %l31, !tbaa !21
  store i1 %t28, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l28, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i64 16, ptr %l32, !tbaa !24
  br label %bb11
bb10:
  store i64 2, ptr %l32, !tbaa !24
  br label %bb11
bb11:
  %t30 = load i64, ptr %l32, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l33, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t32, ptr %l34, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l35, !tbaa !24
  %t35 = load i64, ptr %l33, !tbaa !24
  %t36 = load i64, ptr %l35, !tbaa !24
  %t37 = icmp eq i64 %t35, %t36
  store i1 %t37, ptr %l36, !tbaa !21
  %t38 = load i1, ptr %l36, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  store i32 65537, ptr %l37, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l37, !tbaa !23
  %t40 = insertvalue { i32, i64 } zeroinitializer, i32 %t39, 0
  store { i32, i64 } %t40, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t41 = load i64, ptr %l3, !tbaa !24
  store i64 %t41, ptr %l38, !tbaa !24
  %t42 = load i64, ptr %l38, !tbaa !24
  store i64 %t42, ptr %l39, !tbaa !65
  %t43 = load i64, ptr %l39, !tbaa !65
  store i64 %t43, ptr %l5, !tbaa !65
  %t44 = load i64, ptr %l2, !tbaa !65
  store i64 %t44, ptr %l40, !tbaa !65
  %t45 = load i64, ptr %l5, !tbaa !65
  store i64 %t45, ptr %l41, !tbaa !65
  %t46 = load i64, ptr %l40, !tbaa !65
  %t47 = load i64, ptr %l41, !tbaa !65
  %t48 = udiv i64 %t46, %t47
  store i64 %t48, ptr %l42, !tbaa !65
  %t49 = load i64, ptr %l42, !tbaa !65
  store i64 %t49, ptr %l6, !tbaa !65
  %t50 = load i64, ptr %l2, !tbaa !65
  store i64 %t50, ptr %l43, !tbaa !65
  %t51 = load i64, ptr %l5, !tbaa !65
  store i64 %t51, ptr %l44, !tbaa !65
  %t52 = load i64, ptr %l43, !tbaa !65
  %t53 = load i64, ptr %l44, !tbaa !65
  %t54 = urem i64 %t52, %t53
  store i64 %t54, ptr %l45, !tbaa !65
  %t55 = load i64, ptr %l45, !tbaa !65
  store i64 %t55, ptr %l7, !tbaa !65
  store i64 0, ptr %l8, !tbaa !65
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l4, !tbaa !24
  store i64 %t56, ptr %l46, !tbaa !24
  %t57 = load i64, ptr %l46, !tbaa !24
  store i64 %t57, ptr %l9, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t58, ptr %l47, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l48, !tbaa !24
  %t61 = load i64, ptr %l48, !tbaa !24
  store i64 %t61, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t62 = load i64, ptr %l10, !tbaa !24
  store i64 %t62, ptr %l49, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  store i64 %t63, ptr %l50, !tbaa !24
  %t64 = load i64, ptr %l49, !tbaa !24
  %t65 = load i64, ptr %l50, !tbaa !24
  %t66 = icmp sgt i64 %t64, %t65
  store i1 %t66, ptr %l51, !tbaa !21
  %t67 = load i1, ptr %l51, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  %t68 = load i64, ptr %l11, !tbaa !24
  store i64 %t68, ptr %l53, !tbaa !24
  %t69 = load i64, ptr %l53, !tbaa !24
  %t70 = icmp sgt i64 %t69, 0
  store i1 %t70, ptr %l54, !tbaa !21
  %t71 = load i1, ptr %l54, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb22
bb19:
  %t72 = load i64, ptr %l10, !tbaa !24
  store i64 %t72, ptr %l56, !tbaa !24
  %t73 = load i64, ptr %l9, !tbaa !24
  store i64 %t73, ptr %l57, !tbaa !24
  %t74 = load i64, ptr %l56, !tbaa !24
  %t75 = load i64, ptr %l57, !tbaa !24
  %t76 = sub i64 %t74, %t75
  store i64 %t76, ptr %l58, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  store i64 %t77, ptr %l59, !tbaa !24
  %t78 = load i64, ptr %l58, !tbaa !24
  %t79 = load i64, ptr %l59, !tbaa !24
  %t80 = add i64 %t78, %t79
  store i64 %t80, ptr %l60, !tbaa !24
  %t81 = load i64, ptr %l60, !tbaa !24
  %t82 = sub i64 %t81, 1
  store i64 %t82, ptr %l61, !tbaa !24
  %t83 = load i64, ptr %l11, !tbaa !24
  store i64 %t83, ptr %l62, !tbaa !24
  %t84 = load i64, ptr %l61, !tbaa !24
  %t85 = load i64, ptr %l62, !tbaa !24
  %t86 = sdiv i64 %t84, %t85
  store i64 %t86, ptr %l63, !tbaa !24
  %t87 = load i64, ptr %l63, !tbaa !24
  store i64 %t87, ptr %l55, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb21
bb21:
  %t88 = load i64, ptr %l55, !tbaa !24
  store i64 %t88, ptr %l52, !tbaa !24
  br label %bb22
bb22:
  %t89 = load i64, ptr %l52, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load i64, ptr %l13, !tbaa !24
  store i64 %t90, ptr %l64, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  store i64 %t91, ptr %l65, !tbaa !24
  %t92 = load i64, ptr %l64, !tbaa !24
  %t93 = load i64, ptr %l65, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  store i1 %t94, ptr %l66, !tbaa !21
  %t95 = load i1, ptr %l66, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l67, !tbaa !21
  %t97 = load i1, ptr %l67, !tbaa !21
  br i1 %t97, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb56
bb25:
  br label %bb26
bb26:
  %t98 = load i64, ptr %l9, !tbaa !24
  store i64 %t98, ptr %l68, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  store i64 %t99, ptr %l69, !tbaa !24
  %t100 = load i64, ptr %l11, !tbaa !24
  store i64 %t100, ptr %l70, !tbaa !24
  %t101 = load i64, ptr %l69, !tbaa !24
  %t102 = load i64, ptr %l70, !tbaa !24
  %t103 = mul i64 %t101, %t102
  store i64 %t103, ptr %l71, !tbaa !24
  %t104 = load i64, ptr %l68, !tbaa !24
  %t105 = load i64, ptr %l71, !tbaa !24
  %t106 = add i64 %t104, %t105
  store i64 %t106, ptr %l72, !tbaa !24
  %t107 = load i64, ptr %l72, !tbaa !24
  store i64 %t107, ptr %l14, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t108, ptr %l73, !tbaa !27
  %t109 = load i64, ptr %l14, !tbaa !24
  store i64 %t109, ptr %l74, !tbaa !24
  %t110 = load i64, ptr %l74, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i8, ptr %t112, i64 %t110
  %t114 = load i8, ptr %t113, !tbaa !32
  store i8 %t114, ptr %l75, !tbaa !22
  %t115 = load i8, ptr %l75, !tbaa !22
  store i8 %t115, ptr %l15, !tbaa !22
  %t116 = load i8, ptr %l15, !tbaa !22
  store i8 %t116, ptr %l76, !tbaa !22
  %t117 = load i8, ptr %l76, !tbaa !22
  %t118 = icmp eq i8 %t117, 95
  store i1 %t118, ptr %l77, !tbaa !21
  %t119 = load i1, ptr %l77, !tbaa !21
  br i1 %t119, label %bb27, label %bb28
bb27:
  %t120 = load i64, ptr %l1, !tbaa !24
  store i64 %t120, ptr %l79, !tbaa !24
  %t121 = load i64, ptr %l79, !tbaa !24
  store i64 %t121, ptr %l80, !tbaa !24
  %t122 = load i64, ptr %l80, !tbaa !24
  %t123 = icmp eq i64 %t122, 0
  store i1 %t123, ptr %l81, !tbaa !21
  %t124 = load i1, ptr %l81, !tbaa !21
  store i1 %t124, ptr %l78, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb29
bb29:
  %t125 = load i1, ptr %l78, !tbaa !21
  br i1 %t125, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t126 = load i64, ptr %l14, !tbaa !24
  store i64 %t126, ptr %l82, !tbaa !24
  %t127 = load i64, ptr %l4, !tbaa !24
  store i64 %t127, ptr %l83, !tbaa !24
  %t128 = load i64, ptr %l82, !tbaa !24
  %t129 = load i64, ptr %l83, !tbaa !24
  %t130 = icmp eq i64 %t128, %t129
  store i1 %t130, ptr %l84, !tbaa !21
  %t131 = load i1, ptr %l84, !tbaa !21
  br i1 %t131, label %bb32, label %bb33
bb31:
  br label %bb41
bb32:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb34
bb33:
  %t132 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t132, ptr %l86, !tbaa !27
  %t133 = load i64, ptr %l14, !tbaa !24
  store i64 %t133, ptr %l87, !tbaa !24
  %t134 = load i64, ptr %l87, !tbaa !24
  %t135 = sub i64 %t134, 1
  store i64 %t135, ptr %l88, !tbaa !24
  %t136 = load i64, ptr %l88, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t136
  %t140 = load i8, ptr %t139, !tbaa !32
  store i8 %t140, ptr %l89, !tbaa !22
  %t141 = load i8, ptr %l89, !tbaa !22
  %t142 = icmp eq i8 %t141, 95
  store i1 %t142, ptr %l90, !tbaa !21
  %t143 = load i1, ptr %l90, !tbaa !21
  store i1 %t143, ptr %l85, !tbaa !21
  br label %bb34
bb34:
  %t144 = load i1, ptr %l85, !tbaa !21
  br i1 %t144, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb37
bb36:
  %t145 = load i64, ptr %l14, !tbaa !24
  store i64 %t145, ptr %l92, !tbaa !24
  %t146 = load i64, ptr %l92, !tbaa !24
  %t147 = add i64 %t146, 1
  store i64 %t147, ptr %l93, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t148, ptr %l94, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  store i64 %t150, ptr %l95, !tbaa !24
  %t151 = load i64, ptr %l93, !tbaa !24
  %t152 = load i64, ptr %l95, !tbaa !24
  %t153 = icmp eq i64 %t151, %t152
  store i1 %t153, ptr %l96, !tbaa !21
  %t154 = load i1, ptr %l96, !tbaa !21
  store i1 %t154, ptr %l91, !tbaa !21
  br label %bb37
bb37:
  %t155 = load i1, ptr %l91, !tbaa !21
  br i1 %t155, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 65537, ptr %l97, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t156 = load i32, ptr %l97, !tbaa !23
  %t157 = insertvalue { i32, i64 } zeroinitializer, i32 %t156, 0
  store { i32, i64 } %t157, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb41:
  %t158 = load i8, ptr %l15, !tbaa !22
  store i8 %t158, ptr %l98, !tbaa !22
  %t159 = load i8, ptr %l98, !tbaa !22
  %t160 = call i64 @std_2fprelude_2ftext_2edigitWorth(i8 %t159)
  store i64 %t160, ptr %l99
  br label %bb42
bb42:
  %t161 = load i64, ptr %l99, !tbaa !24
  store i64 %t161, ptr %l16, !tbaa !24
  %t162 = load i64, ptr %l16, !tbaa !24
  store i64 %t162, ptr %l100, !tbaa !24
  %t163 = load i64, ptr %l3, !tbaa !24
  store i64 %t163, ptr %l101, !tbaa !24
  %t164 = load i64, ptr %l100, !tbaa !24
  %t165 = load i64, ptr %l101, !tbaa !24
  %t166 = icmp sge i64 %t164, %t165
  store i1 %t166, ptr %l102, !tbaa !21
  %t167 = load i1, ptr %l102, !tbaa !21
  br i1 %t167, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65537, ptr %l103, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t168 = load i32, ptr %l103, !tbaa !23
  %t169 = insertvalue { i32, i64 } zeroinitializer, i32 %t168, 0
  store { i32, i64 } %t169, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t170 = load i64, ptr %l16, !tbaa !24
  store i64 %t170, ptr %l104, !tbaa !24
  %t171 = load i64, ptr %l104, !tbaa !24
  store i64 %t171, ptr %l105, !tbaa !65
  %t172 = load i64, ptr %l105, !tbaa !65
  store i64 %t172, ptr %l17, !tbaa !65
  %t173 = load i64, ptr %l8, !tbaa !65
  store i64 %t173, ptr %l106, !tbaa !65
  %t174 = load i64, ptr %l6, !tbaa !65
  store i64 %t174, ptr %l107, !tbaa !65
  %t175 = load i64, ptr %l106, !tbaa !65
  %t176 = load i64, ptr %l107, !tbaa !65
  %t177 = icmp ugt i64 %t175, %t176
  store i1 %t177, ptr %l108, !tbaa !21
  %t178 = load i1, ptr %l108, !tbaa !21
  br i1 %t178, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb51
bb47:
  %t179 = load i64, ptr %l8, !tbaa !65
  store i64 %t179, ptr %l110, !tbaa !65
  %t180 = load i64, ptr %l6, !tbaa !65
  store i64 %t180, ptr %l111, !tbaa !65
  %t181 = load i64, ptr %l110, !tbaa !65
  %t182 = load i64, ptr %l111, !tbaa !65
  %t183 = icmp eq i64 %t181, %t182
  store i1 %t183, ptr %l112, !tbaa !21
  %t184 = load i1, ptr %l112, !tbaa !21
  br i1 %t184, label %bb48, label %bb49
bb48:
  %t185 = load i64, ptr %l17, !tbaa !65
  store i64 %t185, ptr %l114, !tbaa !65
  %t186 = load i64, ptr %l7, !tbaa !65
  store i64 %t186, ptr %l115, !tbaa !65
  %t187 = load i64, ptr %l114, !tbaa !65
  %t188 = load i64, ptr %l115, !tbaa !65
  %t189 = icmp ugt i64 %t187, %t188
  store i1 %t189, ptr %l116, !tbaa !21
  %t190 = load i1, ptr %l116, !tbaa !21
  store i1 %t190, ptr %l113, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb50
bb50:
  %t191 = load i1, ptr %l113, !tbaa !21
  store i1 %t191, ptr %l109, !tbaa !21
  br label %bb51
bb51:
  %t192 = load i1, ptr %l109, !tbaa !21
  br i1 %t192, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s9
  store i32 65538, ptr %l117, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t193 = load i32, ptr %l117, !tbaa !23
  %t194 = insertvalue { i32, i64 } zeroinitializer, i32 %t193, 0
  store { i32, i64 } %t194, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t195 = load i64, ptr %l8, !tbaa !65
  store i64 %t195, ptr %l118, !tbaa !65
  %t196 = load i64, ptr %l5, !tbaa !65
  store i64 %t196, ptr %l119, !tbaa !65
  %t197 = load i64, ptr %l118, !tbaa !65
  %t198 = load i64, ptr %l119, !tbaa !65
  %t199 = mul i64 %t197, %t198
  store i64 %t199, ptr %l120, !tbaa !65
  %t200 = load i64, ptr %l17, !tbaa !65
  store i64 %t200, ptr %l121, !tbaa !65
  %t201 = load i64, ptr %l120, !tbaa !65
  %t202 = load i64, ptr %l121, !tbaa !65
  %t203 = add i64 %t201, %t202
  store i64 %t203, ptr %l122, !tbaa !65
  %t204 = load i64, ptr %l122, !tbaa !65
  store i64 %t204, ptr %l8, !tbaa !65
  call void @__olang_scope_close(ptr %s5)
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t205 = load i64, ptr %l13, !tbaa !24
  store i64 %t205, ptr %l123, !tbaa !24
  %t206 = load i64, ptr %l123, !tbaa !24
  %t207 = add i64 %t206, 1
  store i64 %t207, ptr %l124, !tbaa !24
  %t208 = load i64, ptr %l124, !tbaa !24
  store i64 %t208, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb23
bb56:
  call void @__olang_scope_close(ptr %s4)
  %t209 = load i64, ptr %l8, !tbaa !65
  store i64 %t209, ptr %l125, !tbaa !65
  call void @__olang_scope_close(ptr %s0)
  %t210 = load i64, ptr %l125, !tbaa !65
  %t211 = insertvalue { i32, i64 } zeroinitializer, i64 %t210, 1
  store { i32, i64 } %t211, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i8
  %l24 = alloca i8
  %l25 = alloca i8
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l9, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l10, !tbaa !24
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = icmp ne i64 %t7, %t8
  store i1 %t9, ptr %l11, !tbaa !21
  %t10 = load i1, ptr %l11, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l12, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l13, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l15, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  store i64 %t19, ptr %l17, !tbaa !24
  %t20 = load i64, ptr %l16, !tbaa !24
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  store i1 %t22, ptr %l18, !tbaa !21
  %t23 = load i1, ptr %l18, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l19, !tbaa !21
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load i64, ptr %l20, !tbaa !24
  store i64 %t27, ptr %l5, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t28, ptr %l21, !tbaa !27
  %t29 = load i64, ptr %l3, !tbaa !24
  store i64 %t29, ptr %l22, !tbaa !24
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i8, ptr %t32, i64 %t30
  %t34 = load i8, ptr %t33, !tbaa !32
  store i8 %t34, ptr %l23, !tbaa !22
  %t35 = load i8, ptr %l23, !tbaa !22
  store i8 %t35, ptr %l6, !tbaa !22
  %t36 = load i8, ptr %l6, !tbaa !22
  store i8 %t36, ptr %l24, !tbaa !22
  %t37 = load i8, ptr %l24, !tbaa !22
  %t38 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t37)
  store i8 %t38, ptr %l25
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t39, ptr %l26, !tbaa !27
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load i64, ptr %l27, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i8, ptr %t43, i64 %t41
  %t45 = load i8, ptr %t44, !tbaa !32
  store i8 %t45, ptr %l28, !tbaa !22
  %t46 = load i8, ptr %l25, !tbaa !22
  %t47 = load i8, ptr %l28, !tbaa !22
  %t48 = icmp ne i8 %t46, %t47
  store i1 %t48, ptr %l29, !tbaa !21
  %t49 = load i1, ptr %l29, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l30, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i1, ptr %l30, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t51 = load i64, ptr %l3, !tbaa !24
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l31, !tbaa !24
  %t53 = add i64 %t52, 1
  store i64 %t53, ptr %l32, !tbaa !24
  %t54 = load i64, ptr %l32, !tbaa !24
  store i64 %t54, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb4
bb13:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %l33, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i1, ptr %l33, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %a0, i1 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca %"std/prelude/text:decimal"
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:decimal"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca double
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, double }
  store { i64, ptr } %a0, ptr %l0
  store i1 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:decimal" @std_2fprelude_2ftext_3adecimal_2ector(ptr %s0)
  store %"std/prelude/text:decimal" %t1, ptr %l4
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:decimal", ptr %l4
  store %"std/prelude/text:decimal" %t2, ptr %l2
  store ptr %l2, ptr %l5, !tbaa !29
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l6, !tbaa !27
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eset(ptr %s0, ptr %v0, ptr %t4, { i64, ptr } %t5)
  br label %bb2
bb2:
  store ptr %l2, ptr %l8, !tbaa !29
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2ebits(ptr %s0, ptr %t6)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l10
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb4, label %ok.11
ok.11:
  store i64 %t8, ptr %l9
  br label %bb3
bb3:
  %t12 = load i64, ptr %l9, !tbaa !65
  store i64 %t12, ptr %l7, !tbaa !65
  br label %bb5
bb4:
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  store i32 %t21, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l11, !tbaa !23
  %t23 = insertvalue { i32, double } zeroinitializer, i32 %t22, 0
  store { i32, double } %t23, ptr %rv
  br label %ret
bb5:
  %t24 = load i64, ptr %l7, !tbaa !65
  store i64 %t24, ptr %l3, !tbaa !65
  %t25 = load i1, ptr %l1, !tbaa !21
  store i1 %t25, ptr %l12, !tbaa !21
  %t26 = load i1, ptr %l12, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load i64, ptr %l3, !tbaa !65
  store i64 %t27, ptr %l13, !tbaa !65
  %t28 = shl i64 1, 63
  store i64 %t28, ptr %l14, !tbaa !65
  %t29 = load i64, ptr %l13, !tbaa !65
  %t30 = load i64, ptr %l14, !tbaa !65
  %t31 = or i64 %t29, %t30
  store i64 %t31, ptr %l15, !tbaa !65
  %t32 = load i64, ptr %l15, !tbaa !65
  store i64 %t32, ptr %l3, !tbaa !65
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t33 = load i64, ptr %l3, !tbaa !65
  store i64 %t33, ptr %l16, !tbaa !65
  %t34 = load i64, ptr %l16, !tbaa !65
  %t35 = bitcast i64 %t34 to double
  store double %t35, ptr %l17, !tbaa !26
  call void @__olang_scope_close(ptr %s0)
  %t36 = load double, ptr %l17, !tbaa !26
  %t37 = insertvalue { i32, double } zeroinitializer, double %t36, 1
  store { i32, double } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp uge i8 %t2, 48
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = icmp ule i8 %t6, 57
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t2)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t6)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp uge i8 %t2, 97
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = icmp ule i8 %t6, 122
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp uge i8 %t2, 65
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = icmp ule i8 %t6, 90
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i1, ptr %l3, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i8
  %l6 = alloca i8
  %s0 = alloca %olang.scope
  %rv = alloca i8
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t2)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = add i8 %t6, 32
  store i8 %t7, ptr %l5, !tbaa !22
  %t8 = load i8, ptr %l5, !tbaa !22
  store i8 %t8, ptr %l3, !tbaa !22
  br label %bb4
bb3:
  %t9 = load i8, ptr %l0, !tbaa !22
  store i8 %t9, ptr %l6, !tbaa !22
  %t10 = load i8, ptr %l6, !tbaa !22
  store i8 %t10, ptr %l3, !tbaa !22
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i8, ptr %l3, !tbaa !22
  store i8 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i8
  %l6 = alloca i8
  %s0 = alloca %olang.scope
  %rv = alloca i8
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t2)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l4, !tbaa !22
  %t6 = load i8, ptr %l4, !tbaa !22
  %t7 = sub i8 %t6, 32
  store i8 %t7, ptr %l5, !tbaa !22
  %t8 = load i8, ptr %l5, !tbaa !22
  store i8 %t8, ptr %l3, !tbaa !22
  br label %bb4
bb3:
  %t9 = load i8, ptr %l0, !tbaa !22
  store i8 %t9, ptr %l6, !tbaa !22
  %t10 = load i8, ptr %l6, !tbaa !22
  store i8 %t10, ptr %l3, !tbaa !22
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i8, ptr %l3, !tbaa !22
  store i8 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i8
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i8
  %l46 = alloca i1
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:LineIter", ptr %t2, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = getelementptr %"std/prelude/text:LineIter", ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l7, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l8, !tbaa !21
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t15, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l10, !tbaa !29
  %t18 = load ptr, ptr %l10, !tbaa !29
  %t19 = getelementptr %"std/prelude/text:LineIter", ptr %t18, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l11, !tbaa !24
  store i64 %t21, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l1, !tbaa !24
  store i64 %t22, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l12, !tbaa !24
  store i64 %t23, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load i64, ptr %l2, !tbaa !24
  store i64 %t24, ptr %l13, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = getelementptr %"std/prelude/text:LineIter", ptr %t26, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l15, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l16, !tbaa !24
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l17, !tbaa !21
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb5, label %bb6
bb5:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = getelementptr %"std/prelude/text:LineIter", ptr %t36, i32 0, i32 0
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l20, !tbaa !27
  %t39 = load i64, ptr %l2, !tbaa !24
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l21, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr i8, ptr %t42, i64 %t40
  %t44 = load i8, ptr %t43, !tbaa !32
  store i8 %t44, ptr %l22, !tbaa !22
  %t45 = load i8, ptr %l22, !tbaa !22
  %t46 = icmp ne i8 %t45, 10
  store i1 %t46, ptr %l23, !tbaa !21
  %t47 = load i1, ptr %l23, !tbaa !21
  store i1 %t47, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t48 = load i1, ptr %l18, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l24, !tbaa !21
  %t50 = load i1, ptr %l24, !tbaa !21
  br i1 %t50, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t51 = load i64, ptr %l2, !tbaa !24
  store i64 %t51, ptr %l25, !tbaa !24
  %t52 = load i64, ptr %l25, !tbaa !24
  %t53 = add i64 %t52, 1
  store i64 %t53, ptr %l26, !tbaa !24
  %t54 = load i64, ptr %l26, !tbaa !24
  store i64 %t54, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb4
bb12:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l27, !tbaa !29
  %t56 = load i64, ptr %l2, !tbaa !24
  store i64 %t56, ptr %l28, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l29, !tbaa !29
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = getelementptr %"std/prelude/text:LineIter", ptr %t58, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l30, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l31, !tbaa !24
  %t63 = load i64, ptr %l28, !tbaa !24
  %t64 = load i64, ptr %l31, !tbaa !24
  %t65 = icmp slt i64 %t63, %t64
  store i1 %t65, ptr %l32, !tbaa !21
  %t66 = load i1, ptr %l32, !tbaa !21
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t67 = load i64, ptr %l2, !tbaa !24
  store i64 %t67, ptr %l34, !tbaa !24
  %t68 = load i64, ptr %l34, !tbaa !24
  %t69 = add i64 %t68, 1
  store i64 %t69, ptr %l35, !tbaa !24
  %t70 = load i64, ptr %l35, !tbaa !24
  store i64 %t70, ptr %l33, !tbaa !24
  br label %bb15
bb14:
  %t71 = load i64, ptr %l2, !tbaa !24
  store i64 %t71, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l36, !tbaa !24
  store i64 %t72, ptr %l33, !tbaa !24
  br label %bb15
bb15:
  %t73 = load i64, ptr %l33, !tbaa !24
  %t74 = load ptr, ptr %l27, !tbaa !29
  %t75 = getelementptr %"std/prelude/text:LineIter", ptr %t74, i32 0, i32 1
  store i64 %t73, ptr %t75, !tbaa !24
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %l37, !tbaa !24
  %t77 = load i64, ptr %l1, !tbaa !24
  store i64 %t77, ptr %l38, !tbaa !24
  %t78 = load i64, ptr %l37, !tbaa !24
  %t79 = load i64, ptr %l38, !tbaa !24
  %t80 = icmp sgt i64 %t78, %t79
  store i1 %t80, ptr %l39, !tbaa !21
  %t81 = load i1, ptr %l39, !tbaa !21
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l41, !tbaa !29
  %t83 = load ptr, ptr %l41, !tbaa !29
  %t84 = getelementptr %"std/prelude/text:LineIter", ptr %t83, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  store { i64, ptr } %t85, ptr %l42, !tbaa !27
  %t86 = load i64, ptr %l2, !tbaa !24
  store i64 %t86, ptr %l43, !tbaa !24
  %t87 = load i64, ptr %l43, !tbaa !24
  %t88 = sub i64 %t87, 1
  store i64 %t88, ptr %l44, !tbaa !24
  %t89 = load i64, ptr %l44, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t89
  %t93 = load i8, ptr %t92, !tbaa !32
  store i8 %t93, ptr %l45, !tbaa !22
  %t94 = load i8, ptr %l45, !tbaa !22
  %t95 = icmp eq i8 %t94, 13
  store i1 %t95, ptr %l46, !tbaa !21
  %t96 = load i1, ptr %l46, !tbaa !21
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t97 = load i1, ptr %l40, !tbaa !21
  br i1 %t97, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l47, !tbaa !24
  %t99 = load i64, ptr %l47, !tbaa !24
  %t100 = sub i64 %t99, 1
  store i64 %t100, ptr %l48, !tbaa !24
  %t101 = load i64, ptr %l48, !tbaa !24
  store i64 %t101, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l49, !tbaa !29
  %t103 = load ptr, ptr %l49, !tbaa !29
  %t104 = getelementptr %"std/prelude/text:LineIter", ptr %t103, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l50, !tbaa !27
  %t106 = load i64, ptr %l1, !tbaa !24
  store i64 %t106, ptr %l51, !tbaa !24
  %t107 = load i64, ptr %l2, !tbaa !24
  store i64 %t107, ptr %l52, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l53, !tbaa !24
  %t110 = load i64, ptr %l51, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  store i1 %t111, ptr %l54, !tbaa !21
  %t112 = load i1, ptr %l54, !tbaa !21
  br i1 %t112, label %bb22, label %bb23
bb22:
  %t113 = load i64, ptr %l51, !tbaa !24
  %t114 = load i64, ptr %l52, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  store i1 %t115, ptr %l55, !tbaa !21
  %t116 = load i1, ptr %l55, !tbaa !21
  br i1 %t116, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb24:
  %t117 = load i64, ptr %l52, !tbaa !24
  %t118 = load i64, ptr %l53, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  store i1 %t119, ptr %l56, !tbaa !21
  %t120 = load i1, ptr %l56, !tbaa !21
  br i1 %t120, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb26:
  %t121 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = load i64, ptr %l51, !tbaa !24
  %t124 = load i64, ptr %l52, !tbaa !24
  %t125 = getelementptr i8, ptr %t122, i64 %t123
  %t126 = sub i64 %t124, %t123
  %t127 = insertvalue { i64, ptr } undef, i64 %t126, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t125, 1
  store { i64, ptr } %t128, ptr %l57, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t129 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t130 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t129, 1
  store { i32, { i64, ptr } } %t130, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:StringBuilder", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:StringBuilder", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H19b8985d31946b3485fef8ba31e677f6(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i8
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:StringBuilder", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i8, ptr %l1, !tbaa !22
  store i8 %t4, ptr %l4, !tbaa !22
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i8, ptr %l4, !tbaa !22
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %t5, i8 %t6)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:StringBuilder", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eTo_Hb8acb615cfdcbcf79972fa4c281da350(ptr %v0, ptr %v1, ptr %t4)
  store { i64, ptr } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i8
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i8
  %l48 = alloca i1
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i8
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i8
  %l56 = alloca i1
  %l57 = alloca i32
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i32
  %l72 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l9, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l10, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t5, ptr %l11, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l12, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l13, !tbaa !24
  %t9 = load i64, ptr %l12, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l14, !tbaa !21
  %t12 = load i1, ptr %l14, !tbaa !21
  br i1 %t12, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l15, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l16, !tbaa !24
  %t16 = load i64, ptr %l16, !tbaa !24
  store i64 %t16, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb3
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %l17, !tbaa !24
  %t18 = load i64, ptr %l17, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  store i64 %t19, ptr %l18, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  store i64 %t20, ptr %l19, !tbaa !24
  %t21 = load i64, ptr %l18, !tbaa !24
  %t22 = load i64, ptr %l19, !tbaa !24
  %t23 = icmp sgt i64 %t21, %t22
  store i1 %t23, ptr %l20, !tbaa !21
  %t24 = load i1, ptr %l20, !tbaa !21
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %l22, !tbaa !24
  %t26 = load i64, ptr %l22, !tbaa !24
  %t27 = icmp sgt i64 %t26, 0
  store i1 %t27, ptr %l23, !tbaa !21
  %t28 = load i1, ptr %l23, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb6:
  %t29 = load i64, ptr %l4, !tbaa !24
  store i64 %t29, ptr %l25, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l26, !tbaa !24
  %t31 = load i64, ptr %l25, !tbaa !24
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = sub i64 %t31, %t32
  store i64 %t33, ptr %l27, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  store i64 %t34, ptr %l28, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t36 = load i64, ptr %l28, !tbaa !24
  %t37 = add i64 %t35, %t36
  store i64 %t37, ptr %l29, !tbaa !24
  %t38 = load i64, ptr %l29, !tbaa !24
  %t39 = sub i64 %t38, 1
  store i64 %t39, ptr %l30, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l31, !tbaa !24
  %t41 = load i64, ptr %l30, !tbaa !24
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = sdiv i64 %t41, %t42
  store i64 %t43, ptr %l32, !tbaa !24
  %t44 = load i64, ptr %l32, !tbaa !24
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t45 = load i64, ptr %l24, !tbaa !24
  store i64 %t45, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l21, !tbaa !24
  store i64 %t46, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load i64, ptr %l7, !tbaa !24
  store i64 %t47, ptr %l33, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  store i64 %t48, ptr %l34, !tbaa !24
  %t49 = load i64, ptr %l33, !tbaa !24
  %t50 = load i64, ptr %l34, !tbaa !24
  %t51 = icmp slt i64 %t49, %t50
  store i1 %t51, ptr %l35, !tbaa !21
  %t52 = load i1, ptr %l35, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l36, !tbaa !21
  %t54 = load i1, ptr %l36, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb12:
  br label %bb13
bb13:
  %t55 = load i64, ptr %l3, !tbaa !24
  store i64 %t55, ptr %l37, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l38, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  store i64 %t57, ptr %l39, !tbaa !24
  %t58 = load i64, ptr %l38, !tbaa !24
  %t59 = load i64, ptr %l39, !tbaa !24
  %t60 = mul i64 %t58, %t59
  store i64 %t60, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l37, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = add i64 %t61, %t62
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load i64, ptr %l41, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t65, ptr %l42, !tbaa !27
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l43, !tbaa !24
  %t67 = load i64, ptr %l43, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 %t67
  %t71 = load i8, ptr %t70, !tbaa !32
  store i8 %t71, ptr %l44, !tbaa !22
  %t72 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t72, ptr %l45, !tbaa !27
  %t73 = load i64, ptr %l8, !tbaa !24
  store i64 %t73, ptr %l46, !tbaa !24
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t74
  %t78 = load i8, ptr %t77, !tbaa !32
  store i8 %t78, ptr %l47, !tbaa !22
  %t79 = load i8, ptr %l44, !tbaa !22
  %t80 = load i8, ptr %l47, !tbaa !22
  %t81 = icmp ult i8 %t79, %t80
  store i1 %t81, ptr %l48, !tbaa !21
  %t82 = load i1, ptr %l48, !tbaa !21
  br i1 %t82, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store i32 -1, ptr %l49, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t83 = load i32, ptr %l49, !tbaa !23
  store i32 %t83, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t84 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t84, ptr %l50, !tbaa !27
  %t85 = load i64, ptr %l8, !tbaa !24
  store i64 %t85, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l51, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i8, ptr %t88, i64 %t86
  %t90 = load i8, ptr %t89, !tbaa !32
  store i8 %t90, ptr %l52, !tbaa !22
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l53, !tbaa !27
  %t92 = load i64, ptr %l8, !tbaa !24
  store i64 %t92, ptr %l54, !tbaa !24
  %t93 = load i64, ptr %l54, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr i8, ptr %t95, i64 %t93
  %t97 = load i8, ptr %t96, !tbaa !32
  store i8 %t97, ptr %l55, !tbaa !22
  %t98 = load i8, ptr %l52, !tbaa !22
  %t99 = load i8, ptr %l55, !tbaa !22
  %t100 = icmp ugt i8 %t98, %t99
  store i1 %t100, ptr %l56, !tbaa !21
  %t101 = load i1, ptr %l56, !tbaa !21
  br i1 %t101, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  store i32 1, ptr %l57, !tbaa !23
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load i32, ptr %l57, !tbaa !23
  store i32 %t102, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t103 = load i64, ptr %l7, !tbaa !24
  store i64 %t103, ptr %l58, !tbaa !24
  %t104 = load i64, ptr %l58, !tbaa !24
  %t105 = add i64 %t104, 1
  store i64 %t105, ptr %l59, !tbaa !24
  %t106 = load i64, ptr %l59, !tbaa !24
  store i64 %t106, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb10
bb21:
  call void @__olang_scope_close(ptr %s2)
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l61, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t110, ptr %l62, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  store i64 %t112, ptr %l63, !tbaa !24
  %t113 = load i64, ptr %l61, !tbaa !24
  %t114 = load i64, ptr %l63, !tbaa !24
  %t115 = icmp slt i64 %t113, %t114
  store i1 %t115, ptr %l64, !tbaa !21
  %t116 = load i1, ptr %l64, !tbaa !21
  br i1 %t116, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  store i32 -1, ptr %l65, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load i32, ptr %l65, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t118 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t118, ptr %l66, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l67, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t121, ptr %l68, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l69, !tbaa !24
  %t124 = load i64, ptr %l67, !tbaa !24
  %t125 = load i64, ptr %l69, !tbaa !24
  %t126 = icmp sgt i64 %t124, %t125
  store i1 %t126, ptr %l70, !tbaa !21
  %t127 = load i1, ptr %l70, !tbaa !21
  br i1 %t127, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 1, ptr %l71, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t128 = load i32, ptr %l71, !tbaa !23
  store i32 %t128, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store i32 0, ptr %l72, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t129 = load i32, ptr %l72, !tbaa !23
  store i32 %t129, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l6, !tbaa !21
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l7, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l10, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = load i64, ptr %l12, !tbaa !24
  %t21 = sub i64 %t19, %t20
  store i64 %t21, ptr %l13, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t22, ptr %l14, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l17, !tbaa !24
  %t28 = load i64, ptr %l13, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  store i1 %t29, ptr %l18, !tbaa !21
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = icmp sle i64 %t31, %t32
  store i1 %t33, ptr %l19, !tbaa !21
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb6:
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  store i1 %t37, ptr %l20, !tbaa !21
  %t38 = load i1, ptr %l20, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb8:
  %t39 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l13, !tbaa !24
  %t42 = load i64, ptr %l16, !tbaa !24
  %t43 = getelementptr i8, ptr %t40, i64 %t41
  %t44 = sub i64 %t42, %t41
  %t45 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  store { i64, ptr } %t46, ptr %l21, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l22, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t50 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t48, { i64, ptr } %t49)
  store i1 %t50, ptr %l23
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i1, ptr %l23, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca i8
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i8
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l9, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l10, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load i64, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp ne i64 %t7, %t8
  store i1 %t9, ptr %l12, !tbaa !21
  %t10 = load i1, ptr %l12, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l13, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l13, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l14, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l15, !tbaa !24
  %t15 = load i64, ptr %l15, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l16, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  store i64 %t17, ptr %l17, !tbaa !24
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = icmp sgt i64 %t18, %t19
  store i1 %t20, ptr %l18, !tbaa !21
  %t21 = load i1, ptr %l18, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l20, !tbaa !24
  %t23 = load i64, ptr %l20, !tbaa !24
  %t24 = icmp sgt i64 %t23, 0
  store i1 %t24, ptr %l21, !tbaa !21
  %t25 = load i1, ptr %l21, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l24, !tbaa !24
  %t28 = load i64, ptr %l23, !tbaa !24
  %t29 = load i64, ptr %l24, !tbaa !24
  %t30 = sub i64 %t28, %t29
  store i64 %t30, ptr %l25, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l26, !tbaa !24
  %t34 = add i64 %t32, %t33
  store i64 %t34, ptr %l27, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t36 = sub i64 %t35, 1
  store i64 %t36, ptr %l28, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  store i64 %t37, ptr %l29, !tbaa !24
  %t38 = load i64, ptr %l28, !tbaa !24
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = sdiv i64 %t38, %t39
  store i64 %t40, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l30, !tbaa !24
  store i64 %t41, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l19, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l6, !tbaa !24
  store i64 %t44, ptr %l31, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  store i64 %t45, ptr %l32, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = load i64, ptr %l32, !tbaa !24
  %t48 = icmp slt i64 %t46, %t47
  store i1 %t48, ptr %l33, !tbaa !21
  %t49 = load i1, ptr %l33, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l34, !tbaa !21
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t52 = load i64, ptr %l2, !tbaa !24
  store i64 %t52, ptr %l35, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l36, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  store i64 %t54, ptr %l37, !tbaa !24
  %t55 = load i64, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l37, !tbaa !24
  %t57 = mul i64 %t55, %t56
  store i64 %t57, ptr %l38, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = load i64, ptr %l38, !tbaa !24
  %t60 = add i64 %t58, %t59
  store i64 %t60, ptr %l39, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load i64, ptr %l41, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i8, ptr %t66, i64 %t64
  %t68 = load i8, ptr %t67, !tbaa !32
  store i8 %t68, ptr %l42, !tbaa !22
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  store i64 %t70, ptr %l44, !tbaa !24
  %t71 = load i64, ptr %l44, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t71
  %t75 = load i8, ptr %t74, !tbaa !32
  store i8 %t75, ptr %l45, !tbaa !22
  %t76 = load i8, ptr %l42, !tbaa !22
  %t77 = load i8, ptr %l45, !tbaa !22
  %t78 = icmp ne i8 %t76, %t77
  store i1 %t78, ptr %l46, !tbaa !21
  %t79 = load i1, ptr %l46, !tbaa !21
  br i1 %t79, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l47, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i1, ptr %l47, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load i64, ptr %l6, !tbaa !24
  store i64 %t81, ptr %l48, !tbaa !24
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = add i64 %t82, 1
  store i64 %t83, ptr %l49, !tbaa !24
  %t84 = load i64, ptr %l49, !tbaa !24
  store i64 %t84, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb10
bb18:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %l50, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t85 = load i1, ptr %l50, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l4, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2efindFrom(ptr %v0, ptr %v1, { i64, ptr } %t3, { i64, ptr } %t4, i64 0)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = lshr i32 %t11, 16
  %t13 = and i32 %t11, 65535
  %t14 = icmp eq i32 %t12, 1
  %t15 = select i1 %t14, i32 1, i32 0
  %t16 = icmp eq i32 %t11, 0
  %t17 = shl i32 %t15, 16
  %t18 = or i32 %t17, %t13
  %t19 = select i1 %t16, i32 0, i32 %t18
  store i32 %t19, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i32, ptr %l7, !tbaa !23
  %t21 = insertvalue { i32, i64 } zeroinitializer, i32 %t20, 0
  store { i32, i64 } %t21, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = insertvalue { i32, i64 } zeroinitializer, i64 %t22, 1
  store { i32, i64 } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i8
  %l37 = alloca i8
  %l38 = alloca i8
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l9, !tbaa !24
  %t4 = load i64, ptr %l9, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load i64, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l12, !tbaa !21
  %t10 = load i1, ptr %l12, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  store i64 %t11, ptr %l14, !tbaa !24
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = icmp sgt i64 %t12, 0
  store i1 %t13, ptr %l15, !tbaa !21
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l17, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %l18, !tbaa !24
  %t17 = load i64, ptr %l17, !tbaa !24
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = sub i64 %t17, %t18
  store i64 %t19, ptr %l19, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  store i64 %t20, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l19, !tbaa !24
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = add i64 %t21, %t22
  store i64 %t23, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = sub i64 %t24, 1
  store i64 %t25, ptr %l22, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load i64, ptr %l22, !tbaa !24
  %t28 = load i64, ptr %l23, !tbaa !24
  %t29 = sdiv i64 %t27, %t28
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  store i64 %t30, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i64, ptr %l6, !tbaa !24
  store i64 %t33, ptr %l25, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l25, !tbaa !24
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  store i1 %t37, ptr %l27, !tbaa !21
  %t38 = load i1, ptr %l27, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l28, !tbaa !21
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  store i64 %t41, ptr %l29, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  store i64 %t42, ptr %l30, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l31, !tbaa !24
  %t44 = load i64, ptr %l30, !tbaa !24
  %t45 = load i64, ptr %l31, !tbaa !24
  %t46 = mul i64 %t44, %t45
  store i64 %t46, ptr %l32, !tbaa !24
  %t47 = load i64, ptr %l29, !tbaa !24
  %t48 = load i64, ptr %l32, !tbaa !24
  %t49 = add i64 %t47, %t48
  store i64 %t49, ptr %l33, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t51, ptr %l34, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  store i64 %t52, ptr %l35, !tbaa !24
  %t53 = load i64, ptr %l35, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 %t53
  %t57 = load i8, ptr %t56, !tbaa !32
  store i8 %t57, ptr %l36, !tbaa !22
  %t58 = load i8, ptr %l36, !tbaa !22
  store i8 %t58, ptr %l37, !tbaa !22
  %t59 = load i8, ptr %l1, !tbaa !22
  store i8 %t59, ptr %l38, !tbaa !22
  %t60 = load i8, ptr %l37, !tbaa !22
  %t61 = load i8, ptr %l38, !tbaa !22
  %t62 = icmp eq i8 %t60, %t61
  store i1 %t62, ptr %l39, !tbaa !21
  %t63 = load i1, ptr %l39, !tbaa !21
  br i1 %t63, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load i64, ptr %l7, !tbaa !24
  store i64 %t64, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = insertvalue { i32, i64 } zeroinitializer, i64 %t65, 1
  store { i32, i64 } %t66, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t67 = load i64, ptr %l6, !tbaa !24
  store i64 %t67, ptr %l41, !tbaa !24
  %t68 = load i64, ptr %l41, !tbaa !24
  %t69 = add i64 %t68, 1
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load i64, ptr %l42, !tbaa !24
  store i64 %t70, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb7
bb15:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %l43, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t71 = load i32, ptr %l43, !tbaa !23
  %t72 = insertvalue { i32, i64 } zeroinitializer, i32 %t71, 0
  store { i32, i64 } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i8
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i8
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load i64, ptr %l6, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l7, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = sub i64 %t9, %t10
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l11, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  store i1 %t15, ptr %l12, !tbaa !21
  %t16 = load i1, ptr %l12, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l13, !tbaa !21
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load i64, ptr %l4, !tbaa !24
  store i64 %t19, ptr %l14, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %l15, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t22 = load i64, ptr %l15, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  store i1 %t23, ptr %l16, !tbaa !21
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t25 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t25, ptr %l18, !tbaa !27
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l19, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l20, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = load i64, ptr %l20, !tbaa !24
  %t30 = add i64 %t28, %t29
  store i64 %t30, ptr %l21, !tbaa !24
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i8, ptr %t33, i64 %t31
  %t35 = load i8, ptr %t34, !tbaa !32
  store i8 %t35, ptr %l22, !tbaa !22
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l23, !tbaa !27
  %t37 = load i64, ptr %l4, !tbaa !24
  store i64 %t37, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t38
  %t42 = load i8, ptr %t41, !tbaa !32
  store i8 %t42, ptr %l25, !tbaa !22
  %t43 = load i8, ptr %l22, !tbaa !22
  %t44 = load i8, ptr %l25, !tbaa !22
  %t45 = icmp eq i8 %t43, %t44
  store i1 %t45, ptr %l26, !tbaa !21
  %t46 = load i1, ptr %l26, !tbaa !21
  store i1 %t46, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t47 = load i1, ptr %l17, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l27, !tbaa !21
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l28, !tbaa !24
  %t51 = load i64, ptr %l28, !tbaa !24
  %t52 = add i64 %t51, 1
  store i64 %t52, ptr %l29, !tbaa !24
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  br label %bb5
bb13:
  %t54 = load i64, ptr %l4, !tbaa !24
  store i64 %t54, ptr %l30, !tbaa !24
  %t55 = load i64, ptr %l2, !tbaa !24
  store i64 %t55, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = load i64, ptr %l31, !tbaa !24
  %t58 = icmp eq i64 %t56, %t57
  store i1 %t58, ptr %l32, !tbaa !21
  %t59 = load i1, ptr %l32, !tbaa !21
  br i1 %t59, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = insertvalue { i32, i64 } zeroinitializer, i64 %t61, 1
  store { i32, i64 } %t62, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t63 = load i64, ptr %l3, !tbaa !24
  store i64 %t63, ptr %l34, !tbaa !24
  %t64 = load i64, ptr %l34, !tbaa !24
  %t65 = sub i64 %t64, 1
  store i64 %t65, ptr %l35, !tbaa !24
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb1
bb18:
  store i32 65536, ptr %l36, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t67 = load i32, ptr %l36, !tbaa !23
  %t68 = insertvalue { i32, i64 } zeroinitializer, i32 %t67, 0
  store { i32, i64 } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i8
  %l16 = alloca i64
  %l17 = alloca i8
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -3750763034362895579, ptr %l1, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t2, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l10, !tbaa !24
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l10, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l11, !tbaa !21
  %t12 = load i1, ptr %l11, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l12, !tbaa !21
  %t14 = load i1, ptr %l12, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t17
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l15, !tbaa !22
  %t22 = load i8, ptr %l15, !tbaa !22
  store i8 %t22, ptr %l5, !tbaa !22
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load i8, ptr %l5, !tbaa !22
  store i8 %t24, ptr %l17, !tbaa !22
  %t25 = load i8, ptr %l17, !tbaa !22
  %t26 = zext i8 %t25 to i64
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = xor i64 %t27, %t28
  store i64 %t29, ptr %l19, !tbaa !24
  %t30 = load i64, ptr %l19, !tbaa !24
  %t31 = mul i64 %t30, 1099511628211
  store i64 %t31, ptr %l20, !tbaa !24
  %t32 = load i64, ptr %l20, !tbaa !24
  store i64 %t32, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t33 = load i64, ptr %l3, !tbaa !24
  store i64 %t33, ptr %l21, !tbaa !24
  %t34 = load i64, ptr %l21, !tbaa !24
  %t35 = add i64 %t34, 1
  store i64 %t35, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb1
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i64, ptr %l23, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = call i32 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eCompare(ptr %v0, ptr %v1, { i64, ptr } %t3, { i64, ptr } %t4)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  %t7 = icmp slt i32 %t6, 0
  store i1 %t7, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:LineIter"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/text:LineIter"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_3aLineIter_2ector(ptr %v0, ptr %v1, { i64, ptr } %t2)
  store %"std/prelude/text:LineIter" %t3, ptr %l2
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"std/prelude/text:LineIter", ptr %l2
  store %"std/prelude/text:LineIter" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:LineIter", ptr %rv
  ret %"std/prelude/text:LineIter" %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i8
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i8
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i8
  %l33 = alloca i64
  %l34 = alloca i8
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t35 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i8 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l9, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l10, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l11, !tbaa !24
  %t5 = load i64, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l11, !tbaa !24
  %t7 = icmp sge i64 %t5, %t6
  store i1 %t7, ptr %l12, !tbaa !21
  %t8 = load i1, ptr %l12, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l13, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t10, ptr %l14, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l15, !tbaa !24
  %t13 = load i64, ptr %l15, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l15, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i8, ptr %l2, !tbaa !22
  store i8 %t27, ptr %l18, !tbaa !22
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  store i1 %t29, ptr %l19, !tbaa !21
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = mul i64 %t31, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t32)
  %t34 = load i8, ptr %l18, !tbaa !22
  store i64 0, ptr %t35
  br label %fill.36
fill.36:
  %t39 = load i64, ptr %t35
  %t40 = icmp slt i64 %t39, %t31
  br i1 %t40, label %fillb.37, label %filld.38
fillb.37:
  %t41 = getelementptr i8, ptr %t33, i64 %t39
  store i8 %t34, ptr %t41
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %t35
  br label %fill.36
filld.38:
  %t43 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t33, 1
  store { i64, ptr } %t44, ptr %l20, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t45, ptr %l21, !tbaa !27
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t46, ptr %lp3
  %t47 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t48 = load ptr, ptr %lp3
  store { i64, ptr } %t47, ptr %t48, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t49, ptr %l22, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t50, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l24, !tbaa !24
  %t54 = load i64, ptr %l24, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c6)
  unreachable
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l25, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  store i64 %t56, ptr %l26, !tbaa !24
  %t57 = load i64, ptr %l25, !tbaa !24
  %t58 = load i64, ptr %l26, !tbaa !24
  %t59 = icmp slt i64 %t57, %t58
  store i1 %t59, ptr %l27, !tbaa !21
  %t60 = load i1, ptr %l27, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l28, !tbaa !21
  %t62 = load i1, ptr %l28, !tbaa !21
  br i1 %t62, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l29, !tbaa !24
  %t64 = load i64, ptr %l29, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t65, ptr %l30, !tbaa !27
  %t66 = load i64, ptr %l5, !tbaa !24
  store i64 %t66, ptr %l31, !tbaa !24
  %t67 = load i64, ptr %l31, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 %t67
  %t71 = load i8, ptr %t70, !tbaa !32
  store i8 %t71, ptr %l32, !tbaa !22
  %t72 = load i8, ptr %l32, !tbaa !22
  store i8 %t72, ptr %l8, !tbaa !22
  %t73 = load i64, ptr %l7, !tbaa !24
  store i64 %t73, ptr %l33, !tbaa !24
  %t74 = load i8, ptr %l8, !tbaa !22
  store i8 %t74, ptr %l34, !tbaa !22
  %t75 = load i8, ptr %l34, !tbaa !22
  %t76 = load ptr, ptr %lp3
  %t77 = load i64, ptr %l33, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i8, ptr %t79, i64 %t77
  store i8 %t75, ptr %t80, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t81 = load i64, ptr %l5, !tbaa !24
  store i64 %t81, ptr %l35, !tbaa !24
  %t82 = load i64, ptr %l35, !tbaa !24
  %t83 = add i64 %t82, 1
  store i64 %t83, ptr %l36, !tbaa !24
  %t84 = load i64, ptr %l36, !tbaa !24
  store i64 %t84, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb6
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t85 = load ptr, ptr %lp3
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t87 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i8
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i8
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i8
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i8
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t35 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i8 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l10, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l11, !tbaa !24
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l12, !tbaa !24
  %t5 = load i64, ptr %l11, !tbaa !24
  %t6 = load i64, ptr %l12, !tbaa !24
  %t7 = icmp sge i64 %t5, %t6
  store i1 %t7, ptr %l13, !tbaa !21
  %t8 = load i1, ptr %l13, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l14, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t10, ptr %l15, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l16, !tbaa !24
  %t13 = load i64, ptr %l16, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l17, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load i8, ptr %l2, !tbaa !22
  store i8 %t27, ptr %l19, !tbaa !22
  %t28 = load i64, ptr %l18, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  store i1 %t29, ptr %l20, !tbaa !21
  %t30 = load i1, ptr %l20, !tbaa !21
  br i1 %t30, label %bb4, label %bb5
bb4:
  %t31 = load i64, ptr %l18, !tbaa !24
  %t32 = mul i64 %t31, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t32)
  %t34 = load i8, ptr %l19, !tbaa !22
  store i64 0, ptr %t35
  br label %fill.36
fill.36:
  %t39 = load i64, ptr %t35
  %t40 = icmp slt i64 %t39, %t31
  br i1 %t40, label %fillb.37, label %filld.38
fillb.37:
  %t41 = getelementptr i8, ptr %t33, i64 %t39
  store i8 %t34, ptr %t41
  %t42 = add i64 %t39, 1
  store i64 %t42, ptr %t35
  br label %fill.36
filld.38:
  %t43 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t33, 1
  store { i64, ptr } %t44, ptr %l21, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t45, ptr %l22, !tbaa !27
  %t46 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t46, ptr %lp3
  %t47 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t48 = load ptr, ptr %lp3
  store { i64, ptr } %t47, ptr %t48, !tbaa !27
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l23, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t50, ptr %l24, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l25, !tbaa !24
  %t53 = load i64, ptr %l23, !tbaa !24
  %t54 = load i64, ptr %l25, !tbaa !24
  %t55 = sub i64 %t53, %t54
  store i64 %t55, ptr %l26, !tbaa !24
  %t56 = load i64, ptr %l26, !tbaa !24
  store i64 %t56, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t57, ptr %l27, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t58, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t59, ptr %l28, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  store i64 %t61, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l29, !tbaa !24
  store i64 %t62, ptr %l7, !tbaa !24
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c7)
  unreachable
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t63 = load i64, ptr %l6, !tbaa !24
  store i64 %t63, ptr %l30, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  store i64 %t64, ptr %l31, !tbaa !24
  %t65 = load i64, ptr %l30, !tbaa !24
  %t66 = load i64, ptr %l31, !tbaa !24
  %t67 = icmp slt i64 %t65, %t66
  store i1 %t67, ptr %l32, !tbaa !21
  %t68 = load i1, ptr %l32, !tbaa !21
  %t69 = xor i1 %t68, true
  store i1 %t69, ptr %l33, !tbaa !21
  %t70 = load i1, ptr %l33, !tbaa !21
  br i1 %t70, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  store i64 %t72, ptr %l8, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t73, ptr %l35, !tbaa !27
  %t74 = load i64, ptr %l6, !tbaa !24
  store i64 %t74, ptr %l36, !tbaa !24
  %t75 = load i64, ptr %l36, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t75
  %t79 = load i8, ptr %t78, !tbaa !32
  store i8 %t79, ptr %l37, !tbaa !22
  %t80 = load i8, ptr %l37, !tbaa !22
  store i8 %t80, ptr %l9, !tbaa !22
  %t81 = load i64, ptr %l4, !tbaa !24
  store i64 %t81, ptr %l38, !tbaa !24
  %t82 = load i64, ptr %l8, !tbaa !24
  store i64 %t82, ptr %l39, !tbaa !24
  %t83 = load i64, ptr %l38, !tbaa !24
  %t84 = load i64, ptr %l39, !tbaa !24
  %t85 = add i64 %t83, %t84
  store i64 %t85, ptr %l40, !tbaa !24
  %t86 = load i8, ptr %l9, !tbaa !22
  store i8 %t86, ptr %l41, !tbaa !22
  %t87 = load i8, ptr %l41, !tbaa !22
  %t88 = load ptr, ptr %lp3
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i8, ptr %t91, i64 %t89
  store i8 %t87, ptr %t92, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t93 = load i64, ptr %l6, !tbaa !24
  store i64 %t93, ptr %l42, !tbaa !24
  %t94 = load i64, ptr %l42, !tbaa !24
  %t95 = add i64 %t94, 1
  store i64 %t95, ptr %l43, !tbaa !24
  %t96 = load i64, ptr %l43, !tbaa !24
  store i64 %t96, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb6
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t97 = load ptr, ptr %lp3
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l44, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t99 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i8
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i8
  %l26 = alloca i1
  %l27 = alloca { i64, ptr }
  %l28 = alloca i8
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca i8
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i8
  %l53 = alloca i1
  %l54 = alloca i1
  %l55 = alloca { i64, ptr }
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca double
  %l64 = alloca { i64, ptr }
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca double
  %l70 = alloca i32
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i8
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i8
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i8
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i1
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i8
  %l98 = alloca i8
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i8
  %l104 = alloca i1
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca { i64, ptr }
  %l114 = alloca i64
  %l115 = alloca i8
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca i1
  %l123 = alloca i1
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l126 = alloca i8
  %l127 = alloca i1
  %l128 = alloca i1
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca i8
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i8
  %l135 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i64
  %l138 = alloca i1
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i64
  %l144 = alloca i1
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i8
  %l148 = alloca i8
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i8
  %l154 = alloca i1
  %l155 = alloca i64
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i1
  %l159 = alloca i32
  %l160 = alloca i64
  %l161 = alloca { i64, ptr }
  %l162 = alloca i64
  %l163 = alloca i1
  %l164 = alloca i1
  %l165 = alloca { i64, ptr }
  %l166 = alloca i64
  %l167 = alloca i8
  %l168 = alloca i1
  %l169 = alloca i1
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca i8
  %l173 = alloca i1
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca i1
  %l180 = alloca i1
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l183 = alloca i8
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca { i64, ptr }
  %l187 = alloca i64
  %l188 = alloca i8
  %l189 = alloca i1
  %l190 = alloca { i64, ptr }
  %l191 = alloca i64
  %l192 = alloca i8
  %l193 = alloca i1
  %l194 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %l198 = alloca i64
  %l199 = alloca i1
  %l200 = alloca i1
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l203 = alloca i8
  %l204 = alloca i1
  %l205 = alloca i1
  %l206 = alloca i32
  %l207 = alloca i64
  %l208 = alloca { i64, ptr }
  %l209 = alloca i64
  %l210 = alloca i1
  %l211 = alloca i1
  %l212 = alloca { i64, ptr }
  %l213 = alloca i64
  %l214 = alloca i8
  %l215 = alloca i1
  %l216 = alloca i1
  %l217 = alloca i64
  %l218 = alloca i1
  %l219 = alloca i64
  %l220 = alloca i64
  %l221 = alloca { i64, ptr }
  %l222 = alloca i64
  %l223 = alloca i8
  %l224 = alloca i8
  %l225 = alloca i64
  %l226 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i64
  %l229 = alloca i64
  %l230 = alloca i64
  %l231 = alloca i64
  %l232 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca { i64, ptr }
  %l236 = alloca i64
  %l237 = alloca i1
  %l238 = alloca i32
  %l239 = alloca double
  %l240 = alloca i64
  %l241 = alloca i64
  %l242 = alloca i64
  %l243 = alloca i64
  %l244 = alloca i1
  %l245 = alloca i1
  %l246 = alloca { i64, ptr }
  %l247 = alloca double
  %l248 = alloca i32
  %l249 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca { i32, double }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l16, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l17, !tbaa !24
  %t4 = load i64, ptr %l17, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l18, !tbaa !21
  %t6 = load i1, ptr %l18, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l19, !tbaa !23
  %t8 = insertvalue { i32, double } zeroinitializer, i32 %t7, 0
  store { i32, double } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %l1, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l20, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  store i8 %t13, ptr %l21, !tbaa !22
  %t14 = load i8, ptr %l21, !tbaa !22
  %t15 = icmp eq i8 %t14, 45
  store i1 %t15, ptr %l22, !tbaa !21
  %t16 = load i1, ptr %l22, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb6
bb5:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l24, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 0
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l25, !tbaa !22
  %t22 = load i8, ptr %l25, !tbaa !22
  %t23 = icmp eq i8 %t22, 43
  store i1 %t23, ptr %l26, !tbaa !21
  %t24 = load i1, ptr %l26, !tbaa !21
  store i1 %t24, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l23, !tbaa !21
  br i1 %t25, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l27, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 0
  %t30 = load i8, ptr %t29, !tbaa !32
  store i8 %t30, ptr %l28, !tbaa !22
  %t31 = load i8, ptr %l28, !tbaa !22
  %t32 = icmp eq i8 %t31, 45
  store i1 %t32, ptr %l29, !tbaa !21
  %t33 = load i1, ptr %l29, !tbaa !21
  store i1 %t33, ptr %l1, !tbaa !21
  store i64 1, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t34, ptr %l30, !tbaa !27
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t36, ptr %l32, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t37, ptr %l33, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l34, !tbaa !24
  %t40 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l35, !tbaa !24
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  store i1 %t43, ptr %l36, !tbaa !21
  %t44 = load i1, ptr %l36, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t45 = load i64, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  store i1 %t47, ptr %l37, !tbaa !21
  %t48 = load i1, ptr %l37, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c8)
  unreachable
bb12:
  %t49 = load i64, ptr %l34, !tbaa !24
  %t50 = load i64, ptr %l35, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  store i1 %t51, ptr %l38, !tbaa !21
  %t52 = load i1, ptr %l38, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c8)
  unreachable
bb14:
  %t53 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l34, !tbaa !24
  %t57 = getelementptr i8, ptr %t54, i64 %t55
  %t58 = sub i64 %t56, %t55
  %t59 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t57, 1
  store { i64, ptr } %t60, ptr %l39, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t61, ptr %l3, !tbaa !27
  %t62 = load i1, ptr %l1, !tbaa !21
  store i1 %t62, ptr %l40, !tbaa !21
  %t63 = load i1, ptr %l40, !tbaa !21
  br i1 %t63, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c8)
  unreachable
bb16:
  %t64 = shl i64 1, 63
  store i64 %t64, ptr %l42, !tbaa !65
  %t65 = load i64, ptr %l42, !tbaa !65
  store i64 %t65, ptr %l41, !tbaa !65
  br label %bb18
bb17:
  store i64 0, ptr %l41, !tbaa !65
  br label %bb18
bb18:
  %t66 = load i64, ptr %l41, !tbaa !65
  store i64 %t66, ptr %l4, !tbaa !65
  %t67 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t67, ptr %l43, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l44, !tbaa !24
  %t70 = load i64, ptr %l44, !tbaa !24
  %t71 = icmp sgt i64 %t70, 0
  store i1 %t71, ptr %l45, !tbaa !21
  %t72 = load i1, ptr %l45, !tbaa !21
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t73, ptr %l47, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr i8, ptr %t75, i64 0
  %t77 = load i8, ptr %t76, !tbaa !32
  store i8 %t77, ptr %l48, !tbaa !22
  %t78 = load i8, ptr %l48, !tbaa !22
  %t79 = icmp ne i8 %t78, 46
  store i1 %t79, ptr %l49, !tbaa !21
  %t80 = load i1, ptr %l49, !tbaa !21
  store i1 %t80, ptr %l46, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb21
bb21:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr i8, ptr %t84, i64 0
  %t86 = load i8, ptr %t85, !tbaa !32
  store i8 %t86, ptr %l52, !tbaa !22
  %t87 = load i8, ptr %l52, !tbaa !22
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t87)
  store i1 %t88, ptr %l53
  br label %bb24
bb23:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb25
bb24:
  %t89 = load i1, ptr %l53, !tbaa !21
  %t90 = xor i1 %t89, true
  store i1 %t90, ptr %l54, !tbaa !21
  %t91 = load i1, ptr %l54, !tbaa !21
  store i1 %t91, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t92 = load i1, ptr %l50, !tbaa !21
  br i1 %t92, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t93 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t93, ptr %l55, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %s3, { i64, ptr } %t94, { i64, ptr } { i64 3, ptr @.d9 })
  store i1 %t95, ptr %l56
  br label %bb28
bb27:
  br label %bb40
bb28:
  %t96 = load i1, ptr %l56, !tbaa !21
  br i1 %t96, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb32
bb30:
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l58, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %s3, { i64, ptr } %t98, { i64, ptr } { i64 8, ptr @.d10 })
  store i1 %t99, ptr %l59
  br label %bb31
bb31:
  %t100 = load i1, ptr %l59, !tbaa !21
  store i1 %t100, ptr %l57, !tbaa !21
  br label %bb32
bb32:
  %t101 = load i1, ptr %l57, !tbaa !21
  br i1 %t101, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t102 = load i64, ptr %l4, !tbaa !65
  store i64 %t102, ptr %l60, !tbaa !65
  %t103 = shl i64 2047, 52
  store i64 %t103, ptr %l61, !tbaa !65
  %t104 = load i64, ptr %l60, !tbaa !65
  %t105 = load i64, ptr %l61, !tbaa !65
  %t106 = or i64 %t104, %t105
  store i64 %t106, ptr %l62, !tbaa !65
  %t107 = load i64, ptr %l62, !tbaa !65
  %t108 = bitcast i64 %t107 to double
  store double %t108, ptr %l63, !tbaa !26
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t109 = load double, ptr %l63, !tbaa !26
  %t110 = insertvalue { i32, double } zeroinitializer, double %t109, 1
  store { i32, double } %t110, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t111 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t111, ptr %l64, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t113 = call i1 @std_2fprelude_2ftext_2esameLetters(ptr %v0, ptr %s3, { i64, ptr } %t112, { i64, ptr } { i64 3, ptr @.d11 })
  store i1 %t113, ptr %l65
  br label %bb36
bb36:
  %t114 = load i1, ptr %l65, !tbaa !21
  br i1 %t114, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t115 = load i64, ptr %l4, !tbaa !65
  store i64 %t115, ptr %l66, !tbaa !65
  %t116 = shl i64 4095, 51
  store i64 %t116, ptr %l67, !tbaa !65
  %t117 = load i64, ptr %l66, !tbaa !65
  %t118 = load i64, ptr %l67, !tbaa !65
  %t119 = or i64 %t117, %t118
  store i64 %t119, ptr %l68, !tbaa !65
  %t120 = load i64, ptr %l68, !tbaa !65
  %t121 = bitcast i64 %t120 to double
  store double %t121, ptr %l69, !tbaa !26
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t122 = load double, ptr %l69, !tbaa !26
  %t123 = insertvalue { i32, double } zeroinitializer, double %t122, 1
  store { i32, double } %t123, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  store i32 65537, ptr %l70, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t124 = load i32, ptr %l70, !tbaa !23
  %t125 = insertvalue { i32, double } zeroinitializer, i32 %t124, 0
  store { i32, double } %t125, ptr %rv
  br label %ret
bb40:
  store i64 0, ptr %l5, !tbaa !65
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t126 = load i64, ptr %l10, !tbaa !24
  store i64 %t126, ptr %l71, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t127, ptr %l72, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  store i64 %t129, ptr %l73, !tbaa !24
  %t130 = load i64, ptr %l71, !tbaa !24
  %t131 = load i64, ptr %l73, !tbaa !24
  %t132 = icmp slt i64 %t130, %t131
  store i1 %t132, ptr %l74, !tbaa !21
  %t133 = load i1, ptr %l74, !tbaa !21
  br i1 %t133, label %bb42, label %bb43
bb42:
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t134, ptr %l76, !tbaa !27
  %t135 = load i64, ptr %l10, !tbaa !24
  store i64 %t135, ptr %l77, !tbaa !24
  %t136 = load i64, ptr %l77, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t136
  %t140 = load i8, ptr %t139, !tbaa !32
  store i8 %t140, ptr %l78, !tbaa !22
  %t141 = load i8, ptr %l78, !tbaa !22
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t141)
  store i1 %t142, ptr %l79
  br label %bb44
bb43:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb45
bb44:
  %t143 = load i1, ptr %l79, !tbaa !21
  store i1 %t143, ptr %l75, !tbaa !21
  br label %bb45
bb45:
  %t144 = load i1, ptr %l75, !tbaa !21
  %t145 = xor i1 %t144, true
  store i1 %t145, ptr %l80, !tbaa !21
  %t146 = load i1, ptr %l80, !tbaa !21
  br i1 %t146, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb62
bb47:
  br label %bb48
bb48:
  %t147 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t147, ptr %l81, !tbaa !27
  %t148 = load i64, ptr %l10, !tbaa !24
  store i64 %t148, ptr %l82, !tbaa !24
  %t149 = load i64, ptr %l82, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i8, ptr %t151, i64 %t149
  %t153 = load i8, ptr %t152, !tbaa !32
  store i8 %t153, ptr %l83, !tbaa !22
  %t154 = load i8, ptr %l83, !tbaa !22
  store i8 %t154, ptr %l11, !tbaa !22
  %t155 = load i64, ptr %l9, !tbaa !24
  store i64 %t155, ptr %l84, !tbaa !24
  %t156 = load i64, ptr %l84, !tbaa !24
  %t157 = add i64 %t156, 1
  store i64 %t157, ptr %l85, !tbaa !24
  %t158 = load i64, ptr %l85, !tbaa !24
  store i64 %t158, ptr %l9, !tbaa !24
  %t159 = load i8, ptr %l11, !tbaa !22
  store i8 %t159, ptr %l86, !tbaa !22
  %t160 = load i8, ptr %l86, !tbaa !22
  %t161 = icmp ne i8 %t160, 48
  store i1 %t161, ptr %l87, !tbaa !21
  %t162 = load i1, ptr %l87, !tbaa !21
  br i1 %t162, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb51
bb50:
  %t163 = load i64, ptr %l7, !tbaa !24
  store i64 %t163, ptr %l89, !tbaa !24
  %t164 = load i64, ptr %l89, !tbaa !24
  %t165 = icmp sgt i64 %t164, 0
  store i1 %t165, ptr %l90, !tbaa !21
  %t166 = load i1, ptr %l90, !tbaa !21
  store i1 %t166, ptr %l88, !tbaa !21
  br label %bb51
bb51:
  %t167 = load i1, ptr %l88, !tbaa !21
  br i1 %t167, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s7
  %t168 = load i64, ptr %l7, !tbaa !24
  store i64 %t168, ptr %l91, !tbaa !24
  %t169 = load i64, ptr %l91, !tbaa !24
  %t170 = add i64 %t169, 1
  store i64 %t170, ptr %l92, !tbaa !24
  %t171 = load i64, ptr %l92, !tbaa !24
  store i64 %t171, ptr %l7, !tbaa !24
  %t172 = load i64, ptr %l6, !tbaa !24
  store i64 %t172, ptr %l93, !tbaa !24
  %t173 = load i64, ptr %l93, !tbaa !24
  %t174 = icmp slt i64 %t173, 19
  store i1 %t174, ptr %l94, !tbaa !21
  %t175 = load i1, ptr %l94, !tbaa !21
  br i1 %t175, label %bb54, label %bb55
bb53:
  br label %bb60
bb54:
  store %olang.scope zeroinitializer, ptr %s8
  %t176 = load i64, ptr %l5, !tbaa !65
  store i64 %t176, ptr %l95, !tbaa !65
  %t177 = load i64, ptr %l95, !tbaa !65
  %t178 = mul i64 %t177, 10
  store i64 %t178, ptr %l96, !tbaa !65
  %t179 = load i8, ptr %l11, !tbaa !22
  store i8 %t179, ptr %l97, !tbaa !22
  %t180 = load i8, ptr %l97, !tbaa !22
  %t181 = sub i8 %t180, 48
  store i8 %t181, ptr %l98, !tbaa !22
  %t182 = load i8, ptr %l98, !tbaa !22
  %t183 = zext i8 %t182 to i64
  store i64 %t183, ptr %l99, !tbaa !65
  %t184 = load i64, ptr %l96, !tbaa !65
  %t185 = load i64, ptr %l99, !tbaa !65
  %t186 = add i64 %t184, %t185
  store i64 %t186, ptr %l100, !tbaa !65
  %t187 = load i64, ptr %l100, !tbaa !65
  store i64 %t187, ptr %l5, !tbaa !65
  %t188 = load i64, ptr %l6, !tbaa !24
  store i64 %t188, ptr %l101, !tbaa !24
  %t189 = load i64, ptr %l101, !tbaa !24
  %t190 = add i64 %t189, 1
  store i64 %t190, ptr %l102, !tbaa !24
  %t191 = load i64, ptr %l102, !tbaa !24
  store i64 %t191, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb59
bb55:
  store %olang.scope zeroinitializer, ptr %s9
  %t192 = load i8, ptr %l11, !tbaa !22
  store i8 %t192, ptr %l103, !tbaa !22
  %t193 = load i8, ptr %l103, !tbaa !22
  %t194 = icmp ne i8 %t193, 48
  store i1 %t194, ptr %l104, !tbaa !21
  %t195 = load i1, ptr %l104, !tbaa !21
  br i1 %t195, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  store i1 true, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb57:
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s9)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb60
bb60:
  %t196 = load i64, ptr %l10, !tbaa !24
  store i64 %t196, ptr %l105, !tbaa !24
  %t197 = load i64, ptr %l105, !tbaa !24
  %t198 = add i64 %t197, 1
  store i64 %t198, ptr %l106, !tbaa !24
  %t199 = load i64, ptr %l106, !tbaa !24
  store i64 %t199, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb61
bb61:
  br label %bb41
bb62:
  %t200 = load i64, ptr %l7, !tbaa !24
  store i64 %t200, ptr %l107, !tbaa !24
  %t201 = load i64, ptr %l107, !tbaa !24
  store i64 %t201, ptr %l12, !tbaa !24
  %t202 = load i64, ptr %l10, !tbaa !24
  store i64 %t202, ptr %l108, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t203, ptr %l109, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  store i64 %t205, ptr %l110, !tbaa !24
  %t206 = load i64, ptr %l108, !tbaa !24
  %t207 = load i64, ptr %l110, !tbaa !24
  %t208 = icmp slt i64 %t206, %t207
  store i1 %t208, ptr %l111, !tbaa !21
  %t209 = load i1, ptr %l111, !tbaa !21
  br i1 %t209, label %bb63, label %bb64
bb63:
  %t210 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t210, ptr %l113, !tbaa !27
  %t211 = load i64, ptr %l10, !tbaa !24
  store i64 %t211, ptr %l114, !tbaa !24
  %t212 = load i64, ptr %l114, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr i8, ptr %t214, i64 %t212
  %t216 = load i8, ptr %t215, !tbaa !32
  store i8 %t216, ptr %l115, !tbaa !22
  %t217 = load i8, ptr %l115, !tbaa !22
  %t218 = icmp eq i8 %t217, 46
  store i1 %t218, ptr %l116, !tbaa !21
  %t219 = load i1, ptr %l116, !tbaa !21
  store i1 %t219, ptr %l112, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb65
bb65:
  %t220 = load i1, ptr %l112, !tbaa !21
  br i1 %t220, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s11
  %t221 = load i64, ptr %l10, !tbaa !24
  store i64 %t221, ptr %l117, !tbaa !24
  %t222 = load i64, ptr %l117, !tbaa !24
  %t223 = add i64 %t222, 1
  store i64 %t223, ptr %l118, !tbaa !24
  %t224 = load i64, ptr %l118, !tbaa !24
  store i64 %t224, ptr %l10, !tbaa !24
  br label %bb68
bb67:
  br label %bb90
bb68:
  store %olang.scope zeroinitializer, ptr %s12
  %t225 = load i64, ptr %l10, !tbaa !24
  store i64 %t225, ptr %l119, !tbaa !24
  %t226 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t226, ptr %l120, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  store i64 %t228, ptr %l121, !tbaa !24
  %t229 = load i64, ptr %l119, !tbaa !24
  %t230 = load i64, ptr %l121, !tbaa !24
  %t231 = icmp slt i64 %t229, %t230
  store i1 %t231, ptr %l122, !tbaa !21
  %t232 = load i1, ptr %l122, !tbaa !21
  br i1 %t232, label %bb69, label %bb70
bb69:
  %t233 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t233, ptr %l124, !tbaa !27
  %t234 = load i64, ptr %l10, !tbaa !24
  store i64 %t234, ptr %l125, !tbaa !24
  %t235 = load i64, ptr %l125, !tbaa !24
  %t236 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i8, ptr %t237, i64 %t235
  %t239 = load i8, ptr %t238, !tbaa !32
  store i8 %t239, ptr %l126, !tbaa !22
  %t240 = load i8, ptr %l126, !tbaa !22
  %t241 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t240)
  store i1 %t241, ptr %l127
  br label %bb71
bb70:
  store i1 false, ptr %l123, !tbaa !21
  br label %bb72
bb71:
  %t242 = load i1, ptr %l127, !tbaa !21
  store i1 %t242, ptr %l123, !tbaa !21
  br label %bb72
bb72:
  %t243 = load i1, ptr %l123, !tbaa !21
  %t244 = xor i1 %t243, true
  store i1 %t244, ptr %l128, !tbaa !21
  %t245 = load i1, ptr %l128, !tbaa !21
  br i1 %t245, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s12)
  br label %bb89
bb74:
  br label %bb75
bb75:
  %t246 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t246, ptr %l129, !tbaa !27
  %t247 = load i64, ptr %l10, !tbaa !24
  store i64 %t247, ptr %l130, !tbaa !24
  %t248 = load i64, ptr %l130, !tbaa !24
  %t249 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = getelementptr i8, ptr %t250, i64 %t248
  %t252 = load i8, ptr %t251, !tbaa !32
  store i8 %t252, ptr %l131, !tbaa !22
  %t253 = load i8, ptr %l131, !tbaa !22
  store i8 %t253, ptr %l13, !tbaa !22
  %t254 = load i64, ptr %l9, !tbaa !24
  store i64 %t254, ptr %l132, !tbaa !24
  %t255 = load i64, ptr %l132, !tbaa !24
  %t256 = add i64 %t255, 1
  store i64 %t256, ptr %l133, !tbaa !24
  %t257 = load i64, ptr %l133, !tbaa !24
  store i64 %t257, ptr %l9, !tbaa !24
  %t258 = load i8, ptr %l13, !tbaa !22
  store i8 %t258, ptr %l134, !tbaa !22
  %t259 = load i8, ptr %l134, !tbaa !22
  %t260 = icmp eq i8 %t259, 48
  store i1 %t260, ptr %l135, !tbaa !21
  %t261 = load i1, ptr %l135, !tbaa !21
  br i1 %t261, label %bb76, label %bb77
bb76:
  %t262 = load i64, ptr %l7, !tbaa !24
  store i64 %t262, ptr %l137, !tbaa !24
  %t263 = load i64, ptr %l137, !tbaa !24
  %t264 = icmp eq i64 %t263, 0
  store i1 %t264, ptr %l138, !tbaa !21
  %t265 = load i1, ptr %l138, !tbaa !21
  store i1 %t265, ptr %l136, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb78
bb78:
  %t266 = load i1, ptr %l136, !tbaa !21
  br i1 %t266, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s13
  %t267 = load i64, ptr %l12, !tbaa !24
  store i64 %t267, ptr %l139, !tbaa !24
  %t268 = load i64, ptr %l139, !tbaa !24
  %t269 = sub i64 %t268, 1
  store i64 %t269, ptr %l140, !tbaa !24
  %t270 = load i64, ptr %l140, !tbaa !24
  store i64 %t270, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb87
bb80:
  store %olang.scope zeroinitializer, ptr %s14
  %t271 = load i64, ptr %l7, !tbaa !24
  store i64 %t271, ptr %l141, !tbaa !24
  %t272 = load i64, ptr %l141, !tbaa !24
  %t273 = add i64 %t272, 1
  store i64 %t273, ptr %l142, !tbaa !24
  %t274 = load i64, ptr %l142, !tbaa !24
  store i64 %t274, ptr %l7, !tbaa !24
  %t275 = load i64, ptr %l6, !tbaa !24
  store i64 %t275, ptr %l143, !tbaa !24
  %t276 = load i64, ptr %l143, !tbaa !24
  %t277 = icmp slt i64 %t276, 19
  store i1 %t277, ptr %l144, !tbaa !21
  %t278 = load i1, ptr %l144, !tbaa !21
  br i1 %t278, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s15
  %t279 = load i64, ptr %l5, !tbaa !65
  store i64 %t279, ptr %l145, !tbaa !65
  %t280 = load i64, ptr %l145, !tbaa !65
  %t281 = mul i64 %t280, 10
  store i64 %t281, ptr %l146, !tbaa !65
  %t282 = load i8, ptr %l13, !tbaa !22
  store i8 %t282, ptr %l147, !tbaa !22
  %t283 = load i8, ptr %l147, !tbaa !22
  %t284 = sub i8 %t283, 48
  store i8 %t284, ptr %l148, !tbaa !22
  %t285 = load i8, ptr %l148, !tbaa !22
  %t286 = zext i8 %t285 to i64
  store i64 %t286, ptr %l149, !tbaa !65
  %t287 = load i64, ptr %l146, !tbaa !65
  %t288 = load i64, ptr %l149, !tbaa !65
  %t289 = add i64 %t287, %t288
  store i64 %t289, ptr %l150, !tbaa !65
  %t290 = load i64, ptr %l150, !tbaa !65
  store i64 %t290, ptr %l5, !tbaa !65
  %t291 = load i64, ptr %l6, !tbaa !24
  store i64 %t291, ptr %l151, !tbaa !24
  %t292 = load i64, ptr %l151, !tbaa !24
  %t293 = add i64 %t292, 1
  store i64 %t293, ptr %l152, !tbaa !24
  %t294 = load i64, ptr %l152, !tbaa !24
  store i64 %t294, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb86
bb82:
  store %olang.scope zeroinitializer, ptr %s16
  %t295 = load i8, ptr %l13, !tbaa !22
  store i8 %t295, ptr %l153, !tbaa !22
  %t296 = load i8, ptr %l153, !tbaa !22
  %t297 = icmp ne i8 %t296, 48
  store i1 %t297, ptr %l154, !tbaa !21
  %t298 = load i1, ptr %l154, !tbaa !21
  br i1 %t298, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s17
  store i1 true, ptr %l8, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb85
bb84:
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s16)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s14)
  br label %bb87
bb87:
  %t299 = load i64, ptr %l10, !tbaa !24
  store i64 %t299, ptr %l155, !tbaa !24
  %t300 = load i64, ptr %l155, !tbaa !24
  %t301 = add i64 %t300, 1
  store i64 %t301, ptr %l156, !tbaa !24
  %t302 = load i64, ptr %l156, !tbaa !24
  store i64 %t302, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb88
bb88:
  br label %bb68
bb89:
  call void @__olang_scope_close(ptr %s11)
  br label %bb90
bb90:
  %t303 = load i64, ptr %l9, !tbaa !24
  store i64 %t303, ptr %l157, !tbaa !24
  %t304 = load i64, ptr %l157, !tbaa !24
  %t305 = icmp eq i64 %t304, 0
  store i1 %t305, ptr %l158, !tbaa !21
  %t306 = load i1, ptr %l158, !tbaa !21
  br i1 %t306, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s18
  store i32 65537, ptr %l159, !tbaa !23
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t307 = load i32, ptr %l159, !tbaa !23
  %t308 = insertvalue { i32, double } zeroinitializer, i32 %t307, 0
  store { i32, double } %t308, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t309 = load i64, ptr %l10, !tbaa !24
  store i64 %t309, ptr %l160, !tbaa !24
  %t310 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t310, ptr %l161, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 0
  store i64 %t312, ptr %l162, !tbaa !24
  %t313 = load i64, ptr %l160, !tbaa !24
  %t314 = load i64, ptr %l162, !tbaa !24
  %t315 = icmp slt i64 %t313, %t314
  store i1 %t315, ptr %l163, !tbaa !21
  %t316 = load i1, ptr %l163, !tbaa !21
  br i1 %t316, label %bb94, label %bb95
bb94:
  %t317 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t317, ptr %l165, !tbaa !27
  %t318 = load i64, ptr %l10, !tbaa !24
  store i64 %t318, ptr %l166, !tbaa !24
  %t319 = load i64, ptr %l166, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr i8, ptr %t321, i64 %t319
  %t323 = load i8, ptr %t322, !tbaa !32
  store i8 %t323, ptr %l167, !tbaa !22
  %t324 = load i8, ptr %l167, !tbaa !22
  %t325 = icmp eq i8 %t324, 101
  store i1 %t325, ptr %l168, !tbaa !21
  %t326 = load i1, ptr %l168, !tbaa !21
  br i1 %t326, label %bb96, label %bb97
bb95:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb99
bb96:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb98
bb97:
  %t327 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t327, ptr %l170, !tbaa !27
  %t328 = load i64, ptr %l10, !tbaa !24
  store i64 %t328, ptr %l171, !tbaa !24
  %t329 = load i64, ptr %l171, !tbaa !24
  %t330 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr i8, ptr %t331, i64 %t329
  %t333 = load i8, ptr %t332, !tbaa !32
  store i8 %t333, ptr %l172, !tbaa !22
  %t334 = load i8, ptr %l172, !tbaa !22
  %t335 = icmp eq i8 %t334, 69
  store i1 %t335, ptr %l173, !tbaa !21
  %t336 = load i1, ptr %l173, !tbaa !21
  store i1 %t336, ptr %l169, !tbaa !21
  br label %bb98
bb98:
  %t337 = load i1, ptr %l169, !tbaa !21
  store i1 %t337, ptr %l164, !tbaa !21
  br label %bb99
bb99:
  %t338 = load i1, ptr %l164, !tbaa !21
  br i1 %t338, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s19
  %t339 = load i64, ptr %l10, !tbaa !24
  store i64 %t339, ptr %l174, !tbaa !24
  %t340 = load i64, ptr %l174, !tbaa !24
  %t341 = add i64 %t340, 1
  store i64 %t341, ptr %l175, !tbaa !24
  %t342 = load i64, ptr %l175, !tbaa !24
  store i64 %t342, ptr %l10, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t343 = load i64, ptr %l10, !tbaa !24
  store i64 %t343, ptr %l176, !tbaa !24
  %t344 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t344, ptr %l177, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t345, 0
  store i64 %t346, ptr %l178, !tbaa !24
  %t347 = load i64, ptr %l176, !tbaa !24
  %t348 = load i64, ptr %l178, !tbaa !24
  %t349 = icmp slt i64 %t347, %t348
  store i1 %t349, ptr %l179, !tbaa !21
  %t350 = load i1, ptr %l179, !tbaa !21
  br i1 %t350, label %bb102, label %bb103
bb101:
  br label %bb134
bb102:
  %t351 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t351, ptr %l181, !tbaa !27
  %t352 = load i64, ptr %l10, !tbaa !24
  store i64 %t352, ptr %l182, !tbaa !24
  %t353 = load i64, ptr %l182, !tbaa !24
  %t354 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr i8, ptr %t355, i64 %t353
  %t357 = load i8, ptr %t356, !tbaa !32
  store i8 %t357, ptr %l183, !tbaa !22
  %t358 = load i8, ptr %l183, !tbaa !22
  %t359 = icmp eq i8 %t358, 43
  store i1 %t359, ptr %l184, !tbaa !21
  %t360 = load i1, ptr %l184, !tbaa !21
  br i1 %t360, label %bb104, label %bb105
bb103:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb107
bb104:
  store i1 true, ptr %l185, !tbaa !21
  br label %bb106
bb105:
  %t361 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t361, ptr %l186, !tbaa !27
  %t362 = load i64, ptr %l10, !tbaa !24
  store i64 %t362, ptr %l187, !tbaa !24
  %t363 = load i64, ptr %l187, !tbaa !24
  %t364 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i8, ptr %t365, i64 %t363
  %t367 = load i8, ptr %t366, !tbaa !32
  store i8 %t367, ptr %l188, !tbaa !22
  %t368 = load i8, ptr %l188, !tbaa !22
  %t369 = icmp eq i8 %t368, 45
  store i1 %t369, ptr %l189, !tbaa !21
  %t370 = load i1, ptr %l189, !tbaa !21
  store i1 %t370, ptr %l185, !tbaa !21
  br label %bb106
bb106:
  %t371 = load i1, ptr %l185, !tbaa !21
  store i1 %t371, ptr %l180, !tbaa !21
  br label %bb107
bb107:
  %t372 = load i1, ptr %l180, !tbaa !21
  br i1 %t372, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s20
  %t373 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t373, ptr %l190, !tbaa !27
  %t374 = load i64, ptr %l10, !tbaa !24
  store i64 %t374, ptr %l191, !tbaa !24
  %t375 = load i64, ptr %l191, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l190, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr i8, ptr %t377, i64 %t375
  %t379 = load i8, ptr %t378, !tbaa !32
  store i8 %t379, ptr %l192, !tbaa !22
  %t380 = load i8, ptr %l192, !tbaa !22
  %t381 = icmp eq i8 %t380, 45
  store i1 %t381, ptr %l193, !tbaa !21
  %t382 = load i1, ptr %l193, !tbaa !21
  br i1 %t382, label %bb110, label %bb111
bb109:
  br label %bb113
bb110:
  store %olang.scope zeroinitializer, ptr %s21
  store i64 -1, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb112
bb111:
  br label %bb112
bb112:
  %t383 = load i64, ptr %l10, !tbaa !24
  store i64 %t383, ptr %l194, !tbaa !24
  %t384 = load i64, ptr %l194, !tbaa !24
  %t385 = add i64 %t384, 1
  store i64 %t385, ptr %l195, !tbaa !24
  %t386 = load i64, ptr %l195, !tbaa !24
  store i64 %t386, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb113
bb113:
  %t387 = load i64, ptr %l10, !tbaa !24
  store i64 %t387, ptr %l196, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t388, ptr %l197, !tbaa !27
  %t389 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  store i64 %t390, ptr %l198, !tbaa !24
  %t391 = load i64, ptr %l196, !tbaa !24
  %t392 = load i64, ptr %l198, !tbaa !24
  %t393 = icmp eq i64 %t391, %t392
  store i1 %t393, ptr %l199, !tbaa !21
  %t394 = load i1, ptr %l199, !tbaa !21
  br i1 %t394, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb117
bb115:
  %t395 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t395, ptr %l201, !tbaa !27
  %t396 = load i64, ptr %l10, !tbaa !24
  store i64 %t396, ptr %l202, !tbaa !24
  %t397 = load i64, ptr %l202, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i8, ptr %t399, i64 %t397
  %t401 = load i8, ptr %t400, !tbaa !32
  store i8 %t401, ptr %l203, !tbaa !22
  %t402 = load i8, ptr %l203, !tbaa !22
  %t403 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t402)
  store i1 %t403, ptr %l204
  br label %bb116
bb116:
  %t404 = load i1, ptr %l204, !tbaa !21
  %t405 = xor i1 %t404, true
  store i1 %t405, ptr %l205, !tbaa !21
  %t406 = load i1, ptr %l205, !tbaa !21
  store i1 %t406, ptr %l200, !tbaa !21
  br label %bb117
bb117:
  %t407 = load i1, ptr %l200, !tbaa !21
  br i1 %t407, label %bb118, label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s22
  store i32 65537, ptr %l206, !tbaa !23
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t408 = load i32, ptr %l206, !tbaa !23
  %t409 = insertvalue { i32, double } zeroinitializer, i32 %t408, 0
  store { i32, double } %t409, ptr %rv
  br label %ret
bb119:
  br label %bb120
bb120:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb121
bb121:
  store %olang.scope zeroinitializer, ptr %s23
  %t410 = load i64, ptr %l10, !tbaa !24
  store i64 %t410, ptr %l207, !tbaa !24
  %t411 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t411, ptr %l208, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l208, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 0
  store i64 %t413, ptr %l209, !tbaa !24
  %t414 = load i64, ptr %l207, !tbaa !24
  %t415 = load i64, ptr %l209, !tbaa !24
  %t416 = icmp slt i64 %t414, %t415
  store i1 %t416, ptr %l210, !tbaa !21
  %t417 = load i1, ptr %l210, !tbaa !21
  br i1 %t417, label %bb122, label %bb123
bb122:
  %t418 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t418, ptr %l212, !tbaa !27
  %t419 = load i64, ptr %l10, !tbaa !24
  store i64 %t419, ptr %l213, !tbaa !24
  %t420 = load i64, ptr %l213, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr i8, ptr %t422, i64 %t420
  %t424 = load i8, ptr %t423, !tbaa !32
  store i8 %t424, ptr %l214, !tbaa !22
  %t425 = load i8, ptr %l214, !tbaa !22
  %t426 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t425)
  store i1 %t426, ptr %l215
  br label %bb124
bb123:
  store i1 false, ptr %l211, !tbaa !21
  br label %bb125
bb124:
  %t427 = load i1, ptr %l215, !tbaa !21
  store i1 %t427, ptr %l211, !tbaa !21
  br label %bb125
bb125:
  %t428 = load i1, ptr %l211, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l216, !tbaa !21
  %t430 = load i1, ptr %l216, !tbaa !21
  br i1 %t430, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s23)
  br label %bb133
bb127:
  br label %bb128
bb128:
  %t431 = load i64, ptr %l15, !tbaa !24
  store i64 %t431, ptr %l217, !tbaa !24
  %t432 = load i64, ptr %l217, !tbaa !24
  %t433 = icmp slt i64 %t432, 100000
  store i1 %t433, ptr %l218, !tbaa !21
  %t434 = load i1, ptr %l218, !tbaa !21
  br i1 %t434, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s24
  %t435 = load i64, ptr %l15, !tbaa !24
  store i64 %t435, ptr %l219, !tbaa !24
  %t436 = load i64, ptr %l219, !tbaa !24
  %t437 = mul i64 %t436, 10
  store i64 %t437, ptr %l220, !tbaa !24
  %t438 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t438, ptr %l221, !tbaa !27
  %t439 = load i64, ptr %l10, !tbaa !24
  store i64 %t439, ptr %l222, !tbaa !24
  %t440 = load i64, ptr %l222, !tbaa !24
  %t441 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr i8, ptr %t442, i64 %t440
  %t444 = load i8, ptr %t443, !tbaa !32
  store i8 %t444, ptr %l223, !tbaa !22
  %t445 = load i8, ptr %l223, !tbaa !22
  %t446 = sub i8 %t445, 48
  store i8 %t446, ptr %l224, !tbaa !22
  %t447 = load i8, ptr %l224, !tbaa !22
  %t448 = zext i8 %t447 to i64
  store i64 %t448, ptr %l225, !tbaa !24
  %t449 = load i64, ptr %l220, !tbaa !24
  %t450 = load i64, ptr %l225, !tbaa !24
  %t451 = add i64 %t449, %t450
  store i64 %t451, ptr %l226, !tbaa !24
  %t452 = load i64, ptr %l226, !tbaa !24
  store i64 %t452, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb131
bb130:
  br label %bb131
bb131:
  %t453 = load i64, ptr %l10, !tbaa !24
  store i64 %t453, ptr %l227, !tbaa !24
  %t454 = load i64, ptr %l227, !tbaa !24
  %t455 = add i64 %t454, 1
  store i64 %t455, ptr %l228, !tbaa !24
  %t456 = load i64, ptr %l228, !tbaa !24
  store i64 %t456, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb132
bb132:
  br label %bb121
bb133:
  %t457 = load i64, ptr %l12, !tbaa !24
  store i64 %t457, ptr %l229, !tbaa !24
  %t458 = load i64, ptr %l15, !tbaa !24
  store i64 %t458, ptr %l230, !tbaa !24
  %t459 = load i64, ptr %l14, !tbaa !24
  store i64 %t459, ptr %l231, !tbaa !24
  %t460 = load i64, ptr %l230, !tbaa !24
  %t461 = load i64, ptr %l231, !tbaa !24
  %t462 = mul i64 %t460, %t461
  store i64 %t462, ptr %l232, !tbaa !24
  %t463 = load i64, ptr %l229, !tbaa !24
  %t464 = load i64, ptr %l232, !tbaa !24
  %t465 = add i64 %t463, %t464
  store i64 %t465, ptr %l233, !tbaa !24
  %t466 = load i64, ptr %l233, !tbaa !24
  store i64 %t466, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb134
bb134:
  %t467 = load i64, ptr %l10, !tbaa !24
  store i64 %t467, ptr %l234, !tbaa !24
  %t468 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t468, ptr %l235, !tbaa !27
  %t469 = load { i64, ptr }, ptr %l235, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 0
  store i64 %t470, ptr %l236, !tbaa !24
  %t471 = load i64, ptr %l234, !tbaa !24
  %t472 = load i64, ptr %l236, !tbaa !24
  %t473 = icmp slt i64 %t471, %t472
  store i1 %t473, ptr %l237, !tbaa !21
  %t474 = load i1, ptr %l237, !tbaa !21
  br i1 %t474, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s25
  store i32 65537, ptr %l238, !tbaa !23
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t475 = load i32, ptr %l238, !tbaa !23
  %t476 = insertvalue { i32, double } zeroinitializer, i32 %t475, 0
  store { i32, double } %t476, ptr %rv
  br label %ret
bb136:
  br label %bb137
bb137:
  %t477 = load i64, ptr %l5, !tbaa !65
  store i64 %t477, ptr %l240, !tbaa !65
  %t478 = load i64, ptr %l12, !tbaa !24
  store i64 %t478, ptr %l241, !tbaa !24
  %t479 = load i64, ptr %l6, !tbaa !24
  store i64 %t479, ptr %l242, !tbaa !24
  %t480 = load i64, ptr %l241, !tbaa !24
  %t481 = load i64, ptr %l242, !tbaa !24
  %t482 = sub i64 %t480, %t481
  store i64 %t482, ptr %l243, !tbaa !24
  %t483 = load i1, ptr %l8, !tbaa !21
  store i1 %t483, ptr %l244, !tbaa !21
  %t484 = load i1, ptr %l1, !tbaa !21
  store i1 %t484, ptr %l245, !tbaa !21
  %t485 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t485, ptr %l246, !tbaa !27
  %t486 = load i64, ptr %l240, !tbaa !65
  %t487 = load i64, ptr %l243, !tbaa !24
  %t488 = load i1, ptr %l244, !tbaa !21
  %t489 = load i1, ptr %l245, !tbaa !21
  %t490 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t491 = call { i32, double } @std_2fprelude_2ftext_2etoF64(ptr %v0, i64 %t486, i64 %t487, i1 %t488, i1 %t489, { i64, ptr } %t490)
  %t492 = extractvalue { i32, double } %t491, 1
  %t493 = extractvalue { i32, double } %t491, 0
  store i32 %t493, ptr %l248
  %t494 = icmp ne i32 %t493, 0
  br i1 %t494, label %bb139, label %ok.495
ok.495:
  store double %t492, ptr %l247
  br label %bb138
bb138:
  %t496 = load double, ptr %l247, !tbaa !26
  store double %t496, ptr %l239, !tbaa !26
  br label %bb140
bb139:
  %t497 = load i32, ptr %l248, !tbaa !23
  %t498 = lshr i32 %t497, 16
  %t499 = and i32 %t497, 65535
  %t500 = icmp eq i32 %t498, 1
  %t501 = select i1 %t500, i32 1, i32 0
  %t502 = icmp eq i32 %t497, 0
  %t503 = shl i32 %t501, 16
  %t504 = or i32 %t503, %t499
  %t505 = select i1 %t502, i32 0, i32 %t504
  store i32 %t505, ptr %l249, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t506 = load i32, ptr %l249, !tbaa !23
  %t507 = insertvalue { i32, double } zeroinitializer, i32 %t506, 0
  store { i32, double } %t507, ptr %rv
  br label %ret
bb140:
  call void @__olang_scope_close(ptr %s0)
  %t508 = load double, ptr %l239, !tbaa !26
  %t509 = insertvalue { i32, double } zeroinitializer, double %t508, 1
  store { i32, double } %t509, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca i8
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i8
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i32
  %l52 = alloca i32
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i1
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i32
  %l70 = alloca i32
  %l71 = alloca i1
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l9, !tbaa !21
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l10, !tbaa !23
  %t8 = insertvalue { i32, i64 } zeroinitializer, i32 %t7, 0
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l11, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  store i8 %t13, ptr %l12, !tbaa !22
  %t14 = load i8, ptr %l12, !tbaa !22
  %t15 = icmp eq i8 %t14, 45
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  store i1 %t16, ptr %l2, !tbaa !21
  %t17 = load i1, ptr %l2, !tbaa !21
  store i1 %t17, ptr %l14, !tbaa !21
  %t18 = load i1, ptr %l14, !tbaa !21
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 0
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l17, !tbaa !22
  %t24 = load i8, ptr %l17, !tbaa !22
  %t25 = icmp eq i8 %t24, 43
  store i1 %t25, ptr %l18, !tbaa !21
  %t26 = load i1, ptr %l18, !tbaa !21
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t30, ptr %l22, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l23, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = icmp sge i64 1, 0
  store i1 %t35, ptr %l25, !tbaa !21
  %t36 = load i1, ptr %l25, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb8:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l29, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t38, ptr %l30, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t39, ptr %l31, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l32, !tbaa !24
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l33, !tbaa !24
  %t44 = icmp sge i64 0, 0
  store i1 %t44, ptr %l34, !tbaa !21
  %t45 = load i1, ptr %l34, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb9:
  %t46 = load i64, ptr %l23, !tbaa !24
  %t47 = icmp sle i64 1, %t46
  store i1 %t47, ptr %l26, !tbaa !21
  %t48 = load i1, ptr %l26, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb11:
  %t49 = load i64, ptr %l23, !tbaa !24
  %t50 = load i64, ptr %l24, !tbaa !24
  %t51 = icmp sle i64 %t49, %t50
  store i1 %t51, ptr %l27, !tbaa !21
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb13:
  %t53 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = load i64, ptr %l23, !tbaa !24
  %t56 = getelementptr i8, ptr %t54, i64 1
  %t57 = sub i64 %t55, 1
  %t58 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t56, 1
  store { i64, ptr } %t59, ptr %l28, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t60, ptr %l19, !tbaa !27
  br label %bb21
bb14:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb15:
  %t61 = load i64, ptr %l32, !tbaa !24
  %t62 = icmp sle i64 0, %t61
  store i1 %t62, ptr %l35, !tbaa !21
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb17:
  %t64 = load i64, ptr %l32, !tbaa !24
  %t65 = load i64, ptr %l33, !tbaa !24
  %t66 = icmp sle i64 %t64, %t65
  store i1 %t66, ptr %l36, !tbaa !21
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb19:
  %t68 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = getelementptr i8, ptr %t69, i64 0
  %t72 = sub i64 %t70, 0
  %t73 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t71, 1
  store { i64, ptr } %t74, ptr %l37, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t75, ptr %l19, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb21:
  %t76 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t76, ptr %l3, !tbaa !27
  %t77 = load i64, ptr %l1, !tbaa !24
  store i64 %t77, ptr %l38, !tbaa !24
  %t78 = load i64, ptr %l38, !tbaa !24
  store i64 %t78, ptr %l39, !tbaa !24
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = icmp eq i64 %t79, 0
  store i1 %t80, ptr %l40, !tbaa !21
  %t81 = load i1, ptr %l40, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t82, ptr %l42, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t84 = call i1 @std_2fprelude_2ftext_2eisPrefixed(ptr %v0, { i64, ptr } %t83)
  store i1 %t84, ptr %l43
  br label %bb24
bb23:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb25
bb24:
  %t85 = load i1, ptr %l43, !tbaa !21
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s2
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l45, !tbaa !27
  %t88 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s2, i64 0)
  %t89 = extractvalue { i32, i64 } %t88, 1
  %t90 = extractvalue { i32, i64 } %t88, 0
  store i32 %t90, ptr %l47
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb29, label %ok.92
ok.92:
  store i64 %t89, ptr %l46
  br label %bb28
bb27:
  br label %bb36
bb28:
  %t93 = xor i64 0, -1
  store i64 %t93, ptr %l49, !tbaa !65
  %t94 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t95 = load i64, ptr %l46, !tbaa !24
  %t96 = load i64, ptr %l49, !tbaa !65
  %t97 = call { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %t94, i64 %t95, i64 %t96)
  %t98 = extractvalue { i32, i64 } %t97, 1
  %t99 = extractvalue { i32, i64 } %t97, 0
  store i32 %t99, ptr %l51
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb31, label %ok.101
ok.101:
  store i64 %t98, ptr %l50
  br label %bb30
bb29:
  %t102 = load i32, ptr %l47, !tbaa !23
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 0, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  store i32 %t110, ptr %l48, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i32, ptr %l48, !tbaa !23
  %t112 = insertvalue { i32, i64 } zeroinitializer, i32 %t111, 0
  store { i32, i64 } %t112, ptr %rv
  br label %ret
bb30:
  %t113 = load i64, ptr %l50, !tbaa !65
  store i64 %t113, ptr %l44, !tbaa !65
  br label %bb32
bb31:
  %t114 = load i32, ptr %l51, !tbaa !23
  %t115 = lshr i32 %t114, 16
  %t116 = and i32 %t114, 65535
  %t117 = icmp eq i32 %t115, 1
  %t118 = select i1 %t117, i32 1, i32 0
  %t119 = icmp eq i32 %t114, 0
  %t120 = shl i32 %t118, 16
  %t121 = or i32 %t120, %t116
  %t122 = select i1 %t119, i32 0, i32 %t121
  store i32 %t122, ptr %l52, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l52, !tbaa !23
  %t124 = insertvalue { i32, i64 } zeroinitializer, i32 %t123, 0
  store { i32, i64 } %t124, ptr %rv
  br label %ret
bb32:
  %t125 = load i64, ptr %l44, !tbaa !65
  store i64 %t125, ptr %l53, !tbaa !24
  %t126 = load i64, ptr %l53, !tbaa !24
  store i64 %t126, ptr %l4, !tbaa !24
  %t127 = load i1, ptr %l2, !tbaa !21
  store i1 %t127, ptr %l54, !tbaa !21
  %t128 = load i1, ptr %l54, !tbaa !21
  br i1 %t128, label %bb33, label %bb34
bb33:
  %t129 = load i64, ptr %l4, !tbaa !24
  store i64 %t129, ptr %l56, !tbaa !24
  %t130 = load i64, ptr %l56, !tbaa !24
  %t131 = sub i64 0, %t130
  store i64 %t131, ptr %l57, !tbaa !24
  %t132 = load i64, ptr %l57, !tbaa !24
  store i64 %t132, ptr %l55, !tbaa !24
  br label %bb35
bb34:
  %t133 = load i64, ptr %l4, !tbaa !24
  store i64 %t133, ptr %l58, !tbaa !24
  %t134 = load i64, ptr %l58, !tbaa !24
  store i64 %t134, ptr %l55, !tbaa !24
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t135 = load i64, ptr %l55, !tbaa !24
  %t136 = insertvalue { i32, i64 } zeroinitializer, i64 %t135, 1
  store { i32, i64 } %t136, ptr %rv
  br label %ret
bb36:
  %t137 = load i1, ptr %l2, !tbaa !21
  store i1 %t137, ptr %l59, !tbaa !21
  %t138 = load i1, ptr %l59, !tbaa !21
  br i1 %t138, label %bb37, label %bb38
bb37:
  %t139 = shl i64 1, 63
  store i64 %t139, ptr %l61, !tbaa !65
  %t140 = load i64, ptr %l61, !tbaa !65
  store i64 %t140, ptr %l60, !tbaa !65
  br label %bb39
bb38:
  %t141 = shl i64 1, 63
  store i64 %t141, ptr %l62, !tbaa !65
  %t142 = load i64, ptr %l62, !tbaa !65
  %t143 = sub i64 %t142, 1
  store i64 %t143, ptr %l63, !tbaa !65
  %t144 = load i64, ptr %l63, !tbaa !65
  store i64 %t144, ptr %l60, !tbaa !65
  br label %bb39
bb39:
  %t145 = load i64, ptr %l60, !tbaa !65
  store i64 %t145, ptr %l5, !tbaa !65
  %t146 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t146, ptr %l65, !tbaa !27
  %t147 = load i64, ptr %l1, !tbaa !24
  store i64 %t147, ptr %l66, !tbaa !24
  %t148 = load i64, ptr %l5, !tbaa !65
  store i64 %t148, ptr %l67, !tbaa !65
  %t149 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t150 = load i64, ptr %l66, !tbaa !24
  %t151 = load i64, ptr %l67, !tbaa !65
  %t152 = call { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %t149, i64 %t150, i64 %t151)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l69
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb41, label %ok.156
ok.156:
  store i64 %t153, ptr %l68
  br label %bb40
bb40:
  %t157 = load i64, ptr %l68, !tbaa !65
  store i64 %t157, ptr %l64, !tbaa !65
  br label %bb42
bb41:
  %t158 = load i32, ptr %l69, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  store i32 %t166, ptr %l70, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t167 = load i32, ptr %l70, !tbaa !23
  %t168 = insertvalue { i32, i64 } zeroinitializer, i32 %t167, 0
  store { i32, i64 } %t168, ptr %rv
  br label %ret
bb42:
  %t169 = load i64, ptr %l64, !tbaa !65
  store i64 %t169, ptr %l6, !tbaa !65
  %t170 = load i1, ptr %l2, !tbaa !21
  store i1 %t170, ptr %l71, !tbaa !21
  %t171 = load i1, ptr %l71, !tbaa !21
  br i1 %t171, label %bb43, label %bb44
bb43:
  %t172 = load i64, ptr %l6, !tbaa !65
  store i64 %t172, ptr %l73, !tbaa !65
  %t173 = load i64, ptr %l73, !tbaa !65
  store i64 %t173, ptr %l74, !tbaa !24
  %t174 = load i64, ptr %l74, !tbaa !24
  %t175 = sub i64 0, %t174
  store i64 %t175, ptr %l75, !tbaa !24
  %t176 = load i64, ptr %l75, !tbaa !24
  store i64 %t176, ptr %l72, !tbaa !24
  br label %bb45
bb44:
  %t177 = load i64, ptr %l6, !tbaa !65
  store i64 %t177, ptr %l76, !tbaa !65
  %t178 = load i64, ptr %l76, !tbaa !65
  store i64 %t178, ptr %l77, !tbaa !24
  %t179 = load i64, ptr %l77, !tbaa !24
  store i64 %t179, ptr %l72, !tbaa !24
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t180 = load i64, ptr %l72, !tbaa !24
  %t181 = insertvalue { i32, i64 } zeroinitializer, i64 %t180, 1
  store { i32, i64 } %t181, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i8
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l35 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l5, !tbaa !21
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i32 65536, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i32, ptr %l6, !tbaa !23
  %t8 = insertvalue { i32, i64 } zeroinitializer, i32 %t7, 0
  store { i32, i64 } %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 0
  %t13 = load i8, ptr %t12, !tbaa !32
  store i8 %t13, ptr %l8, !tbaa !22
  %t14 = load i8, ptr %l8, !tbaa !22
  %t15 = icmp eq i8 %t14, 43
  store i1 %t15, ptr %l9, !tbaa !21
  %t16 = load i1, ptr %l9, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t18, ptr %l12, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t19, ptr %l13, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l14, !tbaa !24
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = icmp sge i64 1, 0
  store i1 %t24, ptr %l16, !tbaa !21
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb5:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l20, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t28, ptr %l22, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l24, !tbaa !24
  %t33 = icmp sge i64 0, 0
  store i1 %t33, ptr %l25, !tbaa !21
  %t34 = load i1, ptr %l25, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb6:
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = icmp sle i64 1, %t35
  store i1 %t36, ptr %l17, !tbaa !21
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb8:
  %t38 = load i64, ptr %l14, !tbaa !24
  %t39 = load i64, ptr %l15, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  store i1 %t40, ptr %l18, !tbaa !21
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb10:
  %t42 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l14, !tbaa !24
  %t45 = getelementptr i8, ptr %t43, i64 1
  %t46 = sub i64 %t44, 1
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l19, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t49, ptr %l10, !tbaa !27
  br label %bb18
bb11:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb12:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = icmp sle i64 0, %t50
  store i1 %t51, ptr %l26, !tbaa !21
  %t52 = load i1, ptr %l26, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb14:
  %t53 = load i64, ptr %l23, !tbaa !24
  %t54 = load i64, ptr %l24, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  store i1 %t55, ptr %l27, !tbaa !21
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb16:
  %t57 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l23, !tbaa !24
  %t60 = getelementptr i8, ptr %t58, i64 0
  %t61 = sub i64 %t59, 0
  %t62 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  store { i64, ptr } %t63, ptr %l28, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t64, ptr %l10, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb18:
  %t65 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t65, ptr %l2, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l30, !tbaa !27
  %t67 = load i64, ptr %l1, !tbaa !24
  store i64 %t67, ptr %l31, !tbaa !24
  %t68 = xor i64 0, -1
  store i64 %t68, ptr %l32, !tbaa !65
  %t69 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t70 = load i64, ptr %l31, !tbaa !24
  %t71 = load i64, ptr %l32, !tbaa !65
  %t72 = call { i32, i64 } @std_2fprelude_2ftext_2ereadDigits(ptr %v0, { i64, ptr } %t69, i64 %t70, i64 %t71)
  %t73 = extractvalue { i32, i64 } %t72, 1
  %t74 = extractvalue { i32, i64 } %t72, 0
  store i32 %t74, ptr %l34
  %t75 = icmp ne i32 %t74, 0
  br i1 %t75, label %bb20, label %ok.76
ok.76:
  store i64 %t73, ptr %l33
  br label %bb19
bb19:
  %t77 = load i64, ptr %l33, !tbaa !65
  store i64 %t77, ptr %l29, !tbaa !65
  br label %bb21
bb20:
  %t78 = load i32, ptr %l34, !tbaa !23
  %t79 = lshr i32 %t78, 16
  %t80 = and i32 %t78, 65535
  %t81 = icmp eq i32 %t79, 1
  %t82 = select i1 %t81, i32 1, i32 0
  %t83 = icmp eq i32 %t78, 0
  %t84 = shl i32 %t82, 16
  %t85 = or i32 %t84, %t80
  %t86 = select i1 %t83, i32 0, i32 %t85
  store i32 %t86, ptr %l35, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i32, ptr %l35, !tbaa !23
  %t88 = insertvalue { i32, i64 } zeroinitializer, i32 %t87, 0
  store { i32, i64 } %t88, ptr %rv
  br label %ret
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load i64, ptr %l29, !tbaa !65
  %t90 = insertvalue { i32, i64 } zeroinitializer, i64 %t89, 1
  store { i32, i64 } %t90, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i8
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i1
  %l87 = alloca { i64, ptr }
  %l88 = alloca i8
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i8
  %l99 = alloca i8
  %l100 = alloca i8
  %l101 = alloca i1
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i1
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i1
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca i8
  %l140 = alloca i8
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l143 = alloca i64
  %l144 = alloca { i64, ptr }
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca i1
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca { i64, ptr }
  %l161 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i1
  %l167 = alloca i1
  %l168 = alloca i1
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i32
  %l177 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i1
  %l185 = alloca i1
  %l186 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l188 = alloca i64
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i64
  %l192 = alloca i1
  %l193 = alloca i64
  %l194 = alloca i64
  %l195 = alloca i1
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i64
  %l203 = alloca i64
  %l204 = alloca i64
  %l205 = alloca i64
  %l206 = alloca i64
  %l207 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i64
  %l210 = alloca i64
  %l211 = alloca i64
  %l212 = alloca i64
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l217 = alloca i64
  %l218 = alloca i64
  %l219 = alloca i32
  %l220 = alloca { i64, ptr }
  %l221 = alloca i64
  %l222 = alloca { i64, ptr }
  %l223 = alloca i64
  %l224 = alloca i64
  %l225 = alloca i64
  %l226 = alloca i1
  %l227 = alloca i1
  %l228 = alloca i1
  %l229 = alloca { i64, ptr }
  %l230 = alloca i64
  %l231 = alloca { i64, ptr }
  %l232 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca i64
  %l236 = alloca { i64, ptr }
  %l237 = alloca i64
  %l238 = alloca i64
  %l239 = alloca { i64, ptr }
  %l240 = alloca i64
  %l241 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l243 = alloca i64
  %l244 = alloca i64
  %l245 = alloca i1
  %l246 = alloca i1
  %l247 = alloca i1
  %l248 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l35, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l36, !tbaa !24
  %t4 = load i64, ptr %l36, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l37, !tbaa !21
  %t6 = load i1, ptr %l37, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l38, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l39, !tbaa !24
  %t10 = load i64, ptr %l39, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  store i1 %t11, ptr %l40, !tbaa !21
  %t12 = load i1, ptr %l40, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb2:
  br label %bb25
bb3:
  %t13 = load i64, ptr %l39, !tbaa !24
  %t14 = icmp sle i64 %t13, 576460752303423487
  store i1 %t14, ptr %l41, !tbaa !21
  %t15 = load i1, ptr %l41, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb5:
  %t16 = load i64, ptr %l39, !tbaa !24
  %t17 = mul i64 %t16, 16
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l42, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 16
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l43, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l3, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l44, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l45, !tbaa !24
  %t32 = load i64, ptr %l45, !tbaa !24
  store i64 %t32, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  store i64 %t33, ptr %l46, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l47, !tbaa !24
  %t35 = load i64, ptr %l46, !tbaa !24
  %t36 = load i64, ptr %l47, !tbaa !24
  %t37 = icmp sgt i64 %t35, %t36
  store i1 %t37, ptr %l48, !tbaa !21
  %t38 = load i1, ptr %l48, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb7:
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l50, !tbaa !24
  %t40 = load i64, ptr %l50, !tbaa !24
  %t41 = icmp sgt i64 %t40, 0
  store i1 %t41, ptr %l51, !tbaa !21
  %t42 = load i1, ptr %l51, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb12
bb9:
  %t43 = load i64, ptr %l4, !tbaa !24
  store i64 %t43, ptr %l53, !tbaa !24
  %t44 = load i64, ptr %l3, !tbaa !24
  store i64 %t44, ptr %l54, !tbaa !24
  %t45 = load i64, ptr %l53, !tbaa !24
  %t46 = load i64, ptr %l54, !tbaa !24
  %t47 = sub i64 %t45, %t46
  store i64 %t47, ptr %l55, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l56, !tbaa !24
  %t49 = load i64, ptr %l55, !tbaa !24
  %t50 = load i64, ptr %l56, !tbaa !24
  %t51 = add i64 %t49, %t50
  store i64 %t51, ptr %l57, !tbaa !24
  %t52 = load i64, ptr %l57, !tbaa !24
  %t53 = sub i64 %t52, 1
  store i64 %t53, ptr %l58, !tbaa !24
  %t54 = load i64, ptr %l5, !tbaa !24
  store i64 %t54, ptr %l59, !tbaa !24
  %t55 = load i64, ptr %l58, !tbaa !24
  %t56 = load i64, ptr %l59, !tbaa !24
  %t57 = sdiv i64 %t55, %t56
  store i64 %t57, ptr %l60, !tbaa !24
  %t58 = load i64, ptr %l60, !tbaa !24
  store i64 %t58, ptr %l52, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb11
bb11:
  %t59 = load i64, ptr %l52, !tbaa !24
  store i64 %t59, ptr %l49, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l49, !tbaa !24
  store i64 %t60, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load i64, ptr %l7, !tbaa !24
  store i64 %t61, ptr %l61, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l62, !tbaa !24
  %t63 = load i64, ptr %l61, !tbaa !24
  %t64 = load i64, ptr %l62, !tbaa !24
  %t65 = icmp slt i64 %t63, %t64
  store i1 %t65, ptr %l63, !tbaa !21
  %t66 = load i1, ptr %l63, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l64, !tbaa !21
  %t68 = load i1, ptr %l64, !tbaa !21
  br i1 %t68, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t69 = load i64, ptr %l3, !tbaa !24
  store i64 %t69, ptr %l65, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  store i64 %t70, ptr %l66, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  store i64 %t71, ptr %l67, !tbaa !24
  %t72 = load i64, ptr %l66, !tbaa !24
  %t73 = load i64, ptr %l67, !tbaa !24
  %t74 = mul i64 %t72, %t73
  store i64 %t74, ptr %l68, !tbaa !24
  %t75 = load i64, ptr %l65, !tbaa !24
  %t76 = load i64, ptr %l68, !tbaa !24
  %t77 = add i64 %t75, %t76
  store i64 %t77, ptr %l69, !tbaa !24
  %t78 = load i64, ptr %l69, !tbaa !24
  store i64 %t78, ptr %l8, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t79, ptr %l70, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  store i64 %t80, ptr %l71, !tbaa !24
  %t81 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t81, ptr %l72, !tbaa !27
  %t82 = load i64, ptr %l8, !tbaa !24
  store i64 %t82, ptr %l73, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  store i64 %t83, ptr %l74, !tbaa !24
  %t84 = load i64, ptr %l74, !tbaa !24
  %t85 = add i64 %t84, 1
  store i64 %t85, ptr %l75, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 0
  store i64 %t87, ptr %l76, !tbaa !24
  %t88 = load i64, ptr %l73, !tbaa !24
  %t89 = icmp sge i64 %t88, 0
  store i1 %t89, ptr %l77, !tbaa !21
  %t90 = load i1, ptr %l77, !tbaa !21
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t91 = load i64, ptr %l73, !tbaa !24
  %t92 = load i64, ptr %l75, !tbaa !24
  %t93 = icmp sle i64 %t91, %t92
  store i1 %t93, ptr %l78, !tbaa !21
  %t94 = load i1, ptr %l78, !tbaa !21
  br i1 %t94, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb19:
  %t95 = load i64, ptr %l75, !tbaa !24
  %t96 = load i64, ptr %l76, !tbaa !24
  %t97 = icmp sle i64 %t95, %t96
  store i1 %t97, ptr %l79, !tbaa !21
  %t98 = load i1, ptr %l79, !tbaa !21
  br i1 %t98, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb21:
  %t99 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = load i64, ptr %l73, !tbaa !24
  %t102 = load i64, ptr %l75, !tbaa !24
  %t103 = getelementptr i8, ptr %t100, i64 %t101
  %t104 = sub i64 %t102, %t101
  %t105 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  store { i64, ptr } %t106, ptr %l80, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t108 = load i64, ptr %l71, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %t110, i64 %t108
  store { i64, ptr } %t107, ptr %t111, !tbaa !37
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @.c15)
  unreachable
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t112 = load i64, ptr %l7, !tbaa !24
  store i64 %t112, ptr %l81, !tbaa !24
  %t113 = load i64, ptr %l81, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l82, !tbaa !24
  %t115 = load i64, ptr %l82, !tbaa !24
  store i64 %t115, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb24:
  call void @__olang_scope_close(ptr %s2)
  %t116 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t116, ptr %l83, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t117, ptr %rv
  br label %ret
bb25:
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t118, ptr %l84, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l85, !tbaa !24
  %t121 = load i64, ptr %l85, !tbaa !24
  %t122 = icmp eq i64 %t121, 1
  store i1 %t122, ptr %l86, !tbaa !21
  %t123 = load i1, ptr %l86, !tbaa !21
  br i1 %t123, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t124 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t124, ptr %l87, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i8, ptr %t126, i64 0
  %t128 = load i8, ptr %t127, !tbaa !32
  store i8 %t128, ptr %l88, !tbaa !22
  %t129 = load i8, ptr %l88, !tbaa !22
  store i8 %t129, ptr %l9, !tbaa !22
  store i64 1, ptr %l10, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  %t130 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t130, ptr %l89, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t131, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t132, ptr %l90, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l91, !tbaa !24
  %t135 = load i64, ptr %l91, !tbaa !24
  store i64 %t135, ptr %l13, !tbaa !24
  br label %bb28
bb27:
  br label %bb68
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t136 = load i64, ptr %l12, !tbaa !24
  store i64 %t136, ptr %l92, !tbaa !24
  %t137 = load i64, ptr %l13, !tbaa !24
  store i64 %t137, ptr %l93, !tbaa !24
  %t138 = load i64, ptr %l92, !tbaa !24
  %t139 = load i64, ptr %l93, !tbaa !24
  %t140 = icmp slt i64 %t138, %t139
  store i1 %t140, ptr %l94, !tbaa !21
  %t141 = load i1, ptr %l94, !tbaa !21
  %t142 = xor i1 %t141, true
  store i1 %t142, ptr %l95, !tbaa !21
  %t143 = load i1, ptr %l95, !tbaa !21
  br i1 %t143, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb30:
  br label %bb31
bb31:
  %t144 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t144, ptr %l96, !tbaa !27
  %t145 = load i64, ptr %l12, !tbaa !24
  store i64 %t145, ptr %l97, !tbaa !24
  %t146 = load i64, ptr %l97, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t146
  %t150 = load i8, ptr %t149, !tbaa !32
  store i8 %t150, ptr %l98, !tbaa !22
  %t151 = load i8, ptr %l98, !tbaa !22
  store i8 %t151, ptr %l14, !tbaa !22
  %t152 = load i8, ptr %l14, !tbaa !22
  store i8 %t152, ptr %l99, !tbaa !22
  %t153 = load i8, ptr %l9, !tbaa !22
  store i8 %t153, ptr %l100, !tbaa !22
  %t154 = load i8, ptr %l99, !tbaa !22
  %t155 = load i8, ptr %l100, !tbaa !22
  %t156 = icmp eq i8 %t154, %t155
  store i1 %t156, ptr %l101, !tbaa !21
  %t157 = load i1, ptr %l101, !tbaa !21
  br i1 %t157, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t158 = load i64, ptr %l10, !tbaa !24
  store i64 %t158, ptr %l102, !tbaa !24
  %t159 = load i64, ptr %l102, !tbaa !24
  %t160 = add i64 %t159, 1
  store i64 %t160, ptr %l103, !tbaa !24
  %t161 = load i64, ptr %l103, !tbaa !24
  store i64 %t161, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  %t162 = load i64, ptr %l12, !tbaa !24
  store i64 %t162, ptr %l104, !tbaa !24
  %t163 = load i64, ptr %l104, !tbaa !24
  %t164 = add i64 %t163, 1
  store i64 %t164, ptr %l105, !tbaa !24
  %t165 = load i64, ptr %l105, !tbaa !24
  store i64 %t165, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb36:
  call void @__olang_scope_close(ptr %s6)
  %t166 = load i64, ptr %l10, !tbaa !24
  store i64 %t166, ptr %l106, !tbaa !24
  %t167 = load i64, ptr %l106, !tbaa !24
  %t168 = icmp sge i64 %t167, 0
  store i1 %t168, ptr %l107, !tbaa !21
  %t169 = load i1, ptr %l107, !tbaa !21
  br i1 %t169, label %bb37, label %bb38
bb37:
  %t170 = load i64, ptr %l106, !tbaa !24
  %t171 = icmp sle i64 %t170, 576460752303423487
  store i1 %t171, ptr %l108, !tbaa !21
  %t172 = load i1, ptr %l108, !tbaa !21
  br i1 %t172, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb39:
  %t173 = load i64, ptr %l106, !tbaa !24
  %t174 = mul i64 %t173, 16
  %t175 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  store { i64, ptr } %t177, ptr %l109, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 16
  %t182 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l110, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t185, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s10
  store i64 0, ptr %l18, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t186, ptr %l111, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l112, !tbaa !24
  %t189 = load i64, ptr %l112, !tbaa !24
  store i64 %t189, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t190 = load i64, ptr %l19, !tbaa !24
  store i64 %t190, ptr %l113, !tbaa !24
  %t191 = load i64, ptr %l18, !tbaa !24
  store i64 %t191, ptr %l114, !tbaa !24
  %t192 = load i64, ptr %l113, !tbaa !24
  %t193 = load i64, ptr %l114, !tbaa !24
  %t194 = icmp sgt i64 %t192, %t193
  store i1 %t194, ptr %l115, !tbaa !21
  %t195 = load i1, ptr %l115, !tbaa !21
  br i1 %t195, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @.c16)
  unreachable
bb41:
  %t196 = load i64, ptr %l20, !tbaa !24
  store i64 %t196, ptr %l117, !tbaa !24
  %t197 = load i64, ptr %l117, !tbaa !24
  %t198 = icmp sgt i64 %t197, 0
  store i1 %t198, ptr %l118, !tbaa !21
  %t199 = load i1, ptr %l118, !tbaa !21
  br i1 %t199, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb46
bb43:
  %t200 = load i64, ptr %l19, !tbaa !24
  store i64 %t200, ptr %l120, !tbaa !24
  %t201 = load i64, ptr %l18, !tbaa !24
  store i64 %t201, ptr %l121, !tbaa !24
  %t202 = load i64, ptr %l120, !tbaa !24
  %t203 = load i64, ptr %l121, !tbaa !24
  %t204 = sub i64 %t202, %t203
  store i64 %t204, ptr %l122, !tbaa !24
  %t205 = load i64, ptr %l20, !tbaa !24
  store i64 %t205, ptr %l123, !tbaa !24
  %t206 = load i64, ptr %l122, !tbaa !24
  %t207 = load i64, ptr %l123, !tbaa !24
  %t208 = add i64 %t206, %t207
  store i64 %t208, ptr %l124, !tbaa !24
  %t209 = load i64, ptr %l124, !tbaa !24
  %t210 = sub i64 %t209, 1
  store i64 %t210, ptr %l125, !tbaa !24
  %t211 = load i64, ptr %l20, !tbaa !24
  store i64 %t211, ptr %l126, !tbaa !24
  %t212 = load i64, ptr %l125, !tbaa !24
  %t213 = load i64, ptr %l126, !tbaa !24
  %t214 = sdiv i64 %t212, %t213
  store i64 %t214, ptr %l127, !tbaa !24
  %t215 = load i64, ptr %l127, !tbaa !24
  store i64 %t215, ptr %l119, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l119, !tbaa !24
  br label %bb45
bb45:
  %t216 = load i64, ptr %l119, !tbaa !24
  store i64 %t216, ptr %l116, !tbaa !24
  br label %bb46
bb46:
  %t217 = load i64, ptr %l116, !tbaa !24
  store i64 %t217, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t218 = load i64, ptr %l22, !tbaa !24
  store i64 %t218, ptr %l128, !tbaa !24
  %t219 = load i64, ptr %l21, !tbaa !24
  store i64 %t219, ptr %l129, !tbaa !24
  %t220 = load i64, ptr %l128, !tbaa !24
  %t221 = load i64, ptr %l129, !tbaa !24
  %t222 = icmp slt i64 %t220, %t221
  store i1 %t222, ptr %l130, !tbaa !21
  %t223 = load i1, ptr %l130, !tbaa !21
  %t224 = xor i1 %t223, true
  store i1 %t224, ptr %l131, !tbaa !21
  %t225 = load i1, ptr %l131, !tbaa !21
  br i1 %t225, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s11)
  br label %bb61
bb49:
  br label %bb50
bb50:
  %t226 = load i64, ptr %l18, !tbaa !24
  store i64 %t226, ptr %l132, !tbaa !24
  %t227 = load i64, ptr %l22, !tbaa !24
  store i64 %t227, ptr %l133, !tbaa !24
  %t228 = load i64, ptr %l20, !tbaa !24
  store i64 %t228, ptr %l134, !tbaa !24
  %t229 = load i64, ptr %l133, !tbaa !24
  %t230 = load i64, ptr %l134, !tbaa !24
  %t231 = mul i64 %t229, %t230
  store i64 %t231, ptr %l135, !tbaa !24
  %t232 = load i64, ptr %l132, !tbaa !24
  %t233 = load i64, ptr %l135, !tbaa !24
  %t234 = add i64 %t232, %t233
  store i64 %t234, ptr %l136, !tbaa !24
  %t235 = load i64, ptr %l136, !tbaa !24
  store i64 %t235, ptr %l23, !tbaa !24
  %t236 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t236, ptr %l137, !tbaa !27
  %t237 = load i64, ptr %l23, !tbaa !24
  store i64 %t237, ptr %l138, !tbaa !24
  %t238 = load i64, ptr %l138, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i8, ptr %t240, i64 %t238
  %t242 = load i8, ptr %t241, !tbaa !32
  store i8 %t242, ptr %l139, !tbaa !22
  %t243 = load i8, ptr %l9, !tbaa !22
  store i8 %t243, ptr %l140, !tbaa !22
  %t244 = load i8, ptr %l139, !tbaa !22
  %t245 = load i8, ptr %l140, !tbaa !22
  %t246 = icmp eq i8 %t244, %t245
  store i1 %t246, ptr %l141, !tbaa !21
  %t247 = load i1, ptr %l141, !tbaa !21
  br i1 %t247, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s12
  %t248 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t248, ptr %l142, !tbaa !27
  %t249 = load i64, ptr %l16, !tbaa !24
  store i64 %t249, ptr %l143, !tbaa !24
  %t250 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t250, ptr %l144, !tbaa !27
  %t251 = load i64, ptr %l17, !tbaa !24
  store i64 %t251, ptr %l145, !tbaa !24
  %t252 = load i64, ptr %l23, !tbaa !24
  store i64 %t252, ptr %l146, !tbaa !24
  %t253 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 0
  store i64 %t254, ptr %l147, !tbaa !24
  %t255 = load i64, ptr %l145, !tbaa !24
  %t256 = icmp sge i64 %t255, 0
  store i1 %t256, ptr %l148, !tbaa !21
  %t257 = load i1, ptr %l148, !tbaa !21
  br i1 %t257, label %bb53, label %bb54
bb52:
  br label %bb59
bb53:
  %t258 = load i64, ptr %l145, !tbaa !24
  %t259 = load i64, ptr %l146, !tbaa !24
  %t260 = icmp sle i64 %t258, %t259
  store i1 %t260, ptr %l149, !tbaa !21
  %t261 = load i1, ptr %l149, !tbaa !21
  br i1 %t261, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb55:
  %t262 = load i64, ptr %l146, !tbaa !24
  %t263 = load i64, ptr %l147, !tbaa !24
  %t264 = icmp sle i64 %t262, %t263
  store i1 %t264, ptr %l150, !tbaa !21
  %t265 = load i1, ptr %l150, !tbaa !21
  br i1 %t265, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb57:
  %t266 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = load i64, ptr %l145, !tbaa !24
  %t269 = load i64, ptr %l146, !tbaa !24
  %t270 = getelementptr i8, ptr %t267, i64 %t268
  %t271 = sub i64 %t269, %t268
  %t272 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t270, 1
  store { i64, ptr } %t273, ptr %l151, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t275 = load i64, ptr %l143, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %t277, i64 %t275
  store { i64, ptr } %t274, ptr %t278, !tbaa !37
  %t279 = load i64, ptr %l16, !tbaa !24
  store i64 %t279, ptr %l152, !tbaa !24
  %t280 = load i64, ptr %l152, !tbaa !24
  %t281 = add i64 %t280, 1
  store i64 %t281, ptr %l153, !tbaa !24
  %t282 = load i64, ptr %l153, !tbaa !24
  store i64 %t282, ptr %l16, !tbaa !24
  %t283 = load i64, ptr %l23, !tbaa !24
  store i64 %t283, ptr %l154, !tbaa !24
  %t284 = load i64, ptr %l154, !tbaa !24
  %t285 = add i64 %t284, 1
  store i64 %t285, ptr %l155, !tbaa !24
  %t286 = load i64, ptr %l155, !tbaa !24
  store i64 %t286, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @.c17)
  unreachable
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s13
  %t287 = load i64, ptr %l22, !tbaa !24
  store i64 %t287, ptr %l156, !tbaa !24
  %t288 = load i64, ptr %l156, !tbaa !24
  %t289 = add i64 %t288, 1
  store i64 %t289, ptr %l157, !tbaa !24
  %t290 = load i64, ptr %l157, !tbaa !24
  store i64 %t290, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb47
bb61:
  call void @__olang_scope_close(ptr %s10)
  %t291 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t291, ptr %l158, !tbaa !27
  %t292 = load i64, ptr %l16, !tbaa !24
  store i64 %t292, ptr %l159, !tbaa !24
  %t293 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t293, ptr %l160, !tbaa !27
  %t294 = load i64, ptr %l17, !tbaa !24
  store i64 %t294, ptr %l161, !tbaa !24
  %t295 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t295, ptr %l162, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t296, ptr %l163, !tbaa !27
  %t297 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t298 = extractvalue { i64, ptr } %t297, 0
  store i64 %t298, ptr %l164, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  store i64 %t300, ptr %l165, !tbaa !24
  %t301 = load i64, ptr %l161, !tbaa !24
  %t302 = icmp sge i64 %t301, 0
  store i1 %t302, ptr %l166, !tbaa !21
  %t303 = load i1, ptr %l166, !tbaa !21
  br i1 %t303, label %bb62, label %bb63
bb62:
  %t304 = load i64, ptr %l161, !tbaa !24
  %t305 = load i64, ptr %l164, !tbaa !24
  %t306 = icmp sle i64 %t304, %t305
  store i1 %t306, ptr %l167, !tbaa !21
  %t307 = load i1, ptr %l167, !tbaa !21
  br i1 %t307, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb64:
  %t308 = load i64, ptr %l164, !tbaa !24
  %t309 = load i64, ptr %l165, !tbaa !24
  %t310 = icmp sle i64 %t308, %t309
  store i1 %t310, ptr %l168, !tbaa !21
  %t311 = load i1, ptr %l168, !tbaa !21
  br i1 %t311, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb66:
  %t312 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = load i64, ptr %l161, !tbaa !24
  %t315 = load i64, ptr %l164, !tbaa !24
  %t316 = getelementptr i8, ptr %t313, i64 %t314
  %t317 = sub i64 %t315, %t314
  %t318 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t319 = insertvalue { i64, ptr } %t318, ptr %t316, 1
  store { i64, ptr } %t319, ptr %l169, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t321 = load i64, ptr %l159, !tbaa !24
  %t322 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %t323, i64 %t321
  store { i64, ptr } %t320, ptr %t324, !tbaa !37
  %t325 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t325, ptr %l170, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t326 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t326, ptr %rv
  br label %ret
bb67:
  call void @__olang_check_failed(ptr @.c18)
  unreachable
bb68:
  store i64 1, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t327 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t327, ptr %l172, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t328, ptr %l173, !tbaa !27
  %t329 = load i64, ptr %l25, !tbaa !24
  store i64 %t329, ptr %l174, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t332 = load i64, ptr %l174, !tbaa !24
  %t333 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2efindFrom(ptr %v0, ptr %v1, { i64, ptr } %t330, { i64, ptr } %t331, i64 %t332)
  %t334 = extractvalue { i32, i64 } %t333, 1
  %t335 = extractvalue { i32, i64 } %t333, 0
  store i32 %t335, ptr %l176
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb71, label %ok.337
ok.337:
  store i64 %t334, ptr %l175
  br label %bb70
bb70:
  %t338 = load i64, ptr %l175, !tbaa !24
  store i64 %t338, ptr %l171, !tbaa !24
  br label %bb73
bb71:
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s15
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  br label %bb75
bb73:
  %t339 = load i64, ptr %l171, !tbaa !24
  store i64 %t339, ptr %l26, !tbaa !24
  %t340 = load i64, ptr %l24, !tbaa !24
  store i64 %t340, ptr %l177, !tbaa !24
  %t341 = load i64, ptr %l177, !tbaa !24
  %t342 = add i64 %t341, 1
  store i64 %t342, ptr %l178, !tbaa !24
  %t343 = load i64, ptr %l178, !tbaa !24
  store i64 %t343, ptr %l24, !tbaa !24
  %t344 = load i64, ptr %l26, !tbaa !24
  store i64 %t344, ptr %l179, !tbaa !24
  %t345 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t345, ptr %l180, !tbaa !27
  %t346 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  store i64 %t347, ptr %l181, !tbaa !24
  %t348 = load i64, ptr %l179, !tbaa !24
  %t349 = load i64, ptr %l181, !tbaa !24
  %t350 = add i64 %t348, %t349
  store i64 %t350, ptr %l182, !tbaa !24
  %t351 = load i64, ptr %l182, !tbaa !24
  store i64 %t351, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb74
bb74:
  br label %bb69
bb75:
  %t352 = load i64, ptr %l24, !tbaa !24
  store i64 %t352, ptr %l183, !tbaa !24
  %t353 = load i64, ptr %l183, !tbaa !24
  %t354 = icmp sge i64 %t353, 0
  store i1 %t354, ptr %l184, !tbaa !21
  %t355 = load i1, ptr %l184, !tbaa !21
  br i1 %t355, label %bb76, label %bb77
bb76:
  %t356 = load i64, ptr %l183, !tbaa !24
  %t357 = icmp sle i64 %t356, 576460752303423487
  store i1 %t357, ptr %l185, !tbaa !21
  %t358 = load i1, ptr %l185, !tbaa !21
  br i1 %t358, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb78:
  %t359 = load i64, ptr %l183, !tbaa !24
  %t360 = mul i64 %t359, 16
  %t361 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t360)
  %t362 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  store { i64, ptr } %t363, ptr %l186, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 16
  %t368 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  store { i64, ptr } %t370, ptr %l187, !tbaa !27
  %t371 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t371, ptr %l27, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s16
  store i64 0, ptr %l28, !tbaa !24
  %t372 = load i64, ptr %l24, !tbaa !24
  store i64 %t372, ptr %l188, !tbaa !24
  %t373 = load i64, ptr %l188, !tbaa !24
  %t374 = sub i64 %t373, 1
  store i64 %t374, ptr %l189, !tbaa !24
  %t375 = load i64, ptr %l189, !tbaa !24
  store i64 %t375, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t376 = load i64, ptr %l29, !tbaa !24
  store i64 %t376, ptr %l190, !tbaa !24
  %t377 = load i64, ptr %l28, !tbaa !24
  store i64 %t377, ptr %l191, !tbaa !24
  %t378 = load i64, ptr %l190, !tbaa !24
  %t379 = load i64, ptr %l191, !tbaa !24
  %t380 = icmp sgt i64 %t378, %t379
  store i1 %t380, ptr %l192, !tbaa !21
  %t381 = load i1, ptr %l192, !tbaa !21
  br i1 %t381, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb80:
  %t382 = load i64, ptr %l30, !tbaa !24
  store i64 %t382, ptr %l194, !tbaa !24
  %t383 = load i64, ptr %l194, !tbaa !24
  %t384 = icmp sgt i64 %t383, 0
  store i1 %t384, ptr %l195, !tbaa !21
  %t385 = load i1, ptr %l195, !tbaa !21
  br i1 %t385, label %bb82, label %bb83
bb81:
  store i64 0, ptr %l193, !tbaa !24
  br label %bb85
bb82:
  %t386 = load i64, ptr %l29, !tbaa !24
  store i64 %t386, ptr %l197, !tbaa !24
  %t387 = load i64, ptr %l28, !tbaa !24
  store i64 %t387, ptr %l198, !tbaa !24
  %t388 = load i64, ptr %l197, !tbaa !24
  %t389 = load i64, ptr %l198, !tbaa !24
  %t390 = sub i64 %t388, %t389
  store i64 %t390, ptr %l199, !tbaa !24
  %t391 = load i64, ptr %l30, !tbaa !24
  store i64 %t391, ptr %l200, !tbaa !24
  %t392 = load i64, ptr %l199, !tbaa !24
  %t393 = load i64, ptr %l200, !tbaa !24
  %t394 = add i64 %t392, %t393
  store i64 %t394, ptr %l201, !tbaa !24
  %t395 = load i64, ptr %l201, !tbaa !24
  %t396 = sub i64 %t395, 1
  store i64 %t396, ptr %l202, !tbaa !24
  %t397 = load i64, ptr %l30, !tbaa !24
  store i64 %t397, ptr %l203, !tbaa !24
  %t398 = load i64, ptr %l202, !tbaa !24
  %t399 = load i64, ptr %l203, !tbaa !24
  %t400 = sdiv i64 %t398, %t399
  store i64 %t400, ptr %l204, !tbaa !24
  %t401 = load i64, ptr %l204, !tbaa !24
  store i64 %t401, ptr %l196, !tbaa !24
  br label %bb84
bb83:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb84
bb84:
  %t402 = load i64, ptr %l196, !tbaa !24
  store i64 %t402, ptr %l193, !tbaa !24
  br label %bb85
bb85:
  %t403 = load i64, ptr %l193, !tbaa !24
  store i64 %t403, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb86
bb86:
  store %olang.scope zeroinitializer, ptr %s17
  %t404 = load i64, ptr %l32, !tbaa !24
  store i64 %t404, ptr %l205, !tbaa !24
  %t405 = load i64, ptr %l31, !tbaa !24
  store i64 %t405, ptr %l206, !tbaa !24
  %t406 = load i64, ptr %l205, !tbaa !24
  %t407 = load i64, ptr %l206, !tbaa !24
  %t408 = icmp slt i64 %t406, %t407
  store i1 %t408, ptr %l207, !tbaa !21
  %t409 = load i1, ptr %l207, !tbaa !21
  %t410 = xor i1 %t409, true
  store i1 %t410, ptr %l208, !tbaa !21
  %t411 = load i1, ptr %l208, !tbaa !21
  br i1 %t411, label %bb87, label %bb88
bb87:
  call void @__olang_scope_close(ptr %s17)
  br label %bb101
bb88:
  br label %bb89
bb89:
  %t412 = load i64, ptr %l28, !tbaa !24
  store i64 %t412, ptr %l209, !tbaa !24
  %t413 = load i64, ptr %l32, !tbaa !24
  store i64 %t413, ptr %l210, !tbaa !24
  %t414 = load i64, ptr %l30, !tbaa !24
  store i64 %t414, ptr %l211, !tbaa !24
  %t415 = load i64, ptr %l210, !tbaa !24
  %t416 = load i64, ptr %l211, !tbaa !24
  %t417 = mul i64 %t415, %t416
  store i64 %t417, ptr %l212, !tbaa !24
  %t418 = load i64, ptr %l209, !tbaa !24
  %t419 = load i64, ptr %l212, !tbaa !24
  %t420 = add i64 %t418, %t419
  store i64 %t420, ptr %l213, !tbaa !24
  %t421 = load i64, ptr %l213, !tbaa !24
  store i64 %t421, ptr %l33, !tbaa !24
  %t422 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t422, ptr %l215, !tbaa !27
  %t423 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t423, ptr %l216, !tbaa !27
  %t424 = load i64, ptr %l25, !tbaa !24
  store i64 %t424, ptr %l217, !tbaa !24
  %t425 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t426 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t427 = load i64, ptr %l217, !tbaa !24
  %t428 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2efindFrom(ptr %v0, ptr %v1, { i64, ptr } %t425, { i64, ptr } %t426, i64 %t427)
  %t429 = extractvalue { i32, i64 } %t428, 1
  %t430 = extractvalue { i32, i64 } %t428, 0
  store i32 %t430, ptr %l219
  %t431 = icmp ne i32 %t430, 0
  br i1 %t431, label %bb91, label %ok.432
ok.432:
  store i64 %t429, ptr %l218
  br label %bb90
bb90:
  %t433 = load i64, ptr %l218, !tbaa !24
  store i64 %t433, ptr %l214, !tbaa !24
  br label %bb93
bb91:
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s18
  call void @__olang_check_failed(ptr @.c20)
  unreachable
bb93:
  %t434 = load i64, ptr %l214, !tbaa !24
  store i64 %t434, ptr %l34, !tbaa !24
  %t435 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t435, ptr %l220, !tbaa !27
  %t436 = load i64, ptr %l33, !tbaa !24
  store i64 %t436, ptr %l221, !tbaa !24
  %t437 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t437, ptr %l222, !tbaa !27
  %t438 = load i64, ptr %l25, !tbaa !24
  store i64 %t438, ptr %l223, !tbaa !24
  %t439 = load i64, ptr %l34, !tbaa !24
  store i64 %t439, ptr %l224, !tbaa !24
  %t440 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 0
  store i64 %t441, ptr %l225, !tbaa !24
  %t442 = load i64, ptr %l223, !tbaa !24
  %t443 = icmp sge i64 %t442, 0
  store i1 %t443, ptr %l226, !tbaa !21
  %t444 = load i1, ptr %l226, !tbaa !21
  br i1 %t444, label %bb94, label %bb95
bb94:
  %t445 = load i64, ptr %l223, !tbaa !24
  %t446 = load i64, ptr %l224, !tbaa !24
  %t447 = icmp sle i64 %t445, %t446
  store i1 %t447, ptr %l227, !tbaa !21
  %t448 = load i1, ptr %l227, !tbaa !21
  br i1 %t448, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb96:
  %t449 = load i64, ptr %l224, !tbaa !24
  %t450 = load i64, ptr %l225, !tbaa !24
  %t451 = icmp sle i64 %t449, %t450
  store i1 %t451, ptr %l228, !tbaa !21
  %t452 = load i1, ptr %l228, !tbaa !21
  br i1 %t452, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb98:
  %t453 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = load i64, ptr %l223, !tbaa !24
  %t456 = load i64, ptr %l224, !tbaa !24
  %t457 = getelementptr i8, ptr %t454, i64 %t455
  %t458 = sub i64 %t456, %t455
  %t459 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t457, 1
  store { i64, ptr } %t460, ptr %l229, !tbaa !27
  %t461 = load { i64, ptr }, ptr %l229, !tbaa !27
  %t462 = load i64, ptr %l221, !tbaa !24
  %t463 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr { i64, ptr }, ptr %t464, i64 %t462
  store { i64, ptr } %t461, ptr %t465, !tbaa !37
  %t466 = load i64, ptr %l34, !tbaa !24
  store i64 %t466, ptr %l230, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t467, ptr %l231, !tbaa !27
  %t468 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t468, 0
  store i64 %t469, ptr %l232, !tbaa !24
  %t470 = load i64, ptr %l230, !tbaa !24
  %t471 = load i64, ptr %l232, !tbaa !24
  %t472 = add i64 %t470, %t471
  store i64 %t472, ptr %l233, !tbaa !24
  %t473 = load i64, ptr %l233, !tbaa !24
  store i64 %t473, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb100:
  store %olang.scope zeroinitializer, ptr %s19
  %t474 = load i64, ptr %l32, !tbaa !24
  store i64 %t474, ptr %l234, !tbaa !24
  %t475 = load i64, ptr %l234, !tbaa !24
  %t476 = add i64 %t475, 1
  store i64 %t476, ptr %l235, !tbaa !24
  %t477 = load i64, ptr %l235, !tbaa !24
  store i64 %t477, ptr %l32, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb86
bb101:
  call void @__olang_scope_close(ptr %s16)
  %t478 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t478, ptr %l236, !tbaa !27
  %t479 = load i64, ptr %l24, !tbaa !24
  store i64 %t479, ptr %l237, !tbaa !24
  %t480 = load i64, ptr %l237, !tbaa !24
  %t481 = sub i64 %t480, 1
  store i64 %t481, ptr %l238, !tbaa !24
  %t482 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t482, ptr %l239, !tbaa !27
  %t483 = load i64, ptr %l25, !tbaa !24
  store i64 %t483, ptr %l240, !tbaa !24
  %t484 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t484, ptr %l241, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l241, !tbaa !27
  store { i64, ptr } %t485, ptr %l242, !tbaa !27
  %t486 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t486, 0
  store i64 %t487, ptr %l243, !tbaa !24
  %t488 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t489 = extractvalue { i64, ptr } %t488, 0
  store i64 %t489, ptr %l244, !tbaa !24
  %t490 = load i64, ptr %l240, !tbaa !24
  %t491 = icmp sge i64 %t490, 0
  store i1 %t491, ptr %l245, !tbaa !21
  %t492 = load i1, ptr %l245, !tbaa !21
  br i1 %t492, label %bb102, label %bb103
bb102:
  %t493 = load i64, ptr %l240, !tbaa !24
  %t494 = load i64, ptr %l243, !tbaa !24
  %t495 = icmp sle i64 %t493, %t494
  store i1 %t495, ptr %l246, !tbaa !21
  %t496 = load i1, ptr %l246, !tbaa !21
  br i1 %t496, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb104:
  %t497 = load i64, ptr %l243, !tbaa !24
  %t498 = load i64, ptr %l244, !tbaa !24
  %t499 = icmp sle i64 %t497, %t498
  store i1 %t499, ptr %l247, !tbaa !21
  %t500 = load i1, ptr %l247, !tbaa !21
  br i1 %t500, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
bb106:
  %t501 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t502 = load ptr, ptr %t501, !tbaa !27
  %t503 = load i64, ptr %l240, !tbaa !24
  %t504 = load i64, ptr %l243, !tbaa !24
  %t505 = getelementptr i8, ptr %t502, i64 %t503
  %t506 = sub i64 %t504, %t503
  %t507 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t508 = insertvalue { i64, ptr } %t507, ptr %t505, 1
  store { i64, ptr } %t508, ptr %l248, !tbaa !27
  %t509 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t510 = load i64, ptr %l238, !tbaa !24
  %t511 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t512 = load ptr, ptr %t511, !tbaa !27
  %t513 = getelementptr { i64, ptr }, ptr %t512, i64 %t510
  store { i64, ptr } %t509, ptr %t513, !tbaa !37
  %t514 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t514, ptr %l249, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t515 = load { i64, ptr }, ptr %l249, !tbaa !27
  store { i64, ptr } %t515, ptr %rv
  br label %ret
bb107:
  call void @__olang_check_failed(ptr @.c22)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t4, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp sgt i64 %t7, %t8
  store i1 %t9, ptr %l6, !tbaa !21
  %t10 = load i1, ptr %l6, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l7, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l10, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  store i64 %t17, ptr %l11, !tbaa !24
  %t18 = icmp sge i64 0, 0
  store i1 %t18, ptr %l12, !tbaa !21
  %t19 = load i1, ptr %l12, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t20 = load i64, ptr %l10, !tbaa !24
  %t21 = icmp sle i64 0, %t20
  store i1 %t21, ptr %l13, !tbaa !21
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb6:
  %t23 = load i64, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = icmp sle i64 %t23, %t24
  store i1 %t25, ptr %l14, !tbaa !21
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb8:
  %t27 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = load i64, ptr %l10, !tbaa !24
  %t30 = getelementptr i8, ptr %t28, i64 0
  %t31 = sub i64 %t29, 0
  %t32 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t30, 1
  store { i64, ptr } %t33, ptr %l15, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t34, ptr %l16, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t37 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t35, { i64, ptr } %t36)
  store i1 %t37, ptr %l17
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @.c23)
  unreachable
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i1, ptr %l17, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i8
  %l23 = alloca i64
  %l24 = alloca i8
  %l25 = alloca i8
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  store i1 %t5, ptr %l9, !tbaa !21
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t13, ptr %lp1
  %t14 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t15 = load ptr, ptr %lp1
  store { i64, ptr } %t14, ptr %t15, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c24)
  unreachable
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l15, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t25 = load i64, ptr %l16, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  store i1 %t26, ptr %l17, !tbaa !21
  %t27 = load i1, ptr %l17, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l18, !tbaa !21
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l19, !tbaa !24
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  store i64 %t33, ptr %l21, !tbaa !24
  %t34 = load i64, ptr %l21, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t34
  %t38 = load i8, ptr %t37, !tbaa !32
  store i8 %t38, ptr %l22, !tbaa !22
  %t39 = load i8, ptr %l22, !tbaa !22
  store i8 %t39, ptr %l6, !tbaa !22
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  %t41 = load i8, ptr %l6, !tbaa !22
  store i8 %t41, ptr %l24, !tbaa !22
  %t42 = load i8, ptr %l24, !tbaa !22
  %t43 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t42)
  store i8 %t43, ptr %l25
  br label %bb7
bb7:
  %t44 = load i8, ptr %l25, !tbaa !22
  %t45 = load ptr, ptr %lp1
  %t46 = load i64, ptr %l23, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t46
  store i8 %t44, ptr %t49, !tbaa !32
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = add i64 %t51, 1
  store i64 %t52, ptr %l27, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb3
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t54 = load ptr, ptr %lp1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToUpper(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i8
  %l23 = alloca i64
  %l24 = alloca i8
  %l25 = alloca i8
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l7, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  store i1 %t5, ptr %l9, !tbaa !21
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t13, ptr %lp1
  %t14 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t15 = load ptr, ptr %lp1
  store { i64, ptr } %t14, ptr %t15, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l14, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l15, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l16, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t25 = load i64, ptr %l16, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  store i1 %t26, ptr %l17, !tbaa !21
  %t27 = load i1, ptr %l17, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l18, !tbaa !21
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l19, !tbaa !24
  %t31 = load i64, ptr %l19, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t33 = load i64, ptr %l3, !tbaa !24
  store i64 %t33, ptr %l21, !tbaa !24
  %t34 = load i64, ptr %l21, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i8, ptr %t36, i64 %t34
  %t38 = load i8, ptr %t37, !tbaa !32
  store i8 %t38, ptr %l22, !tbaa !22
  %t39 = load i8, ptr %l22, !tbaa !22
  store i8 %t39, ptr %l6, !tbaa !22
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  %t41 = load i8, ptr %l6, !tbaa !22
  store i8 %t41, ptr %l24, !tbaa !22
  %t42 = load i8, ptr %l24, !tbaa !22
  %t43 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t42)
  store i8 %t43, ptr %l25
  br label %bb7
bb7:
  %t44 = load i8, ptr %l25, !tbaa !22
  %t45 = load ptr, ptr %lp1
  %t46 = load i64, ptr %l23, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t46
  store i8 %t44, ptr %t49, !tbaa !32
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l3, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = add i64 %t51, 1
  store i64 %t52, ptr %l27, !tbaa !24
  %t53 = load i64, ptr %l27, !tbaa !24
  store i64 %t53, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb3
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t54 = load ptr, ptr %lp1
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l28, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i8
  %l12 = alloca i8
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i8
  %l25 = alloca i8
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  store i1 %t9, ptr %l7, !tbaa !21
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = load i64, ptr %l10, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t13
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l11, !tbaa !22
  %t18 = load i8, ptr %l11, !tbaa !22
  store i8 %t18, ptr %l12, !tbaa !22
  %t19 = load i8, ptr %l12, !tbaa !22
  %t20 = call i1 @std_2fprelude_2ftext_2eisSpace(i8 %t19)
  store i1 %t20, ptr %l13
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i1, ptr %l13, !tbaa !21
  store i1 %t21, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l8, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l14, !tbaa !21
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t25 = load i64, ptr %l1, !tbaa !24
  store i64 %t25, ptr %l15, !tbaa !24
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = add i64 %t26, 1
  store i64 %t27, ptr %l16, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l2, !tbaa !24
  store i64 %t29, ptr %l17, !tbaa !24
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l18, !tbaa !24
  %t31 = load i64, ptr %l17, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = icmp sgt i64 %t31, %t32
  store i1 %t33, ptr %l19, !tbaa !21
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t35 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t35, ptr %l21, !tbaa !27
  %t36 = load i64, ptr %l2, !tbaa !24
  store i64 %t36, ptr %l22, !tbaa !24
  %t37 = load i64, ptr %l22, !tbaa !24
  %t38 = sub i64 %t37, 1
  store i64 %t38, ptr %l23, !tbaa !24
  %t39 = load i64, ptr %l23, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 %t39
  %t43 = load i8, ptr %t42, !tbaa !32
  store i8 %t43, ptr %l24, !tbaa !22
  %t44 = load i8, ptr %l24, !tbaa !22
  store i8 %t44, ptr %l25, !tbaa !22
  %t45 = load i8, ptr %l25, !tbaa !22
  %t46 = call i1 @std_2fprelude_2ftext_2eisSpace(i8 %t45)
  store i1 %t46, ptr %l26
  br label %bb14
bb13:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t48 = load i1, ptr %l20, !tbaa !21
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l27, !tbaa !21
  %t50 = load i1, ptr %l27, !tbaa !21
  br i1 %t50, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t51 = load i64, ptr %l2, !tbaa !24
  store i64 %t51, ptr %l28, !tbaa !24
  %t52 = load i64, ptr %l28, !tbaa !24
  %t53 = sub i64 %t52, 1
  store i64 %t53, ptr %l29, !tbaa !24
  %t54 = load i64, ptr %l29, !tbaa !24
  store i64 %t54, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb11
bb20:
  %t55 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t55, ptr %l30, !tbaa !27
  %t56 = load i64, ptr %l1, !tbaa !24
  store i64 %t56, ptr %l31, !tbaa !24
  %t57 = load i64, ptr %l2, !tbaa !24
  store i64 %t57, ptr %l32, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  store i64 %t59, ptr %l33, !tbaa !24
  %t60 = load i64, ptr %l31, !tbaa !24
  %t61 = icmp sge i64 %t60, 0
  store i1 %t61, ptr %l34, !tbaa !21
  %t62 = load i1, ptr %l34, !tbaa !21
  br i1 %t62, label %bb21, label %bb22
bb21:
  %t63 = load i64, ptr %l31, !tbaa !24
  %t64 = load i64, ptr %l32, !tbaa !24
  %t65 = icmp sle i64 %t63, %t64
  store i1 %t65, ptr %l35, !tbaa !21
  %t66 = load i1, ptr %l35, !tbaa !21
  br i1 %t66, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb23:
  %t67 = load i64, ptr %l32, !tbaa !24
  %t68 = load i64, ptr %l33, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  store i1 %t69, ptr %l36, !tbaa !21
  %t70 = load i1, ptr %l36, !tbaa !21
  br i1 %t70, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
bb25:
  %t71 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l31, !tbaa !24
  %t74 = load i64, ptr %l32, !tbaa !24
  %t75 = getelementptr i8, ptr %t72, i64 %t73
  %t76 = sub i64 %t74, %t73
  %t77 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t75, 1
  store { i64, ptr } %t78, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t79 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t79, ptr %rv
  br label %ret
bb26:
  call void @__olang_check_failed(ptr @.c26)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i8
  %l11 = alloca i8
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = sub i64 %t11, 1
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t13
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l10, !tbaa !22
  %t18 = load i8, ptr %l10, !tbaa !22
  store i8 %t18, ptr %l11, !tbaa !22
  %t19 = load i8, ptr %l11, !tbaa !22
  %t20 = call i1 @std_2fprelude_2ftext_2eisSpace(i8 %t19)
  store i1 %t20, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i1, ptr %l12, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l6, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l13, !tbaa !21
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t25 = load i64, ptr %l1, !tbaa !24
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = sub i64 %t26, 1
  store i64 %t27, ptr %l15, !tbaa !24
  %t28 = load i64, ptr %l15, !tbaa !24
  store i64 %t28, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l16, !tbaa !27
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l17, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l18, !tbaa !24
  %t33 = icmp sge i64 0, 0
  store i1 %t33, ptr %l19, !tbaa !21
  %t34 = load i1, ptr %l19, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  store i1 %t36, ptr %l20, !tbaa !21
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb13:
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = load i64, ptr %l18, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  store i1 %t40, ptr %l21, !tbaa !21
  %t41 = load i1, ptr %l21, !tbaa !21
  br i1 %t41, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
bb15:
  %t42 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = getelementptr i8, ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l22, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @.c27)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimStart(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp slt i64 %t5, %t6
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t11
  %t15 = load i8, ptr %t14, !tbaa !32
  store i8 %t15, ptr %l9, !tbaa !22
  %t16 = load i8, ptr %l9, !tbaa !22
  store i8 %t16, ptr %l10, !tbaa !22
  %t17 = load i8, ptr %l10, !tbaa !22
  %t18 = call i1 @std_2fprelude_2ftext_2eisSpace(i8 %t17)
  store i1 %t18, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t19 = load i1, ptr %l11, !tbaa !21
  store i1 %t19, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l6, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l12, !tbaa !21
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t23 = load i64, ptr %l1, !tbaa !24
  store i64 %t23, ptr %l13, !tbaa !24
  %t24 = load i64, ptr %l13, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  store i64 %t26, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb9:
  br label %bb1
bb10:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = load i64, ptr %l1, !tbaa !24
  store i64 %t28, ptr %l16, !tbaa !24
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l17, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t30, ptr %l18, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l19, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load i64, ptr %l16, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  store i1 %t36, ptr %l21, !tbaa !21
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t38 = load i64, ptr %l16, !tbaa !24
  %t39 = load i64, ptr %l19, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  store i1 %t40, ptr %l22, !tbaa !21
  %t41 = load i1, ptr %l22, !tbaa !21
  br i1 %t41, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb13:
  %t42 = load i64, ptr %l19, !tbaa !24
  %t43 = load i64, ptr %l20, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  store i1 %t44, ptr %l23, !tbaa !21
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
bb15:
  %t46 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l16, !tbaa !24
  %t49 = load i64, ptr %l19, !tbaa !24
  %t50 = getelementptr i8, ptr %t47, i64 %t48
  %t51 = sub i64 %t49, %t48
  %t52 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t50, 1
  store { i64, ptr } %t53, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @.c28)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2efindFrom(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i8
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i8
  %l52 = alloca i8
  %l53 = alloca i1
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i8
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i8
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i1
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l12, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l13, !tbaa !24
  %t4 = load i64, ptr %l13, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l14, !tbaa !24
  %t6 = load i64, ptr %l14, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l15, !tbaa !21
  %t8 = load i1, ptr %l15, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t10 = load i64, ptr %l16, !tbaa !24
  %t11 = insertvalue { i32, i64 } zeroinitializer, i64 %t10, 1
  store { i32, i64 } %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l17, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr i8, ptr %t14, i64 0
  %t16 = load i8, ptr %t15, !tbaa !32
  store i8 %t16, ptr %l18, !tbaa !22
  %t17 = load i8, ptr %l18, !tbaa !22
  store i8 %t17, ptr %l4, !tbaa !22
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l19, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l21, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %l22, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = load i64, ptr %l22, !tbaa !24
  %t26 = sub i64 %t24, %t25
  store i64 %t26, ptr %l23, !tbaa !24
  %t27 = load i64, ptr %l23, !tbaa !24
  %t28 = add i64 %t27, 1
  store i64 %t28, ptr %l24, !tbaa !24
  %t29 = load i64, ptr %l24, !tbaa !24
  store i64 %t29, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  store i64 %t30, ptr %l25, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l26, !tbaa !24
  %t34 = icmp sgt i64 %t32, %t33
  store i1 %t34, ptr %l27, !tbaa !21
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb4, label %bb5
bb4:
  %t36 = load i64, ptr %l7, !tbaa !24
  store i64 %t36, ptr %l29, !tbaa !24
  %t37 = load i64, ptr %l29, !tbaa !24
  %t38 = icmp sgt i64 %t37, 0
  store i1 %t38, ptr %l30, !tbaa !21
  %t39 = load i1, ptr %l30, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb9
bb6:
  %t40 = load i64, ptr %l6, !tbaa !24
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  store i64 %t41, ptr %l33, !tbaa !24
  %t42 = load i64, ptr %l32, !tbaa !24
  %t43 = load i64, ptr %l33, !tbaa !24
  %t44 = sub i64 %t42, %t43
  store i64 %t44, ptr %l34, !tbaa !24
  %t45 = load i64, ptr %l7, !tbaa !24
  store i64 %t45, ptr %l35, !tbaa !24
  %t46 = load i64, ptr %l34, !tbaa !24
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = add i64 %t46, %t47
  store i64 %t48, ptr %l36, !tbaa !24
  %t49 = load i64, ptr %l36, !tbaa !24
  %t50 = sub i64 %t49, 1
  store i64 %t50, ptr %l37, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  store i64 %t51, ptr %l38, !tbaa !24
  %t52 = load i64, ptr %l37, !tbaa !24
  %t53 = load i64, ptr %l38, !tbaa !24
  %t54 = sdiv i64 %t52, %t53
  store i64 %t54, ptr %l39, !tbaa !24
  %t55 = load i64, ptr %l39, !tbaa !24
  store i64 %t55, ptr %l31, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t56 = load i64, ptr %l31, !tbaa !24
  store i64 %t56, ptr %l28, !tbaa !24
  br label %bb9
bb9:
  %t57 = load i64, ptr %l28, !tbaa !24
  store i64 %t57, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l9, !tbaa !24
  store i64 %t58, ptr %l40, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  store i64 %t59, ptr %l41, !tbaa !24
  %t60 = load i64, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l41, !tbaa !24
  %t62 = icmp slt i64 %t60, %t61
  store i1 %t62, ptr %l42, !tbaa !21
  %t63 = load i1, ptr %l42, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l43, !tbaa !21
  %t65 = load i1, ptr %l43, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb12:
  br label %bb13
bb13:
  %t66 = load i64, ptr %l5, !tbaa !24
  store i64 %t66, ptr %l44, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  store i64 %t67, ptr %l45, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  store i64 %t68, ptr %l46, !tbaa !24
  %t69 = load i64, ptr %l45, !tbaa !24
  %t70 = load i64, ptr %l46, !tbaa !24
  %t71 = mul i64 %t69, %t70
  store i64 %t71, ptr %l47, !tbaa !24
  %t72 = load i64, ptr %l44, !tbaa !24
  %t73 = load i64, ptr %l47, !tbaa !24
  %t74 = add i64 %t72, %t73
  store i64 %t74, ptr %l48, !tbaa !24
  %t75 = load i64, ptr %l48, !tbaa !24
  store i64 %t75, ptr %l10, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t76, ptr %l49, !tbaa !27
  %t77 = load i64, ptr %l10, !tbaa !24
  store i64 %t77, ptr %l50, !tbaa !24
  %t78 = load i64, ptr %l50, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 %t78
  %t82 = load i8, ptr %t81, !tbaa !32
  store i8 %t82, ptr %l51, !tbaa !22
  %t83 = load i8, ptr %l4, !tbaa !22
  store i8 %t83, ptr %l52, !tbaa !22
  %t84 = load i8, ptr %l51, !tbaa !22
  %t85 = load i8, ptr %l52, !tbaa !22
  %t86 = icmp eq i8 %t84, %t85
  store i1 %t86, ptr %l53, !tbaa !21
  %t87 = load i1, ptr %l53, !tbaa !21
  br i1 %t87, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  store i64 1, ptr %l11, !tbaa !24
  br label %bb16
bb15:
  br label %bb28
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t88 = load i64, ptr %l11, !tbaa !24
  store i64 %t88, ptr %l54, !tbaa !24
  %t89 = load i64, ptr %l3, !tbaa !24
  store i64 %t89, ptr %l55, !tbaa !24
  %t90 = load i64, ptr %l54, !tbaa !24
  %t91 = load i64, ptr %l55, !tbaa !24
  %t92 = icmp slt i64 %t90, %t91
  store i1 %t92, ptr %l56, !tbaa !21
  %t93 = load i1, ptr %l56, !tbaa !21
  br i1 %t93, label %bb17, label %bb18
bb17:
  %t94 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t94, ptr %l58, !tbaa !27
  %t95 = load i64, ptr %l10, !tbaa !24
  store i64 %t95, ptr %l59, !tbaa !24
  %t96 = load i64, ptr %l11, !tbaa !24
  store i64 %t96, ptr %l60, !tbaa !24
  %t97 = load i64, ptr %l59, !tbaa !24
  %t98 = load i64, ptr %l60, !tbaa !24
  %t99 = add i64 %t97, %t98
  store i64 %t99, ptr %l61, !tbaa !24
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr i8, ptr %t102, i64 %t100
  %t104 = load i8, ptr %t103, !tbaa !32
  store i8 %t104, ptr %l62, !tbaa !22
  %t105 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t105, ptr %l63, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  store i64 %t106, ptr %l64, !tbaa !24
  %t107 = load i64, ptr %l64, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i8, ptr %t109, i64 %t107
  %t111 = load i8, ptr %t110, !tbaa !32
  store i8 %t111, ptr %l65, !tbaa !22
  %t112 = load i8, ptr %l62, !tbaa !22
  %t113 = load i8, ptr %l65, !tbaa !22
  %t114 = icmp eq i8 %t112, %t113
  store i1 %t114, ptr %l66, !tbaa !21
  %t115 = load i1, ptr %l66, !tbaa !21
  store i1 %t115, ptr %l57, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb19
bb19:
  %t116 = load i1, ptr %l57, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l67, !tbaa !21
  %t118 = load i1, ptr %l67, !tbaa !21
  br i1 %t118, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t119 = load i64, ptr %l11, !tbaa !24
  store i64 %t119, ptr %l68, !tbaa !24
  %t120 = load i64, ptr %l68, !tbaa !24
  %t121 = add i64 %t120, 1
  store i64 %t121, ptr %l69, !tbaa !24
  %t122 = load i64, ptr %l69, !tbaa !24
  store i64 %t122, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb23:
  br label %bb16
bb24:
  %t123 = load i64, ptr %l11, !tbaa !24
  store i64 %t123, ptr %l70, !tbaa !24
  %t124 = load i64, ptr %l3, !tbaa !24
  store i64 %t124, ptr %l71, !tbaa !24
  %t125 = load i64, ptr %l70, !tbaa !24
  %t126 = load i64, ptr %l71, !tbaa !24
  %t127 = icmp eq i64 %t125, %t126
  store i1 %t127, ptr %l72, !tbaa !21
  %t128 = load i1, ptr %l72, !tbaa !21
  br i1 %t128, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load i64, ptr %l10, !tbaa !24
  store i64 %t129, ptr %l73, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load i64, ptr %l73, !tbaa !24
  %t131 = insertvalue { i32, i64 } zeroinitializer, i64 %t130, 1
  store { i32, i64 } %t131, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t132 = load i64, ptr %l9, !tbaa !24
  store i64 %t132, ptr %l74, !tbaa !24
  %t133 = load i64, ptr %l74, !tbaa !24
  %t134 = add i64 %t133, 1
  store i64 %t134, ptr %l75, !tbaa !24
  %t135 = load i64, ptr %l75, !tbaa !24
  store i64 %t135, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb10
bb30:
  call void @__olang_scope_close(ptr %s2)
  store i32 65536, ptr %l76, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t136 = load i32, ptr %l76, !tbaa !23
  %t137 = insertvalue { i32, i64 } zeroinitializer, i32 %t136, 0
  store { i32, i64 } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2ebits(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l46 = alloca i8
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i1
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i1
  %l92 = alloca i32
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i1
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l8, !tbaa !24
  %t5 = load i64, ptr %l8, !tbaa !24
  %t6 = icmp eq i64 %t5, 0
  store i1 %t6, ptr %l9, !tbaa !21
  %t7 = load i1, ptr %l9, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l11, !tbaa !29
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = getelementptr %"std/prelude/text:decimal", ptr %t9, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l12, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp slt i64 %t12, -330
  store i1 %t13, ptr %l13, !tbaa !21
  %t14 = load i1, ptr %l13, !tbaa !21
  store i1 %t14, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l10, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l14, !tbaa !65
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t16 = load i64, ptr %l14, !tbaa !65
  %t17 = insertvalue { i32, i64 } zeroinitializer, i64 %t16, 1
  store { i32, i64 } %t17, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load ptr, ptr %l15, !tbaa !29
  %t20 = getelementptr %"std/prelude/text:decimal", ptr %t19, i32 0, i32 3
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l16, !tbaa !24
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = icmp sgt i64 %t22, 310
  store i1 %t23, ptr %l17, !tbaa !21
  %t24 = load i1, ptr %l17, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i32 65538, ptr %l18, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l18, !tbaa !23
  %t26 = insertvalue { i32, i64 } zeroinitializer, i32 %t25, 0
  store { i32, i64 } %t26, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = getelementptr %"std/prelude/text:decimal", ptr %t28, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l20, !tbaa !24
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  store i1 %t32, ptr %l21, !tbaa !21
  %t33 = load i1, ptr %l21, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l22, !tbaa !21
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l23, !tbaa !29
  %t37 = load ptr, ptr %l23, !tbaa !29
  %t38 = getelementptr %"std/prelude/text:decimal", ptr %t37, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load i64, ptr %l24, !tbaa !24
  %t41 = icmp sge i64 %t40, 9
  store i1 %t41, ptr %l25, !tbaa !21
  %t42 = load i1, ptr %l25, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  store i64 27, ptr %l26, !tbaa !24
  br label %bb16
bb15:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l27, !tbaa !29
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = getelementptr %"std/prelude/text:decimal", ptr %t44, i32 0, i32 3
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l28, !tbaa !24
  %t47 = load i64, ptr %l28, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2edecimalShifts, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i64, ptr %t49, i64 %t47
  %t51 = load i64, ptr %t50, !tbaa !34
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l29, !tbaa !24
  store i64 %t52, ptr %l26, !tbaa !24
  br label %bb16
bb16:
  %t53 = load i64, ptr %l26, !tbaa !24
  store i64 %t53, ptr %l2, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %l2, !tbaa !24
  store i64 %t55, ptr %l31, !tbaa !24
  %t56 = load i64, ptr %l31, !tbaa !24
  %t57 = sub i64 0, %t56
  store i64 %t57, ptr %l32, !tbaa !24
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = load i64, ptr %l32, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t58, i64 %t59)
  br label %bb17
bb17:
  %t60 = load i64, ptr %l1, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l34, !tbaa !24
  %t62 = load i64, ptr %l33, !tbaa !24
  %t63 = load i64, ptr %l34, !tbaa !24
  %t64 = add i64 %t62, %t63
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l35, !tbaa !24
  store i64 %t65, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb10
bb19:
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l36, !tbaa !29
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t68 = getelementptr %"std/prelude/text:decimal", ptr %t67, i32 0, i32 3
  %t69 = load i64, ptr %t68, !tbaa !24
  store i64 %t69, ptr %l37, !tbaa !24
  %t70 = load i64, ptr %l37, !tbaa !24
  %t71 = icmp slt i64 %t70, 0
  store i1 %t71, ptr %l38, !tbaa !21
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb26
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l40, !tbaa !29
  %t74 = load ptr, ptr %l40, !tbaa !29
  %t75 = getelementptr %"std/prelude/text:decimal", ptr %t74, i32 0, i32 3
  %t76 = load i64, ptr %t75, !tbaa !24
  store i64 %t76, ptr %l41, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = icmp eq i64 %t77, 0
  store i1 %t78, ptr %l42, !tbaa !21
  %t79 = load i1, ptr %l42, !tbaa !21
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l44, !tbaa !29
  %t81 = load ptr, ptr %l44, !tbaa !29
  %t82 = getelementptr %"std/prelude/text:decimal", ptr %t81, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l45, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i8, ptr %t85, i64 0
  %t87 = load i8, ptr %t86, !tbaa !32
  store i8 %t87, ptr %l46, !tbaa !22
  %t88 = load i8, ptr %l46, !tbaa !22
  %t89 = icmp ult i8 %t88, 5
  store i1 %t89, ptr %l47, !tbaa !21
  %t90 = load i1, ptr %l47, !tbaa !21
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l43, !tbaa !21
  store i1 %t91, ptr %l39, !tbaa !21
  br label %bb26
bb26:
  %t92 = load i1, ptr %l39, !tbaa !21
  %t93 = xor i1 %t92, true
  store i1 %t93, ptr %l48, !tbaa !21
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l49, !tbaa !29
  %t96 = load ptr, ptr %l49, !tbaa !29
  %t97 = getelementptr %"std/prelude/text:decimal", ptr %t96, i32 0, i32 3
  %t98 = load i64, ptr %t97, !tbaa !24
  store i64 %t98, ptr %l50, !tbaa !24
  %t99 = load i64, ptr %l50, !tbaa !24
  %t100 = sub i64 0, %t99
  store i64 %t100, ptr %l51, !tbaa !24
  %t101 = load i64, ptr %l51, !tbaa !24
  %t102 = icmp sge i64 %t101, 9
  store i1 %t102, ptr %l52, !tbaa !21
  %t103 = load i1, ptr %l52, !tbaa !21
  br i1 %t103, label %bb30, label %bb31
bb30:
  store i64 27, ptr %l53, !tbaa !24
  br label %bb32
bb31:
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l54, !tbaa !29
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t106 = getelementptr %"std/prelude/text:decimal", ptr %t105, i32 0, i32 3
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l55, !tbaa !24
  %t108 = load i64, ptr %l55, !tbaa !24
  %t109 = sub i64 0, %t108
  store i64 %t109, ptr %l56, !tbaa !24
  %t110 = load i64, ptr %l56, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2edecimalShifts, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i64, ptr %t112, i64 %t110
  %t114 = load i64, ptr %t113, !tbaa !34
  store i64 %t114, ptr %l57, !tbaa !24
  %t115 = load i64, ptr %l57, !tbaa !24
  store i64 %t115, ptr %l53, !tbaa !24
  br label %bb32
bb32:
  %t116 = load i64, ptr %l53, !tbaa !24
  store i64 %t116, ptr %l3, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l58, !tbaa !29
  %t118 = load i64, ptr %l3, !tbaa !24
  store i64 %t118, ptr %l59, !tbaa !24
  %t119 = load ptr, ptr %l58, !tbaa !29
  %t120 = load i64, ptr %l59, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t119, i64 %t120)
  br label %bb33
bb33:
  %t121 = load i64, ptr %l1, !tbaa !24
  store i64 %t121, ptr %l60, !tbaa !24
  %t122 = load i64, ptr %l3, !tbaa !24
  store i64 %t122, ptr %l61, !tbaa !24
  %t123 = load i64, ptr %l60, !tbaa !24
  %t124 = load i64, ptr %l61, !tbaa !24
  %t125 = sub i64 %t123, %t124
  store i64 %t125, ptr %l62, !tbaa !24
  %t126 = load i64, ptr %l62, !tbaa !24
  store i64 %t126, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  br label %bb20
bb35:
  %t127 = load i64, ptr %l1, !tbaa !24
  store i64 %t127, ptr %l63, !tbaa !24
  %t128 = load i64, ptr %l63, !tbaa !24
  %t129 = sub i64 %t128, 1
  store i64 %t129, ptr %l64, !tbaa !24
  %t130 = load i64, ptr %l64, !tbaa !24
  store i64 %t130, ptr %l1, !tbaa !24
  %t131 = load i64, ptr %l1, !tbaa !24
  store i64 %t131, ptr %l65, !tbaa !24
  %t132 = load i64, ptr %l65, !tbaa !24
  %t133 = icmp slt i64 %t132, -1022
  store i1 %t133, ptr %l66, !tbaa !21
  %t134 = load i1, ptr %l66, !tbaa !21
  br i1 %t134, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s5
  %t135 = load i64, ptr %l1, !tbaa !24
  store i64 %t135, ptr %l67, !tbaa !24
  %t136 = load i64, ptr %l67, !tbaa !24
  %t137 = sub i64 -1022, %t136
  store i64 %t137, ptr %l68, !tbaa !24
  %t138 = load i64, ptr %l68, !tbaa !24
  store i64 %t138, ptr %l4, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l69, !tbaa !29
  %t140 = load i64, ptr %l4, !tbaa !24
  store i64 %t140, ptr %l70, !tbaa !24
  %t141 = load i64, ptr %l70, !tbaa !24
  %t142 = sub i64 0, %t141
  store i64 %t142, ptr %l71, !tbaa !24
  %t143 = load ptr, ptr %l69, !tbaa !29
  %t144 = load i64, ptr %l71, !tbaa !24
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t143, i64 %t144)
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t145 = load i64, ptr %l1, !tbaa !24
  store i64 %t145, ptr %l72, !tbaa !24
  %t146 = load i64, ptr %l4, !tbaa !24
  store i64 %t146, ptr %l73, !tbaa !24
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l73, !tbaa !24
  %t149 = add i64 %t147, %t148
  store i64 %t149, ptr %l74, !tbaa !24
  %t150 = load i64, ptr %l74, !tbaa !24
  store i64 %t150, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  %t151 = load i64, ptr %l1, !tbaa !24
  store i64 %t151, ptr %l75, !tbaa !24
  %t152 = load i64, ptr %l75, !tbaa !24
  %t153 = add i64 %t152, 1023
  store i64 %t153, ptr %l76, !tbaa !24
  %t154 = load i64, ptr %l76, !tbaa !24
  %t155 = icmp sge i64 %t154, 2047
  store i1 %t155, ptr %l77, !tbaa !21
  %t156 = load i1, ptr %l77, !tbaa !21
  br i1 %t156, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s6
  store i32 65538, ptr %l78, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t157 = load i32, ptr %l78, !tbaa !23
  %t158 = insertvalue { i32, i64 } zeroinitializer, i32 %t157, 0
  store { i32, i64 } %t158, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l79, !tbaa !29
  %t160 = load ptr, ptr %l79, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %t160, i64 53)
  br label %bb43
bb43:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l80, !tbaa !29
  %t162 = load ptr, ptr %l80, !tbaa !29
  %t163 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundedInteger(ptr %v0, ptr %t162)
  store i64 %t163, ptr %l81
  br label %bb44
bb44:
  %t164 = load i64, ptr %l81, !tbaa !65
  store i64 %t164, ptr %l5, !tbaa !65
  %t165 = load i64, ptr %l5, !tbaa !65
  store i64 %t165, ptr %l82, !tbaa !65
  %t166 = shl i64 1, 53
  store i64 %t166, ptr %l83, !tbaa !65
  %t167 = load i64, ptr %l82, !tbaa !65
  %t168 = load i64, ptr %l83, !tbaa !65
  %t169 = icmp eq i64 %t167, %t168
  store i1 %t169, ptr %l84, !tbaa !21
  %t170 = load i1, ptr %l84, !tbaa !21
  br i1 %t170, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t171 = load i64, ptr %l5, !tbaa !65
  store i64 %t171, ptr %l85, !tbaa !65
  %t172 = load i64, ptr %l85, !tbaa !65
  %t173 = lshr i64 %t172, 1
  store i64 %t173, ptr %l86, !tbaa !65
  %t174 = load i64, ptr %l86, !tbaa !65
  store i64 %t174, ptr %l5, !tbaa !65
  %t175 = load i64, ptr %l1, !tbaa !24
  store i64 %t175, ptr %l87, !tbaa !24
  %t176 = load i64, ptr %l87, !tbaa !24
  %t177 = add i64 %t176, 1
  store i64 %t177, ptr %l88, !tbaa !24
  %t178 = load i64, ptr %l88, !tbaa !24
  store i64 %t178, ptr %l1, !tbaa !24
  %t179 = load i64, ptr %l1, !tbaa !24
  store i64 %t179, ptr %l89, !tbaa !24
  %t180 = load i64, ptr %l89, !tbaa !24
  %t181 = add i64 %t180, 1023
  store i64 %t181, ptr %l90, !tbaa !24
  %t182 = load i64, ptr %l90, !tbaa !24
  %t183 = icmp sge i64 %t182, 2047
  store i1 %t183, ptr %l91, !tbaa !21
  %t184 = load i1, ptr %l91, !tbaa !21
  br i1 %t184, label %bb47, label %bb48
bb46:
  br label %bb50
bb47:
  store %olang.scope zeroinitializer, ptr %s8
  store i32 65538, ptr %l92, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t185 = load i32, ptr %l92, !tbaa !23
  %t186 = insertvalue { i32, i64 } zeroinitializer, i32 %t185, 0
  store { i32, i64 } %t186, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  %t187 = load i64, ptr %l1, !tbaa !24
  store i64 %t187, ptr %l93, !tbaa !24
  %t188 = load i64, ptr %l93, !tbaa !24
  %t189 = add i64 %t188, 1023
  store i64 %t189, ptr %l94, !tbaa !24
  %t190 = load i64, ptr %l94, !tbaa !24
  store i64 %t190, ptr %l6, !tbaa !24
  %t191 = load i64, ptr %l5, !tbaa !65
  store i64 %t191, ptr %l95, !tbaa !65
  %t192 = shl i64 1, 52
  store i64 %t192, ptr %l96, !tbaa !65
  %t193 = load i64, ptr %l95, !tbaa !65
  %t194 = load i64, ptr %l96, !tbaa !65
  %t195 = and i64 %t193, %t194
  store i64 %t195, ptr %l97, !tbaa !65
  %t196 = load i64, ptr %l97, !tbaa !65
  %t197 = icmp eq i64 %t196, 0
  store i1 %t197, ptr %l98, !tbaa !21
  %t198 = load i1, ptr %l98, !tbaa !21
  br i1 %t198, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s9
  store i64 0, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t199 = load i64, ptr %l5, !tbaa !65
  store i64 %t199, ptr %l99, !tbaa !65
  %t200 = load i64, ptr %l99, !tbaa !65
  %t201 = and i64 %t200, 4503599627370495
  store i64 %t201, ptr %l100, !tbaa !65
  %t202 = load i64, ptr %l6, !tbaa !24
  store i64 %t202, ptr %l101, !tbaa !24
  %t203 = load i64, ptr %l101, !tbaa !24
  store i64 %t203, ptr %l102, !tbaa !65
  %t204 = load i64, ptr %l102, !tbaa !65
  %t205 = shl i64 %t204, 52
  store i64 %t205, ptr %l103, !tbaa !65
  %t206 = load i64, ptr %l100, !tbaa !65
  %t207 = load i64, ptr %l103, !tbaa !65
  %t208 = or i64 %t206, %t207
  store i64 %t208, ptr %l104, !tbaa !65
  call void @__olang_scope_close(ptr %s0)
  %t209 = load i64, ptr %l104, !tbaa !65
  %t210 = insertvalue { i32, i64 } zeroinitializer, i64 %t209, 1
  store { i32, i64 } %t210, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eleftShift(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i8
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i8
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i8
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca ptr
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i8
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i1
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i1
  %l142 = alloca i1
  %l143 = alloca i64
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca ptr
  %l149 = alloca { i64, ptr }
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i8
  %l154 = alloca i1
  %l155 = alloca ptr
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca i64
  %l160 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l21, !tbaa !29
  %t2 = load ptr, ptr %l21, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t2, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l22, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l23, !tbaa !24
  %t7 = load i64, ptr %l23, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !65
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l24, !tbaa !29
  %t9 = load ptr, ptr %l24, !tbaa !29
  %t10 = getelementptr %"std/prelude/text:decimal", ptr %t9, i32 0, i32 2
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l25, !tbaa !24
  %t12 = load i64, ptr %l25, !tbaa !24
  %t13 = sub i64 %t12, 1
  store i64 %t13, ptr %l26, !tbaa !24
  %t14 = load i64, ptr %l26, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load i64, ptr %l4, !tbaa !24
  store i64 %t15, ptr %l27, !tbaa !24
  %t16 = load i64, ptr %l27, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  store i1 %t17, ptr %l28, !tbaa !21
  %t18 = load i1, ptr %l28, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l29, !tbaa !21
  %t20 = load i1, ptr %l29, !tbaa !21
  br i1 %t20, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t21 = load i64, ptr %l3, !tbaa !65
  store i64 %t21, ptr %l30, !tbaa !65
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l31, !tbaa !29
  %t23 = load ptr, ptr %l31, !tbaa !29
  %t24 = getelementptr %"std/prelude/text:decimal", ptr %t23, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l32, !tbaa !27
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l33, !tbaa !24
  %t27 = load i64, ptr %l33, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr i8, ptr %t29, i64 %t27
  %t31 = load i8, ptr %t30, !tbaa !32
  store i8 %t31, ptr %l34, !tbaa !22
  %t32 = load i8, ptr %l34, !tbaa !22
  %t33 = zext i8 %t32 to i64
  store i64 %t33, ptr %l35, !tbaa !65
  %t34 = load i64, ptr %l1, !tbaa !65
  store i64 %t34, ptr %l36, !tbaa !65
  %t35 = load i64, ptr %l35, !tbaa !65
  %t36 = load i64, ptr %l36, !tbaa !65
  %t37 = load i64, ptr %l36, !tbaa !65
  %t38 = shl i64 %t35, %t37
  store i64 %t38, ptr %l37, !tbaa !65
  %t39 = load i64, ptr %l30, !tbaa !65
  %t40 = load i64, ptr %l37, !tbaa !65
  %t41 = add i64 %t39, %t40
  store i64 %t41, ptr %l38, !tbaa !65
  %t42 = load i64, ptr %l38, !tbaa !65
  store i64 %t42, ptr %l3, !tbaa !65
  %t43 = load i64, ptr %l3, !tbaa !65
  store i64 %t43, ptr %l39, !tbaa !65
  %t44 = load i64, ptr %l39, !tbaa !65
  %t45 = udiv i64 %t44, 10
  store i64 %t45, ptr %l40, !tbaa !65
  %t46 = load i64, ptr %l40, !tbaa !65
  store i64 %t46, ptr %l5, !tbaa !65
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l41, !tbaa !24
  %t48 = load i64, ptr %l41, !tbaa !24
  %t49 = sub i64 %t48, 1
  store i64 %t49, ptr %l42, !tbaa !24
  %t50 = load i64, ptr %l42, !tbaa !24
  store i64 %t50, ptr %l2, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l43, !tbaa !29
  %t52 = load ptr, ptr %l43, !tbaa !29
  %t53 = getelementptr %"std/prelude/text:decimal", ptr %t52, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l44, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  store i64 %t55, ptr %l45, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !65
  store i64 %t56, ptr %l46, !tbaa !65
  %t57 = load i64, ptr %l5, !tbaa !65
  store i64 %t57, ptr %l47, !tbaa !65
  %t58 = load i64, ptr %l47, !tbaa !65
  %t59 = mul i64 10, %t58
  store i64 %t59, ptr %l48, !tbaa !65
  %t60 = load i64, ptr %l46, !tbaa !65
  %t61 = load i64, ptr %l48, !tbaa !65
  %t62 = sub i64 %t60, %t61
  store i64 %t62, ptr %l49, !tbaa !65
  %t63 = load i64, ptr %l49, !tbaa !65
  %t64 = trunc i64 %t63 to i8
  store i8 %t64, ptr %l50, !tbaa !22
  %t65 = load i8, ptr %l50, !tbaa !22
  %t66 = load i64, ptr %l45, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t66
  store i8 %t65, ptr %t69, !tbaa !32
  %t70 = load i64, ptr %l5, !tbaa !65
  store i64 %t70, ptr %l51, !tbaa !65
  %t71 = load i64, ptr %l51, !tbaa !65
  store i64 %t71, ptr %l3, !tbaa !65
  %t72 = load i64, ptr %l4, !tbaa !24
  store i64 %t72, ptr %l52, !tbaa !24
  %t73 = load i64, ptr %l52, !tbaa !24
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %l53, !tbaa !24
  %t75 = load i64, ptr %l53, !tbaa !24
  store i64 %t75, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  br label %bb1
bb6:
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t76 = load i64, ptr %l3, !tbaa !65
  store i64 %t76, ptr %l54, !tbaa !65
  %t77 = load i64, ptr %l54, !tbaa !65
  %t78 = icmp ugt i64 %t77, 0
  store i1 %t78, ptr %l55, !tbaa !21
  %t79 = load i1, ptr %l55, !tbaa !21
  %t80 = xor i1 %t79, true
  store i1 %t80, ptr %l56, !tbaa !21
  %t81 = load i1, ptr %l56, !tbaa !21
  br i1 %t81, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t82 = load i64, ptr %l3, !tbaa !65
  store i64 %t82, ptr %l57, !tbaa !65
  %t83 = load i64, ptr %l57, !tbaa !65
  %t84 = udiv i64 %t83, 10
  store i64 %t84, ptr %l58, !tbaa !65
  %t85 = load i64, ptr %l58, !tbaa !65
  store i64 %t85, ptr %l6, !tbaa !65
  %t86 = load i64, ptr %l2, !tbaa !24
  store i64 %t86, ptr %l59, !tbaa !24
  %t87 = load i64, ptr %l59, !tbaa !24
  %t88 = sub i64 %t87, 1
  store i64 %t88, ptr %l60, !tbaa !24
  %t89 = load i64, ptr %l60, !tbaa !24
  store i64 %t89, ptr %l2, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l61, !tbaa !29
  %t91 = load ptr, ptr %l61, !tbaa !29
  %t92 = getelementptr %"std/prelude/text:decimal", ptr %t91, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l62, !tbaa !27
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %l63, !tbaa !24
  %t95 = load i64, ptr %l3, !tbaa !65
  store i64 %t95, ptr %l64, !tbaa !65
  %t96 = load i64, ptr %l6, !tbaa !65
  store i64 %t96, ptr %l65, !tbaa !65
  %t97 = load i64, ptr %l65, !tbaa !65
  %t98 = mul i64 10, %t97
  store i64 %t98, ptr %l66, !tbaa !65
  %t99 = load i64, ptr %l64, !tbaa !65
  %t100 = load i64, ptr %l66, !tbaa !65
  %t101 = sub i64 %t99, %t100
  store i64 %t101, ptr %l67, !tbaa !65
  %t102 = load i64, ptr %l67, !tbaa !65
  %t103 = trunc i64 %t102 to i8
  store i8 %t103, ptr %l68, !tbaa !22
  %t104 = load i8, ptr %l68, !tbaa !22
  %t105 = load i64, ptr %l63, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 %t105
  store i8 %t104, ptr %t108, !tbaa !32
  %t109 = load i64, ptr %l6, !tbaa !65
  store i64 %t109, ptr %l69, !tbaa !65
  %t110 = load i64, ptr %l69, !tbaa !65
  store i64 %t110, ptr %l3, !tbaa !65
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb7
bb12:
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l70, !tbaa !29
  %t112 = load ptr, ptr %l70, !tbaa !29
  %t113 = getelementptr %"std/prelude/text:decimal", ptr %t112, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l71, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l72, !tbaa !24
  %t117 = load i64, ptr %l2, !tbaa !24
  store i64 %t117, ptr %l73, !tbaa !24
  %t118 = load i64, ptr %l72, !tbaa !24
  %t119 = load i64, ptr %l73, !tbaa !24
  %t120 = sub i64 %t118, %t119
  store i64 %t120, ptr %l74, !tbaa !24
  %t121 = load i64, ptr %l74, !tbaa !24
  store i64 %t121, ptr %l7, !tbaa !24
  %t122 = load ptr, ptr %l0, !tbaa !29
  store ptr %t122, ptr %l75, !tbaa !29
  %t123 = load ptr, ptr %l75, !tbaa !29
  %t124 = getelementptr %"std/prelude/text:decimal", ptr %t123, i32 0, i32 3
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l76, !tbaa !24
  %t126 = load i64, ptr %l7, !tbaa !24
  store i64 %t126, ptr %l77, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l78, !tbaa !29
  %t128 = load ptr, ptr %l78, !tbaa !29
  %t129 = getelementptr %"std/prelude/text:decimal", ptr %t128, i32 0, i32 2
  %t130 = load i64, ptr %t129, !tbaa !24
  store i64 %t130, ptr %l79, !tbaa !24
  %t131 = load i64, ptr %l77, !tbaa !24
  %t132 = load i64, ptr %l79, !tbaa !24
  %t133 = sub i64 %t131, %t132
  store i64 %t133, ptr %l80, !tbaa !24
  %t134 = load i64, ptr %l76, !tbaa !24
  %t135 = load i64, ptr %l80, !tbaa !24
  %t136 = add i64 %t134, %t135
  store i64 %t136, ptr %l81, !tbaa !24
  %t137 = load i64, ptr %l81, !tbaa !24
  %t138 = load ptr, ptr %l75, !tbaa !29
  %t139 = getelementptr %"std/prelude/text:decimal", ptr %t138, i32 0, i32 3
  store i64 %t137, ptr %t139, !tbaa !24
  %t140 = load i64, ptr %l7, !tbaa !24
  store i64 %t140, ptr %l82, !tbaa !24
  %t141 = load i64, ptr %l82, !tbaa !24
  %t142 = icmp slt i64 %t141, 800
  store i1 %t142, ptr %l83, !tbaa !21
  %t143 = load i1, ptr %l83, !tbaa !21
  br i1 %t143, label %bb13, label %bb14
bb13:
  %t144 = load i64, ptr %l7, !tbaa !24
  store i64 %t144, ptr %l85, !tbaa !24
  %t145 = load i64, ptr %l85, !tbaa !24
  store i64 %t145, ptr %l84, !tbaa !24
  br label %bb15
bb14:
  store i64 800, ptr %l84, !tbaa !24
  br label %bb15
bb15:
  %t146 = load i64, ptr %l84, !tbaa !24
  store i64 %t146, ptr %l8, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s3
  store i64 0, ptr %l9, !tbaa !24
  %t147 = load i64, ptr %l8, !tbaa !24
  store i64 %t147, ptr %l86, !tbaa !24
  %t148 = load i64, ptr %l86, !tbaa !24
  store i64 %t148, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t149 = load i64, ptr %l10, !tbaa !24
  store i64 %t149, ptr %l87, !tbaa !24
  %t150 = load i64, ptr %l9, !tbaa !24
  store i64 %t150, ptr %l88, !tbaa !24
  %t151 = load i64, ptr %l87, !tbaa !24
  %t152 = load i64, ptr %l88, !tbaa !24
  %t153 = icmp sgt i64 %t151, %t152
  store i1 %t153, ptr %l89, !tbaa !21
  %t154 = load i1, ptr %l89, !tbaa !21
  br i1 %t154, label %bb16, label %bb17
bb16:
  %t155 = load i64, ptr %l11, !tbaa !24
  store i64 %t155, ptr %l91, !tbaa !24
  %t156 = load i64, ptr %l91, !tbaa !24
  %t157 = icmp sgt i64 %t156, 0
  store i1 %t157, ptr %l92, !tbaa !21
  %t158 = load i1, ptr %l92, !tbaa !21
  br i1 %t158, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb21
bb18:
  %t159 = load i64, ptr %l10, !tbaa !24
  store i64 %t159, ptr %l94, !tbaa !24
  %t160 = load i64, ptr %l9, !tbaa !24
  store i64 %t160, ptr %l95, !tbaa !24
  %t161 = load i64, ptr %l94, !tbaa !24
  %t162 = load i64, ptr %l95, !tbaa !24
  %t163 = sub i64 %t161, %t162
  store i64 %t163, ptr %l96, !tbaa !24
  %t164 = load i64, ptr %l11, !tbaa !24
  store i64 %t164, ptr %l97, !tbaa !24
  %t165 = load i64, ptr %l96, !tbaa !24
  %t166 = load i64, ptr %l97, !tbaa !24
  %t167 = add i64 %t165, %t166
  store i64 %t167, ptr %l98, !tbaa !24
  %t168 = load i64, ptr %l98, !tbaa !24
  %t169 = sub i64 %t168, 1
  store i64 %t169, ptr %l99, !tbaa !24
  %t170 = load i64, ptr %l11, !tbaa !24
  store i64 %t170, ptr %l100, !tbaa !24
  %t171 = load i64, ptr %l99, !tbaa !24
  %t172 = load i64, ptr %l100, !tbaa !24
  %t173 = sdiv i64 %t171, %t172
  store i64 %t173, ptr %l101, !tbaa !24
  %t174 = load i64, ptr %l101, !tbaa !24
  store i64 %t174, ptr %l93, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb20
bb20:
  %t175 = load i64, ptr %l93, !tbaa !24
  store i64 %t175, ptr %l90, !tbaa !24
  br label %bb21
bb21:
  %t176 = load i64, ptr %l90, !tbaa !24
  store i64 %t176, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t177 = load i64, ptr %l13, !tbaa !24
  store i64 %t177, ptr %l102, !tbaa !24
  %t178 = load i64, ptr %l12, !tbaa !24
  store i64 %t178, ptr %l103, !tbaa !24
  %t179 = load i64, ptr %l102, !tbaa !24
  %t180 = load i64, ptr %l103, !tbaa !24
  %t181 = icmp slt i64 %t179, %t180
  store i1 %t181, ptr %l104, !tbaa !21
  %t182 = load i1, ptr %l104, !tbaa !21
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %l105, !tbaa !21
  %t184 = load i1, ptr %l105, !tbaa !21
  br i1 %t184, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t185 = load i64, ptr %l9, !tbaa !24
  store i64 %t185, ptr %l106, !tbaa !24
  %t186 = load i64, ptr %l13, !tbaa !24
  store i64 %t186, ptr %l107, !tbaa !24
  %t187 = load i64, ptr %l11, !tbaa !24
  store i64 %t187, ptr %l108, !tbaa !24
  %t188 = load i64, ptr %l107, !tbaa !24
  %t189 = load i64, ptr %l108, !tbaa !24
  %t190 = mul i64 %t188, %t189
  store i64 %t190, ptr %l109, !tbaa !24
  %t191 = load i64, ptr %l106, !tbaa !24
  %t192 = load i64, ptr %l109, !tbaa !24
  %t193 = add i64 %t191, %t192
  store i64 %t193, ptr %l110, !tbaa !24
  %t194 = load i64, ptr %l110, !tbaa !24
  store i64 %t194, ptr %l14, !tbaa !24
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l111, !tbaa !29
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t197 = getelementptr %"std/prelude/text:decimal", ptr %t196, i32 0, i32 0
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  store { i64, ptr } %t198, ptr %l112, !tbaa !27
  %t199 = load i64, ptr %l14, !tbaa !24
  store i64 %t199, ptr %l113, !tbaa !24
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l114, !tbaa !29
  %t201 = load ptr, ptr %l114, !tbaa !29
  %t202 = getelementptr %"std/prelude/text:decimal", ptr %t201, i32 0, i32 1
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l115, !tbaa !27
  %t204 = load i64, ptr %l2, !tbaa !24
  store i64 %t204, ptr %l116, !tbaa !24
  %t205 = load i64, ptr %l14, !tbaa !24
  store i64 %t205, ptr %l117, !tbaa !24
  %t206 = load i64, ptr %l116, !tbaa !24
  %t207 = load i64, ptr %l117, !tbaa !24
  %t208 = add i64 %t206, %t207
  store i64 %t208, ptr %l118, !tbaa !24
  %t209 = load i64, ptr %l118, !tbaa !24
  %t210 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = getelementptr i8, ptr %t211, i64 %t209
  %t213 = load i8, ptr %t212, !tbaa !32
  store i8 %t213, ptr %l119, !tbaa !22
  %t214 = load i8, ptr %l119, !tbaa !22
  %t215 = load i64, ptr %l113, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr i8, ptr %t217, i64 %t215
  store i8 %t214, ptr %t218, !tbaa !32
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t219 = load i64, ptr %l13, !tbaa !24
  store i64 %t219, ptr %l120, !tbaa !24
  %t220 = load i64, ptr %l120, !tbaa !24
  %t221 = add i64 %t220, 1
  store i64 %t221, ptr %l121, !tbaa !24
  %t222 = load i64, ptr %l121, !tbaa !24
  store i64 %t222, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb27:
  call void @__olang_scope_close(ptr %s3)
  store %olang.scope zeroinitializer, ptr %s6
  %t223 = load i64, ptr %l8, !tbaa !24
  store i64 %t223, ptr %l122, !tbaa !24
  %t224 = load i64, ptr %l122, !tbaa !24
  store i64 %t224, ptr %l15, !tbaa !24
  %t225 = load i64, ptr %l7, !tbaa !24
  store i64 %t225, ptr %l123, !tbaa !24
  %t226 = load i64, ptr %l123, !tbaa !24
  store i64 %t226, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t227 = load i64, ptr %l16, !tbaa !24
  store i64 %t227, ptr %l124, !tbaa !24
  %t228 = load i64, ptr %l15, !tbaa !24
  store i64 %t228, ptr %l125, !tbaa !24
  %t229 = load i64, ptr %l124, !tbaa !24
  %t230 = load i64, ptr %l125, !tbaa !24
  %t231 = icmp sgt i64 %t229, %t230
  store i1 %t231, ptr %l126, !tbaa !21
  %t232 = load i1, ptr %l126, !tbaa !21
  br i1 %t232, label %bb28, label %bb29
bb28:
  %t233 = load i64, ptr %l17, !tbaa !24
  store i64 %t233, ptr %l128, !tbaa !24
  %t234 = load i64, ptr %l128, !tbaa !24
  %t235 = icmp sgt i64 %t234, 0
  store i1 %t235, ptr %l129, !tbaa !21
  %t236 = load i1, ptr %l129, !tbaa !21
  br i1 %t236, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb33
bb30:
  %t237 = load i64, ptr %l16, !tbaa !24
  store i64 %t237, ptr %l131, !tbaa !24
  %t238 = load i64, ptr %l15, !tbaa !24
  store i64 %t238, ptr %l132, !tbaa !24
  %t239 = load i64, ptr %l131, !tbaa !24
  %t240 = load i64, ptr %l132, !tbaa !24
  %t241 = sub i64 %t239, %t240
  store i64 %t241, ptr %l133, !tbaa !24
  %t242 = load i64, ptr %l17, !tbaa !24
  store i64 %t242, ptr %l134, !tbaa !24
  %t243 = load i64, ptr %l133, !tbaa !24
  %t244 = load i64, ptr %l134, !tbaa !24
  %t245 = add i64 %t243, %t244
  store i64 %t245, ptr %l135, !tbaa !24
  %t246 = load i64, ptr %l135, !tbaa !24
  %t247 = sub i64 %t246, 1
  store i64 %t247, ptr %l136, !tbaa !24
  %t248 = load i64, ptr %l17, !tbaa !24
  store i64 %t248, ptr %l137, !tbaa !24
  %t249 = load i64, ptr %l136, !tbaa !24
  %t250 = load i64, ptr %l137, !tbaa !24
  %t251 = sdiv i64 %t249, %t250
  store i64 %t251, ptr %l138, !tbaa !24
  %t252 = load i64, ptr %l138, !tbaa !24
  store i64 %t252, ptr %l130, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb32
bb32:
  %t253 = load i64, ptr %l130, !tbaa !24
  store i64 %t253, ptr %l127, !tbaa !24
  br label %bb33
bb33:
  %t254 = load i64, ptr %l127, !tbaa !24
  store i64 %t254, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t255 = load i64, ptr %l19, !tbaa !24
  store i64 %t255, ptr %l139, !tbaa !24
  %t256 = load i64, ptr %l18, !tbaa !24
  store i64 %t256, ptr %l140, !tbaa !24
  %t257 = load i64, ptr %l139, !tbaa !24
  %t258 = load i64, ptr %l140, !tbaa !24
  %t259 = icmp slt i64 %t257, %t258
  store i1 %t259, ptr %l141, !tbaa !21
  %t260 = load i1, ptr %l141, !tbaa !21
  %t261 = xor i1 %t260, true
  store i1 %t261, ptr %l142, !tbaa !21
  %t262 = load i1, ptr %l142, !tbaa !21
  br i1 %t262, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb42
bb36:
  br label %bb37
bb37:
  %t263 = load i64, ptr %l15, !tbaa !24
  store i64 %t263, ptr %l143, !tbaa !24
  %t264 = load i64, ptr %l19, !tbaa !24
  store i64 %t264, ptr %l144, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  store i64 %t265, ptr %l145, !tbaa !24
  %t266 = load i64, ptr %l144, !tbaa !24
  %t267 = load i64, ptr %l145, !tbaa !24
  %t268 = mul i64 %t266, %t267
  store i64 %t268, ptr %l146, !tbaa !24
  %t269 = load i64, ptr %l143, !tbaa !24
  %t270 = load i64, ptr %l146, !tbaa !24
  %t271 = add i64 %t269, %t270
  store i64 %t271, ptr %l147, !tbaa !24
  %t272 = load i64, ptr %l147, !tbaa !24
  store i64 %t272, ptr %l20, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  store ptr %t273, ptr %l148, !tbaa !29
  %t274 = load ptr, ptr %l148, !tbaa !29
  %t275 = getelementptr %"std/prelude/text:decimal", ptr %t274, i32 0, i32 1
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  store { i64, ptr } %t276, ptr %l149, !tbaa !27
  %t277 = load i64, ptr %l2, !tbaa !24
  store i64 %t277, ptr %l150, !tbaa !24
  %t278 = load i64, ptr %l20, !tbaa !24
  store i64 %t278, ptr %l151, !tbaa !24
  %t279 = load i64, ptr %l150, !tbaa !24
  %t280 = load i64, ptr %l151, !tbaa !24
  %t281 = add i64 %t279, %t280
  store i64 %t281, ptr %l152, !tbaa !24
  %t282 = load i64, ptr %l152, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i8, ptr %t284, i64 %t282
  %t286 = load i8, ptr %t285, !tbaa !32
  store i8 %t286, ptr %l153, !tbaa !22
  %t287 = load i8, ptr %l153, !tbaa !22
  %t288 = icmp ne i8 %t287, 0
  store i1 %t288, ptr %l154, !tbaa !21
  %t289 = load i1, ptr %l154, !tbaa !21
  br i1 %t289, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t290 = load ptr, ptr %l0, !tbaa !29
  store ptr %t290, ptr %l155, !tbaa !29
  %t291 = load ptr, ptr %l155, !tbaa !29
  %t292 = getelementptr %"std/prelude/text:decimal", ptr %t291, i32 0, i32 4
  store i1 true, ptr %t292, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb39:
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t293 = load i64, ptr %l19, !tbaa !24
  store i64 %t293, ptr %l156, !tbaa !24
  %t294 = load i64, ptr %l156, !tbaa !24
  %t295 = add i64 %t294, 1
  store i64 %t295, ptr %l157, !tbaa !24
  %t296 = load i64, ptr %l157, !tbaa !24
  store i64 %t296, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb34
bb42:
  call void @__olang_scope_close(ptr %s6)
  %t297 = load ptr, ptr %l0, !tbaa !29
  store ptr %t297, ptr %l158, !tbaa !29
  %t298 = load i64, ptr %l8, !tbaa !24
  store i64 %t298, ptr %l159, !tbaa !24
  %t299 = load i64, ptr %l159, !tbaa !24
  %t300 = load ptr, ptr %l158, !tbaa !29
  %t301 = getelementptr %"std/prelude/text:decimal", ptr %t300, i32 0, i32 2
  store i64 %t299, ptr %t301, !tbaa !24
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l160, !tbaa !29
  %t303 = load ptr, ptr %l160, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2etrim(ptr %v0, ptr %t303)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2erightShift(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i8
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i8
  %l56 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i8
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i8
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i8
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca i64
  %l99 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !65
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load i64, ptr %l4, !tbaa !65
  store i64 %t1, ptr %l8, !tbaa !65
  %t2 = load i64, ptr %l1, !tbaa !65
  store i64 %t2, ptr %l9, !tbaa !65
  %t3 = load i64, ptr %l8, !tbaa !65
  %t4 = load i64, ptr %l9, !tbaa !65
  %t5 = load i64, ptr %l9, !tbaa !65
  %t6 = lshr i64 %t3, %t5
  store i64 %t6, ptr %l10, !tbaa !65
  %t7 = load i64, ptr %l10, !tbaa !65
  %t8 = icmp eq i64 %t7, 0
  store i1 %t8, ptr %l11, !tbaa !21
  %t9 = load i1, ptr %l11, !tbaa !21
  %t10 = xor i1 %t9, true
  store i1 %t10, ptr %l12, !tbaa !21
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l13, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t15 = getelementptr %"std/prelude/text:decimal", ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = load i64, ptr %l13, !tbaa !24
  %t18 = load i64, ptr %l15, !tbaa !24
  %t19 = icmp sge i64 %t17, %t18
  store i1 %t19, ptr %l16, !tbaa !21
  %t20 = load i1, ptr %l16, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l4, !tbaa !65
  store i64 %t21, ptr %l17, !tbaa !65
  %t22 = load i64, ptr %l17, !tbaa !65
  %t23 = icmp eq i64 %t22, 0
  store i1 %t23, ptr %l18, !tbaa !21
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb6:
  br label %bb16
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l19, !tbaa !29
  %t26 = load ptr, ptr %l19, !tbaa !29
  %t27 = getelementptr %"std/prelude/text:decimal", ptr %t26, i32 0, i32 2
  store i64 0, ptr %t27, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t28 = load i64, ptr %l4, !tbaa !65
  store i64 %t28, ptr %l20, !tbaa !65
  %t29 = load i64, ptr %l1, !tbaa !65
  store i64 %t29, ptr %l21, !tbaa !65
  %t30 = load i64, ptr %l20, !tbaa !65
  %t31 = load i64, ptr %l21, !tbaa !65
  %t32 = load i64, ptr %l21, !tbaa !65
  %t33 = lshr i64 %t30, %t32
  store i64 %t33, ptr %l22, !tbaa !65
  %t34 = load i64, ptr %l22, !tbaa !65
  %t35 = icmp eq i64 %t34, 0
  store i1 %t35, ptr %l23, !tbaa !21
  %t36 = load i1, ptr %l23, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l24, !tbaa !21
  %t38 = load i1, ptr %l24, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t39 = load i64, ptr %l4, !tbaa !65
  store i64 %t39, ptr %l25, !tbaa !65
  %t40 = load i64, ptr %l25, !tbaa !65
  %t41 = mul i64 %t40, 10
  store i64 %t41, ptr %l26, !tbaa !65
  %t42 = load i64, ptr %l26, !tbaa !65
  store i64 %t42, ptr %l4, !tbaa !65
  %t43 = load i64, ptr %l2, !tbaa !24
  store i64 %t43, ptr %l27, !tbaa !24
  %t44 = load i64, ptr %l27, !tbaa !24
  %t45 = add i64 %t44, 1
  store i64 %t45, ptr %l28, !tbaa !24
  %t46 = load i64, ptr %l28, !tbaa !24
  store i64 %t46, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb14:
  br label %bb10
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %bb18
bb16:
  %t47 = load i64, ptr %l4, !tbaa !65
  store i64 %t47, ptr %l29, !tbaa !65
  %t48 = load i64, ptr %l29, !tbaa !65
  %t49 = mul i64 %t48, 10
  store i64 %t49, ptr %l30, !tbaa !65
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load ptr, ptr %l31, !tbaa !29
  %t52 = getelementptr %"std/prelude/text:decimal", ptr %t51, i32 0, i32 0
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l32, !tbaa !27
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l33, !tbaa !24
  %t55 = load i64, ptr %l33, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i8, ptr %t57, i64 %t55
  %t59 = load i8, ptr %t58, !tbaa !32
  store i8 %t59, ptr %l34, !tbaa !22
  %t60 = load i8, ptr %l34, !tbaa !22
  %t61 = zext i8 %t60 to i64
  store i64 %t61, ptr %l35, !tbaa !65
  %t62 = load i64, ptr %l30, !tbaa !65
  %t63 = load i64, ptr %l35, !tbaa !65
  %t64 = add i64 %t62, %t63
  store i64 %t64, ptr %l36, !tbaa !65
  %t65 = load i64, ptr %l36, !tbaa !65
  store i64 %t65, ptr %l4, !tbaa !65
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l37, !tbaa !24
  %t67 = load i64, ptr %l37, !tbaa !24
  %t68 = add i64 %t67, 1
  store i64 %t68, ptr %l38, !tbaa !24
  %t69 = load i64, ptr %l38, !tbaa !24
  store i64 %t69, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l39, !tbaa !29
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t72 = getelementptr %"std/prelude/text:decimal", ptr %t71, i32 0, i32 3
  %t73 = load i64, ptr %t72, !tbaa !24
  store i64 %t73, ptr %l40, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %l41, !tbaa !24
  %t75 = load i64, ptr %l41, !tbaa !24
  %t76 = sub i64 %t75, 1
  store i64 %t76, ptr %l42, !tbaa !24
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = sub i64 %t77, %t78
  store i64 %t79, ptr %l43, !tbaa !24
  %t80 = load i64, ptr %l43, !tbaa !24
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = getelementptr %"std/prelude/text:decimal", ptr %t81, i32 0, i32 3
  store i64 %t80, ptr %t82, !tbaa !24
  %t83 = load i64, ptr %l1, !tbaa !65
  store i64 %t83, ptr %l44, !tbaa !65
  %t84 = load i64, ptr %l44, !tbaa !65
  %t85 = load i64, ptr %l44, !tbaa !65
  %t86 = shl i64 1, %t85
  store i64 %t86, ptr %l45, !tbaa !65
  %t87 = load i64, ptr %l45, !tbaa !65
  %t88 = sub i64 %t87, 1
  store i64 %t88, ptr %l46, !tbaa !65
  %t89 = load i64, ptr %l46, !tbaa !65
  store i64 %t89, ptr %l5, !tbaa !65
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load i64, ptr %l2, !tbaa !24
  store i64 %t90, ptr %l47, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load ptr, ptr %l48, !tbaa !29
  %t93 = getelementptr %"std/prelude/text:decimal", ptr %t92, i32 0, i32 2
  %t94 = load i64, ptr %t93, !tbaa !24
  store i64 %t94, ptr %l49, !tbaa !24
  %t95 = load i64, ptr %l47, !tbaa !24
  %t96 = load i64, ptr %l49, !tbaa !24
  %t97 = icmp slt i64 %t95, %t96
  store i1 %t97, ptr %l50, !tbaa !21
  %t98 = load i1, ptr %l50, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l51, !tbaa !21
  %t100 = load i1, ptr %l51, !tbaa !21
  br i1 %t100, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l52, !tbaa !29
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = getelementptr %"std/prelude/text:decimal", ptr %t102, i32 0, i32 0
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = load i64, ptr %l2, !tbaa !24
  store i64 %t105, ptr %l54, !tbaa !24
  %t106 = load i64, ptr %l54, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i8, ptr %t108, i64 %t106
  %t110 = load i8, ptr %t109, !tbaa !32
  store i8 %t110, ptr %l55, !tbaa !22
  %t111 = load i8, ptr %l55, !tbaa !22
  store i8 %t111, ptr %l6, !tbaa !22
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l56, !tbaa !29
  %t113 = load ptr, ptr %l56, !tbaa !29
  %t114 = getelementptr %"std/prelude/text:decimal", ptr %t113, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l57, !tbaa !27
  %t116 = load i64, ptr %l3, !tbaa !24
  store i64 %t116, ptr %l58, !tbaa !24
  %t117 = load i64, ptr %l4, !tbaa !65
  store i64 %t117, ptr %l59, !tbaa !65
  %t118 = load i64, ptr %l1, !tbaa !65
  store i64 %t118, ptr %l60, !tbaa !65
  %t119 = load i64, ptr %l59, !tbaa !65
  %t120 = load i64, ptr %l60, !tbaa !65
  %t121 = load i64, ptr %l60, !tbaa !65
  %t122 = lshr i64 %t119, %t121
  store i64 %t122, ptr %l61, !tbaa !65
  %t123 = load i64, ptr %l61, !tbaa !65
  %t124 = trunc i64 %t123 to i8
  store i8 %t124, ptr %l62, !tbaa !22
  %t125 = load i8, ptr %l62, !tbaa !22
  %t126 = load i64, ptr %l58, !tbaa !24
  %t127 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = getelementptr i8, ptr %t128, i64 %t126
  store i8 %t125, ptr %t129, !tbaa !32
  %t130 = load i64, ptr %l3, !tbaa !24
  store i64 %t130, ptr %l63, !tbaa !24
  %t131 = load i64, ptr %l63, !tbaa !24
  %t132 = add i64 %t131, 1
  store i64 %t132, ptr %l64, !tbaa !24
  %t133 = load i64, ptr %l64, !tbaa !24
  store i64 %t133, ptr %l3, !tbaa !24
  %t134 = load i64, ptr %l4, !tbaa !65
  store i64 %t134, ptr %l65, !tbaa !65
  %t135 = load i64, ptr %l5, !tbaa !65
  store i64 %t135, ptr %l66, !tbaa !65
  %t136 = load i64, ptr %l65, !tbaa !65
  %t137 = load i64, ptr %l66, !tbaa !65
  %t138 = and i64 %t136, %t137
  store i64 %t138, ptr %l67, !tbaa !65
  %t139 = load i64, ptr %l67, !tbaa !65
  %t140 = mul i64 %t139, 10
  store i64 %t140, ptr %l68, !tbaa !65
  %t141 = load i8, ptr %l6, !tbaa !22
  store i8 %t141, ptr %l69, !tbaa !22
  %t142 = load i8, ptr %l69, !tbaa !22
  %t143 = zext i8 %t142 to i64
  store i64 %t143, ptr %l70, !tbaa !65
  %t144 = load i64, ptr %l68, !tbaa !65
  %t145 = load i64, ptr %l70, !tbaa !65
  %t146 = add i64 %t144, %t145
  store i64 %t146, ptr %l71, !tbaa !65
  %t147 = load i64, ptr %l71, !tbaa !65
  store i64 %t147, ptr %l4, !tbaa !65
  %t148 = load i64, ptr %l2, !tbaa !24
  store i64 %t148, ptr %l72, !tbaa !24
  %t149 = load i64, ptr %l72, !tbaa !24
  %t150 = add i64 %t149, 1
  store i64 %t150, ptr %l73, !tbaa !24
  %t151 = load i64, ptr %l73, !tbaa !24
  store i64 %t151, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb23:
  br label %bb19
bb24:
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t152 = load i64, ptr %l4, !tbaa !65
  store i64 %t152, ptr %l74, !tbaa !65
  %t153 = load i64, ptr %l74, !tbaa !65
  %t154 = icmp ugt i64 %t153, 0
  store i1 %t154, ptr %l75, !tbaa !21
  %t155 = load i1, ptr %l75, !tbaa !21
  %t156 = xor i1 %t155, true
  store i1 %t156, ptr %l76, !tbaa !21
  %t157 = load i1, ptr %l76, !tbaa !21
  br i1 %t157, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t158 = load i64, ptr %l4, !tbaa !65
  store i64 %t158, ptr %l77, !tbaa !65
  %t159 = load i64, ptr %l1, !tbaa !65
  store i64 %t159, ptr %l78, !tbaa !65
  %t160 = load i64, ptr %l77, !tbaa !65
  %t161 = load i64, ptr %l78, !tbaa !65
  %t162 = load i64, ptr %l78, !tbaa !65
  %t163 = lshr i64 %t160, %t162
  store i64 %t163, ptr %l79, !tbaa !65
  %t164 = load i64, ptr %l79, !tbaa !65
  store i64 %t164, ptr %l7, !tbaa !65
  %t165 = load i64, ptr %l4, !tbaa !65
  store i64 %t165, ptr %l80, !tbaa !65
  %t166 = load i64, ptr %l5, !tbaa !65
  store i64 %t166, ptr %l81, !tbaa !65
  %t167 = load i64, ptr %l80, !tbaa !65
  %t168 = load i64, ptr %l81, !tbaa !65
  %t169 = and i64 %t167, %t168
  store i64 %t169, ptr %l82, !tbaa !65
  %t170 = load i64, ptr %l82, !tbaa !65
  store i64 %t170, ptr %l4, !tbaa !65
  %t171 = load i64, ptr %l3, !tbaa !24
  store i64 %t171, ptr %l83, !tbaa !24
  %t172 = load i64, ptr %l83, !tbaa !24
  %t173 = icmp slt i64 %t172, 800
  store i1 %t173, ptr %l84, !tbaa !21
  %t174 = load i1, ptr %l84, !tbaa !21
  br i1 %t174, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l85, !tbaa !29
  %t176 = load ptr, ptr %l85, !tbaa !29
  %t177 = getelementptr %"std/prelude/text:decimal", ptr %t176, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l86, !tbaa !27
  %t179 = load i64, ptr %l3, !tbaa !24
  store i64 %t179, ptr %l87, !tbaa !24
  %t180 = load i64, ptr %l7, !tbaa !65
  store i64 %t180, ptr %l88, !tbaa !65
  %t181 = load i64, ptr %l88, !tbaa !65
  %t182 = trunc i64 %t181 to i8
  store i8 %t182, ptr %l89, !tbaa !22
  %t183 = load i8, ptr %l89, !tbaa !22
  %t184 = load i64, ptr %l87, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i8, ptr %t186, i64 %t184
  store i8 %t183, ptr %t187, !tbaa !32
  %t188 = load i64, ptr %l3, !tbaa !24
  store i64 %t188, ptr %l90, !tbaa !24
  %t189 = load i64, ptr %l90, !tbaa !24
  %t190 = add i64 %t189, 1
  store i64 %t190, ptr %l91, !tbaa !24
  %t191 = load i64, ptr %l91, !tbaa !24
  store i64 %t191, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t192 = load i64, ptr %l7, !tbaa !65
  store i64 %t192, ptr %l92, !tbaa !65
  %t193 = load i64, ptr %l92, !tbaa !65
  %t194 = icmp ugt i64 %t193, 0
  store i1 %t194, ptr %l93, !tbaa !21
  %t195 = load i1, ptr %l93, !tbaa !21
  br i1 %t195, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s9
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l94, !tbaa !29
  %t197 = load ptr, ptr %l94, !tbaa !29
  %t198 = getelementptr %"std/prelude/text:decimal", ptr %t197, i32 0, i32 4
  store i1 true, ptr %t198, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s8)
  br label %bb34
bb34:
  %t199 = load i64, ptr %l4, !tbaa !65
  store i64 %t199, ptr %l95, !tbaa !65
  %t200 = load i64, ptr %l95, !tbaa !65
  %t201 = mul i64 %t200, 10
  store i64 %t201, ptr %l96, !tbaa !65
  %t202 = load i64, ptr %l96, !tbaa !65
  store i64 %t202, ptr %l4, !tbaa !65
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  br label %bb25
bb36:
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l97, !tbaa !29
  %t204 = load i64, ptr %l3, !tbaa !24
  store i64 %t204, ptr %l98, !tbaa !24
  %t205 = load i64, ptr %l98, !tbaa !24
  %t206 = load ptr, ptr %l97, !tbaa !29
  %t207 = getelementptr %"std/prelude/text:decimal", ptr %t206, i32 0, i32 2
  store i64 %t205, ptr %t207, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  store ptr %t208, ptr %l99, !tbaa !29
  %t209 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2etrim(ptr %v0, ptr %t209)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundedInteger(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i8
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t2, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  %t6 = icmp sgt i64 %t5, 20
  store i1 %t6, ptr %l5, !tbaa !21
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = xor i64 0, -1
  store i64 %t8, ptr %l6, !tbaa !65
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i64, ptr %l6, !tbaa !65
  store i64 %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !65
  store i64 0, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t13 = getelementptr %"std/prelude/text:decimal", ptr %t12, i32 0, i32 3
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l9, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  store i1 %t17, ptr %l10, !tbaa !21
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l12, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l13, !tbaa !29
  %t21 = load ptr, ptr %l13, !tbaa !29
  %t22 = getelementptr %"std/prelude/text:decimal", ptr %t21, i32 0, i32 2
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l14, !tbaa !24
  %t24 = load i64, ptr %l12, !tbaa !24
  %t25 = load i64, ptr %l14, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  %t27 = load i1, ptr %l15, !tbaa !21
  store i1 %t27, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l11, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l16, !tbaa !21
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t31 = load i64, ptr %l1, !tbaa !65
  store i64 %t31, ptr %l17, !tbaa !65
  %t32 = load i64, ptr %l17, !tbaa !65
  %t33 = mul i64 %t32, 10
  store i64 %t33, ptr %l18, !tbaa !65
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l19, !tbaa !29
  %t35 = load ptr, ptr %l19, !tbaa !29
  %t36 = getelementptr %"std/prelude/text:decimal", ptr %t35, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l20, !tbaa !27
  %t38 = load i64, ptr %l2, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !24
  %t39 = load i64, ptr %l21, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 %t39
  %t43 = load i8, ptr %t42, !tbaa !32
  store i8 %t43, ptr %l22, !tbaa !22
  %t44 = load i8, ptr %l22, !tbaa !22
  %t45 = zext i8 %t44 to i64
  store i64 %t45, ptr %l23, !tbaa !65
  %t46 = load i64, ptr %l18, !tbaa !65
  %t47 = load i64, ptr %l23, !tbaa !65
  %t48 = add i64 %t46, %t47
  store i64 %t48, ptr %l24, !tbaa !65
  %t49 = load i64, ptr %l24, !tbaa !65
  store i64 %t49, ptr %l1, !tbaa !65
  %t50 = load i64, ptr %l2, !tbaa !24
  store i64 %t50, ptr %l25, !tbaa !24
  %t51 = load i64, ptr %l25, !tbaa !24
  %t52 = add i64 %t51, 1
  store i64 %t52, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  store i64 %t53, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  br label %bb4
bb12:
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l27, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l28, !tbaa !29
  %t56 = load ptr, ptr %l28, !tbaa !29
  %t57 = getelementptr %"std/prelude/text:decimal", ptr %t56, i32 0, i32 3
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l29, !tbaa !24
  %t59 = load i64, ptr %l27, !tbaa !24
  %t60 = load i64, ptr %l29, !tbaa !24
  %t61 = icmp slt i64 %t59, %t60
  store i1 %t61, ptr %l30, !tbaa !21
  %t62 = load i1, ptr %l30, !tbaa !21
  %t63 = xor i1 %t62, true
  store i1 %t63, ptr %l31, !tbaa !21
  %t64 = load i1, ptr %l31, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l1, !tbaa !65
  store i64 %t65, ptr %l32, !tbaa !65
  %t66 = load i64, ptr %l32, !tbaa !65
  %t67 = mul i64 %t66, 10
  store i64 %t67, ptr %l33, !tbaa !65
  %t68 = load i64, ptr %l33, !tbaa !65
  store i64 %t68, ptr %l1, !tbaa !65
  %t69 = load i64, ptr %l2, !tbaa !24
  store i64 %t69, ptr %l34, !tbaa !24
  %t70 = load i64, ptr %l34, !tbaa !24
  %t71 = add i64 %t70, 1
  store i64 %t71, ptr %l35, !tbaa !24
  %t72 = load i64, ptr %l35, !tbaa !24
  store i64 %t72, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  br label %bb13
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l36, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l37, !tbaa !29
  %t75 = load ptr, ptr %l37, !tbaa !29
  %t76 = getelementptr %"std/prelude/text:decimal", ptr %t75, i32 0, i32 3
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l38, !tbaa !24
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = load i64, ptr %l38, !tbaa !24
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundsUp(ptr %v0, ptr %t78, i64 %t79)
  store i1 %t80, ptr %l39
  br label %bb19
bb19:
  %t81 = load i1, ptr %l39, !tbaa !21
  br i1 %t81, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load i64, ptr %l1, !tbaa !65
  store i64 %t82, ptr %l40, !tbaa !65
  %t83 = load i64, ptr %l40, !tbaa !65
  %t84 = add i64 %t83, 1
  store i64 %t84, ptr %l41, !tbaa !65
  %t85 = load i64, ptr %l41, !tbaa !65
  store i64 %t85, ptr %l1, !tbaa !65
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t86 = load i64, ptr %l1, !tbaa !65
  store i64 %t86, ptr %l42, !tbaa !65
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i64, ptr %l42, !tbaa !65
  store i64 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eroundsUp(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i8
  %l32 = alloca i8
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i8
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"std/prelude/text:decimal", ptr %t7, i32 0, i32 2
  %t9 = load i64, ptr %t8, !tbaa !24
  store i64 %t9, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = icmp sge i64 %t10, %t11
  store i1 %t12, ptr %l8, !tbaa !21
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l4, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l9, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i1, ptr %l9, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = getelementptr %"std/prelude/text:decimal", ptr %t17, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18, !tbaa !27
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l12, !tbaa !24
  %t21 = load i64, ptr %l12, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t21
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l13, !tbaa !22
  %t26 = load i8, ptr %l13, !tbaa !22
  %t27 = icmp eq i8 %t26, 5
  store i1 %t27, ptr %l14, !tbaa !21
  %t28 = load i1, ptr %l14, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l16, !tbaa !24
  %t30 = load i64, ptr %l16, !tbaa !24
  %t31 = add i64 %t30, 1
  store i64 %t31, ptr %l17, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"std/prelude/text:decimal", ptr %t33, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l19, !tbaa !24
  %t36 = load i64, ptr %l17, !tbaa !24
  %t37 = load i64, ptr %l19, !tbaa !24
  %t38 = icmp eq i64 %t36, %t37
  store i1 %t38, ptr %l20, !tbaa !21
  %t39 = load i1, ptr %l20, !tbaa !21
  store i1 %t39, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l15, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load ptr, ptr %l21, !tbaa !29
  %t43 = getelementptr %"std/prelude/text:decimal", ptr %t42, i32 0, i32 4
  %t44 = load i1, ptr %t43, !tbaa !21
  store i1 %t44, ptr %l22, !tbaa !21
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb12, label %bb13
bb11:
  br label %bb18
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  store i1 true, ptr %l23, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t47 = load i64, ptr %l1, !tbaa !24
  store i64 %t47, ptr %l24, !tbaa !24
  %t48 = load i64, ptr %l24, !tbaa !24
  %t49 = icmp sgt i64 %t48, 0
  store i1 %t49, ptr %l25, !tbaa !21
  %t50 = load i1, ptr %l25, !tbaa !21
  br i1 %t50, label %bb15, label %bb16
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l27, !tbaa !29
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = getelementptr %"std/prelude/text:decimal", ptr %t52, i32 0, i32 0
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l28, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  store i64 %t55, ptr %l29, !tbaa !24
  %t56 = load i64, ptr %l29, !tbaa !24
  %t57 = sub i64 %t56, 1
  store i64 %t57, ptr %l30, !tbaa !24
  %t58 = load i64, ptr %l30, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t58
  %t62 = load i8, ptr %t61, !tbaa !32
  store i8 %t62, ptr %l31, !tbaa !22
  %t63 = load i8, ptr %l31, !tbaa !22
  %t64 = urem i8 %t63, 2
  store i8 %t64, ptr %l32, !tbaa !22
  %t65 = load i8, ptr %l32, !tbaa !22
  %t66 = icmp eq i8 %t65, 1
  store i1 %t66, ptr %l33, !tbaa !21
  %t67 = load i1, ptr %l33, !tbaa !21
  store i1 %t67, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i1, ptr %l26, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
bb18:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l34, !tbaa !29
  %t70 = load ptr, ptr %l34, !tbaa !29
  %t71 = getelementptr %"std/prelude/text:decimal", ptr %t70, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l35, !tbaa !27
  %t73 = load i64, ptr %l1, !tbaa !24
  store i64 %t73, ptr %l36, !tbaa !24
  %t74 = load i64, ptr %l36, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t74
  %t78 = load i8, ptr %t77, !tbaa !32
  store i8 %t78, ptr %l37, !tbaa !22
  %t79 = load i8, ptr %l37, !tbaa !22
  %t80 = icmp uge i8 %t79, 5
  store i1 %t80, ptr %l38, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i1, ptr %l38, !tbaa !21
  store i1 %t81, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eset(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i8
  %l15 = alloca i8
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i8
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i8
  %l24 = alloca i1
  %l25 = alloca i8
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i8
  %l42 = alloca i8
  %l43 = alloca i8
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i8
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca i8
  %l66 = alloca i1
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca i8
  %l72 = alloca i1
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i8
  %l87 = alloca i8
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l7, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t2, ptr %l8, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  store i64 %t4, ptr %l9, !tbaa !24
  %t5 = load i64, ptr %l7, !tbaa !24
  %t6 = load i64, ptr %l9, !tbaa !24
  %t7 = icmp slt i64 %t5, %t6
  store i1 %t7, ptr %l10, !tbaa !21
  %t8 = load i1, ptr %l10, !tbaa !21
  %t9 = xor i1 %t8, true
  store i1 %t9, ptr %l11, !tbaa !21
  %t10 = load i1, ptr %l11, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb3:
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l12, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l13, !tbaa !24
  %t13 = load i64, ptr %l13, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 %t13
  %t17 = load i8, ptr %t16, !tbaa !32
  store i8 %t17, ptr %l14, !tbaa !22
  %t18 = load i8, ptr %l14, !tbaa !22
  store i8 %t18, ptr %l4, !tbaa !22
  %t19 = load i8, ptr %l4, !tbaa !22
  store i8 %t19, ptr %l15, !tbaa !22
  %t20 = load i8, ptr %l15, !tbaa !22
  %t21 = icmp eq i8 %t20, 46
  store i1 %t21, ptr %l16, !tbaa !21
  %t22 = load i1, ptr %l16, !tbaa !21
  br i1 %t22, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 true, ptr %l3, !tbaa !21
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l18, !tbaa !29
  %t26 = getelementptr %"std/prelude/text:decimal", ptr %t25, i32 0, i32 2
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l19, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = load ptr, ptr %l17, !tbaa !29
  %t30 = getelementptr %"std/prelude/text:decimal", ptr %t29, i32 0, i32 3
  store i64 %t28, ptr %t30, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i8, ptr %l4, !tbaa !22
  store i8 %t31, ptr %l20, !tbaa !22
  %t32 = load i8, ptr %l20, !tbaa !22
  %t33 = icmp ult i8 %t32, 48
  store i1 %t33, ptr %l21, !tbaa !21
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb9
bb8:
  %t35 = load i8, ptr %l4, !tbaa !22
  store i8 %t35, ptr %l23, !tbaa !22
  %t36 = load i8, ptr %l23, !tbaa !22
  %t37 = icmp ugt i8 %t36, 57
  store i1 %t37, ptr %l24, !tbaa !21
  %t38 = load i1, ptr %l24, !tbaa !21
  store i1 %t38, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t40 = load i8, ptr %l4, !tbaa !22
  store i8 %t40, ptr %l25, !tbaa !22
  %t41 = load i8, ptr %l25, !tbaa !22
  %t42 = icmp eq i8 %t41, 48
  store i1 %t42, ptr %l26, !tbaa !21
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l28, !tbaa !29
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = getelementptr %"std/prelude/text:decimal", ptr %t45, i32 0, i32 2
  %t47 = load i64, ptr %t46, !tbaa !24
  store i64 %t47, ptr %l29, !tbaa !24
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = icmp eq i64 %t48, 0
  store i1 %t49, ptr %l30, !tbaa !21
  %t50 = load i1, ptr %l30, !tbaa !21
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l27, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l31, !tbaa !29
  %t53 = load ptr, ptr %l31, !tbaa !29
  %t54 = getelementptr %"std/prelude/text:decimal", ptr %t53, i32 0, i32 3
  %t55 = load i64, ptr %t54, !tbaa !24
  store i64 %t55, ptr %l32, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  %t57 = sub i64 %t56, 1
  store i64 %t57, ptr %l33, !tbaa !24
  %t58 = load i64, ptr %l33, !tbaa !24
  %t59 = load ptr, ptr %l31, !tbaa !29
  %t60 = getelementptr %"std/prelude/text:decimal", ptr %t59, i32 0, i32 3
  store i64 %t58, ptr %t60, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb16:
  store %olang.scope zeroinitializer, ptr %s7
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l34, !tbaa !29
  %t62 = load ptr, ptr %l34, !tbaa !29
  %t63 = getelementptr %"std/prelude/text:decimal", ptr %t62, i32 0, i32 2
  %t64 = load i64, ptr %t63, !tbaa !24
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = icmp slt i64 %t65, 800
  store i1 %t66, ptr %l36, !tbaa !21
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s8
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l37, !tbaa !29
  %t69 = load ptr, ptr %l37, !tbaa !29
  %t70 = getelementptr %"std/prelude/text:decimal", ptr %t69, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l38, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l39, !tbaa !29
  %t73 = load ptr, ptr %l39, !tbaa !29
  %t74 = getelementptr %"std/prelude/text:decimal", ptr %t73, i32 0, i32 2
  %t75 = load i64, ptr %t74, !tbaa !24
  store i64 %t75, ptr %l40, !tbaa !24
  %t76 = load i8, ptr %l4, !tbaa !22
  store i8 %t76, ptr %l41, !tbaa !22
  %t77 = load i8, ptr %l41, !tbaa !22
  %t78 = sub i8 %t77, 48
  store i8 %t78, ptr %l42, !tbaa !22
  %t79 = load i8, ptr %l42, !tbaa !22
  store i8 %t79, ptr %l43, !tbaa !22
  %t80 = load i8, ptr %l43, !tbaa !22
  %t81 = load i64, ptr %l40, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t81
  store i8 %t80, ptr %t84, !tbaa !32
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l44, !tbaa !29
  %t86 = load ptr, ptr %l44, !tbaa !29
  %t87 = getelementptr %"std/prelude/text:decimal", ptr %t86, i32 0, i32 2
  %t88 = load i64, ptr %t87, !tbaa !24
  store i64 %t88, ptr %l45, !tbaa !24
  %t89 = load i64, ptr %l45, !tbaa !24
  %t90 = add i64 %t89, 1
  store i64 %t90, ptr %l46, !tbaa !24
  %t91 = load i64, ptr %l46, !tbaa !24
  %t92 = load ptr, ptr %l44, !tbaa !29
  %t93 = getelementptr %"std/prelude/text:decimal", ptr %t92, i32 0, i32 2
  store i64 %t91, ptr %t93, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb22
bb18:
  store %olang.scope zeroinitializer, ptr %s9
  %t94 = load i8, ptr %l4, !tbaa !22
  store i8 %t94, ptr %l47, !tbaa !22
  %t95 = load i8, ptr %l47, !tbaa !22
  %t96 = icmp ne i8 %t95, 48
  store i1 %t96, ptr %l48, !tbaa !21
  %t97 = load i1, ptr %l48, !tbaa !21
  br i1 %t97, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s10
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l49, !tbaa !29
  %t99 = load ptr, ptr %l49, !tbaa !29
  %t100 = getelementptr %"std/prelude/text:decimal", ptr %t99, i32 0, i32 4
  store i1 true, ptr %t100, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s9)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t101 = load i64, ptr %l2, !tbaa !24
  store i64 %t101, ptr %l50, !tbaa !24
  %t102 = load i64, ptr %l50, !tbaa !24
  %t103 = add i64 %t102, 1
  store i64 %t103, ptr %l51, !tbaa !24
  %t104 = load i64, ptr %l51, !tbaa !24
  store i64 %t104, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb26:
  br label %bb1
bb27:
  %t105 = load i1, ptr %l3, !tbaa !21
  store i1 %t105, ptr %l52, !tbaa !21
  %t106 = load i1, ptr %l52, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l53, !tbaa !21
  %t108 = load i1, ptr %l53, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s11
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l54, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l55, !tbaa !29
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t112 = getelementptr %"std/prelude/text:decimal", ptr %t111, i32 0, i32 2
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l56, !tbaa !24
  %t114 = load i64, ptr %l56, !tbaa !24
  %t115 = load ptr, ptr %l54, !tbaa !29
  %t116 = getelementptr %"std/prelude/text:decimal", ptr %t115, i32 0, i32 3
  store i64 %t114, ptr %t116, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t117 = load i64, ptr %l2, !tbaa !24
  store i64 %t117, ptr %l57, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t118, ptr %l58, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l59, !tbaa !24
  %t121 = load i64, ptr %l57, !tbaa !24
  %t122 = load i64, ptr %l59, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  store i1 %t123, ptr %l60, !tbaa !21
  %t124 = load i1, ptr %l60, !tbaa !21
  br i1 %t124, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s12
  %t125 = load i64, ptr %l2, !tbaa !24
  store i64 %t125, ptr %l61, !tbaa !24
  %t126 = load i64, ptr %l61, !tbaa !24
  %t127 = add i64 %t126, 1
  store i64 %t127, ptr %l62, !tbaa !24
  %t128 = load i64, ptr %l62, !tbaa !24
  store i64 %t128, ptr %l2, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t129, ptr %l63, !tbaa !27
  %t130 = load i64, ptr %l2, !tbaa !24
  store i64 %t130, ptr %l64, !tbaa !24
  %t131 = load i64, ptr %l64, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i8, ptr %t133, i64 %t131
  %t135 = load i8, ptr %t134, !tbaa !32
  store i8 %t135, ptr %l65, !tbaa !22
  %t136 = load i8, ptr %l65, !tbaa !22
  %t137 = icmp eq i8 %t136, 43
  store i1 %t137, ptr %l66, !tbaa !21
  %t138 = load i1, ptr %l66, !tbaa !21
  br i1 %t138, label %bb33, label %bb34
bb32:
  br label %bb48
bb33:
  store %olang.scope zeroinitializer, ptr %s13
  %t139 = load i64, ptr %l2, !tbaa !24
  store i64 %t139, ptr %l67, !tbaa !24
  %t140 = load i64, ptr %l67, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l68, !tbaa !24
  %t142 = load i64, ptr %l68, !tbaa !24
  store i64 %t142, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s14
  %t143 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t143, ptr %l69, !tbaa !27
  %t144 = load i64, ptr %l2, !tbaa !24
  store i64 %t144, ptr %l70, !tbaa !24
  %t145 = load i64, ptr %l70, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i8, ptr %t147, i64 %t145
  %t149 = load i8, ptr %t148, !tbaa !32
  store i8 %t149, ptr %l71, !tbaa !22
  %t150 = load i8, ptr %l71, !tbaa !22
  %t151 = icmp eq i8 %t150, 45
  store i1 %t151, ptr %l72, !tbaa !21
  %t152 = load i1, ptr %l72, !tbaa !21
  br i1 %t152, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s15
  store i64 -1, ptr %l5, !tbaa !24
  %t153 = load i64, ptr %l2, !tbaa !24
  store i64 %t153, ptr %l73, !tbaa !24
  %t154 = load i64, ptr %l73, !tbaa !24
  %t155 = add i64 %t154, 1
  store i64 %t155, ptr %l74, !tbaa !24
  %t156 = load i64, ptr %l74, !tbaa !24
  store i64 %t156, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb37
bb36:
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s14)
  br label %bb38
bb38:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s16
  %t157 = load i64, ptr %l2, !tbaa !24
  store i64 %t157, ptr %l75, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t158, ptr %l76, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 0
  store i64 %t160, ptr %l77, !tbaa !24
  %t161 = load i64, ptr %l75, !tbaa !24
  %t162 = load i64, ptr %l77, !tbaa !24
  %t163 = icmp slt i64 %t161, %t162
  store i1 %t163, ptr %l78, !tbaa !21
  %t164 = load i1, ptr %l78, !tbaa !21
  %t165 = xor i1 %t164, true
  store i1 %t165, ptr %l79, !tbaa !21
  %t166 = load i1, ptr %l79, !tbaa !21
  br i1 %t166, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s16)
  br label %bb47
bb41:
  br label %bb42
bb42:
  %t167 = load i64, ptr %l6, !tbaa !24
  store i64 %t167, ptr %l80, !tbaa !24
  %t168 = load i64, ptr %l80, !tbaa !24
  %t169 = icmp slt i64 %t168, 10000
  store i1 %t169, ptr %l81, !tbaa !21
  %t170 = load i1, ptr %l81, !tbaa !21
  br i1 %t170, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s17
  %t171 = load i64, ptr %l6, !tbaa !24
  store i64 %t171, ptr %l82, !tbaa !24
  %t172 = load i64, ptr %l82, !tbaa !24
  %t173 = mul i64 %t172, 10
  store i64 %t173, ptr %l83, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t174, ptr %l84, !tbaa !27
  %t175 = load i64, ptr %l2, !tbaa !24
  store i64 %t175, ptr %l85, !tbaa !24
  %t176 = load i64, ptr %l85, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t176
  %t180 = load i8, ptr %t179, !tbaa !32
  store i8 %t180, ptr %l86, !tbaa !22
  %t181 = load i8, ptr %l86, !tbaa !22
  %t182 = sub i8 %t181, 48
  store i8 %t182, ptr %l87, !tbaa !22
  %t183 = load i8, ptr %l87, !tbaa !22
  %t184 = zext i8 %t183 to i64
  store i64 %t184, ptr %l88, !tbaa !24
  %t185 = load i64, ptr %l83, !tbaa !24
  %t186 = load i64, ptr %l88, !tbaa !24
  %t187 = add i64 %t185, %t186
  store i64 %t187, ptr %l89, !tbaa !24
  %t188 = load i64, ptr %l89, !tbaa !24
  store i64 %t188, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t189 = load i64, ptr %l2, !tbaa !24
  store i64 %t189, ptr %l90, !tbaa !24
  %t190 = load i64, ptr %l90, !tbaa !24
  %t191 = add i64 %t190, 1
  store i64 %t191, ptr %l91, !tbaa !24
  %t192 = load i64, ptr %l91, !tbaa !24
  store i64 %t192, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb46
bb46:
  br label %bb39
bb47:
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l92, !tbaa !29
  %t194 = load ptr, ptr %l92, !tbaa !29
  %t195 = getelementptr %"std/prelude/text:decimal", ptr %t194, i32 0, i32 3
  %t196 = load i64, ptr %t195, !tbaa !24
  store i64 %t196, ptr %l93, !tbaa !24
  %t197 = load i64, ptr %l6, !tbaa !24
  store i64 %t197, ptr %l94, !tbaa !24
  %t198 = load i64, ptr %l5, !tbaa !24
  store i64 %t198, ptr %l95, !tbaa !24
  %t199 = load i64, ptr %l94, !tbaa !24
  %t200 = load i64, ptr %l95, !tbaa !24
  %t201 = mul i64 %t199, %t200
  store i64 %t201, ptr %l96, !tbaa !24
  %t202 = load i64, ptr %l93, !tbaa !24
  %t203 = load i64, ptr %l96, !tbaa !24
  %t204 = add i64 %t202, %t203
  store i64 %t204, ptr %l97, !tbaa !24
  %t205 = load i64, ptr %l97, !tbaa !24
  %t206 = load ptr, ptr %l92, !tbaa !29
  %t207 = getelementptr %"std/prelude/text:decimal", ptr %t206, i32 0, i32 3
  store i64 %t205, ptr %t207, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eshift(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = icmp eq i64 %t5, 0
  store i1 %t6, ptr %l4, !tbaa !21
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l1, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = icmp sgt i64 %t9, 60
  store i1 %t10, ptr %l6, !tbaa !21
  %t11 = load i1, ptr %l6, !tbaa !21
  %t12 = xor i1 %t11, true
  store i1 %t12, ptr %l7, !tbaa !21
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l8, !tbaa !29
  %t15 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eleftShift(ptr %v0, ptr %t15, i64 60)
  br label %bb8
bb8:
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %l9, !tbaa !24
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = sub i64 %t17, 60
  store i64 %t18, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l10, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  br label %bb4
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l11, !tbaa !24
  %t21 = load i64, ptr %l11, !tbaa !24
  %t22 = icmp slt i64 %t21, -60
  store i1 %t22, ptr %l12, !tbaa !21
  %t23 = load i1, ptr %l12, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l13, !tbaa !21
  %t25 = load i1, ptr %l13, !tbaa !21
  br i1 %t25, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l14, !tbaa !29
  %t27 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2erightShift(ptr %v0, ptr %t27, i64 60)
  br label %bb15
bb15:
  %t28 = load i64, ptr %l1, !tbaa !24
  store i64 %t28, ptr %l15, !tbaa !24
  %t29 = load i64, ptr %l15, !tbaa !24
  %t30 = add i64 %t29, 60
  store i64 %t30, ptr %l16, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l1, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  br label %bb11
bb17:
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %l17, !tbaa !24
  %t33 = load i64, ptr %l17, !tbaa !24
  %t34 = icmp sgt i64 %t33, 0
  store i1 %t34, ptr %l18, !tbaa !21
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  store i64 %t38, ptr %l21, !tbaa !65
  %t39 = load ptr, ptr %l19, !tbaa !29
  %t40 = load i64, ptr %l21, !tbaa !65
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2eleftShift(ptr %v0, ptr %t39, i64 %t40)
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t41 = load i64, ptr %l1, !tbaa !24
  store i64 %t41, ptr %l22, !tbaa !24
  %t42 = load i64, ptr %l22, !tbaa !24
  %t43 = icmp slt i64 %t42, 0
  store i1 %t43, ptr %l23, !tbaa !21
  %t44 = load i1, ptr %l23, !tbaa !21
  br i1 %t44, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l24, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  store i64 %t46, ptr %l25, !tbaa !24
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = sub i64 0, %t47
  store i64 %t48, ptr %l26, !tbaa !24
  %t49 = load i64, ptr %l26, !tbaa !24
  store i64 %t49, ptr %l27, !tbaa !65
  %t50 = load ptr, ptr %l24, !tbaa !29
  %t51 = load i64, ptr %l27, !tbaa !65
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2erightShift(ptr %v0, ptr %t50, i64 %t51)
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3adecimal_2etrim(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"std/prelude/text:decimal", ptr %t2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = icmp sgt i64 %t5, 0
  store i1 %t6, ptr %l3, !tbaa !21
  %t7 = load i1, ptr %l3, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"std/prelude/text:decimal", ptr %t9, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l7, !tbaa !29
  %t13 = load ptr, ptr %l7, !tbaa !29
  %t14 = getelementptr %"std/prelude/text:decimal", ptr %t13, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l8, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t17 = sub i64 %t16, 1
  store i64 %t17, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i8, ptr %t20, i64 %t18
  %t22 = load i8, ptr %t21, !tbaa !32
  store i8 %t22, ptr %l10, !tbaa !22
  %t23 = load i8, ptr %l10, !tbaa !22
  %t24 = icmp eq i8 %t23, 0
  store i1 %t24, ptr %l11, !tbaa !21
  %t25 = load i1, ptr %l11, !tbaa !21
  store i1 %t25, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t26 = load i1, ptr %l4, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l12, !tbaa !21
  %t28 = load i1, ptr %l12, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  %t30 = load ptr, ptr %l13, !tbaa !29
  %t31 = getelementptr %"std/prelude/text:decimal", ptr %t30, i32 0, i32 2
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l14, !tbaa !24
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = sub i64 %t33, 1
  store i64 %t34, ptr %l15, !tbaa !24
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = load ptr, ptr %l13, !tbaa !29
  %t37 = getelementptr %"std/prelude/text:decimal", ptr %t36, i32 0, i32 2
  store i64 %t35, ptr %t37, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l16, !tbaa !29
  %t39 = load ptr, ptr %l16, !tbaa !29
  %t40 = getelementptr %"std/prelude/text:decimal", ptr %t39, i32 0, i32 2
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l17, !tbaa !24
  %t42 = load i64, ptr %l17, !tbaa !24
  %t43 = icmp eq i64 %t42, 0
  store i1 %t43, ptr %l18, !tbaa !21
  %t44 = load i1, ptr %l18, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l19, !tbaa !29
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = getelementptr %"std/prelude/text:decimal", ptr %t46, i32 0, i32 3
  store i64 0, ptr %t47, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, double } @std_2fprelude_2ftext_2etoF64(ptr %v0, i64 %a0, i64 %a1, i1 %a2, i1 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca double
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca double
  %l13 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca double
  %l21 = alloca i1
  %l22 = alloca double
  %l23 = alloca double
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca double
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca double
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca double
  %l39 = alloca double
  %l40 = alloca double
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca double
  %l44 = alloca i1
  %l45 = alloca double
  %l46 = alloca i64
  %l47 = alloca double
  %l48 = alloca double
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i1
  %l54 = alloca double
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca double
  %l58 = alloca double
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca double
  %l65 = alloca { i64, ptr }
  %l66 = alloca i1
  %l67 = alloca double
  %l68 = alloca i32
  %l69 = alloca i32
  %l70 = alloca i1
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca double
  %l78 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca double
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i1
  %l86 = alloca double
  %l87 = alloca { i64, ptr }
  %l88 = alloca i1
  %l89 = alloca double
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca double
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i32, double }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !65
  store i64 %t1, ptr %l9, !tbaa !65
  %t2 = load i64, ptr %l9, !tbaa !65
  %t3 = icmp eq i64 %t2, 0
  store i1 %t3, ptr %l10, !tbaa !21
  %t4 = load i1, ptr %l10, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i1, ptr %l3, !tbaa !21
  store i1 %t5, ptr %l11, !tbaa !21
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  store double 0x8000000000000000, ptr %l12, !tbaa !26
  br label %bb5
bb4:
  store double 0x0000000000000000, ptr %l12, !tbaa !26
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load double, ptr %l12, !tbaa !26
  %t8 = insertvalue { i32, double } zeroinitializer, double %t7, 1
  store { i32, double } %t8, ptr %rv
  br label %ret
bb6:
  %t9 = load i1, ptr %l2, !tbaa !21
  store i1 %t9, ptr %l13, !tbaa !21
  %t10 = load i1, ptr %l13, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l14, !tbaa !21
  %t12 = load i1, ptr %l14, !tbaa !21
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t13 = load i64, ptr %l0, !tbaa !65
  store i64 %t13, ptr %l16, !tbaa !65
  %t14 = load i64, ptr %l16, !tbaa !65
  %t15 = lshr i64 %t14, 52
  store i64 %t15, ptr %l17, !tbaa !65
  %t16 = load i64, ptr %l17, !tbaa !65
  %t17 = icmp eq i64 %t16, 0
  store i1 %t17, ptr %l18, !tbaa !21
  %t18 = load i1, ptr %l18, !tbaa !21
  store i1 %t18, ptr %l15, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load i64, ptr %l0, !tbaa !65
  store i64 %t20, ptr %l19, !tbaa !65
  %t21 = load i64, ptr %l19, !tbaa !65
  %t22 = uitofp i64 %t21 to double
  store double %t22, ptr %l20, !tbaa !26
  %t23 = load double, ptr %l20, !tbaa !26
  store double %t23, ptr %l5, !tbaa !26
  %t24 = load i1, ptr %l3, !tbaa !21
  store i1 %t24, ptr %l21, !tbaa !21
  %t25 = load i1, ptr %l21, !tbaa !21
  br i1 %t25, label %bb12, label %bb13
bb11:
  br label %bb39
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t26 = load double, ptr %l5, !tbaa !26
  store double %t26, ptr %l22, !tbaa !26
  %t27 = load double, ptr %l22, !tbaa !26
  %t28 = fneg double %t27
  store double %t28, ptr %l23, !tbaa !26
  %t29 = load double, ptr %l23, !tbaa !26
  store double %t29, ptr %l5, !tbaa !26
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t30 = load i64, ptr %l1, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load i64, ptr %l24, !tbaa !24
  %t32 = icmp eq i64 %t31, 0
  store i1 %t32, ptr %l25, !tbaa !21
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t34 = load double, ptr %l5, !tbaa !26
  store double %t34, ptr %l26, !tbaa !26
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t35 = load double, ptr %l26, !tbaa !26
  %t36 = insertvalue { i32, double } zeroinitializer, double %t35, 1
  store { i32, double } %t36, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l27, !tbaa !24
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp sgt i64 %t38, 0
  store i1 %t39, ptr %l28, !tbaa !21
  %t40 = load i1, ptr %l28, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load i64, ptr %l1, !tbaa !24
  store i64 %t41, ptr %l30, !tbaa !24
  %t42 = load i64, ptr %l30, !tbaa !24
  %t43 = icmp sle i64 %t42, 37
  store i1 %t43, ptr %l31, !tbaa !21
  %t44 = load i1, ptr %l31, !tbaa !21
  store i1 %t44, ptr %l29, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb20
bb20:
  %t45 = load i1, ptr %l29, !tbaa !21
  br i1 %t45, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t46 = load i64, ptr %l1, !tbaa !24
  store i64 %t46, ptr %l32, !tbaa !24
  %t47 = load i64, ptr %l32, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  store i64 %t48, ptr %l33, !tbaa !24
  %t49 = load i64, ptr %l33, !tbaa !24
  %t50 = icmp sgt i64 %t49, 22
  store i1 %t50, ptr %l34, !tbaa !21
  %t51 = load i1, ptr %l34, !tbaa !21
  br i1 %t51, label %bb23, label %bb24
bb22:
  store %olang.scope zeroinitializer, ptr %s8
  %t52 = load i64, ptr %l1, !tbaa !24
  store i64 %t52, ptr %l49, !tbaa !24
  %t53 = load i64, ptr %l49, !tbaa !24
  %t54 = icmp slt i64 %t53, 0
  store i1 %t54, ptr %l50, !tbaa !21
  %t55 = load i1, ptr %l50, !tbaa !21
  br i1 %t55, label %bb32, label %bb33
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t56 = load double, ptr %l5, !tbaa !26
  store double %t56, ptr %l35, !tbaa !26
  %t57 = load i64, ptr %l6, !tbaa !24
  store i64 %t57, ptr %l36, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = sub i64 %t58, 22
  store i64 %t59, ptr %l37, !tbaa !24
  %t60 = load i64, ptr %l37, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2eexactPow10, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr double, ptr %t62, i64 %t60
  %t64 = load double, ptr %t63, !tbaa !36
  store double %t64, ptr %l38, !tbaa !26
  %t65 = load double, ptr %l35, !tbaa !26
  %t66 = load double, ptr %l38, !tbaa !26
  %t67 = fmul double %t65, %t66
  store double %t67, ptr %l39, !tbaa !26
  %t68 = load double, ptr %l39, !tbaa !26
  store double %t68, ptr %l5, !tbaa !26
  store i64 22, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t69 = load double, ptr %l5, !tbaa !26
  store double %t69, ptr %l40, !tbaa !26
  %t70 = load double, ptr %l40, !tbaa !26
  %t71 = fcmp ole double %t70, 0x430c6bf526340000
  store i1 %t71, ptr %l41, !tbaa !21
  %t72 = load i1, ptr %l41, !tbaa !21
  br i1 %t72, label %bb26, label %bb27
bb26:
  %t73 = load double, ptr %l5, !tbaa !26
  store double %t73, ptr %l43, !tbaa !26
  %t74 = load double, ptr %l43, !tbaa !26
  %t75 = fcmp oge double %t74, 0xc30c6bf526340000
  store i1 %t75, ptr %l44, !tbaa !21
  %t76 = load i1, ptr %l44, !tbaa !21
  store i1 %t76, ptr %l42, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb28
bb28:
  %t77 = load i1, ptr %l42, !tbaa !21
  br i1 %t77, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t78 = load double, ptr %l5, !tbaa !26
  store double %t78, ptr %l45, !tbaa !26
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l46, !tbaa !24
  %t80 = load i64, ptr %l46, !tbaa !24
  %t81 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2eexactPow10, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = getelementptr double, ptr %t82, i64 %t80
  %t84 = load double, ptr %t83, !tbaa !36
  store double %t84, ptr %l47, !tbaa !26
  %t85 = load double, ptr %l45, !tbaa !26
  %t86 = load double, ptr %l47, !tbaa !26
  %t87 = fmul double %t85, %t86
  store double %t87, ptr %l48, !tbaa !26
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t88 = load double, ptr %l48, !tbaa !26
  %t89 = insertvalue { i32, double } zeroinitializer, double %t88, 1
  store { i32, double } %t89, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb32:
  %t90 = load i64, ptr %l1, !tbaa !24
  store i64 %t90, ptr %l52, !tbaa !24
  %t91 = load i64, ptr %l52, !tbaa !24
  %t92 = icmp sge i64 %t91, -22
  store i1 %t92, ptr %l53, !tbaa !21
  %t93 = load i1, ptr %l53, !tbaa !21
  store i1 %t93, ptr %l51, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb34
bb34:
  %t94 = load i1, ptr %l51, !tbaa !21
  br i1 %t94, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  %t95 = load double, ptr %l5, !tbaa !26
  store double %t95, ptr %l54, !tbaa !26
  %t96 = load i64, ptr %l1, !tbaa !24
  store i64 %t96, ptr %l55, !tbaa !24
  %t97 = load i64, ptr %l55, !tbaa !24
  %t98 = sub i64 0, %t97
  store i64 %t98, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l56, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr @G_2estd_2fprelude_2ftext_2eexactPow10, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr double, ptr %t101, i64 %t99
  %t103 = load double, ptr %t102, !tbaa !36
  store double %t103, ptr %l57, !tbaa !26
  %t104 = load double, ptr %l54, !tbaa !26
  %t105 = load double, ptr %l57, !tbaa !26
  %t106 = fdiv double %t104, %t105
  store double %t106, ptr %l58, !tbaa !26
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t107 = load double, ptr %l58, !tbaa !26
  %t108 = insertvalue { i32, double } zeroinitializer, double %t107, 1
  store { i32, double } %t108, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s8)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb39:
  %t109 = load i64, ptr %l0, !tbaa !65
  store i64 %t109, ptr %l60, !tbaa !65
  %t110 = load i64, ptr %l1, !tbaa !24
  store i64 %t110, ptr %l61, !tbaa !24
  %t111 = load i64, ptr %l60, !tbaa !65
  %t112 = load i64, ptr %l61, !tbaa !24
  %t113 = call { i32, i64 } @std_2fprelude_2ftext_2eeiselLemire(i64 %t111, i64 %t112)
  %t114 = extractvalue { i32, i64 } %t113, 1
  %t115 = extractvalue { i32, i64 } %t113, 0
  store i32 %t115, ptr %l63
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb41, label %ok.117
ok.117:
  store i64 %t114, ptr %l62
  br label %bb40
bb40:
  %t118 = load i64, ptr %l62, !tbaa !65
  store i64 %t118, ptr %l59, !tbaa !65
  br label %bb46
bb41:
  br label %bb42
bb42:
  store %olang.scope zeroinitializer, ptr %s10
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t119, ptr %l65, !tbaa !27
  %t120 = load i1, ptr %l3, !tbaa !21
  store i1 %t120, ptr %l66, !tbaa !21
  %t121 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t122 = load i1, ptr %l66, !tbaa !21
  %t123 = call { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %t121, i1 %t122)
  %t124 = extractvalue { i32, double } %t123, 1
  %t125 = extractvalue { i32, double } %t123, 0
  store i32 %t125, ptr %l68
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb44, label %ok.127
ok.127:
  store double %t124, ptr %l67
  br label %bb43
bb43:
  %t128 = load double, ptr %l67, !tbaa !26
  store double %t128, ptr %l64, !tbaa !26
  br label %bb45
bb44:
  %t129 = load i32, ptr %l68, !tbaa !23
  %t130 = lshr i32 %t129, 16
  %t131 = and i32 %t129, 65535
  %t132 = icmp eq i32 %t130, 1
  %t133 = select i1 %t132, i32 1, i32 0
  %t134 = icmp eq i32 %t129, 0
  %t135 = shl i32 %t133, 16
  %t136 = or i32 %t135, %t131
  %t137 = select i1 %t134, i32 0, i32 %t136
  store i32 %t137, ptr %l69, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t138 = load i32, ptr %l69, !tbaa !23
  %t139 = insertvalue { i32, double } zeroinitializer, i32 %t138, 0
  store { i32, double } %t139, ptr %rv
  br label %ret
bb45:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t140 = load double, ptr %l64, !tbaa !26
  %t141 = insertvalue { i32, double } zeroinitializer, double %t140, 1
  store { i32, double } %t141, ptr %rv
  br label %ret
bb46:
  %t142 = load i64, ptr %l59, !tbaa !65
  store i64 %t142, ptr %l7, !tbaa !65
  %t143 = load i1, ptr %l2, !tbaa !21
  store i1 %t143, ptr %l70, !tbaa !21
  %t144 = load i1, ptr %l70, !tbaa !21
  br i1 %t144, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t145 = load i64, ptr %l0, !tbaa !65
  store i64 %t145, ptr %l72, !tbaa !65
  %t146 = load i64, ptr %l72, !tbaa !65
  %t147 = add i64 %t146, 1
  store i64 %t147, ptr %l73, !tbaa !65
  %t148 = load i64, ptr %l1, !tbaa !24
  store i64 %t148, ptr %l74, !tbaa !24
  %t149 = load i64, ptr %l73, !tbaa !65
  %t150 = load i64, ptr %l74, !tbaa !24
  %t151 = call { i32, i64 } @std_2fprelude_2ftext_2eeiselLemire(i64 %t149, i64 %t150)
  %t152 = extractvalue { i32, i64 } %t151, 1
  %t153 = extractvalue { i32, i64 } %t151, 0
  store i32 %t153, ptr %l76
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb50, label %ok.155
ok.155:
  store i64 %t152, ptr %l75
  br label %bb49
bb48:
  br label %bb62
bb49:
  %t156 = load i64, ptr %l75, !tbaa !65
  store i64 %t156, ptr %l71, !tbaa !65
  br label %bb55
bb50:
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s12
  %t157 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t157, ptr %l78, !tbaa !27
  %t158 = load i1, ptr %l3, !tbaa !21
  store i1 %t158, ptr %l79, !tbaa !21
  %t159 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t160 = load i1, ptr %l79, !tbaa !21
  %t161 = call { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %t159, i1 %t160)
  %t162 = extractvalue { i32, double } %t161, 1
  %t163 = extractvalue { i32, double } %t161, 0
  store i32 %t163, ptr %l81
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb53, label %ok.165
ok.165:
  store double %t162, ptr %l80
  br label %bb52
bb52:
  %t166 = load double, ptr %l80, !tbaa !26
  store double %t166, ptr %l77, !tbaa !26
  br label %bb54
bb53:
  %t167 = load i32, ptr %l81, !tbaa !23
  %t168 = lshr i32 %t167, 16
  %t169 = and i32 %t167, 65535
  %t170 = icmp eq i32 %t168, 1
  %t171 = select i1 %t170, i32 1, i32 0
  %t172 = icmp eq i32 %t167, 0
  %t173 = shl i32 %t171, 16
  %t174 = or i32 %t173, %t169
  %t175 = select i1 %t172, i32 0, i32 %t174
  store i32 %t175, ptr %l82, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i32, ptr %l82, !tbaa !23
  %t177 = insertvalue { i32, double } zeroinitializer, i32 %t176, 0
  store { i32, double } %t177, ptr %rv
  br label %ret
bb54:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t178 = load double, ptr %l77, !tbaa !26
  %t179 = insertvalue { i32, double } zeroinitializer, double %t178, 1
  store { i32, double } %t179, ptr %rv
  br label %ret
bb55:
  %t180 = load i64, ptr %l71, !tbaa !65
  store i64 %t180, ptr %l8, !tbaa !65
  %t181 = load i64, ptr %l8, !tbaa !65
  store i64 %t181, ptr %l83, !tbaa !65
  %t182 = load i64, ptr %l7, !tbaa !65
  store i64 %t182, ptr %l84, !tbaa !65
  %t183 = load i64, ptr %l83, !tbaa !65
  %t184 = load i64, ptr %l84, !tbaa !65
  %t185 = icmp ne i64 %t183, %t184
  store i1 %t185, ptr %l85, !tbaa !21
  %t186 = load i1, ptr %l85, !tbaa !21
  br i1 %t186, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t187 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t187, ptr %l87, !tbaa !27
  %t188 = load i1, ptr %l3, !tbaa !21
  store i1 %t188, ptr %l88, !tbaa !21
  %t189 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t190 = load i1, ptr %l88, !tbaa !21
  %t191 = call { i32, double } @std_2fprelude_2ftext_2eslowF64(ptr %v0, { i64, ptr } %t189, i1 %t190)
  %t192 = extractvalue { i32, double } %t191, 1
  %t193 = extractvalue { i32, double } %t191, 0
  store i32 %t193, ptr %l90
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb59, label %ok.195
ok.195:
  store double %t192, ptr %l89
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t196 = load double, ptr %l89, !tbaa !26
  store double %t196, ptr %l86, !tbaa !26
  br label %bb60
bb59:
  %t197 = load i32, ptr %l90, !tbaa !23
  %t198 = lshr i32 %t197, 16
  %t199 = and i32 %t197, 65535
  %t200 = icmp eq i32 %t198, 1
  %t201 = select i1 %t200, i32 1, i32 0
  %t202 = icmp eq i32 %t197, 0
  %t203 = shl i32 %t201, 16
  %t204 = or i32 %t203, %t199
  %t205 = select i1 %t202, i32 0, i32 %t204
  store i32 %t205, ptr %l91, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t206 = load i32, ptr %l91, !tbaa !23
  %t207 = insertvalue { i32, double } zeroinitializer, i32 %t206, 0
  store { i32, double } %t207, ptr %rv
  br label %ret
bb60:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t208 = load double, ptr %l86, !tbaa !26
  %t209 = insertvalue { i32, double } zeroinitializer, double %t208, 1
  store { i32, double } %t209, ptr %rv
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  %t210 = load i1, ptr %l3, !tbaa !21
  store i1 %t210, ptr %l92, !tbaa !21
  %t211 = load i1, ptr %l92, !tbaa !21
  br i1 %t211, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t212 = load i64, ptr %l7, !tbaa !65
  store i64 %t212, ptr %l93, !tbaa !65
  %t213 = shl i64 1, 63
  store i64 %t213, ptr %l94, !tbaa !65
  %t214 = load i64, ptr %l93, !tbaa !65
  %t215 = load i64, ptr %l94, !tbaa !65
  %t216 = or i64 %t214, %t215
  store i64 %t216, ptr %l95, !tbaa !65
  %t217 = load i64, ptr %l95, !tbaa !65
  store i64 %t217, ptr %l7, !tbaa !65
  call void @__olang_scope_close(ptr %s14)
  br label %bb65
bb64:
  br label %bb65
bb65:
  %t218 = load i64, ptr %l7, !tbaa !65
  store i64 %t218, ptr %l96, !tbaa !65
  %t219 = load i64, ptr %l96, !tbaa !65
  %t220 = bitcast i64 %t219 to double
  store double %t220, ptr %l97, !tbaa !26
  call void @__olang_scope_close(ptr %s0)
  %t221 = load double, ptr %l97, !tbaa !26
  %t222 = insertvalue { i32, double } zeroinitializer, double %t221, 1
  store { i32, double } %t222, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local %"std/prelude/text:LineIter" @std_2fprelude_2ftext_3aLineIter_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/text:LineIter"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/text:LineIter"
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = insertvalue %"std/prelude/text:LineIter" undef, { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = insertvalue %"std/prelude/text:LineIter" %t4, i64 %t5, 1
  store %"std/prelude/text:LineIter" %t6, ptr %l4
  call void @__olang_scope_close(ptr %s0)
  %t7 = load %"std/prelude/text:LineIter", ptr %l4
  store %"std/prelude/text:LineIter" %t7, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:LineIter", ptr %rv
  ret %"std/prelude/text:LineIter" %rr
}

define dso_local %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:Char>"
  %l1 = alloca %"std/prelude/list:List<std/prelude/text:Char>"
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List<std/prelude/text:Char>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<std/prelude/text:Char>" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List<std/prelude/text:Char>", ptr %l1
  store %"std/prelude/list:List<std/prelude/text:Char>" %t2, ptr %l0
  %t3 = load %"std/prelude/list:List<std/prelude/text:Char>", ptr %l0
  %t4 = insertvalue %"std/prelude/text:StringBuilder" undef, %"std/prelude/list:List<std/prelude/text:Char>" %t3, 0
  store %"std/prelude/text:StringBuilder" %t4, ptr %l2
  call void @__olang_scope_close(ptr %s0)
  %t5 = load %"std/prelude/text:StringBuilder", ptr %l2
  store %"std/prelude/text:StringBuilder" %t5, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

define dso_local %"std/prelude/text:decimal" @std_2fprelude_2ftext_3adecimal_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:decimal"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/text:decimal"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = icmp sge i64 800, 0
  store i1 %t1, ptr %l5, !tbaa !21
  %t2 = load i1, ptr %l5, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t3 = mul i64 800, 1
  %t4 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t3)
  %t5 = insertvalue { i64, ptr } undef, i64 800, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t4, 1
  store { i64, ptr } %t6, ptr %l6, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = mul i64 %t8, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t9, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t14, ptr %l0, !tbaa !27
  %t15 = icmp sge i64 820, 0
  store i1 %t15, ptr %l8, !tbaa !21
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c29)
  unreachable
bb3:
  %t17 = mul i64 820, 1
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 820, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l10, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t28, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  store i1 false, ptr %l4, !tbaa !21
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = insertvalue %"std/prelude/text:decimal" undef, { i64, ptr } %t29, 0
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = insertvalue %"std/prelude/text:decimal" %t30, { i64, ptr } %t31, 1
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = insertvalue %"std/prelude/text:decimal" %t32, i64 %t33, 2
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = insertvalue %"std/prelude/text:decimal" %t34, i64 %t35, 3
  %t37 = load i1, ptr %l4, !tbaa !21
  %t38 = insertvalue %"std/prelude/text:decimal" %t36, i1 %t37, 4
  store %"std/prelude/text:decimal" %t38, ptr %l11
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"std/prelude/text:decimal", ptr %l11
  store %"std/prelude/text:decimal" %t39, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @.c30)
  unreachable
ret:
  %rr = load %"std/prelude/text:decimal", ptr %rv
  ret %"std/prelude/text:decimal" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_sb_done(ptr)
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d0 = private constant [36 x i8] c"0123456789abcdefghijklmnopqrstuvwxyz"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_check_failed(ptr)
@.c1 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:398: array length out of range\0A\00"
@.c2 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:349: slice bounds out of range\0A\00"
@.d3 = private constant [1 x i8] c"-"
declare void @__olang_sb_put(ptr, ptr, i64)
@.c4 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:276: slice bounds out of range\0A\00"
@.c5 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:100: slice bounds out of range\0A\00"
@.c6 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:319: array length out of range\0A\00"
@.c7 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:309: array length out of range\0A\00"
@.c8 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:505: slice bounds out of range\0A\00"
@.d9 = private constant [3 x i8] c"inf"
@.d10 = private constant [8 x i8] c"infinity"
@.d11 = private constant [3 x i8] c"nan"
@.c12 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:416: slice bounds out of range\0A\00"
@.c13 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:432: slice bounds out of range\0A\00"
@.c14 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:144: array length out of range\0A\00"
@.c15 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:146: slice bounds out of range\0A\00"
@.c16 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:156: array length out of range\0A\00"
@.c17 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:161: slice bounds out of range\0A\00"
@.c18 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:166: slice bounds out of range\0A\00"
@.c19 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:176: array length out of range\0A\00"
@.c20 = private unnamed_addr constant [54 x i8] c"std/prelude/text.olang:179: reached unreachable code\0A\00"
@.c21 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:180: slice bounds out of range\0A\00"
@.c22 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:183: slice bounds out of range\0A\00"
@.c23 = private unnamed_addr constant [54 x i8] c"std/prelude/text.olang:93: slice bounds out of range\0A\00"
@.c24 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:233: array length out of range\0A\00"
@.c25 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:226: array length out of range\0A\00"
@.c26 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:202: slice bounds out of range\0A\00"
@.c27 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:220: slice bounds out of range\0A\00"
@.c28 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:211: slice bounds out of range\0A\00"
@.c29 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:702: array length out of range\0A\00"
@.c30 = private unnamed_addr constant [55 x i8] c"std/prelude/text.olang:703: array length out of range\0A\00"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eLe_H123f33f8ddaac384b8a67c2466e49838(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H19b8985d31946b3485fef8ba31e677f6(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ePu_H849b787d6464fd61c7b36d59bd222081(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2eTo_Hb8acb615cfdcbcf79972fa4c281da350(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/list:List<std/prelude/text:Char>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aChar_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
