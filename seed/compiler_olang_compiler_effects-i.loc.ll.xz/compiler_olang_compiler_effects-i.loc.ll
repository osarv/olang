; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1bd0ad365a8e38e_b00e754070167a92 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:53: slice bounds out of range\0A\00"
@olang_loc_2123fc61f91462e5_f6442a7b1bb3d319 = weak_odr constant [54 x i8] c"std/prelude/map.olang:105: array length out of range\0A\00"
@olang_loc_7c5a221fc21546b6_8cd0583a02f1cc52 = weak_odr constant [53 x i8] c"std/prelude/map.olang:85: slice bounds out of range\0A\00"
@olang_loc_7c6b183b1a98ab13_d6bf4b540853c4f = weak_odr constant [53 x i8] c"std/prelude/map.olang:88: slice bounds out of range\0A\00"
@olang_loc_866d9bbb4f0cfa78_ce909751b54c5fac = weak_odr constant [53 x i8] c"std/prelude/vec.olang:53: slice bounds out of range\0A\00"
@olang_loc_88036afb979306f2_57b94754ef962996 = weak_odr constant [53 x i8] c"std/prelude/map.olang:94: array length out of range\0A\00"
