; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3f899fc571d42529_c24733a4ca5f80ed = weak_odr constant [55 x i8] c"std/prelude/list.olang:534: array length out of range\0A\00"
@olang_loc_4dc06d9077551cdf_2c6bce65fb6a75ab = weak_odr constant [55 x i8] c"std/prelude/list.olang:114: array length out of range\0A\00"
@olang_loc_633bdd7e62b7da5c_1326dd696b8e1bc0 = weak_odr constant [55 x i8] c"std/prelude/list.olang:533: array length out of range\0A\00"
@olang_loc_6945ad779c7e7f7c_aa454bb08a1e6148 = weak_odr constant [55 x i8] c"std/prelude/list.olang:103: array length out of range\0A\00"
@olang_loc_6b4064a4db3c0e1a_ae9fabcb554ef13e = weak_odr constant [54 x i8] c"std/prelude/list.olang:49: array length out of range\0A\00"
@olang_loc_705f0c942e068bc9_811d7cacde790eb5 = weak_odr constant [55 x i8] c"std/prelude/list.olang:108: array length out of range\0A\00"
@olang_loc_8bf73551b96bdeef_865952527ff4c073 = weak_odr constant [54 x i8] c"std/prelude/list.olang:51: array length out of range\0A\00"
@olang_loc_bf019c573f3a88c_d9422507a3cea850 = weak_odr constant [54 x i8] c"std/prelude/list.olang:54: array length out of range\0A\00"
@olang_loc_eae9d5df37060f0a_8a452e5dcec4c596 = weak_odr constant [55 x i8] c"std/prelude/list.olang:110: array length out of range\0A\00"
