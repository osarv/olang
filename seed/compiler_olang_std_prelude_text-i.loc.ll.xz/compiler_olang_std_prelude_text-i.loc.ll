; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_20dc38f747c9f0af_bc7597226811d3db = weak_odr constant [54 x i8] c"std/prelude/vec.olang:238: array length out of range\0A\00"
@olang_loc_38cffb837dbf0f3f_de6161724c950b63 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_572d6a725e3d8da_ac8d4b5fe6d55046 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:237: array length out of range\0A\00"
@olang_loc_c82c60337346054c_9d0e745fb9f2a370 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:36: array length out of range\0A\00"
