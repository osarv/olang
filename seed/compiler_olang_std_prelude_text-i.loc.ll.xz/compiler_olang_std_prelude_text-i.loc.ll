; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_20dc38f747c9f0af_bc7597226811d3db = weak_odr constant [54 x i8] c"std/prelude/vec.olang:252: array length out of range\0A\00"
@olang_loc_572d6a725e3d8da_ac8d4b5fe6d55046 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:251: array length out of range\0A\00"
@olang_loc_6124bee271ea27df_40001a175be242b = weak_odr constant [55 x i8] c"std/prelude/text.olang:320: array length out of range\0A\00"
@olang_loc_98322877b323543a_c315b51d8b07b39e = weak_odr constant [53 x i8] c"std/prelude/vec.olang:53: slice bounds out of range\0A\00"
@olang_loc_b4b3d3a21dffee1a_94412941cff469ee = weak_odr constant [55 x i8] c"std/prelude/text.olang:320: array length out of range\0A\00"
