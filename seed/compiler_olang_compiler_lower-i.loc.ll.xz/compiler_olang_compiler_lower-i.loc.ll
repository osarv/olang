; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_3e36132a3052637a_18572711d0b9c0e6 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:238: array length out of range\0A\00"
@olang_loc_445704ad4e625289_659f29daaa5cb46d = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_54f6e289da4d1929_d301f3d774aac6ed = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_5ad199e3f58ced57_5212be7b307f348b = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_64c57e6f11dc5da7_aea7c02f240fa33b = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_bdfa7a258d24c5b6_82d0626f7d148f5a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_ca5757a0a1611cb6_cb63e742dbeb9b6a = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_cfd59561ea775d8d_fb7a12cd355158c1 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_e3b1df08dc6ab325_9af88a564d3137f9 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
@olang_loc_e830083477ac3acf_e07c8e26dbb2717b = weak_odr constant [54 x i8] c"std/prelude/vec.olang:237: array length out of range\0A\00"
