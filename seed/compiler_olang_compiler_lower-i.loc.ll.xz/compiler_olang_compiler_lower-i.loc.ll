; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_1cfb720cfe577eb1_761799f1a8d8ff8d = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_3e36132a3052637a_18572711d0b9c0e6 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:240: array length out of range\0A\00"
@olang_loc_54566c9688ae7656_a589f03dbff3a4c2 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_60b34a119ceacd56_8aa8a588639da0f2 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_65a130a0ed701d91_8b4cff4de8aed0d = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_7ee7f01d358362a5_8b6e8315d74ff9e1 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_cfd59561ea775d8d_fb7a12cd355158c1 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_e43d1c07af8515c7_1f2a4af2b67982d3 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_e73aec5a7184dc17_8da576f071597283 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_e830083477ac3acf_e07c8e26dbb2717b = weak_odr constant [54 x i8] c"std/prelude/vec.olang:239: array length out of range\0A\00"
