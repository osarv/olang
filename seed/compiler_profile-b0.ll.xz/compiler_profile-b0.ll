; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/profile:Sample" = type { i64, i64, i64 }
%"compiler/profile:node" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/profile:Frame" = type { i64, i64, i64 }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/profile:mapping" = type { i64, i64, i64, { i64, ptr } }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/profile:Tally" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/profile:elfFn" = type { i64, i64, { i64, ptr } }
define dso_local { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/profile:Sample"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca %"compiler/profile:node"
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca %"compiler/profile:node"
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca %"std/prelude/text:StringBuilder"
  %l52 = alloca double
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca ptr
  %l55 = alloca %"compiler/profile:node"
  %l58 = alloca i64
  %l60 = alloca i64
  %l65 = alloca %"compiler/profile:Sample"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l80 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca %"compiler/profile:Frame"
  %l94 = alloca %"compiler/profile:node"
  %l96 = alloca %"compiler/profile:node"
  %l98 = alloca i64
  %l100 = alloca i64
  %l105 = alloca i64
  %l108 = alloca %"compiler/profile:node"
  %l119 = alloca i64
  %l120 = alloca ptr
  %l121 = alloca i64
  %l124 = alloca %"compiler/profile:node"
  %l127 = alloca %"compiler/profile:node"
  %l130 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l152 = alloca i64
  %l154 = alloca i64
  %l159 = alloca %"compiler/profile:node"
  %l168 = alloca %"compiler/profile:node"
  %l175 = alloca %"std/prelude/text:StringBuilder"
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l178 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l180 = alloca i64
  %l182 = alloca i64
  %l187 = alloca %"compiler/profile:node"
  %l188 = alloca %"compiler/profile:node"
  %l189 = alloca i64
  %l191 = alloca { i64, ptr }
  %l192 = alloca i64
  %l193 = alloca { i64, ptr }
  %l201 = alloca i64
  %l203 = alloca i64
  %l208 = alloca i64
  %l211 = alloca %"compiler/profile:node"
  %l213 = alloca %"compiler/profile:node"
  %l215 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l216 = alloca i64
  %l218 = alloca { i64, ptr }
  %l219 = alloca i64
  %l220 = alloca { i64, ptr }
  %l224 = alloca ptr
  %l225 = alloca ptr
  %l227 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l228 = alloca i64
  %l230 = alloca i64
  %l231 = alloca { i64, ptr }
  %l232 = alloca i64
  %l235 = alloca %"compiler/profile:node"
  %l236 = alloca i64
  %l238 = alloca { i64, ptr }
  %l239 = alloca i64
  %l240 = alloca { i64, ptr }
  %l250 = alloca i64
  %l252 = alloca i64
  %l254 = alloca i64
  %l259 = alloca i64
  %l263 = alloca i64
  %l266 = alloca %"compiler/profile:node"
  %l278 = alloca i64
  %l280 = alloca i64
  %l285 = alloca i64
  %l288 = alloca ptr
  %l291 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l297 = alloca { i64, ptr }
  %l302 = alloca { i64, ptr }
  %l306 = alloca { i64, ptr }
  %l309 = alloca i64
  %l329 = alloca ptr
  %l332 = alloca i64
  %l334 = alloca i64
  %l336 = alloca i64
  %l338 = alloca { i64, ptr }
  %l339 = alloca i64
  %l341 = alloca i64
  %l342 = alloca i64
  %l343 = alloca i64
  %l344 = alloca i64
  %l347 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l355 = alloca %"std/prelude/text:StringBuilder"
  %l356 = alloca ptr
  %l358 = alloca { i64, ptr }
  %l363 = alloca i64
  %l370 = alloca ptr
  %l372 = alloca { i64, ptr }
  %l375 = alloca i64
  %l377 = alloca { i64, ptr }
  %l380 = alloca ptr
  %l381 = alloca i64
  %l382 = alloca i64
  %l383 = alloca i64
  %l385 = alloca { i64, ptr }
  %l392 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t480 = alloca { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l53
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  store ptr %l3, ptr %l54, !tbaa !29
  %t3 = call %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %s0, i64 -1, i64 0)
  store %"compiler/profile:node" %t3, ptr %l55
  br label %bb2
bb2:
  %t4 = load ptr, ptr %l54, !tbaa !29
  %t5 = load %"compiler/profile:node", ptr %l55
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t4, %"compiler/profile:node" %t5)
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/profile:Profile", ptr %t6, i32 0, i32 3
  store ptr %t8, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l58, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l60
  br label %bb5
bb5:
  %t14 = load i64, ptr %l58, !tbaa !24
  %t15 = load i64, ptr %l60, !tbaa !24
  %t16 = icmp slt i64 %t14, %t15
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t20, i64 %t21)
  store %"compiler/profile:Sample" %t24, ptr %l65
  br label %bb9
bb9:
  %t25 = load %"compiler/profile:Sample", ptr %l65
  store %"compiler/profile:Sample" %t25, ptr %l6
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t28 = load %"compiler/profile:Sample", ptr %l6
  %t32 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v2, ptr %v1, ptr %s2, ptr %t26, ptr %t27, %"compiler/profile:Sample" %t28)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l69
  br label %bb10
bb10:
  %t33 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t34 = getelementptr %"compiler/profile:Sample", ptr %l6, i32 0, i32 0
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l10, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store ptr %t40, ptr %l73
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l73, !tbaa !29
  store ptr %t41, ptr %l74, !tbaa !29
  %t43 = load ptr, ptr %l74, !tbaa !29
  %t44 = getelementptr %"compiler/profile:node", ptr %t43, i32 0, i32 2
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = load i64, ptr %l10, !tbaa !24
  %t50 = add i64 %t45, %t47
  %t52 = load ptr, ptr %l74, !tbaa !29
  %t53 = getelementptr %"compiler/profile:node", ptr %t52, i32 0, i32 2
  store i64 %t50, ptr %t53, !tbaa !24
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l7)
  store i64 %t55, ptr %l80
  br label %bb12
bb12:
  %t56 = load i64, ptr %l80, !tbaa !24
  %t57 = sub i64 %t56, 1
  store i64 %t57, ptr %l12, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l12, !tbaa !24
  %t61 = icmp sge i64 %t59, 0
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb44
bb15:
  br label %bb16
bb16:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/profile:Places", ptr %t65, i32 0, i32 2
  store ptr %t67, ptr %l86, !tbaa !29
  %t68 = load i64, ptr %l12, !tbaa !24
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l7, i64 %t68)
  store i64 %t71, ptr %l89
  br label %bb17
bb17:
  %t72 = load ptr, ptr %l86, !tbaa !29
  %t73 = load i64, ptr %l89, !tbaa !24
  %t74 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t72, i64 %t73)
  store %"compiler/profile:Frame" %t74, ptr %l90
  br label %bb18
bb18:
  %t75 = getelementptr %"compiler/profile:Frame", ptr %l90, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  store i64 %t76, ptr %l13, !tbaa !24
  store i64 -1, ptr %l14, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t78)
  store %"compiler/profile:node" %t81, ptr %l94
  br label %bb19
bb19:
  %t83 = call %"compiler/profile:node" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fprofile_3anode(ptr %s0, ptr %l94)
  store %"compiler/profile:node" %t83, ptr %l96
  br label %bb20
bb20:
  %t84 = getelementptr %"compiler/profile:node", ptr %l96, i32 0, i32 3
  store ptr %t84, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load i64, ptr %l16, !tbaa !24
  store i64 %t86, ptr %l98, !tbaa !24
  %t87 = load ptr, ptr %l15, !tbaa !29
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s4, ptr %t87)
  store i64 %t89, ptr %l100
  br label %bb22
bb22:
  %t90 = load i64, ptr %l98, !tbaa !24
  %t91 = load i64, ptr %l100, !tbaa !24
  %t92 = icmp slt i64 %t90, %t91
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb24:
  br label %bb25
bb25:
  %t96 = load ptr, ptr %l15, !tbaa !29
  %t97 = load i64, ptr %l16, !tbaa !24
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s4, ptr %t96, i64 %t97)
  store i64 %t100, ptr %l105
  br label %bb26
bb26:
  %t101 = load i64, ptr %l105, !tbaa !24
  store i64 %t101, ptr %l17, !tbaa !24
  %t102 = load i64, ptr %l17, !tbaa !24
  %t105 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s5, ptr %l3, i64 %t102)
  store %"compiler/profile:node" %t105, ptr %l108
  br label %bb27
bb27:
  %t106 = getelementptr %"compiler/profile:node", ptr %l108, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = icmp eq i64 %t107, %t108
  br i1 %t111, label %bb28, label %bb29
bb28:
  %t113 = load i64, ptr %l17, !tbaa !24
  store i64 %t113, ptr %l14, !tbaa !24
  br label %bb30
bb29:
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t115 = load i64, ptr %l16, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l16, !tbaa !24
  br label %bb21
bb32:
  call void @__olang_scope_close(ptr %s4)
  %t120 = load i64, ptr %l14, !tbaa !24
  %t122 = icmp slt i64 %t120, 0
  br i1 %t122, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t125 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %l3)
  store i64 %t125, ptr %l119
  br label %bb35
bb34:
  br label %bb41
bb35:
  %t126 = load i64, ptr %l119, !tbaa !24
  store i64 %t126, ptr %l14, !tbaa !24
  store ptr %l3, ptr %l120, !tbaa !29
  %t127 = load i64, ptr %l13, !tbaa !24
  store i64 %t127, ptr %l121, !tbaa !24
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s8, ptr %l3, i64 %t128)
  store %"compiler/profile:node" %t131, ptr %l124
  br label %bb36
bb36:
  %t132 = getelementptr %"compiler/profile:node", ptr %l124, i32 0, i32 1
  %t133 = load i64, ptr %t132, !tbaa !24
  %t135 = add i64 %t133, 1
  %t136 = load i64, ptr %l121, !tbaa !24
  %t138 = call %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %s8, i64 %t136, i64 %t135)
  store %"compiler/profile:node" %t138, ptr %l127
  br label %bb37
bb37:
  %t139 = load ptr, ptr %l120, !tbaa !29
  %t140 = load %"compiler/profile:node", ptr %l127
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s8, ptr %t139, %"compiler/profile:node" %t140)
  br label %bb38
bb38:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t141)
  store ptr %t144, ptr %l130
  br label %bb39
bb39:
  %t145 = load ptr, ptr %l130, !tbaa !29
  %t147 = getelementptr %"compiler/profile:node", ptr %t145, i32 0, i32 3
  %t148 = load i64, ptr %l14, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t147, i64 %t148)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s8)
  br label %bb41
bb41:
  %t151 = load i64, ptr %l14, !tbaa !24
  %t153 = getelementptr %"compiler/profile:Sample", ptr %l6, i32 0, i32 0
  %t154 = load i64, ptr %t153, !tbaa !24
  store i64 %t154, ptr %l19, !tbaa !24
  %t159 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t151)
  store ptr %t159, ptr %l138
  br label %bb42
bb42:
  %t160 = load ptr, ptr %l138, !tbaa !29
  store ptr %t160, ptr %l139, !tbaa !29
  %t162 = load ptr, ptr %l139, !tbaa !29
  %t163 = getelementptr %"compiler/profile:node", ptr %t162, i32 0, i32 2
  %t164 = load i64, ptr %t163, !tbaa !24
  %t166 = load i64, ptr %l19, !tbaa !24
  %t169 = add i64 %t164, %t166
  %t171 = load ptr, ptr %l139, !tbaa !29
  %t172 = getelementptr %"compiler/profile:node", ptr %t171, i32 0, i32 2
  store i64 %t169, ptr %t172, !tbaa !24
  %t173 = load i64, ptr %l14, !tbaa !24
  store i64 %t173, ptr %l8, !tbaa !24
  %t175 = load i64, ptr %l12, !tbaa !24
  %t178 = sub i64 %t175, 1
  store i64 %t178, ptr %l12, !tbaa !24
  br label %bb43
bb43:
  br label %bb13
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  %t180 = load i64, ptr %l5, !tbaa !24
  %t183 = add i64 %t180, 1
  store i64 %t183, ptr %l5, !tbaa !24
  br label %bb4
bb46:
  store i64 0, ptr %l21, !tbaa !24
  store ptr %l3, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb47
bb47:
  %t186 = load i64, ptr %l23, !tbaa !24
  store i64 %t186, ptr %l152, !tbaa !24
  %t187 = load ptr, ptr %l22, !tbaa !29
  %t189 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %t187)
  store i64 %t189, ptr %l154
  br label %bb48
bb48:
  %t190 = load i64, ptr %l152, !tbaa !24
  %t191 = load i64, ptr %l154, !tbaa !24
  %t192 = icmp slt i64 %t190, %t191
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb49, label %bb50
bb49:
  br label %bb57
bb50:
  br label %bb51
bb51:
  %t196 = load ptr, ptr %l22, !tbaa !29
  %t197 = load i64, ptr %l23, !tbaa !24
  %t200 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t196, i64 %t197)
  store %"compiler/profile:node" %t200, ptr %l159
  br label %bb52
bb52:
  %t201 = load %"compiler/profile:node", ptr %l159
  store %"compiler/profile:node" %t201, ptr %l24
  %t202 = getelementptr %"compiler/profile:node", ptr %l24, i32 0, i32 1
  %t203 = load i64, ptr %t202, !tbaa !24
  %t204 = load i64, ptr %l21, !tbaa !24
  %t207 = icmp sgt i64 %t203, %t204
  br i1 %t207, label %bb53, label %bb54
bb53:
  %t209 = getelementptr %"compiler/profile:node", ptr %l24, i32 0, i32 1
  %t210 = load i64, ptr %t209, !tbaa !24
  store i64 %t210, ptr %l21, !tbaa !24
  br label %bb55
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t212 = load i64, ptr %l23, !tbaa !24
  %t215 = add i64 %t212, 1
  store i64 %t215, ptr %l23, !tbaa !24
  br label %bb47
bb57:
  %t218 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store %"compiler/profile:node" %t218, ptr %l168
  br label %bb58
bb58:
  %t219 = getelementptr %"compiler/profile:node", ptr %l168, i32 0, i32 2
  %t220 = load i64, ptr %t219, !tbaa !24
  store i64 %t220, ptr %l25, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t224 = add i64 %t222, 1
  %t225 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t228 = mul i64 %t224, %t225
  %t230 = add i64 %t228, 40
  store i64 %t230, ptr %l26, !tbaa !24
  %t232 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t232, ptr %l175
  br label %bb59
bb59:
  %t233 = load %"std/prelude/text:StringBuilder", ptr %l175
  store %"std/prelude/text:StringBuilder" %t233, ptr %l27
  %t234 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l176
  br label %bb60
bb60:
  %t235 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l176
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t235, ptr %l28
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l28, i64 0)
  br label %bb61
bb61:
  %t237 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t237, ptr %l178
  br label %bb62
bb62:
  %t238 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t238, ptr %l29
  store ptr %l3, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s15
  %t240 = load i64, ptr %l31, !tbaa !24
  store i64 %t240, ptr %l180, !tbaa !24
  %t241 = load ptr, ptr %l30, !tbaa !29
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %t241)
  store i64 %t243, ptr %l182
  br label %bb64
bb64:
  %t244 = load i64, ptr %l180, !tbaa !24
  %t245 = load i64, ptr %l182, !tbaa !24
  %t246 = icmp slt i64 %t244, %t245
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s15)
  br label %bb77
bb66:
  br label %bb67
bb67:
  %t250 = load ptr, ptr %l30, !tbaa !29
  %t251 = load i64, ptr %l31, !tbaa !24
  %t254 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %t250, i64 %t251)
  store %"compiler/profile:node" %t254, ptr %l187
  br label %bb68
bb68:
  %t255 = load %"compiler/profile:node", ptr %l187
  store %"compiler/profile:node" %t255, ptr %l188
  %t256 = call ptr @__olang_scope_hold(ptr %s15)
  %t257 = ptrtoint ptr %t256 to i64
  store i64 %t257, ptr %l189, !tbaa !24
  %t258 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t258, label %bb69, label %bb70
bb69:
  %t260 = call ptr @__olang_region_make_part(ptr %s15)
  %t261 = ptrtoint ptr %t260 to i64
  store i64 %t261, ptr %l189, !tbaa !24
  br label %bb70
bb70:
  %t262 = getelementptr %"compiler/profile:node", ptr %l188, i32 0, i32 3
  %t263 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t262, i32 0, i32 0
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l191, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  store i64 %t266, ptr %l192, !tbaa !24
  %t267 = load i64, ptr %l192, !tbaa !24
  %t268 = mul i64 %t267, 8
  %t269 = load i64, ptr %l189
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = call ptr @__olang_held_alloc(ptr %t270, i64 %t268)
  %t272 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l193, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = load i64, ptr %l192, !tbaa !24
  %t279 = mul i64 %t278, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t275, ptr %t277, i64 %t279, i1 false)
  %t280 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t281 = getelementptr %"compiler/profile:node", ptr %l188, i32 0, i32 3
  %t282 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t281, i32 0, i32 0
  store { i64, ptr } %t280, ptr %t282, !tbaa !27
  %t283 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t283, label %bb71, label %bb72
bb71:
  %t285 = getelementptr %"compiler/profile:node", ptr %l188, i32 0, i32 3
  %t286 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t285, i32 0, i32 0
  %t287 = load { i64, ptr }, ptr %t286, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 0
  %t290 = icmp eq i64 %t288, 0
  br i1 %t290, label %bb73, label %bb74
bb72:
  %t292 = load %"compiler/profile:node", ptr %l188
  store %"compiler/profile:node" %t292, ptr %l32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l29, i64 0)
  br label %bb75
bb73:
  %t294 = getelementptr %"compiler/profile:node", ptr %l188, i32 0, i32 3
  %t295 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t294, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t295, !tbaa !27
  br label %bb74
bb74:
  %t296 = getelementptr %"compiler/profile:node", ptr %l188, i32 0, i32 3
  %t297 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t296, i32 0, i32 0
  %t298 = load i64, ptr %l189
  %t299 = inttoptr i64 %t298 to ptr
  %t300 = load { i64, ptr }, ptr %t297
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = call ptr @__olang_region_or(ptr %t301, ptr null)
  %t303 = icmp ne ptr %t302, null
  %t304 = select i1 %t303, ptr %t302, ptr null
  call void @__olang_region_settle_in(ptr %t299, ptr %t304)
  br label %bb72
bb75:
  call void @__olang_scope_close(ptr %s15)
  br label %bb76
bb76:
  %t305 = load i64, ptr %l31, !tbaa !24
  %t308 = add i64 %t305, 1
  store i64 %t308, ptr %l31, !tbaa !24
  br label %bb63
bb77:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s18
  %t310 = load i64, ptr %l33, !tbaa !24
  store i64 %t310, ptr %l201, !tbaa !24
  %t312 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l28)
  store i64 %t312, ptr %l203
  br label %bb79
bb79:
  %t313 = load i64, ptr %l201, !tbaa !24
  %t314 = load i64, ptr %l203, !tbaa !24
  %t315 = icmp slt i64 %t313, %t314
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s18)
  br label %bb124
bb81:
  br label %bb82
bb82:
  %t319 = load i64, ptr %l33, !tbaa !24
  %t322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l28, i64 %t319)
  store i64 %t322, ptr %l208
  br label %bb83
bb83:
  %t323 = load i64, ptr %l208, !tbaa !24
  store i64 %t323, ptr %l34, !tbaa !24
  %t324 = load i64, ptr %l34, !tbaa !24
  %t327 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t324)
  store %"compiler/profile:node" %t327, ptr %l211
  br label %bb84
bb84:
  %t329 = call %"compiler/profile:node" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fprofile_3anode(ptr %s18, ptr %l211)
  store %"compiler/profile:node" %t329, ptr %l213
  br label %bb85
bb85:
  %t330 = getelementptr %"compiler/profile:node", ptr %l213, i32 0, i32 3
  %t331 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t330
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t331, ptr %l215
  %t333 = call ptr @__olang_scope_hold(ptr %s18)
  %t334 = ptrtoint ptr %t333 to i64
  store i64 %t334, ptr %l216, !tbaa !24
  %t335 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t335, label %bb86, label %bb87
bb86:
  %t337 = call ptr @__olang_region_make_part(ptr %s18)
  %t338 = ptrtoint ptr %t337 to i64
  store i64 %t338, ptr %l216, !tbaa !24
  br label %bb87
bb87:
  %t339 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215, i32 0, i32 0
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l218, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 0
  store i64 %t342, ptr %l219, !tbaa !24
  %t343 = load i64, ptr %l219, !tbaa !24
  %t344 = mul i64 %t343, 8
  %t345 = load i64, ptr %l216
  %t346 = inttoptr i64 %t345 to ptr
  %t347 = call ptr @__olang_held_alloc(ptr %t346, i64 %t344)
  %t348 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l220, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = load i64, ptr %l219, !tbaa !24
  %t355 = mul i64 %t354, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t351, ptr %t353, i64 %t355, i1 false)
  %t356 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t357 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215, i32 0, i32 0
  store { i64, ptr } %t356, ptr %t357, !tbaa !27
  %t358 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t358, label %bb88, label %bb89
bb88:
  %t360 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215, i32 0, i32 0
  %t361 = load { i64, ptr }, ptr %t360, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t361, 0
  %t364 = icmp eq i64 %t362, 0
  br i1 %t364, label %bb90, label %bb91
bb89:
  %t366 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t366, ptr %l35
  store ptr %l35, ptr %l224, !tbaa !29
  %t367 = load ptr, ptr %l2, !tbaa !29
  store ptr %t367, ptr %l225, !tbaa !29
  %t368 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t368, ptr %l227
  %t370 = call ptr @__olang_scope_hold(ptr %s18)
  %t371 = ptrtoint ptr %t370 to i64
  store i64 %t371, ptr %l228, !tbaa !24
  %t372 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2e0
  br i1 %t372, label %bb92, label %bb93
bb90:
  %t374 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t374, !tbaa !27
  br label %bb91
bb91:
  %t375 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l215, i32 0, i32 0
  %t376 = load i64, ptr %l216
  %t377 = inttoptr i64 %t376 to ptr
  %t378 = load { i64, ptr }, ptr %t375
  %t379 = extractvalue { i64, ptr } %t378, 1
  %t380 = call ptr @__olang_region_or(ptr %t379, ptr null)
  %t381 = icmp ne ptr %t380, null
  %t382 = select i1 %t381, ptr %t380, ptr null
  call void @__olang_region_settle_in(ptr %t377, ptr %t382)
  br label %bb89
bb92:
  %t383 = call ptr @__olang_region_make_part(ptr %s18)
  %t384 = ptrtoint ptr %t383 to i64
  store i64 %t384, ptr %l228, !tbaa !24
  br label %bb93
bb93:
  %t385 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227, i32 0, i32 0
  %t386 = load { i64, ptr }, ptr %t385, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 0
  store i64 %t387, ptr %l230, !tbaa !24
  %t388 = load i64, ptr %l230, !tbaa !24
  %t389 = mul i64 %t388, 56
  %t390 = load i64, ptr %l228
  %t391 = inttoptr i64 %t390 to ptr
  %t392 = call ptr @__olang_held_alloc(ptr %t391, i64 %t389)
  %t393 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t392, 1
  store { i64, ptr } %t394, ptr %l231, !tbaa !27
  store i64 0, ptr %l232, !tbaa !24
  br label %bb94
bb94:
  %t395 = load i64, ptr %l232, !tbaa !24
  %t396 = load i64, ptr %l230, !tbaa !24
  %t397 = icmp slt i64 %t395, %t396
  br i1 %t397, label %bb95, label %bb96
bb95:
  %t399 = load i64, ptr %l232, !tbaa !24
  %t400 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227, i32 0, i32 1
  %t401 = load i64, ptr %t400, !tbaa !24
  %t402 = icmp slt i64 %t399, %t401
  br i1 %t402, label %bb99, label %bb97
bb96:
  %t404 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t405 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227, i32 0, i32 0
  store { i64, ptr } %t404, ptr %t405, !tbaa !27
  %t406 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2e0
  br i1 %t406, label %bb106, label %bb107
bb97:
  %t408 = load i64, ptr %l232, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr %"compiler/profile:node", ptr %t410, i64 %t408
  store %"compiler/profile:node" zeroinitializer, ptr %t411
  br label %bb98
bb98:
  %t412 = load i64, ptr %l232, !tbaa !24
  %t413 = add i64 %t412, 1
  store i64 %t413, ptr %l232, !tbaa !24
  br label %bb94
bb99:
  %t414 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227, i32 0, i32 0
  %t415 = load i64, ptr %l232, !tbaa !24
  %t416 = getelementptr { i64, ptr }, ptr %t414, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr %"compiler/profile:node", ptr %t417, i64 %t415
  %t419 = load %"compiler/profile:node", ptr %t418
  store %"compiler/profile:node" %t419, ptr %l235
  %t420 = call ptr @__olang_scope_hold(ptr %s18)
  %t421 = ptrtoint ptr %t420 to i64
  store i64 %t421, ptr %l236, !tbaa !24
  %t422 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t422, label %bb100, label %bb101
bb100:
  %t424 = call ptr @__olang_region_make_part(ptr %s18)
  %t425 = ptrtoint ptr %t424 to i64
  store i64 %t425, ptr %l236, !tbaa !24
  br label %bb101
bb101:
  %t426 = getelementptr %"compiler/profile:node", ptr %l235, i32 0, i32 3
  %t427 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t426, i32 0, i32 0
  %t428 = load { i64, ptr }, ptr %t427, !tbaa !27
  store { i64, ptr } %t428, ptr %l238, !tbaa !27
  %t429 = load { i64, ptr }, ptr %l238, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t429, 0
  store i64 %t430, ptr %l239, !tbaa !24
  %t431 = load i64, ptr %l239, !tbaa !24
  %t432 = mul i64 %t431, 8
  %t433 = load i64, ptr %l236
  %t434 = inttoptr i64 %t433 to ptr
  %t435 = call ptr @__olang_held_alloc(ptr %t434, i64 %t432)
  %t436 = insertvalue { i64, ptr } undef, i64 %t431, 0
  %t437 = insertvalue { i64, ptr } %t436, ptr %t435, 1
  store { i64, ptr } %t437, ptr %l240, !tbaa !27
  %t438 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !27
  %t442 = load i64, ptr %l239, !tbaa !24
  %t443 = mul i64 %t442, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t439, ptr %t441, i64 %t443, i1 false)
  %t444 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t445 = getelementptr %"compiler/profile:node", ptr %l235, i32 0, i32 3
  %t446 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t445, i32 0, i32 0
  store { i64, ptr } %t444, ptr %t446, !tbaa !27
  %t447 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t447, label %bb102, label %bb103
bb102:
  %t449 = getelementptr %"compiler/profile:node", ptr %l235, i32 0, i32 3
  %t450 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t449, i32 0, i32 0
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t451, 0
  %t454 = icmp eq i64 %t452, 0
  br i1 %t454, label %bb104, label %bb105
bb103:
  %t456 = load %"compiler/profile:node", ptr %l235
  %t457 = load i64, ptr %l232, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr %"compiler/profile:node", ptr %t459, i64 %t457
  store %"compiler/profile:node" %t456, ptr %t460
  br label %bb98
bb104:
  %t461 = getelementptr %"compiler/profile:node", ptr %l235, i32 0, i32 3
  %t462 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t461, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t462, !tbaa !27
  br label %bb105
bb105:
  %t463 = getelementptr %"compiler/profile:node", ptr %l235, i32 0, i32 3
  %t464 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t463, i32 0, i32 0
  %t465 = load i64, ptr %l236
  %t466 = inttoptr i64 %t465 to ptr
  %t467 = load { i64, ptr }, ptr %t464
  %t468 = extractvalue { i64, ptr } %t467, 1
  %t469 = call ptr @__olang_region_or(ptr %t468, ptr null)
  %t470 = icmp ne ptr %t469, null
  %t471 = select i1 %t470, ptr %t469, ptr null
  call void @__olang_region_settle_in(ptr %t466, ptr %t471)
  br label %bb103
bb106:
  %t472 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227, i32 0, i32 0
  %t473 = load { i64, ptr }, ptr %t472, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 0
  %t476 = icmp eq i64 %t474, 0
  br i1 %t476, label %bb108, label %bb109
bb107:
  %t478 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr null, i32 1
  %t479 = ptrtoint ptr %t478 to i64
  %t481 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t480, i32 0, i32 0
  %t482 = load ptr, ptr %l225, !tbaa !29
  store ptr %t482, ptr %t481, !tbaa !28
  %t483 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t480, i32 0, i32 1
  %t484 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t484, ptr %t483, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t485 = call ptr @__olang_scope_hold(ptr %v2)
  %t486 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t480, i32 0, i32 2
  store ptr %t485, ptr %t486, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t487 = call ptr @__olang_scope_hold(ptr %s0)
  %t488 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %t480, i32 0, i32 3
  store ptr %t487, ptr %t488, !tbaa !28
  %t489 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t490 = insertvalue { ptr, ptr } %t489, ptr %t480, 1
  %t491 = load ptr, ptr %l224, !tbaa !29
  %t493 = extractvalue { ptr, ptr } %t490, 0
  %t494 = extractvalue { ptr, ptr } %t490, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s18, ptr %s18, ptr %t491, ptr %t493, ptr %t494)
  br label %bb110
bb108:
  %t495 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t495, !tbaa !27
  br label %bb109
bb109:
  %t496 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l227, i32 0, i32 0
  %t497 = load i64, ptr %l228
  %t498 = inttoptr i64 %t497 to ptr
  %t499 = load { i64, ptr }, ptr %t496
  %t500 = extractvalue { i64, ptr } %t499, 1
  %t501 = call ptr @__olang_region_or(ptr %t500, ptr null)
  %t502 = icmp ne ptr %t501, null
  %t503 = select i1 %t502, ptr %t501, ptr null
  call void @__olang_region_settle_in(ptr %t498, ptr %t503)
  br label %bb107
bb110:
  %t504 = load i64, ptr %l34, !tbaa !24
  %t507 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t504)
  store i64 %t507, ptr %l250
  br label %bb111
bb111:
  %t508 = load i64, ptr %l250, !tbaa !24
  store i64 %t508, ptr %l36, !tbaa !24
  store ptr %l35, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s20
  %t510 = load i64, ptr %l38, !tbaa !24
  store i64 %t510, ptr %l252, !tbaa !24
  %t511 = load ptr, ptr %l37, !tbaa !29
  %t513 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s18, ptr %t511)
  store i64 %t513, ptr %l254
  br label %bb113
bb113:
  %t514 = load i64, ptr %l252, !tbaa !24
  %t515 = load i64, ptr %l254, !tbaa !24
  %t516 = icmp slt i64 %t514, %t515
  %t518 = xor i1 %t516, true
  br i1 %t518, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s20)
  br label %bb122
bb115:
  br label %bb116
bb116:
  %t520 = load ptr, ptr %l37, !tbaa !29
  %t521 = load i64, ptr %l38, !tbaa !24
  %t524 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s18, ptr %t520, i64 %t521)
  store i64 %t524, ptr %l259
  br label %bb117
bb117:
  %t525 = load i64, ptr %l259, !tbaa !24
  store i64 %t525, ptr %l39, !tbaa !24
  %t526 = load i64, ptr %l39, !tbaa !24
  %t527 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t526, i64 %t527)
  br label %bb118
bb118:
  %t531 = load i64, ptr %l36, !tbaa !24
  store i64 %t531, ptr %l263, !tbaa !24
  %t532 = load i64, ptr %l39, !tbaa !24
  %t535 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s20, ptr %l3, i64 %t532)
  store %"compiler/profile:node" %t535, ptr %l266
  br label %bb119
bb119:
  %t536 = getelementptr %"compiler/profile:node", ptr %l266, i32 0, i32 2
  %t537 = load i64, ptr %t536, !tbaa !24
  %t538 = load i64, ptr %l263, !tbaa !24
  %t540 = add i64 %t538, %t537
  store i64 %t540, ptr %l36, !tbaa !24
  %t542 = load i64, ptr %l39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l28, i64 %t542)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s20)
  br label %bb121
bb121:
  %t545 = load i64, ptr %l38, !tbaa !24
  %t548 = add i64 %t545, 1
  store i64 %t548, ptr %l38, !tbaa !24
  br label %bb112
bb122:
  call void @__olang_scope_close(ptr %s18)
  br label %bb123
bb123:
  %t550 = load i64, ptr %l33, !tbaa !24
  %t553 = add i64 %t550, 1
  store i64 %t553, ptr %l33, !tbaa !24
  br label %bb78
bb124:
  store ptr %l28, ptr %l40, !tbaa !29
  store i64 0, ptr %l41, !tbaa !24
  br label %bb125
bb125:
  store %olang.scope zeroinitializer, ptr %s24
  %t556 = load i64, ptr %l41, !tbaa !24
  store i64 %t556, ptr %l278, !tbaa !24
  %t557 = load ptr, ptr %l40, !tbaa !29
  %t559 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t557)
  store i64 %t559, ptr %l280
  br label %bb126
bb126:
  %t560 = load i64, ptr %l278, !tbaa !24
  %t561 = load i64, ptr %l280, !tbaa !24
  %t562 = icmp slt i64 %t560, %t561
  %t564 = xor i1 %t562, true
  br i1 %t564, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s24)
  br label %bb144
bb128:
  br label %bb129
bb129:
  %t566 = load ptr, ptr %l40, !tbaa !29
  %t567 = load i64, ptr %l41, !tbaa !24
  %t570 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t566, i64 %t567)
  store i64 %t570, ptr %l285
  br label %bb130
bb130:
  %t571 = load i64, ptr %l285, !tbaa !24
  store i64 %t571, ptr %l42, !tbaa !24
  %t572 = load i64, ptr %l42, !tbaa !24
  %t575 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRef_3ccompiler_2fprofile_3anode_3e(ptr %s0, ptr %s0, ptr %l3, i64 %t572)
  store ptr %t575, ptr %l288
  br label %bb131
bb131:
  %t576 = load ptr, ptr %l288, !tbaa !29
  store ptr %t576, ptr %l43, !tbaa !29
  %t577 = load i64, ptr %l42, !tbaa !24
  %t579 = icmp eq i64 %t577, 0
  br i1 %t579, label %bb132, label %bb133
bb132:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l291, !tbaa !27
  br label %bb135
bb133:
  %t581 = load ptr, ptr %l2, !tbaa !29
  %t583 = getelementptr %"compiler/profile:Places", ptr %t581, i32 0, i32 0
  %t584 = load ptr, ptr %l43, !tbaa !29
  %t586 = getelementptr %"compiler/profile:node", ptr %t584, i32 0, i32 0
  %t587 = load i64, ptr %t586, !tbaa !24
  %t590 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s24, ptr %t583, i64 %t587)
  store { i64, ptr } %t590, ptr %l296
  br label %bb134
bb134:
  %t591 = load { i64, ptr }, ptr %l296, !tbaa !27
  store { i64, ptr } %t591, ptr %l291, !tbaa !27
  br label %bb135
bb135:
  %t592 = load { i64, ptr }, ptr %l291, !tbaa !27
  store { i64, ptr } %t592, ptr %l44, !tbaa !27
  %t593 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t593, ptr %l297, !tbaa !27
  %t594 = load ptr, ptr %l43, !tbaa !29
  %t596 = getelementptr %"compiler/profile:node", ptr %t594, i32 0, i32 2
  %t597 = load i64, ptr %t596, !tbaa !24
  %t598 = load ptr, ptr %l1, !tbaa !29
  %t600 = getelementptr %"compiler/profile:Profile", ptr %t598, i32 0, i32 0
  %t601 = load i64, ptr %t600, !tbaa !24
  %t604 = call { i64, ptr } @compiler_2fprofile_2emillis(ptr %s24, i64 %t597, i64 %t601)
  store { i64, ptr } %t604, ptr %l302
  br label %bb136
bb136:
  %t605 = load ptr, ptr %l43, !tbaa !29
  %t607 = getelementptr %"compiler/profile:node", ptr %t605, i32 0, i32 2
  %t608 = load i64, ptr %t607, !tbaa !24
  %t609 = load i64, ptr %l25, !tbaa !24
  %t612 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s24, i64 %t608, i64 %t609)
  store { i64, ptr } %t612, ptr %l306
  br label %bb137
bb137:
  %t613 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t617 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t618 = add i64 %t615, %t617
  %t619 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t620 = extractvalue { i64, ptr } %t619, 1
  %t621 = extractvalue { i64, ptr } %t619, 0
  %t622 = add i64 %t618, %t621
  %t623 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t624 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t625 = add i64 %t622, %t624
  %t626 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t627 = extractvalue { i64, ptr } %t626, 1
  %t628 = extractvalue { i64, ptr } %t626, 0
  %t629 = add i64 %t625, %t628
  %t630 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t629)
  call void @olang_textcopy(ptr %t630, ptr %t614, i64 %t615)
  %t631 = getelementptr i8, ptr %t630, i64 %t615
  call void @olang_textcopy(ptr %t631, ptr %t616, i64 %t617)
  %t632 = getelementptr i8, ptr %t631, i64 %t617
  call void @olang_textcopy(ptr %t632, ptr %t620, i64 %t621)
  %t633 = getelementptr i8, ptr %t632, i64 %t621
  call void @olang_textcopy(ptr %t633, ptr %t623, i64 %t624)
  %t634 = getelementptr i8, ptr %t633, i64 %t624
  call void @olang_textcopy(ptr %t634, ptr %t627, i64 %t628)
  %t635 = insertvalue { i64, ptr } undef, i64 %t629, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t630, 1
  store { i64, ptr } %t636, ptr %l45, !tbaa !27
  %t638 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t640 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s24, { i64, ptr } %t638)
  store i64 %t640, ptr %l309
  br label %bb138
bb138:
  %t641 = load i64, ptr %l309, !tbaa !24
  %t642 = and i64 %t641, 65535
  store i64 %t642, ptr %l46, !tbaa !24
  %t644 = load i64, ptr %l46, !tbaa !24
  %t646 = srem i64 %t644, 50
  %t648 = add i64 205, %t646
  store i64 %t648, ptr %l47, !tbaa !24
  %t650 = load i64, ptr %l46, !tbaa !24
  %t652 = sdiv i64 %t650, 50
  %t654 = srem i64 %t652, 140
  %t656 = add i64 90, %t654
  store i64 %t656, ptr %l48, !tbaa !24
  %t658 = load i64, ptr %l46, !tbaa !24
  %t660 = sdiv i64 %t658, 7000
  %t662 = srem i64 %t660, 55
  store i64 %t662, ptr %l49, !tbaa !24
  %t664 = load i64, ptr %l26, !tbaa !24
  %t666 = sub i64 %t664, 20
  %t667 = load ptr, ptr %l43, !tbaa !29
  %t669 = getelementptr %"compiler/profile:node", ptr %t667, i32 0, i32 1
  %t670 = load i64, ptr %t669, !tbaa !24
  %t672 = add i64 %t670, 1
  %t673 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t676 = mul i64 %t672, %t673
  %t679 = sub i64 %t666, %t676
  store i64 %t679, ptr %l50, !tbaa !24
  store ptr %l27, ptr %l329, !tbaa !29
  %t681 = load i64, ptr %l42, !tbaa !24
  %t684 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l29, i64 %t681)
  store i64 %t684, ptr %l332
  br label %bb139
bb139:
  %t685 = load ptr, ptr %l43, !tbaa !29
  %t687 = getelementptr %"compiler/profile:node", ptr %t685, i32 0, i32 2
  %t688 = load i64, ptr %t687, !tbaa !24
  store i64 %t688, ptr %l334, !tbaa !24
  %t689 = load ptr, ptr %l43, !tbaa !29
  %t691 = getelementptr %"compiler/profile:node", ptr %t689, i32 0, i32 1
  %t692 = load i64, ptr %t691, !tbaa !24
  store i64 %t692, ptr %l336, !tbaa !24
  %t693 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t695 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %s24, ptr %s24, { i64, ptr } %t693)
  store { i64, ptr } %t695, ptr %l338
  br label %bb140
bb140:
  %t696 = load i64, ptr %l50, !tbaa !24
  store i64 %t696, ptr %l339, !tbaa !24
  %t697 = load i64, ptr @G_2ecompiler_2fprofile_2eFrameHeight, !tbaa !24
  %t699 = sub i64 %t697, 1
  store i64 %t699, ptr %l341, !tbaa !24
  %t700 = load i64, ptr %l47, !tbaa !24
  store i64 %t700, ptr %l342, !tbaa !24
  %t701 = load i64, ptr %l48, !tbaa !24
  store i64 %t701, ptr %l343, !tbaa !24
  %t702 = load i64, ptr %l49, !tbaa !24
  store i64 %t702, ptr %l344, !tbaa !24
  %t703 = load i64, ptr %l50, !tbaa !24
  %t705 = add i64 %t703, 13
  %t707 = call i64 @__olang_fmt_i64(ptr null, i64 %t705)
  %t708 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t707)
  %t709 = call i64 @__olang_fmt_i64(ptr %t708, i64 %t705)
  %t710 = insertvalue { i64, ptr } undef, i64 %t707, 0
  %t711 = insertvalue { i64, ptr } %t710, ptr %t708, 1
  store { i64, ptr } %t711, ptr %l347, !tbaa !27
  %t712 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t714 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %s24, ptr %s24, { i64, ptr } %t712)
  store { i64, ptr } %t714, ptr %l349
  br label %bb141
bb141:
  %t715 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t717 = load i64, ptr %l332, !tbaa !24
  %t718 = call i64 @__olang_fmt_i64(ptr null, i64 %t717)
  %t719 = add i64 %t716, %t718
  %t720 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t721 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t722 = add i64 %t719, %t721
  %t723 = load i64, ptr %l334, !tbaa !24
  %t724 = call i64 @__olang_fmt_i64(ptr null, i64 %t723)
  %t725 = add i64 %t722, %t724
  %t726 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t727 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t728 = add i64 %t725, %t727
  %t729 = load i64, ptr %l336, !tbaa !24
  %t730 = call i64 @__olang_fmt_i64(ptr null, i64 %t729)
  %t731 = add i64 %t728, %t730
  %t732 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t733 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t734 = add i64 %t731, %t733
  %t735 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t736 = extractvalue { i64, ptr } %t735, 1
  %t737 = extractvalue { i64, ptr } %t735, 0
  %t738 = add i64 %t734, %t737
  %t739 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t740 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t741 = add i64 %t738, %t740
  %t742 = load i64, ptr %l339, !tbaa !24
  %t743 = call i64 @__olang_fmt_i64(ptr null, i64 %t742)
  %t744 = add i64 %t741, %t743
  %t745 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t746 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t747 = add i64 %t744, %t746
  %t748 = load i64, ptr %l341, !tbaa !24
  %t749 = call i64 @__olang_fmt_i64(ptr null, i64 %t748)
  %t750 = add i64 %t747, %t749
  %t751 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t752 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t753 = add i64 %t750, %t752
  %t754 = load i64, ptr %l342, !tbaa !24
  %t755 = call i64 @__olang_fmt_i64(ptr null, i64 %t754)
  %t756 = add i64 %t753, %t755
  %t757 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t758 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t759 = add i64 %t756, %t758
  %t760 = load i64, ptr %l343, !tbaa !24
  %t761 = call i64 @__olang_fmt_i64(ptr null, i64 %t760)
  %t762 = add i64 %t759, %t761
  %t763 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t764 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t765 = add i64 %t762, %t764
  %t766 = load i64, ptr %l344, !tbaa !24
  %t767 = call i64 @__olang_fmt_i64(ptr null, i64 %t766)
  %t768 = add i64 %t765, %t767
  %t769 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t772 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t773 = extractvalue { i64, ptr } %t772, 1
  %t774 = extractvalue { i64, ptr } %t772, 0
  %t775 = add i64 %t771, %t774
  %t776 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t778 = add i64 %t775, %t777
  %t779 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t780 = extractvalue { i64, ptr } %t779, 1
  %t781 = extractvalue { i64, ptr } %t779, 0
  %t782 = add i64 %t778, %t781
  %t783 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t784 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t785 = add i64 %t782, %t784
  %t786 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t785)
  call void @olang_textcopy(ptr %t786, ptr %t715, i64 %t716)
  %t787 = getelementptr i8, ptr %t786, i64 %t716
  %t788 = call i64 @__olang_fmt_i64(ptr %t787, i64 %t717)
  %t789 = getelementptr i8, ptr %t787, i64 %t718
  call void @olang_textcopy(ptr %t789, ptr %t720, i64 %t721)
  %t790 = getelementptr i8, ptr %t789, i64 %t721
  %t791 = call i64 @__olang_fmt_i64(ptr %t790, i64 %t723)
  %t792 = getelementptr i8, ptr %t790, i64 %t724
  call void @olang_textcopy(ptr %t792, ptr %t726, i64 %t727)
  %t793 = getelementptr i8, ptr %t792, i64 %t727
  %t794 = call i64 @__olang_fmt_i64(ptr %t793, i64 %t729)
  %t795 = getelementptr i8, ptr %t793, i64 %t730
  call void @olang_textcopy(ptr %t795, ptr %t732, i64 %t733)
  %t796 = getelementptr i8, ptr %t795, i64 %t733
  call void @olang_textcopy(ptr %t796, ptr %t736, i64 %t737)
  %t797 = getelementptr i8, ptr %t796, i64 %t737
  call void @olang_textcopy(ptr %t797, ptr %t739, i64 %t740)
  %t798 = getelementptr i8, ptr %t797, i64 %t740
  %t799 = call i64 @__olang_fmt_i64(ptr %t798, i64 %t742)
  %t800 = getelementptr i8, ptr %t798, i64 %t743
  call void @olang_textcopy(ptr %t800, ptr %t745, i64 %t746)
  %t801 = getelementptr i8, ptr %t800, i64 %t746
  %t802 = call i64 @__olang_fmt_i64(ptr %t801, i64 %t748)
  %t803 = getelementptr i8, ptr %t801, i64 %t749
  call void @olang_textcopy(ptr %t803, ptr %t751, i64 %t752)
  %t804 = getelementptr i8, ptr %t803, i64 %t752
  %t805 = call i64 @__olang_fmt_i64(ptr %t804, i64 %t754)
  %t806 = getelementptr i8, ptr %t804, i64 %t755
  call void @olang_textcopy(ptr %t806, ptr %t757, i64 %t758)
  %t807 = getelementptr i8, ptr %t806, i64 %t758
  %t808 = call i64 @__olang_fmt_i64(ptr %t807, i64 %t760)
  %t809 = getelementptr i8, ptr %t807, i64 %t761
  call void @olang_textcopy(ptr %t809, ptr %t763, i64 %t764)
  %t810 = getelementptr i8, ptr %t809, i64 %t764
  %t811 = call i64 @__olang_fmt_i64(ptr %t810, i64 %t766)
  %t812 = getelementptr i8, ptr %t810, i64 %t767
  call void @olang_textcopy(ptr %t812, ptr %t769, i64 %t770)
  %t813 = getelementptr i8, ptr %t812, i64 %t770
  call void @olang_textcopy(ptr %t813, ptr %t773, i64 %t774)
  %t814 = getelementptr i8, ptr %t813, i64 %t774
  call void @olang_textcopy(ptr %t814, ptr %t776, i64 %t777)
  %t815 = getelementptr i8, ptr %t814, i64 %t777
  call void @olang_textcopy(ptr %t815, ptr %t780, i64 %t781)
  %t816 = getelementptr i8, ptr %t815, i64 %t781
  call void @olang_textcopy(ptr %t816, ptr %t783, i64 %t784)
  %t817 = insertvalue { i64, ptr } undef, i64 %t785, 0
  %t818 = insertvalue { i64, ptr } %t817, ptr %t786, 1
  %t820 = load ptr, ptr %l329, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s24, ptr %t820, { i64, ptr } %t818)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s24)
  br label %bb143
bb143:
  %t822 = load i64, ptr %l41, !tbaa !24
  %t825 = add i64 %t822, 1
  store i64 %t825, ptr %l41, !tbaa !24
  br label %bb125
bb144:
  %t827 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t827, ptr %l355
  br label %bb145
bb145:
  %t828 = load %"std/prelude/text:StringBuilder", ptr %l355
  store %"std/prelude/text:StringBuilder" %t828, ptr %l51
  store ptr %l51, ptr %l356, !tbaa !29
  %t829 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t831 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %s0, { i64, ptr } %t829)
  store { i64, ptr } %t831, ptr %l358
  br label %bb146
bb146:
  %t832 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t834 = load { i64, ptr }, ptr %l358, !tbaa !27
  %t835 = extractvalue { i64, ptr } %t834, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = add i64 %t833, %t836
  %t838 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t839 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t840 = add i64 %t837, %t839
  %t841 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t840)
  call void @olang_textcopy(ptr %t841, ptr %t832, i64 %t833)
  %t842 = getelementptr i8, ptr %t841, i64 %t833
  call void @olang_textcopy(ptr %t842, ptr %t835, i64 %t836)
  %t843 = getelementptr i8, ptr %t842, i64 %t836
  call void @olang_textcopy(ptr %t843, ptr %t838, i64 %t839)
  %t844 = insertvalue { i64, ptr } undef, i64 %t840, 0
  %t845 = insertvalue { i64, ptr } %t844, ptr %t841, 1
  %t847 = load ptr, ptr %l356, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t847, { i64, ptr } %t845)
  br label %bb147
bb147:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l51, { i64, ptr } { i64 213, ptr getelementptr inbounds (<{ i64, [213 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb148
bb148:
  %t850 = load ptr, ptr %l1, !tbaa !29
  %t852 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v1, ptr %t850)
  store i64 %t852, ptr %l363
  br label %bb149
bb149:
  %t853 = load i64, ptr %l363, !tbaa !24
  %t854 = sitofp i64 %t853 to double
  %t855 = load ptr, ptr %l1, !tbaa !29
  %t857 = getelementptr %"compiler/profile:Profile", ptr %t855, i32 0, i32 0
  %t858 = load i64, ptr %t857, !tbaa !24
  %t860 = sitofp i64 %t858 to double
  %t863 = fmul double %t854, %t860
  %t865 = fdiv double %t863, 0x41cdcd6500000000
  store double %t865, ptr %l52, !tbaa !26
  store ptr %l51, ptr %l370, !tbaa !29
  %t867 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t869 = call { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %s0, { i64, ptr } %t867)
  store { i64, ptr } %t869, ptr %l372
  br label %bb150
bb150:
  %t870 = load ptr, ptr %l1, !tbaa !29
  %t872 = getelementptr %"compiler/profile:Profile", ptr %t870, i32 0, i32 3
  %t874 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t872)
  store i64 %t874, ptr %l375
  br label %bb151
bb151:
  %t875 = load double, ptr %l52, !tbaa !26
  %t877 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t875, i64 3)
  store { i64, ptr } %t877, ptr %l377
  br label %bb152
bb152:
  %t878 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t879 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t880 = load { i64, ptr }, ptr %l372, !tbaa !27
  %t881 = extractvalue { i64, ptr } %t880, 1
  %t882 = extractvalue { i64, ptr } %t880, 0
  %t883 = add i64 %t879, %t882
  %t884 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t885 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t886 = add i64 %t883, %t885
  %t887 = load i64, ptr %l375, !tbaa !24
  %t888 = call i64 @__olang_fmt_i64(ptr null, i64 %t887)
  %t889 = add i64 %t886, %t888
  %t890 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t891 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t892 = add i64 %t889, %t891
  %t893 = load { i64, ptr }, ptr %l377, !tbaa !27
  %t894 = extractvalue { i64, ptr } %t893, 1
  %t895 = extractvalue { i64, ptr } %t893, 0
  %t896 = add i64 %t892, %t895
  %t897 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t898 = extractvalue { i64, ptr } { i64 78, ptr getelementptr inbounds (<{ i64, [78 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t899 = add i64 %t896, %t898
  %t900 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t899)
  call void @olang_textcopy(ptr %t900, ptr %t878, i64 %t879)
  %t901 = getelementptr i8, ptr %t900, i64 %t879
  call void @olang_textcopy(ptr %t901, ptr %t881, i64 %t882)
  %t902 = getelementptr i8, ptr %t901, i64 %t882
  call void @olang_textcopy(ptr %t902, ptr %t884, i64 %t885)
  %t903 = getelementptr i8, ptr %t902, i64 %t885
  %t904 = call i64 @__olang_fmt_i64(ptr %t903, i64 %t887)
  %t905 = getelementptr i8, ptr %t903, i64 %t888
  call void @olang_textcopy(ptr %t905, ptr %t890, i64 %t891)
  %t906 = getelementptr i8, ptr %t905, i64 %t891
  call void @olang_textcopy(ptr %t906, ptr %t894, i64 %t895)
  %t907 = getelementptr i8, ptr %t906, i64 %t895
  call void @olang_textcopy(ptr %t907, ptr %t897, i64 %t898)
  %t908 = insertvalue { i64, ptr } undef, i64 %t899, 0
  %t909 = insertvalue { i64, ptr } %t908, ptr %t900, 1
  %t911 = load ptr, ptr %l370, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t911, { i64, ptr } %t909)
  br label %bb153
bb153:
  store ptr %l51, ptr %l380, !tbaa !29
  %t913 = load i64, ptr @G_2ecompiler_2fprofile_2eFlameWidth, !tbaa !24
  store i64 %t913, ptr %l381, !tbaa !24
  %t914 = load i64, ptr %l26, !tbaa !24
  store i64 %t914, ptr %l382, !tbaa !24
  %t915 = load i64, ptr %l25, !tbaa !24
  store i64 %t915, ptr %l383, !tbaa !24
  %t917 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l27)
  store { i64, ptr } %t917, ptr %l385
  br label %bb154
bb154:
  %t918 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t919 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t920 = load i64, ptr %l381, !tbaa !24
  %t921 = call i64 @__olang_fmt_i64(ptr null, i64 %t920)
  %t922 = add i64 %t919, %t921
  %t923 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t924 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t925 = add i64 %t922, %t924
  %t926 = load i64, ptr %l382, !tbaa !24
  %t927 = call i64 @__olang_fmt_i64(ptr null, i64 %t926)
  %t928 = add i64 %t925, %t927
  %t929 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t930 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t931 = add i64 %t928, %t930
  %t932 = load i64, ptr %l383, !tbaa !24
  %t933 = call i64 @__olang_fmt_i64(ptr null, i64 %t932)
  %t934 = add i64 %t931, %t933
  %t935 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t936 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t937 = add i64 %t934, %t936
  %t938 = load { i64, ptr }, ptr %l385, !tbaa !27
  %t939 = extractvalue { i64, ptr } %t938, 1
  %t940 = extractvalue { i64, ptr } %t938, 0
  %t941 = add i64 %t937, %t940
  %t942 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t943 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t944 = add i64 %t941, %t943
  %t945 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t944)
  call void @olang_textcopy(ptr %t945, ptr %t918, i64 %t919)
  %t946 = getelementptr i8, ptr %t945, i64 %t919
  %t947 = call i64 @__olang_fmt_i64(ptr %t946, i64 %t920)
  %t948 = getelementptr i8, ptr %t946, i64 %t921
  call void @olang_textcopy(ptr %t948, ptr %t923, i64 %t924)
  %t949 = getelementptr i8, ptr %t948, i64 %t924
  %t950 = call i64 @__olang_fmt_i64(ptr %t949, i64 %t926)
  %t951 = getelementptr i8, ptr %t949, i64 %t927
  call void @olang_textcopy(ptr %t951, ptr %t929, i64 %t930)
  %t952 = getelementptr i8, ptr %t951, i64 %t930
  %t953 = call i64 @__olang_fmt_i64(ptr %t952, i64 %t932)
  %t954 = getelementptr i8, ptr %t952, i64 %t933
  call void @olang_textcopy(ptr %t954, ptr %t935, i64 %t936)
  %t955 = getelementptr i8, ptr %t954, i64 %t936
  call void @olang_textcopy(ptr %t955, ptr %t939, i64 %t940)
  %t956 = getelementptr i8, ptr %t955, i64 %t940
  call void @olang_textcopy(ptr %t956, ptr %t942, i64 %t943)
  %t957 = insertvalue { i64, ptr } undef, i64 %t944, 0
  %t958 = insertvalue { i64, ptr } %t957, ptr %t945, 1
  %t960 = load ptr, ptr %l380, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t960, { i64, ptr } %t958)
  br label %bb155
bb155:
  %t962 = load { i64, ptr }, ptr @G_2ecompiler_2fprofile_2eFlameScript, !tbaa !27
  %t963 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %t963, ptr %l51, { i64, ptr } %t962)
  br label %bb156
bb156:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l51, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb157
bb157:
  %t968 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l51)
  store { i64, ptr } %t968, ptr %l392
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  %t969 = load { i64, ptr }, ptr %l392, !tbaa !27
  store { i64, ptr } %t969, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2ePlaces_2eResolve(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/profile:Sample"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca %"compiler/profile:mapping"
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %lp34 = alloca ptr
  %l35 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca [3 x { i64, ptr }]
  %lp44 = alloca ptr
  %lp45 = alloca ptr
  %l47 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %l58 = alloca { { i64, ptr }, i64 }
  %lp59 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/profile:Places"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca %"compiler/profile:Sample"
  %l84 = alloca i64
  %l87 = alloca i64
  %l110 = alloca i64
  %l113 = alloca i64
  %l117 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i64
  %l122 = alloca i64
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l134 = alloca i64
  %l136 = alloca i64
  %l141 = alloca i64
  %l142 = alloca { i64, ptr }
  %l145 = alloca i64
  %l147 = alloca i64
  %l152 = alloca %"compiler/profile:mapping"
  %l156 = alloca i1
  %l160 = alloca i64
  %l163 = alloca { i64, ptr }
  %l164 = alloca i64
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l175 = alloca i1
  %l179 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca { i64, ptr }
  %l184 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l185 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca i32
  %l190 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l193 = alloca i64
  %l197 = alloca i64
  %l200 = alloca i64
  %l218 = alloca i64
  %l221 = alloca i64
  %l223 = alloca i1
  %l224 = alloca i64
  %l227 = alloca i64
  %l231 = alloca i64
  %l234 = alloca i64
  %l237 = alloca i64
  %l238 = alloca i64
  %l242 = alloca i64
  %l257 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l259 = alloca i1
  %l261 = alloca %"std/prelude/text:StringBuilder"
  %l263 = alloca i64
  %l267 = alloca i64
  %l270 = alloca i64
  %l290 = alloca i64
  %l292 = alloca ptr
  %l295 = alloca { i64, ptr }
  %l298 = alloca i64
  %l299 = alloca i64
  %l300 = alloca i64
  %l301 = alloca i32
  %l302 = alloca { i64, ptr }
  %l313 = alloca %"std/os:Output"
  %l317 = alloca { i64, ptr }
  %l319 = alloca { i64, ptr }
  %l322 = alloca %"std/os:Output"
  %l323 = alloca i32
  %l325 = alloca i1
  %l328 = alloca %"std/os:Output"
  %l332 = alloca %"std/prelude/text:LineIter"
  %l333 = alloca { i64, ptr }
  %l335 = alloca { i64, ptr }
  %l336 = alloca i32
  %l338 = alloca i1
  %l341 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l343 = alloca i64
  %l347 = alloca i64
  %l350 = alloca i64
  %l368 = alloca ptr
  %l370 = alloca i64
  %l373 = alloca i64
  %l375 = alloca i1
  %l376 = alloca i64
  %l378 = alloca i64
  %l381 = alloca i64
  %l383 = alloca i64
  %l385 = alloca i1
  %l388 = alloca { i64, ptr }
  %l389 = alloca i1
  %l394 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l403 = alloca { { i64, ptr }, i64 }
  %l404 = alloca { i64, ptr }
  %l405 = alloca i64
  %l406 = alloca { i64, ptr }
  %l409 = alloca i1
  %l410 = alloca i1
  %l413 = alloca { i64, ptr }
  %l414 = alloca i1
  %l415 = alloca ptr
  %l418 = alloca { i64, ptr }
  %l421 = alloca i64
  %l422 = alloca { i64, ptr }
  %l425 = alloca i1
  %l428 = alloca i64
  %l429 = alloca i64
  %l430 = alloca i64
  %l431 = alloca i32
  %l432 = alloca { i64, ptr }
  %l435 = alloca { i64, ptr }
  %l436 = alloca { i64, ptr }
  %l440 = alloca { i64, ptr }
  %l442 = alloca ptr
  %l445 = alloca i64
  %l448 = alloca i64
  %l450 = alloca %"compiler/profile:Frame"
  %l459 = alloca i1
  %l462 = alloca i64
  %l464 = alloca i1
  %l467 = alloca { i64, ptr }
  %l468 = alloca i1
  %l469 = alloca ptr
  %l472 = alloca { i64, ptr }
  %l473 = alloca i1
  %l475 = alloca ptr
  %l476 = alloca i64
  %l480 = alloca { i64, ptr }
  %l482 = alloca { i64, ptr }
  %l485 = alloca { i64, ptr }
  %l486 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l487 = alloca ptr
  %l488 = alloca ptr
  %l491 = alloca { i64, ptr }
  %l492 = alloca ptr
  %l493 = alloca i32
  %l494 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l496 = alloca ptr
  %l499 = alloca i64
  %l500 = alloca { i64, ptr }
  %l502 = alloca i1
  %l504 = alloca ptr
  %l505 = alloca ptr
  %l507 = alloca { i64, ptr }
  %l509 = alloca i64
  %l511 = alloca i64
  %l512 = alloca %"compiler/profile:Frame"
  %l517 = alloca { i64, ptr }
  %l518 = alloca i1
  %l520 = alloca { i64, ptr }
  %l523 = alloca { i64, ptr }
  %l524 = alloca { i64, ptr }
  %l525 = alloca ptr
  %l526 = alloca ptr
  %l529 = alloca i64
  %l530 = alloca i64
  %l531 = alloca i64
  %l532 = alloca i32
  %l533 = alloca { i64, ptr }
  %l537 = alloca i64
  %l539 = alloca i64
  %l540 = alloca %"compiler/profile:Frame"
  %l546 = alloca %"compiler/profile:Places"
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %t1 = alloca %"compiler/profile:Places", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fprofile_3aPlaces_2ector(ptr %t1, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l64, ptr %t1, i64 272, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 272, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l64, i64 272, i1 false)
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/profile:Profile", ptr %t4, i32 0, i32 5
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2emappings(ptr %v0, ptr %s0, { i64, ptr } %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l67
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l3
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H6cf7c9f2359d1ee39cd99e769614c19f(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l68
  br label %bb3
bb3:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l68
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %l4
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l69
  br label %bb4
bb4:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l5
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/profile:Profile", ptr %t15, i32 0, i32 3
  store ptr %t17, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t19 = load i64, ptr %l7, !tbaa !24
  store i64 %t19, ptr %l72, !tbaa !24
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l74
  br label %bb6
bb6:
  %t23 = load i64, ptr %l72, !tbaa !24
  %t24 = load i64, ptr %l74, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  br label %bb35
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t29, i64 %t30)
  store %"compiler/profile:Sample" %t33, ptr %l79
  br label %bb10
bb10:
  %t34 = load %"compiler/profile:Sample", ptr %l79
  store %"compiler/profile:Sample" %t34, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t35 = getelementptr %"compiler/profile:Sample", ptr %l8, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t38 = load i64, ptr %l10, !tbaa !24
  %t39 = load i64, ptr %l9, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = load i64, ptr %l11, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb16
bb13:
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l11, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l11, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l87, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb15
bb15:
  %t64 = load i64, ptr %l87, !tbaa !24
  store i64 %t64, ptr %l84, !tbaa !24
  br label %bb16
bb16:
  %t65 = load i64, ptr %l84, !tbaa !24
  store i64 %t65, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l13, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  br label %bb33
bb19:
  br label %bb20
bb20:
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l13, !tbaa !24
  %t76 = load i64, ptr %l11, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l14, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/profile:Profile", ptr %t84, i32 0, i32 4
  %t87 = getelementptr %"compiler/profile:Sample", ptr %l8, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t89 = load i64, ptr %l14, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t86, i64 %t92)
  store i64 %t95, ptr %l110
  br label %bb21
bb21:
  %t96 = load i64, ptr %l14, !tbaa !24
  %t98 = icmp eq i64 %t96, 0
  br i1 %t98, label %bb22, label %bb23
bb22:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb24
bb23:
  store i64 1, ptr %l113, !tbaa !24
  br label %bb24
bb24:
  %t100 = load i64, ptr %l110, !tbaa !24
  %t101 = load i64, ptr %l113, !tbaa !24
  %t102 = sub i64 %t100, %t101
  store i64 %t102, ptr %l15, !tbaa !24
  %t104 = load ptr, ptr %lp2
  %t105 = getelementptr %"compiler/profile:Places", ptr %t104, i32 0, i32 5
  %t106 = load i64, ptr %l15, !tbaa !24
  %t109 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t105, i64 %t106)
  store i1 %t109, ptr %l117
  br label %bb25
bb25:
  %t110 = load i1, ptr %l117, !tbaa !21
  %t111 = xor i1 %t110, true
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t113 = load ptr, ptr %lp2
  %t114 = getelementptr %"compiler/profile:Places", ptr %t113, i32 0, i32 5
  store ptr %t114, ptr %l119, !tbaa !29
  %t115 = load i64, ptr %l15, !tbaa !24
  store i64 %t115, ptr %l120, !tbaa !24
  %t117 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t117, ptr %l122
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t118 = load ptr, ptr %l119, !tbaa !29
  %t119 = load i64, ptr %l120, !tbaa !24
  %t120 = load i64, ptr %l122, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %t118, i64 %t119, i64 %t120)
  br label %bb29
bb29:
  %t121 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t121)
  br label %bb30
bb30:
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t127 = add i64 %t124, 1
  store i64 %t127, ptr %l13, !tbaa !24
  br label %bb17
bb33:
  br label %bb34
bb34:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t132 = add i64 %t129, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb5
bb35:
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l131
  br label %bb36
bb36:
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l16
  %t136 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l132
  br label %bb37
bb37:
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l17
  store ptr %l5, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb38
bb38:
  %t139 = load i64, ptr %l19, !tbaa !24
  store i64 %t139, ptr %l134, !tbaa !24
  %t140 = load ptr, ptr %l18, !tbaa !29
  %t142 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t140)
  store i64 %t142, ptr %l136
  br label %bb39
bb39:
  %t143 = load i64, ptr %l134, !tbaa !24
  %t144 = load i64, ptr %l136, !tbaa !24
  %t145 = icmp slt i64 %t143, %t144
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb40, label %bb41
bb40:
  br label %bb106
bb41:
  br label %bb42
bb42:
  %t149 = load ptr, ptr %l18, !tbaa !29
  %t150 = load i64, ptr %l19, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l141
  br label %bb43
bb43:
  %t154 = load i64, ptr %l141, !tbaa !24
  store i64 %t154, ptr %l20, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l142, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t155, ptr %l21, !tbaa !27
  store i64 -1, ptr %l22, !tbaa !24
  store ptr %l3, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s11
  %t158 = load i64, ptr %l24, !tbaa !24
  store i64 %t158, ptr %l145, !tbaa !24
  %t159 = load ptr, ptr %l23, !tbaa !29
  %t161 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eLen__Heb6545c4cbf57678e5e8a74f397c9583(ptr %s0, ptr %t159)
  store i64 %t161, ptr %l147
  br label %bb45
bb45:
  %t162 = load i64, ptr %l145, !tbaa !24
  %t163 = load i64, ptr %l147, !tbaa !24
  %t164 = icmp slt i64 %t162, %t163
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s11)
  br label %bb102
bb47:
  br label %bb48
bb48:
  %t168 = load ptr, ptr %l23, !tbaa !29
  %t169 = load i64, ptr %l24, !tbaa !24
  %t172 = call %"compiler/profile:mapping" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eAt_3ccompiler_2fprofile_3amapping_3e(ptr %s0, ptr %s0, ptr %t168, i64 %t169)
  store %"compiler/profile:mapping" %t172, ptr %l152
  br label %bb49
bb49:
  %t173 = load %"compiler/profile:mapping", ptr %l152
  store %"compiler/profile:mapping" %t173, ptr %l25
  %t174 = load i64, ptr %l20, !tbaa !24
  %t175 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 0
  %t176 = load i64, ptr %t175, !tbaa !24
  %t179 = icmp slt i64 %t174, %t176
  br i1 %t179, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb52
bb51:
  %t181 = load i64, ptr %l20, !tbaa !24
  %t182 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 1
  %t183 = load i64, ptr %t182, !tbaa !24
  %t186 = icmp sge i64 %t181, %t183
  store i1 %t186, ptr %l156, !tbaa !21
  br label %bb52
bb52:
  %t188 = load i1, ptr %l156, !tbaa !21
  br i1 %t188, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s11)
  br label %bb101
bb54:
  br label %bb55
bb55:
  %t189 = call ptr @__olang_scope_hold(ptr %s0)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l160, !tbaa !24
  %t191 = load i1, ptr @olang_2esole_2ecompiler__2fprofile__2ePlaces__2eResolve_2elocal_2e21
  br i1 %t191, label %bb56, label %bb57
bb56:
  %t193 = call ptr @__olang_region_make(ptr %s0)
  %t194 = ptrtoint ptr %t193 to i64
  store i64 %t194, ptr %l160, !tbaa !24
  br label %bb57
bb57:
  %t195 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 3
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  store { i64, ptr } %t196, ptr %l163, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l164, !tbaa !24
  %t200 = load i64, ptr %l164, !tbaa !24
  %t201 = mul i64 %t200, 1
  %t202 = load i64, ptr %l160
  %t203 = inttoptr i64 %t202 to ptr
  %t204 = call ptr @__olang_held_alloc(ptr %t203, i64 %t201)
  %t205 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l165, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !27
  %t211 = load i64, ptr %l164, !tbaa !24
  %t212 = mul i64 %t211, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t208, ptr %t210, i64 %t212, i1 false)
  %t213 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t213, ptr %l166, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t214, ptr %l21, !tbaa !27
  %t215 = load i1, ptr @olang_2esole_2ecompiler__2fprofile__2ePlaces__2eResolve_2elocal_2e21
  br i1 %t215, label %bb58, label %bb59
bb58:
  %t217 = load { i64, ptr }, ptr %l166
  %t218 = extractvalue { i64, ptr } %t217, 1
  call void @__olang_region_release(ptr %t218)
  store { i64, ptr } zeroinitializer, ptr %l166
  br label %bb59
bb59:
  %t219 = load i1, ptr @olang_2esole_2ecompiler__2fprofile__2ePlaces__2eResolve_2elocal_2e21
  br i1 %t219, label %bb60, label %bb61
bb60:
  %t221 = load i64, ptr %l160
  %t222 = inttoptr i64 %t221 to ptr
  %t223 = load { i64, ptr }, ptr %l21
  %t224 = extractvalue { i64, ptr } %t223, 1
  %t225 = call ptr @__olang_region_or(ptr %t224, ptr null)
  %t226 = icmp ne ptr %t225, null
  %t227 = select i1 %t226, ptr %t225, ptr null
  call void @__olang_region_settle_in(ptr %t222, ptr %t227)
  br label %bb61
bb61:
  %t228 = load i64, ptr %l20, !tbaa !24
  %t229 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t233 = sub i64 %t228, %t230
  %t234 = getelementptr %"compiler/profile:mapping", ptr %l25, i32 0, i32 2
  %t235 = load i64, ptr %t234, !tbaa !24
  %t238 = add i64 %t233, %t235
  store i64 %t238, ptr %l26, !tbaa !24
  %t240 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t242 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s11, { i64, ptr } %t240, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t242, ptr %l175
  br label %bb62
bb62:
  %t243 = load i1, ptr %l175, !tbaa !21
  %t244 = xor i1 %t243, true
  br i1 %t244, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb102
bb64:
  br label %bb65
bb65:
  %t246 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t249 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H67bc384d82ac3ceb3fdc5d6d25b5f02a(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t246)
  store i1 %t249, ptr %l179
  br label %bb66
bb66:
  %t250 = load i1, ptr %l179, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s14
  store ptr %l4, ptr %l181, !tbaa !29
  %t253 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t253, ptr %l182, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t256 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2esegments(ptr %s0, ptr %s14, { i64, ptr } %t254)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %l184
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t257 = load ptr, ptr %l181, !tbaa !29
  %t258 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t259 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l184
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd2a6d6393d72da4a22d0070783b9e545(ptr %s0, ptr %s0, ptr %s14, ptr %t257, { i64, ptr } %t258, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t259)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s14)
  br label %bb71
bb71:
  %t260 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t263 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H613fddb0939c6e46b95f2b1f68ba1bdb(ptr %s0, ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t260)
  %t264 = extractvalue { i32, ptr } %t263, 1
  %t265 = extractvalue { i32, ptr } %t263, 0
  store i32 %t265, ptr %l189
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb73, label %ok.267, !prof !99
ok.267:
  store ptr %t264, ptr %l188
  br label %bb72
bb72:
  %t268 = load ptr, ptr %l188, !tbaa !29
  store ptr %t268, ptr %l185, !tbaa !29
  br label %bb76
bb73:
  br label %bb74
bb74:
  %t269 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t269, ptr %l190
  br label %bb75
bb75:
  %t270 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l190
  %t271 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t270, ptr %t271
  store ptr %t271, ptr %l185, !tbaa !29
  br label %bb76
bb76:
  %t273 = load ptr, ptr %l185, !tbaa !29
  store ptr %t273, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  %t274 = load ptr, ptr %l27, !tbaa !29
  %t276 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t274)
  store i64 %t276, ptr %l193
  br label %bb77
bb77:
  %t277 = load i64, ptr %l193, !tbaa !24
  store i64 %t277, ptr %l29, !tbaa !24
  store i64 3, ptr %l30, !tbaa !24
  %t278 = load i64, ptr %l29, !tbaa !24
  %t279 = load i64, ptr %l28, !tbaa !24
  %t282 = icmp sgt i64 %t278, %t279
  br i1 %t282, label %bb78, label %bb79
bb78:
  %t284 = load i64, ptr %l30, !tbaa !24
  %t286 = icmp sgt i64 %t284, 0
  br i1 %t286, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l197, !tbaa !24
  br label %bb83
bb80:
  %t288 = load i64, ptr %l29, !tbaa !24
  %t289 = load i64, ptr %l28, !tbaa !24
  %t292 = sub i64 %t288, %t289
  %t293 = load i64, ptr %l30, !tbaa !24
  %t296 = add i64 %t292, %t293
  %t298 = sub i64 %t296, 1
  %t299 = load i64, ptr %l30, !tbaa !24
  %t302 = sdiv i64 %t298, %t299
  store i64 %t302, ptr %l200, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l200, !tbaa !24
  br label %bb82
bb82:
  %t304 = load i64, ptr %l200, !tbaa !24
  store i64 %t304, ptr %l197, !tbaa !24
  br label %bb83
bb83:
  %t305 = load i64, ptr %l197, !tbaa !24
  store i64 %t305, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb84
bb84:
  %t306 = load i64, ptr %l32, !tbaa !24
  %t307 = load i64, ptr %l31, !tbaa !24
  %t310 = icmp slt i64 %t306, %t307
  %t312 = xor i1 %t310, true
  br i1 %t312, label %bb85, label %bb86
bb85:
  br label %bb100
bb86:
  br label %bb87
bb87:
  %t314 = load i64, ptr %l28, !tbaa !24
  %t315 = load i64, ptr %l32, !tbaa !24
  %t316 = load i64, ptr %l30, !tbaa !24
  %t319 = mul i64 %t315, %t316
  %t322 = add i64 %t314, %t319
  store i64 %t322, ptr %l33, !tbaa !24
  %t324 = load i64, ptr %l26, !tbaa !24
  store i64 %t324, ptr %l218, !tbaa !24
  %t325 = load ptr, ptr %l27, !tbaa !29
  %t326 = load i64, ptr %l33, !tbaa !24
  %t329 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t325, i64 %t326)
  store i64 %t329, ptr %l221
  br label %bb88
bb88:
  %t330 = load i64, ptr %l218, !tbaa !24
  %t331 = load i64, ptr %l221, !tbaa !24
  %t332 = icmp sge i64 %t330, %t331
  br i1 %t332, label %bb89, label %bb90
bb89:
  %t334 = load i64, ptr %l26, !tbaa !24
  store i64 %t334, ptr %l224, !tbaa !24
  %t335 = load ptr, ptr %l27, !tbaa !29
  %t336 = load i64, ptr %l33, !tbaa !24
  %t339 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t335, i64 %t336)
  store i64 %t339, ptr %l227
  br label %bb91
bb90:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb93
bb91:
  %t340 = load ptr, ptr %l27, !tbaa !29
  %t341 = load i64, ptr %l33, !tbaa !24
  %t343 = add i64 %t341, 1
  %t346 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t340, i64 %t343)
  store i64 %t346, ptr %l231
  br label %bb92
bb92:
  %t347 = load i64, ptr %l227, !tbaa !24
  %t348 = load i64, ptr %l231, !tbaa !24
  %t349 = add i64 %t347, %t348
  %t350 = load i64, ptr %l224, !tbaa !24
  %t352 = icmp slt i64 %t350, %t349
  store i1 %t352, ptr %l223, !tbaa !21
  br label %bb93
bb93:
  %t354 = load i1, ptr %l223, !tbaa !21
  br i1 %t354, label %bb94, label %bb95
bb94:
  %t355 = load i64, ptr %l26, !tbaa !24
  store i64 %t355, ptr %l234, !tbaa !24
  %t356 = load ptr, ptr %l27, !tbaa !29
  %t357 = load i64, ptr %l33, !tbaa !24
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t356, i64 %t357)
  store i64 %t360, ptr %l237
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t361 = load i64, ptr %l234, !tbaa !24
  %t362 = load i64, ptr %l237, !tbaa !24
  %t363 = sub i64 %t361, %t362
  store i64 %t363, ptr %l238, !tbaa !24
  %t364 = load ptr, ptr %l27, !tbaa !29
  %t365 = load i64, ptr %l33, !tbaa !24
  %t367 = add i64 %t365, 2
  %t370 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t364, i64 %t367)
  store i64 %t370, ptr %l242
  br label %bb97
bb97:
  %t371 = load i64, ptr %l238, !tbaa !24
  %t372 = load i64, ptr %l242, !tbaa !24
  %t373 = add i64 %t371, %t372
  store i64 %t373, ptr %l22, !tbaa !24
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t375 = load i64, ptr %l32, !tbaa !24
  %t378 = add i64 %t375, 1
  store i64 %t378, ptr %l32, !tbaa !24
  br label %bb84
bb100:
  call void @__olang_scope_close(ptr %s11)
  br label %bb102
bb101:
  %t380 = load i64, ptr %l24, !tbaa !24
  %t383 = add i64 %t380, 1
  store i64 %t383, ptr %l24, !tbaa !24
  br label %bb44
bb102:
  %t385 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l16, { i64, ptr } %t385)
  br label %bb103
bb103:
  %t388 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l17, i64 %t388)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t391 = load i64, ptr %l19, !tbaa !24
  %t394 = add i64 %t391, 1
  store i64 %t394, ptr %l19, !tbaa !24
  br label %bb38
bb106:
  %t396 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396, ptr %l257
  br label %bb107
bb107:
  %t397 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t397, ptr %lp34
  %t398 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l257
  %t399 = load ptr, ptr %lp34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t398, ptr %t399
  %t400 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t402 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t400, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t402, ptr %l259
  br label %bb108
bb108:
  %t403 = load i1, ptr %l259, !tbaa !21
  %t404 = xor i1 %t403, true
  br i1 %t404, label %bb109, label %bb110
bb109:
  store %olang.scope zeroinitializer, ptr %s21
  %t406 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s21)
  store %"std/prelude/text:StringBuilder" %t406, ptr %l261
  br label %bb111
bb110:
  br label %bb158
bb111:
  %t407 = load %"std/prelude/text:StringBuilder", ptr %l261
  store %"std/prelude/text:StringBuilder" %t407, ptr %l35
  store i64 0, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  %t409 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t409, ptr %l263
  br label %bb112
bb112:
  %t410 = load i64, ptr %l263, !tbaa !24
  store i64 %t410, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t411 = load i64, ptr %l38, !tbaa !24
  %t412 = load i64, ptr %l37, !tbaa !24
  %t415 = icmp sgt i64 %t411, %t412
  br i1 %t415, label %bb113, label %bb114
bb113:
  %t417 = load i64, ptr %l39, !tbaa !24
  %t419 = icmp sgt i64 %t417, 0
  br i1 %t419, label %bb115, label %bb116
bb114:
  store i64 0, ptr %l267, !tbaa !24
  br label %bb118
bb115:
  %t421 = load i64, ptr %l38, !tbaa !24
  %t422 = load i64, ptr %l37, !tbaa !24
  %t425 = sub i64 %t421, %t422
  %t426 = load i64, ptr %l39, !tbaa !24
  %t429 = add i64 %t425, %t426
  %t431 = sub i64 %t429, 1
  %t432 = load i64, ptr %l39, !tbaa !24
  %t435 = sdiv i64 %t431, %t432
  store i64 %t435, ptr %l270, !tbaa !24
  br label %bb117
bb116:
  store i64 0, ptr %l270, !tbaa !24
  br label %bb117
bb117:
  %t437 = load i64, ptr %l270, !tbaa !24
  store i64 %t437, ptr %l267, !tbaa !24
  br label %bb118
bb118:
  %t438 = load i64, ptr %l267, !tbaa !24
  store i64 %t438, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s23
  %t439 = load i64, ptr %l41, !tbaa !24
  %t440 = load i64, ptr %l40, !tbaa !24
  %t443 = icmp slt i64 %t439, %t440
  %t445 = xor i1 %t443, true
  br i1 %t445, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s23)
  br label %bb134
bb121:
  br label %bb122
bb122:
  %t447 = load i64, ptr %l37, !tbaa !24
  %t448 = load i64, ptr %l41, !tbaa !24
  %t449 = load i64, ptr %l39, !tbaa !24
  %t452 = mul i64 %t448, %t449
  %t455 = add i64 %t447, %t452
  store i64 %t455, ptr %l42, !tbaa !24
  %t457 = load i64, ptr %l42, !tbaa !24
  %t460 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t457)
  store i64 %t460, ptr %l290
  br label %bb123
bb123:
  %t461 = load i64, ptr %l290, !tbaa !24
  %t462 = icmp slt i64 %t461, 0
  br i1 %t462, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s23)
  br label %bb133
bb125:
  br label %bb126
bb126:
  store ptr %l35, ptr %l292, !tbaa !29
  %t464 = load i64, ptr %l42, !tbaa !24
  %t467 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s23, ptr %l16, i64 %t464)
  store { i64, ptr } %t467, ptr %l295
  br label %bb127
bb127:
  %t468 = load i64, ptr %l42, !tbaa !24
  %t471 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t468)
  store i64 %t471, ptr %l298
  br label %bb128
bb128:
  %t472 = load i64, ptr %l298, !tbaa !24
  store i64 %t472, ptr %l299, !tbaa !65
  %t473 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s23, i64 16)
  %t474 = extractvalue { i32, i64 } %t473, 1
  %t475 = extractvalue { i32, i64 } %t473, 0
  store i32 %t475, ptr %l301
  %t476 = icmp ne i32 %t475, 0
  br i1 %t476, label %bb130, label %ok.477, !prof !99
ok.477:
  store i64 %t474, ptr %l300
  br label %bb129
bb129:
  %t478 = load i64, ptr %l299, !tbaa !65
  %t479 = load i64, ptr %l300, !tbaa !24
  %t480 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s23, i64 %t478, i64 %t479)
  store { i64, ptr } %t480, ptr %l302
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_3866f265829cb50e_54c32d3b9a091762)
  unreachable
bb131:
  %t481 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t482 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t483 = load { i64, ptr }, ptr %l295, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t483, 1
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t486 = add i64 %t482, %t485
  %t487 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t488 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t489 = add i64 %t486, %t488
  %t490 = load { i64, ptr }, ptr %l302, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = add i64 %t489, %t492
  %t494 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t495 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t496 = add i64 %t493, %t495
  %t497 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t496)
  call void @olang_textcopy(ptr %t497, ptr %t481, i64 %t482)
  %t498 = getelementptr i8, ptr %t497, i64 %t482
  call void @olang_textcopy(ptr %t498, ptr %t484, i64 %t485)
  %t499 = getelementptr i8, ptr %t498, i64 %t485
  call void @olang_textcopy(ptr %t499, ptr %t487, i64 %t488)
  %t500 = getelementptr i8, ptr %t499, i64 %t488
  call void @olang_textcopy(ptr %t500, ptr %t491, i64 %t492)
  %t501 = getelementptr i8, ptr %t500, i64 %t492
  call void @olang_textcopy(ptr %t501, ptr %t494, i64 %t495)
  %t502 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t503 = insertvalue { i64, ptr } %t502, ptr %t497, 1
  %t505 = load ptr, ptr %l292, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s21, ptr %s23, ptr %t505, { i64, ptr } %t503)
  br label %bb132
bb132:
  %t507 = load i64, ptr %l36, !tbaa !24
  %t510 = add i64 %t507, 1
  store i64 %t510, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s23)
  br label %bb133
bb133:
  %t512 = load i64, ptr %l41, !tbaa !24
  %t515 = add i64 %t512, 1
  store i64 %t515, ptr %l41, !tbaa !24
  br label %bb119
bb134:
  %t517 = load i64, ptr %l36, !tbaa !24
  %t519 = icmp sgt i64 %t517, 0
  br i1 %t519, label %bb135, label %bb136
bb135:
  store %olang.scope zeroinitializer, ptr %s27
  %t521 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t523 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t521, 0
  %t524 = insertvalue [3 x { i64, ptr }] %t523, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t525 = insertvalue [3 x { i64, ptr }] %t524, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d35, i32 0, i32 1) }, 2
  store [3 x { i64, ptr }] %t525, ptr %l43
  %t528 = insertvalue { i64, ptr } undef, i64 3, 0
  %t529 = insertvalue { i64, ptr } %t528, ptr %l43, 1
  store { i64, ptr } %t529, ptr %l317, !tbaa !27
  %t531 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s21, ptr %s27, ptr %l35)
  store { i64, ptr } %t531, ptr %l319
  br label %bb137
bb136:
  br label %bb157
bb137:
  %t532 = load { i64, ptr }, ptr %l319, !tbaa !27
  %t534 = extractvalue { i64, ptr } %t532, 0
  %t535 = extractvalue { i64, ptr } %t532, 1
  %t536 = mul i64 %t534, 1
  %t537 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t536)
  call void @llvm.memcpy.p0.p0.i64(ptr %t537, ptr %t535, i64 %t536, i1 false)
  %t538 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t539 = insertvalue { i64, ptr } %t538, ptr %t537, 1
  %t540 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t542 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s27, ptr %s27, ptr %s27, ptr %v2, { i64, ptr } %t540, { i64, ptr } %t539, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  %t543 = extractvalue { i32, %"std/os:Output" } %t542, 1
  %t544 = extractvalue { i32, %"std/os:Output" } %t542, 0
  store i32 %t544, ptr %l323
  %t545 = icmp ne i32 %t544, 0
  br i1 %t545, label %bb139, label %ok.546, !prof !99
ok.546:
  store %"std/os:Output" %t543, ptr %l322
  br label %bb138
bb138:
  %t547 = load %"std/os:Output", ptr %l322
  store %"std/os:Output" %t547, ptr %l313
  br label %bb144
bb139:
  %t548 = load i32, ptr %l323, !tbaa !23
  %t549 = ashr i32 %t548, 16
  %t551 = icmp eq i32 %t549, 1
  store i1 %t551, ptr %l325, !tbaa !21
  %t552 = load i32, ptr %l323, !tbaa !23
  %t553 = ashr i32 %t552, 16
  %t555 = icmp eq i32 %t553, 1
  br i1 %t555, label %bb140, label %bb141
bb140:
  call void @__olang_errpay_pop()
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t557 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v2, ptr %v2, ptr %v2, i32 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store %"std/os:Output" %t557, ptr %l328
  br label %bb143
bb143:
  %t558 = load %"std/os:Output", ptr %l328
  store %"std/os:Output" %t558, ptr %l313
  br label %bb144
bb144:
  %t559 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store ptr %t559, ptr %lp44
  %t560 = load %"std/os:Output", ptr %l313
  %t561 = load ptr, ptr %lp44
  store %"std/os:Output" %t560, ptr %t561
  %t562 = load ptr, ptr %lp44
  %t563 = getelementptr %"std/os:Output", ptr %t562, i32 0, i32 0
  %t564 = load i32, ptr %t563, !tbaa !23
  %t566 = icmp eq i32 %t564, 0
  br i1 %t566, label %bb145, label %bb146
bb145:
  %t568 = load ptr, ptr %lp44
  %t569 = getelementptr %"std/os:Output", ptr %t568, i32 0, i32 1
  %t570 = load { i64, ptr }, ptr %t569, !tbaa !27
  %t572 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v2, ptr %v2, { i64, ptr } %t570)
  store %"std/prelude/text:LineIter" %t572, ptr %l332
  br label %bb147
bb146:
  br label %bb156
bb147:
  %t573 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t573, ptr %lp45
  %t574 = load %"std/prelude/text:LineIter", ptr %l332
  %t575 = load ptr, ptr %lp45
  store %"std/prelude/text:LineIter" %t574, ptr %t575
  br label %bb148
bb148:
  %t576 = load ptr, ptr %lp45
  %t578 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v2, ptr %v2, ptr %t576)
  %t579 = extractvalue { i32, { i64, ptr } } %t578, 1
  %t580 = extractvalue { i32, { i64, ptr } } %t578, 0
  store i32 %t580, ptr %l336
  %t581 = icmp ne i32 %t580, 0
  br i1 %t581, label %bb150, label %ok.582, !prof !99
ok.582:
  store { i64, ptr } %t579, ptr %l335
  br label %bb149
bb149:
  %t583 = load { i64, ptr }, ptr %l335, !tbaa !27
  store { i64, ptr } %t583, ptr %l333, !tbaa !27
  br label %bb152
bb150:
  %t584 = load i32, ptr %l336, !tbaa !23
  %t585 = ashr i32 %t584, 16
  %t587 = icmp eq i32 %t585, 1
  store i1 %t587, ptr %l338, !tbaa !21
  br label %bb151
bb151:
  br label %bb155
bb152:
  %t588 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t589 = load ptr, ptr %lp34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t589, { i64, ptr } %t588)
  br label %bb153
bb153:
  br label %bb154
bb154:
  br label %bb148
bb155:
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s27)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s21)
  br label %bb158
bb158:
  %t593 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H84525b00cfc40be2d2c61524b3658c11(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t593, ptr %l341
  br label %bb159
bb159:
  %t594 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l341
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t594, ptr %l47
  store i64 0, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  %t596 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t596, ptr %l343
  br label %bb160
bb160:
  %t597 = load i64, ptr %l343, !tbaa !24
  store i64 %t597, ptr %l50, !tbaa !24
  store i64 1, ptr %l51, !tbaa !24
  %t598 = load i64, ptr %l50, !tbaa !24
  %t599 = load i64, ptr %l49, !tbaa !24
  %t602 = icmp sgt i64 %t598, %t599
  br i1 %t602, label %bb161, label %bb162
bb161:
  %t604 = load i64, ptr %l51, !tbaa !24
  %t606 = icmp sgt i64 %t604, 0
  br i1 %t606, label %bb163, label %bb164
bb162:
  store i64 0, ptr %l347, !tbaa !24
  br label %bb166
bb163:
  %t608 = load i64, ptr %l50, !tbaa !24
  %t609 = load i64, ptr %l49, !tbaa !24
  %t612 = sub i64 %t608, %t609
  %t613 = load i64, ptr %l51, !tbaa !24
  %t616 = add i64 %t612, %t613
  %t618 = sub i64 %t616, 1
  %t619 = load i64, ptr %l51, !tbaa !24
  %t622 = sdiv i64 %t618, %t619
  store i64 %t622, ptr %l350, !tbaa !24
  br label %bb165
bb164:
  store i64 0, ptr %l350, !tbaa !24
  br label %bb165
bb165:
  %t624 = load i64, ptr %l350, !tbaa !24
  store i64 %t624, ptr %l347, !tbaa !24
  br label %bb166
bb166:
  %t625 = load i64, ptr %l347, !tbaa !24
  store i64 %t625, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb167
bb167:
  store %olang.scope zeroinitializer, ptr %s32
  %t626 = load i64, ptr %l53, !tbaa !24
  %t627 = load i64, ptr %l52, !tbaa !24
  %t630 = icmp slt i64 %t626, %t627
  %t632 = xor i1 %t630, true
  br i1 %t632, label %bb168, label %bb169
bb168:
  call void @__olang_scope_close(ptr %s32)
  br label %bb283
bb169:
  br label %bb170
bb170:
  %t634 = load i64, ptr %l49, !tbaa !24
  %t635 = load i64, ptr %l53, !tbaa !24
  %t636 = load i64, ptr %l51, !tbaa !24
  %t639 = mul i64 %t635, %t636
  %t642 = add i64 %t634, %t639
  store i64 %t642, ptr %l54, !tbaa !24
  %t644 = load ptr, ptr %lp2
  %t645 = getelementptr %"compiler/profile:Places", ptr %t644, i32 0, i32 3
  store ptr %t645, ptr %l368, !tbaa !29
  %t646 = load ptr, ptr %lp2
  %t647 = getelementptr %"compiler/profile:Places", ptr %t646, i32 0, i32 2
  %t649 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eLen_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t647)
  store i64 %t649, ptr %l370
  br label %bb171
bb171:
  %t650 = load ptr, ptr %l368, !tbaa !29
  %t651 = load i64, ptr %l370, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t650, i64 %t651)
  br label %bb172
bb172:
  store i64 0, ptr %l55, !tbaa !24
  %t652 = load i64, ptr %l54, !tbaa !24
  %t655 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t652)
  store i64 %t655, ptr %l373
  br label %bb173
bb173:
  %t656 = load i64, ptr %l373, !tbaa !24
  %t657 = icmp sge i64 %t656, 0
  br i1 %t657, label %bb174, label %bb175
bb174:
  %t659 = load i64, ptr %l48, !tbaa !24
  store i64 %t659, ptr %l376, !tbaa !24
  %t660 = load ptr, ptr %lp34
  %t662 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t660)
  store i64 %t662, ptr %l378
  br label %bb176
bb175:
  store i1 false, ptr %l375, !tbaa !21
  br label %bb177
bb176:
  %t663 = load i64, ptr %l376, !tbaa !24
  %t664 = load i64, ptr %l378, !tbaa !24
  %t665 = icmp slt i64 %t663, %t664
  store i1 %t665, ptr %l375, !tbaa !21
  br label %bb177
bb177:
  %t667 = load i1, ptr %l375, !tbaa !21
  br i1 %t667, label %bb178, label %bb179
bb178:
  br label %bb180
bb179:
  br label %bb222
bb180:
  store %olang.scope zeroinitializer, ptr %s34
  %t668 = load i64, ptr %l48, !tbaa !24
  %t670 = add i64 %t668, 1
  store i64 %t670, ptr %l381, !tbaa !24
  %t671 = load ptr, ptr %lp34
  %t673 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t671)
  store i64 %t673, ptr %l383
  br label %bb181
bb181:
  %t674 = load i64, ptr %l381, !tbaa !24
  %t675 = load i64, ptr %l383, !tbaa !24
  %t676 = icmp slt i64 %t674, %t675
  br i1 %t676, label %bb182, label %bb183
bb182:
  %t678 = load ptr, ptr %lp34
  %t679 = load i64, ptr %l48, !tbaa !24
  %t682 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t678, i64 %t679)
  store { i64, ptr } %t682, ptr %l388
  br label %bb184
bb183:
  store i1 false, ptr %l385, !tbaa !21
  br label %bb186
bb184:
  %t683 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t684 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s34, { i64, ptr } %t683, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t684, ptr %l389
  br label %bb185
bb185:
  %t685 = load i1, ptr %l389, !tbaa !21
  %t686 = xor i1 %t685, true
  store i1 %t686, ptr %l385, !tbaa !21
  br label %bb186
bb186:
  %t688 = load i1, ptr %l385, !tbaa !21
  %t689 = xor i1 %t688, true
  br i1 %t689, label %bb187, label %bb188
bb187:
  call void @__olang_scope_close(ptr %s34)
  br label %bb221
bb188:
  br label %bb189
bb189:
  %t691 = load ptr, ptr %lp34
  %t692 = load i64, ptr %l48, !tbaa !24
  %t695 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t691, i64 %t692)
  store { i64, ptr } %t695, ptr %l394
  br label %bb190
bb190:
  %t696 = load { i64, ptr }, ptr %l394, !tbaa !27
  store { i64, ptr } %t696, ptr %l56, !tbaa !27
  %t697 = load ptr, ptr %lp34
  %t698 = load i64, ptr %l48, !tbaa !24
  %t700 = add i64 %t698, 1
  %t703 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t697, i64 %t700)
  store { i64, ptr } %t703, ptr %l398
  br label %bb191
bb191:
  %t704 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t705 = load i64, ptr %l48, !tbaa !24
  %t708 = add i64 %t705, 2
  store i64 %t708, ptr %l48, !tbaa !24
  %t712 = call { { i64, ptr }, i64 } @compiler_2fprofile_2efileLine(ptr %v2, ptr %v2, { i64, ptr } %t704)
  store { { i64, ptr }, i64 } %t712, ptr %l403
  br label %bb192
bb192:
  %t713 = load { { i64, ptr }, i64 }, ptr %l403
  store { { i64, ptr }, i64 } %t713, ptr %l58
  %t714 = getelementptr { { i64, ptr }, i64 }, ptr %l58, i32 0, i32 0
  %t715 = load { i64, ptr }, ptr %t714, !tbaa !27
  store { i64, ptr } %t715, ptr %l404, !tbaa !27
  %t716 = load { i64, ptr }, ptr %l404, !tbaa !27
  %t717 = extractvalue { i64, ptr } %t716, 0
  store i64 %t717, ptr %l405, !tbaa !24
  %t718 = load i64, ptr %l405, !tbaa !24
  %t719 = mul i64 %t718, 1
  %t720 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t719)
  %t721 = insertvalue { i64, ptr } undef, i64 %t718, 0
  %t722 = insertvalue { i64, ptr } %t721, ptr %t720, 1
  store { i64, ptr } %t722, ptr %l406, !tbaa !27
  %t723 = getelementptr { i64, ptr }, ptr %l406, i32 0, i32 1
  %t724 = load ptr, ptr %t723, !tbaa !27
  %t725 = getelementptr { i64, ptr }, ptr %l404, i32 0, i32 1
  %t726 = load ptr, ptr %t725, !tbaa !27
  %t727 = load i64, ptr %l405, !tbaa !24
  %t728 = mul i64 %t727, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t724, ptr %t726, i64 %t728, i1 false)
  %t729 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t729, ptr %lp59
  %t730 = load { i64, ptr }, ptr %l406, !tbaa !27
  %t731 = load ptr, ptr %lp59
  store { i64, ptr } %t730, ptr %t731, !tbaa !27
  %t732 = getelementptr { { i64, ptr }, i64 }, ptr %l58, i32 0, i32 1
  %t733 = load i64, ptr %t732, !tbaa !24
  store i64 %t733, ptr %l60, !tbaa !24
  %t735 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t737 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s34, { i64, ptr } %t735, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t737, ptr %l409
  br label %bb193
bb193:
  %t738 = load i1, ptr %l409, !tbaa !21
  br i1 %t738, label %bb194, label %bb195
bb194:
  %t739 = load i64, ptr %l54, !tbaa !24
  %t742 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t739)
  store { i64, ptr } %t742, ptr %l413
  br label %bb196
bb195:
  store i1 false, ptr %l410, !tbaa !21
  br label %bb198
bb196:
  %t743 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t744 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s34, { i64, ptr } %t743, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t744, ptr %l414
  br label %bb197
bb197:
  %t745 = load i1, ptr %l414, !tbaa !21
  store i1 %t745, ptr %l410, !tbaa !21
  br label %bb198
bb198:
  %t746 = load i1, ptr %l410, !tbaa !21
  br i1 %t746, label %bb199, label %bb200
bb199:
  store ptr %l47, ptr %l415, !tbaa !29
  %t747 = load i64, ptr %l54, !tbaa !24
  %t750 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t747)
  store { i64, ptr } %t750, ptr %l418
  br label %bb201
bb200:
  br label %bb204
bb201:
  %t751 = load i64, ptr %l54, !tbaa !24
  %t754 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t751)
  store i64 %t754, ptr %l421
  br label %bb202
bb202:
  %t755 = load ptr, ptr %l415, !tbaa !29
  %t756 = load { i64, ptr }, ptr %l418, !tbaa !27
  %t757 = load i64, ptr %l421, !tbaa !24
  %t758 = call { i64, ptr } @compiler_2fprofile_2esymbolIn(ptr %s0, ptr %s0, ptr %v2, ptr %t755, { i64, ptr } %t756, i64 %t757)
  store { i64, ptr } %t758, ptr %l422
  br label %bb203
bb203:
  %t759 = load { i64, ptr }, ptr %l422, !tbaa !27
  store { i64, ptr } %t759, ptr %l56, !tbaa !27
  br label %bb204
bb204:
  %t761 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t763 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s34, { i64, ptr } %t761, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t763, ptr %l425
  br label %bb205
bb205:
  %t764 = load i1, ptr %l425, !tbaa !21
  br i1 %t764, label %bb206, label %bb207
bb206:
  store %olang.scope zeroinitializer, ptr %s36
  %t765 = load i64, ptr %l54, !tbaa !24
  %t768 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t765)
  store i64 %t768, ptr %l428
  br label %bb208
bb207:
  %t769 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t771 = call { i64, ptr } @compiler_2fprofile_2eReadable(ptr %v2, ptr %v2, { i64, ptr } %t769)
  store { i64, ptr } %t771, ptr %l440
  br label %bb214
bb208:
  %t772 = load i64, ptr %l428, !tbaa !24
  store i64 %t772, ptr %l429, !tbaa !65
  %t773 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s36, i64 16)
  %t774 = extractvalue { i32, i64 } %t773, 1
  %t775 = extractvalue { i32, i64 } %t773, 0
  store i32 %t775, ptr %l431
  %t776 = icmp ne i32 %t775, 0
  br i1 %t776, label %bb210, label %ok.777, !prof !99
ok.777:
  store i64 %t774, ptr %l430
  br label %bb209
bb209:
  %t778 = load i64, ptr %l429, !tbaa !65
  %t779 = load i64, ptr %l430, !tbaa !24
  %t780 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s36, i64 %t778, i64 %t779)
  store { i64, ptr } %t780, ptr %l432
  br label %bb211
bb210:
  call void @__olang_check_failed(ptr @olang_loc_698502529ad2e54f_f0e75116d399f563)
  unreachable
bb211:
  %t781 = load i64, ptr %l54, !tbaa !24
  %t784 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t781)
  store { i64, ptr } %t784, ptr %l435
  br label %bb212
bb212:
  %t785 = load { i64, ptr }, ptr %l435, !tbaa !27
  %t786 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s36, { i64, ptr } %t785)
  store { i64, ptr } %t786, ptr %l436
  br label %bb213
bb213:
  %t787 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t788 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t789 = load { i64, ptr }, ptr %l432, !tbaa !27
  %t790 = extractvalue { i64, ptr } %t789, 1
  %t791 = extractvalue { i64, ptr } %t789, 0
  %t792 = add i64 %t788, %t791
  %t793 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t794 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t795 = add i64 %t792, %t794
  %t796 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t797 = extractvalue { i64, ptr } %t796, 1
  %t798 = extractvalue { i64, ptr } %t796, 0
  %t799 = add i64 %t795, %t798
  %t800 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t801 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t802 = add i64 %t799, %t801
  %t803 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t802)
  call void @olang_textcopy(ptr %t803, ptr %t787, i64 %t788)
  %t804 = getelementptr i8, ptr %t803, i64 %t788
  call void @olang_textcopy(ptr %t804, ptr %t790, i64 %t791)
  %t805 = getelementptr i8, ptr %t804, i64 %t791
  call void @olang_textcopy(ptr %t805, ptr %t793, i64 %t794)
  %t806 = getelementptr i8, ptr %t805, i64 %t794
  call void @olang_textcopy(ptr %t806, ptr %t797, i64 %t798)
  %t807 = getelementptr i8, ptr %t806, i64 %t798
  call void @olang_textcopy(ptr %t807, ptr %t800, i64 %t801)
  %t808 = insertvalue { i64, ptr } undef, i64 %t802, 0
  %t809 = insertvalue { i64, ptr } %t808, ptr %t803, 1
  store { i64, ptr } %t809, ptr %l56, !tbaa !27
  call void @__olang_scope_close(ptr %s36)
  br label %bb215
bb214:
  %t812 = load { i64, ptr }, ptr %l440, !tbaa !27
  store { i64, ptr } %t812, ptr %l56, !tbaa !27
  br label %bb215
bb215:
  %t814 = load ptr, ptr %lp2
  %t815 = getelementptr %"compiler/profile:Places", ptr %t814, i32 0, i32 2
  store ptr %t815, ptr %l442, !tbaa !29
  %t816 = load ptr, ptr %lp2
  %t817 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t820 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %v2, ptr %t816, { i64, ptr } %t817)
  store i64 %t820, ptr %l445
  br label %bb216
bb216:
  %t821 = load ptr, ptr %lp2
  %t822 = load ptr, ptr %lp59
  %t823 = load { i64, ptr }, ptr %t822, !tbaa !27
  %t826 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %v2, ptr %t821, { i64, ptr } %t823)
  store i64 %t826, ptr %l448
  br label %bb217
bb217:
  %t827 = load i64, ptr %l60, !tbaa !24
  %t828 = load i64, ptr %l445, !tbaa !24
  %t829 = load i64, ptr %l448, !tbaa !24
  %t831 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s34, i64 %t828, i64 %t829, i64 %t827)
  store %"compiler/profile:Frame" %t831, ptr %l450
  br label %bb218
bb218:
  %t832 = load ptr, ptr %l442, !tbaa !29
  %t833 = load %"compiler/profile:Frame", ptr %l450
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t832, %"compiler/profile:Frame" %t833)
  br label %bb219
bb219:
  %t834 = load i64, ptr %l55, !tbaa !24
  %t837 = add i64 %t834, 1
  store i64 %t837, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s34)
  br label %bb220
bb220:
  br label %bb180
bb221:
  %t839 = load i64, ptr %l48, !tbaa !24
  %t842 = add i64 %t839, 1
  store i64 %t842, ptr %l48, !tbaa !24
  br label %bb222
bb222:
  %t844 = load i64, ptr %l55, !tbaa !24
  %t846 = icmp eq i64 %t844, 0
  br i1 %t846, label %bb223, label %bb224
bb223:
  %t848 = load i64, ptr %l54, !tbaa !24
  %t851 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t848)
  store i64 %t851, ptr %l462
  br label %bb225
bb224:
  store i1 false, ptr %l459, !tbaa !21
  br label %bb226
bb225:
  %t852 = load i64, ptr %l462, !tbaa !24
  %t853 = icmp sge i64 %t852, 0
  store i1 %t853, ptr %l459, !tbaa !21
  br label %bb226
bb226:
  %t855 = load i1, ptr %l459, !tbaa !21
  br i1 %t855, label %bb227, label %bb228
bb227:
  %t856 = load i64, ptr %l54, !tbaa !24
  %t859 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t856)
  store { i64, ptr } %t859, ptr %l467
  br label %bb229
bb228:
  store i1 false, ptr %l464, !tbaa !21
  br label %bb231
bb229:
  %t860 = load { i64, ptr }, ptr %l467, !tbaa !27
  %t861 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s32, { i64, ptr } %t860, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t861, ptr %l468
  br label %bb230
bb230:
  %t862 = load i1, ptr %l468, !tbaa !21
  store i1 %t862, ptr %l464, !tbaa !21
  br label %bb231
bb231:
  %t863 = load i1, ptr %l464, !tbaa !21
  br i1 %t863, label %bb232, label %bb233
bb232:
  store %olang.scope zeroinitializer, ptr %s39
  store ptr %l47, ptr %l469, !tbaa !29
  %t864 = load i64, ptr %l54, !tbaa !24
  %t867 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t864)
  store { i64, ptr } %t867, ptr %l472
  br label %bb234
bb233:
  br label %bb262
bb234:
  %t868 = load ptr, ptr %l469, !tbaa !29
  %t869 = load { i64, ptr }, ptr %l472, !tbaa !27
  %t870 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %s0, ptr %s0, ptr %t868, { i64, ptr } %t869)
  store i1 %t870, ptr %l473
  br label %bb235
bb235:
  %t871 = load i1, ptr %l473, !tbaa !21
  %t872 = xor i1 %t871, true
  br i1 %t872, label %bb236, label %bb237
bb236:
  store %olang.scope zeroinitializer, ptr %s40
  store ptr %l47, ptr %l475, !tbaa !29
  %t874 = call ptr @__olang_scope_hold(ptr %s0)
  %t875 = ptrtoint ptr %t874 to i64
  store i64 %t875, ptr %l476, !tbaa !24
  %t876 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_H31300daf7c6be9b9667c9cd96eea1c7e
  br i1 %t876, label %bb238, label %bb239
bb237:
  br label %bb244
bb238:
  %t878 = call ptr @__olang_region_make(ptr %s0)
  %t879 = ptrtoint ptr %t878 to i64
  store i64 %t879, ptr %l476, !tbaa !24
  br label %bb239
bb239:
  %t880 = load i64, ptr %l54, !tbaa !24
  %t883 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s40, ptr %l16, i64 %t880)
  store { i64, ptr } %t883, ptr %l480
  br label %bb240
bb240:
  %t884 = load { i64, ptr }, ptr %l480, !tbaa !27
  %t885 = extractvalue { i64, ptr } %t884, 1
  %t886 = extractvalue { i64, ptr } %t884, 0
  %t887 = load i64, ptr %l476
  %t888 = inttoptr i64 %t887 to ptr
  %t889 = call ptr @__olang_held_alloc(ptr %t888, i64 %t886)
  call void @olang_textcopy(ptr %t889, ptr %t885, i64 %t886)
  %t890 = insertvalue { i64, ptr } undef, i64 %t886, 0
  %t891 = insertvalue { i64, ptr } %t890, ptr %t889, 1
  store { i64, ptr } %t891, ptr %l482, !tbaa !27
  %t893 = load i64, ptr %l54, !tbaa !24
  %t896 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t893)
  store { i64, ptr } %t896, ptr %l485
  br label %bb241
bb241:
  %t897 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t898 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2efunctionSymbols(ptr %s0, ptr %s0, { i64, ptr } %t897)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t898, ptr %l486
  br label %bb242
bb242:
  %t899 = load ptr, ptr %l475, !tbaa !29
  %t900 = load { i64, ptr }, ptr %l482, !tbaa !27
  %t901 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l486
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %s0, ptr %s0, ptr %s0, ptr %t899, { i64, ptr } %t900, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t901)
  br label %bb243
bb243:
  call void @__olang_scope_close(ptr %s40)
  br label %bb244
bb244:
  store ptr %l47, ptr %l488, !tbaa !29
  %t902 = load i64, ptr %l54, !tbaa !24
  %t905 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t902)
  store { i64, ptr } %t905, ptr %l491
  br label %bb245
bb245:
  %t906 = load ptr, ptr %l488, !tbaa !29
  %t907 = load { i64, ptr }, ptr %l491, !tbaa !27
  %t908 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hfa095cf457cc3af0cc9715613212afd3(ptr %s0, ptr %s0, ptr %s0, ptr %t906, { i64, ptr } %t907)
  %t909 = extractvalue { i32, ptr } %t908, 1
  %t910 = extractvalue { i32, ptr } %t908, 0
  store i32 %t910, ptr %l493
  %t911 = icmp ne i32 %t910, 0
  br i1 %t911, label %bb247, label %ok.912, !prof !99
ok.912:
  store ptr %t909, ptr %l492
  br label %bb246
bb246:
  %t913 = load ptr, ptr %l492, !tbaa !29
  store ptr %t913, ptr %l487, !tbaa !29
  br label %bb250
bb247:
  br label %bb248
bb248:
  %t914 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t914, ptr %l494
  br label %bb249
bb249:
  %t915 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l494
  %t916 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t915, ptr %t916
  store ptr %t916, ptr %l487, !tbaa !29
  br label %bb250
bb250:
  %t918 = load ptr, ptr %l487, !tbaa !29
  store ptr %t918, ptr %l496, !tbaa !29
  %t920 = load i64, ptr %l54, !tbaa !24
  %t923 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l17, i64 %t920)
  store i64 %t923, ptr %l499
  br label %bb251
bb251:
  %t924 = load ptr, ptr %l496, !tbaa !29
  %t925 = load i64, ptr %l499, !tbaa !24
  %t926 = call { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %s0, ptr %s39, ptr %t924, i64 %t925)
  store { i64, ptr } %t926, ptr %l500
  br label %bb252
bb252:
  %t927 = load { i64, ptr }, ptr %l500, !tbaa !27
  store { i64, ptr } %t927, ptr %l62, !tbaa !27
  %t928 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t930 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s39, ptr %s39, { i64, ptr } %t928, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t930, ptr %l502
  br label %bb253
bb253:
  %t931 = load i1, ptr %l502, !tbaa !21
  %t932 = xor i1 %t931, true
  br i1 %t932, label %bb254, label %bb255
bb254:
  store %olang.scope zeroinitializer, ptr %s42
  %t934 = load ptr, ptr %lp2
  %t935 = getelementptr %"compiler/profile:Places", ptr %t934, i32 0, i32 2
  store ptr %t935, ptr %l504, !tbaa !29
  %t936 = load ptr, ptr %lp2
  store ptr %t936, ptr %l505, !tbaa !29
  %t937 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t939 = call { i64, ptr } @compiler_2fprofile_2eReadable(ptr %s39, ptr %v2, { i64, ptr } %t937)
  store { i64, ptr } %t939, ptr %l507
  br label %bb256
bb255:
  br label %bb261
bb256:
  %t940 = load { i64, ptr }, ptr %l507, !tbaa !27
  %t941 = load ptr, ptr %l505, !tbaa !29
  %t943 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %v2, ptr %t941, { i64, ptr } %t940)
  store i64 %t943, ptr %l509
  br label %bb257
bb257:
  %t944 = load ptr, ptr %lp2
  %t946 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %v2, ptr %t944, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i64 %t946, ptr %l511
  br label %bb258
bb258:
  %t947 = load i64, ptr %l509, !tbaa !24
  %t948 = load i64, ptr %l511, !tbaa !24
  %t949 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s42, i64 %t947, i64 %t948, i64 0)
  store %"compiler/profile:Frame" %t949, ptr %l512
  br label %bb259
bb259:
  %t950 = load ptr, ptr %l504, !tbaa !29
  %t951 = load %"compiler/profile:Frame", ptr %l512
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t950, %"compiler/profile:Frame" %t951)
  br label %bb260
bb260:
  store i64 1, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s42)
  br label %bb261
bb261:
  call void @__olang_scope_close(ptr %s39)
  br label %bb262
bb262:
  %t952 = load i64, ptr %l55, !tbaa !24
  %t954 = icmp eq i64 %t952, 0
  br i1 %t954, label %bb263, label %bb264
bb263:
  store %olang.scope zeroinitializer, ptr %s43
  %t956 = load i64, ptr %l54, !tbaa !24
  %t959 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t956)
  store { i64, ptr } %t959, ptr %l517
  br label %bb265
bb264:
  br label %bb280
bb265:
  %t960 = load { i64, ptr }, ptr %l517, !tbaa !27
  %t961 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s43, { i64, ptr } %t960, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t961, ptr %l518
  br label %bb266
bb266:
  %t962 = load i1, ptr %l518, !tbaa !21
  %t963 = xor i1 %t962, true
  br i1 %t963, label %bb267, label %bb268
bb267:
  %t965 = load i64, ptr %l54, !tbaa !24
  %t968 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l16, i64 %t965)
  store { i64, ptr } %t968, ptr %l523
  br label %bb269
bb268:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l520, !tbaa !27
  br label %bb271
bb269:
  %t969 = load { i64, ptr }, ptr %l523, !tbaa !27
  %t970 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s43, { i64, ptr } %t969)
  store { i64, ptr } %t970, ptr %l524
  br label %bb270
bb270:
  %t971 = load { i64, ptr }, ptr %l524, !tbaa !27
  store { i64, ptr } %t971, ptr %l520, !tbaa !27
  br label %bb271
bb271:
  %t972 = load { i64, ptr }, ptr %l520, !tbaa !27
  store { i64, ptr } %t972, ptr %l63, !tbaa !27
  %t973 = load ptr, ptr %lp2
  %t974 = getelementptr %"compiler/profile:Places", ptr %t973, i32 0, i32 2
  store ptr %t974, ptr %l525, !tbaa !29
  %t975 = load ptr, ptr %lp2
  store ptr %t975, ptr %l526, !tbaa !29
  %t976 = load i64, ptr %l54, !tbaa !24
  %t979 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l5, i64 %t976)
  store i64 %t979, ptr %l529
  br label %bb272
bb272:
  %t980 = load i64, ptr %l529, !tbaa !24
  store i64 %t980, ptr %l530, !tbaa !65
  %t981 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s43, i64 16)
  %t982 = extractvalue { i32, i64 } %t981, 1
  %t983 = extractvalue { i32, i64 } %t981, 0
  store i32 %t983, ptr %l532
  %t984 = icmp ne i32 %t983, 0
  br i1 %t984, label %bb274, label %ok.985, !prof !99
ok.985:
  store i64 %t982, ptr %l531
  br label %bb273
bb273:
  %t986 = load i64, ptr %l530, !tbaa !65
  %t987 = load i64, ptr %l531, !tbaa !24
  %t988 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s43, i64 %t986, i64 %t987)
  store { i64, ptr } %t988, ptr %l533
  br label %bb275
bb274:
  call void @__olang_check_failed(ptr @olang_loc_6b0ecf2869984314_228026d38fe8b188)
  unreachable
bb275:
  %t989 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t990 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t991 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t992 = load { i64, ptr }, ptr %l533, !tbaa !27
  %t993 = extractvalue { i64, ptr } %t992, 1
  %t994 = extractvalue { i64, ptr } %t992, 0
  %t995 = add i64 %t991, %t994
  %t996 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t997 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t998 = add i64 %t995, %t997
  %t1000 = extractvalue { i64, ptr } %t989, 1
  %t1001 = extractvalue { i64, ptr } %t989, 0
  %t1002 = add i64 %t998, %t1001
  %t1003 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t1004 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t1005 = add i64 %t1002, %t1004
  %t1006 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t1005)
  call void @olang_textcopy(ptr %t1006, ptr %t990, i64 %t991)
  %t1007 = getelementptr i8, ptr %t1006, i64 %t991
  call void @olang_textcopy(ptr %t1007, ptr %t993, i64 %t994)
  %t1008 = getelementptr i8, ptr %t1007, i64 %t994
  call void @olang_textcopy(ptr %t1008, ptr %t996, i64 %t997)
  %t1009 = getelementptr i8, ptr %t1008, i64 %t997
  call void @olang_textcopy(ptr %t1009, ptr %t1000, i64 %t1001)
  %t1010 = getelementptr i8, ptr %t1009, i64 %t1001
  call void @olang_textcopy(ptr %t1010, ptr %t1003, i64 %t1004)
  %t1011 = insertvalue { i64, ptr } undef, i64 %t1005, 0
  %t1012 = insertvalue { i64, ptr } %t1011, ptr %t1006, 1
  %t1014 = load ptr, ptr %l526, !tbaa !29
  %t1016 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %v2, ptr %t1014, { i64, ptr } %t1012)
  store i64 %t1016, ptr %l537
  br label %bb276
bb276:
  %t1017 = load ptr, ptr %lp2
  %t1019 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v2, ptr %v2, ptr %t1017, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i64 %t1019, ptr %l539
  br label %bb277
bb277:
  %t1020 = load i64, ptr %l537, !tbaa !24
  %t1021 = load i64, ptr %l539, !tbaa !24
  %t1022 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s43, i64 %t1020, i64 %t1021, i64 0)
  store %"compiler/profile:Frame" %t1022, ptr %l540
  br label %bb278
bb278:
  %t1023 = load ptr, ptr %l525, !tbaa !29
  %t1024 = load %"compiler/profile:Frame", ptr %l540
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v2, ptr %t1023, %"compiler/profile:Frame" %t1024)
  br label %bb279
bb279:
  store i64 1, ptr %l55, !tbaa !24
  call void @__olang_scope_close(ptr %s43)
  br label %bb280
bb280:
  %t1025 = load ptr, ptr %lp2
  %t1026 = getelementptr %"compiler/profile:Places", ptr %t1025, i32 0, i32 4
  %t1027 = load i64, ptr %l55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t1026, i64 %t1027)
  br label %bb281
bb281:
  call void @__olang_scope_close(ptr %s32)
  br label %bb282
bb282:
  %t1030 = load i64, ptr %l53, !tbaa !24
  %t1033 = add i64 %t1030, 1
  store i64 %t1033, ptr %l53, !tbaa !24
  br label %bb167
bb283:
  %t1035 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l546, ptr %t1035, i64 272, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l546, i64 272, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca %"compiler/profile:Profile"
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l23 = alloca [8 x i8]
  %l24 = alloca { i64, ptr }
  %l26 = alloca i1
  %l30 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i1
  %l54 = alloca i64
  %l59 = alloca i1
  %l62 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca i64
  %l80 = alloca i64
  %l82 = alloca %"compiler/profile:Sample"
  %l87 = alloca i64
  %l90 = alloca i64
  %l108 = alloca ptr
  %l115 = alloca i64
  %l124 = alloca i64
  %l126 = alloca { i64, ptr }
  %l129 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/profile:Profile" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v1)
  store %"compiler/profile:Profile" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 104, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"compiler/profile:Profile", ptr %l12
  %t4 = load ptr, ptr %lp1
  store %"compiler/profile:Profile" %t3, ptr %t4
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp slt i64 %t7, 40
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb3:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l17, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l18, !tbaa !24
  %t14 = icmp sge i64 0, 0
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = icmp sle i64 0, 8
  br i1 %t16, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_19eabfe0257f2300_73d07f391b90fd8c)
  unreachable
bb6:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = icmp sle i64 8, %t18
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_19eabfe0257f2300_73d07f391b90fd8c)
  unreachable
bb8:
  %t21 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 0
  %t25 = load [8 x i8], ptr %t23
  store [8 x i8] %t25, ptr %l23
  %t26 = mul i64 8, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 8, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l24, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = mul i64 8, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t31, ptr %l23, i64 %t32, i1 false)
  %t33 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t33, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t35, ptr %l26
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_19eabfe0257f2300_73d07f391b90fd8c)
  unreachable
bb10:
  %t36 = load i1, ptr %l26, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l16, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t41 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/profile:Profile" } %t41, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t42 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t44 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t42, i64 1)
  store i64 %t44, ptr %l30
  br label %bb15
bb15:
  %t45 = load i64, ptr %l30, !tbaa !24
  %t46 = load ptr, ptr %lp1
  %t47 = getelementptr %"compiler/profile:Profile", ptr %t46, i32 0, i32 0
  store i64 %t45, ptr %t47, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t50 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t48, i64 2)
  store i64 %t50, ptr %l32
  br label %bb16
bb16:
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t54 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t52, i64 3)
  store i64 %t54, ptr %l34
  br label %bb17
bb17:
  %t55 = load i64, ptr %l34, !tbaa !24
  %t56 = load ptr, ptr %lp1
  %t57 = getelementptr %"compiler/profile:Profile", ptr %t56, i32 0, i32 1
  store i64 %t55, ptr %t57, !tbaa !24
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t60 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t58, i64 4)
  store i64 %t60, ptr %l36
  br label %bb18
bb18:
  %t61 = load i64, ptr %l36, !tbaa !24
  %t62 = load ptr, ptr %lp1
  %t63 = getelementptr %"compiler/profile:Profile", ptr %t62, i32 0, i32 2
  store i64 %t61, ptr %t63, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  %t66 = icmp slt i64 %t64, 0
  br i1 %t66, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb21
bb20:
  %t68 = load i64, ptr %l2, !tbaa !24
  %t70 = mul i64 %t68, 8
  %t72 = add i64 40, %t70
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t78 = icmp sgt i64 %t72, %t75
  store i1 %t78, ptr %l39, !tbaa !21
  br label %bb21
bb21:
  %t80 = load i1, ptr %l39, !tbaa !21
  br i1 %t80, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t82 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/profile:Profile" } %t82, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i64 0, ptr %l3, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t83 = load i64, ptr %l3, !tbaa !24
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb27:
  br label %bb28
bb28:
  %t91 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = add i64 5, %t92
  %t97 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t91, i64 %t94)
  store i64 %t97, ptr %l54
  br label %bb29
bb29:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l4, !tbaa !24
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = and i64 %t99, 255
  store i64 %t101, ptr %l5, !tbaa !24
  %t103 = load i64, ptr %l4, !tbaa !24
  %t105 = icmp eq i64 %t103, 0
  br i1 %t105, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb32
bb31:
  %t107 = load i64, ptr %l5, !tbaa !24
  %t109 = icmp eq i64 %t107, 0
  store i1 %t109, ptr %l59, !tbaa !21
  br label %bb32
bb32:
  %t111 = load i1, ptr %l59, !tbaa !21
  br i1 %t111, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb35
bb34:
  %t112 = load i64, ptr %l3, !tbaa !24
  %t114 = add i64 %t112, 1
  %t115 = load i64, ptr %l5, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t119 = load i64, ptr %l2, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  store i1 %t122, ptr %l62, !tbaa !21
  br label %bb35
bb35:
  %t124 = load i1, ptr %l62, !tbaa !21
  br i1 %t124, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb37:
  br label %bb38
bb38:
  %t125 = load i64, ptr %l4, !tbaa !24
  %t127 = icmp slt i64 %t125, 0
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = load i64, ptr %l3, !tbaa !24
  %t131 = load i64, ptr %l5, !tbaa !24
  %t133 = add i64 %t131, 1
  %t136 = add i64 %t129, %t133
  store i64 %t136, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb40:
  br label %bb41
bb41:
  %t138 = load ptr, ptr %lp1
  %t139 = getelementptr %"compiler/profile:Profile", ptr %t138, i32 0, i32 3
  store ptr %t139, ptr %l76, !tbaa !29
  %t140 = load i64, ptr %l4, !tbaa !24
  %t142 = ashr i64 %t140, 8
  store i64 %t142, ptr %l78, !tbaa !24
  %t143 = load ptr, ptr %lp1
  %t144 = getelementptr %"compiler/profile:Profile", ptr %t143, i32 0, i32 4
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t144)
  store i64 %t146, ptr %l80
  br label %bb42
bb42:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t148 = load i64, ptr %l78, !tbaa !24
  %t149 = load i64, ptr %l80, !tbaa !24
  %t151 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s3, i64 %t148, i64 %t149, i64 %t147)
  store %"compiler/profile:Sample" %t151, ptr %l82
  br label %bb43
bb43:
  %t152 = load ptr, ptr %l76, !tbaa !29
  %t153 = load %"compiler/profile:Sample", ptr %l82
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t152, %"compiler/profile:Sample" %t153)
  br label %bb44
bb44:
  store i64 0, ptr %l6, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  store i64 %t154, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t156 = load i64, ptr %l7, !tbaa !24
  %t157 = load i64, ptr %l6, !tbaa !24
  %t160 = icmp sgt i64 %t156, %t157
  br i1 %t160, label %bb45, label %bb46
bb45:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t164 = icmp sgt i64 %t162, 0
  br i1 %t164, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb50
bb47:
  %t166 = load i64, ptr %l7, !tbaa !24
  %t167 = load i64, ptr %l6, !tbaa !24
  %t170 = sub i64 %t166, %t167
  %t171 = load i64, ptr %l8, !tbaa !24
  %t174 = add i64 %t170, %t171
  %t176 = sub i64 %t174, 1
  %t177 = load i64, ptr %l8, !tbaa !24
  %t180 = sdiv i64 %t176, %t177
  store i64 %t180, ptr %l90, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb49
bb49:
  %t182 = load i64, ptr %l90, !tbaa !24
  store i64 %t182, ptr %l87, !tbaa !24
  br label %bb50
bb50:
  %t183 = load i64, ptr %l87, !tbaa !24
  store i64 %t183, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb51
bb51:
  %t184 = load i64, ptr %l10, !tbaa !24
  %t185 = load i64, ptr %l9, !tbaa !24
  %t188 = icmp slt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb52, label %bb53
bb52:
  br label %bb58
bb53:
  br label %bb54
bb54:
  %t192 = load i64, ptr %l6, !tbaa !24
  %t193 = load i64, ptr %l10, !tbaa !24
  %t194 = load i64, ptr %l8, !tbaa !24
  %t197 = mul i64 %t193, %t194
  %t200 = add i64 %t192, %t197
  %t202 = load ptr, ptr %lp1
  %t203 = getelementptr %"compiler/profile:Profile", ptr %t202, i32 0, i32 4
  store ptr %t203, ptr %l108, !tbaa !29
  %t204 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t205 = load i64, ptr %l3, !tbaa !24
  %t207 = add i64 5, %t205
  %t209 = add i64 %t207, 1
  %t213 = add i64 %t209, %t200
  %t216 = call i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %t204, i64 %t213)
  store i64 %t216, ptr %l115
  br label %bb55
bb55:
  %t217 = load ptr, ptr %l108, !tbaa !29
  %t218 = load i64, ptr %l115, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t217, i64 %t218)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t219 = load i64, ptr %l10, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l10, !tbaa !24
  br label %bb51
bb58:
  %t224 = load i64, ptr %l3, !tbaa !24
  %t226 = load i64, ptr %l5, !tbaa !24
  %t228 = add i64 %t226, 1
  %t231 = add i64 %t224, %t228
  store i64 %t231, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb59
bb59:
  br label %bb25
bb60:
  %t233 = call ptr @__olang_scope_hold(ptr %v1)
  %t234 = ptrtoint ptr %t233 to i64
  store i64 %t234, ptr %l124, !tbaa !24
  %t235 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aProfile_2e5
  br i1 %t235, label %bb61, label %bb62
bb61:
  %t237 = call ptr @__olang_region_make(ptr %v1)
  %t238 = ptrtoint ptr %t237 to i64
  store i64 %t238, ptr %l124, !tbaa !24
  br label %bb62
bb62:
  %t239 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t239, ptr %l126, !tbaa !27
  %t240 = load i64, ptr %l2, !tbaa !24
  %t242 = mul i64 %t240, 8
  %t244 = add i64 40, %t242
  store i64 %t244, ptr %l129, !tbaa !24
  %t245 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t245, 0
  store i64 %t248, ptr %l132, !tbaa !24
  %t249 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 0
  store i64 %t250, ptr %l133, !tbaa !24
  %t251 = load i64, ptr %l129, !tbaa !24
  %t252 = icmp sge i64 %t251, 0
  br i1 %t252, label %bb63, label %bb64
bb63:
  %t254 = load i64, ptr %l129, !tbaa !24
  %t255 = load i64, ptr %l132, !tbaa !24
  %t256 = icmp sle i64 %t254, %t255
  br i1 %t256, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_5e6251cd9155695d_6237c97633bfa1b9)
  unreachable
bb65:
  %t258 = load i64, ptr %l132, !tbaa !24
  %t259 = load i64, ptr %l133, !tbaa !24
  %t260 = icmp sle i64 %t258, %t259
  br i1 %t260, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_5e6251cd9155695d_6237c97633bfa1b9)
  unreachable
bb67:
  %t262 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = load i64, ptr %l129, !tbaa !24
  %t265 = load i64, ptr %l132, !tbaa !24
  %t266 = getelementptr i8, ptr %t263, i64 %t264
  %t267 = sub i64 %t265, %t264
  %t268 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t266, 1
  store { i64, ptr } %t269, ptr %l138, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l139, !tbaa !24
  %t273 = load i64, ptr %l139, !tbaa !24
  %t274 = mul i64 %t273, 1
  %t275 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l140, !tbaa !27
  %t278 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t279 = load ptr, ptr %t278, !tbaa !27
  %t280 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !27
  %t282 = load i64, ptr %l139, !tbaa !24
  %t283 = mul i64 %t282, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t279, ptr %t281, i64 %t283, i1 false)
  %t284 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t286 = load i64, ptr %l124
  %t287 = inttoptr i64 %t286 to ptr
  %t288 = extractvalue { i64, ptr } %t284, 0
  %t289 = extractvalue { i64, ptr } %t284, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_held_alloc(ptr %t287, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t294 = load ptr, ptr %lp1
  %t295 = getelementptr %"compiler/profile:Profile", ptr %t294, i32 0, i32 5
  %t296 = load { i64, ptr }, ptr %t295, !tbaa !27
  store { i64, ptr } %t296, ptr %l143, !tbaa !27
  %t298 = load ptr, ptr %lp1
  %t299 = getelementptr %"compiler/profile:Profile", ptr %t298, i32 0, i32 5
  store { i64, ptr } %t293, ptr %t299, !tbaa !27
  %t300 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aProfile_2e5
  br i1 %t300, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_5e6251cd9155695d_6237c97633bfa1b9)
  unreachable
bb69:
  %t302 = load { i64, ptr }, ptr %l143
  %t303 = extractvalue { i64, ptr } %t302, 1
  call void @__olang_region_release(ptr %t303)
  store { i64, ptr } zeroinitializer, ptr %l143
  br label %bb70
bb70:
  %t304 = load ptr, ptr %lp1
  %t305 = load %"compiler/profile:Profile", ptr %t304
  call void @__olang_scope_close(ptr %s0)
  %t307 = insertvalue { i32, %"compiler/profile:Profile" } zeroinitializer, %"compiler/profile:Profile" %t305, 1
  store { i32, %"compiler/profile:Profile" } %t307, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/profile:Profile" }, ptr %rv
  ret { i32, %"compiler/profile:Profile" } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l39 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i32
  %l101 = alloca i1
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i1, ptr %l13, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l18
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l19, !tbaa !24
  %t22 = load i64, ptr %l19, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l20, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = load i64, ptr %l19, !tbaa !24
  %t32 = mul i64 %t31, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t28, ptr %t30, i64 %t32, i1 false)
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t33, ptr %lp1
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = load ptr, ptr %lp1
  store { i64, ptr } %t34, ptr %t35, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l2, !tbaa !24
  store i64 %t36, ptr %l21, !tbaa !24
  %t37 = load ptr, ptr %lp1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l23, !tbaa !24
  %t41 = load ptr, ptr %lp1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  store i64 %t43, ptr %l24, !tbaa !24
  %t44 = load i64, ptr %l21, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load i64, ptr %l21, !tbaa !24
  %t48 = load i64, ptr %l23, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb9:
  %t51 = load i64, ptr %l23, !tbaa !24
  %t52 = load i64, ptr %l24, !tbaa !24
  %t53 = icmp sle i64 %t51, %t52
  br i1 %t53, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb11:
  %t55 = load ptr, ptr %lp1
  %t56 = getelementptr { i64, ptr }, ptr %t55, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = load i64, ptr %l21, !tbaa !24
  %t59 = load i64, ptr %l23, !tbaa !24
  %t60 = getelementptr i8, ptr %t57, i64 %t58
  %t61 = sub i64 %t59, %t58
  %t62 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t63, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t65, ptr %l29
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb13:
  %t66 = load i1, ptr %l29, !tbaa !21
  br i1 %t66, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb23
bb15:
  %t67 = load i64, ptr %l2, !tbaa !24
  store i64 %t67, ptr %l31, !tbaa !24
  %t68 = load ptr, ptr %lp1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t69, 0
  store i64 %t71, ptr %l33, !tbaa !24
  %t72 = load ptr, ptr %lp1
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l34, !tbaa !24
  %t75 = load i64, ptr %l31, !tbaa !24
  %t76 = icmp sge i64 %t75, 0
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t78 = load i64, ptr %l31, !tbaa !24
  %t79 = load i64, ptr %l33, !tbaa !24
  %t80 = icmp sle i64 %t78, %t79
  br i1 %t80, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb18:
  %t82 = load i64, ptr %l33, !tbaa !24
  %t83 = load i64, ptr %l34, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb20:
  %t86 = load ptr, ptr %lp1
  %t87 = getelementptr { i64, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l31, !tbaa !24
  %t90 = load i64, ptr %l33, !tbaa !24
  %t91 = getelementptr i8, ptr %t88, i64 %t89
  %t92 = sub i64 %t90, %t89
  %t93 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t96 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t94, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t96, ptr %l39
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb22:
  %t97 = load i1, ptr %l39, !tbaa !21
  store i1 %t97, ptr %l30, !tbaa !21
  br label %bb23
bb23:
  %t98 = load i1, ptr %l30, !tbaa !21
  %t99 = xor i1 %t98, true
  br i1 %t99, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb25:
  br label %bb26
bb26:
  %t101 = load i64, ptr %l2, !tbaa !24
  store i64 %t101, ptr %l41, !tbaa !24
  %t102 = load i64, ptr %l2, !tbaa !24
  store i64 %t102, ptr %l42, !tbaa !24
  %t103 = load ptr, ptr %lp1
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l44, !tbaa !24
  %t107 = load ptr, ptr %lp1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l45, !tbaa !24
  %t110 = load i64, ptr %l42, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb27, label %bb28
bb27:
  %t113 = load i64, ptr %l42, !tbaa !24
  %t114 = load i64, ptr %l44, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb29:
  %t117 = load i64, ptr %l44, !tbaa !24
  %t118 = load i64, ptr %l45, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  br i1 %t119, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb31:
  %t121 = load ptr, ptr %lp1
  %t122 = getelementptr { i64, ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l42, !tbaa !24
  %t125 = load i64, ptr %l44, !tbaa !24
  %t126 = getelementptr i8, ptr %t123, i64 %t124
  %t127 = sub i64 %t125, %t124
  %t128 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s3, { i64, ptr } %t129, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d59, i32 0, i32 1) })
  store i1 %t131, ptr %l50
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_3603727fe313055_49dd245dfeecf61)
  unreachable
bb33:
  %t132 = load i1, ptr %l50, !tbaa !21
  br i1 %t132, label %bb34, label %bb35
bb34:
  store i64 2, ptr %l51, !tbaa !24
  br label %bb36
bb35:
  store i64 3, ptr %l51, !tbaa !24
  br label %bb36
bb36:
  %t133 = load i64, ptr %l41, !tbaa !24
  %t134 = load i64, ptr %l51, !tbaa !24
  %t135 = add i64 %t133, %t134
  store i64 %t135, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  br label %bb6
bb38:
  %t137 = load i64, ptr %l2, !tbaa !24
  store i64 %t137, ptr %l54, !tbaa !24
  %t138 = load ptr, ptr %lp1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  store i64 %t141, ptr %l56, !tbaa !24
  %t142 = load ptr, ptr %lp1
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l57, !tbaa !24
  %t145 = load i64, ptr %l54, !tbaa !24
  %t146 = icmp sge i64 %t145, 0
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t148 = load i64, ptr %l54, !tbaa !24
  %t149 = load i64, ptr %l56, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb41:
  %t152 = load i64, ptr %l56, !tbaa !24
  %t153 = load i64, ptr %l57, !tbaa !24
  %t154 = icmp sle i64 %t152, %t153
  br i1 %t154, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb43:
  %t156 = load ptr, ptr %lp1
  %t157 = getelementptr { i64, ptr }, ptr %t156, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l54, !tbaa !24
  %t160 = load i64, ptr %l56, !tbaa !24
  %t161 = getelementptr i8, ptr %t158, i64 %t159
  %t162 = sub i64 %t160, %t159
  %t163 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  %t166 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t164, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) })
  %t167 = extractvalue { i32, i64 } %t166, 1
  %t168 = extractvalue { i32, i64 } %t166, 0
  store i32 %t168, ptr %l63
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb46, label %ok.170, !prof !99
ok.170:
  store i64 %t167, ptr %l62
  br label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e16765c4a8f41078_55e216e6a7163174)
  unreachable
bb45:
  %t171 = load i64, ptr %l62, !tbaa !24
  store i64 %t171, ptr %l53, !tbaa !24
  br label %bb48
bb46:
  br label %bb47
bb47:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb48
bb48:
  %t172 = load i64, ptr %l53, !tbaa !24
  store i64 %t172, ptr %l3, !tbaa !24
  %t173 = load i64, ptr %l3, !tbaa !24
  %t175 = icmp slt i64 %t173, 0
  br i1 %t175, label %bb49, label %bb50
bb49:
  %t177 = load ptr, ptr %lp1
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l66, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l67, !tbaa !24
  %t181 = load i64, ptr %l67, !tbaa !24
  %t182 = mul i64 %t181, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l68, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l67, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  %t192 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t192, ptr %l66, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t193 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t193, ptr %rv
  br label %ret
bb50:
  br label %bb51
bb51:
  %t194 = load i64, ptr %l2, !tbaa !24
  %t195 = load i64, ptr %l3, !tbaa !24
  %t198 = add i64 %t194, %t195
  store i64 %t198, ptr %l4, !tbaa !24
  %t200 = load i64, ptr %l4, !tbaa !24
  %t202 = add i64 %t200, 1
  store i64 %t202, ptr %l73, !tbaa !24
  %t203 = load ptr, ptr %lp1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l75, !tbaa !24
  %t207 = load ptr, ptr %lp1
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 0
  store i64 %t209, ptr %l76, !tbaa !24
  %t210 = load i64, ptr %l73, !tbaa !24
  %t211 = icmp sge i64 %t210, 0
  br i1 %t211, label %bb52, label %bb53
bb52:
  %t213 = load i64, ptr %l73, !tbaa !24
  %t214 = load i64, ptr %l75, !tbaa !24
  %t215 = icmp sle i64 %t213, %t214
  br i1 %t215, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb54:
  %t217 = load i64, ptr %l75, !tbaa !24
  %t218 = load i64, ptr %l76, !tbaa !24
  %t219 = icmp sle i64 %t217, %t218
  br i1 %t219, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb56:
  %t221 = load ptr, ptr %lp1
  %t222 = getelementptr { i64, ptr }, ptr %t221, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = load i64, ptr %l73, !tbaa !24
  %t225 = load i64, ptr %l75, !tbaa !24
  %t226 = getelementptr i8, ptr %t223, i64 %t224
  %t227 = sub i64 %t225, %t224
  %t228 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t226, 1
  store { i64, ptr } %t229, ptr %l5, !tbaa !27
  %t231 = load i64, ptr %l4, !tbaa !24
  store i64 %t231, ptr %l81, !tbaa !24
  %t232 = load ptr, ptr %lp1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  store i64 %t234, ptr %l82, !tbaa !24
  %t235 = icmp sge i64 0, 0
  br i1 %t235, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f)
  unreachable
bb58:
  %t237 = load i64, ptr %l81, !tbaa !24
  %t238 = icmp sle i64 0, %t237
  br i1 %t238, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb60:
  %t240 = load i64, ptr %l81, !tbaa !24
  %t241 = load i64, ptr %l82, !tbaa !24
  %t242 = icmp sle i64 %t240, %t241
  br i1 %t242, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb62:
  %t244 = load ptr, ptr %lp1
  %t245 = getelementptr { i64, ptr }, ptr %t244, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = load i64, ptr %l81, !tbaa !24
  %t248 = getelementptr i8, ptr %t246, i64 0
  %t249 = sub i64 %t247, 0
  %t250 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t248, 1
  %t255 = call { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v1, ptr %s0, { i64, ptr } %t251)
  store { i64, ptr } %t255, ptr %l88
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_efed15e4a0150676_49528d4cd386b8e2)
  unreachable
bb64:
  %t256 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t256, ptr %l7, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t259 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t257, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d61, i32 0, i32 1) })
  %t260 = extractvalue { i32, i64 } %t259, 1
  %t261 = extractvalue { i32, i64 } %t259, 0
  store i32 %t261, ptr %l92
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb66, label %ok.263, !prof !99
ok.263:
  store i64 %t260, ptr %l91
  br label %bb65
bb65:
  %t264 = load i64, ptr %l91, !tbaa !24
  store i64 %t264, ptr %l89, !tbaa !24
  br label %bb68
bb66:
  br label %bb67
bb67:
  store i64 -1, ptr %l89, !tbaa !24
  br label %bb68
bb68:
  %t265 = load i64, ptr %l89, !tbaa !24
  store i64 %t265, ptr %l8, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t268 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t266, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) })
  %t269 = extractvalue { i32, i64 } %t268, 1
  %t270 = extractvalue { i32, i64 } %t268, 0
  store i32 %t270, ptr %l96
  %t271 = icmp ne i32 %t270, 0
  br i1 %t271, label %bb70, label %ok.272, !prof !99
ok.272:
  store i64 %t269, ptr %l95
  br label %bb69
bb69:
  %t273 = load i64, ptr %l95, !tbaa !24
  store i64 %t273, ptr %l93, !tbaa !24
  br label %bb72
bb70:
  br label %bb71
bb71:
  %t274 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t274, 0
  store i64 %t276, ptr %l93, !tbaa !24
  br label %bb72
bb72:
  %t278 = load i64, ptr %l93, !tbaa !24
  store i64 %t278, ptr %l9, !tbaa !24
  %t279 = load i64, ptr %l8, !tbaa !24
  %t281 = icmp sge i64 %t279, 0
  br i1 %t281, label %bb73, label %bb74
bb73:
  %t283 = load i64, ptr %l8, !tbaa !24
  %t284 = load i64, ptr %l9, !tbaa !24
  %t287 = icmp slt i64 %t283, %t284
  store i1 %t287, ptr %l101, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb75
bb75:
  %t289 = load i1, ptr %l101, !tbaa !21
  br i1 %t289, label %bb76, label %bb77
bb76:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l105, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t291 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t291, ptr %l107, !tbaa !27
  store { i64, ptr } %t290, ptr %l7, !tbaa !27
  %t293 = load i1, ptr @olang_2esole_2ecompiler__2fprofile__2eReadable_2elocal_2e7
  br i1 %t293, label %bb78, label %bb79
bb77:
  br label %bb80
bb78:
  %t295 = load { i64, ptr }, ptr %l107
  %t296 = extractvalue { i64, ptr } %t295, 1
  call void @__olang_region_release(ptr %t296)
  store { i64, ptr } zeroinitializer, ptr %l107
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t297 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t297, ptr %l109, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t300 = call { i64, ptr } @compiler_2fprofile_2etypesRead(ptr %v1, ptr %s0, { i64, ptr } %t298)
  store { i64, ptr } %t300, ptr %l111
  br label %bb81
bb81:
  %t301 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t301, 1
  %t303 = extractvalue { i64, ptr } %t301, 0
  %t304 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 1
  %t306 = extractvalue { i64, ptr } %t304, 0
  %t307 = add i64 %t303, %t306
  %t308 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t302, i64 %t303)
  %t309 = getelementptr i8, ptr %t308, i64 %t303
  call void @olang_textcopy(ptr %t309, ptr %t305, i64 %t306)
  %t310 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t308, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t311, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/profile:Tally"
  %l4 = alloca i64
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l6 = alloca double
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l44 = alloca %"compiler/profile:Tally"
  %l46 = alloca i64
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l59 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca i64
  %l67 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca %"compiler/profile:Tally"
  %l95 = alloca %"compiler/profile:Tally"
  %l96 = alloca i64
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l104 = alloca i64
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca { i64, ptr }
  %l112 = alloca i64
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %l120 = alloca i64
  %l122 = alloca { i64, ptr }
  %l123 = alloca i64
  %l124 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l136 = alloca i64
  %l138 = alloca { i64, ptr }
  %l139 = alloca i64
  %l140 = alloca { i64, ptr }
  %l144 = alloca i64
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca { i64, ptr }
  %l152 = alloca i64
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %l160 = alloca i64
  %l162 = alloca { i64, ptr }
  %l163 = alloca i64
  %l164 = alloca { i64, ptr }
  %l168 = alloca i64
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca { i64, ptr }
  %l176 = alloca i64
  %l178 = alloca { i64, ptr }
  %l179 = alloca i64
  %l180 = alloca { i64, ptr }
  %l184 = alloca i64
  %l186 = alloca { i64, ptr }
  %l187 = alloca i64
  %l188 = alloca { i64, ptr }
  %l192 = alloca i64
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %l200 = alloca i64
  %l202 = alloca { i64, ptr }
  %l203 = alloca i64
  %l204 = alloca { i64, ptr }
  %l208 = alloca i64
  %l210 = alloca { i64, ptr }
  %l211 = alloca i64
  %l212 = alloca { i64, ptr }
  %l216 = alloca i64
  %l218 = alloca { i64, ptr }
  %l219 = alloca i64
  %l220 = alloca { i64, ptr }
  %l224 = alloca i64
  %l226 = alloca { i64, ptr }
  %l227 = alloca i64
  %l228 = alloca { i64, ptr }
  %l236 = alloca i64
  %l238 = alloca i64
  %l243 = alloca i64
  %l244 = alloca i64
  %l247 = alloca i64
  %l248 = alloca i32
  %l251 = alloca i1
  %l256 = alloca i64
  %l259 = alloca i64
  %l260 = alloca i32
  %l261 = alloca ptr
  %l264 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l275 = alloca { i64, ptr }
  %l285 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l286 = alloca i64
  %l288 = alloca { i64, ptr }
  %l289 = alloca i64
  %l290 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l295 = alloca %"compiler/profile:Tally"
  %l296 = alloca %"compiler/profile:Tally"
  %l297 = alloca i64
  %l299 = alloca { i64, ptr }
  %l300 = alloca i64
  %l301 = alloca { i64, ptr }
  %l305 = alloca i64
  %l307 = alloca { i64, ptr }
  %l308 = alloca i64
  %l309 = alloca { i64, ptr }
  %l313 = alloca i64
  %l315 = alloca { i64, ptr }
  %l316 = alloca i64
  %l317 = alloca { i64, ptr }
  %l321 = alloca i64
  %l323 = alloca { i64, ptr }
  %l324 = alloca i64
  %l325 = alloca { i64, ptr }
  %l329 = alloca i64
  %l331 = alloca { i64, ptr }
  %l332 = alloca i64
  %l333 = alloca { i64, ptr }
  %l337 = alloca i64
  %l339 = alloca { i64, ptr }
  %l340 = alloca i64
  %l341 = alloca { i64, ptr }
  %l345 = alloca i64
  %l347 = alloca { i64, ptr }
  %l348 = alloca i64
  %l349 = alloca { i64, ptr }
  %l353 = alloca i64
  %l355 = alloca { i64, ptr }
  %l356 = alloca i64
  %l357 = alloca { i64, ptr }
  %l361 = alloca i64
  %l363 = alloca { i64, ptr }
  %l364 = alloca i64
  %l365 = alloca { i64, ptr }
  %l369 = alloca i64
  %l371 = alloca { i64, ptr }
  %l372 = alloca i64
  %l373 = alloca { i64, ptr }
  %l377 = alloca i64
  %l379 = alloca { i64, ptr }
  %l380 = alloca i64
  %l381 = alloca { i64, ptr }
  %l385 = alloca i64
  %l387 = alloca { i64, ptr }
  %l388 = alloca i64
  %l389 = alloca { i64, ptr }
  %l393 = alloca i64
  %l395 = alloca { i64, ptr }
  %l396 = alloca i64
  %l397 = alloca { i64, ptr }
  %l401 = alloca i64
  %l403 = alloca { i64, ptr }
  %l404 = alloca i64
  %l405 = alloca { i64, ptr }
  %l409 = alloca i64
  %l411 = alloca { i64, ptr }
  %l412 = alloca i64
  %l413 = alloca { i64, ptr }
  %l417 = alloca i64
  %l419 = alloca { i64, ptr }
  %l420 = alloca i64
  %l421 = alloca { i64, ptr }
  %l425 = alloca i64
  %l427 = alloca { i64, ptr }
  %l428 = alloca i64
  %l429 = alloca { i64, ptr }
  %l435 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l437 = alloca i64
  %l439 = alloca i64
  %l444 = alloca i64
  %l445 = alloca i64
  %l448 = alloca i64
  %l449 = alloca i32
  %l451 = alloca i64
  %l453 = alloca i1
  %l461 = alloca { i64, ptr }
  %l462 = alloca i1
  %l469 = alloca i64
  %l471 = alloca i64
  %l476 = alloca i64
  %l480 = alloca { i64, ptr }
  %l481 = alloca { i64, ptr }
  %l482 = alloca i64
  %l483 = alloca { i64, ptr }
  %l490 = alloca { i64, ptr }
  %l491 = alloca { i64, ptr }
  %l492 = alloca i64
  %l493 = alloca { i64, ptr }
  %l498 = alloca ptr
  %l500 = alloca { i64, ptr }
  %l504 = alloca i64
  %l506 = alloca i64
  %l511 = alloca i64
  %l512 = alloca i64
  %l515 = alloca i64
  %l516 = alloca i32
  %l517 = alloca i64
  %l520 = alloca i64
  %l521 = alloca i32
  %l522 = alloca ptr
  %l525 = alloca { i64, ptr }
  %l527 = alloca { i64, ptr }
  %l531 = alloca { i64, ptr }
  %l532 = alloca { i64, ptr }
  %l533 = alloca i64
  %l534 = alloca { i64, ptr }
  %l537 = alloca { i64, ptr }
  %l541 = alloca { i64, ptr }
  %l549 = alloca i64
  %l551 = alloca i64
  %l556 = alloca i64
  %l559 = alloca i64
  %l562 = alloca i64
  %l563 = alloca i32
  %l569 = alloca i64
  %l572 = alloca i64
  %l573 = alloca i32
  %l574 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l576 = alloca i64
  %l578 = alloca i64
  %l583 = alloca i64
  %l589 = alloca i1
  %l595 = alloca ptr
  %l596 = alloca %"compiler/profile:Tally"
  %l597 = alloca %"compiler/profile:Tally"
  %l598 = alloca i64
  %l600 = alloca { i64, ptr }
  %l601 = alloca i64
  %l602 = alloca { i64, ptr }
  %l606 = alloca i64
  %l608 = alloca { i64, ptr }
  %l609 = alloca i64
  %l610 = alloca { i64, ptr }
  %l614 = alloca i64
  %l616 = alloca { i64, ptr }
  %l617 = alloca i64
  %l618 = alloca { i64, ptr }
  %l622 = alloca i64
  %l624 = alloca { i64, ptr }
  %l625 = alloca i64
  %l626 = alloca { i64, ptr }
  %l630 = alloca i64
  %l632 = alloca { i64, ptr }
  %l633 = alloca i64
  %l634 = alloca { i64, ptr }
  %l638 = alloca i64
  %l640 = alloca { i64, ptr }
  %l641 = alloca i64
  %l642 = alloca { i64, ptr }
  %l646 = alloca i64
  %l648 = alloca { i64, ptr }
  %l649 = alloca i64
  %l650 = alloca { i64, ptr }
  %l654 = alloca i64
  %l656 = alloca { i64, ptr }
  %l657 = alloca i64
  %l658 = alloca { i64, ptr }
  %l662 = alloca i64
  %l664 = alloca { i64, ptr }
  %l665 = alloca i64
  %l666 = alloca { i64, ptr }
  %l670 = alloca i64
  %l672 = alloca { i64, ptr }
  %l673 = alloca i64
  %l674 = alloca { i64, ptr }
  %l678 = alloca i64
  %l680 = alloca { i64, ptr }
  %l681 = alloca i64
  %l682 = alloca { i64, ptr }
  %l686 = alloca i64
  %l688 = alloca { i64, ptr }
  %l689 = alloca i64
  %l690 = alloca { i64, ptr }
  %l694 = alloca i64
  %l696 = alloca { i64, ptr }
  %l697 = alloca i64
  %l698 = alloca { i64, ptr }
  %l702 = alloca i64
  %l704 = alloca { i64, ptr }
  %l705 = alloca i64
  %l706 = alloca { i64, ptr }
  %l710 = alloca i64
  %l712 = alloca { i64, ptr }
  %l713 = alloca i64
  %l714 = alloca { i64, ptr }
  %l718 = alloca i64
  %l720 = alloca { i64, ptr }
  %l721 = alloca i64
  %l722 = alloca { i64, ptr }
  %l726 = alloca i64
  %l728 = alloca { i64, ptr }
  %l729 = alloca i64
  %l730 = alloca { i64, ptr }
  %l737 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l739 = alloca i64
  %l741 = alloca i64
  %l746 = alloca i64
  %l748 = alloca i64
  %l750 = alloca ptr
  %l751 = alloca i64
  %l756 = alloca { i64, ptr }
  %l757 = alloca i64
  %l763 = alloca i64
  %l764 = alloca i32
  %l766 = alloca { i64, ptr }
  %l772 = alloca ptr
  %l776 = alloca { i64, ptr }
  %l778 = alloca i64
  %l780 = alloca { i64, ptr }
  %l782 = alloca { i64, ptr }
  %l790 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t3 = alloca %"compiler/profile:Tally", align 8
  %t969 = alloca { %"compiler/profile:Tally", ptr, ptr, ptr }, align 8
  %t1952 = alloca { %"compiler/profile:Tally", ptr, ptr, ptr }, align 8
  %t3147 = alloca { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, align 8
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fprofile_2eTally_2eTallied(ptr %t3, ptr %v1, ptr %v2, ptr %s0, ptr %t1, ptr %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %t3, i64 424, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l44, i64 424, i1 false)
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l46
  br label %bb2
bb2:
  %t9 = load i64, ptr %l46, !tbaa !24
  store i64 %t9, ptr %l4, !tbaa !24
  %t10 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t10, ptr %l47
  br label %bb3
bb3:
  %t11 = load %"std/prelude/text:StringBuilder", ptr %l47
  store %"std/prelude/text:StringBuilder" %t11, ptr %l5
  %t12 = load i64, ptr %l4, !tbaa !24
  %t14 = sitofp i64 %t12 to double
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/profile:Profile", ptr %t15, i32 0, i32 0
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = sitofp i64 %t18 to double
  %t23 = fmul double %t14, %t20
  %t25 = fdiv double %t23, 0x41cdcd6500000000
  store double %t25, ptr %l6, !tbaa !26
  store ptr %l5, ptr %l55, !tbaa !29
  store { i64, ptr } %a0, ptr %l56, !tbaa !27
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/profile:Profile", ptr %t28, i32 0, i32 3
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v1, ptr %t30)
  store i64 %t32, ptr %l59
  br label %bb4
bb4:
  %t33 = load double, ptr %l6, !tbaa !26
  %t35 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t33, i64 3)
  store { i64, ptr } %t35, ptr %l61
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t38 = getelementptr %"compiler/profile:Profile", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  store i64 %t39, ptr %l63, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/profile:Profile", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t45 = icmp eq i64 %t43, 1
  br i1 %t45, label %bb6, label %bb7
bb6:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb8
bb7:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l67, !tbaa !27
  br label %bb8
bb8:
  %t47 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t49 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = load i64, ptr %l59, !tbaa !24
  %t57 = call i64 @__olang_fmt_i64(ptr null, i64 %t56)
  %t58 = add i64 %t55, %t57
  %t59 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = add i64 %t61, %t64
  %t66 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t69 = load i64, ptr %l63, !tbaa !24
  %t70 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t71 = add i64 %t68, %t70
  %t72 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t47, i64 %t48)
  %t80 = getelementptr i8, ptr %t79, i64 %t48
  call void @olang_textcopy(ptr %t80, ptr %t50, i64 %t51)
  %t81 = getelementptr i8, ptr %t80, i64 %t51
  call void @olang_textcopy(ptr %t81, ptr %t53, i64 %t54)
  %t82 = getelementptr i8, ptr %t81, i64 %t54
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t56)
  %t84 = getelementptr i8, ptr %t82, i64 %t57
  call void @olang_textcopy(ptr %t84, ptr %t59, i64 %t60)
  %t85 = getelementptr i8, ptr %t84, i64 %t60
  call void @olang_textcopy(ptr %t85, ptr %t63, i64 %t64)
  %t86 = getelementptr i8, ptr %t85, i64 %t64
  call void @olang_textcopy(ptr %t86, ptr %t66, i64 %t67)
  %t87 = getelementptr i8, ptr %t86, i64 %t67
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t69)
  %t89 = getelementptr i8, ptr %t87, i64 %t70
  call void @olang_textcopy(ptr %t89, ptr %t73, i64 %t74)
  %t90 = getelementptr i8, ptr %t89, i64 %t74
  call void @olang_textcopy(ptr %t90, ptr %t76, i64 %t77)
  %t91 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t79, 1
  %t94 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t94, { i64, ptr } %t92)
  br label %bb9
bb9:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/profile:Profile", ptr %t96, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/profile:Profile", ptr %t103, i32 0, i32 1
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t110 = call i64 @__olang_fmt_i64(ptr null, i64 %t106)
  %t111 = add i64 %t108, %t110
  %t112 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t114 = add i64 %t111, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t107, i64 %t108)
  %t116 = getelementptr i8, ptr %t115, i64 %t108
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t106)
  %t118 = getelementptr i8, ptr %t116, i64 %t110
  call void @olang_textcopy(ptr %t118, ptr %t112, i64 %t113)
  %t119 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t115, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l5, { i64, ptr } %t120)
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t124 = load i64, ptr %l4, !tbaa !24
  %t126 = icmp eq i64 %t124, 0
  br i1 %t126, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l5, { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t130 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l5)
  store { i64, ptr } %t130, ptr %l82
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t131 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t131, ptr %rv
  br label %ret
bb18:
  %t132 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 5
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t132
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l84
  %t135 = call ptr @__olang_scope_hold(ptr %s0)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l85, !tbaa !24
  %t137 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t137, label %bb19, label %bb20
bb19:
  %t139 = call ptr @__olang_region_make_part(ptr %s0)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l85, !tbaa !24
  br label %bb20
bb20:
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l87, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 0
  store i64 %t144, ptr %l88, !tbaa !24
  %t145 = load i64, ptr %l88, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = load i64, ptr %l85
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l89, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l88, !tbaa !24
  %t157 = mul i64 %t156, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  store { i64, ptr } %t158, ptr %t159, !tbaa !27
  %t160 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t160, label %bb21, label %bb22
bb21:
  %t162 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  %t166 = icmp eq i64 %t164, 0
  br i1 %t166, label %bb23, label %bb24
bb22:
  %t168 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t168, ptr %l7
  store ptr %l7, ptr %l93, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %l3, i64 424, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l95, ptr %l94, i64 424, i1 false)
  %t169 = call ptr @__olang_scope_hold(ptr %s0)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l96, !tbaa !24
  %t171 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t171, label %bb25, label %bb26
bb23:
  %t173 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t173, !tbaa !27
  br label %bb24
bb24:
  %t174 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84, i32 0, i32 0
  %t175 = load i64, ptr %l85
  %t176 = inttoptr i64 %t175 to ptr
  %t177 = load { i64, ptr }, ptr %t174
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = call ptr @__olang_region_or(ptr %t178, ptr null)
  %t180 = icmp ne ptr %t179, null
  %t181 = select i1 %t180, ptr %t179, ptr null
  call void @__olang_region_settle_in(ptr %t176, ptr %t181)
  br label %bb22
bb25:
  %t182 = call ptr @__olang_region_make_part(ptr %s0)
  %t183 = ptrtoint ptr %t182 to i64
  store i64 %t183, ptr %l96, !tbaa !24
  br label %bb26
bb26:
  %t184 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t185 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t184, i32 0, i32 0
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  store { i64, ptr } %t186, ptr %l98, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l99, !tbaa !24
  %t189 = load i64, ptr %l99, !tbaa !24
  %t190 = mul i64 %t189, 16
  %t191 = load i64, ptr %l96
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call ptr @__olang_held_alloc(ptr %t192, i64 %t190)
  %t194 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  store { i64, ptr } %t195, ptr %l100, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = load i64, ptr %l99, !tbaa !24
  %t201 = mul i64 %t200, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t197, ptr %t199, i64 %t201, i1 false)
  %t202 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t203 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t204 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t203, i32 0, i32 0
  store { i64, ptr } %t202, ptr %t204, !tbaa !27
  %t205 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t205, label %bb27, label %bb28
bb27:
  %t207 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t208 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t207, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t212 = icmp eq i64 %t210, 0
  br i1 %t212, label %bb29, label %bb30
bb28:
  %t214 = call ptr @__olang_scope_hold(ptr %s0)
  %t215 = ptrtoint ptr %t214 to i64
  store i64 %t215, ptr %l104, !tbaa !24
  %t216 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t216, label %bb31, label %bb32
bb29:
  %t218 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t219 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t218, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t219, !tbaa !27
  br label %bb30
bb30:
  %t220 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t221 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t220, i32 0, i32 0
  %t222 = load i64, ptr %l96
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = load { i64, ptr }, ptr %t221
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = call ptr @__olang_region_or(ptr %t225, ptr null)
  %t227 = icmp ne ptr %t226, null
  %t228 = select i1 %t227, ptr %t226, ptr null
  call void @__olang_region_settle_in(ptr %t223, ptr %t228)
  br label %bb28
bb31:
  %t229 = call ptr @__olang_region_make_part(ptr %s0)
  %t230 = ptrtoint ptr %t229 to i64
  store i64 %t230, ptr %l104, !tbaa !24
  br label %bb32
bb32:
  %t231 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l106, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  store i64 %t235, ptr %l107, !tbaa !24
  %t236 = load i64, ptr %l107, !tbaa !24
  %t237 = mul i64 %t236, 8
  %t238 = load i64, ptr %l104
  %t239 = inttoptr i64 %t238 to ptr
  %t240 = call ptr @__olang_held_alloc(ptr %t239, i64 %t237)
  %t241 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l108, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = load i64, ptr %l107, !tbaa !24
  %t248 = mul i64 %t247, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t244, ptr %t246, i64 %t248, i1 false)
  %t249 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t250 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t251 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t250, i32 0, i32 1
  store { i64, ptr } %t249, ptr %t251, !tbaa !27
  %t252 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t252, label %bb33, label %bb34
bb33:
  %t254 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t255 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t254, i32 0, i32 1
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 0
  %t259 = icmp eq i64 %t257, 0
  br i1 %t259, label %bb35, label %bb36
bb34:
  %t261 = call ptr @__olang_scope_hold(ptr %s0)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l112, !tbaa !24
  %t263 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t263, label %bb37, label %bb38
bb35:
  %t265 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t266 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t265, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t266, !tbaa !27
  br label %bb36
bb36:
  %t267 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t268 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t267, i32 0, i32 1
  %t269 = load i64, ptr %l104
  %t270 = inttoptr i64 %t269 to ptr
  %t271 = load { i64, ptr }, ptr %t268
  %t272 = extractvalue { i64, ptr } %t271, 1
  %t273 = call ptr @__olang_region_or(ptr %t272, ptr null)
  %t274 = icmp ne ptr %t273, null
  %t275 = select i1 %t274, ptr %t273, ptr null
  call void @__olang_region_settle_in(ptr %t270, ptr %t275)
  br label %bb34
bb37:
  %t276 = call ptr @__olang_region_make_part(ptr %s0)
  %t277 = ptrtoint ptr %t276 to i64
  store i64 %t277, ptr %l112, !tbaa !24
  br label %bb38
bb38:
  %t278 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t279 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t278, i32 0, i32 2
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l114, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t281, 0
  store i64 %t282, ptr %l115, !tbaa !24
  %t283 = load i64, ptr %l115, !tbaa !24
  %t284 = mul i64 %t283, 8
  %t285 = load i64, ptr %l112
  %t286 = inttoptr i64 %t285 to ptr
  %t287 = call ptr @__olang_held_alloc(ptr %t286, i64 %t284)
  %t288 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  store { i64, ptr } %t289, ptr %l116, !tbaa !27
  %t290 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = load i64, ptr %l115, !tbaa !24
  %t295 = mul i64 %t294, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t291, ptr %t293, i64 %t295, i1 false)
  %t296 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t297 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t298 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t297, i32 0, i32 2
  store { i64, ptr } %t296, ptr %t298, !tbaa !27
  %t299 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t299, label %bb39, label %bb40
bb39:
  %t301 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t302 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t301, i32 0, i32 2
  %t303 = load { i64, ptr }, ptr %t302, !tbaa !27
  %t304 = extractvalue { i64, ptr } %t303, 0
  %t306 = icmp eq i64 %t304, 0
  br i1 %t306, label %bb41, label %bb42
bb40:
  %t308 = call ptr @__olang_scope_hold(ptr %s0)
  %t309 = ptrtoint ptr %t308 to i64
  store i64 %t309, ptr %l120, !tbaa !24
  %t310 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t310, label %bb43, label %bb44
bb41:
  %t312 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t313 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t312, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t313, !tbaa !27
  br label %bb42
bb42:
  %t314 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 0
  %t315 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t314, i32 0, i32 2
  %t316 = load i64, ptr %l112
  %t317 = inttoptr i64 %t316 to ptr
  %t318 = load { i64, ptr }, ptr %t315
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = call ptr @__olang_region_or(ptr %t319, ptr null)
  %t321 = icmp ne ptr %t320, null
  %t322 = select i1 %t321, ptr %t320, ptr null
  call void @__olang_region_settle_in(ptr %t317, ptr %t322)
  br label %bb40
bb43:
  %t323 = call ptr @__olang_region_make_part(ptr %s0)
  %t324 = ptrtoint ptr %t323 to i64
  store i64 %t324, ptr %l120, !tbaa !24
  br label %bb44
bb44:
  %t325 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t326 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t325, i32 0, i32 0
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  store { i64, ptr } %t327, ptr %l122, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 0
  store i64 %t329, ptr %l123, !tbaa !24
  %t330 = load i64, ptr %l123, !tbaa !24
  %t331 = mul i64 %t330, 16
  %t332 = load i64, ptr %l120
  %t333 = inttoptr i64 %t332 to ptr
  %t334 = call ptr @__olang_held_alloc(ptr %t333, i64 %t331)
  %t335 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  store { i64, ptr } %t336, ptr %l124, !tbaa !27
  %t337 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t338 = load ptr, ptr %t337, !tbaa !27
  %t339 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = load i64, ptr %l123, !tbaa !24
  %t342 = mul i64 %t341, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t338, ptr %t340, i64 %t342, i1 false)
  %t343 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t344 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t345 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t344, i32 0, i32 0
  store { i64, ptr } %t343, ptr %t345, !tbaa !27
  %t346 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t346, label %bb45, label %bb46
bb45:
  %t348 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t349 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t348, i32 0, i32 0
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 0
  %t353 = icmp eq i64 %t351, 0
  br i1 %t353, label %bb47, label %bb48
bb46:
  %t355 = call ptr @__olang_scope_hold(ptr %s0)
  %t356 = ptrtoint ptr %t355 to i64
  store i64 %t356, ptr %l128, !tbaa !24
  %t357 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t357, label %bb49, label %bb50
bb47:
  %t359 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t360 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t359, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t360, !tbaa !27
  br label %bb48
bb48:
  %t361 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t362 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t361, i32 0, i32 0
  %t363 = load i64, ptr %l120
  %t364 = inttoptr i64 %t363 to ptr
  %t365 = load { i64, ptr }, ptr %t362
  %t366 = extractvalue { i64, ptr } %t365, 1
  %t367 = call ptr @__olang_region_or(ptr %t366, ptr null)
  %t368 = icmp ne ptr %t367, null
  %t369 = select i1 %t368, ptr %t367, ptr null
  call void @__olang_region_settle_in(ptr %t364, ptr %t369)
  br label %bb46
bb49:
  %t370 = call ptr @__olang_region_make_part(ptr %s0)
  %t371 = ptrtoint ptr %t370 to i64
  store i64 %t371, ptr %l128, !tbaa !24
  br label %bb50
bb50:
  %t372 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t373 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t372, i32 0, i32 1
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, ptr } %t374, ptr %l130, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 0
  store i64 %t376, ptr %l131, !tbaa !24
  %t377 = load i64, ptr %l131, !tbaa !24
  %t378 = mul i64 %t377, 8
  %t379 = load i64, ptr %l128
  %t380 = inttoptr i64 %t379 to ptr
  %t381 = call ptr @__olang_held_alloc(ptr %t380, i64 %t378)
  %t382 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t383 = insertvalue { i64, ptr } %t382, ptr %t381, 1
  store { i64, ptr } %t383, ptr %l132, !tbaa !27
  %t384 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !27
  %t388 = load i64, ptr %l131, !tbaa !24
  %t389 = mul i64 %t388, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t385, ptr %t387, i64 %t389, i1 false)
  %t390 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t391 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t392 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t391, i32 0, i32 1
  store { i64, ptr } %t390, ptr %t392, !tbaa !27
  %t393 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t393, label %bb51, label %bb52
bb51:
  %t395 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t396 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t395, i32 0, i32 1
  %t397 = load { i64, ptr }, ptr %t396, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 0
  %t400 = icmp eq i64 %t398, 0
  br i1 %t400, label %bb53, label %bb54
bb52:
  %t402 = call ptr @__olang_scope_hold(ptr %s0)
  %t403 = ptrtoint ptr %t402 to i64
  store i64 %t403, ptr %l136, !tbaa !24
  %t404 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t404, label %bb55, label %bb56
bb53:
  %t406 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t407 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t406, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t407, !tbaa !27
  br label %bb54
bb54:
  %t408 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t409 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t408, i32 0, i32 1
  %t410 = load i64, ptr %l128
  %t411 = inttoptr i64 %t410 to ptr
  %t412 = load { i64, ptr }, ptr %t409
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = call ptr @__olang_region_or(ptr %t413, ptr null)
  %t415 = icmp ne ptr %t414, null
  %t416 = select i1 %t415, ptr %t414, ptr null
  call void @__olang_region_settle_in(ptr %t411, ptr %t416)
  br label %bb52
bb55:
  %t417 = call ptr @__olang_region_make_part(ptr %s0)
  %t418 = ptrtoint ptr %t417 to i64
  store i64 %t418, ptr %l136, !tbaa !24
  br label %bb56
bb56:
  %t419 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t420 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t419, i32 0, i32 2
  %t421 = load { i64, ptr }, ptr %t420, !tbaa !27
  store { i64, ptr } %t421, ptr %l138, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t423 = extractvalue { i64, ptr } %t422, 0
  store i64 %t423, ptr %l139, !tbaa !24
  %t424 = load i64, ptr %l139, !tbaa !24
  %t425 = mul i64 %t424, 8
  %t426 = load i64, ptr %l136
  %t427 = inttoptr i64 %t426 to ptr
  %t428 = call ptr @__olang_held_alloc(ptr %t427, i64 %t425)
  %t429 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  store { i64, ptr } %t430, ptr %l140, !tbaa !27
  %t431 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t434 = load ptr, ptr %t433, !tbaa !27
  %t435 = load i64, ptr %l139, !tbaa !24
  %t436 = mul i64 %t435, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t432, ptr %t434, i64 %t436, i1 false)
  %t437 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t438 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t439 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t438, i32 0, i32 2
  store { i64, ptr } %t437, ptr %t439, !tbaa !27
  %t440 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t440, label %bb57, label %bb58
bb57:
  %t442 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t443 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t442, i32 0, i32 2
  %t444 = load { i64, ptr }, ptr %t443, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  %t447 = icmp eq i64 %t445, 0
  br i1 %t447, label %bb59, label %bb60
bb58:
  %t449 = call ptr @__olang_scope_hold(ptr %s0)
  %t450 = ptrtoint ptr %t449 to i64
  store i64 %t450, ptr %l144, !tbaa !24
  %t451 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t451, label %bb61, label %bb62
bb59:
  %t453 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t454 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t453, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t454, !tbaa !27
  br label %bb60
bb60:
  %t455 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 1
  %t456 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t455, i32 0, i32 2
  %t457 = load i64, ptr %l136
  %t458 = inttoptr i64 %t457 to ptr
  %t459 = load { i64, ptr }, ptr %t456
  %t460 = extractvalue { i64, ptr } %t459, 1
  %t461 = call ptr @__olang_region_or(ptr %t460, ptr null)
  %t462 = icmp ne ptr %t461, null
  %t463 = select i1 %t462, ptr %t461, ptr null
  call void @__olang_region_settle_in(ptr %t458, ptr %t463)
  br label %bb58
bb61:
  %t464 = call ptr @__olang_region_make_part(ptr %s0)
  %t465 = ptrtoint ptr %t464 to i64
  store i64 %t465, ptr %l144, !tbaa !24
  br label %bb62
bb62:
  %t466 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t467 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t466, i32 0, i32 0
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  store { i64, ptr } %t468, ptr %l146, !tbaa !27
  %t469 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 0
  store i64 %t470, ptr %l147, !tbaa !24
  %t471 = load i64, ptr %l147, !tbaa !24
  %t472 = mul i64 %t471, 16
  %t473 = load i64, ptr %l144
  %t474 = inttoptr i64 %t473 to ptr
  %t475 = call ptr @__olang_held_alloc(ptr %t474, i64 %t472)
  %t476 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  store { i64, ptr } %t477, ptr %l148, !tbaa !27
  %t478 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = load i64, ptr %l147, !tbaa !24
  %t483 = mul i64 %t482, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t479, ptr %t481, i64 %t483, i1 false)
  %t484 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t485 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t486 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t485, i32 0, i32 0
  store { i64, ptr } %t484, ptr %t486, !tbaa !27
  %t487 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t487, label %bb63, label %bb64
bb63:
  %t489 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t490 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t489, i32 0, i32 0
  %t491 = load { i64, ptr }, ptr %t490, !tbaa !27
  %t492 = extractvalue { i64, ptr } %t491, 0
  %t494 = icmp eq i64 %t492, 0
  br i1 %t494, label %bb65, label %bb66
bb64:
  %t496 = call ptr @__olang_scope_hold(ptr %s0)
  %t497 = ptrtoint ptr %t496 to i64
  store i64 %t497, ptr %l152, !tbaa !24
  %t498 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t498, label %bb67, label %bb68
bb65:
  %t500 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t501 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t500, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t501, !tbaa !27
  br label %bb66
bb66:
  %t502 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t503 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t502, i32 0, i32 0
  %t504 = load i64, ptr %l144
  %t505 = inttoptr i64 %t504 to ptr
  %t506 = load { i64, ptr }, ptr %t503
  %t507 = extractvalue { i64, ptr } %t506, 1
  %t508 = call ptr @__olang_region_or(ptr %t507, ptr null)
  %t509 = icmp ne ptr %t508, null
  %t510 = select i1 %t509, ptr %t508, ptr null
  call void @__olang_region_settle_in(ptr %t505, ptr %t510)
  br label %bb64
bb67:
  %t511 = call ptr @__olang_region_make_part(ptr %s0)
  %t512 = ptrtoint ptr %t511 to i64
  store i64 %t512, ptr %l152, !tbaa !24
  br label %bb68
bb68:
  %t513 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t514 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t513, i32 0, i32 1
  %t515 = load { i64, ptr }, ptr %t514, !tbaa !27
  store { i64, ptr } %t515, ptr %l154, !tbaa !27
  %t516 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t517 = extractvalue { i64, ptr } %t516, 0
  store i64 %t517, ptr %l155, !tbaa !24
  %t518 = load i64, ptr %l155, !tbaa !24
  %t519 = mul i64 %t518, 8
  %t520 = load i64, ptr %l152
  %t521 = inttoptr i64 %t520 to ptr
  %t522 = call ptr @__olang_held_alloc(ptr %t521, i64 %t519)
  %t523 = insertvalue { i64, ptr } undef, i64 %t518, 0
  %t524 = insertvalue { i64, ptr } %t523, ptr %t522, 1
  store { i64, ptr } %t524, ptr %l156, !tbaa !27
  %t525 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t526 = load ptr, ptr %t525, !tbaa !27
  %t527 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = load i64, ptr %l155, !tbaa !24
  %t530 = mul i64 %t529, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t526, ptr %t528, i64 %t530, i1 false)
  %t531 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t532 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t533 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t532, i32 0, i32 1
  store { i64, ptr } %t531, ptr %t533, !tbaa !27
  %t534 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t534, label %bb69, label %bb70
bb69:
  %t536 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t537 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t536, i32 0, i32 1
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  %t539 = extractvalue { i64, ptr } %t538, 0
  %t541 = icmp eq i64 %t539, 0
  br i1 %t541, label %bb71, label %bb72
bb70:
  %t543 = call ptr @__olang_scope_hold(ptr %s0)
  %t544 = ptrtoint ptr %t543 to i64
  store i64 %t544, ptr %l160, !tbaa !24
  %t545 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t545, label %bb73, label %bb74
bb71:
  %t547 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t548 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t547, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t548, !tbaa !27
  br label %bb72
bb72:
  %t549 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t550 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t549, i32 0, i32 1
  %t551 = load i64, ptr %l152
  %t552 = inttoptr i64 %t551 to ptr
  %t553 = load { i64, ptr }, ptr %t550
  %t554 = extractvalue { i64, ptr } %t553, 1
  %t555 = call ptr @__olang_region_or(ptr %t554, ptr null)
  %t556 = icmp ne ptr %t555, null
  %t557 = select i1 %t556, ptr %t555, ptr null
  call void @__olang_region_settle_in(ptr %t552, ptr %t557)
  br label %bb70
bb73:
  %t558 = call ptr @__olang_region_make_part(ptr %s0)
  %t559 = ptrtoint ptr %t558 to i64
  store i64 %t559, ptr %l160, !tbaa !24
  br label %bb74
bb74:
  %t560 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t561 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t560, i32 0, i32 2
  %t562 = load { i64, ptr }, ptr %t561, !tbaa !27
  store { i64, ptr } %t562, ptr %l162, !tbaa !27
  %t563 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t563, 0
  store i64 %t564, ptr %l163, !tbaa !24
  %t565 = load i64, ptr %l163, !tbaa !24
  %t566 = mul i64 %t565, 8
  %t567 = load i64, ptr %l160
  %t568 = inttoptr i64 %t567 to ptr
  %t569 = call ptr @__olang_held_alloc(ptr %t568, i64 %t566)
  %t570 = insertvalue { i64, ptr } undef, i64 %t565, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  store { i64, ptr } %t571, ptr %l164, !tbaa !27
  %t572 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t573 = load ptr, ptr %t572, !tbaa !27
  %t574 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = load i64, ptr %l163, !tbaa !24
  %t577 = mul i64 %t576, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t573, ptr %t575, i64 %t577, i1 false)
  %t578 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t579 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t580 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t579, i32 0, i32 2
  store { i64, ptr } %t578, ptr %t580, !tbaa !27
  %t581 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t581, label %bb75, label %bb76
bb75:
  %t583 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t584 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t583, i32 0, i32 2
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t585, 0
  %t588 = icmp eq i64 %t586, 0
  br i1 %t588, label %bb77, label %bb78
bb76:
  %t590 = call ptr @__olang_scope_hold(ptr %s0)
  %t591 = ptrtoint ptr %t590 to i64
  store i64 %t591, ptr %l168, !tbaa !24
  %t592 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t592, label %bb79, label %bb80
bb77:
  %t594 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t595 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t594, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t595, !tbaa !27
  br label %bb78
bb78:
  %t596 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 2
  %t597 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t596, i32 0, i32 2
  %t598 = load i64, ptr %l160
  %t599 = inttoptr i64 %t598 to ptr
  %t600 = load { i64, ptr }, ptr %t597
  %t601 = extractvalue { i64, ptr } %t600, 1
  %t602 = call ptr @__olang_region_or(ptr %t601, ptr null)
  %t603 = icmp ne ptr %t602, null
  %t604 = select i1 %t603, ptr %t602, ptr null
  call void @__olang_region_settle_in(ptr %t599, ptr %t604)
  br label %bb76
bb79:
  %t605 = call ptr @__olang_region_make_part(ptr %s0)
  %t606 = ptrtoint ptr %t605 to i64
  store i64 %t606, ptr %l168, !tbaa !24
  br label %bb80
bb80:
  %t607 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t608 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t607, i32 0, i32 0
  %t609 = load { i64, ptr }, ptr %t608, !tbaa !27
  store { i64, ptr } %t609, ptr %l170, !tbaa !27
  %t610 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 0
  store i64 %t611, ptr %l171, !tbaa !24
  %t612 = load i64, ptr %l171, !tbaa !24
  %t613 = mul i64 %t612, 16
  %t614 = load i64, ptr %l168
  %t615 = inttoptr i64 %t614 to ptr
  %t616 = call ptr @__olang_held_alloc(ptr %t615, i64 %t613)
  %t617 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  store { i64, ptr } %t618, ptr %l172, !tbaa !27
  %t619 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t620 = load ptr, ptr %t619, !tbaa !27
  %t621 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = load i64, ptr %l171, !tbaa !24
  %t624 = mul i64 %t623, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t620, ptr %t622, i64 %t624, i1 false)
  %t625 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t626 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t627 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t626, i32 0, i32 0
  store { i64, ptr } %t625, ptr %t627, !tbaa !27
  %t628 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t628, label %bb81, label %bb82
bb81:
  %t630 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t631 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t630, i32 0, i32 0
  %t632 = load { i64, ptr }, ptr %t631, !tbaa !27
  %t633 = extractvalue { i64, ptr } %t632, 0
  %t635 = icmp eq i64 %t633, 0
  br i1 %t635, label %bb83, label %bb84
bb82:
  %t637 = call ptr @__olang_scope_hold(ptr %s0)
  %t638 = ptrtoint ptr %t637 to i64
  store i64 %t638, ptr %l176, !tbaa !24
  %t639 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t639, label %bb85, label %bb86
bb83:
  %t641 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t642 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t641, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t642, !tbaa !27
  br label %bb84
bb84:
  %t643 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t644 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t643, i32 0, i32 0
  %t645 = load i64, ptr %l168
  %t646 = inttoptr i64 %t645 to ptr
  %t647 = load { i64, ptr }, ptr %t644
  %t648 = extractvalue { i64, ptr } %t647, 1
  %t649 = call ptr @__olang_region_or(ptr %t648, ptr null)
  %t650 = icmp ne ptr %t649, null
  %t651 = select i1 %t650, ptr %t649, ptr null
  call void @__olang_region_settle_in(ptr %t646, ptr %t651)
  br label %bb82
bb85:
  %t652 = call ptr @__olang_region_make_part(ptr %s0)
  %t653 = ptrtoint ptr %t652 to i64
  store i64 %t653, ptr %l176, !tbaa !24
  br label %bb86
bb86:
  %t654 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t655 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t654, i32 0, i32 1
  %t656 = load { i64, ptr }, ptr %t655, !tbaa !27
  store { i64, ptr } %t656, ptr %l178, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t657, 0
  store i64 %t658, ptr %l179, !tbaa !24
  %t659 = load i64, ptr %l179, !tbaa !24
  %t660 = mul i64 %t659, 8
  %t661 = load i64, ptr %l176
  %t662 = inttoptr i64 %t661 to ptr
  %t663 = call ptr @__olang_held_alloc(ptr %t662, i64 %t660)
  %t664 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t665 = insertvalue { i64, ptr } %t664, ptr %t663, 1
  store { i64, ptr } %t665, ptr %l180, !tbaa !27
  %t666 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !27
  %t668 = getelementptr { i64, ptr }, ptr %l178, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !27
  %t670 = load i64, ptr %l179, !tbaa !24
  %t671 = mul i64 %t670, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t667, ptr %t669, i64 %t671, i1 false)
  %t672 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t673 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t674 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t673, i32 0, i32 1
  store { i64, ptr } %t672, ptr %t674, !tbaa !27
  %t675 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t675, label %bb87, label %bb88
bb87:
  %t677 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t678 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t677, i32 0, i32 1
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !27
  %t680 = extractvalue { i64, ptr } %t679, 0
  %t682 = icmp eq i64 %t680, 0
  br i1 %t682, label %bb89, label %bb90
bb88:
  %t684 = call ptr @__olang_scope_hold(ptr %s0)
  %t685 = ptrtoint ptr %t684 to i64
  store i64 %t685, ptr %l184, !tbaa !24
  %t686 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t686, label %bb91, label %bb92
bb89:
  %t688 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t689 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t688, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t689, !tbaa !27
  br label %bb90
bb90:
  %t690 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t691 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t690, i32 0, i32 1
  %t692 = load i64, ptr %l176
  %t693 = inttoptr i64 %t692 to ptr
  %t694 = load { i64, ptr }, ptr %t691
  %t695 = extractvalue { i64, ptr } %t694, 1
  %t696 = call ptr @__olang_region_or(ptr %t695, ptr null)
  %t697 = icmp ne ptr %t696, null
  %t698 = select i1 %t697, ptr %t696, ptr null
  call void @__olang_region_settle_in(ptr %t693, ptr %t698)
  br label %bb88
bb91:
  %t699 = call ptr @__olang_region_make_part(ptr %s0)
  %t700 = ptrtoint ptr %t699 to i64
  store i64 %t700, ptr %l184, !tbaa !24
  br label %bb92
bb92:
  %t701 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t702 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t701, i32 0, i32 2
  %t703 = load { i64, ptr }, ptr %t702, !tbaa !27
  store { i64, ptr } %t703, ptr %l186, !tbaa !27
  %t704 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t705 = extractvalue { i64, ptr } %t704, 0
  store i64 %t705, ptr %l187, !tbaa !24
  %t706 = load i64, ptr %l187, !tbaa !24
  %t707 = mul i64 %t706, 8
  %t708 = load i64, ptr %l184
  %t709 = inttoptr i64 %t708 to ptr
  %t710 = call ptr @__olang_held_alloc(ptr %t709, i64 %t707)
  %t711 = insertvalue { i64, ptr } undef, i64 %t706, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t710, 1
  store { i64, ptr } %t712, ptr %l188, !tbaa !27
  %t713 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !27
  %t715 = getelementptr { i64, ptr }, ptr %l186, i32 0, i32 1
  %t716 = load ptr, ptr %t715, !tbaa !27
  %t717 = load i64, ptr %l187, !tbaa !24
  %t718 = mul i64 %t717, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t714, ptr %t716, i64 %t718, i1 false)
  %t719 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t720 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t721 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t720, i32 0, i32 2
  store { i64, ptr } %t719, ptr %t721, !tbaa !27
  %t722 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t722, label %bb93, label %bb94
bb93:
  %t724 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t725 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t724, i32 0, i32 2
  %t726 = load { i64, ptr }, ptr %t725, !tbaa !27
  %t727 = extractvalue { i64, ptr } %t726, 0
  %t729 = icmp eq i64 %t727, 0
  br i1 %t729, label %bb95, label %bb96
bb94:
  %t731 = call ptr @__olang_scope_hold(ptr %s0)
  %t732 = ptrtoint ptr %t731 to i64
  store i64 %t732, ptr %l192, !tbaa !24
  %t733 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t733, label %bb97, label %bb98
bb95:
  %t735 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t736 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t735, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t736, !tbaa !27
  br label %bb96
bb96:
  %t737 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 3
  %t738 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t737, i32 0, i32 2
  %t739 = load i64, ptr %l184
  %t740 = inttoptr i64 %t739 to ptr
  %t741 = load { i64, ptr }, ptr %t738
  %t742 = extractvalue { i64, ptr } %t741, 1
  %t743 = call ptr @__olang_region_or(ptr %t742, ptr null)
  %t744 = icmp ne ptr %t743, null
  %t745 = select i1 %t744, ptr %t743, ptr null
  call void @__olang_region_settle_in(ptr %t740, ptr %t745)
  br label %bb94
bb97:
  %t746 = call ptr @__olang_region_make_part(ptr %s0)
  %t747 = ptrtoint ptr %t746 to i64
  store i64 %t747, ptr %l192, !tbaa !24
  br label %bb98
bb98:
  %t748 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t749 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t748, i32 0, i32 0
  %t750 = load { i64, ptr }, ptr %t749, !tbaa !27
  store { i64, ptr } %t750, ptr %l194, !tbaa !27
  %t751 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t752 = extractvalue { i64, ptr } %t751, 0
  store i64 %t752, ptr %l195, !tbaa !24
  %t753 = load i64, ptr %l195, !tbaa !24
  %t754 = mul i64 %t753, 16
  %t755 = load i64, ptr %l192
  %t756 = inttoptr i64 %t755 to ptr
  %t757 = call ptr @__olang_held_alloc(ptr %t756, i64 %t754)
  %t758 = insertvalue { i64, ptr } undef, i64 %t753, 0
  %t759 = insertvalue { i64, ptr } %t758, ptr %t757, 1
  store { i64, ptr } %t759, ptr %l196, !tbaa !27
  %t760 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t761 = load ptr, ptr %t760, !tbaa !27
  %t762 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !27
  %t764 = load i64, ptr %l195, !tbaa !24
  %t765 = mul i64 %t764, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t761, ptr %t763, i64 %t765, i1 false)
  %t766 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t767 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t768 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t767, i32 0, i32 0
  store { i64, ptr } %t766, ptr %t768, !tbaa !27
  %t769 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t769, label %bb99, label %bb100
bb99:
  %t771 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t772 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t771, i32 0, i32 0
  %t773 = load { i64, ptr }, ptr %t772, !tbaa !27
  %t774 = extractvalue { i64, ptr } %t773, 0
  %t776 = icmp eq i64 %t774, 0
  br i1 %t776, label %bb101, label %bb102
bb100:
  %t778 = call ptr @__olang_scope_hold(ptr %s0)
  %t779 = ptrtoint ptr %t778 to i64
  store i64 %t779, ptr %l200, !tbaa !24
  %t780 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t780, label %bb103, label %bb104
bb101:
  %t782 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t783 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t782, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t783, !tbaa !27
  br label %bb102
bb102:
  %t784 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t785 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t784, i32 0, i32 0
  %t786 = load i64, ptr %l192
  %t787 = inttoptr i64 %t786 to ptr
  %t788 = load { i64, ptr }, ptr %t785
  %t789 = extractvalue { i64, ptr } %t788, 1
  %t790 = call ptr @__olang_region_or(ptr %t789, ptr null)
  %t791 = icmp ne ptr %t790, null
  %t792 = select i1 %t791, ptr %t790, ptr null
  call void @__olang_region_settle_in(ptr %t787, ptr %t792)
  br label %bb100
bb103:
  %t793 = call ptr @__olang_region_make_part(ptr %s0)
  %t794 = ptrtoint ptr %t793 to i64
  store i64 %t794, ptr %l200, !tbaa !24
  br label %bb104
bb104:
  %t795 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t796 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t795, i32 0, i32 1
  %t797 = load { i64, ptr }, ptr %t796, !tbaa !27
  store { i64, ptr } %t797, ptr %l202, !tbaa !27
  %t798 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t799 = extractvalue { i64, ptr } %t798, 0
  store i64 %t799, ptr %l203, !tbaa !24
  %t800 = load i64, ptr %l203, !tbaa !24
  %t801 = mul i64 %t800, 8
  %t802 = load i64, ptr %l200
  %t803 = inttoptr i64 %t802 to ptr
  %t804 = call ptr @__olang_held_alloc(ptr %t803, i64 %t801)
  %t805 = insertvalue { i64, ptr } undef, i64 %t800, 0
  %t806 = insertvalue { i64, ptr } %t805, ptr %t804, 1
  store { i64, ptr } %t806, ptr %l204, !tbaa !27
  %t807 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t808 = load ptr, ptr %t807, !tbaa !27
  %t809 = getelementptr { i64, ptr }, ptr %l202, i32 0, i32 1
  %t810 = load ptr, ptr %t809, !tbaa !27
  %t811 = load i64, ptr %l203, !tbaa !24
  %t812 = mul i64 %t811, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t808, ptr %t810, i64 %t812, i1 false)
  %t813 = load { i64, ptr }, ptr %l204, !tbaa !27
  %t814 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t815 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t814, i32 0, i32 1
  store { i64, ptr } %t813, ptr %t815, !tbaa !27
  %t816 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t816, label %bb105, label %bb106
bb105:
  %t818 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t819 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t818, i32 0, i32 1
  %t820 = load { i64, ptr }, ptr %t819, !tbaa !27
  %t821 = extractvalue { i64, ptr } %t820, 0
  %t823 = icmp eq i64 %t821, 0
  br i1 %t823, label %bb107, label %bb108
bb106:
  %t825 = call ptr @__olang_scope_hold(ptr %s0)
  %t826 = ptrtoint ptr %t825 to i64
  store i64 %t826, ptr %l208, !tbaa !24
  %t827 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t827, label %bb109, label %bb110
bb107:
  %t829 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t830 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t829, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t830, !tbaa !27
  br label %bb108
bb108:
  %t831 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t832 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t831, i32 0, i32 1
  %t833 = load i64, ptr %l200
  %t834 = inttoptr i64 %t833 to ptr
  %t835 = load { i64, ptr }, ptr %t832
  %t836 = extractvalue { i64, ptr } %t835, 1
  %t837 = call ptr @__olang_region_or(ptr %t836, ptr null)
  %t838 = icmp ne ptr %t837, null
  %t839 = select i1 %t838, ptr %t837, ptr null
  call void @__olang_region_settle_in(ptr %t834, ptr %t839)
  br label %bb106
bb109:
  %t840 = call ptr @__olang_region_make_part(ptr %s0)
  %t841 = ptrtoint ptr %t840 to i64
  store i64 %t841, ptr %l208, !tbaa !24
  br label %bb110
bb110:
  %t842 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t843 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t842, i32 0, i32 2
  %t844 = load { i64, ptr }, ptr %t843, !tbaa !27
  store { i64, ptr } %t844, ptr %l210, !tbaa !27
  %t845 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t846 = extractvalue { i64, ptr } %t845, 0
  store i64 %t846, ptr %l211, !tbaa !24
  %t847 = load i64, ptr %l211, !tbaa !24
  %t848 = mul i64 %t847, 8
  %t849 = load i64, ptr %l208
  %t850 = inttoptr i64 %t849 to ptr
  %t851 = call ptr @__olang_held_alloc(ptr %t850, i64 %t848)
  %t852 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t853 = insertvalue { i64, ptr } %t852, ptr %t851, 1
  store { i64, ptr } %t853, ptr %l212, !tbaa !27
  %t854 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t855 = load ptr, ptr %t854, !tbaa !27
  %t856 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t857 = load ptr, ptr %t856, !tbaa !27
  %t858 = load i64, ptr %l211, !tbaa !24
  %t859 = mul i64 %t858, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t855, ptr %t857, i64 %t859, i1 false)
  %t860 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t861 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t862 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t861, i32 0, i32 2
  store { i64, ptr } %t860, ptr %t862, !tbaa !27
  %t863 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t863, label %bb111, label %bb112
bb111:
  %t865 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t866 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t865, i32 0, i32 2
  %t867 = load { i64, ptr }, ptr %t866, !tbaa !27
  %t868 = extractvalue { i64, ptr } %t867, 0
  %t870 = icmp eq i64 %t868, 0
  br i1 %t870, label %bb113, label %bb114
bb112:
  %t872 = call ptr @__olang_scope_hold(ptr %s0)
  %t873 = ptrtoint ptr %t872 to i64
  store i64 %t873, ptr %l216, !tbaa !24
  %t874 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t874, label %bb115, label %bb116
bb113:
  %t876 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t877 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t876, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t877, !tbaa !27
  br label %bb114
bb114:
  %t878 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 4
  %t879 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t878, i32 0, i32 2
  %t880 = load i64, ptr %l208
  %t881 = inttoptr i64 %t880 to ptr
  %t882 = load { i64, ptr }, ptr %t879
  %t883 = extractvalue { i64, ptr } %t882, 1
  %t884 = call ptr @__olang_region_or(ptr %t883, ptr null)
  %t885 = icmp ne ptr %t884, null
  %t886 = select i1 %t885, ptr %t884, ptr null
  call void @__olang_region_settle_in(ptr %t881, ptr %t886)
  br label %bb112
bb115:
  %t887 = call ptr @__olang_region_make_part(ptr %s0)
  %t888 = ptrtoint ptr %t887 to i64
  store i64 %t888, ptr %l216, !tbaa !24
  br label %bb116
bb116:
  %t889 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 5
  %t890 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t889, i32 0, i32 0
  %t891 = load { i64, ptr }, ptr %t890, !tbaa !27
  store { i64, ptr } %t891, ptr %l218, !tbaa !27
  %t892 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t893 = extractvalue { i64, ptr } %t892, 0
  store i64 %t893, ptr %l219, !tbaa !24
  %t894 = load i64, ptr %l219, !tbaa !24
  %t895 = mul i64 %t894, 8
  %t896 = load i64, ptr %l216
  %t897 = inttoptr i64 %t896 to ptr
  %t898 = call ptr @__olang_held_alloc(ptr %t897, i64 %t895)
  %t899 = insertvalue { i64, ptr } undef, i64 %t894, 0
  %t900 = insertvalue { i64, ptr } %t899, ptr %t898, 1
  store { i64, ptr } %t900, ptr %l220, !tbaa !27
  %t901 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t902 = load ptr, ptr %t901, !tbaa !27
  %t903 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t904 = load ptr, ptr %t903, !tbaa !27
  %t905 = load i64, ptr %l219, !tbaa !24
  %t906 = mul i64 %t905, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t902, ptr %t904, i64 %t906, i1 false)
  %t907 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t908 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 5
  %t909 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t908, i32 0, i32 0
  store { i64, ptr } %t907, ptr %t909, !tbaa !27
  %t910 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t910, label %bb117, label %bb118
bb117:
  %t912 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 5
  %t913 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t912, i32 0, i32 0
  %t914 = load { i64, ptr }, ptr %t913, !tbaa !27
  %t915 = extractvalue { i64, ptr } %t914, 0
  %t917 = icmp eq i64 %t915, 0
  br i1 %t917, label %bb119, label %bb120
bb118:
  %t919 = call ptr @__olang_scope_hold(ptr %s0)
  %t920 = ptrtoint ptr %t919 to i64
  store i64 %t920, ptr %l224, !tbaa !24
  %t921 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t921, label %bb121, label %bb122
bb119:
  %t923 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 5
  %t924 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t923, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t924, !tbaa !27
  br label %bb120
bb120:
  %t925 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 5
  %t926 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t925, i32 0, i32 0
  %t927 = load i64, ptr %l216
  %t928 = inttoptr i64 %t927 to ptr
  %t929 = load { i64, ptr }, ptr %t926
  %t930 = extractvalue { i64, ptr } %t929, 1
  %t931 = call ptr @__olang_region_or(ptr %t930, ptr null)
  %t932 = icmp ne ptr %t931, null
  %t933 = select i1 %t932, ptr %t931, ptr null
  call void @__olang_region_settle_in(ptr %t928, ptr %t933)
  br label %bb118
bb121:
  %t934 = call ptr @__olang_region_make_part(ptr %s0)
  %t935 = ptrtoint ptr %t934 to i64
  store i64 %t935, ptr %l224, !tbaa !24
  br label %bb122
bb122:
  %t936 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 6
  %t937 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t936, i32 0, i32 0
  %t938 = load { i64, ptr }, ptr %t937, !tbaa !27
  store { i64, ptr } %t938, ptr %l226, !tbaa !27
  %t939 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t940 = extractvalue { i64, ptr } %t939, 0
  store i64 %t940, ptr %l227, !tbaa !24
  %t941 = load i64, ptr %l227, !tbaa !24
  %t942 = mul i64 %t941, 8
  %t943 = load i64, ptr %l224
  %t944 = inttoptr i64 %t943 to ptr
  %t945 = call ptr @__olang_held_alloc(ptr %t944, i64 %t942)
  %t946 = insertvalue { i64, ptr } undef, i64 %t941, 0
  %t947 = insertvalue { i64, ptr } %t946, ptr %t945, 1
  store { i64, ptr } %t947, ptr %l228, !tbaa !27
  %t948 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t949 = load ptr, ptr %t948, !tbaa !27
  %t950 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t951 = load ptr, ptr %t950, !tbaa !27
  %t952 = load i64, ptr %l227, !tbaa !24
  %t953 = mul i64 %t952, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t949, ptr %t951, i64 %t953, i1 false)
  %t954 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t955 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 6
  %t956 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t955, i32 0, i32 0
  store { i64, ptr } %t954, ptr %t956, !tbaa !27
  %t957 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t957, label %bb123, label %bb124
bb123:
  %t959 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 6
  %t960 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t959, i32 0, i32 0
  %t961 = load { i64, ptr }, ptr %t960, !tbaa !27
  %t962 = extractvalue { i64, ptr } %t961, 0
  %t964 = icmp eq i64 %t962, 0
  br i1 %t964, label %bb125, label %bb126
bb124:
  %t966 = load ptr, ptr %l2, !tbaa !29
  %t967 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr null, i32 1
  %t968 = ptrtoint ptr %t967 to i64
  %t970 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t969, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t970, ptr %l95, i64 424, i1 false)
  %t971 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t969, i32 0, i32 1
  store ptr %t966, ptr %t971, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t973 = call ptr @__olang_scope_hold(ptr %s0)
  %t974 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t969, i32 0, i32 2
  store ptr %t973, ptr %t974, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t975 = call ptr @__olang_scope_hold(ptr %v2)
  %t976 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t969, i32 0, i32 3
  store ptr %t975, ptr %t976, !tbaa !28
  %t977 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_74, 0
  %t978 = insertvalue { ptr, ptr } %t977, ptr %t969, 1
  %t979 = load ptr, ptr %l93, !tbaa !29
  %t981 = extractvalue { ptr, ptr } %t978, 0
  %t982 = extractvalue { ptr, ptr } %t978, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %t979, ptr %t981, ptr %t982)
  br label %bb127
bb125:
  %t983 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 6
  %t984 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t983, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t984, !tbaa !27
  br label %bb126
bb126:
  %t985 = getelementptr %"compiler/profile:Tally", ptr %l95, i32 0, i32 6
  %t986 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t985, i32 0, i32 0
  %t987 = load i64, ptr %l224
  %t988 = inttoptr i64 %t987 to ptr
  %t989 = load { i64, ptr }, ptr %t986
  %t990 = extractvalue { i64, ptr } %t989, 1
  %t991 = call ptr @__olang_region_or(ptr %t990, ptr null)
  %t992 = icmp ne ptr %t991, null
  %t993 = select i1 %t992, ptr %t991, ptr null
  call void @__olang_region_settle_in(ptr %t988, ptr %t993)
  br label %bb124
bb127:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb128
bb128:
  store i64 0, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb129
bb129:
  store %olang.scope zeroinitializer, ptr %s6
  %t996 = load i64, ptr %l10, !tbaa !24
  store i64 %t996, ptr %l236, !tbaa !24
  %t997 = load ptr, ptr %l9, !tbaa !29
  %t999 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t997)
  store i64 %t999, ptr %l238
  br label %bb130
bb130:
  %t1000 = load i64, ptr %l236, !tbaa !24
  %t1001 = load i64, ptr %l238, !tbaa !24
  %t1002 = icmp slt i64 %t1000, %t1001
  %t1004 = xor i1 %t1002, true
  br i1 %t1004, label %bb131, label %bb132
bb131:
  call void @__olang_scope_close(ptr %s6)
  br label %bb156
bb132:
  br label %bb133
bb133:
  %t1006 = load ptr, ptr %l9, !tbaa !29
  %t1007 = load i64, ptr %l10, !tbaa !24
  %t1010 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t1006, i64 %t1007)
  store i64 %t1010, ptr %l243
  br label %bb134
bb134:
  %t1011 = load i64, ptr %l243, !tbaa !24
  store i64 %t1011, ptr %l11, !tbaa !24
  %t1012 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 0
  %t1013 = load i64, ptr %l11, !tbaa !24
  %t1016 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t1012, i64 %t1013)
  %t1017 = extractvalue { i32, i64 } %t1016, 1
  %t1018 = extractvalue { i32, i64 } %t1016, 0
  store i32 %t1018, ptr %l248
  %t1019 = icmp ne i32 %t1018, 0
  br i1 %t1019, label %bb136, label %ok.1020, !prof !99
ok.1020:
  store i64 %t1017, ptr %l247
  br label %bb135
bb135:
  %t1021 = load i64, ptr %l247, !tbaa !24
  store i64 %t1021, ptr %l244, !tbaa !24
  br label %bb138
bb136:
  br label %bb137
bb137:
  store i64 0, ptr %l244, !tbaa !24
  br label %bb138
bb138:
  %t1022 = load i64, ptr %l244, !tbaa !24
  store i64 %t1022, ptr %l12, !tbaa !24
  %t1023 = load i64, ptr %l8, !tbaa !24
  %t1025 = icmp sge i64 %t1023, 25
  br i1 %t1025, label %bb139, label %bb140
bb139:
  store i1 true, ptr %l251, !tbaa !21
  br label %bb141
bb140:
  %t1027 = load i64, ptr %l12, !tbaa !24
  %t1029 = mul i64 %t1027, 200
  %t1030 = load i64, ptr %l4, !tbaa !24
  %t1033 = icmp slt i64 %t1029, %t1030
  store i1 %t1033, ptr %l251, !tbaa !21
  br label %bb141
bb141:
  %t1035 = load i1, ptr %l251, !tbaa !21
  br i1 %t1035, label %bb142, label %bb143
bb142:
  call void @__olang_scope_close(ptr %s6)
  br label %bb156
bb143:
  br label %bb144
bb144:
  %t1036 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 1
  %t1037 = load i64, ptr %l11, !tbaa !24
  %t1040 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t1036, i64 %t1037)
  %t1041 = extractvalue { i32, i64 } %t1040, 1
  %t1042 = extractvalue { i32, i64 } %t1040, 0
  store i32 %t1042, ptr %l260
  %t1043 = icmp ne i32 %t1042, 0
  br i1 %t1043, label %bb146, label %ok.1044, !prof !99
ok.1044:
  store i64 %t1041, ptr %l259
  br label %bb145
bb145:
  %t1045 = load i64, ptr %l259, !tbaa !24
  store i64 %t1045, ptr %l256, !tbaa !24
  br label %bb148
bb146:
  br label %bb147
bb147:
  store i64 0, ptr %l256, !tbaa !24
  br label %bb148
bb148:
  %t1046 = load i64, ptr %l256, !tbaa !24
  store i64 %t1046, ptr %l13, !tbaa !24
  store ptr %l5, ptr %l261, !tbaa !29
  %t1047 = load i64, ptr %l12, !tbaa !24
  %t1048 = load i64, ptr %l4, !tbaa !24
  %t1051 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s6, i64 %t1047, i64 %t1048)
  store { i64, ptr } %t1051, ptr %l264
  br label %bb149
bb149:
  %t1052 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t1054 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t1052, i64 6, i8 32)
  store { i64, ptr } %t1054, ptr %l266
  br label %bb150
bb150:
  %t1055 = load i64, ptr %l13, !tbaa !24
  %t1056 = load i64, ptr %l4, !tbaa !24
  %t1059 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s6, i64 %t1055, i64 %t1056)
  store { i64, ptr } %t1059, ptr %l269
  br label %bb151
bb151:
  %t1060 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t1062 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t1060, i64 6, i8 32)
  store { i64, ptr } %t1062, ptr %l271
  br label %bb152
bb152:
  %t1063 = load ptr, ptr %l2, !tbaa !29
  %t1065 = getelementptr %"compiler/profile:Places", ptr %t1063, i32 0, i32 0
  %t1066 = load i64, ptr %l11, !tbaa !24
  %t1069 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s6, ptr %t1065, i64 %t1066)
  store { i64, ptr } %t1069, ptr %l275
  br label %bb153
bb153:
  %t1070 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t1071 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t1072 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t1073 = extractvalue { i64, ptr } %t1072, 1
  %t1074 = extractvalue { i64, ptr } %t1072, 0
  %t1075 = add i64 %t1071, %t1074
  %t1076 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t1077 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t1078 = add i64 %t1075, %t1077
  %t1079 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t1080 = extractvalue { i64, ptr } %t1079, 1
  %t1081 = extractvalue { i64, ptr } %t1079, 0
  %t1082 = add i64 %t1078, %t1081
  %t1083 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t1084 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t1085 = add i64 %t1082, %t1084
  %t1086 = load { i64, ptr }, ptr %l275, !tbaa !27
  %t1087 = extractvalue { i64, ptr } %t1086, 1
  %t1088 = extractvalue { i64, ptr } %t1086, 0
  %t1089 = add i64 %t1085, %t1088
  %t1090 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t1091 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t1092 = add i64 %t1089, %t1091
  %t1093 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t1092)
  call void @olang_textcopy(ptr %t1093, ptr %t1070, i64 %t1071)
  %t1094 = getelementptr i8, ptr %t1093, i64 %t1071
  call void @olang_textcopy(ptr %t1094, ptr %t1073, i64 %t1074)
  %t1095 = getelementptr i8, ptr %t1094, i64 %t1074
  call void @olang_textcopy(ptr %t1095, ptr %t1076, i64 %t1077)
  %t1096 = getelementptr i8, ptr %t1095, i64 %t1077
  call void @olang_textcopy(ptr %t1096, ptr %t1080, i64 %t1081)
  %t1097 = getelementptr i8, ptr %t1096, i64 %t1081
  call void @olang_textcopy(ptr %t1097, ptr %t1083, i64 %t1084)
  %t1098 = getelementptr i8, ptr %t1097, i64 %t1084
  call void @olang_textcopy(ptr %t1098, ptr %t1087, i64 %t1088)
  %t1099 = getelementptr i8, ptr %t1098, i64 %t1088
  call void @olang_textcopy(ptr %t1099, ptr %t1090, i64 %t1091)
  %t1100 = insertvalue { i64, ptr } undef, i64 %t1092, 0
  %t1101 = insertvalue { i64, ptr } %t1100, ptr %t1093, 1
  %t1103 = load ptr, ptr %l261, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t1103, { i64, ptr } %t1101)
  br label %bb154
bb154:
  %t1105 = load i64, ptr %l8, !tbaa !24
  %t1108 = add i64 %t1105, 1
  store i64 %t1108, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb155
bb155:
  %t1110 = load i64, ptr %l10, !tbaa !24
  %t1113 = add i64 %t1110, 1
  store i64 %t1113, ptr %l10, !tbaa !24
  br label %bb129
bb156:
  %t1115 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 6
  %t1116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1115
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1116, ptr %l285
  %t1118 = call ptr @__olang_scope_hold(ptr %s0)
  %t1119 = ptrtoint ptr %t1118 to i64
  store i64 %t1119, ptr %l286, !tbaa !24
  %t1120 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1120, label %bb157, label %bb158
bb157:
  %t1122 = call ptr @__olang_region_make_part(ptr %s0)
  %t1123 = ptrtoint ptr %t1122 to i64
  store i64 %t1123, ptr %l286, !tbaa !24
  br label %bb158
bb158:
  %t1124 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t1125 = load { i64, ptr }, ptr %t1124, !tbaa !27
  store { i64, ptr } %t1125, ptr %l288, !tbaa !27
  %t1126 = load { i64, ptr }, ptr %l288, !tbaa !27
  %t1127 = extractvalue { i64, ptr } %t1126, 0
  store i64 %t1127, ptr %l289, !tbaa !24
  %t1128 = load i64, ptr %l289, !tbaa !24
  %t1129 = mul i64 %t1128, 8
  %t1130 = load i64, ptr %l286
  %t1131 = inttoptr i64 %t1130 to ptr
  %t1132 = call ptr @__olang_held_alloc(ptr %t1131, i64 %t1129)
  %t1133 = insertvalue { i64, ptr } undef, i64 %t1128, 0
  %t1134 = insertvalue { i64, ptr } %t1133, ptr %t1132, 1
  store { i64, ptr } %t1134, ptr %l290, !tbaa !27
  %t1135 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t1136 = load ptr, ptr %t1135, !tbaa !27
  %t1137 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t1138 = load ptr, ptr %t1137, !tbaa !27
  %t1139 = load i64, ptr %l289, !tbaa !24
  %t1140 = mul i64 %t1139, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1136, ptr %t1138, i64 %t1140, i1 false)
  %t1141 = load { i64, ptr }, ptr %l290, !tbaa !27
  %t1142 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  store { i64, ptr } %t1141, ptr %t1142, !tbaa !27
  %t1143 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1143, label %bb159, label %bb160
bb159:
  %t1145 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t1146 = load { i64, ptr }, ptr %t1145, !tbaa !27
  %t1147 = extractvalue { i64, ptr } %t1146, 0
  %t1149 = icmp eq i64 %t1147, 0
  br i1 %t1149, label %bb161, label %bb162
bb160:
  %t1151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1151, ptr %l14
  store ptr %l14, ptr %l294, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l295, ptr %l3, i64 424, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l296, ptr %l295, i64 424, i1 false)
  %t1152 = call ptr @__olang_scope_hold(ptr %s0)
  %t1153 = ptrtoint ptr %t1152 to i64
  store i64 %t1153, ptr %l297, !tbaa !24
  %t1154 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1154, label %bb163, label %bb164
bb161:
  %t1156 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1156, !tbaa !27
  br label %bb162
bb162:
  %t1157 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l285, i32 0, i32 0
  %t1158 = load i64, ptr %l286
  %t1159 = inttoptr i64 %t1158 to ptr
  %t1160 = load { i64, ptr }, ptr %t1157
  %t1161 = extractvalue { i64, ptr } %t1160, 1
  %t1162 = call ptr @__olang_region_or(ptr %t1161, ptr null)
  %t1163 = icmp ne ptr %t1162, null
  %t1164 = select i1 %t1163, ptr %t1162, ptr null
  call void @__olang_region_settle_in(ptr %t1159, ptr %t1164)
  br label %bb160
bb163:
  %t1165 = call ptr @__olang_region_make_part(ptr %s0)
  %t1166 = ptrtoint ptr %t1165 to i64
  store i64 %t1166, ptr %l297, !tbaa !24
  br label %bb164
bb164:
  %t1167 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1167, i32 0, i32 0
  %t1169 = load { i64, ptr }, ptr %t1168, !tbaa !27
  store { i64, ptr } %t1169, ptr %l299, !tbaa !27
  %t1170 = load { i64, ptr }, ptr %l299, !tbaa !27
  %t1171 = extractvalue { i64, ptr } %t1170, 0
  store i64 %t1171, ptr %l300, !tbaa !24
  %t1172 = load i64, ptr %l300, !tbaa !24
  %t1173 = mul i64 %t1172, 16
  %t1174 = load i64, ptr %l297
  %t1175 = inttoptr i64 %t1174 to ptr
  %t1176 = call ptr @__olang_held_alloc(ptr %t1175, i64 %t1173)
  %t1177 = insertvalue { i64, ptr } undef, i64 %t1172, 0
  %t1178 = insertvalue { i64, ptr } %t1177, ptr %t1176, 1
  store { i64, ptr } %t1178, ptr %l301, !tbaa !27
  %t1179 = getelementptr { i64, ptr }, ptr %l301, i32 0, i32 1
  %t1180 = load ptr, ptr %t1179, !tbaa !27
  %t1181 = getelementptr { i64, ptr }, ptr %l299, i32 0, i32 1
  %t1182 = load ptr, ptr %t1181, !tbaa !27
  %t1183 = load i64, ptr %l300, !tbaa !24
  %t1184 = mul i64 %t1183, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1180, ptr %t1182, i64 %t1184, i1 false)
  %t1185 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t1186 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1187 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1186, i32 0, i32 0
  store { i64, ptr } %t1185, ptr %t1187, !tbaa !27
  %t1188 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1188, label %bb165, label %bb166
bb165:
  %t1190 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1191 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1190, i32 0, i32 0
  %t1192 = load { i64, ptr }, ptr %t1191, !tbaa !27
  %t1193 = extractvalue { i64, ptr } %t1192, 0
  %t1195 = icmp eq i64 %t1193, 0
  br i1 %t1195, label %bb167, label %bb168
bb166:
  %t1197 = call ptr @__olang_scope_hold(ptr %s0)
  %t1198 = ptrtoint ptr %t1197 to i64
  store i64 %t1198, ptr %l305, !tbaa !24
  %t1199 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1199, label %bb169, label %bb170
bb167:
  %t1201 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1202 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1201, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1202, !tbaa !27
  br label %bb168
bb168:
  %t1203 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1204 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1203, i32 0, i32 0
  %t1205 = load i64, ptr %l297
  %t1206 = inttoptr i64 %t1205 to ptr
  %t1207 = load { i64, ptr }, ptr %t1204
  %t1208 = extractvalue { i64, ptr } %t1207, 1
  %t1209 = call ptr @__olang_region_or(ptr %t1208, ptr null)
  %t1210 = icmp ne ptr %t1209, null
  %t1211 = select i1 %t1210, ptr %t1209, ptr null
  call void @__olang_region_settle_in(ptr %t1206, ptr %t1211)
  br label %bb166
bb169:
  %t1212 = call ptr @__olang_region_make_part(ptr %s0)
  %t1213 = ptrtoint ptr %t1212 to i64
  store i64 %t1213, ptr %l305, !tbaa !24
  br label %bb170
bb170:
  %t1214 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1215 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1214, i32 0, i32 1
  %t1216 = load { i64, ptr }, ptr %t1215, !tbaa !27
  store { i64, ptr } %t1216, ptr %l307, !tbaa !27
  %t1217 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t1218 = extractvalue { i64, ptr } %t1217, 0
  store i64 %t1218, ptr %l308, !tbaa !24
  %t1219 = load i64, ptr %l308, !tbaa !24
  %t1220 = mul i64 %t1219, 8
  %t1221 = load i64, ptr %l305
  %t1222 = inttoptr i64 %t1221 to ptr
  %t1223 = call ptr @__olang_held_alloc(ptr %t1222, i64 %t1220)
  %t1224 = insertvalue { i64, ptr } undef, i64 %t1219, 0
  %t1225 = insertvalue { i64, ptr } %t1224, ptr %t1223, 1
  store { i64, ptr } %t1225, ptr %l309, !tbaa !27
  %t1226 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t1227 = load ptr, ptr %t1226, !tbaa !27
  %t1228 = getelementptr { i64, ptr }, ptr %l307, i32 0, i32 1
  %t1229 = load ptr, ptr %t1228, !tbaa !27
  %t1230 = load i64, ptr %l308, !tbaa !24
  %t1231 = mul i64 %t1230, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1227, ptr %t1229, i64 %t1231, i1 false)
  %t1232 = load { i64, ptr }, ptr %l309, !tbaa !27
  %t1233 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1234 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1233, i32 0, i32 1
  store { i64, ptr } %t1232, ptr %t1234, !tbaa !27
  %t1235 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1235, label %bb171, label %bb172
bb171:
  %t1237 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1238 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1237, i32 0, i32 1
  %t1239 = load { i64, ptr }, ptr %t1238, !tbaa !27
  %t1240 = extractvalue { i64, ptr } %t1239, 0
  %t1242 = icmp eq i64 %t1240, 0
  br i1 %t1242, label %bb173, label %bb174
bb172:
  %t1244 = call ptr @__olang_scope_hold(ptr %s0)
  %t1245 = ptrtoint ptr %t1244 to i64
  store i64 %t1245, ptr %l313, !tbaa !24
  %t1246 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1246, label %bb175, label %bb176
bb173:
  %t1248 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1249 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1248, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t1249, !tbaa !27
  br label %bb174
bb174:
  %t1250 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1251 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1250, i32 0, i32 1
  %t1252 = load i64, ptr %l305
  %t1253 = inttoptr i64 %t1252 to ptr
  %t1254 = load { i64, ptr }, ptr %t1251
  %t1255 = extractvalue { i64, ptr } %t1254, 1
  %t1256 = call ptr @__olang_region_or(ptr %t1255, ptr null)
  %t1257 = icmp ne ptr %t1256, null
  %t1258 = select i1 %t1257, ptr %t1256, ptr null
  call void @__olang_region_settle_in(ptr %t1253, ptr %t1258)
  br label %bb172
bb175:
  %t1259 = call ptr @__olang_region_make_part(ptr %s0)
  %t1260 = ptrtoint ptr %t1259 to i64
  store i64 %t1260, ptr %l313, !tbaa !24
  br label %bb176
bb176:
  %t1261 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1262 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1261, i32 0, i32 2
  %t1263 = load { i64, ptr }, ptr %t1262, !tbaa !27
  store { i64, ptr } %t1263, ptr %l315, !tbaa !27
  %t1264 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t1265 = extractvalue { i64, ptr } %t1264, 0
  store i64 %t1265, ptr %l316, !tbaa !24
  %t1266 = load i64, ptr %l316, !tbaa !24
  %t1267 = mul i64 %t1266, 8
  %t1268 = load i64, ptr %l313
  %t1269 = inttoptr i64 %t1268 to ptr
  %t1270 = call ptr @__olang_held_alloc(ptr %t1269, i64 %t1267)
  %t1271 = insertvalue { i64, ptr } undef, i64 %t1266, 0
  %t1272 = insertvalue { i64, ptr } %t1271, ptr %t1270, 1
  store { i64, ptr } %t1272, ptr %l317, !tbaa !27
  %t1273 = getelementptr { i64, ptr }, ptr %l317, i32 0, i32 1
  %t1274 = load ptr, ptr %t1273, !tbaa !27
  %t1275 = getelementptr { i64, ptr }, ptr %l315, i32 0, i32 1
  %t1276 = load ptr, ptr %t1275, !tbaa !27
  %t1277 = load i64, ptr %l316, !tbaa !24
  %t1278 = mul i64 %t1277, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1274, ptr %t1276, i64 %t1278, i1 false)
  %t1279 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t1280 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1281 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1280, i32 0, i32 2
  store { i64, ptr } %t1279, ptr %t1281, !tbaa !27
  %t1282 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1282, label %bb177, label %bb178
bb177:
  %t1284 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1285 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1284, i32 0, i32 2
  %t1286 = load { i64, ptr }, ptr %t1285, !tbaa !27
  %t1287 = extractvalue { i64, ptr } %t1286, 0
  %t1289 = icmp eq i64 %t1287, 0
  br i1 %t1289, label %bb179, label %bb180
bb178:
  %t1291 = call ptr @__olang_scope_hold(ptr %s0)
  %t1292 = ptrtoint ptr %t1291 to i64
  store i64 %t1292, ptr %l321, !tbaa !24
  %t1293 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1293, label %bb181, label %bb182
bb179:
  %t1295 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1296 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1295, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t1296, !tbaa !27
  br label %bb180
bb180:
  %t1297 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 0
  %t1298 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1297, i32 0, i32 2
  %t1299 = load i64, ptr %l313
  %t1300 = inttoptr i64 %t1299 to ptr
  %t1301 = load { i64, ptr }, ptr %t1298
  %t1302 = extractvalue { i64, ptr } %t1301, 1
  %t1303 = call ptr @__olang_region_or(ptr %t1302, ptr null)
  %t1304 = icmp ne ptr %t1303, null
  %t1305 = select i1 %t1304, ptr %t1303, ptr null
  call void @__olang_region_settle_in(ptr %t1300, ptr %t1305)
  br label %bb178
bb181:
  %t1306 = call ptr @__olang_region_make_part(ptr %s0)
  %t1307 = ptrtoint ptr %t1306 to i64
  store i64 %t1307, ptr %l321, !tbaa !24
  br label %bb182
bb182:
  %t1308 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1309 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1308, i32 0, i32 0
  %t1310 = load { i64, ptr }, ptr %t1309, !tbaa !27
  store { i64, ptr } %t1310, ptr %l323, !tbaa !27
  %t1311 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t1312 = extractvalue { i64, ptr } %t1311, 0
  store i64 %t1312, ptr %l324, !tbaa !24
  %t1313 = load i64, ptr %l324, !tbaa !24
  %t1314 = mul i64 %t1313, 16
  %t1315 = load i64, ptr %l321
  %t1316 = inttoptr i64 %t1315 to ptr
  %t1317 = call ptr @__olang_held_alloc(ptr %t1316, i64 %t1314)
  %t1318 = insertvalue { i64, ptr } undef, i64 %t1313, 0
  %t1319 = insertvalue { i64, ptr } %t1318, ptr %t1317, 1
  store { i64, ptr } %t1319, ptr %l325, !tbaa !27
  %t1320 = getelementptr { i64, ptr }, ptr %l325, i32 0, i32 1
  %t1321 = load ptr, ptr %t1320, !tbaa !27
  %t1322 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t1323 = load ptr, ptr %t1322, !tbaa !27
  %t1324 = load i64, ptr %l324, !tbaa !24
  %t1325 = mul i64 %t1324, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1321, ptr %t1323, i64 %t1325, i1 false)
  %t1326 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t1327 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1328 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1327, i32 0, i32 0
  store { i64, ptr } %t1326, ptr %t1328, !tbaa !27
  %t1329 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1329, label %bb183, label %bb184
bb183:
  %t1331 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1332 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1331, i32 0, i32 0
  %t1333 = load { i64, ptr }, ptr %t1332, !tbaa !27
  %t1334 = extractvalue { i64, ptr } %t1333, 0
  %t1336 = icmp eq i64 %t1334, 0
  br i1 %t1336, label %bb185, label %bb186
bb184:
  %t1338 = call ptr @__olang_scope_hold(ptr %s0)
  %t1339 = ptrtoint ptr %t1338 to i64
  store i64 %t1339, ptr %l329, !tbaa !24
  %t1340 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1340, label %bb187, label %bb188
bb185:
  %t1342 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1343 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1342, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1343, !tbaa !27
  br label %bb186
bb186:
  %t1344 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1345 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1344, i32 0, i32 0
  %t1346 = load i64, ptr %l321
  %t1347 = inttoptr i64 %t1346 to ptr
  %t1348 = load { i64, ptr }, ptr %t1345
  %t1349 = extractvalue { i64, ptr } %t1348, 1
  %t1350 = call ptr @__olang_region_or(ptr %t1349, ptr null)
  %t1351 = icmp ne ptr %t1350, null
  %t1352 = select i1 %t1351, ptr %t1350, ptr null
  call void @__olang_region_settle_in(ptr %t1347, ptr %t1352)
  br label %bb184
bb187:
  %t1353 = call ptr @__olang_region_make_part(ptr %s0)
  %t1354 = ptrtoint ptr %t1353 to i64
  store i64 %t1354, ptr %l329, !tbaa !24
  br label %bb188
bb188:
  %t1355 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1356 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1355, i32 0, i32 1
  %t1357 = load { i64, ptr }, ptr %t1356, !tbaa !27
  store { i64, ptr } %t1357, ptr %l331, !tbaa !27
  %t1358 = load { i64, ptr }, ptr %l331, !tbaa !27
  %t1359 = extractvalue { i64, ptr } %t1358, 0
  store i64 %t1359, ptr %l332, !tbaa !24
  %t1360 = load i64, ptr %l332, !tbaa !24
  %t1361 = mul i64 %t1360, 8
  %t1362 = load i64, ptr %l329
  %t1363 = inttoptr i64 %t1362 to ptr
  %t1364 = call ptr @__olang_held_alloc(ptr %t1363, i64 %t1361)
  %t1365 = insertvalue { i64, ptr } undef, i64 %t1360, 0
  %t1366 = insertvalue { i64, ptr } %t1365, ptr %t1364, 1
  store { i64, ptr } %t1366, ptr %l333, !tbaa !27
  %t1367 = getelementptr { i64, ptr }, ptr %l333, i32 0, i32 1
  %t1368 = load ptr, ptr %t1367, !tbaa !27
  %t1369 = getelementptr { i64, ptr }, ptr %l331, i32 0, i32 1
  %t1370 = load ptr, ptr %t1369, !tbaa !27
  %t1371 = load i64, ptr %l332, !tbaa !24
  %t1372 = mul i64 %t1371, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1368, ptr %t1370, i64 %t1372, i1 false)
  %t1373 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t1374 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1375 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1374, i32 0, i32 1
  store { i64, ptr } %t1373, ptr %t1375, !tbaa !27
  %t1376 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1376, label %bb189, label %bb190
bb189:
  %t1378 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1379 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1378, i32 0, i32 1
  %t1380 = load { i64, ptr }, ptr %t1379, !tbaa !27
  %t1381 = extractvalue { i64, ptr } %t1380, 0
  %t1383 = icmp eq i64 %t1381, 0
  br i1 %t1383, label %bb191, label %bb192
bb190:
  %t1385 = call ptr @__olang_scope_hold(ptr %s0)
  %t1386 = ptrtoint ptr %t1385 to i64
  store i64 %t1386, ptr %l337, !tbaa !24
  %t1387 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1387, label %bb193, label %bb194
bb191:
  %t1389 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1390 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1389, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t1390, !tbaa !27
  br label %bb192
bb192:
  %t1391 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1392 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1391, i32 0, i32 1
  %t1393 = load i64, ptr %l329
  %t1394 = inttoptr i64 %t1393 to ptr
  %t1395 = load { i64, ptr }, ptr %t1392
  %t1396 = extractvalue { i64, ptr } %t1395, 1
  %t1397 = call ptr @__olang_region_or(ptr %t1396, ptr null)
  %t1398 = icmp ne ptr %t1397, null
  %t1399 = select i1 %t1398, ptr %t1397, ptr null
  call void @__olang_region_settle_in(ptr %t1394, ptr %t1399)
  br label %bb190
bb193:
  %t1400 = call ptr @__olang_region_make_part(ptr %s0)
  %t1401 = ptrtoint ptr %t1400 to i64
  store i64 %t1401, ptr %l337, !tbaa !24
  br label %bb194
bb194:
  %t1402 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1403 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1402, i32 0, i32 2
  %t1404 = load { i64, ptr }, ptr %t1403, !tbaa !27
  store { i64, ptr } %t1404, ptr %l339, !tbaa !27
  %t1405 = load { i64, ptr }, ptr %l339, !tbaa !27
  %t1406 = extractvalue { i64, ptr } %t1405, 0
  store i64 %t1406, ptr %l340, !tbaa !24
  %t1407 = load i64, ptr %l340, !tbaa !24
  %t1408 = mul i64 %t1407, 8
  %t1409 = load i64, ptr %l337
  %t1410 = inttoptr i64 %t1409 to ptr
  %t1411 = call ptr @__olang_held_alloc(ptr %t1410, i64 %t1408)
  %t1412 = insertvalue { i64, ptr } undef, i64 %t1407, 0
  %t1413 = insertvalue { i64, ptr } %t1412, ptr %t1411, 1
  store { i64, ptr } %t1413, ptr %l341, !tbaa !27
  %t1414 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t1415 = load ptr, ptr %t1414, !tbaa !27
  %t1416 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t1417 = load ptr, ptr %t1416, !tbaa !27
  %t1418 = load i64, ptr %l340, !tbaa !24
  %t1419 = mul i64 %t1418, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1415, ptr %t1417, i64 %t1419, i1 false)
  %t1420 = load { i64, ptr }, ptr %l341, !tbaa !27
  %t1421 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1422 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1421, i32 0, i32 2
  store { i64, ptr } %t1420, ptr %t1422, !tbaa !27
  %t1423 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1423, label %bb195, label %bb196
bb195:
  %t1425 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1426 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1425, i32 0, i32 2
  %t1427 = load { i64, ptr }, ptr %t1426, !tbaa !27
  %t1428 = extractvalue { i64, ptr } %t1427, 0
  %t1430 = icmp eq i64 %t1428, 0
  br i1 %t1430, label %bb197, label %bb198
bb196:
  %t1432 = call ptr @__olang_scope_hold(ptr %s0)
  %t1433 = ptrtoint ptr %t1432 to i64
  store i64 %t1433, ptr %l345, !tbaa !24
  %t1434 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1434, label %bb199, label %bb200
bb197:
  %t1436 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1437 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1436, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t1437, !tbaa !27
  br label %bb198
bb198:
  %t1438 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 1
  %t1439 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1438, i32 0, i32 2
  %t1440 = load i64, ptr %l337
  %t1441 = inttoptr i64 %t1440 to ptr
  %t1442 = load { i64, ptr }, ptr %t1439
  %t1443 = extractvalue { i64, ptr } %t1442, 1
  %t1444 = call ptr @__olang_region_or(ptr %t1443, ptr null)
  %t1445 = icmp ne ptr %t1444, null
  %t1446 = select i1 %t1445, ptr %t1444, ptr null
  call void @__olang_region_settle_in(ptr %t1441, ptr %t1446)
  br label %bb196
bb199:
  %t1447 = call ptr @__olang_region_make_part(ptr %s0)
  %t1448 = ptrtoint ptr %t1447 to i64
  store i64 %t1448, ptr %l345, !tbaa !24
  br label %bb200
bb200:
  %t1449 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1450 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1449, i32 0, i32 0
  %t1451 = load { i64, ptr }, ptr %t1450, !tbaa !27
  store { i64, ptr } %t1451, ptr %l347, !tbaa !27
  %t1452 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t1453 = extractvalue { i64, ptr } %t1452, 0
  store i64 %t1453, ptr %l348, !tbaa !24
  %t1454 = load i64, ptr %l348, !tbaa !24
  %t1455 = mul i64 %t1454, 16
  %t1456 = load i64, ptr %l345
  %t1457 = inttoptr i64 %t1456 to ptr
  %t1458 = call ptr @__olang_held_alloc(ptr %t1457, i64 %t1455)
  %t1459 = insertvalue { i64, ptr } undef, i64 %t1454, 0
  %t1460 = insertvalue { i64, ptr } %t1459, ptr %t1458, 1
  store { i64, ptr } %t1460, ptr %l349, !tbaa !27
  %t1461 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t1462 = load ptr, ptr %t1461, !tbaa !27
  %t1463 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t1464 = load ptr, ptr %t1463, !tbaa !27
  %t1465 = load i64, ptr %l348, !tbaa !24
  %t1466 = mul i64 %t1465, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1462, ptr %t1464, i64 %t1466, i1 false)
  %t1467 = load { i64, ptr }, ptr %l349, !tbaa !27
  %t1468 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1469 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1468, i32 0, i32 0
  store { i64, ptr } %t1467, ptr %t1469, !tbaa !27
  %t1470 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1470, label %bb201, label %bb202
bb201:
  %t1472 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1473 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1472, i32 0, i32 0
  %t1474 = load { i64, ptr }, ptr %t1473, !tbaa !27
  %t1475 = extractvalue { i64, ptr } %t1474, 0
  %t1477 = icmp eq i64 %t1475, 0
  br i1 %t1477, label %bb203, label %bb204
bb202:
  %t1479 = call ptr @__olang_scope_hold(ptr %s0)
  %t1480 = ptrtoint ptr %t1479 to i64
  store i64 %t1480, ptr %l353, !tbaa !24
  %t1481 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1481, label %bb205, label %bb206
bb203:
  %t1483 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1484 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1483, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1484, !tbaa !27
  br label %bb204
bb204:
  %t1485 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1486 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1485, i32 0, i32 0
  %t1487 = load i64, ptr %l345
  %t1488 = inttoptr i64 %t1487 to ptr
  %t1489 = load { i64, ptr }, ptr %t1486
  %t1490 = extractvalue { i64, ptr } %t1489, 1
  %t1491 = call ptr @__olang_region_or(ptr %t1490, ptr null)
  %t1492 = icmp ne ptr %t1491, null
  %t1493 = select i1 %t1492, ptr %t1491, ptr null
  call void @__olang_region_settle_in(ptr %t1488, ptr %t1493)
  br label %bb202
bb205:
  %t1494 = call ptr @__olang_region_make_part(ptr %s0)
  %t1495 = ptrtoint ptr %t1494 to i64
  store i64 %t1495, ptr %l353, !tbaa !24
  br label %bb206
bb206:
  %t1496 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1497 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1496, i32 0, i32 1
  %t1498 = load { i64, ptr }, ptr %t1497, !tbaa !27
  store { i64, ptr } %t1498, ptr %l355, !tbaa !27
  %t1499 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t1500 = extractvalue { i64, ptr } %t1499, 0
  store i64 %t1500, ptr %l356, !tbaa !24
  %t1501 = load i64, ptr %l356, !tbaa !24
  %t1502 = mul i64 %t1501, 8
  %t1503 = load i64, ptr %l353
  %t1504 = inttoptr i64 %t1503 to ptr
  %t1505 = call ptr @__olang_held_alloc(ptr %t1504, i64 %t1502)
  %t1506 = insertvalue { i64, ptr } undef, i64 %t1501, 0
  %t1507 = insertvalue { i64, ptr } %t1506, ptr %t1505, 1
  store { i64, ptr } %t1507, ptr %l357, !tbaa !27
  %t1508 = getelementptr { i64, ptr }, ptr %l357, i32 0, i32 1
  %t1509 = load ptr, ptr %t1508, !tbaa !27
  %t1510 = getelementptr { i64, ptr }, ptr %l355, i32 0, i32 1
  %t1511 = load ptr, ptr %t1510, !tbaa !27
  %t1512 = load i64, ptr %l356, !tbaa !24
  %t1513 = mul i64 %t1512, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1509, ptr %t1511, i64 %t1513, i1 false)
  %t1514 = load { i64, ptr }, ptr %l357, !tbaa !27
  %t1515 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1516 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1515, i32 0, i32 1
  store { i64, ptr } %t1514, ptr %t1516, !tbaa !27
  %t1517 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1517, label %bb207, label %bb208
bb207:
  %t1519 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1520 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1519, i32 0, i32 1
  %t1521 = load { i64, ptr }, ptr %t1520, !tbaa !27
  %t1522 = extractvalue { i64, ptr } %t1521, 0
  %t1524 = icmp eq i64 %t1522, 0
  br i1 %t1524, label %bb209, label %bb210
bb208:
  %t1526 = call ptr @__olang_scope_hold(ptr %s0)
  %t1527 = ptrtoint ptr %t1526 to i64
  store i64 %t1527, ptr %l361, !tbaa !24
  %t1528 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1528, label %bb211, label %bb212
bb209:
  %t1530 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1531 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1530, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t1531, !tbaa !27
  br label %bb210
bb210:
  %t1532 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1533 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1532, i32 0, i32 1
  %t1534 = load i64, ptr %l353
  %t1535 = inttoptr i64 %t1534 to ptr
  %t1536 = load { i64, ptr }, ptr %t1533
  %t1537 = extractvalue { i64, ptr } %t1536, 1
  %t1538 = call ptr @__olang_region_or(ptr %t1537, ptr null)
  %t1539 = icmp ne ptr %t1538, null
  %t1540 = select i1 %t1539, ptr %t1538, ptr null
  call void @__olang_region_settle_in(ptr %t1535, ptr %t1540)
  br label %bb208
bb211:
  %t1541 = call ptr @__olang_region_make_part(ptr %s0)
  %t1542 = ptrtoint ptr %t1541 to i64
  store i64 %t1542, ptr %l361, !tbaa !24
  br label %bb212
bb212:
  %t1543 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1544 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1543, i32 0, i32 2
  %t1545 = load { i64, ptr }, ptr %t1544, !tbaa !27
  store { i64, ptr } %t1545, ptr %l363, !tbaa !27
  %t1546 = load { i64, ptr }, ptr %l363, !tbaa !27
  %t1547 = extractvalue { i64, ptr } %t1546, 0
  store i64 %t1547, ptr %l364, !tbaa !24
  %t1548 = load i64, ptr %l364, !tbaa !24
  %t1549 = mul i64 %t1548, 8
  %t1550 = load i64, ptr %l361
  %t1551 = inttoptr i64 %t1550 to ptr
  %t1552 = call ptr @__olang_held_alloc(ptr %t1551, i64 %t1549)
  %t1553 = insertvalue { i64, ptr } undef, i64 %t1548, 0
  %t1554 = insertvalue { i64, ptr } %t1553, ptr %t1552, 1
  store { i64, ptr } %t1554, ptr %l365, !tbaa !27
  %t1555 = getelementptr { i64, ptr }, ptr %l365, i32 0, i32 1
  %t1556 = load ptr, ptr %t1555, !tbaa !27
  %t1557 = getelementptr { i64, ptr }, ptr %l363, i32 0, i32 1
  %t1558 = load ptr, ptr %t1557, !tbaa !27
  %t1559 = load i64, ptr %l364, !tbaa !24
  %t1560 = mul i64 %t1559, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1556, ptr %t1558, i64 %t1560, i1 false)
  %t1561 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t1562 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1563 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1562, i32 0, i32 2
  store { i64, ptr } %t1561, ptr %t1563, !tbaa !27
  %t1564 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1564, label %bb213, label %bb214
bb213:
  %t1566 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1567 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1566, i32 0, i32 2
  %t1568 = load { i64, ptr }, ptr %t1567, !tbaa !27
  %t1569 = extractvalue { i64, ptr } %t1568, 0
  %t1571 = icmp eq i64 %t1569, 0
  br i1 %t1571, label %bb215, label %bb216
bb214:
  %t1573 = call ptr @__olang_scope_hold(ptr %s0)
  %t1574 = ptrtoint ptr %t1573 to i64
  store i64 %t1574, ptr %l369, !tbaa !24
  %t1575 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1575, label %bb217, label %bb218
bb215:
  %t1577 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1578 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1577, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t1578, !tbaa !27
  br label %bb216
bb216:
  %t1579 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 2
  %t1580 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1579, i32 0, i32 2
  %t1581 = load i64, ptr %l361
  %t1582 = inttoptr i64 %t1581 to ptr
  %t1583 = load { i64, ptr }, ptr %t1580
  %t1584 = extractvalue { i64, ptr } %t1583, 1
  %t1585 = call ptr @__olang_region_or(ptr %t1584, ptr null)
  %t1586 = icmp ne ptr %t1585, null
  %t1587 = select i1 %t1586, ptr %t1585, ptr null
  call void @__olang_region_settle_in(ptr %t1582, ptr %t1587)
  br label %bb214
bb217:
  %t1588 = call ptr @__olang_region_make_part(ptr %s0)
  %t1589 = ptrtoint ptr %t1588 to i64
  store i64 %t1589, ptr %l369, !tbaa !24
  br label %bb218
bb218:
  %t1590 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1591 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1590, i32 0, i32 0
  %t1592 = load { i64, ptr }, ptr %t1591, !tbaa !27
  store { i64, ptr } %t1592, ptr %l371, !tbaa !27
  %t1593 = load { i64, ptr }, ptr %l371, !tbaa !27
  %t1594 = extractvalue { i64, ptr } %t1593, 0
  store i64 %t1594, ptr %l372, !tbaa !24
  %t1595 = load i64, ptr %l372, !tbaa !24
  %t1596 = mul i64 %t1595, 16
  %t1597 = load i64, ptr %l369
  %t1598 = inttoptr i64 %t1597 to ptr
  %t1599 = call ptr @__olang_held_alloc(ptr %t1598, i64 %t1596)
  %t1600 = insertvalue { i64, ptr } undef, i64 %t1595, 0
  %t1601 = insertvalue { i64, ptr } %t1600, ptr %t1599, 1
  store { i64, ptr } %t1601, ptr %l373, !tbaa !27
  %t1602 = getelementptr { i64, ptr }, ptr %l373, i32 0, i32 1
  %t1603 = load ptr, ptr %t1602, !tbaa !27
  %t1604 = getelementptr { i64, ptr }, ptr %l371, i32 0, i32 1
  %t1605 = load ptr, ptr %t1604, !tbaa !27
  %t1606 = load i64, ptr %l372, !tbaa !24
  %t1607 = mul i64 %t1606, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1603, ptr %t1605, i64 %t1607, i1 false)
  %t1608 = load { i64, ptr }, ptr %l373, !tbaa !27
  %t1609 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1610 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1609, i32 0, i32 0
  store { i64, ptr } %t1608, ptr %t1610, !tbaa !27
  %t1611 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1611, label %bb219, label %bb220
bb219:
  %t1613 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1614 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1613, i32 0, i32 0
  %t1615 = load { i64, ptr }, ptr %t1614, !tbaa !27
  %t1616 = extractvalue { i64, ptr } %t1615, 0
  %t1618 = icmp eq i64 %t1616, 0
  br i1 %t1618, label %bb221, label %bb222
bb220:
  %t1620 = call ptr @__olang_scope_hold(ptr %s0)
  %t1621 = ptrtoint ptr %t1620 to i64
  store i64 %t1621, ptr %l377, !tbaa !24
  %t1622 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1622, label %bb223, label %bb224
bb221:
  %t1624 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1625 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1624, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1625, !tbaa !27
  br label %bb222
bb222:
  %t1626 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1627 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1626, i32 0, i32 0
  %t1628 = load i64, ptr %l369
  %t1629 = inttoptr i64 %t1628 to ptr
  %t1630 = load { i64, ptr }, ptr %t1627
  %t1631 = extractvalue { i64, ptr } %t1630, 1
  %t1632 = call ptr @__olang_region_or(ptr %t1631, ptr null)
  %t1633 = icmp ne ptr %t1632, null
  %t1634 = select i1 %t1633, ptr %t1632, ptr null
  call void @__olang_region_settle_in(ptr %t1629, ptr %t1634)
  br label %bb220
bb223:
  %t1635 = call ptr @__olang_region_make_part(ptr %s0)
  %t1636 = ptrtoint ptr %t1635 to i64
  store i64 %t1636, ptr %l377, !tbaa !24
  br label %bb224
bb224:
  %t1637 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1638 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1637, i32 0, i32 1
  %t1639 = load { i64, ptr }, ptr %t1638, !tbaa !27
  store { i64, ptr } %t1639, ptr %l379, !tbaa !27
  %t1640 = load { i64, ptr }, ptr %l379, !tbaa !27
  %t1641 = extractvalue { i64, ptr } %t1640, 0
  store i64 %t1641, ptr %l380, !tbaa !24
  %t1642 = load i64, ptr %l380, !tbaa !24
  %t1643 = mul i64 %t1642, 8
  %t1644 = load i64, ptr %l377
  %t1645 = inttoptr i64 %t1644 to ptr
  %t1646 = call ptr @__olang_held_alloc(ptr %t1645, i64 %t1643)
  %t1647 = insertvalue { i64, ptr } undef, i64 %t1642, 0
  %t1648 = insertvalue { i64, ptr } %t1647, ptr %t1646, 1
  store { i64, ptr } %t1648, ptr %l381, !tbaa !27
  %t1649 = getelementptr { i64, ptr }, ptr %l381, i32 0, i32 1
  %t1650 = load ptr, ptr %t1649, !tbaa !27
  %t1651 = getelementptr { i64, ptr }, ptr %l379, i32 0, i32 1
  %t1652 = load ptr, ptr %t1651, !tbaa !27
  %t1653 = load i64, ptr %l380, !tbaa !24
  %t1654 = mul i64 %t1653, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1650, ptr %t1652, i64 %t1654, i1 false)
  %t1655 = load { i64, ptr }, ptr %l381, !tbaa !27
  %t1656 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1657 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1656, i32 0, i32 1
  store { i64, ptr } %t1655, ptr %t1657, !tbaa !27
  %t1658 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1658, label %bb225, label %bb226
bb225:
  %t1660 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1661 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1660, i32 0, i32 1
  %t1662 = load { i64, ptr }, ptr %t1661, !tbaa !27
  %t1663 = extractvalue { i64, ptr } %t1662, 0
  %t1665 = icmp eq i64 %t1663, 0
  br i1 %t1665, label %bb227, label %bb228
bb226:
  %t1667 = call ptr @__olang_scope_hold(ptr %s0)
  %t1668 = ptrtoint ptr %t1667 to i64
  store i64 %t1668, ptr %l385, !tbaa !24
  %t1669 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1669, label %bb229, label %bb230
bb227:
  %t1671 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1672 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1671, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t1672, !tbaa !27
  br label %bb228
bb228:
  %t1673 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1674 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1673, i32 0, i32 1
  %t1675 = load i64, ptr %l377
  %t1676 = inttoptr i64 %t1675 to ptr
  %t1677 = load { i64, ptr }, ptr %t1674
  %t1678 = extractvalue { i64, ptr } %t1677, 1
  %t1679 = call ptr @__olang_region_or(ptr %t1678, ptr null)
  %t1680 = icmp ne ptr %t1679, null
  %t1681 = select i1 %t1680, ptr %t1679, ptr null
  call void @__olang_region_settle_in(ptr %t1676, ptr %t1681)
  br label %bb226
bb229:
  %t1682 = call ptr @__olang_region_make_part(ptr %s0)
  %t1683 = ptrtoint ptr %t1682 to i64
  store i64 %t1683, ptr %l385, !tbaa !24
  br label %bb230
bb230:
  %t1684 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1685 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1684, i32 0, i32 2
  %t1686 = load { i64, ptr }, ptr %t1685, !tbaa !27
  store { i64, ptr } %t1686, ptr %l387, !tbaa !27
  %t1687 = load { i64, ptr }, ptr %l387, !tbaa !27
  %t1688 = extractvalue { i64, ptr } %t1687, 0
  store i64 %t1688, ptr %l388, !tbaa !24
  %t1689 = load i64, ptr %l388, !tbaa !24
  %t1690 = mul i64 %t1689, 8
  %t1691 = load i64, ptr %l385
  %t1692 = inttoptr i64 %t1691 to ptr
  %t1693 = call ptr @__olang_held_alloc(ptr %t1692, i64 %t1690)
  %t1694 = insertvalue { i64, ptr } undef, i64 %t1689, 0
  %t1695 = insertvalue { i64, ptr } %t1694, ptr %t1693, 1
  store { i64, ptr } %t1695, ptr %l389, !tbaa !27
  %t1696 = getelementptr { i64, ptr }, ptr %l389, i32 0, i32 1
  %t1697 = load ptr, ptr %t1696, !tbaa !27
  %t1698 = getelementptr { i64, ptr }, ptr %l387, i32 0, i32 1
  %t1699 = load ptr, ptr %t1698, !tbaa !27
  %t1700 = load i64, ptr %l388, !tbaa !24
  %t1701 = mul i64 %t1700, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1697, ptr %t1699, i64 %t1701, i1 false)
  %t1702 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t1703 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1704 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1703, i32 0, i32 2
  store { i64, ptr } %t1702, ptr %t1704, !tbaa !27
  %t1705 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1705, label %bb231, label %bb232
bb231:
  %t1707 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1708 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1707, i32 0, i32 2
  %t1709 = load { i64, ptr }, ptr %t1708, !tbaa !27
  %t1710 = extractvalue { i64, ptr } %t1709, 0
  %t1712 = icmp eq i64 %t1710, 0
  br i1 %t1712, label %bb233, label %bb234
bb232:
  %t1714 = call ptr @__olang_scope_hold(ptr %s0)
  %t1715 = ptrtoint ptr %t1714 to i64
  store i64 %t1715, ptr %l393, !tbaa !24
  %t1716 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1716, label %bb235, label %bb236
bb233:
  %t1718 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1719 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1718, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t1719, !tbaa !27
  br label %bb234
bb234:
  %t1720 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 3
  %t1721 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1720, i32 0, i32 2
  %t1722 = load i64, ptr %l385
  %t1723 = inttoptr i64 %t1722 to ptr
  %t1724 = load { i64, ptr }, ptr %t1721
  %t1725 = extractvalue { i64, ptr } %t1724, 1
  %t1726 = call ptr @__olang_region_or(ptr %t1725, ptr null)
  %t1727 = icmp ne ptr %t1726, null
  %t1728 = select i1 %t1727, ptr %t1726, ptr null
  call void @__olang_region_settle_in(ptr %t1723, ptr %t1728)
  br label %bb232
bb235:
  %t1729 = call ptr @__olang_region_make_part(ptr %s0)
  %t1730 = ptrtoint ptr %t1729 to i64
  store i64 %t1730, ptr %l393, !tbaa !24
  br label %bb236
bb236:
  %t1731 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1732 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1731, i32 0, i32 0
  %t1733 = load { i64, ptr }, ptr %t1732, !tbaa !27
  store { i64, ptr } %t1733, ptr %l395, !tbaa !27
  %t1734 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t1735 = extractvalue { i64, ptr } %t1734, 0
  store i64 %t1735, ptr %l396, !tbaa !24
  %t1736 = load i64, ptr %l396, !tbaa !24
  %t1737 = mul i64 %t1736, 16
  %t1738 = load i64, ptr %l393
  %t1739 = inttoptr i64 %t1738 to ptr
  %t1740 = call ptr @__olang_held_alloc(ptr %t1739, i64 %t1737)
  %t1741 = insertvalue { i64, ptr } undef, i64 %t1736, 0
  %t1742 = insertvalue { i64, ptr } %t1741, ptr %t1740, 1
  store { i64, ptr } %t1742, ptr %l397, !tbaa !27
  %t1743 = getelementptr { i64, ptr }, ptr %l397, i32 0, i32 1
  %t1744 = load ptr, ptr %t1743, !tbaa !27
  %t1745 = getelementptr { i64, ptr }, ptr %l395, i32 0, i32 1
  %t1746 = load ptr, ptr %t1745, !tbaa !27
  %t1747 = load i64, ptr %l396, !tbaa !24
  %t1748 = mul i64 %t1747, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t1744, ptr %t1746, i64 %t1748, i1 false)
  %t1749 = load { i64, ptr }, ptr %l397, !tbaa !27
  %t1750 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1751 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1750, i32 0, i32 0
  store { i64, ptr } %t1749, ptr %t1751, !tbaa !27
  %t1752 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t1752, label %bb237, label %bb238
bb237:
  %t1754 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1755 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1754, i32 0, i32 0
  %t1756 = load { i64, ptr }, ptr %t1755, !tbaa !27
  %t1757 = extractvalue { i64, ptr } %t1756, 0
  %t1759 = icmp eq i64 %t1757, 0
  br i1 %t1759, label %bb239, label %bb240
bb238:
  %t1761 = call ptr @__olang_scope_hold(ptr %s0)
  %t1762 = ptrtoint ptr %t1761 to i64
  store i64 %t1762, ptr %l401, !tbaa !24
  %t1763 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1763, label %bb241, label %bb242
bb239:
  %t1765 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1766 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1765, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1766, !tbaa !27
  br label %bb240
bb240:
  %t1767 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1768 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1767, i32 0, i32 0
  %t1769 = load i64, ptr %l393
  %t1770 = inttoptr i64 %t1769 to ptr
  %t1771 = load { i64, ptr }, ptr %t1768
  %t1772 = extractvalue { i64, ptr } %t1771, 1
  %t1773 = call ptr @__olang_region_or(ptr %t1772, ptr null)
  %t1774 = icmp ne ptr %t1773, null
  %t1775 = select i1 %t1774, ptr %t1773, ptr null
  call void @__olang_region_settle_in(ptr %t1770, ptr %t1775)
  br label %bb238
bb241:
  %t1776 = call ptr @__olang_region_make_part(ptr %s0)
  %t1777 = ptrtoint ptr %t1776 to i64
  store i64 %t1777, ptr %l401, !tbaa !24
  br label %bb242
bb242:
  %t1778 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1779 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1778, i32 0, i32 1
  %t1780 = load { i64, ptr }, ptr %t1779, !tbaa !27
  store { i64, ptr } %t1780, ptr %l403, !tbaa !27
  %t1781 = load { i64, ptr }, ptr %l403, !tbaa !27
  %t1782 = extractvalue { i64, ptr } %t1781, 0
  store i64 %t1782, ptr %l404, !tbaa !24
  %t1783 = load i64, ptr %l404, !tbaa !24
  %t1784 = mul i64 %t1783, 8
  %t1785 = load i64, ptr %l401
  %t1786 = inttoptr i64 %t1785 to ptr
  %t1787 = call ptr @__olang_held_alloc(ptr %t1786, i64 %t1784)
  %t1788 = insertvalue { i64, ptr } undef, i64 %t1783, 0
  %t1789 = insertvalue { i64, ptr } %t1788, ptr %t1787, 1
  store { i64, ptr } %t1789, ptr %l405, !tbaa !27
  %t1790 = getelementptr { i64, ptr }, ptr %l405, i32 0, i32 1
  %t1791 = load ptr, ptr %t1790, !tbaa !27
  %t1792 = getelementptr { i64, ptr }, ptr %l403, i32 0, i32 1
  %t1793 = load ptr, ptr %t1792, !tbaa !27
  %t1794 = load i64, ptr %l404, !tbaa !24
  %t1795 = mul i64 %t1794, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1791, ptr %t1793, i64 %t1795, i1 false)
  %t1796 = load { i64, ptr }, ptr %l405, !tbaa !27
  %t1797 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1798 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1797, i32 0, i32 1
  store { i64, ptr } %t1796, ptr %t1798, !tbaa !27
  %t1799 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t1799, label %bb243, label %bb244
bb243:
  %t1801 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1802 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1801, i32 0, i32 1
  %t1803 = load { i64, ptr }, ptr %t1802, !tbaa !27
  %t1804 = extractvalue { i64, ptr } %t1803, 0
  %t1806 = icmp eq i64 %t1804, 0
  br i1 %t1806, label %bb245, label %bb246
bb244:
  %t1808 = call ptr @__olang_scope_hold(ptr %s0)
  %t1809 = ptrtoint ptr %t1808 to i64
  store i64 %t1809, ptr %l409, !tbaa !24
  %t1810 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1810, label %bb247, label %bb248
bb245:
  %t1812 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1813 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1812, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t1813, !tbaa !27
  br label %bb246
bb246:
  %t1814 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1815 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1814, i32 0, i32 1
  %t1816 = load i64, ptr %l401
  %t1817 = inttoptr i64 %t1816 to ptr
  %t1818 = load { i64, ptr }, ptr %t1815
  %t1819 = extractvalue { i64, ptr } %t1818, 1
  %t1820 = call ptr @__olang_region_or(ptr %t1819, ptr null)
  %t1821 = icmp ne ptr %t1820, null
  %t1822 = select i1 %t1821, ptr %t1820, ptr null
  call void @__olang_region_settle_in(ptr %t1817, ptr %t1822)
  br label %bb244
bb247:
  %t1823 = call ptr @__olang_region_make_part(ptr %s0)
  %t1824 = ptrtoint ptr %t1823 to i64
  store i64 %t1824, ptr %l409, !tbaa !24
  br label %bb248
bb248:
  %t1825 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1826 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1825, i32 0, i32 2
  %t1827 = load { i64, ptr }, ptr %t1826, !tbaa !27
  store { i64, ptr } %t1827, ptr %l411, !tbaa !27
  %t1828 = load { i64, ptr }, ptr %l411, !tbaa !27
  %t1829 = extractvalue { i64, ptr } %t1828, 0
  store i64 %t1829, ptr %l412, !tbaa !24
  %t1830 = load i64, ptr %l412, !tbaa !24
  %t1831 = mul i64 %t1830, 8
  %t1832 = load i64, ptr %l409
  %t1833 = inttoptr i64 %t1832 to ptr
  %t1834 = call ptr @__olang_held_alloc(ptr %t1833, i64 %t1831)
  %t1835 = insertvalue { i64, ptr } undef, i64 %t1830, 0
  %t1836 = insertvalue { i64, ptr } %t1835, ptr %t1834, 1
  store { i64, ptr } %t1836, ptr %l413, !tbaa !27
  %t1837 = getelementptr { i64, ptr }, ptr %l413, i32 0, i32 1
  %t1838 = load ptr, ptr %t1837, !tbaa !27
  %t1839 = getelementptr { i64, ptr }, ptr %l411, i32 0, i32 1
  %t1840 = load ptr, ptr %t1839, !tbaa !27
  %t1841 = load i64, ptr %l412, !tbaa !24
  %t1842 = mul i64 %t1841, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1838, ptr %t1840, i64 %t1842, i1 false)
  %t1843 = load { i64, ptr }, ptr %l413, !tbaa !27
  %t1844 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1845 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1844, i32 0, i32 2
  store { i64, ptr } %t1843, ptr %t1845, !tbaa !27
  %t1846 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t1846, label %bb249, label %bb250
bb249:
  %t1848 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1849 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1848, i32 0, i32 2
  %t1850 = load { i64, ptr }, ptr %t1849, !tbaa !27
  %t1851 = extractvalue { i64, ptr } %t1850, 0
  %t1853 = icmp eq i64 %t1851, 0
  br i1 %t1853, label %bb251, label %bb252
bb250:
  %t1855 = call ptr @__olang_scope_hold(ptr %s0)
  %t1856 = ptrtoint ptr %t1855 to i64
  store i64 %t1856, ptr %l417, !tbaa !24
  %t1857 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1857, label %bb253, label %bb254
bb251:
  %t1859 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1860 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1859, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t1860, !tbaa !27
  br label %bb252
bb252:
  %t1861 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 4
  %t1862 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1861, i32 0, i32 2
  %t1863 = load i64, ptr %l409
  %t1864 = inttoptr i64 %t1863 to ptr
  %t1865 = load { i64, ptr }, ptr %t1862
  %t1866 = extractvalue { i64, ptr } %t1865, 1
  %t1867 = call ptr @__olang_region_or(ptr %t1866, ptr null)
  %t1868 = icmp ne ptr %t1867, null
  %t1869 = select i1 %t1868, ptr %t1867, ptr null
  call void @__olang_region_settle_in(ptr %t1864, ptr %t1869)
  br label %bb250
bb253:
  %t1870 = call ptr @__olang_region_make_part(ptr %s0)
  %t1871 = ptrtoint ptr %t1870 to i64
  store i64 %t1871, ptr %l417, !tbaa !24
  br label %bb254
bb254:
  %t1872 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 5
  %t1873 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1872, i32 0, i32 0
  %t1874 = load { i64, ptr }, ptr %t1873, !tbaa !27
  store { i64, ptr } %t1874, ptr %l419, !tbaa !27
  %t1875 = load { i64, ptr }, ptr %l419, !tbaa !27
  %t1876 = extractvalue { i64, ptr } %t1875, 0
  store i64 %t1876, ptr %l420, !tbaa !24
  %t1877 = load i64, ptr %l420, !tbaa !24
  %t1878 = mul i64 %t1877, 8
  %t1879 = load i64, ptr %l417
  %t1880 = inttoptr i64 %t1879 to ptr
  %t1881 = call ptr @__olang_held_alloc(ptr %t1880, i64 %t1878)
  %t1882 = insertvalue { i64, ptr } undef, i64 %t1877, 0
  %t1883 = insertvalue { i64, ptr } %t1882, ptr %t1881, 1
  store { i64, ptr } %t1883, ptr %l421, !tbaa !27
  %t1884 = getelementptr { i64, ptr }, ptr %l421, i32 0, i32 1
  %t1885 = load ptr, ptr %t1884, !tbaa !27
  %t1886 = getelementptr { i64, ptr }, ptr %l419, i32 0, i32 1
  %t1887 = load ptr, ptr %t1886, !tbaa !27
  %t1888 = load i64, ptr %l420, !tbaa !24
  %t1889 = mul i64 %t1888, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1885, ptr %t1887, i64 %t1889, i1 false)
  %t1890 = load { i64, ptr }, ptr %l421, !tbaa !27
  %t1891 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 5
  %t1892 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1891, i32 0, i32 0
  store { i64, ptr } %t1890, ptr %t1892, !tbaa !27
  %t1893 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1893, label %bb255, label %bb256
bb255:
  %t1895 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 5
  %t1896 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1895, i32 0, i32 0
  %t1897 = load { i64, ptr }, ptr %t1896, !tbaa !27
  %t1898 = extractvalue { i64, ptr } %t1897, 0
  %t1900 = icmp eq i64 %t1898, 0
  br i1 %t1900, label %bb257, label %bb258
bb256:
  %t1902 = call ptr @__olang_scope_hold(ptr %s0)
  %t1903 = ptrtoint ptr %t1902 to i64
  store i64 %t1903, ptr %l425, !tbaa !24
  %t1904 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1904, label %bb259, label %bb260
bb257:
  %t1906 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 5
  %t1907 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1906, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1907, !tbaa !27
  br label %bb258
bb258:
  %t1908 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 5
  %t1909 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1908, i32 0, i32 0
  %t1910 = load i64, ptr %l417
  %t1911 = inttoptr i64 %t1910 to ptr
  %t1912 = load { i64, ptr }, ptr %t1909
  %t1913 = extractvalue { i64, ptr } %t1912, 1
  %t1914 = call ptr @__olang_region_or(ptr %t1913, ptr null)
  %t1915 = icmp ne ptr %t1914, null
  %t1916 = select i1 %t1915, ptr %t1914, ptr null
  call void @__olang_region_settle_in(ptr %t1911, ptr %t1916)
  br label %bb256
bb259:
  %t1917 = call ptr @__olang_region_make_part(ptr %s0)
  %t1918 = ptrtoint ptr %t1917 to i64
  store i64 %t1918, ptr %l425, !tbaa !24
  br label %bb260
bb260:
  %t1919 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 6
  %t1920 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1919, i32 0, i32 0
  %t1921 = load { i64, ptr }, ptr %t1920, !tbaa !27
  store { i64, ptr } %t1921, ptr %l427, !tbaa !27
  %t1922 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t1923 = extractvalue { i64, ptr } %t1922, 0
  store i64 %t1923, ptr %l428, !tbaa !24
  %t1924 = load i64, ptr %l428, !tbaa !24
  %t1925 = mul i64 %t1924, 8
  %t1926 = load i64, ptr %l425
  %t1927 = inttoptr i64 %t1926 to ptr
  %t1928 = call ptr @__olang_held_alloc(ptr %t1927, i64 %t1925)
  %t1929 = insertvalue { i64, ptr } undef, i64 %t1924, 0
  %t1930 = insertvalue { i64, ptr } %t1929, ptr %t1928, 1
  store { i64, ptr } %t1930, ptr %l429, !tbaa !27
  %t1931 = getelementptr { i64, ptr }, ptr %l429, i32 0, i32 1
  %t1932 = load ptr, ptr %t1931, !tbaa !27
  %t1933 = getelementptr { i64, ptr }, ptr %l427, i32 0, i32 1
  %t1934 = load ptr, ptr %t1933, !tbaa !27
  %t1935 = load i64, ptr %l428, !tbaa !24
  %t1936 = mul i64 %t1935, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t1932, ptr %t1934, i64 %t1936, i1 false)
  %t1937 = load { i64, ptr }, ptr %l429, !tbaa !27
  %t1938 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 6
  %t1939 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1938, i32 0, i32 0
  store { i64, ptr } %t1937, ptr %t1939, !tbaa !27
  %t1940 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1940, label %bb261, label %bb262
bb261:
  %t1942 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 6
  %t1943 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1942, i32 0, i32 0
  %t1944 = load { i64, ptr }, ptr %t1943, !tbaa !27
  %t1945 = extractvalue { i64, ptr } %t1944, 0
  %t1947 = icmp eq i64 %t1945, 0
  br i1 %t1947, label %bb263, label %bb264
bb262:
  %t1949 = load ptr, ptr %l2, !tbaa !29
  %t1950 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr null, i32 1
  %t1951 = ptrtoint ptr %t1950 to i64
  %t1953 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t1952, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t1953, ptr %l296, i64 424, i1 false)
  %t1954 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t1952, i32 0, i32 1
  store ptr %t1949, ptr %t1954, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t1956 = call ptr @__olang_scope_hold(ptr %s0)
  %t1957 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t1952, i32 0, i32 2
  store ptr %t1956, ptr %t1957, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t1958 = call ptr @__olang_scope_hold(ptr %v2)
  %t1959 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %t1952, i32 0, i32 3
  store ptr %t1958, ptr %t1959, !tbaa !28
  %t1960 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_80, 0
  %t1961 = insertvalue { ptr, ptr } %t1960, ptr %t1952, 1
  %t1962 = load ptr, ptr %l294, !tbaa !29
  %t1964 = extractvalue { ptr, ptr } %t1961, 0
  %t1965 = extractvalue { ptr, ptr } %t1961, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s0, ptr %t1962, ptr %t1964, ptr %t1965)
  br label %bb265
bb263:
  %t1966 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 6
  %t1967 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1966, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t1967, !tbaa !27
  br label %bb264
bb264:
  %t1968 = getelementptr %"compiler/profile:Tally", ptr %l296, i32 0, i32 6
  %t1969 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1968, i32 0, i32 0
  %t1970 = load i64, ptr %l425
  %t1971 = inttoptr i64 %t1970 to ptr
  %t1972 = load { i64, ptr }, ptr %t1969
  %t1973 = extractvalue { i64, ptr } %t1972, 1
  %t1974 = call ptr @__olang_region_or(ptr %t1973, ptr null)
  %t1975 = icmp ne ptr %t1974, null
  %t1976 = select i1 %t1975, ptr %t1974, ptr null
  call void @__olang_region_settle_in(ptr %t1971, ptr %t1976)
  br label %bb262
bb265:
  %t1977 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1977, ptr %l435
  br label %bb266
bb266:
  %t1978 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l435
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1978, ptr %l15
  store ptr %l14, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb267
bb267:
  store %olang.scope zeroinitializer, ptr %s11
  %t1980 = load i64, ptr %l17, !tbaa !24
  store i64 %t1980, ptr %l437, !tbaa !24
  %t1981 = load ptr, ptr %l16, !tbaa !29
  %t1983 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t1981)
  store i64 %t1983, ptr %l439
  br label %bb268
bb268:
  %t1984 = load i64, ptr %l437, !tbaa !24
  %t1985 = load i64, ptr %l439, !tbaa !24
  %t1986 = icmp slt i64 %t1984, %t1985
  %t1988 = xor i1 %t1986, true
  br i1 %t1988, label %bb269, label %bb270
bb269:
  call void @__olang_scope_close(ptr %s11)
  br label %bb291
bb270:
  br label %bb271
bb271:
  %t1990 = load ptr, ptr %l16, !tbaa !29
  %t1991 = load i64, ptr %l17, !tbaa !24
  %t1994 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t1990, i64 %t1991)
  store i64 %t1994, ptr %l444
  br label %bb272
bb272:
  %t1995 = load i64, ptr %l444, !tbaa !24
  store i64 %t1995, ptr %l18, !tbaa !24
  %t1996 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 2
  %t1997 = load i64, ptr %l18, !tbaa !24
  %t2000 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t1996, i64 %t1997)
  %t2001 = extractvalue { i32, i64 } %t2000, 1
  %t2002 = extractvalue { i32, i64 } %t2000, 0
  store i32 %t2002, ptr %l449
  %t2003 = icmp ne i32 %t2002, 0
  br i1 %t2003, label %bb274, label %ok.2004, !prof !99
ok.2004:
  store i64 %t2001, ptr %l448
  br label %bb273
bb273:
  %t2005 = load i64, ptr %l448, !tbaa !24
  store i64 %t2005, ptr %l445, !tbaa !24
  br label %bb276
bb274:
  br label %bb275
bb275:
  store i64 0, ptr %l445, !tbaa !24
  br label %bb276
bb276:
  %t2006 = load i64, ptr %l445, !tbaa !24
  store i64 %t2006, ptr %l19, !tbaa !24
  %t2008 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l15)
  store i64 %t2008, ptr %l451
  br label %bb277
bb277:
  %t2009 = load i64, ptr %l451, !tbaa !24
  %t2010 = icmp sge i64 %t2009, 15
  br i1 %t2010, label %bb278, label %bb279
bb278:
  store i1 true, ptr %l453, !tbaa !21
  br label %bb280
bb279:
  %t2012 = load i64, ptr %l19, !tbaa !24
  %t2014 = mul i64 %t2012, 200
  %t2015 = load i64, ptr %l4, !tbaa !24
  %t2018 = icmp slt i64 %t2014, %t2015
  store i1 %t2018, ptr %l453, !tbaa !21
  br label %bb280
bb280:
  %t2020 = load i1, ptr %l453, !tbaa !21
  br i1 %t2020, label %bb281, label %bb282
bb281:
  call void @__olang_scope_close(ptr %s11)
  br label %bb291
bb282:
  br label %bb283
bb283:
  %t2021 = load ptr, ptr %l2, !tbaa !29
  %t2023 = getelementptr %"compiler/profile:Places", ptr %t2021, i32 0, i32 0
  %t2024 = load i64, ptr %l18, !tbaa !24
  %t2027 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t2023, i64 %t2024)
  store { i64, ptr } %t2027, ptr %l461
  br label %bb284
bb284:
  %t2028 = load { i64, ptr }, ptr %l461, !tbaa !27
  %t2029 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v2, ptr %s11, { i64, ptr } %t2028, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t2029, ptr %l462
  br label %bb285
bb285:
  %t2030 = load i1, ptr %l462, !tbaa !21
  br i1 %t2030, label %bb286, label %bb287
bb286:
  call void @__olang_scope_close(ptr %s11)
  br label %bb290
bb287:
  br label %bb288
bb288:
  %t2031 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l15, i64 %t2031)
  br label %bb289
bb289:
  call void @__olang_scope_close(ptr %s11)
  br label %bb290
bb290:
  %t2034 = load i64, ptr %l17, !tbaa !24
  %t2037 = add i64 %t2034, 1
  store i64 %t2037, ptr %l17, !tbaa !24
  br label %bb267
bb291:
  store i64 4, ptr %l20, !tbaa !24
  store ptr %l15, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb292
bb292:
  store %olang.scope zeroinitializer, ptr %s16
  %t2040 = load i64, ptr %l22, !tbaa !24
  store i64 %t2040, ptr %l469, !tbaa !24
  %t2041 = load ptr, ptr %l21, !tbaa !29
  %t2043 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t2041)
  store i64 %t2043, ptr %l471
  br label %bb293
bb293:
  %t2044 = load i64, ptr %l469, !tbaa !24
  %t2045 = load i64, ptr %l471, !tbaa !24
  %t2046 = icmp slt i64 %t2044, %t2045
  %t2048 = xor i1 %t2046, true
  br i1 %t2048, label %bb294, label %bb295
bb294:
  call void @__olang_scope_close(ptr %s16)
  br label %bb306
bb295:
  br label %bb296
bb296:
  %t2050 = load ptr, ptr %l21, !tbaa !29
  %t2051 = load i64, ptr %l22, !tbaa !24
  %t2054 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2050, i64 %t2051)
  store i64 %t2054, ptr %l476
  br label %bb297
bb297:
  %t2055 = load i64, ptr %l476, !tbaa !24
  store i64 %t2055, ptr %l23, !tbaa !24
  %t2056 = load ptr, ptr %l2, !tbaa !29
  %t2058 = getelementptr %"compiler/profile:Places", ptr %t2056, i32 0, i32 0
  %t2059 = load i64, ptr %l23, !tbaa !24
  %t2062 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t2058, i64 %t2059)
  store { i64, ptr } %t2062, ptr %l480
  br label %bb298
bb298:
  %t2063 = load { i64, ptr }, ptr %l480, !tbaa !27
  %t2064 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s16, { i64, ptr } %t2063)
  store { i64, ptr } %t2064, ptr %l481
  br label %bb299
bb299:
  %t2065 = load { i64, ptr }, ptr %l481, !tbaa !27
  %t2066 = extractvalue { i64, ptr } %t2065, 0
  store i64 %t2066, ptr %l482, !tbaa !24
  %t2067 = load i64, ptr %l482, !tbaa !24
  %t2068 = mul i64 %t2067, 1
  %t2069 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t2068)
  %t2070 = insertvalue { i64, ptr } undef, i64 %t2067, 0
  %t2071 = insertvalue { i64, ptr } %t2070, ptr %t2069, 1
  store { i64, ptr } %t2071, ptr %l483, !tbaa !27
  %t2072 = getelementptr { i64, ptr }, ptr %l483, i32 0, i32 1
  %t2073 = load ptr, ptr %t2072, !tbaa !27
  %t2074 = getelementptr { i64, ptr }, ptr %l481, i32 0, i32 1
  %t2075 = load ptr, ptr %t2074, !tbaa !27
  %t2076 = load i64, ptr %l482, !tbaa !24
  %t2077 = mul i64 %t2076, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2073, ptr %t2075, i64 %t2077, i1 false)
  %t2078 = load { i64, ptr }, ptr %l483, !tbaa !27
  %t2079 = extractvalue { i64, ptr } %t2078, 0
  %t2080 = load i64, ptr %l20, !tbaa !24
  %t2083 = icmp sgt i64 %t2079, %t2080
  br i1 %t2083, label %bb300, label %bb301
bb300:
  store %olang.scope zeroinitializer, ptr %s17
  %t2085 = load ptr, ptr %l2, !tbaa !29
  %t2087 = getelementptr %"compiler/profile:Places", ptr %t2085, i32 0, i32 0
  %t2088 = load i64, ptr %l23, !tbaa !24
  %t2091 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t2087, i64 %t2088)
  store { i64, ptr } %t2091, ptr %l490
  br label %bb302
bb301:
  br label %bb304
bb302:
  %t2092 = load { i64, ptr }, ptr %l490, !tbaa !27
  %t2093 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s17, { i64, ptr } %t2092)
  store { i64, ptr } %t2093, ptr %l491
  br label %bb303
bb303:
  %t2094 = load { i64, ptr }, ptr %l491, !tbaa !27
  %t2095 = extractvalue { i64, ptr } %t2094, 0
  store i64 %t2095, ptr %l492, !tbaa !24
  %t2096 = load i64, ptr %l492, !tbaa !24
  %t2097 = mul i64 %t2096, 1
  %t2098 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t2097)
  %t2099 = insertvalue { i64, ptr } undef, i64 %t2096, 0
  %t2100 = insertvalue { i64, ptr } %t2099, ptr %t2098, 1
  store { i64, ptr } %t2100, ptr %l493, !tbaa !27
  %t2101 = getelementptr { i64, ptr }, ptr %l493, i32 0, i32 1
  %t2102 = load ptr, ptr %t2101, !tbaa !27
  %t2103 = getelementptr { i64, ptr }, ptr %l491, i32 0, i32 1
  %t2104 = load ptr, ptr %t2103, !tbaa !27
  %t2105 = load i64, ptr %l492, !tbaa !24
  %t2106 = mul i64 %t2105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2102, ptr %t2104, i64 %t2106, i1 false)
  %t2107 = load { i64, ptr }, ptr %l493, !tbaa !27
  %t2108 = extractvalue { i64, ptr } %t2107, 0
  store i64 %t2108, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb304
bb304:
  call void @__olang_scope_close(ptr %s16)
  br label %bb305
bb305:
  %t2110 = load i64, ptr %l22, !tbaa !24
  %t2113 = add i64 %t2110, 1
  store i64 %t2113, ptr %l22, !tbaa !24
  br label %bb292
bb306:
  store ptr %l5, ptr %l498, !tbaa !29
  %t2115 = load i64, ptr %l20, !tbaa !24
  %t2117 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d82, i32 0, i32 1) }, i64 %t2115, i8 32)
  store { i64, ptr } %t2117, ptr %l500
  br label %bb307
bb307:
  %t2118 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t2119 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t2120 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t2121 = extractvalue { i64, ptr } %t2120, 1
  %t2122 = extractvalue { i64, ptr } %t2120, 0
  %t2123 = add i64 %t2119, %t2122
  %t2124 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t2125 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t2126 = add i64 %t2123, %t2125
  %t2127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t2126)
  call void @olang_textcopy(ptr %t2127, ptr %t2118, i64 %t2119)
  %t2128 = getelementptr i8, ptr %t2127, i64 %t2119
  call void @olang_textcopy(ptr %t2128, ptr %t2121, i64 %t2122)
  %t2129 = getelementptr i8, ptr %t2128, i64 %t2122
  call void @olang_textcopy(ptr %t2129, ptr %t2124, i64 %t2125)
  %t2130 = insertvalue { i64, ptr } undef, i64 %t2126, 0
  %t2131 = insertvalue { i64, ptr } %t2130, ptr %t2127, 1
  %t2133 = load ptr, ptr %l498, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t2133, { i64, ptr } %t2131)
  br label %bb308
bb308:
  store ptr %l15, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb309
bb309:
  store %olang.scope zeroinitializer, ptr %s21
  %t2136 = load i64, ptr %l25, !tbaa !24
  store i64 %t2136, ptr %l504, !tbaa !24
  %t2137 = load ptr, ptr %l24, !tbaa !29
  %t2139 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t2137)
  store i64 %t2139, ptr %l506
  br label %bb310
bb310:
  %t2140 = load i64, ptr %l504, !tbaa !24
  %t2141 = load i64, ptr %l506, !tbaa !24
  %t2142 = icmp slt i64 %t2140, %t2141
  %t2144 = xor i1 %t2142, true
  br i1 %t2144, label %bb311, label %bb312
bb311:
  call void @__olang_scope_close(ptr %s21)
  br label %bb331
bb312:
  br label %bb313
bb313:
  %t2146 = load ptr, ptr %l24, !tbaa !29
  %t2147 = load i64, ptr %l25, !tbaa !24
  %t2150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2146, i64 %t2147)
  store i64 %t2150, ptr %l511
  br label %bb314
bb314:
  %t2151 = load i64, ptr %l511, !tbaa !24
  store i64 %t2151, ptr %l26, !tbaa !24
  %t2152 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 2
  %t2153 = load i64, ptr %l26, !tbaa !24
  %t2156 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t2152, i64 %t2153)
  %t2157 = extractvalue { i32, i64 } %t2156, 1
  %t2158 = extractvalue { i32, i64 } %t2156, 0
  store i32 %t2158, ptr %l516
  %t2159 = icmp ne i32 %t2158, 0
  br i1 %t2159, label %bb316, label %ok.2160, !prof !99
ok.2160:
  store i64 %t2157, ptr %l515
  br label %bb315
bb315:
  %t2161 = load i64, ptr %l515, !tbaa !24
  store i64 %t2161, ptr %l512, !tbaa !24
  br label %bb318
bb316:
  br label %bb317
bb317:
  store i64 0, ptr %l512, !tbaa !24
  br label %bb318
bb318:
  %t2162 = load i64, ptr %l512, !tbaa !24
  store i64 %t2162, ptr %l27, !tbaa !24
  %t2163 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 3
  %t2164 = load i64, ptr %l26, !tbaa !24
  %t2167 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t2163, i64 %t2164)
  %t2168 = extractvalue { i32, i64 } %t2167, 1
  %t2169 = extractvalue { i32, i64 } %t2167, 0
  store i32 %t2169, ptr %l521
  %t2170 = icmp ne i32 %t2169, 0
  br i1 %t2170, label %bb320, label %ok.2171, !prof !99
ok.2171:
  store i64 %t2168, ptr %l520
  br label %bb319
bb319:
  %t2172 = load i64, ptr %l520, !tbaa !24
  store i64 %t2172, ptr %l517, !tbaa !24
  br label %bb322
bb320:
  br label %bb321
bb321:
  store i64 0, ptr %l517, !tbaa !24
  br label %bb322
bb322:
  %t2173 = load i64, ptr %l517, !tbaa !24
  store i64 %t2173, ptr %l28, !tbaa !24
  store ptr %l5, ptr %l522, !tbaa !29
  %t2174 = load i64, ptr %l27, !tbaa !24
  %t2175 = load i64, ptr %l4, !tbaa !24
  %t2178 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s21, i64 %t2174, i64 %t2175)
  store { i64, ptr } %t2178, ptr %l525
  br label %bb323
bb323:
  %t2179 = load { i64, ptr }, ptr %l525, !tbaa !27
  %t2181 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s21, ptr %s21, { i64, ptr } %t2179, i64 6, i8 32)
  store { i64, ptr } %t2181, ptr %l527
  br label %bb324
bb324:
  %t2182 = load ptr, ptr %l2, !tbaa !29
  %t2184 = getelementptr %"compiler/profile:Places", ptr %t2182, i32 0, i32 0
  %t2185 = load i64, ptr %l26, !tbaa !24
  %t2188 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t2184, i64 %t2185)
  store { i64, ptr } %t2188, ptr %l531
  br label %bb325
bb325:
  %t2189 = load { i64, ptr }, ptr %l531, !tbaa !27
  %t2190 = call { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v2, ptr %s21, { i64, ptr } %t2189)
  store { i64, ptr } %t2190, ptr %l532
  br label %bb326
bb326:
  %t2191 = load { i64, ptr }, ptr %l532, !tbaa !27
  %t2192 = extractvalue { i64, ptr } %t2191, 0
  store i64 %t2192, ptr %l533, !tbaa !24
  %t2193 = load i64, ptr %l533, !tbaa !24
  %t2194 = mul i64 %t2193, 1
  %t2195 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t2194)
  %t2196 = insertvalue { i64, ptr } undef, i64 %t2193, 0
  %t2197 = insertvalue { i64, ptr } %t2196, ptr %t2195, 1
  store { i64, ptr } %t2197, ptr %l534, !tbaa !27
  %t2198 = getelementptr { i64, ptr }, ptr %l534, i32 0, i32 1
  %t2199 = load ptr, ptr %t2198, !tbaa !27
  %t2200 = getelementptr { i64, ptr }, ptr %l532, i32 0, i32 1
  %t2201 = load ptr, ptr %t2200, !tbaa !27
  %t2202 = load i64, ptr %l533, !tbaa !24
  %t2203 = mul i64 %t2202, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t2199, ptr %t2201, i64 %t2203, i1 false)
  %t2204 = load { i64, ptr }, ptr %l534, !tbaa !27
  %t2205 = extractvalue { i64, ptr } %t2204, 0
  %t2206 = extractvalue { i64, ptr } %t2204, 1
  %t2207 = mul i64 %t2205, 1
  %t2208 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t2207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t2208, ptr %t2206, i64 %t2207, i1 false)
  %t2209 = insertvalue { i64, ptr } undef, i64 %t2205, 0
  %t2210 = insertvalue { i64, ptr } %t2209, ptr %t2208, 1
  %t2211 = load i64, ptr %l20, !tbaa !24
  %t2214 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %s21, ptr %s21, { i64, ptr } %t2210, i64 %t2211, i8 32)
  store { i64, ptr } %t2214, ptr %l537
  br label %bb327
bb327:
  %t2215 = load ptr, ptr %l2, !tbaa !29
  %t2217 = getelementptr %"compiler/profile:Places", ptr %t2215, i32 0, i32 0
  %t2218 = load i64, ptr %l28, !tbaa !24
  %t2221 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s21, ptr %t2217, i64 %t2218)
  store { i64, ptr } %t2221, ptr %l541
  br label %bb328
bb328:
  %t2222 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t2223 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t2224 = load { i64, ptr }, ptr %l527, !tbaa !27
  %t2225 = extractvalue { i64, ptr } %t2224, 1
  %t2226 = extractvalue { i64, ptr } %t2224, 0
  %t2227 = add i64 %t2223, %t2226
  %t2228 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t2229 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t2230 = add i64 %t2227, %t2229
  %t2231 = load { i64, ptr }, ptr %l537, !tbaa !27
  %t2232 = extractvalue { i64, ptr } %t2231, 1
  %t2233 = extractvalue { i64, ptr } %t2231, 0
  %t2234 = add i64 %t2230, %t2233
  %t2235 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t2236 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t2237 = add i64 %t2234, %t2236
  %t2238 = load { i64, ptr }, ptr %l541, !tbaa !27
  %t2239 = extractvalue { i64, ptr } %t2238, 1
  %t2240 = extractvalue { i64, ptr } %t2238, 0
  %t2241 = add i64 %t2237, %t2240
  %t2242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 1
  %t2243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d87, i32 0, i32 1) }, 0
  %t2244 = add i64 %t2241, %t2243
  %t2245 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t2244)
  call void @olang_textcopy(ptr %t2245, ptr %t2222, i64 %t2223)
  %t2246 = getelementptr i8, ptr %t2245, i64 %t2223
  call void @olang_textcopy(ptr %t2246, ptr %t2225, i64 %t2226)
  %t2247 = getelementptr i8, ptr %t2246, i64 %t2226
  call void @olang_textcopy(ptr %t2247, ptr %t2228, i64 %t2229)
  %t2248 = getelementptr i8, ptr %t2247, i64 %t2229
  call void @olang_textcopy(ptr %t2248, ptr %t2232, i64 %t2233)
  %t2249 = getelementptr i8, ptr %t2248, i64 %t2233
  call void @olang_textcopy(ptr %t2249, ptr %t2235, i64 %t2236)
  %t2250 = getelementptr i8, ptr %t2249, i64 %t2236
  call void @olang_textcopy(ptr %t2250, ptr %t2239, i64 %t2240)
  %t2251 = getelementptr i8, ptr %t2250, i64 %t2240
  call void @olang_textcopy(ptr %t2251, ptr %t2242, i64 %t2243)
  %t2252 = insertvalue { i64, ptr } undef, i64 %t2244, 0
  %t2253 = insertvalue { i64, ptr } %t2252, ptr %t2245, 1
  %t2255 = load ptr, ptr %l522, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s21, ptr %t2255, { i64, ptr } %t2253)
  br label %bb329
bb329:
  call void @__olang_scope_close(ptr %s21)
  br label %bb330
bb330:
  %t2257 = load i64, ptr %l25, !tbaa !24
  %t2260 = add i64 %t2257, 1
  store i64 %t2260, ptr %l25, !tbaa !24
  br label %bb309
bb331:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb332
bb332:
  store i64 0, ptr %l8, !tbaa !24
  store ptr %l7, ptr %l29, !tbaa !29
  store i64 0, ptr %l30, !tbaa !24
  br label %bb333
bb333:
  store %olang.scope zeroinitializer, ptr %s25
  %t2264 = load i64, ptr %l30, !tbaa !24
  store i64 %t2264, ptr %l549, !tbaa !24
  %t2265 = load ptr, ptr %l29, !tbaa !29
  %t2267 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t2265)
  store i64 %t2267, ptr %l551
  br label %bb334
bb334:
  %t2268 = load i64, ptr %l549, !tbaa !24
  %t2269 = load i64, ptr %l551, !tbaa !24
  %t2270 = icmp slt i64 %t2268, %t2269
  %t2272 = xor i1 %t2270, true
  br i1 %t2272, label %bb335, label %bb336
bb335:
  call void @__olang_scope_close(ptr %s25)
  br label %bb500
bb336:
  br label %bb337
bb337:
  %t2274 = load ptr, ptr %l29, !tbaa !29
  %t2275 = load i64, ptr %l30, !tbaa !24
  %t2278 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2274, i64 %t2275)
  store i64 %t2278, ptr %l556
  br label %bb338
bb338:
  %t2279 = load i64, ptr %l556, !tbaa !24
  store i64 %t2279, ptr %l31, !tbaa !24
  %t2280 = load i64, ptr %l8, !tbaa !24
  %t2282 = icmp sge i64 %t2280, 5
  br i1 %t2282, label %bb339, label %bb340
bb339:
  call void @__olang_scope_close(ptr %s25)
  br label %bb500
bb340:
  br label %bb341
bb341:
  %t2284 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 0
  %t2285 = load i64, ptr %l31, !tbaa !24
  %t2288 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t2284, i64 %t2285)
  %t2289 = extractvalue { i32, i64 } %t2288, 1
  %t2290 = extractvalue { i32, i64 } %t2288, 0
  store i32 %t2290, ptr %l563
  %t2291 = icmp ne i32 %t2290, 0
  br i1 %t2291, label %bb343, label %ok.2292, !prof !99
ok.2292:
  store i64 %t2289, ptr %l562
  br label %bb342
bb342:
  %t2293 = load i64, ptr %l562, !tbaa !24
  store i64 %t2293, ptr %l559, !tbaa !24
  br label %bb345
bb343:
  br label %bb344
bb344:
  store i64 0, ptr %l559, !tbaa !24
  br label %bb345
bb345:
  %t2294 = load i64, ptr %l559, !tbaa !24
  %t2297 = icmp eq i64 %t2294, 0
  br i1 %t2297, label %bb346, label %bb347
bb346:
  call void @__olang_scope_close(ptr %s25)
  br label %bb500
bb347:
  br label %bb348
bb348:
  %t2299 = load i64, ptr %l8, !tbaa !24
  %t2302 = add i64 %t2299, 1
  store i64 %t2302, ptr %l8, !tbaa !24
  %t2304 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 1
  %t2305 = load i64, ptr %l31, !tbaa !24
  %t2308 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t2304, i64 %t2305)
  %t2309 = extractvalue { i32, i64 } %t2308, 1
  %t2310 = extractvalue { i32, i64 } %t2308, 0
  store i32 %t2310, ptr %l573
  %t2311 = icmp ne i32 %t2310, 0
  br i1 %t2311, label %bb350, label %ok.2312, !prof !99
ok.2312:
  store i64 %t2309, ptr %l572
  br label %bb349
bb349:
  %t2313 = load i64, ptr %l572, !tbaa !24
  store i64 %t2313, ptr %l569, !tbaa !24
  br label %bb352
bb350:
  br label %bb351
bb351:
  store i64 0, ptr %l569, !tbaa !24
  br label %bb352
bb352:
  %t2314 = load i64, ptr %l569, !tbaa !24
  store i64 %t2314, ptr %l33, !tbaa !24
  %t2315 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2315, ptr %l574
  br label %bb353
bb353:
  %t2316 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l574
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2316, ptr %l34
  %t2317 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 5
  store ptr %t2317, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb354
bb354:
  %t2319 = load i64, ptr %l36, !tbaa !24
  store i64 %t2319, ptr %l576, !tbaa !24
  %t2320 = load ptr, ptr %l35, !tbaa !29
  %t2322 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t2320)
  store i64 %t2322, ptr %l578
  br label %bb355
bb355:
  %t2323 = load i64, ptr %l576, !tbaa !24
  %t2324 = load i64, ptr %l578, !tbaa !24
  %t2325 = icmp slt i64 %t2323, %t2324
  %t2327 = xor i1 %t2325, true
  br i1 %t2327, label %bb356, label %bb357
bb356:
  br label %bb366
bb357:
  br label %bb358
bb358:
  %t2329 = load ptr, ptr %l35, !tbaa !29
  %t2330 = load i64, ptr %l36, !tbaa !24
  %t2333 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t2329, i64 %t2330)
  store i64 %t2333, ptr %l583
  br label %bb359
bb359:
  %t2334 = load i64, ptr %l583, !tbaa !24
  store i64 %t2334, ptr %l37, !tbaa !24
  %t2335 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 4
  %t2336 = load i64, ptr %l31, !tbaa !24
  %t2338 = mul i64 %t2336, 16777216
  %t2339 = load i64, ptr %l37, !tbaa !24
  %t2342 = add i64 %t2338, %t2339
  %t2345 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %s0, ptr %t2335, i64 %t2342)
  store i1 %t2345, ptr %l589
  br label %bb360
bb360:
  %t2346 = load i1, ptr %l589, !tbaa !21
  br i1 %t2346, label %bb361, label %bb362
bb361:
  %t2347 = load i64, ptr %l37, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s25, ptr %l34, i64 %t2347)
  br label %bb363
bb362:
  br label %bb364
bb363:
  br label %bb364
bb364:
  br label %bb365
bb365:
  %t2350 = load i64, ptr %l36, !tbaa !24
  %t2353 = add i64 %t2350, 1
  store i64 %t2353, ptr %l36, !tbaa !24
  br label %bb354
bb366:
  store ptr %l34, ptr %l595, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l596, ptr %l3, i64 424, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l597, ptr %l596, i64 424, i1 false)
  %t2355 = call ptr @__olang_scope_hold(ptr %s25)
  %t2356 = ptrtoint ptr %t2355 to i64
  store i64 %t2356, ptr %l598, !tbaa !24
  %t2357 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2357, label %bb367, label %bb368
bb367:
  %t2359 = call ptr @__olang_region_make_part(ptr %s25)
  %t2360 = ptrtoint ptr %t2359 to i64
  store i64 %t2360, ptr %l598, !tbaa !24
  br label %bb368
bb368:
  %t2361 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2362 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2361, i32 0, i32 0
  %t2363 = load { i64, ptr }, ptr %t2362, !tbaa !27
  store { i64, ptr } %t2363, ptr %l600, !tbaa !27
  %t2364 = load { i64, ptr }, ptr %l600, !tbaa !27
  %t2365 = extractvalue { i64, ptr } %t2364, 0
  store i64 %t2365, ptr %l601, !tbaa !24
  %t2366 = load i64, ptr %l601, !tbaa !24
  %t2367 = mul i64 %t2366, 16
  %t2368 = load i64, ptr %l598
  %t2369 = inttoptr i64 %t2368 to ptr
  %t2370 = call ptr @__olang_held_alloc(ptr %t2369, i64 %t2367)
  %t2371 = insertvalue { i64, ptr } undef, i64 %t2366, 0
  %t2372 = insertvalue { i64, ptr } %t2371, ptr %t2370, 1
  store { i64, ptr } %t2372, ptr %l602, !tbaa !27
  %t2373 = getelementptr { i64, ptr }, ptr %l602, i32 0, i32 1
  %t2374 = load ptr, ptr %t2373, !tbaa !27
  %t2375 = getelementptr { i64, ptr }, ptr %l600, i32 0, i32 1
  %t2376 = load ptr, ptr %t2375, !tbaa !27
  %t2377 = load i64, ptr %l601, !tbaa !24
  %t2378 = mul i64 %t2377, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t2374, ptr %t2376, i64 %t2378, i1 false)
  %t2379 = load { i64, ptr }, ptr %l602, !tbaa !27
  %t2380 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2381 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2380, i32 0, i32 0
  store { i64, ptr } %t2379, ptr %t2381, !tbaa !27
  %t2382 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2382, label %bb369, label %bb370
bb369:
  %t2384 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2385 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2384, i32 0, i32 0
  %t2386 = load { i64, ptr }, ptr %t2385, !tbaa !27
  %t2387 = extractvalue { i64, ptr } %t2386, 0
  %t2389 = icmp eq i64 %t2387, 0
  br i1 %t2389, label %bb371, label %bb372
bb370:
  %t2391 = call ptr @__olang_scope_hold(ptr %s25)
  %t2392 = ptrtoint ptr %t2391 to i64
  store i64 %t2392, ptr %l606, !tbaa !24
  %t2393 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2393, label %bb373, label %bb374
bb371:
  %t2395 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2396 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2395, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t2396, !tbaa !27
  br label %bb372
bb372:
  %t2397 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2398 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2397, i32 0, i32 0
  %t2399 = load i64, ptr %l598
  %t2400 = inttoptr i64 %t2399 to ptr
  %t2401 = load { i64, ptr }, ptr %t2398
  %t2402 = extractvalue { i64, ptr } %t2401, 1
  %t2403 = call ptr @__olang_region_or(ptr %t2402, ptr null)
  %t2404 = icmp ne ptr %t2403, null
  %t2405 = select i1 %t2404, ptr %t2403, ptr null
  call void @__olang_region_settle_in(ptr %t2400, ptr %t2405)
  br label %bb370
bb373:
  %t2406 = call ptr @__olang_region_make_part(ptr %s25)
  %t2407 = ptrtoint ptr %t2406 to i64
  store i64 %t2407, ptr %l606, !tbaa !24
  br label %bb374
bb374:
  %t2408 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2409 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2408, i32 0, i32 1
  %t2410 = load { i64, ptr }, ptr %t2409, !tbaa !27
  store { i64, ptr } %t2410, ptr %l608, !tbaa !27
  %t2411 = load { i64, ptr }, ptr %l608, !tbaa !27
  %t2412 = extractvalue { i64, ptr } %t2411, 0
  store i64 %t2412, ptr %l609, !tbaa !24
  %t2413 = load i64, ptr %l609, !tbaa !24
  %t2414 = mul i64 %t2413, 8
  %t2415 = load i64, ptr %l606
  %t2416 = inttoptr i64 %t2415 to ptr
  %t2417 = call ptr @__olang_held_alloc(ptr %t2416, i64 %t2414)
  %t2418 = insertvalue { i64, ptr } undef, i64 %t2413, 0
  %t2419 = insertvalue { i64, ptr } %t2418, ptr %t2417, 1
  store { i64, ptr } %t2419, ptr %l610, !tbaa !27
  %t2420 = getelementptr { i64, ptr }, ptr %l610, i32 0, i32 1
  %t2421 = load ptr, ptr %t2420, !tbaa !27
  %t2422 = getelementptr { i64, ptr }, ptr %l608, i32 0, i32 1
  %t2423 = load ptr, ptr %t2422, !tbaa !27
  %t2424 = load i64, ptr %l609, !tbaa !24
  %t2425 = mul i64 %t2424, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2421, ptr %t2423, i64 %t2425, i1 false)
  %t2426 = load { i64, ptr }, ptr %l610, !tbaa !27
  %t2427 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2428 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2427, i32 0, i32 1
  store { i64, ptr } %t2426, ptr %t2428, !tbaa !27
  %t2429 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2429, label %bb375, label %bb376
bb375:
  %t2431 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2432 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2431, i32 0, i32 1
  %t2433 = load { i64, ptr }, ptr %t2432, !tbaa !27
  %t2434 = extractvalue { i64, ptr } %t2433, 0
  %t2436 = icmp eq i64 %t2434, 0
  br i1 %t2436, label %bb377, label %bb378
bb376:
  %t2438 = call ptr @__olang_scope_hold(ptr %s25)
  %t2439 = ptrtoint ptr %t2438 to i64
  store i64 %t2439, ptr %l614, !tbaa !24
  %t2440 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2440, label %bb379, label %bb380
bb377:
  %t2442 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2443 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2442, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t2443, !tbaa !27
  br label %bb378
bb378:
  %t2444 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2445 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2444, i32 0, i32 1
  %t2446 = load i64, ptr %l606
  %t2447 = inttoptr i64 %t2446 to ptr
  %t2448 = load { i64, ptr }, ptr %t2445
  %t2449 = extractvalue { i64, ptr } %t2448, 1
  %t2450 = call ptr @__olang_region_or(ptr %t2449, ptr null)
  %t2451 = icmp ne ptr %t2450, null
  %t2452 = select i1 %t2451, ptr %t2450, ptr null
  call void @__olang_region_settle_in(ptr %t2447, ptr %t2452)
  br label %bb376
bb379:
  %t2453 = call ptr @__olang_region_make_part(ptr %s25)
  %t2454 = ptrtoint ptr %t2453 to i64
  store i64 %t2454, ptr %l614, !tbaa !24
  br label %bb380
bb380:
  %t2455 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2456 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2455, i32 0, i32 2
  %t2457 = load { i64, ptr }, ptr %t2456, !tbaa !27
  store { i64, ptr } %t2457, ptr %l616, !tbaa !27
  %t2458 = load { i64, ptr }, ptr %l616, !tbaa !27
  %t2459 = extractvalue { i64, ptr } %t2458, 0
  store i64 %t2459, ptr %l617, !tbaa !24
  %t2460 = load i64, ptr %l617, !tbaa !24
  %t2461 = mul i64 %t2460, 8
  %t2462 = load i64, ptr %l614
  %t2463 = inttoptr i64 %t2462 to ptr
  %t2464 = call ptr @__olang_held_alloc(ptr %t2463, i64 %t2461)
  %t2465 = insertvalue { i64, ptr } undef, i64 %t2460, 0
  %t2466 = insertvalue { i64, ptr } %t2465, ptr %t2464, 1
  store { i64, ptr } %t2466, ptr %l618, !tbaa !27
  %t2467 = getelementptr { i64, ptr }, ptr %l618, i32 0, i32 1
  %t2468 = load ptr, ptr %t2467, !tbaa !27
  %t2469 = getelementptr { i64, ptr }, ptr %l616, i32 0, i32 1
  %t2470 = load ptr, ptr %t2469, !tbaa !27
  %t2471 = load i64, ptr %l617, !tbaa !24
  %t2472 = mul i64 %t2471, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2468, ptr %t2470, i64 %t2472, i1 false)
  %t2473 = load { i64, ptr }, ptr %l618, !tbaa !27
  %t2474 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2475 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2474, i32 0, i32 2
  store { i64, ptr } %t2473, ptr %t2475, !tbaa !27
  %t2476 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2476, label %bb381, label %bb382
bb381:
  %t2478 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2479 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2478, i32 0, i32 2
  %t2480 = load { i64, ptr }, ptr %t2479, !tbaa !27
  %t2481 = extractvalue { i64, ptr } %t2480, 0
  %t2483 = icmp eq i64 %t2481, 0
  br i1 %t2483, label %bb383, label %bb384
bb382:
  %t2485 = call ptr @__olang_scope_hold(ptr %s25)
  %t2486 = ptrtoint ptr %t2485 to i64
  store i64 %t2486, ptr %l622, !tbaa !24
  %t2487 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2487, label %bb385, label %bb386
bb383:
  %t2489 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2490 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2489, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t2490, !tbaa !27
  br label %bb384
bb384:
  %t2491 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 0
  %t2492 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2491, i32 0, i32 2
  %t2493 = load i64, ptr %l614
  %t2494 = inttoptr i64 %t2493 to ptr
  %t2495 = load { i64, ptr }, ptr %t2492
  %t2496 = extractvalue { i64, ptr } %t2495, 1
  %t2497 = call ptr @__olang_region_or(ptr %t2496, ptr null)
  %t2498 = icmp ne ptr %t2497, null
  %t2499 = select i1 %t2498, ptr %t2497, ptr null
  call void @__olang_region_settle_in(ptr %t2494, ptr %t2499)
  br label %bb382
bb385:
  %t2500 = call ptr @__olang_region_make_part(ptr %s25)
  %t2501 = ptrtoint ptr %t2500 to i64
  store i64 %t2501, ptr %l622, !tbaa !24
  br label %bb386
bb386:
  %t2502 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2503 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2502, i32 0, i32 0
  %t2504 = load { i64, ptr }, ptr %t2503, !tbaa !27
  store { i64, ptr } %t2504, ptr %l624, !tbaa !27
  %t2505 = load { i64, ptr }, ptr %l624, !tbaa !27
  %t2506 = extractvalue { i64, ptr } %t2505, 0
  store i64 %t2506, ptr %l625, !tbaa !24
  %t2507 = load i64, ptr %l625, !tbaa !24
  %t2508 = mul i64 %t2507, 16
  %t2509 = load i64, ptr %l622
  %t2510 = inttoptr i64 %t2509 to ptr
  %t2511 = call ptr @__olang_held_alloc(ptr %t2510, i64 %t2508)
  %t2512 = insertvalue { i64, ptr } undef, i64 %t2507, 0
  %t2513 = insertvalue { i64, ptr } %t2512, ptr %t2511, 1
  store { i64, ptr } %t2513, ptr %l626, !tbaa !27
  %t2514 = getelementptr { i64, ptr }, ptr %l626, i32 0, i32 1
  %t2515 = load ptr, ptr %t2514, !tbaa !27
  %t2516 = getelementptr { i64, ptr }, ptr %l624, i32 0, i32 1
  %t2517 = load ptr, ptr %t2516, !tbaa !27
  %t2518 = load i64, ptr %l625, !tbaa !24
  %t2519 = mul i64 %t2518, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t2515, ptr %t2517, i64 %t2519, i1 false)
  %t2520 = load { i64, ptr }, ptr %l626, !tbaa !27
  %t2521 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2522 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2521, i32 0, i32 0
  store { i64, ptr } %t2520, ptr %t2522, !tbaa !27
  %t2523 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2523, label %bb387, label %bb388
bb387:
  %t2525 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2526 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2525, i32 0, i32 0
  %t2527 = load { i64, ptr }, ptr %t2526, !tbaa !27
  %t2528 = extractvalue { i64, ptr } %t2527, 0
  %t2530 = icmp eq i64 %t2528, 0
  br i1 %t2530, label %bb389, label %bb390
bb388:
  %t2532 = call ptr @__olang_scope_hold(ptr %s25)
  %t2533 = ptrtoint ptr %t2532 to i64
  store i64 %t2533, ptr %l630, !tbaa !24
  %t2534 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2534, label %bb391, label %bb392
bb389:
  %t2536 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2537 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2536, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t2537, !tbaa !27
  br label %bb390
bb390:
  %t2538 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2539 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2538, i32 0, i32 0
  %t2540 = load i64, ptr %l622
  %t2541 = inttoptr i64 %t2540 to ptr
  %t2542 = load { i64, ptr }, ptr %t2539
  %t2543 = extractvalue { i64, ptr } %t2542, 1
  %t2544 = call ptr @__olang_region_or(ptr %t2543, ptr null)
  %t2545 = icmp ne ptr %t2544, null
  %t2546 = select i1 %t2545, ptr %t2544, ptr null
  call void @__olang_region_settle_in(ptr %t2541, ptr %t2546)
  br label %bb388
bb391:
  %t2547 = call ptr @__olang_region_make_part(ptr %s25)
  %t2548 = ptrtoint ptr %t2547 to i64
  store i64 %t2548, ptr %l630, !tbaa !24
  br label %bb392
bb392:
  %t2549 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2550 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2549, i32 0, i32 1
  %t2551 = load { i64, ptr }, ptr %t2550, !tbaa !27
  store { i64, ptr } %t2551, ptr %l632, !tbaa !27
  %t2552 = load { i64, ptr }, ptr %l632, !tbaa !27
  %t2553 = extractvalue { i64, ptr } %t2552, 0
  store i64 %t2553, ptr %l633, !tbaa !24
  %t2554 = load i64, ptr %l633, !tbaa !24
  %t2555 = mul i64 %t2554, 8
  %t2556 = load i64, ptr %l630
  %t2557 = inttoptr i64 %t2556 to ptr
  %t2558 = call ptr @__olang_held_alloc(ptr %t2557, i64 %t2555)
  %t2559 = insertvalue { i64, ptr } undef, i64 %t2554, 0
  %t2560 = insertvalue { i64, ptr } %t2559, ptr %t2558, 1
  store { i64, ptr } %t2560, ptr %l634, !tbaa !27
  %t2561 = getelementptr { i64, ptr }, ptr %l634, i32 0, i32 1
  %t2562 = load ptr, ptr %t2561, !tbaa !27
  %t2563 = getelementptr { i64, ptr }, ptr %l632, i32 0, i32 1
  %t2564 = load ptr, ptr %t2563, !tbaa !27
  %t2565 = load i64, ptr %l633, !tbaa !24
  %t2566 = mul i64 %t2565, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2562, ptr %t2564, i64 %t2566, i1 false)
  %t2567 = load { i64, ptr }, ptr %l634, !tbaa !27
  %t2568 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2569 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2568, i32 0, i32 1
  store { i64, ptr } %t2567, ptr %t2569, !tbaa !27
  %t2570 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2570, label %bb393, label %bb394
bb393:
  %t2572 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2573 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2572, i32 0, i32 1
  %t2574 = load { i64, ptr }, ptr %t2573, !tbaa !27
  %t2575 = extractvalue { i64, ptr } %t2574, 0
  %t2577 = icmp eq i64 %t2575, 0
  br i1 %t2577, label %bb395, label %bb396
bb394:
  %t2579 = call ptr @__olang_scope_hold(ptr %s25)
  %t2580 = ptrtoint ptr %t2579 to i64
  store i64 %t2580, ptr %l638, !tbaa !24
  %t2581 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2581, label %bb397, label %bb398
bb395:
  %t2583 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2584 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2583, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t2584, !tbaa !27
  br label %bb396
bb396:
  %t2585 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2586 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2585, i32 0, i32 1
  %t2587 = load i64, ptr %l630
  %t2588 = inttoptr i64 %t2587 to ptr
  %t2589 = load { i64, ptr }, ptr %t2586
  %t2590 = extractvalue { i64, ptr } %t2589, 1
  %t2591 = call ptr @__olang_region_or(ptr %t2590, ptr null)
  %t2592 = icmp ne ptr %t2591, null
  %t2593 = select i1 %t2592, ptr %t2591, ptr null
  call void @__olang_region_settle_in(ptr %t2588, ptr %t2593)
  br label %bb394
bb397:
  %t2594 = call ptr @__olang_region_make_part(ptr %s25)
  %t2595 = ptrtoint ptr %t2594 to i64
  store i64 %t2595, ptr %l638, !tbaa !24
  br label %bb398
bb398:
  %t2596 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2597 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2596, i32 0, i32 2
  %t2598 = load { i64, ptr }, ptr %t2597, !tbaa !27
  store { i64, ptr } %t2598, ptr %l640, !tbaa !27
  %t2599 = load { i64, ptr }, ptr %l640, !tbaa !27
  %t2600 = extractvalue { i64, ptr } %t2599, 0
  store i64 %t2600, ptr %l641, !tbaa !24
  %t2601 = load i64, ptr %l641, !tbaa !24
  %t2602 = mul i64 %t2601, 8
  %t2603 = load i64, ptr %l638
  %t2604 = inttoptr i64 %t2603 to ptr
  %t2605 = call ptr @__olang_held_alloc(ptr %t2604, i64 %t2602)
  %t2606 = insertvalue { i64, ptr } undef, i64 %t2601, 0
  %t2607 = insertvalue { i64, ptr } %t2606, ptr %t2605, 1
  store { i64, ptr } %t2607, ptr %l642, !tbaa !27
  %t2608 = getelementptr { i64, ptr }, ptr %l642, i32 0, i32 1
  %t2609 = load ptr, ptr %t2608, !tbaa !27
  %t2610 = getelementptr { i64, ptr }, ptr %l640, i32 0, i32 1
  %t2611 = load ptr, ptr %t2610, !tbaa !27
  %t2612 = load i64, ptr %l641, !tbaa !24
  %t2613 = mul i64 %t2612, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2609, ptr %t2611, i64 %t2613, i1 false)
  %t2614 = load { i64, ptr }, ptr %l642, !tbaa !27
  %t2615 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2616 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2615, i32 0, i32 2
  store { i64, ptr } %t2614, ptr %t2616, !tbaa !27
  %t2617 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2617, label %bb399, label %bb400
bb399:
  %t2619 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2620 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2619, i32 0, i32 2
  %t2621 = load { i64, ptr }, ptr %t2620, !tbaa !27
  %t2622 = extractvalue { i64, ptr } %t2621, 0
  %t2624 = icmp eq i64 %t2622, 0
  br i1 %t2624, label %bb401, label %bb402
bb400:
  %t2626 = call ptr @__olang_scope_hold(ptr %s25)
  %t2627 = ptrtoint ptr %t2626 to i64
  store i64 %t2627, ptr %l646, !tbaa !24
  %t2628 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2628, label %bb403, label %bb404
bb401:
  %t2630 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2631 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2630, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t2631, !tbaa !27
  br label %bb402
bb402:
  %t2632 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 1
  %t2633 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2632, i32 0, i32 2
  %t2634 = load i64, ptr %l638
  %t2635 = inttoptr i64 %t2634 to ptr
  %t2636 = load { i64, ptr }, ptr %t2633
  %t2637 = extractvalue { i64, ptr } %t2636, 1
  %t2638 = call ptr @__olang_region_or(ptr %t2637, ptr null)
  %t2639 = icmp ne ptr %t2638, null
  %t2640 = select i1 %t2639, ptr %t2638, ptr null
  call void @__olang_region_settle_in(ptr %t2635, ptr %t2640)
  br label %bb400
bb403:
  %t2641 = call ptr @__olang_region_make_part(ptr %s25)
  %t2642 = ptrtoint ptr %t2641 to i64
  store i64 %t2642, ptr %l646, !tbaa !24
  br label %bb404
bb404:
  %t2643 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2644 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2643, i32 0, i32 0
  %t2645 = load { i64, ptr }, ptr %t2644, !tbaa !27
  store { i64, ptr } %t2645, ptr %l648, !tbaa !27
  %t2646 = load { i64, ptr }, ptr %l648, !tbaa !27
  %t2647 = extractvalue { i64, ptr } %t2646, 0
  store i64 %t2647, ptr %l649, !tbaa !24
  %t2648 = load i64, ptr %l649, !tbaa !24
  %t2649 = mul i64 %t2648, 16
  %t2650 = load i64, ptr %l646
  %t2651 = inttoptr i64 %t2650 to ptr
  %t2652 = call ptr @__olang_held_alloc(ptr %t2651, i64 %t2649)
  %t2653 = insertvalue { i64, ptr } undef, i64 %t2648, 0
  %t2654 = insertvalue { i64, ptr } %t2653, ptr %t2652, 1
  store { i64, ptr } %t2654, ptr %l650, !tbaa !27
  %t2655 = getelementptr { i64, ptr }, ptr %l650, i32 0, i32 1
  %t2656 = load ptr, ptr %t2655, !tbaa !27
  %t2657 = getelementptr { i64, ptr }, ptr %l648, i32 0, i32 1
  %t2658 = load ptr, ptr %t2657, !tbaa !27
  %t2659 = load i64, ptr %l649, !tbaa !24
  %t2660 = mul i64 %t2659, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t2656, ptr %t2658, i64 %t2660, i1 false)
  %t2661 = load { i64, ptr }, ptr %l650, !tbaa !27
  %t2662 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2663 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2662, i32 0, i32 0
  store { i64, ptr } %t2661, ptr %t2663, !tbaa !27
  %t2664 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2664, label %bb405, label %bb406
bb405:
  %t2666 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2667 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2666, i32 0, i32 0
  %t2668 = load { i64, ptr }, ptr %t2667, !tbaa !27
  %t2669 = extractvalue { i64, ptr } %t2668, 0
  %t2671 = icmp eq i64 %t2669, 0
  br i1 %t2671, label %bb407, label %bb408
bb406:
  %t2673 = call ptr @__olang_scope_hold(ptr %s25)
  %t2674 = ptrtoint ptr %t2673 to i64
  store i64 %t2674, ptr %l654, !tbaa !24
  %t2675 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2675, label %bb409, label %bb410
bb407:
  %t2677 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2678 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2677, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t2678, !tbaa !27
  br label %bb408
bb408:
  %t2679 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2680 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2679, i32 0, i32 0
  %t2681 = load i64, ptr %l646
  %t2682 = inttoptr i64 %t2681 to ptr
  %t2683 = load { i64, ptr }, ptr %t2680
  %t2684 = extractvalue { i64, ptr } %t2683, 1
  %t2685 = call ptr @__olang_region_or(ptr %t2684, ptr null)
  %t2686 = icmp ne ptr %t2685, null
  %t2687 = select i1 %t2686, ptr %t2685, ptr null
  call void @__olang_region_settle_in(ptr %t2682, ptr %t2687)
  br label %bb406
bb409:
  %t2688 = call ptr @__olang_region_make_part(ptr %s25)
  %t2689 = ptrtoint ptr %t2688 to i64
  store i64 %t2689, ptr %l654, !tbaa !24
  br label %bb410
bb410:
  %t2690 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2691 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2690, i32 0, i32 1
  %t2692 = load { i64, ptr }, ptr %t2691, !tbaa !27
  store { i64, ptr } %t2692, ptr %l656, !tbaa !27
  %t2693 = load { i64, ptr }, ptr %l656, !tbaa !27
  %t2694 = extractvalue { i64, ptr } %t2693, 0
  store i64 %t2694, ptr %l657, !tbaa !24
  %t2695 = load i64, ptr %l657, !tbaa !24
  %t2696 = mul i64 %t2695, 8
  %t2697 = load i64, ptr %l654
  %t2698 = inttoptr i64 %t2697 to ptr
  %t2699 = call ptr @__olang_held_alloc(ptr %t2698, i64 %t2696)
  %t2700 = insertvalue { i64, ptr } undef, i64 %t2695, 0
  %t2701 = insertvalue { i64, ptr } %t2700, ptr %t2699, 1
  store { i64, ptr } %t2701, ptr %l658, !tbaa !27
  %t2702 = getelementptr { i64, ptr }, ptr %l658, i32 0, i32 1
  %t2703 = load ptr, ptr %t2702, !tbaa !27
  %t2704 = getelementptr { i64, ptr }, ptr %l656, i32 0, i32 1
  %t2705 = load ptr, ptr %t2704, !tbaa !27
  %t2706 = load i64, ptr %l657, !tbaa !24
  %t2707 = mul i64 %t2706, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2703, ptr %t2705, i64 %t2707, i1 false)
  %t2708 = load { i64, ptr }, ptr %l658, !tbaa !27
  %t2709 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2710 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2709, i32 0, i32 1
  store { i64, ptr } %t2708, ptr %t2710, !tbaa !27
  %t2711 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2711, label %bb411, label %bb412
bb411:
  %t2713 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2714 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2713, i32 0, i32 1
  %t2715 = load { i64, ptr }, ptr %t2714, !tbaa !27
  %t2716 = extractvalue { i64, ptr } %t2715, 0
  %t2718 = icmp eq i64 %t2716, 0
  br i1 %t2718, label %bb413, label %bb414
bb412:
  %t2720 = call ptr @__olang_scope_hold(ptr %s25)
  %t2721 = ptrtoint ptr %t2720 to i64
  store i64 %t2721, ptr %l662, !tbaa !24
  %t2722 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2722, label %bb415, label %bb416
bb413:
  %t2724 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2725 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2724, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t2725, !tbaa !27
  br label %bb414
bb414:
  %t2726 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2727 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2726, i32 0, i32 1
  %t2728 = load i64, ptr %l654
  %t2729 = inttoptr i64 %t2728 to ptr
  %t2730 = load { i64, ptr }, ptr %t2727
  %t2731 = extractvalue { i64, ptr } %t2730, 1
  %t2732 = call ptr @__olang_region_or(ptr %t2731, ptr null)
  %t2733 = icmp ne ptr %t2732, null
  %t2734 = select i1 %t2733, ptr %t2732, ptr null
  call void @__olang_region_settle_in(ptr %t2729, ptr %t2734)
  br label %bb412
bb415:
  %t2735 = call ptr @__olang_region_make_part(ptr %s25)
  %t2736 = ptrtoint ptr %t2735 to i64
  store i64 %t2736, ptr %l662, !tbaa !24
  br label %bb416
bb416:
  %t2737 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2738 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2737, i32 0, i32 2
  %t2739 = load { i64, ptr }, ptr %t2738, !tbaa !27
  store { i64, ptr } %t2739, ptr %l664, !tbaa !27
  %t2740 = load { i64, ptr }, ptr %l664, !tbaa !27
  %t2741 = extractvalue { i64, ptr } %t2740, 0
  store i64 %t2741, ptr %l665, !tbaa !24
  %t2742 = load i64, ptr %l665, !tbaa !24
  %t2743 = mul i64 %t2742, 8
  %t2744 = load i64, ptr %l662
  %t2745 = inttoptr i64 %t2744 to ptr
  %t2746 = call ptr @__olang_held_alloc(ptr %t2745, i64 %t2743)
  %t2747 = insertvalue { i64, ptr } undef, i64 %t2742, 0
  %t2748 = insertvalue { i64, ptr } %t2747, ptr %t2746, 1
  store { i64, ptr } %t2748, ptr %l666, !tbaa !27
  %t2749 = getelementptr { i64, ptr }, ptr %l666, i32 0, i32 1
  %t2750 = load ptr, ptr %t2749, !tbaa !27
  %t2751 = getelementptr { i64, ptr }, ptr %l664, i32 0, i32 1
  %t2752 = load ptr, ptr %t2751, !tbaa !27
  %t2753 = load i64, ptr %l665, !tbaa !24
  %t2754 = mul i64 %t2753, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2750, ptr %t2752, i64 %t2754, i1 false)
  %t2755 = load { i64, ptr }, ptr %l666, !tbaa !27
  %t2756 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2757 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2756, i32 0, i32 2
  store { i64, ptr } %t2755, ptr %t2757, !tbaa !27
  %t2758 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2758, label %bb417, label %bb418
bb417:
  %t2760 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2761 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2760, i32 0, i32 2
  %t2762 = load { i64, ptr }, ptr %t2761, !tbaa !27
  %t2763 = extractvalue { i64, ptr } %t2762, 0
  %t2765 = icmp eq i64 %t2763, 0
  br i1 %t2765, label %bb419, label %bb420
bb418:
  %t2767 = call ptr @__olang_scope_hold(ptr %s25)
  %t2768 = ptrtoint ptr %t2767 to i64
  store i64 %t2768, ptr %l670, !tbaa !24
  %t2769 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2769, label %bb421, label %bb422
bb419:
  %t2771 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2772 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2771, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t2772, !tbaa !27
  br label %bb420
bb420:
  %t2773 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 2
  %t2774 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2773, i32 0, i32 2
  %t2775 = load i64, ptr %l662
  %t2776 = inttoptr i64 %t2775 to ptr
  %t2777 = load { i64, ptr }, ptr %t2774
  %t2778 = extractvalue { i64, ptr } %t2777, 1
  %t2779 = call ptr @__olang_region_or(ptr %t2778, ptr null)
  %t2780 = icmp ne ptr %t2779, null
  %t2781 = select i1 %t2780, ptr %t2779, ptr null
  call void @__olang_region_settle_in(ptr %t2776, ptr %t2781)
  br label %bb418
bb421:
  %t2782 = call ptr @__olang_region_make_part(ptr %s25)
  %t2783 = ptrtoint ptr %t2782 to i64
  store i64 %t2783, ptr %l670, !tbaa !24
  br label %bb422
bb422:
  %t2784 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2785 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2784, i32 0, i32 0
  %t2786 = load { i64, ptr }, ptr %t2785, !tbaa !27
  store { i64, ptr } %t2786, ptr %l672, !tbaa !27
  %t2787 = load { i64, ptr }, ptr %l672, !tbaa !27
  %t2788 = extractvalue { i64, ptr } %t2787, 0
  store i64 %t2788, ptr %l673, !tbaa !24
  %t2789 = load i64, ptr %l673, !tbaa !24
  %t2790 = mul i64 %t2789, 16
  %t2791 = load i64, ptr %l670
  %t2792 = inttoptr i64 %t2791 to ptr
  %t2793 = call ptr @__olang_held_alloc(ptr %t2792, i64 %t2790)
  %t2794 = insertvalue { i64, ptr } undef, i64 %t2789, 0
  %t2795 = insertvalue { i64, ptr } %t2794, ptr %t2793, 1
  store { i64, ptr } %t2795, ptr %l674, !tbaa !27
  %t2796 = getelementptr { i64, ptr }, ptr %l674, i32 0, i32 1
  %t2797 = load ptr, ptr %t2796, !tbaa !27
  %t2798 = getelementptr { i64, ptr }, ptr %l672, i32 0, i32 1
  %t2799 = load ptr, ptr %t2798, !tbaa !27
  %t2800 = load i64, ptr %l673, !tbaa !24
  %t2801 = mul i64 %t2800, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t2797, ptr %t2799, i64 %t2801, i1 false)
  %t2802 = load { i64, ptr }, ptr %l674, !tbaa !27
  %t2803 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2804 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2803, i32 0, i32 0
  store { i64, ptr } %t2802, ptr %t2804, !tbaa !27
  %t2805 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2805, label %bb423, label %bb424
bb423:
  %t2807 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2808 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2807, i32 0, i32 0
  %t2809 = load { i64, ptr }, ptr %t2808, !tbaa !27
  %t2810 = extractvalue { i64, ptr } %t2809, 0
  %t2812 = icmp eq i64 %t2810, 0
  br i1 %t2812, label %bb425, label %bb426
bb424:
  %t2814 = call ptr @__olang_scope_hold(ptr %s25)
  %t2815 = ptrtoint ptr %t2814 to i64
  store i64 %t2815, ptr %l678, !tbaa !24
  %t2816 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2816, label %bb427, label %bb428
bb425:
  %t2818 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2819 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2818, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t2819, !tbaa !27
  br label %bb426
bb426:
  %t2820 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2821 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2820, i32 0, i32 0
  %t2822 = load i64, ptr %l670
  %t2823 = inttoptr i64 %t2822 to ptr
  %t2824 = load { i64, ptr }, ptr %t2821
  %t2825 = extractvalue { i64, ptr } %t2824, 1
  %t2826 = call ptr @__olang_region_or(ptr %t2825, ptr null)
  %t2827 = icmp ne ptr %t2826, null
  %t2828 = select i1 %t2827, ptr %t2826, ptr null
  call void @__olang_region_settle_in(ptr %t2823, ptr %t2828)
  br label %bb424
bb427:
  %t2829 = call ptr @__olang_region_make_part(ptr %s25)
  %t2830 = ptrtoint ptr %t2829 to i64
  store i64 %t2830, ptr %l678, !tbaa !24
  br label %bb428
bb428:
  %t2831 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2832 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2831, i32 0, i32 1
  %t2833 = load { i64, ptr }, ptr %t2832, !tbaa !27
  store { i64, ptr } %t2833, ptr %l680, !tbaa !27
  %t2834 = load { i64, ptr }, ptr %l680, !tbaa !27
  %t2835 = extractvalue { i64, ptr } %t2834, 0
  store i64 %t2835, ptr %l681, !tbaa !24
  %t2836 = load i64, ptr %l681, !tbaa !24
  %t2837 = mul i64 %t2836, 8
  %t2838 = load i64, ptr %l678
  %t2839 = inttoptr i64 %t2838 to ptr
  %t2840 = call ptr @__olang_held_alloc(ptr %t2839, i64 %t2837)
  %t2841 = insertvalue { i64, ptr } undef, i64 %t2836, 0
  %t2842 = insertvalue { i64, ptr } %t2841, ptr %t2840, 1
  store { i64, ptr } %t2842, ptr %l682, !tbaa !27
  %t2843 = getelementptr { i64, ptr }, ptr %l682, i32 0, i32 1
  %t2844 = load ptr, ptr %t2843, !tbaa !27
  %t2845 = getelementptr { i64, ptr }, ptr %l680, i32 0, i32 1
  %t2846 = load ptr, ptr %t2845, !tbaa !27
  %t2847 = load i64, ptr %l681, !tbaa !24
  %t2848 = mul i64 %t2847, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2844, ptr %t2846, i64 %t2848, i1 false)
  %t2849 = load { i64, ptr }, ptr %l682, !tbaa !27
  %t2850 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2851 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2850, i32 0, i32 1
  store { i64, ptr } %t2849, ptr %t2851, !tbaa !27
  %t2852 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2852, label %bb429, label %bb430
bb429:
  %t2854 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2855 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2854, i32 0, i32 1
  %t2856 = load { i64, ptr }, ptr %t2855, !tbaa !27
  %t2857 = extractvalue { i64, ptr } %t2856, 0
  %t2859 = icmp eq i64 %t2857, 0
  br i1 %t2859, label %bb431, label %bb432
bb430:
  %t2861 = call ptr @__olang_scope_hold(ptr %s25)
  %t2862 = ptrtoint ptr %t2861 to i64
  store i64 %t2862, ptr %l686, !tbaa !24
  %t2863 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2863, label %bb433, label %bb434
bb431:
  %t2865 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2866 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2865, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t2866, !tbaa !27
  br label %bb432
bb432:
  %t2867 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2868 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2867, i32 0, i32 1
  %t2869 = load i64, ptr %l678
  %t2870 = inttoptr i64 %t2869 to ptr
  %t2871 = load { i64, ptr }, ptr %t2868
  %t2872 = extractvalue { i64, ptr } %t2871, 1
  %t2873 = call ptr @__olang_region_or(ptr %t2872, ptr null)
  %t2874 = icmp ne ptr %t2873, null
  %t2875 = select i1 %t2874, ptr %t2873, ptr null
  call void @__olang_region_settle_in(ptr %t2870, ptr %t2875)
  br label %bb430
bb433:
  %t2876 = call ptr @__olang_region_make_part(ptr %s25)
  %t2877 = ptrtoint ptr %t2876 to i64
  store i64 %t2877, ptr %l686, !tbaa !24
  br label %bb434
bb434:
  %t2878 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2879 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2878, i32 0, i32 2
  %t2880 = load { i64, ptr }, ptr %t2879, !tbaa !27
  store { i64, ptr } %t2880, ptr %l688, !tbaa !27
  %t2881 = load { i64, ptr }, ptr %l688, !tbaa !27
  %t2882 = extractvalue { i64, ptr } %t2881, 0
  store i64 %t2882, ptr %l689, !tbaa !24
  %t2883 = load i64, ptr %l689, !tbaa !24
  %t2884 = mul i64 %t2883, 8
  %t2885 = load i64, ptr %l686
  %t2886 = inttoptr i64 %t2885 to ptr
  %t2887 = call ptr @__olang_held_alloc(ptr %t2886, i64 %t2884)
  %t2888 = insertvalue { i64, ptr } undef, i64 %t2883, 0
  %t2889 = insertvalue { i64, ptr } %t2888, ptr %t2887, 1
  store { i64, ptr } %t2889, ptr %l690, !tbaa !27
  %t2890 = getelementptr { i64, ptr }, ptr %l690, i32 0, i32 1
  %t2891 = load ptr, ptr %t2890, !tbaa !27
  %t2892 = getelementptr { i64, ptr }, ptr %l688, i32 0, i32 1
  %t2893 = load ptr, ptr %t2892, !tbaa !27
  %t2894 = load i64, ptr %l689, !tbaa !24
  %t2895 = mul i64 %t2894, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2891, ptr %t2893, i64 %t2895, i1 false)
  %t2896 = load { i64, ptr }, ptr %l690, !tbaa !27
  %t2897 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2898 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2897, i32 0, i32 2
  store { i64, ptr } %t2896, ptr %t2898, !tbaa !27
  %t2899 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t2899, label %bb435, label %bb436
bb435:
  %t2901 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2902 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2901, i32 0, i32 2
  %t2903 = load { i64, ptr }, ptr %t2902, !tbaa !27
  %t2904 = extractvalue { i64, ptr } %t2903, 0
  %t2906 = icmp eq i64 %t2904, 0
  br i1 %t2906, label %bb437, label %bb438
bb436:
  %t2908 = call ptr @__olang_scope_hold(ptr %s25)
  %t2909 = ptrtoint ptr %t2908 to i64
  store i64 %t2909, ptr %l694, !tbaa !24
  %t2910 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2910, label %bb439, label %bb440
bb437:
  %t2912 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2913 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2912, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t2913, !tbaa !27
  br label %bb438
bb438:
  %t2914 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 3
  %t2915 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2914, i32 0, i32 2
  %t2916 = load i64, ptr %l686
  %t2917 = inttoptr i64 %t2916 to ptr
  %t2918 = load { i64, ptr }, ptr %t2915
  %t2919 = extractvalue { i64, ptr } %t2918, 1
  %t2920 = call ptr @__olang_region_or(ptr %t2919, ptr null)
  %t2921 = icmp ne ptr %t2920, null
  %t2922 = select i1 %t2921, ptr %t2920, ptr null
  call void @__olang_region_settle_in(ptr %t2917, ptr %t2922)
  br label %bb436
bb439:
  %t2923 = call ptr @__olang_region_make_part(ptr %s25)
  %t2924 = ptrtoint ptr %t2923 to i64
  store i64 %t2924, ptr %l694, !tbaa !24
  br label %bb440
bb440:
  %t2925 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2926 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2925, i32 0, i32 0
  %t2927 = load { i64, ptr }, ptr %t2926, !tbaa !27
  store { i64, ptr } %t2927, ptr %l696, !tbaa !27
  %t2928 = load { i64, ptr }, ptr %l696, !tbaa !27
  %t2929 = extractvalue { i64, ptr } %t2928, 0
  store i64 %t2929, ptr %l697, !tbaa !24
  %t2930 = load i64, ptr %l697, !tbaa !24
  %t2931 = mul i64 %t2930, 16
  %t2932 = load i64, ptr %l694
  %t2933 = inttoptr i64 %t2932 to ptr
  %t2934 = call ptr @__olang_held_alloc(ptr %t2933, i64 %t2931)
  %t2935 = insertvalue { i64, ptr } undef, i64 %t2930, 0
  %t2936 = insertvalue { i64, ptr } %t2935, ptr %t2934, 1
  store { i64, ptr } %t2936, ptr %l698, !tbaa !27
  %t2937 = getelementptr { i64, ptr }, ptr %l698, i32 0, i32 1
  %t2938 = load ptr, ptr %t2937, !tbaa !27
  %t2939 = getelementptr { i64, ptr }, ptr %l696, i32 0, i32 1
  %t2940 = load ptr, ptr %t2939, !tbaa !27
  %t2941 = load i64, ptr %l697, !tbaa !24
  %t2942 = mul i64 %t2941, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t2938, ptr %t2940, i64 %t2942, i1 false)
  %t2943 = load { i64, ptr }, ptr %l698, !tbaa !27
  %t2944 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2945 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2944, i32 0, i32 0
  store { i64, ptr } %t2943, ptr %t2945, !tbaa !27
  %t2946 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0
  br i1 %t2946, label %bb441, label %bb442
bb441:
  %t2948 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2949 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2948, i32 0, i32 0
  %t2950 = load { i64, ptr }, ptr %t2949, !tbaa !27
  %t2951 = extractvalue { i64, ptr } %t2950, 0
  %t2953 = icmp eq i64 %t2951, 0
  br i1 %t2953, label %bb443, label %bb444
bb442:
  %t2955 = call ptr @__olang_scope_hold(ptr %s25)
  %t2956 = ptrtoint ptr %t2955 to i64
  store i64 %t2956, ptr %l702, !tbaa !24
  %t2957 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2957, label %bb445, label %bb446
bb443:
  %t2959 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2960 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2959, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t2960, !tbaa !27
  br label %bb444
bb444:
  %t2961 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2962 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2961, i32 0, i32 0
  %t2963 = load i64, ptr %l694
  %t2964 = inttoptr i64 %t2963 to ptr
  %t2965 = load { i64, ptr }, ptr %t2962
  %t2966 = extractvalue { i64, ptr } %t2965, 1
  %t2967 = call ptr @__olang_region_or(ptr %t2966, ptr null)
  %t2968 = icmp ne ptr %t2967, null
  %t2969 = select i1 %t2968, ptr %t2967, ptr null
  call void @__olang_region_settle_in(ptr %t2964, ptr %t2969)
  br label %bb442
bb445:
  %t2970 = call ptr @__olang_region_make_part(ptr %s25)
  %t2971 = ptrtoint ptr %t2970 to i64
  store i64 %t2971, ptr %l702, !tbaa !24
  br label %bb446
bb446:
  %t2972 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2973 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2972, i32 0, i32 1
  %t2974 = load { i64, ptr }, ptr %t2973, !tbaa !27
  store { i64, ptr } %t2974, ptr %l704, !tbaa !27
  %t2975 = load { i64, ptr }, ptr %l704, !tbaa !27
  %t2976 = extractvalue { i64, ptr } %t2975, 0
  store i64 %t2976, ptr %l705, !tbaa !24
  %t2977 = load i64, ptr %l705, !tbaa !24
  %t2978 = mul i64 %t2977, 8
  %t2979 = load i64, ptr %l702
  %t2980 = inttoptr i64 %t2979 to ptr
  %t2981 = call ptr @__olang_held_alloc(ptr %t2980, i64 %t2978)
  %t2982 = insertvalue { i64, ptr } undef, i64 %t2977, 0
  %t2983 = insertvalue { i64, ptr } %t2982, ptr %t2981, 1
  store { i64, ptr } %t2983, ptr %l706, !tbaa !27
  %t2984 = getelementptr { i64, ptr }, ptr %l706, i32 0, i32 1
  %t2985 = load ptr, ptr %t2984, !tbaa !27
  %t2986 = getelementptr { i64, ptr }, ptr %l704, i32 0, i32 1
  %t2987 = load ptr, ptr %t2986, !tbaa !27
  %t2988 = load i64, ptr %l705, !tbaa !24
  %t2989 = mul i64 %t2988, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t2985, ptr %t2987, i64 %t2989, i1 false)
  %t2990 = load { i64, ptr }, ptr %l706, !tbaa !27
  %t2991 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2992 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2991, i32 0, i32 1
  store { i64, ptr } %t2990, ptr %t2992, !tbaa !27
  %t2993 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1
  br i1 %t2993, label %bb447, label %bb448
bb447:
  %t2995 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t2996 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t2995, i32 0, i32 1
  %t2997 = load { i64, ptr }, ptr %t2996, !tbaa !27
  %t2998 = extractvalue { i64, ptr } %t2997, 0
  %t3000 = icmp eq i64 %t2998, 0
  br i1 %t3000, label %bb449, label %bb450
bb448:
  %t3002 = call ptr @__olang_scope_hold(ptr %s25)
  %t3003 = ptrtoint ptr %t3002 to i64
  store i64 %t3003, ptr %l710, !tbaa !24
  %t3004 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t3004, label %bb451, label %bb452
bb449:
  %t3006 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t3007 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3006, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t3007, !tbaa !27
  br label %bb450
bb450:
  %t3008 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t3009 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3008, i32 0, i32 1
  %t3010 = load i64, ptr %l702
  %t3011 = inttoptr i64 %t3010 to ptr
  %t3012 = load { i64, ptr }, ptr %t3009
  %t3013 = extractvalue { i64, ptr } %t3012, 1
  %t3014 = call ptr @__olang_region_or(ptr %t3013, ptr null)
  %t3015 = icmp ne ptr %t3014, null
  %t3016 = select i1 %t3015, ptr %t3014, ptr null
  call void @__olang_region_settle_in(ptr %t3011, ptr %t3016)
  br label %bb448
bb451:
  %t3017 = call ptr @__olang_region_make_part(ptr %s25)
  %t3018 = ptrtoint ptr %t3017 to i64
  store i64 %t3018, ptr %l710, !tbaa !24
  br label %bb452
bb452:
  %t3019 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t3020 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3019, i32 0, i32 2
  %t3021 = load { i64, ptr }, ptr %t3020, !tbaa !27
  store { i64, ptr } %t3021, ptr %l712, !tbaa !27
  %t3022 = load { i64, ptr }, ptr %l712, !tbaa !27
  %t3023 = extractvalue { i64, ptr } %t3022, 0
  store i64 %t3023, ptr %l713, !tbaa !24
  %t3024 = load i64, ptr %l713, !tbaa !24
  %t3025 = mul i64 %t3024, 8
  %t3026 = load i64, ptr %l710
  %t3027 = inttoptr i64 %t3026 to ptr
  %t3028 = call ptr @__olang_held_alloc(ptr %t3027, i64 %t3025)
  %t3029 = insertvalue { i64, ptr } undef, i64 %t3024, 0
  %t3030 = insertvalue { i64, ptr } %t3029, ptr %t3028, 1
  store { i64, ptr } %t3030, ptr %l714, !tbaa !27
  %t3031 = getelementptr { i64, ptr }, ptr %l714, i32 0, i32 1
  %t3032 = load ptr, ptr %t3031, !tbaa !27
  %t3033 = getelementptr { i64, ptr }, ptr %l712, i32 0, i32 1
  %t3034 = load ptr, ptr %t3033, !tbaa !27
  %t3035 = load i64, ptr %l713, !tbaa !24
  %t3036 = mul i64 %t3035, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t3032, ptr %t3034, i64 %t3036, i1 false)
  %t3037 = load { i64, ptr }, ptr %l714, !tbaa !27
  %t3038 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t3039 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3038, i32 0, i32 2
  store { i64, ptr } %t3037, ptr %t3039, !tbaa !27
  %t3040 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2
  br i1 %t3040, label %bb453, label %bb454
bb453:
  %t3042 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t3043 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3042, i32 0, i32 2
  %t3044 = load { i64, ptr }, ptr %t3043, !tbaa !27
  %t3045 = extractvalue { i64, ptr } %t3044, 0
  %t3047 = icmp eq i64 %t3045, 0
  br i1 %t3047, label %bb455, label %bb456
bb454:
  %t3049 = call ptr @__olang_scope_hold(ptr %s25)
  %t3050 = ptrtoint ptr %t3049 to i64
  store i64 %t3050, ptr %l718, !tbaa !24
  %t3051 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t3051, label %bb457, label %bb458
bb455:
  %t3053 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t3054 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3053, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t3054, !tbaa !27
  br label %bb456
bb456:
  %t3055 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 4
  %t3056 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t3055, i32 0, i32 2
  %t3057 = load i64, ptr %l710
  %t3058 = inttoptr i64 %t3057 to ptr
  %t3059 = load { i64, ptr }, ptr %t3056
  %t3060 = extractvalue { i64, ptr } %t3059, 1
  %t3061 = call ptr @__olang_region_or(ptr %t3060, ptr null)
  %t3062 = icmp ne ptr %t3061, null
  %t3063 = select i1 %t3062, ptr %t3061, ptr null
  call void @__olang_region_settle_in(ptr %t3058, ptr %t3063)
  br label %bb454
bb457:
  %t3064 = call ptr @__olang_region_make_part(ptr %s25)
  %t3065 = ptrtoint ptr %t3064 to i64
  store i64 %t3065, ptr %l718, !tbaa !24
  br label %bb458
bb458:
  %t3066 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 5
  %t3067 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3066, i32 0, i32 0
  %t3068 = load { i64, ptr }, ptr %t3067, !tbaa !27
  store { i64, ptr } %t3068, ptr %l720, !tbaa !27
  %t3069 = load { i64, ptr }, ptr %l720, !tbaa !27
  %t3070 = extractvalue { i64, ptr } %t3069, 0
  store i64 %t3070, ptr %l721, !tbaa !24
  %t3071 = load i64, ptr %l721, !tbaa !24
  %t3072 = mul i64 %t3071, 8
  %t3073 = load i64, ptr %l718
  %t3074 = inttoptr i64 %t3073 to ptr
  %t3075 = call ptr @__olang_held_alloc(ptr %t3074, i64 %t3072)
  %t3076 = insertvalue { i64, ptr } undef, i64 %t3071, 0
  %t3077 = insertvalue { i64, ptr } %t3076, ptr %t3075, 1
  store { i64, ptr } %t3077, ptr %l722, !tbaa !27
  %t3078 = getelementptr { i64, ptr }, ptr %l722, i32 0, i32 1
  %t3079 = load ptr, ptr %t3078, !tbaa !27
  %t3080 = getelementptr { i64, ptr }, ptr %l720, i32 0, i32 1
  %t3081 = load ptr, ptr %t3080, !tbaa !27
  %t3082 = load i64, ptr %l721, !tbaa !24
  %t3083 = mul i64 %t3082, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t3079, ptr %t3081, i64 %t3083, i1 false)
  %t3084 = load { i64, ptr }, ptr %l722, !tbaa !27
  %t3085 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 5
  %t3086 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3085, i32 0, i32 0
  store { i64, ptr } %t3084, ptr %t3086, !tbaa !27
  %t3087 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t3087, label %bb459, label %bb460
bb459:
  %t3089 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 5
  %t3090 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3089, i32 0, i32 0
  %t3091 = load { i64, ptr }, ptr %t3090, !tbaa !27
  %t3092 = extractvalue { i64, ptr } %t3091, 0
  %t3094 = icmp eq i64 %t3092, 0
  br i1 %t3094, label %bb461, label %bb462
bb460:
  %t3096 = call ptr @__olang_scope_hold(ptr %s25)
  %t3097 = ptrtoint ptr %t3096 to i64
  store i64 %t3097, ptr %l726, !tbaa !24
  %t3098 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t3098, label %bb463, label %bb464
bb461:
  %t3100 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 5
  %t3101 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3100, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t3101, !tbaa !27
  br label %bb462
bb462:
  %t3102 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 5
  %t3103 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3102, i32 0, i32 0
  %t3104 = load i64, ptr %l718
  %t3105 = inttoptr i64 %t3104 to ptr
  %t3106 = load { i64, ptr }, ptr %t3103
  %t3107 = extractvalue { i64, ptr } %t3106, 1
  %t3108 = call ptr @__olang_region_or(ptr %t3107, ptr null)
  %t3109 = icmp ne ptr %t3108, null
  %t3110 = select i1 %t3109, ptr %t3108, ptr null
  call void @__olang_region_settle_in(ptr %t3105, ptr %t3110)
  br label %bb460
bb463:
  %t3111 = call ptr @__olang_region_make_part(ptr %s25)
  %t3112 = ptrtoint ptr %t3111 to i64
  store i64 %t3112, ptr %l726, !tbaa !24
  br label %bb464
bb464:
  %t3113 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 6
  %t3114 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3113, i32 0, i32 0
  %t3115 = load { i64, ptr }, ptr %t3114, !tbaa !27
  store { i64, ptr } %t3115, ptr %l728, !tbaa !27
  %t3116 = load { i64, ptr }, ptr %l728, !tbaa !27
  %t3117 = extractvalue { i64, ptr } %t3116, 0
  store i64 %t3117, ptr %l729, !tbaa !24
  %t3118 = load i64, ptr %l729, !tbaa !24
  %t3119 = mul i64 %t3118, 8
  %t3120 = load i64, ptr %l726
  %t3121 = inttoptr i64 %t3120 to ptr
  %t3122 = call ptr @__olang_held_alloc(ptr %t3121, i64 %t3119)
  %t3123 = insertvalue { i64, ptr } undef, i64 %t3118, 0
  %t3124 = insertvalue { i64, ptr } %t3123, ptr %t3122, 1
  store { i64, ptr } %t3124, ptr %l730, !tbaa !27
  %t3125 = getelementptr { i64, ptr }, ptr %l730, i32 0, i32 1
  %t3126 = load ptr, ptr %t3125, !tbaa !27
  %t3127 = getelementptr { i64, ptr }, ptr %l728, i32 0, i32 1
  %t3128 = load ptr, ptr %t3127, !tbaa !27
  %t3129 = load i64, ptr %l729, !tbaa !24
  %t3130 = mul i64 %t3129, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t3126, ptr %t3128, i64 %t3130, i1 false)
  %t3131 = load { i64, ptr }, ptr %l730, !tbaa !27
  %t3132 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 6
  %t3133 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3132, i32 0, i32 0
  store { i64, ptr } %t3131, ptr %t3133, !tbaa !27
  %t3134 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t3134, label %bb465, label %bb466
bb465:
  %t3136 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 6
  %t3137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3136, i32 0, i32 0
  %t3138 = load { i64, ptr }, ptr %t3137, !tbaa !27
  %t3139 = extractvalue { i64, ptr } %t3138, 0
  %t3141 = icmp eq i64 %t3139, 0
  br i1 %t3141, label %bb467, label %bb468
bb466:
  %t3143 = load i64, ptr %l31, !tbaa !24
  %t3144 = load ptr, ptr %l2, !tbaa !29
  %t3145 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr null, i32 1
  %t3146 = ptrtoint ptr %t3145 to i64
  %t3148 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t3147, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t3148, ptr %l597, i64 424, i1 false)
  %t3149 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t3147, i32 0, i32 1
  store i64 %t3143, ptr %t3149, !tbaa !28
  %t3151 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t3147, i32 0, i32 2
  store ptr %t3144, ptr %t3151, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t3153 = call ptr @__olang_scope_hold(ptr %s0)
  %t3154 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t3147, i32 0, i32 3
  store ptr %t3153, ptr %t3154, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t3155 = call ptr @__olang_scope_hold(ptr %v2)
  %t3156 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %t3147, i32 0, i32 4
  store ptr %t3155, ptr %t3156, !tbaa !28
  %t3157 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_89, 0
  %t3158 = insertvalue { ptr, ptr } %t3157, ptr %t3147, 1
  %t3159 = load ptr, ptr %l595, !tbaa !29
  %t3161 = extractvalue { ptr, ptr } %t3158, 0
  %t3162 = extractvalue { ptr, ptr } %t3158, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s25, ptr %s25, ptr %t3159, ptr %t3161, ptr %t3162)
  br label %bb469
bb467:
  %t3163 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 6
  %t3164 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3163, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t3164, !tbaa !27
  br label %bb468
bb468:
  %t3165 = getelementptr %"compiler/profile:Tally", ptr %l597, i32 0, i32 6
  %t3166 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3165, i32 0, i32 0
  %t3167 = load i64, ptr %l726
  %t3168 = inttoptr i64 %t3167 to ptr
  %t3169 = load { i64, ptr }, ptr %t3166
  %t3170 = extractvalue { i64, ptr } %t3169, 1
  %t3171 = call ptr @__olang_region_or(ptr %t3170, ptr null)
  %t3172 = icmp ne ptr %t3171, null
  %t3173 = select i1 %t3172, ptr %t3171, ptr null
  call void @__olang_region_settle_in(ptr %t3168, ptr %t3173)
  br label %bb466
bb469:
  %t3174 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s25, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3174, ptr %l737
  br label %bb470
bb470:
  %t3175 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l737
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3175, ptr %l38
  store ptr %l34, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb471
bb471:
  store %olang.scope zeroinitializer, ptr %s33
  %t3177 = load i64, ptr %l40, !tbaa !24
  store i64 %t3177, ptr %l739, !tbaa !24
  %t3178 = load ptr, ptr %l39, !tbaa !29
  %t3180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s25, ptr %t3178)
  store i64 %t3180, ptr %l741
  br label %bb472
bb472:
  %t3181 = load i64, ptr %l739, !tbaa !24
  %t3182 = load i64, ptr %l741, !tbaa !24
  %t3183 = icmp slt i64 %t3181, %t3182
  %t3185 = xor i1 %t3183, true
  br i1 %t3185, label %bb473, label %bb474
bb473:
  call void @__olang_scope_close(ptr %s33)
  br label %bb491
bb474:
  br label %bb475
bb475:
  %t3187 = load ptr, ptr %l39, !tbaa !29
  %t3188 = load i64, ptr %l40, !tbaa !24
  %t3191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s25, ptr %t3187, i64 %t3188)
  store i64 %t3191, ptr %l746
  br label %bb476
bb476:
  %t3192 = load i64, ptr %l746, !tbaa !24
  store i64 %t3192, ptr %l41, !tbaa !24
  %t3194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s25, ptr %l38)
  store i64 %t3194, ptr %l748
  br label %bb477
bb477:
  %t3195 = load i64, ptr %l748, !tbaa !24
  %t3196 = icmp sge i64 %t3195, 4
  br i1 %t3196, label %bb478, label %bb479
bb478:
  call void @__olang_scope_close(ptr %s33)
  br label %bb491
bb479:
  br label %bb480
bb480:
  store ptr %l38, ptr %l750, !tbaa !29
  %t3198 = call ptr @__olang_scope_hold(ptr %s25)
  %t3199 = ptrtoint ptr %t3198 to i64
  store i64 %t3199, ptr %l751, !tbaa !24
  %t3200 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t3200, label %bb481, label %bb482
bb481:
  %t3202 = call ptr @__olang_region_make(ptr %s25)
  %t3203 = ptrtoint ptr %t3202 to i64
  store i64 %t3203, ptr %l751, !tbaa !24
  br label %bb482
bb482:
  %t3204 = load ptr, ptr %l2, !tbaa !29
  %t3206 = getelementptr %"compiler/profile:Places", ptr %t3204, i32 0, i32 0
  %t3207 = load i64, ptr %l41, !tbaa !24
  %t3210 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s33, ptr %t3206, i64 %t3207)
  store { i64, ptr } %t3210, ptr %l756
  br label %bb483
bb483:
  %t3211 = getelementptr %"compiler/profile:Tally", ptr %l3, i32 0, i32 4
  %t3212 = load i64, ptr %l31, !tbaa !24
  %t3214 = mul i64 %t3212, 16777216
  %t3215 = load i64, ptr %l41, !tbaa !24
  %t3218 = add i64 %t3214, %t3215
  %t3221 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %s0, ptr %t3211, i64 %t3218)
  %t3222 = extractvalue { i32, i64 } %t3221, 1
  %t3223 = extractvalue { i32, i64 } %t3221, 0
  store i32 %t3223, ptr %l764
  %t3224 = icmp ne i32 %t3223, 0
  br i1 %t3224, label %bb485, label %ok.3225, !prof !99
ok.3225:
  store i64 %t3222, ptr %l763
  br label %bb484
bb484:
  %t3226 = load i64, ptr %l763, !tbaa !24
  store i64 %t3226, ptr %l757, !tbaa !24
  br label %bb487
bb485:
  br label %bb486
bb486:
  store i64 0, ptr %l757, !tbaa !24
  br label %bb487
bb487:
  %t3227 = load i64, ptr %l33, !tbaa !24
  %t3228 = load i64, ptr %l757, !tbaa !24
  %t3230 = call { i64, ptr } @compiler_2fprofile_2epct(ptr %s33, i64 %t3228, i64 %t3227)
  store { i64, ptr } %t3230, ptr %l766
  br label %bb488
bb488:
  %t3231 = load { i64, ptr }, ptr %l756, !tbaa !27
  %t3232 = extractvalue { i64, ptr } %t3231, 1
  %t3233 = extractvalue { i64, ptr } %t3231, 0
  %t3234 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t3235 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t3236 = add i64 %t3233, %t3235
  %t3237 = load { i64, ptr }, ptr %l766, !tbaa !27
  %t3238 = extractvalue { i64, ptr } %t3237, 1
  %t3239 = extractvalue { i64, ptr } %t3237, 0
  %t3240 = add i64 %t3236, %t3239
  %t3241 = load i64, ptr %l751
  %t3242 = inttoptr i64 %t3241 to ptr
  %t3243 = call ptr @__olang_held_alloc(ptr %t3242, i64 %t3240)
  call void @olang_textcopy(ptr %t3243, ptr %t3232, i64 %t3233)
  %t3244 = getelementptr i8, ptr %t3243, i64 %t3233
  call void @olang_textcopy(ptr %t3244, ptr %t3234, i64 %t3235)
  %t3245 = getelementptr i8, ptr %t3244, i64 %t3235
  call void @olang_textcopy(ptr %t3245, ptr %t3238, i64 %t3239)
  %t3246 = insertvalue { i64, ptr } undef, i64 %t3240, 0
  %t3247 = insertvalue { i64, ptr } %t3246, ptr %t3243, 1
  %t3249 = load ptr, ptr %l750, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s25, ptr %s25, ptr %t3249, { i64, ptr } %t3247)
  br label %bb489
bb489:
  call void @__olang_scope_close(ptr %s33)
  br label %bb490
bb490:
  %t3251 = load i64, ptr %l40, !tbaa !24
  %t3254 = add i64 %t3251, 1
  store i64 %t3254, ptr %l40, !tbaa !24
  br label %bb471
bb491:
  store ptr %l5, ptr %l772, !tbaa !29
  %t3256 = load ptr, ptr %l2, !tbaa !29
  %t3258 = getelementptr %"compiler/profile:Places", ptr %t3256, i32 0, i32 0
  %t3259 = load i64, ptr %l31, !tbaa !24
  %t3262 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %s25, ptr %t3258, i64 %t3259)
  store { i64, ptr } %t3262, ptr %l776
  br label %bb492
bb492:
  %t3264 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s25, ptr %l38)
  store i64 %t3264, ptr %l778
  br label %bb493
bb493:
  %t3265 = load i64, ptr %l778, !tbaa !24
  %t3266 = icmp eq i64 %t3265, 0
  br i1 %t3266, label %bb494, label %bb495
bb494:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l780, !tbaa !27
  br label %bb497
bb495:
  %t3269 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s25, ptr %s25, ptr %s25, ptr %l38, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store { i64, ptr } %t3269, ptr %l782
  br label %bb496
bb496:
  %t3270 = load { i64, ptr }, ptr %l782, !tbaa !27
  store { i64, ptr } %t3270, ptr %l780, !tbaa !27
  br label %bb497
bb497:
  %t3272 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t3273 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t3274 = load { i64, ptr }, ptr %l776, !tbaa !27
  %t3275 = extractvalue { i64, ptr } %t3274, 1
  %t3276 = extractvalue { i64, ptr } %t3274, 0
  %t3277 = add i64 %t3273, %t3276
  %t3278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t3279 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t3280 = add i64 %t3277, %t3279
  %t3281 = load { i64, ptr }, ptr %l780, !tbaa !27
  %t3282 = extractvalue { i64, ptr } %t3281, 1
  %t3283 = extractvalue { i64, ptr } %t3281, 0
  %t3284 = add i64 %t3280, %t3283
  %t3285 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t3286 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t3287 = add i64 %t3284, %t3286
  %t3288 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t3287)
  call void @olang_textcopy(ptr %t3288, ptr %t3272, i64 %t3273)
  %t3289 = getelementptr i8, ptr %t3288, i64 %t3273
  call void @olang_textcopy(ptr %t3289, ptr %t3275, i64 %t3276)
  %t3290 = getelementptr i8, ptr %t3289, i64 %t3276
  call void @olang_textcopy(ptr %t3290, ptr %t3278, i64 %t3279)
  %t3291 = getelementptr i8, ptr %t3290, i64 %t3279
  call void @olang_textcopy(ptr %t3291, ptr %t3282, i64 %t3283)
  %t3292 = getelementptr i8, ptr %t3291, i64 %t3283
  call void @olang_textcopy(ptr %t3292, ptr %t3285, i64 %t3286)
  %t3293 = insertvalue { i64, ptr } undef, i64 %t3287, 0
  %t3294 = insertvalue { i64, ptr } %t3293, ptr %t3288, 1
  %t3296 = load ptr, ptr %l772, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s25, ptr %t3296, { i64, ptr } %t3294)
  br label %bb498
bb498:
  call void @__olang_scope_close(ptr %s25)
  br label %bb499
bb499:
  %t3298 = load i64, ptr %l30, !tbaa !24
  %t3301 = add i64 %t3298, 1
  store i64 %t3301, ptr %l30, !tbaa !24
  br label %bb333
bb500:
  %t3304 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l5)
  store { i64, ptr } %t3304, ptr %l790
  br label %bb501
bb501:
  call void @__olang_scope_close(ptr %s0)
  %t3305 = load { i64, ptr }, ptr %l790, !tbaa !27
  store { i64, ptr } %t3305, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i32
  %l21 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l44 = alloca { i64, ptr }
  %l46 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s0)
  store { i64, ptr } %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t2, ptr %l0, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t5, ptr %l10
  br label %bb2
bb2:
  %t6 = load i1, ptr %l10, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %s0, ptr %s1, { i64, ptr } %t9)
  store { i64, ptr } %t11, ptr %l14
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t12 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t14 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %s1, ptr %s1, { i64, ptr } %t12)
  %t15 = extractvalue { i32, { i64, ptr } } %t14, 1
  %t16 = extractvalue { i32, { i64, ptr } } %t14, 0
  store i32 %t16, ptr %l17
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb7, label %ok.18, !prof !99
ok.18:
  store { i64, ptr } %t15, ptr %l16
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t19, ptr %l12, !tbaa !27
  br label %bb11
bb7:
  %t20 = load i32, ptr %l17, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  br i1 %t23, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb11
bb11:
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t25, ptr %l1, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) })
  store i1 %t28, ptr %l21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l21, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s1, ptr %s2, { i64, ptr } %t32)
  store { i64, ptr } %t34, ptr %l24
  br label %bb15
bb14:
  br label %bb21
bb15:
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t36, i64 %t37)
  %t42 = getelementptr i8, ptr %t41, i64 %t37
  call void @olang_textcopy(ptr %t42, ptr %t38, i64 %t39)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t41, 1
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t45, ptr %lp2
  %t47 = load ptr, ptr %lp2
  store { i64, ptr } %t44, ptr %t47, !tbaa !27
  %t48 = load ptr, ptr %lp2
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %s2, { i64, ptr } %t49)
  store { i64, ptr } %t51, ptr %l27
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t52, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d100, i32 0, i32 1) })
  store i1 %t54, ptr %l29
  br label %bb17
bb17:
  %t55 = load i1, ptr %l29, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %lp2
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t59, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t61 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t62 = insertvalue [4 x { i64, ptr }] %t61, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t63 = insertvalue [4 x { i64, ptr }] %t62, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d103, i32 0, i32 1) }, 2
  %t64 = insertvalue [4 x { i64, ptr }] %t63, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d104, i32 0, i32 1) }, 3
  %t66 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 64, i64 8)
  store [4 x { i64, ptr }] %t64, ptr %t66
  store ptr %t66, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t68 = load ptr, ptr %l3
  store i64 4, ptr %l5, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t71 = load i64, ptr %l4, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t79 = load ptr, ptr %l3
  %t80 = load i64, ptr %l4, !tbaa !24
  %t83 = getelementptr [4 x { i64, ptr }], ptr %t79, i64 0, i64 %t80
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !37
  %t87 = load ptr, ptr @__olang_prog_scope
  %t89 = call { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %t87, ptr %v0, { i64, ptr } %t84)
  store { i64, ptr } %t89, ptr %l44
  br label %bb27
bb27:
  %t90 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t90, ptr %l7, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t91, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t93, ptr %l46
  br label %bb28
bb28:
  %t94 = load i1, ptr %l46, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t97, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t99 = load i64, ptr %l4, !tbaa !24
  %t102 = add i64 %t99, 1
  store i64 %t102, ptr %l4, !tbaa !24
  br label %bb23
bb33:
  call void @__olang_scope_close(ptr %s5)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t104, ptr %l53, !tbaa !27
  %t105 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  store i64 %t106, ptr %l54, !tbaa !24
  %t107 = load i64, ptr %l54, !tbaa !24
  %t108 = mul i64 %t107, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %l55, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l54, !tbaa !24
  %t117 = mul i64 %t116, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t113, ptr %t115, i64 %t117, i1 false)
  %t118 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t118, ptr %l53, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2eTally_2eTallied(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/profile:Sample"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca %"compiler/profile:Frame"
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"compiler/profile:Tally"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca %"compiler/profile:Sample"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l37 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/profile:Frame"
  %l43 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca i64
  %l80 = alloca i64
  %l86 = alloca i64
  %l90 = alloca %"compiler/profile:Frame"
  %l95 = alloca i1
  %l100 = alloca i1
  %l102 = alloca i1
  %l105 = alloca i1
  %l113 = alloca i64
  %l115 = alloca i64
  %l117 = alloca ptr
  %l119 = alloca i64
  %l121 = alloca ptr
  %l125 = alloca i64
  %l126 = alloca %"compiler/profile:Frame"
  %l136 = alloca %"compiler/profile:Tally"
  %s2 = alloca %olang.scope
  %t1 = alloca %"compiler/profile:Tally", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fprofile_3aTally_2ector(ptr %t1, ptr %v2)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t1, i64 424, i1 false)
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 424, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %t3, ptr %l17, i64 424, i1 false)
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/profile:Profile", ptr %t4, i32 0, i32 3
  store ptr %t6, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l20, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l22
  br label %bb3
bb3:
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = load i64, ptr %l22, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t18, i64 %t19)
  store %"compiler/profile:Sample" %t22, ptr %l27
  br label %bb7
bb7:
  %t23 = load %"compiler/profile:Sample", ptr %l27
  store %"compiler/profile:Sample" %t23, ptr %l5
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load %"compiler/profile:Sample", ptr %l5
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v1, ptr %v0, ptr %s2, ptr %t24, ptr %t25, %"compiler/profile:Sample" %t26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l31
  br label %bb8
bb8:
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l6
  %t33 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l6)
  store i64 %t33, ptr %l33
  br label %bb9
bb9:
  %t34 = load i64, ptr %l33, !tbaa !24
  %t35 = icmp eq i64 %t34, 0
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb11:
  br label %bb12
bb12:
  %t37 = getelementptr %"compiler/profile:Sample", ptr %l5, i32 0, i32 0
  %t38 = load i64, ptr %t37, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr %"compiler/profile:Places", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l37, !tbaa !29
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l6, i64 0)
  store i64 %t44, ptr %l39
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l37, !tbaa !29
  %t46 = load i64, ptr %l39, !tbaa !24
  %t47 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t45, i64 %t46)
  store %"compiler/profile:Frame" %t47, ptr %l40
  br label %bb14
bb14:
  %t48 = load %"compiler/profile:Frame", ptr %l40
  store %"compiler/profile:Frame" %t48, ptr %l8
  %t49 = load ptr, ptr %lp2
  %t50 = getelementptr %"compiler/profile:Tally", ptr %t49, i32 0, i32 1
  %t51 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t55 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t50, i64 %t52)
  store i1 %t55, ptr %l43
  br label %bb15
bb15:
  %t56 = load i1, ptr %l43, !tbaa !21
  %t57 = xor i1 %t56, true
  br i1 %t57, label %bb16, label %bb17
bb16:
  %t59 = load ptr, ptr %lp2
  %t60 = getelementptr %"compiler/profile:Tally", ptr %t59, i32 0, i32 0
  %t61 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t60, i64 %t62)
  store i1 %t65, ptr %l48
  br label %bb18
bb17:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb18:
  %t66 = load i1, ptr %l48, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l45, !tbaa !21
  br i1 %t69, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %lp2
  %t71 = getelementptr %"compiler/profile:Tally", ptr %t70, i32 0, i32 5
  %t72 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t73 = load i64, ptr %t72, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t71, i64 %t73)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t76 = load ptr, ptr %lp2
  %t77 = getelementptr %"compiler/profile:Tally", ptr %t76, i32 0, i32 0
  %t78 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t77, i64 %t79, i64 %t80)
  br label %bb24
bb24:
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l55, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/profile:Places", ptr %t85, i32 0, i32 0
  %t88 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 1
  %t89 = load i64, ptr %t88, !tbaa !24
  %t92 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %s2, ptr %t87, i64 %t89)
  store { i64, ptr } %t92, ptr %l59
  br label %bb25
bb25:
  %t93 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 2
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t100 = add i64 %t97, %t99
  %t102 = call i64 @__olang_fmt_i64(ptr null, i64 %t94)
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t96, i64 %t97)
  %t105 = getelementptr i8, ptr %t104, i64 %t97
  call void @olang_textcopy(ptr %t105, ptr %t98, i64 %t99)
  %t106 = getelementptr i8, ptr %t105, i64 %t99
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t94)
  %t108 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t104, 1
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t113 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v1, ptr %v1, ptr %t111, { i64, ptr } %t109)
  store i64 %t113, ptr %l63
  br label %bb26
bb26:
  %t114 = load i64, ptr %l63, !tbaa !24
  store i64 %t114, ptr %l9, !tbaa !24
  %t115 = load ptr, ptr %lp2
  %t116 = getelementptr %"compiler/profile:Tally", ptr %t115, i32 0, i32 2
  %t117 = load i64, ptr %l9, !tbaa !24
  %t120 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t116, i64 %t117)
  store i1 %t120, ptr %l66
  br label %bb27
bb27:
  %t121 = load i1, ptr %l66, !tbaa !21
  %t122 = xor i1 %t121, true
  br i1 %t122, label %bb28, label %bb29
bb28:
  %t124 = load ptr, ptr %lp2
  %t125 = getelementptr %"compiler/profile:Tally", ptr %t124, i32 0, i32 6
  %t126 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t125, i64 %t126)
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t129 = load ptr, ptr %lp2
  %t130 = getelementptr %"compiler/profile:Tally", ptr %t129, i32 0, i32 2
  %t131 = load i64, ptr %l9, !tbaa !24
  %t132 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t130, i64 %t131, i64 %t132)
  br label %bb32
bb32:
  %t136 = load ptr, ptr %lp2
  %t137 = getelementptr %"compiler/profile:Tally", ptr %t136, i32 0, i32 3
  %t138 = load i64, ptr %l9, !tbaa !24
  %t139 = getelementptr %"compiler/profile:Frame", ptr %l8, i32 0, i32 0
  %t140 = load i64, ptr %t139, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v2, ptr %t137, i64 %t138, i64 %t140)
  br label %bb33
bb33:
  %t144 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %l76
  br label %bb34
bb34:
  %t145 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t145, ptr %l10
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb35:
  %t147 = load i64, ptr %l12, !tbaa !24
  store i64 %t147, ptr %l78, !tbaa !24
  %t148 = load ptr, ptr %l11, !tbaa !29
  %t150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t148)
  store i64 %t150, ptr %l80
  br label %bb36
bb36:
  %t151 = load i64, ptr %l78, !tbaa !24
  %t152 = load i64, ptr %l80, !tbaa !24
  %t153 = icmp slt i64 %t151, %t152
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb37, label %bb38
bb37:
  br label %bb65
bb38:
  br label %bb39
bb39:
  %t157 = load i64, ptr %l12, !tbaa !24
  store i64 %t157, ptr %l13, !tbaa !24
  %t159 = load ptr, ptr %l11, !tbaa !29
  %t160 = load i64, ptr %l12, !tbaa !24
  %t163 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l86
  br label %bb40
bb40:
  %t164 = load i64, ptr %l86, !tbaa !24
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/profile:Places", ptr %t165, i32 0, i32 2
  %t171 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t167, i64 %t164)
  store %"compiler/profile:Frame" %t171, ptr %l90
  br label %bb41
bb41:
  %t172 = getelementptr %"compiler/profile:Frame", ptr %l90, i32 0, i32 0
  %t173 = load i64, ptr %t172, !tbaa !24
  store i64 %t173, ptr %l15, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t180 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s2, ptr %l10, i64 %t175)
  store i1 %t180, ptr %l95
  br label %bb42
bb42:
  %t181 = load i1, ptr %l95, !tbaa !21
  br i1 %t181, label %bb43, label %bb44
bb43:
  br label %bb64
bb44:
  br label %bb45
bb45:
  %t182 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s2, ptr %l10, i64 %t182)
  br label %bb46
bb46:
  %t185 = load ptr, ptr %lp2
  %t186 = getelementptr %"compiler/profile:Tally", ptr %t185, i32 0, i32 1
  %t187 = load i64, ptr %l15, !tbaa !24
  %t190 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t186, i64 %t187)
  store i1 %t190, ptr %l100
  br label %bb47
bb47:
  %t191 = load i1, ptr %l100, !tbaa !21
  %t192 = xor i1 %t191, true
  br i1 %t192, label %bb48, label %bb49
bb48:
  %t194 = load ptr, ptr %lp2
  %t195 = getelementptr %"compiler/profile:Tally", ptr %t194, i32 0, i32 0
  %t196 = load i64, ptr %l15, !tbaa !24
  %t199 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v2, ptr %t195, i64 %t196)
  store i1 %t199, ptr %l105
  br label %bb50
bb49:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb51
bb50:
  %t200 = load i1, ptr %l105, !tbaa !21
  %t201 = xor i1 %t200, true
  store i1 %t201, ptr %l102, !tbaa !21
  br label %bb51
bb51:
  %t203 = load i1, ptr %l102, !tbaa !21
  br i1 %t203, label %bb52, label %bb53
bb52:
  %t204 = load ptr, ptr %lp2
  %t205 = getelementptr %"compiler/profile:Tally", ptr %t204, i32 0, i32 5
  %t206 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v2, ptr %t205, i64 %t206)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t209 = load ptr, ptr %lp2
  %t210 = getelementptr %"compiler/profile:Tally", ptr %t209, i32 0, i32 1
  %t211 = load i64, ptr %l15, !tbaa !24
  %t212 = load i64, ptr %l7, !tbaa !24
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t210, i64 %t211, i64 %t212)
  br label %bb56
bb56:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l113, !tbaa !24
  %t220 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %l6)
  store i64 %t220, ptr %l115
  br label %bb57
bb57:
  %t221 = load i64, ptr %l113, !tbaa !24
  %t222 = load i64, ptr %l115, !tbaa !24
  %t223 = icmp slt i64 %t221, %t222
  br i1 %t223, label %bb58, label %bb59
bb58:
  %t225 = load ptr, ptr %lp2
  %t226 = getelementptr %"compiler/profile:Tally", ptr %t225, i32 0, i32 4
  store ptr %t226, ptr %l117, !tbaa !29
  %t227 = load i64, ptr %l15, !tbaa !24
  %t229 = mul i64 %t227, 16777216
  store i64 %t229, ptr %l119, !tbaa !24
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/profile:Places", ptr %t230, i32 0, i32 2
  store ptr %t232, ptr %l121, !tbaa !29
  %t233 = load i64, ptr %l13, !tbaa !24
  %t235 = add i64 %t233, 1
  %t238 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %l6, i64 %t235)
  store i64 %t238, ptr %l125
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t239 = load ptr, ptr %l121, !tbaa !29
  %t240 = load i64, ptr %l125, !tbaa !24
  %t241 = call %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v1, ptr %t239, i64 %t240)
  store %"compiler/profile:Frame" %t241, ptr %l126
  br label %bb61
bb61:
  %t242 = getelementptr %"compiler/profile:Frame", ptr %l126, i32 0, i32 0
  %t243 = load i64, ptr %t242, !tbaa !24
  %t244 = load i64, ptr %l119, !tbaa !24
  %t246 = add i64 %t244, %t243
  %t247 = load i64, ptr %l7, !tbaa !24
  %t248 = load ptr, ptr %l117, !tbaa !29
  call void @compiler_2fprofile_2eadd(ptr %v2, ptr %t248, i64 %t246, i64 %t247)
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t251 = load i64, ptr %l12, !tbaa !24
  %t254 = add i64 %t251, 1
  store i64 %t254, ptr %l12, !tbaa !24
  br label %bb35
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb66:
  %t256 = load i64, ptr %l4, !tbaa !24
  %t259 = add i64 %t256, 1
  store i64 %t259, ptr %l4, !tbaa !24
  br label %bb2
bb67:
  %t261 = load ptr, ptr %lp2
  call void @llvm.memmove.p0.p0.i64(ptr %l136, ptr %t261, i64 424, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l136, i64 424, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprofile_2eadd(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l9
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = add i64 %t14, %a2
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t17, i64 %t18, i64 %t16)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprofile_2eescapeXml(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb24
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = icmp eq i8 %t25, 60
  br i1 %t27, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d108, i32 0, i32 1) })
  br label %bb8
bb7:
  %t30 = load i8, ptr %l5, !tbaa !22
  %t32 = icmp eq i8 %t30, 62
  br i1 %t32, label %bb9, label %bb10
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d109, i32 0, i32 1) })
  br label %bb11
bb10:
  %t35 = load i8, ptr %l5, !tbaa !22
  %t37 = icmp eq i8 %t35, 38
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb12:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l1, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d110, i32 0, i32 1) })
  br label %bb14
bb13:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 34
  br i1 %t42, label %bb15, label %bb16
bb14:
  call void @__olang_scope_close(ptr %s7)
  br label %bb20
bb15:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %l1, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb17
bb16:
  %t45 = load i8, ptr %l5, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l1, i8 %t45)
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s9)
  br label %bb19
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = add i64 %t48, 1
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb2
bb24:
  %t54 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t54, ptr %l35
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2fprofile_2efileLine(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l12 = alloca { { i64, ptr }, i64 }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l31 = alloca { { i64, ptr }, i64 }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i32
  %l57 = alloca i64
  %l58 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64 }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) })
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i64 %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t14, 0
  %t18 = insertvalue { { i64, ptr }, i64 } %t17, i64 0, 1
  store { { i64, ptr }, i64 } %t18, ptr %l12
  %t19 = getelementptr { { i64, ptr }, i64 }, ptr %l12, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l13, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = mul i64 %t23, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l14, !tbaa !24
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t35 = getelementptr { { i64, ptr }, i64 }, ptr %l12, i32 0, i32 0
  store { i64, ptr } %t34, ptr %t35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t36 = load { { i64, ptr }, i64 }, ptr %l12
  store { { i64, ptr }, i64 } %t36, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = load i64, ptr %l1, !tbaa !24
  store i64 %t38, ptr %l17, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 0, 0
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t43 = load i64, ptr %l17, !tbaa !24
  %t44 = icmp sle i64 0, %t43
  br i1 %t44, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb10:
  %t46 = load i64, ptr %l17, !tbaa !24
  %t47 = load i64, ptr %l18, !tbaa !24
  %t48 = icmp sle i64 %t46, %t47
  br i1 %t48, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb12:
  %t50 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = load i64, ptr %l17, !tbaa !24
  %t53 = getelementptr i8, ptr %t51, i64 0
  %t54 = sub i64 %t52, 0
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %l2, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %s0, { i64, ptr } %t58, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d113, i32 0, i32 1) })
  %t61 = extractvalue { i32, i64 } %t60, 1
  %t62 = extractvalue { i32, i64 } %t60, 0
  store i32 %t62, ptr %l26
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb15, label %ok.64, !prof !99
ok.64:
  store i64 %t61, ptr %l25
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9)
  unreachable
bb14:
  %t65 = load i64, ptr %l25, !tbaa !24
  store i64 %t65, ptr %l23, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb17
bb17:
  %t66 = load i64, ptr %l23, !tbaa !24
  store i64 %t66, ptr %l3, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t69 = icmp slt i64 %t67, 0
  br i1 %t69, label %bb18, label %bb19
bb18:
  %t71 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t74 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t71, 0
  %t75 = insertvalue { { i64, ptr }, i64 } %t74, i64 0, 1
  store { { i64, ptr }, i64 } %t75, ptr %l31
  %t76 = getelementptr { { i64, ptr }, i64 }, ptr %l31, i32 0, i32 0
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l32, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l33, !tbaa !24
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l34, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l33, !tbaa !24
  %t90 = mul i64 %t89, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t86, ptr %t88, i64 %t90, i1 false)
  %t91 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t92 = getelementptr { { i64, ptr }, i64 }, ptr %l31, i32 0, i32 0
  store { i64, ptr } %t91, ptr %t92, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { { i64, ptr }, i64 }, ptr %l31
  store { { i64, ptr }, i64 } %t93, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t94, ptr %l35, !tbaa !27
  %t95 = load i64, ptr %l3, !tbaa !24
  store i64 %t95, ptr %l36, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l37, !tbaa !24
  %t98 = icmp sge i64 0, 0
  br i1 %t98, label %bb21, label %bb22
bb21:
  %t100 = load i64, ptr %l36, !tbaa !24
  %t101 = icmp sle i64 0, %t100
  br i1 %t101, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb23:
  %t103 = load i64, ptr %l36, !tbaa !24
  %t104 = load i64, ptr %l37, !tbaa !24
  %t105 = icmp sle i64 %t103, %t104
  br i1 %t105, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb25:
  %t107 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = load i64, ptr %l36, !tbaa !24
  %t110 = getelementptr i8, ptr %t108, i64 0
  %t111 = sub i64 %t109, 0
  %t112 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t115 = extractvalue { i64, ptr } %t113, 1
  %t116 = extractvalue { i64, ptr } %t113, 0
  %t117 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t116)
  call void @olang_textcopy(ptr %t117, ptr %t115, i64 %t116)
  %t118 = insertvalue { i64, ptr } undef, i64 %t116, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t117, 1
  store { i64, ptr } %t119, ptr %l42, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t120, ptr %l44, !tbaa !27
  %t121 = load i64, ptr %l3, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l46, !tbaa !24
  %t124 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t124, 0
  store i64 %t127, ptr %l49, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  store i64 %t129, ptr %l50, !tbaa !24
  %t130 = load i64, ptr %l46, !tbaa !24
  %t131 = icmp sge i64 %t130, 0
  br i1 %t131, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb27:
  %t133 = load i64, ptr %l46, !tbaa !24
  %t134 = load i64, ptr %l49, !tbaa !24
  %t135 = icmp sle i64 %t133, %t134
  br i1 %t135, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb29:
  %t137 = load i64, ptr %l49, !tbaa !24
  %t138 = load i64, ptr %l50, !tbaa !24
  %t139 = icmp sle i64 %t137, %t138
  br i1 %t139, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb31:
  %t141 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = load i64, ptr %l46, !tbaa !24
  %t144 = load i64, ptr %l49, !tbaa !24
  %t145 = getelementptr i8, ptr %t142, i64 %t143
  %t146 = sub i64 %t144, %t143
  %t147 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t145, 1
  store { i64, ptr } %t148, ptr %l54, !tbaa !27
  %t149 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t150 = extractvalue { i32, i64 } %t149, 1
  %t151 = extractvalue { i32, i64 } %t149, 0
  store i32 %t151, ptr %l56
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb34, label %ok.153, !prof !99
ok.153:
  store i64 %t150, ptr %l55
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_ec3589048a52ea40_4feb0c814716a05c)
  unreachable
bb33:
  %t154 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t155 = load i64, ptr %l55, !tbaa !24
  %t156 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t154, i64 %t155)
  %t157 = extractvalue { i32, i64 } %t156, 1
  %t158 = extractvalue { i32, i64 } %t156, 0
  store i32 %t158, ptr %l58
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb37, label %ok.160, !prof !99
ok.160:
  store i64 %t157, ptr %l57
  br label %bb36
bb34:
  br label %bb35
bb35:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb38
bb36:
  %t161 = load i64, ptr %l57, !tbaa !24
  store i64 %t161, ptr %l43, !tbaa !24
  br label %bb38
bb37:
  br label %bb35
bb38:
  %t162 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t163 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t162, 0
  %t164 = load i64, ptr %l43, !tbaa !24
  %t165 = insertvalue { { i64, ptr }, i64 } %t163, i64 %t164, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i64 } %t165, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2efunctionSymbols(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l35 = alloca i1
  %l42 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l107 = alloca i64
  %l110 = alloca i1
  %l117 = alloca i64
  %l122 = alloca i64
  %l127 = alloca i64
  %l132 = alloca i64
  %l141 = alloca i64
  %l144 = alloca i1
  %l157 = alloca i64
  %l160 = alloca i64
  %l187 = alloca i64
  %l188 = alloca { i64, ptr }
  %l195 = alloca i1
  %l198 = alloca i64
  %l202 = alloca i64
  %l209 = alloca i1
  %l210 = alloca { i64, ptr }
  %l219 = alloca ptr
  %l220 = alloca i64
  %l225 = alloca i64
  %l226 = alloca { i64, ptr }
  %l227 = alloca i64
  %l228 = alloca i64
  %l229 = alloca i64
  %l235 = alloca %"compiler/profile:elfFn"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l29
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
  %t8 = extractvalue { i32, { i64, ptr } } %t7, 1
  %t9 = extractvalue { i32, { i64, ptr } } %t7, 0
  store i32 %t9, ptr %l33
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store { i64, ptr } %t8, ptr %l32
  br label %bb2
bb2:
  %t12 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t12, ptr %l30, !tbaa !27
  br label %bb7
bb3:
  %t13 = load i32, ptr %l33, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  store i1 %t16, ptr %l35, !tbaa !21
  %t17 = load i32, ptr %l33, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %lp1
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %rv
  br label %ret
bb7:
  %t25 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp slt i64 %t28, 64
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb10
bb9:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l43, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr i8, ptr %t34, i64 0
  %t36 = load i8, ptr %t35, !tbaa !32
  %t39 = icmp ne i8 %t36, 127
  store i1 %t39, ptr %l42, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l42, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb13
bb12:
  %t42 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t42, ptr %l48, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 1
  %t46 = load i8, ptr %t45, !tbaa !32
  %t50 = icmp ne i8 %t46, 69
  store i1 %t50, ptr %l47, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l47, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb16
bb15:
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t53, ptr %l54, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i8, ptr %t55, i64 4
  %t57 = load i8, ptr %t56, !tbaa !32
  %t60 = icmp ne i8 %t57, 2
  store i1 %t60, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t62 = load i1, ptr %l53, !tbaa !21
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t63 = load ptr, ptr %lp1
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t63
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t69 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t66, i64 40, i64 8)
  store i64 %t69, ptr %l61
  br label %bb20
bb20:
  %t70 = load i64, ptr %l61, !tbaa !24
  store i64 %t70, ptr %l3, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t74 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t71, i64 58, i64 2)
  store i64 %t74, ptr %l64
  br label %bb21
bb21:
  %t75 = load i64, ptr %l64, !tbaa !24
  store i64 %t75, ptr %l4, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t79 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t76, i64 60, i64 2)
  store i64 %t79, ptr %l67
  br label %bb22
bb22:
  %t80 = load i64, ptr %l67, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb23, label %bb24
bb23:
  %t89 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb28
bb25:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l75, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb27
bb27:
  %t109 = load i64, ptr %l75, !tbaa !24
  store i64 %t109, ptr %l72, !tbaa !24
  br label %bb28
bb28:
  %t110 = load i64, ptr %l72, !tbaa !24
  store i64 %t110, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb29
bb29:
  %t111 = load i64, ptr %l10, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb30, label %bb31
bb30:
  br label %bb93
bb31:
  br label %bb32
bb32:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t120 = load i64, ptr %l10, !tbaa !24
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  %t129 = load i64, ptr %l3, !tbaa !24
  %t131 = load i64, ptr %l4, !tbaa !24
  %t134 = mul i64 %t127, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t141 = add i64 %t139, 64
  %t142 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t147 = icmp sgt i64 %t141, %t144
  br i1 %t147, label %bb33, label %bb34
bb33:
  br label %bb93
bb34:
  br label %bb35
bb35:
  %t149 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = add i64 %t151, 4
  %t156 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t149, i64 %t153, i64 4)
  store i64 %t156, ptr %l107
  br label %bb36
bb36:
  %t157 = load i64, ptr %l107, !tbaa !24
  store i64 %t157, ptr %l13, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t160 = icmp ne i64 %t158, 2
  br i1 %t160, label %bb37, label %bb38
bb37:
  %t162 = load i64, ptr %l13, !tbaa !24
  %t164 = icmp ne i64 %t162, 11
  store i1 %t164, ptr %l110, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb39
bb39:
  %t166 = load i1, ptr %l110, !tbaa !21
  br i1 %t166, label %bb40, label %bb41
bb40:
  br label %bb92
bb41:
  br label %bb42
bb42:
  %t167 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t169 = load i64, ptr %l12, !tbaa !24
  %t171 = add i64 %t169, 24
  %t174 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t167, i64 %t171, i64 8)
  store i64 %t174, ptr %l117
  br label %bb43
bb43:
  %t175 = load i64, ptr %l117, !tbaa !24
  store i64 %t175, ptr %l14, !tbaa !24
  %t176 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t178 = load i64, ptr %l12, !tbaa !24
  %t180 = add i64 %t178, 32
  %t183 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t176, i64 %t180, i64 8)
  store i64 %t183, ptr %l122
  br label %bb44
bb44:
  %t184 = load i64, ptr %l122, !tbaa !24
  store i64 %t184, ptr %l15, !tbaa !24
  %t185 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t187 = load i64, ptr %l12, !tbaa !24
  %t189 = add i64 %t187, 40
  %t192 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t185, i64 %t189, i64 4)
  store i64 %t192, ptr %l127
  br label %bb45
bb45:
  %t193 = load i64, ptr %l127, !tbaa !24
  store i64 %t193, ptr %l16, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t196 = load i64, ptr %l12, !tbaa !24
  %t198 = add i64 %t196, 56
  %t201 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t194, i64 %t198, i64 8)
  store i64 %t201, ptr %l132
  br label %bb46
bb46:
  %t202 = load i64, ptr %l132, !tbaa !24
  store i64 %t202, ptr %l17, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t205 = load i64, ptr %l3, !tbaa !24
  %t206 = load i64, ptr %l16, !tbaa !24
  %t207 = load i64, ptr %l4, !tbaa !24
  %t210 = mul i64 %t206, %t207
  %t213 = add i64 %t205, %t210
  %t215 = add i64 %t213, 24
  %t218 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t203, i64 %t215, i64 8)
  store i64 %t218, ptr %l141
  br label %bb47
bb47:
  %t219 = load i64, ptr %l141, !tbaa !24
  store i64 %t219, ptr %l18, !tbaa !24
  %t220 = load i64, ptr %l17, !tbaa !24
  %t222 = icmp slt i64 %t220, 24
  br i1 %t222, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l144, !tbaa !21
  br label %bb50
bb49:
  %t224 = load i64, ptr %l14, !tbaa !24
  %t225 = load i64, ptr %l15, !tbaa !24
  %t228 = add i64 %t224, %t225
  %t229 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t234 = icmp sgt i64 %t228, %t231
  store i1 %t234, ptr %l144, !tbaa !21
  br label %bb50
bb50:
  %t236 = load i1, ptr %l144, !tbaa !21
  br i1 %t236, label %bb51, label %bb52
bb51:
  br label %bb92
bb52:
  br label %bb53
bb53:
  store i64 0, ptr %l19, !tbaa !24
  %t237 = load i64, ptr %l15, !tbaa !24
  %t238 = load i64, ptr %l17, !tbaa !24
  %t241 = sdiv i64 %t237, %t238
  store i64 %t241, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t243 = load i64, ptr %l20, !tbaa !24
  %t244 = load i64, ptr %l19, !tbaa !24
  %t247 = icmp sgt i64 %t243, %t244
  br i1 %t247, label %bb54, label %bb55
bb54:
  %t249 = load i64, ptr %l21, !tbaa !24
  %t251 = icmp sgt i64 %t249, 0
  br i1 %t251, label %bb56, label %bb57
bb55:
  store i64 0, ptr %l157, !tbaa !24
  br label %bb59
bb56:
  %t253 = load i64, ptr %l20, !tbaa !24
  %t254 = load i64, ptr %l19, !tbaa !24
  %t257 = sub i64 %t253, %t254
  %t258 = load i64, ptr %l21, !tbaa !24
  %t261 = add i64 %t257, %t258
  %t263 = sub i64 %t261, 1
  %t264 = load i64, ptr %l21, !tbaa !24
  %t267 = sdiv i64 %t263, %t264
  store i64 %t267, ptr %l160, !tbaa !24
  br label %bb58
bb57:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb58
bb58:
  %t269 = load i64, ptr %l160, !tbaa !24
  store i64 %t269, ptr %l157, !tbaa !24
  br label %bb59
bb59:
  %t270 = load i64, ptr %l157, !tbaa !24
  store i64 %t270, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb60
bb60:
  %t271 = load i64, ptr %l23, !tbaa !24
  %t272 = load i64, ptr %l22, !tbaa !24
  %t275 = icmp slt i64 %t271, %t272
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb61, label %bb62
bb61:
  br label %bb91
bb62:
  br label %bb63
bb63:
  %t279 = load i64, ptr %l19, !tbaa !24
  %t280 = load i64, ptr %l23, !tbaa !24
  %t281 = load i64, ptr %l21, !tbaa !24
  %t284 = mul i64 %t280, %t281
  %t287 = add i64 %t279, %t284
  %t289 = load i64, ptr %l14, !tbaa !24
  %t291 = load i64, ptr %l17, !tbaa !24
  %t294 = mul i64 %t287, %t291
  %t297 = add i64 %t289, %t294
  store i64 %t297, ptr %l25, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t301 = load i64, ptr %l25, !tbaa !24
  %t303 = add i64 %t301, 8
  %t306 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t299, i64 %t303, i64 8)
  store i64 %t306, ptr %l187
  br label %bb64
bb64:
  %t307 = load i64, ptr %l187, !tbaa !24
  store i64 %t307, ptr %l26, !tbaa !24
  %t308 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t308, ptr %l188, !tbaa !27
  %t309 = load i64, ptr %l25, !tbaa !24
  %t311 = add i64 %t309, 4
  %t313 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t314 = load ptr, ptr %t313, !tbaa !27
  %t315 = getelementptr i8, ptr %t314, i64 %t311
  %t316 = load i8, ptr %t315, !tbaa !32
  %t318 = zext i8 %t316 to i64
  %t320 = and i64 %t318, 15
  %t322 = icmp ne i64 %t320, 2
  br i1 %t322, label %bb65, label %bb66
bb65:
  store i1 true, ptr %l195, !tbaa !21
  br label %bb67
bb66:
  %t324 = load i64, ptr %l26, !tbaa !24
  %t326 = icmp eq i64 %t324, 0
  store i1 %t326, ptr %l195, !tbaa !21
  br label %bb67
bb67:
  %t328 = load i1, ptr %l195, !tbaa !21
  br i1 %t328, label %bb68, label %bb69
bb68:
  br label %bb90
bb69:
  br label %bb70
bb70:
  %t329 = load i64, ptr %l18, !tbaa !24
  store i64 %t329, ptr %l198, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t332 = load i64, ptr %l25, !tbaa !24
  %t335 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t330, i64 %t332, i64 4)
  store i64 %t335, ptr %l202
  br label %bb71
bb71:
  %t336 = load i64, ptr %l198, !tbaa !24
  %t337 = load i64, ptr %l202, !tbaa !24
  %t338 = add i64 %t336, %t337
  store i64 %t338, ptr %l27, !tbaa !24
  %t340 = load i64, ptr %l27, !tbaa !24
  store i64 %t340, ptr %l28, !tbaa !24
  br label %bb72
bb72:
  %t342 = load i64, ptr %l28, !tbaa !24
  %t343 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t348 = icmp slt i64 %t342, %t345
  br i1 %t348, label %bb73, label %bb74
bb73:
  %t350 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t350, ptr %l210, !tbaa !27
  %t351 = load i64, ptr %l28, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i8, ptr %t354, i64 %t351
  %t356 = load i8, ptr %t355, !tbaa !32
  %t359 = icmp ne i8 %t356, 0
  store i1 %t359, ptr %l209, !tbaa !21
  br label %bb75
bb74:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb75
bb75:
  %t361 = load i1, ptr %l209, !tbaa !21
  %t362 = xor i1 %t361, true
  br i1 %t362, label %bb76, label %bb77
bb76:
  br label %bb80
bb77:
  br label %bb78
bb78:
  %t364 = load i64, ptr %l28, !tbaa !24
  %t367 = add i64 %t364, 1
  store i64 %t367, ptr %l28, !tbaa !24
  br label %bb79
bb79:
  br label %bb72
bb80:
  %t369 = load ptr, ptr %lp1
  store ptr %t369, ptr %l219, !tbaa !29
  %t370 = load i64, ptr %l26, !tbaa !24
  store i64 %t370, ptr %l220, !tbaa !24
  %t371 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t373 = load i64, ptr %l25, !tbaa !24
  %t375 = add i64 %t373, 16
  %t378 = call i64 @compiler_2fprofile_2ele(ptr %v1, { i64, ptr } %t371, i64 %t375, i64 8)
  store i64 %t378, ptr %l225
  br label %bb81
bb81:
  %t379 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t379, ptr %l226, !tbaa !27
  %t380 = load i64, ptr %l27, !tbaa !24
  store i64 %t380, ptr %l227, !tbaa !24
  %t381 = load i64, ptr %l28, !tbaa !24
  store i64 %t381, ptr %l228, !tbaa !24
  %t382 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t382, 0
  store i64 %t383, ptr %l229, !tbaa !24
  %t384 = load i64, ptr %l227, !tbaa !24
  %t385 = icmp sge i64 %t384, 0
  br i1 %t385, label %bb82, label %bb83
bb82:
  %t387 = load i64, ptr %l227, !tbaa !24
  %t388 = load i64, ptr %l228, !tbaa !24
  %t389 = icmp sle i64 %t387, %t388
  br i1 %t389, label %bb84, label %bb85
bb83:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb84:
  %t391 = load i64, ptr %l228, !tbaa !24
  %t392 = load i64, ptr %l229, !tbaa !24
  %t393 = icmp sle i64 %t391, %t392
  br i1 %t393, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb86:
  %t395 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = load i64, ptr %l227, !tbaa !24
  %t398 = load i64, ptr %l228, !tbaa !24
  %t399 = getelementptr i8, ptr %t396, i64 %t397
  %t400 = sub i64 %t398, %t397
  %t401 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t399, 1
  %t404 = load i64, ptr %l220, !tbaa !24
  %t405 = load i64, ptr %l225, !tbaa !24
  %t407 = call %"compiler/profile:elfFn" @compiler_2fprofile_3aelfFn_2ector(ptr %v1, ptr %v1, i64 %t404, i64 %t405, { i64, ptr } %t402)
  store %"compiler/profile:elfFn" %t407, ptr %l235
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_47d41d181de998ca_407a2b261e632036)
  unreachable
bb88:
  %t408 = load ptr, ptr %l219, !tbaa !29
  %t409 = load %"compiler/profile:elfFn", ptr %l235
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ePush_3ccompiler_2fprofile_3aelfFn_3e(ptr %v1, ptr %v1, ptr %t408, %"compiler/profile:elfFn" %t409)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t410 = load i64, ptr %l23, !tbaa !24
  %t413 = add i64 %t410, 1
  store i64 %t413, ptr %l23, !tbaa !24
  br label %bb60
bb91:
  br label %bb92
bb92:
  %t415 = load i64, ptr %l10, !tbaa !24
  %t418 = add i64 %t415, 1
  store i64 %t418, ptr %l10, !tbaa !24
  br label %bb29
bb93:
  %t420 = load ptr, ptr %lp1
  %t421 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_114, 0
  %t422 = insertvalue { ptr, ptr } %t421, ptr null, 1
  %t425 = extractvalue { ptr, ptr } %t422, 0
  %t426 = extractvalue { ptr, ptr } %t422, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eSort_3_H16cb1151e861568c30a5b57cf3c12bc1(ptr %v1, ptr %s0, ptr %t420, ptr %t425, ptr %t426)
  br label %bb94
bb94:
  %t427 = load ptr, ptr %lp1
  %t428 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t427
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t428, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2fprofile_2ehex(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  %t2 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t3 = extractvalue { i32, i64 } %t2, 1
  %t4 = extractvalue { i32, i64 } %t2, 0
  store i32 %t4, ptr %l4
  %t5 = icmp ne i32 %t4, 0
  br i1 %t5, label %bb2, label %ok.6, !prof !99
ok.6:
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t7, i64 %t8)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l6
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb5, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l5
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb6
bb4:
  %t14 = load i64, ptr %l5, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb6
bb5:
  br label %bb3
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fprofile_2eidentityChar(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t1)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb5
bb3:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t5)
  store i1 %t7, ptr %l5
  br label %bb4
bb4:
  %t8 = load i1, ptr %l5, !tbaa !21
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb5
bb5:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb8
bb7:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp eq i8 %t10, 95
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb8
bb8:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb11
bb10:
  %t15 = load i8, ptr %l0, !tbaa !22
  %t17 = icmp eq i8 %t15, 47
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb11
bb11:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb14
bb13:
  %t20 = load i8, ptr %l0, !tbaa !22
  %t22 = icmp eq i8 %t20, 45
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb14
bb14:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb17
bb16:
  %t25 = load i8, ptr %l0, !tbaa !22
  %t27 = icmp eq i8 %t25, 126
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb17
bb17:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fprofile_2ele(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i1
  %l41 = alloca { i64, ptr }
  %l48 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 %a2, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t3 = load i64, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp sgt i64 %t3, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = sub i64 %t13, %t14
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = add i64 %t17, %t18
  %t23 = sub i64 %t21, 1
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = sdiv i64 %t23, %t24
  store i64 %t27, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l14, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t32 = sub i64 %t31, 1
  store i64 %t32, ptr %l26, !tbaa !24
  %t33 = load i64, ptr %l7, !tbaa !24
  %t34 = icmp slt i64 %t33, 2147483648
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = icmp sge i64 %t35, 0
  %t39 = and i1 %t34, %t36
  store i1 %t39, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t40 = load i64, ptr %l8, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l3, !tbaa !24
  store { i64, ptr } %a0, ptr %l41, !tbaa !27
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = add i64 %a1, %t62
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = zext i8 %t70 to i64
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = mul i64 %t73, 8
  store i64 %t75, ptr %l48, !tbaa !24
  %t77 = load i64, ptr %l48, !tbaa !24
  %t78 = load i64, ptr %l48, !tbaa !24
  %t79 = shl i64 %t72, %t78
  %t82 = or i64 %t58, %t79
  store i64 %t82, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  %t89 = load i64, ptr %l3, !tbaa !24
  store i64 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2emappings(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/text:LineIter"
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/text:LineIter"
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i32
  %l56 = alloca %"std/prelude/text:StringBuilder"
  %l58 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l86 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca i64
  %l110 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i64
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca i64
  %l126 = alloca { i64, ptr }
  %l128 = alloca %"compiler/profile:mapping"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t5 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store %"std/prelude/text:LineIter" %t5, ptr %l19
  br label %bb2
bb2:
  %t6 = load %"std/prelude/text:LineIter", ptr %l19
  store %"std/prelude/text:LineIter" %t6, ptr %l2
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v0, ptr %l2)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l23
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l22
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t13, ptr %l20, !tbaa !27
  br label %bb7
bb5:
  %t14 = load i32, ptr %l23, !tbaa !23
  %t15 = ashr i32 %t14, 16
  %t17 = icmp eq i32 %t15, 1
  store i1 %t17, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb78
bb7:
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l26
  br label %bb8
bb8:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l4
  store %olang.scope zeroinitializer, ptr %s3
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s3, ptr %v0, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) })
  store { i64, ptr } %t23, ptr %l28
  br label %bb9
bb9:
  %t24 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t29 = load i64, ptr %l6, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t37, ptr %l35, !tbaa !27
  %t38 = load i64, ptr %l6, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  store { i64, ptr } %t43, ptr %l8, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t45, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d116, i32 0, i32 1) })
  store i1 %t47, ptr %l39
  br label %bb14
bb14:
  %t48 = load i1, ptr %l39, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  %t51 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %v0, ptr %l4, { i64, ptr } %t51)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %l6, !tbaa !24
  br label %bb10
bb20:
  call void @__olang_scope_close(ptr %s3)
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l4)
  store i64 %t60, ptr %l47
  br label %bb21
bb21:
  %t61 = load i64, ptr %l47, !tbaa !24
  %t62 = icmp slt i64 %t61, 6
  br i1 %t62, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb77
bb23:
  br label %bb24
bb24:
  %t65 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t65, ptr %l51
  br label %bb25
bb25:
  %t66 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t67 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %s2, ptr %s2, { i64, ptr } %t66, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) })
  %t68 = extractvalue { i32, i64 } %t67, 1
  %t69 = extractvalue { i32, i64 } %t67, 0
  store i32 %t69, ptr %l53
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb27, label %ok.71, !prof !99
ok.71:
  store i64 %t68, ptr %l52
  br label %bb26
bb26:
  %t72 = load i64, ptr %l52, !tbaa !24
  store i64 %t72, ptr %l49, !tbaa !24
  br label %bb29
bb27:
  br label %bb28
bb28:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb29
bb29:
  %t73 = load i64, ptr %l49, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t76 = icmp slt i64 %t74, 0
  br i1 %t76, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb77
bb31:
  br label %bb32
bb32:
  %t78 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t78, ptr %l56
  br label %bb33
bb33:
  %t79 = load %"std/prelude/text:StringBuilder", ptr %l56
  store %"std/prelude/text:StringBuilder" %t79, ptr %l10
  store i64 5, ptr %l11, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l4)
  store i64 %t81, ptr %l58
  br label %bb34
bb34:
  %t82 = load i64, ptr %l58, !tbaa !24
  store i64 %t82, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t83 = load i64, ptr %l12, !tbaa !24
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb35, label %bb36
bb35:
  %t89 = load i64, ptr %l13, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb40
bb37:
  %t93 = load i64, ptr %l12, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l13, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l13, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l65, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb39
bb39:
  %t109 = load i64, ptr %l65, !tbaa !24
  store i64 %t109, ptr %l62, !tbaa !24
  br label %bb40
bb40:
  %t110 = load i64, ptr %l62, !tbaa !24
  store i64 %t110, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t111 = load i64, ptr %l15, !tbaa !24
  %t112 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb42, label %bb43
bb42:
  br label %bb52
bb43:
  br label %bb44
bb44:
  %t119 = load i64, ptr %l11, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t121 = load i64, ptr %l13, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l16, !tbaa !24
  %t129 = load i64, ptr %l16, !tbaa !24
  %t131 = icmp sgt i64 %t129, 5
  br i1 %t131, label %bb45, label %bb46
bb45:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s2, ptr %l10, i8 32)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb48
bb48:
  store ptr %l10, ptr %l86, !tbaa !29
  %t134 = load i64, ptr %l16, !tbaa !24
  %t137 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 %t134)
  store { i64, ptr } %t137, ptr %l89
  br label %bb49
bb49:
  %t138 = load ptr, ptr %l86, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l89, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s2, ptr %t138, { i64, ptr } %t139)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t140 = load i64, ptr %l15, !tbaa !24
  %t143 = add i64 %t140, 1
  store i64 %t143, ptr %l15, !tbaa !24
  br label %bb41
bb52:
  store ptr %l1, ptr %l93, !tbaa !29
  %t146 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t146, ptr %l95
  br label %bb53
bb53:
  %t147 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t147, ptr %l96, !tbaa !27
  %t148 = load i64, ptr %l9, !tbaa !24
  store i64 %t148, ptr %l97, !tbaa !24
  %t149 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  store i64 %t150, ptr %l98, !tbaa !24
  %t151 = icmp sge i64 0, 0
  br i1 %t151, label %bb54, label %bb55
bb54:
  %t153 = load i64, ptr %l97, !tbaa !24
  %t154 = icmp sle i64 0, %t153
  br i1 %t154, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb56:
  %t156 = load i64, ptr %l97, !tbaa !24
  %t157 = load i64, ptr %l98, !tbaa !24
  %t158 = icmp sle i64 %t156, %t157
  br i1 %t158, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb58:
  %t160 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = load i64, ptr %l97, !tbaa !24
  %t163 = getelementptr i8, ptr %t161, i64 0
  %t164 = sub i64 %t162, 0
  %t165 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t163, 1
  %t168 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t166)
  store i64 %t168, ptr %l103
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb60:
  %t170 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t170, ptr %l105
  br label %bb61
bb61:
  %t171 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t171, ptr %l106, !tbaa !27
  %t172 = load i64, ptr %l9, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l108, !tbaa !24
  %t176 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 0)
  store { i64, ptr } %t176, ptr %l110
  br label %bb62
bb62:
  %t177 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t177, 0
  store i64 %t180, ptr %l113, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l114, !tbaa !24
  %t183 = load i64, ptr %l108, !tbaa !24
  %t184 = icmp sge i64 %t183, 0
  br i1 %t184, label %bb63, label %bb64
bb63:
  %t186 = load i64, ptr %l108, !tbaa !24
  %t187 = load i64, ptr %l113, !tbaa !24
  %t188 = icmp sle i64 %t186, %t187
  br i1 %t188, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb65:
  %t190 = load i64, ptr %l113, !tbaa !24
  %t191 = load i64, ptr %l114, !tbaa !24
  %t192 = icmp sle i64 %t190, %t191
  br i1 %t192, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb67:
  %t194 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l108, !tbaa !24
  %t197 = load i64, ptr %l113, !tbaa !24
  %t198 = getelementptr i8, ptr %t195, i64 %t196
  %t199 = sub i64 %t197, %t196
  %t200 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t198, 1
  %t203 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t201)
  store i64 %t203, ptr %l119
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_49a351722641e944_c5b141a1c073228)
  unreachable
bb69:
  %t205 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %l4, i64 2)
  store { i64, ptr } %t205, ptr %l121
  br label %bb70
bb70:
  %t206 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t207 = call i64 @compiler_2fprofile_2ehex(ptr %s2, { i64, ptr } %t206)
  store i64 %t207, ptr %l122
  br label %bb71
bb71:
  %t208 = call ptr @__olang_scope_hold(ptr %v1)
  %t209 = ptrtoint ptr %t208 to i64
  store i64 %t209, ptr %l123, !tbaa !24
  %t210 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3amapping_2e3
  br i1 %t210, label %bb72, label %bb73
bb72:
  %t212 = call ptr @__olang_region_make(ptr %v1)
  %t213 = ptrtoint ptr %t212 to i64
  store i64 %t213, ptr %l123, !tbaa !24
  br label %bb73
bb73:
  %t214 = load i64, ptr %l123
  %t215 = inttoptr i64 %t214 to ptr
  %t217 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %t215, ptr %l10)
  store { i64, ptr } %t217, ptr %l126
  br label %bb74
bb74:
  %t218 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t219 = load i64, ptr %l103, !tbaa !24
  %t220 = load i64, ptr %l119, !tbaa !24
  %t221 = load i64, ptr %l122, !tbaa !24
  %t223 = call %"compiler/profile:mapping" @compiler_2fprofile_3amapping_2ector(ptr %v1, ptr %v1, i64 %t219, i64 %t220, i64 %t221, { i64, ptr } %t218)
  store %"compiler/profile:mapping" %t223, ptr %l128
  br label %bb75
bb75:
  %t224 = load ptr, ptr %l93, !tbaa !29
  %t225 = load %"compiler/profile:mapping", ptr %l128
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ePush_Hc0dd0b8028ee4ec7edce99e352ae7bbd(ptr %v1, ptr %v1, ptr %t224, %"compiler/profile:mapping" %t225)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s2)
  br label %bb77
bb77:
  br label %bb3
bb78:
  %t226 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t226, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2emillis(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = sitofp i64 %a0 to double
  %t6 = sitofp i64 %a1 to double
  %t9 = fmul double %t3, %t6
  %t11 = fdiv double %t9, 0x412e848000000000
  %t13 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %t11, i64 1)
  store { i64, ptr } %t13, ptr %l8
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca [1 x i32]
  %l13 = alloca i32
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l37 = alloca i32
  %l38 = alloca i32
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l51 = alloca { i64, ptr }
  %l53 = alloca i32
  %l57 = alloca i64
  %l58 = alloca i64
  %l63 = alloca i32
  %l69 = alloca i1
  %l72 = alloca i64
  %l74 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l4, { i64, ptr } %a1)
  br label %bb2
bb2:
  store { i64, ptr } %a2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp slt i64 %t12, %t13
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb9
bb5:
  br label %bb6
bb6:
  %t20 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t20, ptr %l24, !tbaa !27
  %t21 = load i64, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr { i64, ptr }, ptr %t24, i64 %t21
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l4, { i64, ptr } %t26)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = add i64 %t31, 1
  store i64 %t34, ptr %l6, !tbaa !24
  br label %bb3
bb9:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t39 = extractvalue { i64, ptr } %a3, 1
  %t40 = extractvalue { i64, ptr } %a3, 0
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t39, i64 %t40)
  %t45 = getelementptr i8, ptr %t44, i64 %t40
  call void @olang_textcopy(ptr %t45, ptr %t41, i64 %t42)
  %t46 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t44, 1
  %t50 = extractvalue { i64, ptr } %t36, 1
  %t51 = extractvalue { i64, ptr } %t36, 0
  %t53 = extractvalue { i64, ptr } %t47, 1
  %t54 = extractvalue { i64, ptr } %t47, 0
  %t55 = call i32 @setenv(ptr %t50, ptr %t53, i32 1)
  store i32 %t55, ptr %l37
  br label %bb10
bb10:
  %t56 = call i32 @fork()
  store i32 %t56, ptr %l38
  br label %bb11
bb11:
  %t57 = load i32, ptr %l38, !tbaa !23
  store i32 %t57, ptr %l9, !tbaa !23
  %t58 = load i32, ptr %l9, !tbaa !23
  %t60 = icmp eq i32 %t58, 0
  br i1 %t60, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %s5, { i64, ptr } %a0)
  store { i64, ptr } %t64, ptr %l42
  br label %bb14
bb13:
  br label %bb23
bb14:
  %t65 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t65, ptr %l43, !tbaa !27
  %t67 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t67, ptr %l45
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t70 = call i32 @std_2fos_2eExecInPlace(ptr %s5, ptr %s0, { i64, ptr } %t68, { i64, ptr } %t69)
  store i32 %t70, ptr %l46
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb17, label %ok.72, !prof !99
ok.72:
  br label %bb16
bb16:
  br label %bb21
bb17:
  %t73 = load i32, ptr %l46, !tbaa !23
  %t74 = ashr i32 %t73, 16
  %t76 = icmp eq i32 %t74, 1
  store i1 %t76, ptr %l48, !tbaa !21
  %t77 = load i32, ptr %l46, !tbaa !23
  %t78 = ashr i32 %t77, 16
  %t80 = icmp eq i32 %t78, 1
  br i1 %t80, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  call void @_exit(i32 127)
  unreachable
bb22:
  call void @__olang_check_failed(ptr @olang_loc_ec22c3592c386ac4_6a748f217c4c44c0)
  unreachable
bb23:
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %l51, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = extractvalue { i64, ptr } %t82, 0
  %t86 = call i32 @unsetenv(ptr %t84)
  store i32 %t86, ptr %l53
  br label %bb24
bb24:
  %t87 = load i32, ptr %l9, !tbaa !23
  %t89 = icmp slt i32 %t87, 0
  br i1 %t89, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t92 = call i64 @signal(i32 2, i64 1)
  store i64 %t92, ptr %l57
  br label %bb28
bb28:
  %t93 = load i64, ptr %l57, !tbaa !24
  store i64 %t93, ptr %l10, !tbaa !24
  %t94 = call i64 @signal(i32 3, i64 1)
  store i64 %t94, ptr %l58
  br label %bb29
bb29:
  %t95 = load i64, ptr %l58, !tbaa !24
  store i64 %t95, ptr %l11, !tbaa !24
  %t96 = insertvalue [1 x i32] undef, i32 0, 0
  store [1 x i32] %t96, ptr %l12
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  %t98 = load i32, ptr %l9, !tbaa !23
  %t100 = insertvalue { i64, ptr } undef, i64 1, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %l12, 1
  %t104 = extractvalue { i64, ptr } %t101, 1
  %t105 = extractvalue { i64, ptr } %t101, 0
  %t106 = call i32 @waitpid(i32 %t98, ptr %t104, i32 0)
  store i32 %t106, ptr %l63
  br label %bb31
bb31:
  %t107 = load i32, ptr %l63, !tbaa !23
  %t108 = icmp slt i32 %t107, 0
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb33:
  br label %bb34
bb34:
  %t112 = load i32, ptr %l9, !tbaa !23
  %t113 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t116 = sext i32 %t112 to i64
  %t117 = call i64 @__olang_fmt_i64(ptr null, i64 %t116)
  %t118 = add i64 %t114, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t113, i64 %t114)
  %t120 = getelementptr i8, ptr %t119, i64 %t114
  %t121 = call i64 @__olang_fmt_i64(ptr %t120, i64 %t116)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t119, 1
  %t126 = call i1 @std_2fos_2eExists(ptr %s8, { i64, ptr } %t123)
  store i1 %t126, ptr %l69
  br label %bb35
bb35:
  %t127 = load i1, ptr %l69, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb40
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s8)
  br label %bb39
bb39:
  br label %bb30
bb40:
  %t130 = load i64, ptr %l10, !tbaa !24
  %t132 = call i64 @signal(i32 2, i64 %t130)
  store i64 %t132, ptr %l72
  br label %bb41
bb41:
  %t133 = load i64, ptr %l11, !tbaa !24
  %t135 = call i64 @signal(i32 3, i64 %t133)
  store i64 %t135, ptr %l74
  br label %bb42
bb42:
  %t136 = getelementptr [1 x i32], ptr %l12, i64 0, i64 0
  %t137 = load i32, ptr %t136, !tbaa !33
  store i32 %t137, ptr %l13, !tbaa !23
  %t139 = load i32, ptr %l13, !tbaa !23
  %t141 = and i32 %t139, 127
  %t143 = icmp ne i32 %t141, 0
  br i1 %t143, label %bb43, label %bb44
bb43:
  %t145 = load i32, ptr %l13, !tbaa !23
  %t147 = and i32 %t145, 127
  %t149 = add i32 128, %t147
  call void @__olang_scope_close(ptr %s0)
  store i32 %t149, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t151 = load i32, ptr %l13, !tbaa !23
  %t153 = ashr i32 %t151, 8
  %t155 = and i32 %t153, 255
  call void @__olang_scope_close(ptr %s0)
  store i32 %t155, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2esampleFile(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca { i64, ptr }
  %l63 = alloca i64
  %l66 = alloca i64
  %l87 = alloca i64
  %l104 = alloca { i64, ptr }
  %l110 = alloca i64
  %l113 = alloca i64
  %l134 = alloca i64
  %l151 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l163 = alloca i64
  %l164 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l31
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d122, i32 0, i32 1) }, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l38, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t21)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t27, 1
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb2
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = insertvalue [4 x i64] undef, i64 1000000, 0
  %t37 = insertvalue [4 x i64] %t35, i64 %t34, 1
  %t38 = insertvalue [4 x i64] %t37, i64 2, 2
  %t39 = insertvalue [4 x i64] %t38, i64 1, 3
  %t41 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store [4 x i64] %t39, ptr %t41
  store ptr %t41, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load ptr, ptr %l7
  store i64 4, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  br label %bb27
bb11:
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l7
  %t55 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr [4 x i64], ptr %t54, i64 0, i64 %t55
  %t59 = load i64, ptr %t58, !tbaa !34
  store i64 %t59, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  store i64 8, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t61 = load i64, ptr %l12, !tbaa !24
  %t62 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp sgt i64 %t61, %t62
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load i64, ptr %l13, !tbaa !24
  %t69 = icmp sgt i64 %t67, 0
  br i1 %t69, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb18
bb15:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = sub i64 %t71, %t72
  %t76 = load i64, ptr %l13, !tbaa !24
  %t79 = add i64 %t75, %t76
  %t81 = sub i64 %t79, 1
  %t82 = load i64, ptr %l13, !tbaa !24
  %t85 = sdiv i64 %t81, %t82
  store i64 %t85, ptr %l66, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb17
bb17:
  %t87 = load i64, ptr %l66, !tbaa !24
  store i64 %t87, ptr %l63, !tbaa !24
  br label %bb18
bb18:
  %t88 = load i64, ptr %l63, !tbaa !24
  store i64 %t88, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  %t89 = load i64, ptr %l15, !tbaa !24
  %t90 = load i64, ptr %l14, !tbaa !24
  %t93 = icmp slt i64 %t89, %t90
  %t95 = xor i1 %t93, true
  br i1 %t95, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l15, !tbaa !24
  %t99 = load i64, ptr %l13, !tbaa !24
  %t102 = mul i64 %t98, %t99
  %t105 = add i64 %t97, %t102
  %t107 = load i64, ptr %l10, !tbaa !24
  %t110 = mul i64 %t105, 8
  store i64 %t110, ptr %l87, !tbaa !24
  %t112 = load i64, ptr %l87, !tbaa !24
  %t113 = load i64, ptr %l87, !tbaa !24
  %t114 = ashr i64 %t107, %t113
  %t116 = and i64 %t114, 255
  %t118 = trunc i64 %t116 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t118)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t121 = load i64, ptr %l15, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l15, !tbaa !24
  br label %bb19
bb25:
  br label %bb26
bb26:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = add i64 %t126, 1
  store i64 %t129, ptr %l8, !tbaa !24
  br label %bb9
bb27:
  call void @__olang_scope_close(ptr %s4)
  %t131 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t131, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l19, !tbaa !24
  br label %bb28
bb28:
  %t137 = load i64, ptr %l18, !tbaa !24
  %t138 = load i64, ptr %l19, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb29, label %bb30
bb29:
  br label %bb46
bb30:
  br label %bb31
bb31:
  %t145 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t145, ptr %l104, !tbaa !27
  %t146 = load i64, ptr %l18, !tbaa !24
  %t148 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i64, ptr %t149, i64 %t146
  %t151 = load i64, ptr %t150, !tbaa !34
  store i64 %t151, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  store i64 8, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t153 = load i64, ptr %l22, !tbaa !24
  %t154 = load i64, ptr %l21, !tbaa !24
  %t157 = icmp sgt i64 %t153, %t154
  br i1 %t157, label %bb32, label %bb33
bb32:
  %t159 = load i64, ptr %l23, !tbaa !24
  %t161 = icmp sgt i64 %t159, 0
  br i1 %t161, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb37
bb34:
  %t163 = load i64, ptr %l22, !tbaa !24
  %t164 = load i64, ptr %l21, !tbaa !24
  %t167 = sub i64 %t163, %t164
  %t168 = load i64, ptr %l23, !tbaa !24
  %t171 = add i64 %t167, %t168
  %t173 = sub i64 %t171, 1
  %t174 = load i64, ptr %l23, !tbaa !24
  %t177 = sdiv i64 %t173, %t174
  store i64 %t177, ptr %l113, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb36
bb36:
  %t179 = load i64, ptr %l113, !tbaa !24
  store i64 %t179, ptr %l110, !tbaa !24
  br label %bb37
bb37:
  %t180 = load i64, ptr %l110, !tbaa !24
  store i64 %t180, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb38
bb38:
  %t181 = load i64, ptr %l25, !tbaa !24
  %t182 = load i64, ptr %l24, !tbaa !24
  %t185 = icmp slt i64 %t181, %t182
  %t187 = xor i1 %t185, true
  br i1 %t187, label %bb39, label %bb40
bb39:
  br label %bb44
bb40:
  br label %bb41
bb41:
  %t189 = load i64, ptr %l21, !tbaa !24
  %t190 = load i64, ptr %l25, !tbaa !24
  %t191 = load i64, ptr %l23, !tbaa !24
  %t194 = mul i64 %t190, %t191
  %t197 = add i64 %t189, %t194
  %t199 = load i64, ptr %l20, !tbaa !24
  %t202 = mul i64 %t197, 8
  store i64 %t202, ptr %l134, !tbaa !24
  %t204 = load i64, ptr %l134, !tbaa !24
  %t205 = load i64, ptr %l134, !tbaa !24
  %t206 = ashr i64 %t199, %t205
  %t208 = and i64 %t206, 255
  %t210 = trunc i64 %t208 to i8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t210)
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t213 = load i64, ptr %l25, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l25, !tbaa !24
  br label %bb38
bb44:
  br label %bb45
bb45:
  %t218 = load i64, ptr %l18, !tbaa !24
  %t221 = add i64 %t218, 1
  store i64 %t221, ptr %l18, !tbaa !24
  br label %bb28
bb46:
  store { i64, ptr } %a1, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t225, 0
  store i64 %t227, ptr %l29, !tbaa !24
  br label %bb47
bb47:
  %t229 = load i64, ptr %l28, !tbaa !24
  %t230 = load i64, ptr %l29, !tbaa !24
  %t233 = icmp slt i64 %t229, %t230
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t237 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t237, ptr %l151, !tbaa !27
  %t238 = load i64, ptr %l28, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr i8, ptr %t241, i64 %t238
  %t243 = load i8, ptr %t242, !tbaa !32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %s0, ptr %l2, i8 %t243)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t249 = load i64, ptr %l28, !tbaa !24
  %t252 = add i64 %t249, 1
  store i64 %t252, ptr %l28, !tbaa !24
  br label %bb47
bb53:
  %t255 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %s0, ptr %s0, ptr %l2)
  store { i64, ptr } %t255, ptr %l161
  br label %bb54
bb54:
  %t256 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t256, ptr %l162, !tbaa !27
  %t257 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 0
  store i64 %t258, ptr %l163, !tbaa !24
  %t259 = load i64, ptr %l163, !tbaa !24
  %t260 = mul i64 %t259, 1
  %t261 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t260)
  %t262 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  store { i64, ptr } %t263, ptr %l164, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = load i64, ptr %l163, !tbaa !24
  %t269 = mul i64 %t268, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t265, ptr %t267, i64 %t269, i1 false)
  %t270 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t270, ptr %l162, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t271 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t271, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2esegments(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l20 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l67 = alloca i64
  %l70 = alloca i64
  %l98 = alloca i1
  %l107 = alloca i64
  %l110 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca ptr
  %l121 = alloca i64
  %l122 = alloca ptr
  %l127 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %s0, { i64, ptr } %a0)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l18
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l17
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t10, ptr %l15, !tbaa !27
  br label %bb7
bb3:
  %t11 = load i32, ptr %l18, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l20, !tbaa !21
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
bb7:
  %t22 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t22, ptr %l2, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t27 = icmp slt i64 %t25, 64
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb10
bb9:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr i8, ptr %t31, i64 0
  %t33 = load i8, ptr %t32, !tbaa !32
  %t36 = icmp ne i8 %t33, 127
  store i1 %t36, ptr %l27, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l27, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb13
bb12:
  %t39 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t39, ptr %l33, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i8, ptr %t41, i64 1
  %t43 = load i8, ptr %t42, !tbaa !32
  %t47 = icmp ne i8 %t43, 69
  store i1 %t47, ptr %l32, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l32, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb16
bb15:
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t50, ptr %l39, !tbaa !27
  %t51 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 4
  %t54 = load i8, ptr %t53, !tbaa !32
  %t57 = icmp ne i8 %t54, 2
  store i1 %t57, ptr %l38, !tbaa !21
  br label %bb16
bb16:
  %t59 = load i1, ptr %l38, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t62, i64 4)
  store i64 %t65, ptr %l46
  br label %bb20
bb20:
  %t66 = load i64, ptr %l46, !tbaa !24
  store i64 %t66, ptr %l3, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t67, ptr %l47, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 54
  %t71 = load i8, ptr %t70, !tbaa !32
  %t73 = zext i8 %t71 to i64
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t74, ptr %l50, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 55
  %t78 = load i8, ptr %t77, !tbaa !32
  %t80 = zext i8 %t78 to i64
  %t82 = shl i64 %t80, 8
  %t85 = or i64 %t73, %t82
  store i64 %t85, ptr %l4, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l55, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 56
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = zext i8 %t91 to i64
  %t94 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t94, ptr %l58, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i8, ptr %t96, i64 57
  %t98 = load i8, ptr %t97, !tbaa !32
  %t100 = zext i8 %t98 to i64
  %t102 = shl i64 %t100, 8
  %t105 = or i64 %t93, %t102
  store i64 0, ptr %l6, !tbaa !24
  store i64 %t105, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = load i64, ptr %l6, !tbaa !24
  %t113 = icmp sgt i64 %t109, %t110
  br i1 %t113, label %bb21, label %bb22
bb21:
  %t115 = load i64, ptr %l8, !tbaa !24
  %t117 = icmp sgt i64 %t115, 0
  br i1 %t117, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb26
bb23:
  %t119 = load i64, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = sub i64 %t119, %t120
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = add i64 %t123, %t124
  %t129 = sub i64 %t127, 1
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = sdiv i64 %t129, %t130
  store i64 %t133, ptr %l70, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb25
bb25:
  %t135 = load i64, ptr %l70, !tbaa !24
  store i64 %t135, ptr %l67, !tbaa !24
  br label %bb26
bb26:
  %t136 = load i64, ptr %l67, !tbaa !24
  store i64 %t136, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t137 = load i64, ptr %l10, !tbaa !24
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb28, label %bb29
bb28:
  br label %bb48
bb29:
  br label %bb30
bb30:
  %t145 = load i64, ptr %l6, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t147 = load i64, ptr %l8, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  %t155 = load i64, ptr %l3, !tbaa !24
  %t157 = load i64, ptr %l4, !tbaa !24
  %t160 = mul i64 %t153, %t157
  %t163 = add i64 %t155, %t160
  store i64 %t163, ptr %l12, !tbaa !24
  %t165 = load i64, ptr %l12, !tbaa !24
  %t167 = add i64 %t165, 56
  %t168 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t173 = icmp sgt i64 %t167, %t170
  br i1 %t173, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l98, !tbaa !21
  br label %bb33
bb32:
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = srem i64 %t175, 8
  %t179 = icmp ne i64 %t177, 0
  store i1 %t179, ptr %l98, !tbaa !21
  br label %bb33
bb33:
  %t181 = load i1, ptr %l98, !tbaa !21
  br i1 %t181, label %bb34, label %bb35
bb34:
  br label %bb48
bb35:
  br label %bb36
bb36:
  %t182 = load i64, ptr %l12, !tbaa !24
  %t184 = sdiv i64 %t182, 8
  store i64 %t184, ptr %l13, !tbaa !24
  %t186 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t188 = load i64, ptr %l13, !tbaa !24
  %t191 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t186, i64 %t188)
  store i64 %t191, ptr %l107
  br label %bb37
bb37:
  %t192 = load i64, ptr %l107, !tbaa !24
  %t193 = and i64 %t192, 4294967295
  %t195 = icmp ne i64 %t193, 1
  br i1 %t195, label %bb38, label %bb39
bb38:
  br label %bb47
bb39:
  br label %bb40
bb40:
  store ptr %l1, ptr %l110, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t199 = load i64, ptr %l13, !tbaa !24
  %t201 = add i64 %t199, 1
  %t204 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t197, i64 %t201)
  store i64 %t204, ptr %l115
  br label %bb41
bb41:
  %t205 = load ptr, ptr %l110, !tbaa !29
  %t206 = load i64, ptr %l115, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t205, i64 %t206)
  br label %bb42
bb42:
  store ptr %l1, ptr %l116, !tbaa !29
  %t207 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t209 = load i64, ptr %l13, !tbaa !24
  %t211 = add i64 %t209, 4
  %t214 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t207, i64 %t211)
  store i64 %t214, ptr %l121
  br label %bb43
bb43:
  %t215 = load ptr, ptr %l116, !tbaa !29
  %t216 = load i64, ptr %l121, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t215, i64 %t216)
  br label %bb44
bb44:
  store ptr %l1, ptr %l122, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t219 = load i64, ptr %l13, !tbaa !24
  %t221 = add i64 %t219, 2
  %t224 = call i64 @compiler_2fprofile_2eword(ptr %s0, { i64, ptr } %t217, i64 %t221)
  store i64 %t224, ptr %l127
  br label %bb45
bb45:
  %t225 = load ptr, ptr %l122, !tbaa !29
  %t226 = load i64, ptr %l127, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t225, i64 %t226)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t227 = load i64, ptr %l10, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l10, !tbaa !24
  br label %bb27
bb48:
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2eshortPath(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l8 = alloca i1
  %l10 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l4, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t12 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t12, ptr %l1, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t15, ptr %l8
  br label %bb7
bb7:
  %t16 = load i1, ptr %l8, !tbaa !21
  %t17 = xor i1 %t16, true
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 1
  %t23 = extractvalue { i64, ptr } %t20, 0
  %t24 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t25 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t26 = add i64 %t23, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t22, i64 %t23)
  %t28 = getelementptr i8, ptr %t27, i64 %t23
  call void @olang_textcopy(ptr %t28, ptr %t24, i64 %t25)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  %t34 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t19, { i64, ptr } %t30)
  store i1 %t34, ptr %l15
  br label %bb10
bb9:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb11
bb10:
  %t35 = load i1, ptr %l15, !tbaa !21
  store i1 %t35, ptr %l10, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l10, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l16, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l19, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t43, 0
  store i64 %t46, ptr %l22, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  store i64 %t48, ptr %l23, !tbaa !24
  %t49 = load i64, ptr %l19, !tbaa !24
  %t50 = icmp sge i64 %t49, 0
  br i1 %t50, label %bb14, label %bb15
bb13:
  br label %bb20
bb14:
  %t52 = load i64, ptr %l19, !tbaa !24
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = icmp sle i64 %t52, %t53
  br i1 %t54, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb16:
  %t56 = load i64, ptr %l22, !tbaa !24
  %t57 = load i64, ptr %l23, !tbaa !24
  %t58 = icmp sle i64 %t56, %t57
  br i1 %t58, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb18:
  %t60 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l19, !tbaa !24
  %t63 = load i64, ptr %l22, !tbaa !24
  %t64 = getelementptr i8, ptr %t61, i64 %t62
  %t65 = sub i64 %t63, %t62
  %t66 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t64, 1
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = extractvalue { i64, ptr } %t67, 0
  %t71 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t70)
  call void @olang_textcopy(ptr %t71, ptr %t69, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t73, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba)
  unreachable
bb20:
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t75, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fprofile_2esymbolIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %v0, ptr %v1, ptr %t1, { i64, ptr } %t2)
  store i1 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i1, ptr %l7, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  %t10 = call ptr @__olang_scope_hold(ptr %v0)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_H31300daf7c6be9b9667c9cd96eea1c7e
  br i1 %t12, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  %t14 = call ptr @__olang_region_make(ptr %v0)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l10, !tbaa !24
  br label %bb5
bb5:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = extractvalue { i64, ptr } %t16, 0
  %t20 = load i64, ptr %l10
  %t21 = inttoptr i64 %t20 to ptr
  %t22 = call ptr @__olang_held_alloc(ptr %t21, i64 %t19)
  call void @olang_textcopy(ptr %t22, ptr %t18, i64 %t19)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l14, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2efunctionSymbols(ptr %v1, ptr %v0, { i64, ptr } %t26)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l9, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %v0, ptr %v0, ptr %v0, ptr %t29, { i64, ptr } %t30, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t36 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hfa095cf457cc3af0cc9715613212afd3(ptr %v0, ptr %v1, ptr %v0, ptr %t32, { i64, ptr } %t33)
  %t37 = extractvalue { i32, ptr } %t36, 1
  %t38 = extractvalue { i32, ptr } %t36, 0
  store i32 %t38, ptr %l21
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb10, label %ok.40, !prof !99
ok.40:
  store ptr %t37, ptr %l20
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l20, !tbaa !29
  store ptr %t41, ptr %l17, !tbaa !29
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t42 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l22
  br label %bb12
bb12:
  %t43 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  %t44 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %t44
  store ptr %t44, ptr %l17, !tbaa !29
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %v0, ptr %v2, ptr %t46, i64 %a2)
  store { i64, ptr } %t51, ptr %l26
  br label %bb14
bb14:
  %t52 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t52, ptr %l4, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t53, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t55, ptr %l28
  br label %bb15
bb15:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l29, !tbaa !27
  %t57 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  store { i64, ptr } %t57, ptr %l4, !tbaa !27
  %t60 = load i1, ptr @olang_2esole_2ecompiler__2fprofile__2esymbolIn_2elocal_2e4
  br i1 %t60, label %bb18, label %bb19
bb17:
  br label %bb20
bb18:
  %t62 = load { i64, ptr }, ptr %l31
  %t63 = extractvalue { i64, ptr } %t62, 1
  call void @__olang_region_release(ptr %t63)
  store { i64, ptr } zeroinitializer, ptr %l31
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t64, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_2etwoStacks(ptr %out, ptr %v0) #0 {
entry:
  %lp0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %lp5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca %"compiler/profile:Profile"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/profile:Sample"
  %l14 = alloca ptr
  %l15 = alloca %"compiler/profile:Sample"
  %l32 = alloca %"compiler/profile:Places"
  %l54 = alloca ptr
  %l56 = alloca i64
  %l58 = alloca i64
  %l59 = alloca %"compiler/profile:Frame"
  %l60 = alloca ptr
  %l62 = alloca i64
  %l64 = alloca i64
  %l65 = alloca %"compiler/profile:Frame"
  %l66 = alloca ptr
  %l68 = alloca i64
  %l70 = alloca i64
  %l71 = alloca %"compiler/profile:Frame"
  %l73 = alloca %"compiler/profile:Places"
  %l74 = alloca { %"compiler/profile:Profile", %"compiler/profile:Places" }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t52 = alloca %"compiler/profile:Places", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v0)
  store %"compiler/profile:Profile" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 104, i64 8)
  store ptr %t2, ptr %lp0
  %t3 = load %"compiler/profile:Profile", ptr %l11
  %t4 = load ptr, ptr %lp0
  store %"compiler/profile:Profile" %t3, ptr %t4
  %t5 = load ptr, ptr %lp0
  %t6 = getelementptr %"compiler/profile:Profile", ptr %t5, i32 0, i32 2
  store i64 1, ptr %t6, !tbaa !24
  %t7 = load ptr, ptr %lp0
  %t8 = getelementptr %"compiler/profile:Profile", ptr %t7, i32 0, i32 3
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s0, i64 3, i64 0, i64 2)
  store %"compiler/profile:Sample" %t9, ptr %l13
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l12, !tbaa !29
  %t11 = load %"compiler/profile:Sample", ptr %l13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t10, %"compiler/profile:Sample" %t11)
  br label %bb3
bb3:
  %t12 = load ptr, ptr %lp0
  %t13 = getelementptr %"compiler/profile:Profile", ptr %t12, i32 0, i32 3
  store ptr %t13, ptr %l14, !tbaa !29
  %t14 = call %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %s0, i64 1, i64 2, i64 2)
  store %"compiler/profile:Sample" %t14, ptr %l15
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l14, !tbaa !29
  %t16 = load %"compiler/profile:Sample", ptr %l15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %t15, %"compiler/profile:Sample" %t16)
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = insertvalue [4 x i64] undef, i64 100, 0
  %t18 = insertvalue [4 x i64] %t17, i64 201, 1
  %t19 = insertvalue [4 x i64] %t18, i64 300, 2
  %t20 = insertvalue [4 x i64] %t19, i64 201, 3
  %t22 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [4 x i64] %t20, ptr %t22
  store ptr %t22, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t24 = load ptr, ptr %l1
  store i64 4, ptr %l3, !tbaa !24
  br label %bb6
bb6:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp slt i64 %t27, %t28
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  br label %bb12
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l1
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = getelementptr [4 x i64], ptr %t35, i64 0, i64 %t36
  %t40 = load i64, ptr %t39, !tbaa !34
  %t42 = load ptr, ptr %lp0
  %t43 = getelementptr %"compiler/profile:Profile", ptr %t42, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t43, i64 %t40)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = add i64 %t47, 1
  store i64 %t50, ptr %l2, !tbaa !24
  br label %bb6
bb12:
  call void @__olang_scope_close(ptr %s1)
  call void @compiler_2fprofile_3aPlaces_2ector(ptr %t52, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l32, ptr %t52, i64 272, i1 false)
  br label %bb13
bb13:
  %t53 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 272, i64 8)
  store ptr %t53, ptr %lp5
  %t54 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %t54, ptr %l32, i64 272, i1 false)
  store %olang.scope zeroinitializer, ptr %s4
  %t55 = insertvalue [3 x i64] undef, i64 100, 0
  %t56 = insertvalue [3 x i64] %t55, i64 200, 1
  %t57 = insertvalue [3 x i64] %t56, i64 300, 2
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 24, i64 8)
  store [3 x i64] %t57, ptr %t59
  store ptr %t59, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l6
  store i64 3, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb15, label %bb16
bb15:
  br label %bb22
bb16:
  br label %bb17
bb17:
  %t72 = load i64, ptr %l7, !tbaa !24
  store i64 %t72, ptr %l9, !tbaa !24
  %t74 = load ptr, ptr %l6
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = getelementptr [3 x i64], ptr %t74, i64 0, i64 %t75
  %t79 = load i64, ptr %t78, !tbaa !34
  %t81 = load ptr, ptr %lp5
  %t82 = getelementptr %"compiler/profile:Places", ptr %t81, i32 0, i32 5
  %t84 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t82, i64 %t79, i64 %t84)
  br label %bb18
bb18:
  %t88 = load ptr, ptr %lp5
  %t89 = getelementptr %"compiler/profile:Places", ptr %t88, i32 0, i32 3
  %t90 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  br label %bb19
bb19:
  %t93 = load ptr, ptr %lp5
  %t94 = getelementptr %"compiler/profile:Places", ptr %t93, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t94, i64 1)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t99 = add i64 %t96, 1
  store i64 %t99, ptr %l7, !tbaa !24
  br label %bb14
bb22:
  call void @__olang_scope_close(ptr %s4)
  %t101 = load ptr, ptr %lp5
  %t102 = getelementptr %"compiler/profile:Places", ptr %t101, i32 0, i32 2
  store ptr %t102, ptr %l54, !tbaa !29
  %t103 = load ptr, ptr %lp5
  %t105 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v0, ptr %t103, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) })
  store i64 %t105, ptr %l56
  br label %bb23
bb23:
  %t106 = load ptr, ptr %lp5
  %t108 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v0, ptr %t106, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i64 %t108, ptr %l58
  br label %bb24
bb24:
  %t109 = load i64, ptr %l56, !tbaa !24
  %t110 = load i64, ptr %l58, !tbaa !24
  %t111 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t109, i64 %t110, i64 6)
  store %"compiler/profile:Frame" %t111, ptr %l59
  br label %bb25
bb25:
  %t112 = load ptr, ptr %l54, !tbaa !29
  %t113 = load %"compiler/profile:Frame", ptr %l59
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t112, %"compiler/profile:Frame" %t113)
  br label %bb26
bb26:
  %t114 = load ptr, ptr %lp5
  %t115 = getelementptr %"compiler/profile:Places", ptr %t114, i32 0, i32 2
  store ptr %t115, ptr %l60, !tbaa !29
  %t116 = load ptr, ptr %lp5
  %t118 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v0, ptr %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store i64 %t118, ptr %l62
  br label %bb27
bb27:
  %t119 = load ptr, ptr %lp5
  %t121 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v0, ptr %t119, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d131, i32 0, i32 1) })
  store i64 %t121, ptr %l64
  br label %bb28
bb28:
  %t122 = load i64, ptr %l62, !tbaa !24
  %t123 = load i64, ptr %l64, !tbaa !24
  %t124 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t122, i64 %t123, i64 20)
  store %"compiler/profile:Frame" %t124, ptr %l65
  br label %bb29
bb29:
  %t125 = load ptr, ptr %l60, !tbaa !29
  %t126 = load %"compiler/profile:Frame", ptr %l65
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t125, %"compiler/profile:Frame" %t126)
  br label %bb30
bb30:
  %t127 = load ptr, ptr %lp5
  %t128 = getelementptr %"compiler/profile:Places", ptr %t127, i32 0, i32 2
  store ptr %t128, ptr %l66, !tbaa !29
  %t129 = load ptr, ptr %lp5
  %t131 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v0, ptr %t129, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d132, i32 0, i32 1) })
  store i64 %t131, ptr %l68
  br label %bb31
bb31:
  %t132 = load ptr, ptr %lp5
  %t134 = call i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v0, ptr %t132, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i64 %t134, ptr %l70
  br label %bb32
bb32:
  %t135 = load i64, ptr %l68, !tbaa !24
  %t136 = load i64, ptr %l70, !tbaa !24
  %t137 = call %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %s0, i64 %t135, i64 %t136, i64 14)
  store %"compiler/profile:Frame" %t137, ptr %l71
  br label %bb33
bb33:
  %t138 = load ptr, ptr %l66, !tbaa !29
  %t139 = load %"compiler/profile:Frame", ptr %l71
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %t138, %"compiler/profile:Frame" %t139)
  br label %bb34
bb34:
  %t140 = load ptr, ptr %lp0
  %t141 = load %"compiler/profile:Profile", ptr %t140
  %t142 = load ptr, ptr %lp5
  call void @llvm.memmove.p0.p0.i64(ptr %l73, ptr %t142, i64 272, i1 false)
  %t143 = getelementptr { %"compiler/profile:Profile", %"compiler/profile:Places" }, ptr %l74, i32 0, i32 0
  store %"compiler/profile:Profile" %t141, ptr %t143
  %t145 = getelementptr { %"compiler/profile:Profile", %"compiler/profile:Places" }, ptr %l74, i32 0, i32 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %l73, i64 272, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l74, i64 376, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fprofile_2etypesRead(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l18 = alloca { i64, ptr }
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l55 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l74 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l6, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t29 = icmp ne i8 %t25, 58
  br i1 %t29, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb7:
  br label %bb8
bb8:
  %t31 = load i64, ptr %l6, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t33 = load i64, ptr %l8, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  %t37 = icmp sgt i64 %t33, %t34
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t39 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t39, ptr %l28, !tbaa !27
  %t40 = load i64, ptr %l8, !tbaa !24
  %t42 = sub i64 %t40, 1
  %t44 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t49 = call i1 @compiler_2fprofile_2eidentityChar(i8 %t47)
  store i1 %t49, ptr %l32
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t50 = load i1, ptr %l32, !tbaa !21
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t51 = load i1, ptr %l27, !tbaa !21
  %t52 = xor i1 %t51, true
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sub i64 %t54, 1
  store i64 %t57, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  br label %bb9
bb18:
  store ptr %l1, ptr %l37, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t59, ptr %l38, !tbaa !27
  %t60 = load i64, ptr %l2, !tbaa !24
  store i64 %t60, ptr %l39, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  store i64 %t61, ptr %l40, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l41, !tbaa !24
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sge i64 %t64, 0
  br i1 %t65, label %bb19, label %bb20
bb19:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = icmp sle i64 %t67, %t68
  br i1 %t69, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb21:
  %t71 = load i64, ptr %l40, !tbaa !24
  %t72 = load i64, ptr %l41, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb23:
  %t75 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l39, !tbaa !24
  %t78 = load i64, ptr %l40, !tbaa !24
  %t79 = getelementptr i8, ptr %t76, i64 %t77
  %t80 = sub i64 %t78, %t77
  %t81 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  %t83 = load ptr, ptr %l37, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t83, { i64, ptr } %t82)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e)
  unreachable
bb25:
  store ptr %l1, ptr %l46, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t85, ptr %l47, !tbaa !27
  %t86 = load i64, ptr %l8, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  store i64 %t87, ptr %l49, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l50, !tbaa !24
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = icmp sge i64 %t90, 0
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = load i64, ptr %l49, !tbaa !24
  %t95 = icmp sle i64 %t93, %t94
  br i1 %t95, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb28:
  %t97 = load i64, ptr %l49, !tbaa !24
  %t98 = load i64, ptr %l50, !tbaa !24
  %t99 = icmp sle i64 %t97, %t98
  br i1 %t99, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb30:
  %t101 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l48, !tbaa !24
  %t104 = load i64, ptr %l49, !tbaa !24
  %t105 = getelementptr i8, ptr %t102, i64 %t103
  %t106 = sub i64 %t104, %t103
  %t107 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  %t110 = call { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v0, ptr %s2, { i64, ptr } %t108)
  store { i64, ptr } %t110, ptr %l55
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_4bebebd3fadd2f37_94a97b9fa165786b)
  unreachable
bb32:
  %t111 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t112 = load ptr, ptr %l46, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t112, { i64, ptr } %t111)
  br label %bb33
bb33:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t116 = add i64 %t114, 1
  store i64 %t116, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t118 = load i64, ptr %l4, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l4, !tbaa !24
  br label %bb2
bb35:
  store ptr %l1, ptr %l62, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load i64, ptr %l2, !tbaa !24
  store i64 %t124, ptr %l64, !tbaa !24
  %t125 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t125, 0
  store i64 %t128, ptr %l67, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  store i64 %t130, ptr %l68, !tbaa !24
  %t131 = load i64, ptr %l64, !tbaa !24
  %t132 = icmp sge i64 %t131, 0
  br i1 %t132, label %bb36, label %bb37
bb36:
  %t134 = load i64, ptr %l64, !tbaa !24
  %t135 = load i64, ptr %l67, !tbaa !24
  %t136 = icmp sle i64 %t134, %t135
  br i1 %t136, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb38:
  %t138 = load i64, ptr %l67, !tbaa !24
  %t139 = load i64, ptr %l68, !tbaa !24
  %t140 = icmp sle i64 %t138, %t139
  br i1 %t140, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb40:
  %t142 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l64, !tbaa !24
  %t145 = load i64, ptr %l67, !tbaa !24
  %t146 = getelementptr i8, ptr %t143, i64 %t144
  %t147 = sub i64 %t145, %t144
  %t148 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  %t150 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t150, { i64, ptr } %t149)
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0)
  unreachable
bb42:
  %t153 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t153, ptr %l74
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t154 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t154, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fprofile_3aPlaces_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l30 = alloca %"compiler/profile:Places"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l6, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l6
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l0
  %t22 = call ptr @__olang_scope_hold(ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = call ptr @__olang_region_make(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l10
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %t29)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %l12
  br label %bb8
bb8:
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e1
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i64, ptr %l10
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = call ptr @__olang_region_or(ptr %t37, ptr null)
  %t39 = call ptr @__olang_region_home(ptr %t38)
  %t40 = icmp ne ptr %t39, null
  %t41 = select i1 %t40, ptr %t39, ptr null
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = call ptr @__olang_region_or(ptr %t44, ptr null)
  %t46 = call ptr @__olang_region_home(ptr %t45)
  %t47 = icmp ne ptr %t46, null
  %t48 = select i1 %t47, ptr %t46, ptr %t41
  %t49 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = call ptr @__olang_region_or(ptr %t51, ptr null)
  %t53 = call ptr @__olang_region_home(ptr %t52)
  %t54 = icmp ne ptr %t53, null
  %t55 = select i1 %t54, ptr %t53, ptr %t48
  call void @__olang_region_settle_in(ptr %t34, ptr %t55)
  br label %bb10
bb10:
  %t56 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t56, ptr %l1
  %t57 = call ptr @__olang_scope_hold(ptr %v0)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l14, !tbaa !24
  %t59 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e2
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = call ptr @__olang_region_make(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l14, !tbaa !24
  br label %bb12
bb12:
  %t63 = load i64, ptr %l14
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ector(ptr %t64, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l16
  br label %bb13
bb13:
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e2
  br i1 %t66, label %bb14, label %bb15
bb14:
  %t68 = load i64, ptr %l14
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = call ptr @__olang_region_or(ptr %t72, ptr null)
  %t74 = call ptr @__olang_region_home(ptr %t73)
  %t75 = icmp ne ptr %t74, null
  %t76 = select i1 %t75, ptr %t74, ptr null
  call void @__olang_region_settle_in(ptr %t69, ptr %t76)
  br label %bb15
bb15:
  %t77 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l2
  %t78 = call ptr @__olang_scope_hold(ptr %v0)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l18, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e3
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = call ptr @__olang_region_make(ptr %v0)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l18, !tbaa !24
  br label %bb17
bb17:
  %t84 = load i64, ptr %l18
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t85, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l20
  br label %bb18
bb18:
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e3
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = load i64, ptr %l18
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr null
  call void @__olang_region_settle_in(ptr %t90, ptr %t97)
  br label %bb20
bb20:
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %l3
  %t99 = call ptr @__olang_scope_hold(ptr %v0)
  %t100 = ptrtoint ptr %t99 to i64
  store i64 %t100, ptr %l22, !tbaa !24
  %t101 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e4
  br i1 %t101, label %bb21, label %bb22
bb21:
  %t103 = call ptr @__olang_region_make(ptr %v0)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l22, !tbaa !24
  br label %bb22
bb22:
  %t105 = load i64, ptr %l22
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t106, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l24
  br label %bb23
bb23:
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e4
  br i1 %t108, label %bb24, label %bb25
bb24:
  %t110 = load i64, ptr %l22
  %t111 = inttoptr i64 %t110 to ptr
  %t112 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = call ptr @__olang_region_or(ptr %t114, ptr null)
  %t116 = call ptr @__olang_region_home(ptr %t115)
  %t117 = icmp ne ptr %t116, null
  %t118 = select i1 %t117, ptr %t116, ptr null
  call void @__olang_region_settle_in(ptr %t111, ptr %t118)
  br label %bb25
bb25:
  %t119 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l4
  %t120 = call ptr @__olang_scope_hold(ptr %v0)
  %t121 = ptrtoint ptr %t120 to i64
  store i64 %t121, ptr %l26, !tbaa !24
  %t122 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e5
  br i1 %t122, label %bb26, label %bb27
bb26:
  %t124 = call ptr @__olang_region_make(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l26, !tbaa !24
  br label %bb27
bb27:
  %t126 = load i64, ptr %l26
  %t127 = inttoptr i64 %t126 to ptr
  %t128 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t127)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t128, ptr %l28
  br label %bb28
bb28:
  %t129 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aPlaces_2e5
  br i1 %t129, label %bb29, label %bb30
bb29:
  %t131 = load i64, ptr %l26
  %t132 = inttoptr i64 %t131 to ptr
  %t133 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 2
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = call ptr @__olang_region_or(ptr %t135, ptr null)
  %t137 = call ptr @__olang_region_home(ptr %t136)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr null
  %t140 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 1
  %t141 = load { i64, ptr }, ptr %t140
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = call ptr @__olang_region_or(ptr %t142, ptr null)
  %t144 = call ptr @__olang_region_home(ptr %t143)
  %t145 = icmp ne ptr %t144, null
  %t146 = select i1 %t145, ptr %t144, ptr %t139
  %t147 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28, i32 0, i32 0
  %t148 = load { i64, ptr }, ptr %t147
  %t149 = extractvalue { i64, ptr } %t148, 1
  %t150 = call ptr @__olang_region_or(ptr %t149, ptr null)
  %t151 = call ptr @__olang_region_home(ptr %t150)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr %t146
  call void @__olang_region_settle_in(ptr %t132, ptr %t153)
  br label %bb30
bb30:
  %t154 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l28
  %t155 = getelementptr %"compiler/profile:Places", ptr %l30, i32 0, i32 0
  %t156 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t156, ptr %t155
  %t157 = getelementptr %"compiler/profile:Places", ptr %l30, i32 0, i32 1
  %t158 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t158, ptr %t157
  %t159 = getelementptr %"compiler/profile:Places", ptr %l30, i32 0, i32 2
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %t159
  %t161 = getelementptr %"compiler/profile:Places", ptr %l30, i32 0, i32 3
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %t161
  %t163 = getelementptr %"compiler/profile:Places", ptr %l30, i32 0, i32 4
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %t163
  %t165 = getelementptr %"compiler/profile:Places", ptr %l30, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t154, ptr %t165
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 272, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fprofile_3aTally_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca i64
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l23 = alloca i64
  %l25 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l27 = alloca i64
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca %"compiler/profile:Tally"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l7, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l9
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l7
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9, i32 0, i32 2
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  %t21 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = call ptr @__olang_region_or(ptr %t23, ptr null)
  %t25 = call ptr @__olang_region_home(ptr %t24)
  %t26 = icmp ne ptr %t25, null
  %t27 = select i1 %t26, ptr %t25, ptr %t20
  %t28 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = call ptr @__olang_region_or(ptr %t30, ptr null)
  %t32 = call ptr @__olang_region_home(ptr %t31)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr %t27
  call void @__olang_region_settle_in(ptr %t13, ptr %t34)
  br label %bb5
bb5:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %l0
  %t36 = call ptr @__olang_scope_hold(ptr %v0)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l11, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e1
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = call ptr @__olang_region_make(ptr %v0)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l11, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l11
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t43)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t44, ptr %l13
  br label %bb8
bb8:
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e1
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l11
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %t49
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = call ptr @__olang_region_or(ptr %t51, ptr null)
  %t53 = call ptr @__olang_region_home(ptr %t52)
  %t54 = icmp ne ptr %t53, null
  %t55 = select i1 %t54, ptr %t53, ptr null
  %t56 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr %t55
  %t63 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr %t62
  call void @__olang_region_settle_in(ptr %t48, ptr %t69)
  br label %bb10
bb10:
  %t70 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t70, ptr %l1
  %t71 = call ptr @__olang_scope_hold(ptr %v0)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l15, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e2
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t75 = call ptr @__olang_region_make(ptr %v0)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l15, !tbaa !24
  br label %bb12
bb12:
  %t77 = load i64, ptr %l15
  %t78 = inttoptr i64 %t77 to ptr
  %t79 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t78)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t79, ptr %l17
  br label %bb13
bb13:
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e2
  br i1 %t80, label %bb14, label %bb15
bb14:
  %t82 = load i64, ptr %l15
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17, i32 0, i32 2
  %t85 = load { i64, ptr }, ptr %t84
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = call ptr @__olang_region_or(ptr %t86, ptr null)
  %t88 = call ptr @__olang_region_home(ptr %t87)
  %t89 = icmp ne ptr %t88, null
  %t90 = select i1 %t89, ptr %t88, ptr null
  %t91 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr %t90
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t97
  call void @__olang_region_settle_in(ptr %t83, ptr %t104)
  br label %bb15
bb15:
  %t105 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t105, ptr %l2
  %t106 = call ptr @__olang_scope_hold(ptr %v0)
  %t107 = ptrtoint ptr %t106 to i64
  store i64 %t107, ptr %l19, !tbaa !24
  %t108 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e3
  br i1 %t108, label %bb16, label %bb17
bb16:
  %t110 = call ptr @__olang_region_make(ptr %v0)
  %t111 = ptrtoint ptr %t110 to i64
  store i64 %t111, ptr %l19, !tbaa !24
  br label %bb17
bb17:
  %t112 = load i64, ptr %l19
  %t113 = inttoptr i64 %t112 to ptr
  %t114 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t113)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t114, ptr %l21
  br label %bb18
bb18:
  %t115 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e3
  br i1 %t115, label %bb19, label %bb20
bb19:
  %t117 = load i64, ptr %l19
  %t118 = inttoptr i64 %t117 to ptr
  %t119 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = call ptr @__olang_region_or(ptr %t121, ptr null)
  %t123 = call ptr @__olang_region_home(ptr %t122)
  %t124 = icmp ne ptr %t123, null
  %t125 = select i1 %t124, ptr %t123, ptr null
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = call ptr @__olang_region_or(ptr %t128, ptr null)
  %t130 = call ptr @__olang_region_home(ptr %t129)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr %t125
  %t133 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = call ptr @__olang_region_or(ptr %t135, ptr null)
  %t137 = call ptr @__olang_region_home(ptr %t136)
  %t138 = icmp ne ptr %t137, null
  %t139 = select i1 %t138, ptr %t137, ptr %t132
  call void @__olang_region_settle_in(ptr %t118, ptr %t139)
  br label %bb20
bb20:
  %t140 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l21
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t140, ptr %l3
  %t141 = call ptr @__olang_scope_hold(ptr %v0)
  %t142 = ptrtoint ptr %t141 to i64
  store i64 %t142, ptr %l23, !tbaa !24
  %t143 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e4
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = call ptr @__olang_region_make(ptr %v0)
  %t146 = ptrtoint ptr %t145 to i64
  store i64 %t146, ptr %l23, !tbaa !24
  br label %bb22
bb22:
  %t147 = load i64, ptr %l23
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t148)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t149, ptr %l25
  br label %bb23
bb23:
  %t150 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e4
  br i1 %t150, label %bb24, label %bb25
bb24:
  %t152 = load i64, ptr %l23
  %t153 = inttoptr i64 %t152 to ptr
  %t154 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25, i32 0, i32 2
  %t155 = load { i64, ptr }, ptr %t154
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr null)
  %t158 = call ptr @__olang_region_home(ptr %t157)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr null
  %t161 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25, i32 0, i32 1
  %t162 = load { i64, ptr }, ptr %t161
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = call ptr @__olang_region_or(ptr %t163, ptr null)
  %t165 = call ptr @__olang_region_home(ptr %t164)
  %t166 = icmp ne ptr %t165, null
  %t167 = select i1 %t166, ptr %t165, ptr %t160
  %t168 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25, i32 0, i32 0
  %t169 = load { i64, ptr }, ptr %t168
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = call ptr @__olang_region_or(ptr %t170, ptr null)
  %t172 = call ptr @__olang_region_home(ptr %t171)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, ptr %t172, ptr %t167
  call void @__olang_region_settle_in(ptr %t153, ptr %t174)
  br label %bb25
bb25:
  %t175 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t175, ptr %l4
  %t176 = call ptr @__olang_scope_hold(ptr %v0)
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l27, !tbaa !24
  %t178 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e5
  br i1 %t178, label %bb26, label %bb27
bb26:
  %t180 = call ptr @__olang_region_make(ptr %v0)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l27, !tbaa !24
  br label %bb27
bb27:
  %t182 = load i64, ptr %l27
  %t183 = inttoptr i64 %t182 to ptr
  %t184 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t183, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %l29
  br label %bb28
bb28:
  %t185 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e5
  br i1 %t185, label %bb29, label %bb30
bb29:
  %t187 = load i64, ptr %l27
  %t188 = inttoptr i64 %t187 to ptr
  %t189 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29, i32 0, i32 0
  %t190 = load { i64, ptr }, ptr %t189
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = call ptr @__olang_region_or(ptr %t191, ptr null)
  %t193 = call ptr @__olang_region_home(ptr %t192)
  %t194 = icmp ne ptr %t193, null
  %t195 = select i1 %t194, ptr %t193, ptr null
  call void @__olang_region_settle_in(ptr %t188, ptr %t195)
  br label %bb30
bb30:
  %t196 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l5
  %t197 = call ptr @__olang_scope_hold(ptr %v0)
  %t198 = ptrtoint ptr %t197 to i64
  store i64 %t198, ptr %l31, !tbaa !24
  %t199 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e6
  br i1 %t199, label %bb31, label %bb32
bb31:
  %t201 = call ptr @__olang_region_make(ptr %v0)
  %t202 = ptrtoint ptr %t201 to i64
  store i64 %t202, ptr %l31, !tbaa !24
  br label %bb32
bb32:
  %t203 = load i64, ptr %l31
  %t204 = inttoptr i64 %t203 to ptr
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t204, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l33
  br label %bb33
bb33:
  %t206 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3aTally_2e6
  br i1 %t206, label %bb34, label %bb35
bb34:
  %t208 = load i64, ptr %l31
  %t209 = inttoptr i64 %t208 to ptr
  %t210 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t211 = load { i64, ptr }, ptr %t210
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = call ptr @__olang_region_or(ptr %t212, ptr null)
  %t214 = call ptr @__olang_region_home(ptr %t213)
  %t215 = icmp ne ptr %t214, null
  %t216 = select i1 %t215, ptr %t214, ptr null
  call void @__olang_region_settle_in(ptr %t209, ptr %t216)
  br label %bb35
bb35:
  %t217 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  %t218 = getelementptr %"compiler/profile:Tally", ptr %l35, i32 0, i32 0
  %t219 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t219, ptr %t218
  %t220 = getelementptr %"compiler/profile:Tally", ptr %l35, i32 0, i32 1
  %t221 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t221, ptr %t220
  %t222 = getelementptr %"compiler/profile:Tally", ptr %l35, i32 0, i32 2
  %t223 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t223, ptr %t222
  %t224 = getelementptr %"compiler/profile:Tally", ptr %l35, i32 0, i32 3
  %t225 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t225, ptr %t224
  %t226 = getelementptr %"compiler/profile:Tally", ptr %l35, i32 0, i32 4
  %t227 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l4
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t227, ptr %t226
  %t228 = getelementptr %"compiler/profile:Tally", ptr %l35, i32 0, i32 5
  %t229 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %t228
  %t230 = getelementptr %"compiler/profile:Tally", ptr %l35, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t217, ptr %t230
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l35, i64 424, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/profile:elfFn" @compiler_2fprofile_3aelfFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %rv = alloca %"compiler/profile:elfFn"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/profile:elfFn" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/profile:elfFn" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/profile:elfFn" %t10, { i64, ptr } %a2, 2
  store %"compiler/profile:elfFn" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:elfFn", ptr %rv
  ret %"compiler/profile:elfFn" %rr
}

define dso_local %"compiler/profile:mapping" @compiler_2fprofile_3amapping_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/profile:mapping"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/profile:mapping" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/profile:mapping" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/profile:mapping" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/profile:mapping" %t14, { i64, ptr } %a3, 3
  store %"compiler/profile:mapping" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:mapping", ptr %rv
  ret %"compiler/profile:mapping" %rr
}

define dso_local %"compiler/profile:node" @compiler_2fprofile_3anode_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/profile:node"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t5 = call ptr @__olang_scope_hold(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l8, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3anode_2e3
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l8
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t12, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l10
  br label %bb3
bb3:
  %t14 = load i1, ptr @olang_2esole_2ecompiler_2fprofile_3anode_2e3
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l8
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10, i32 0, i32 0
  %t19 = load { i64, ptr }, ptr %t18
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = call ptr @__olang_region_or(ptr %t20, ptr null)
  %t22 = call ptr @__olang_region_home(ptr %t21)
  %t23 = icmp ne ptr %t22, null
  %t24 = select i1 %t23, ptr %t22, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t24)
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  %t26 = load i64, ptr %l2, !tbaa !24
  %t27 = insertvalue %"compiler/profile:node" undef, i64 %t26, 0
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = insertvalue %"compiler/profile:node" %t27, i64 %t28, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = insertvalue %"compiler/profile:node" %t29, i64 %t30, 2
  %t33 = insertvalue %"compiler/profile:node" %t31, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, 3
  store %"compiler/profile:node" %t33, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:node", ptr %rv
  ret %"compiler/profile:node" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define linkonce_odr %"compiler/profile:node" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fprofile_3anode(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/profile:node"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/profile:node"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/profile:node", ptr %a0
  store %"compiler/profile:node" %t2, ptr %l1
  %t3 = getelementptr %"compiler/profile:node", ptr %l1, i32 0, i32 3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/profile:node", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/profile:node", ptr %l1
  store %"compiler/profile:node" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/profile:node", ptr %rv
  ret %"compiler/profile:node" %rr
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2e0 = weak hidden constant i1 false
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l8 = alloca %"compiler/profile:node"
  %l10 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l15 = alloca %"compiler/profile:node"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  %cp0 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  store ptr %cv0, ptr %l2
  %cp1 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %cp1, !tbaa !28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %cv1, ptr %l3
  %vq0 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/profile:Places", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l5, !tbaa !29
  %t7 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %vc1, ptr %s0, ptr %l3, i64 %a0)
  store %"compiler/profile:node" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/profile:node", ptr %l8, i32 0, i32 0
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t12 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t10, i64 %t9)
  store { i64, ptr } %t12, ptr %l10
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/profile:Places", ptr %t13, i32 0, i32 0
  store ptr %t15, ptr %l12, !tbaa !29
  %t19 = call %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %vc1, ptr %s0, ptr %l3, i64 %a1)
  store %"compiler/profile:node" %t19, ptr %l15
  br label %bb3
bb3:
  %t20 = getelementptr %"compiler/profile:node", ptr %l15, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc0, ptr %vc0, ptr %t22, i64 %t21)
  store { i64, ptr } %t24, ptr %l17
  br label %bb4
bb4:
  %t25 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc0, ptr %vc0, { i64, ptr } %t25, { i64, ptr } %t26)
  store i1 %t27, ptr %l18
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d1 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"all" }>, align 8
@.d2 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms, " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare i64 @__olang_fmt_i64(ptr, i64)
@.d4 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"<g class=\22f\22 data-x=\22" }>, align 8
@.d5 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 data-w=\22" }>, align 8
@.d6 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 data-d=\22" }>, align 8
@.d7 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\22><title>" }>, align 8
@.d8 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"</title><rect y=\22" }>, align 8
@.d9 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 height=\22" }>, align 8
@.d10 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"\22 rx=\222\22 fill=\22rgb(" }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"," }>, align 8
@.d12 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c")\22/><text y=\22" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22>" }>, align 8
@.d14 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"</text></g>\0A" }>, align 8
@.d15 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"<!doctype html>\0A<html><head><meta charset=\22utf-8\22><title>" }>, align 8
@.d16 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" - olang profile</title>\0A" }>, align 8
@.d17 = private constant <{ i64, [213 x i8] }> <{ i64 0, [213 x i8] c"<style>body{margin:0;padding:10px;font:12px monospace;background:#fff}svg text{font:11px monospace;fill:#000;pointer-events:none}g.f{cursor:pointer}g.f:hover rect{stroke:#000;stroke-width:.5}</style></head><body>\0A" }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"<div>" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d20 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" samples, " }>, align 8
@.d21 = private constant <{ i64, [78 x i8] }> <{ i64 0, [78 x i8] c" s of CPU time - a click on a frame zooms to it, on the bottom bar back</div>\0A" }>, align 8
@.d22 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"<svg id=\22fg\22 width=\22" }>, align 8
@.d23 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22 height=\22" }>, align 8
@.d24 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"\22 data-total=\22" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\22>\0A" }>, align 8
@.d26 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"</svg>\0A" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d27 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"</body></html>\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H6cf7c9f2359d1ee39cd99e769614c19f(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fprofile__2ePlaces__2eResolve_2elocal_2e21 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
declare void @__olang_region_release(ptr) noinline
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\22 0x" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d34 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--inlining" }>, align 8
@.d35 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"--functions=short" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H84525b00cfc40be2d2c61524b3658c11(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3a_Hdb387e679134e71bf5648ac6d1ce10ff(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d43 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d46 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_H31300daf7c6be9b9667c9cd96eea1c7e = weak hidden constant i1 false
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d49 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d50 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"no file" }>, align 8
@.d51 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"0x" }>, align 8
@.d52 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@.d55 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OLPROF01" }>, align 8
@olang_2esole_2ecompiler_2fprofile_3aProfile_2e5 = weak hidden constant i1 false
@.d56 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"_2e" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d58 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"../" }>, align 8
@.d59 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d61 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fprofile__2eReadable_2elocal_2e7 = weak hidden constant i1 false
@.d64 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" thread" }>, align 8
@.d65 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" threads" }>, align 8
@.d66 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"\0Aolang profile: " }>, align 8
@.d67 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" - " }>, align 8
@.d68 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" samples, " }>, align 8
@.d69 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" s of CPU time on " }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d71 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  (" }>, align 8
@.d72 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" samples dropped: the buffer was full)\0A" }>, align 8
@.d73 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"  no samples: the program used less CPU time than one period\0A" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2e2 = weak hidden constant i1 false
define internal i1 @olang_lambda_74(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l43 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %cp0, i64 424, i1 false)
  %cp1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  store ptr %cv1, ptr %l7
  %vq0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 0
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l12
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l11
  br label %bb1
bb1:
  %t10 = load i64, ptr %l11, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 0
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l17
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l16
  br label %bb5
bb5:
  %t21 = load i64, ptr %l16, !tbaa !24
  store i64 %t21, ptr %l13, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  store i1 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 1
  %t36 = load i64, ptr %l0, !tbaa !24
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t35, i64 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l28
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb13, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l27
  br label %bb12
bb12:
  %t44 = load i64, ptr %l27, !tbaa !24
  store i64 %t44, ptr %l24, !tbaa !24
  br label %bb15
bb13:
  br label %bb14
bb14:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb15
bb15:
  %t45 = load i64, ptr %l24, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 1
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t46, i64 %t47)
  %t51 = extractvalue { i32, i64 } %t50, 1
  %t52 = extractvalue { i32, i64 } %t50, 0
  store i32 %t52, ptr %l33
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb17, label %ok.54, !prof !99
ok.54:
  store i64 %t51, ptr %l32
  br label %bb16
bb16:
  %t55 = load i64, ptr %l32, !tbaa !24
  store i64 %t55, ptr %l29, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb19
bb19:
  %t56 = load i64, ptr %l29, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l5, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp ne i64 %t57, %t58
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  store i1 %t67, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t69 = load ptr, ptr %l7, !tbaa !29
  %t71 = getelementptr %"compiler/profile:Places", ptr %t69, i32 0, i32 0
  %t72 = load i64, ptr %l0, !tbaa !24
  %t75 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t71, i64 %t72)
  store { i64, ptr } %t75, ptr %l43
  br label %bb23
bb23:
  %t76 = load ptr, ptr %l7, !tbaa !29
  %t78 = getelementptr %"compiler/profile:Places", ptr %t76, i32 0, i32 0
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l47
  br label %bb24
bb24:
  %t83 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t85 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t83, { i64, ptr } %t84)
  store i1 %t85, ptr %l48
  br label %bb25
bb25:
  %t86 = load i1, ptr %l48, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d75 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"\0A   self   total  function\0A" }>, align 8
@.d76 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d78 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define internal i1 @olang_lambda_80(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %cp0, i64 424, i1 false)
  %cp1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  store ptr %cv1, ptr %l5
  %vq0 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 2
  %t2 = load i64, ptr %l0, !tbaa !24
  %t5 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t2)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l10
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l9
  br label %bb1
bb1:
  %t10 = load i64, ptr %l9, !tbaa !24
  store i64 %t10, ptr %l6, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l6, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 2
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t12, i64 %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l15
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb6, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l14
  br label %bb5
bb5:
  %t21 = load i64, ptr %l14, !tbaa !24
  store i64 %t21, ptr %l11, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t22 = load i64, ptr %l11, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp ne i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  store i1 %t33, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l5, !tbaa !29
  %t37 = getelementptr %"compiler/profile:Places", ptr %t35, i32 0, i32 0
  %t38 = load i64, ptr %l0, !tbaa !24
  %t41 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t37, i64 %t38)
  store { i64, ptr } %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/profile:Places", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %l1, !tbaa !24
  %t48 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t44, i64 %t45)
  store { i64, ptr } %t48, ptr %l29
  br label %bb13
bb13:
  %t49 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t49, { i64, ptr } %t50)
  store i1 %t51, ptr %l30
  br label %bb14
bb14:
  %t52 = load i1, ptr %l30, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d81 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":0" }>, align 8
@.d82 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"line" }>, align 8
@.d83 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0A   self  " }>, align 8
@.d84 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"  function\0A" }>, align 8
@.d85 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d87 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d88 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"\0A  called from (the five hottest functions)\0A" }>, align 8
define internal i1 @olang_lambda_89(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca %"compiler/profile:Tally"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i32
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i1
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %cp0, i64 424, i1 false)
  %cp1 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i64, ptr %cp1, !tbaa !28
  store i64 %cv1, ptr %l3
  %cp2 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load ptr, ptr %cp2, !tbaa !28
  store ptr %cv2, ptr %l6
  %vq0 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { %"compiler/profile:Tally", i64, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 4
  %t2 = load i64, ptr %l3, !tbaa !24
  %t4 = mul i64 %t2, 16777216
  %t5 = load i64, ptr %l0, !tbaa !24
  %t8 = add i64 %t4, %t5
  %t11 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t1, i64 %t8)
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store i64 %t12, ptr %l13
  br label %bb1
bb1:
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  %t18 = getelementptr %"compiler/profile:Tally", ptr %l2, i32 0, i32 4
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = mul i64 %t19, 16777216
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t28 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %vc0, ptr %t18, i64 %t25)
  %t29 = extractvalue { i32, i64 } %t28, 1
  %t30 = extractvalue { i32, i64 } %t28, 0
  store i32 %t30, ptr %l22
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb6, label %ok.32, !prof !99
ok.32:
  store i64 %t29, ptr %l21
  br label %bb5
bb5:
  %t33 = load i64, ptr %l21, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp ne i64 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  store i1 %t45, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = getelementptr %"compiler/profile:Places", ptr %t47, i32 0, i32 0
  %t50 = load i64, ptr %l0, !tbaa !24
  %t53 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t49, i64 %t50)
  store { i64, ptr } %t53, ptr %l32
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = getelementptr %"compiler/profile:Places", ptr %t54, i32 0, i32 0
  %t57 = load i64, ptr %l1, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %vc1, ptr %vc1, ptr %t56, i64 %t57)
  store { i64, ptr } %t60, ptr %l36
  br label %bb13
bb13:
  %t61 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %vc1, ptr %vc1, { i64, ptr } %t61, { i64, ptr } %t62)
  store i1 %t63, ptr %l37
  br label %bb14
bb14:
  %t64 = load i1, ptr %l37, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d91 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"(the thread's first frame)" }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d93 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d94 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"  <-  " }>, align 8
@.d95 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"/llvm-symbolizer" }>, align 8
@.d100 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d101 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-20" }>, align 8
@.d102 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-19" }>, align 8
@.d103 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"llvm-symbolizer-18" }>, align 8
@.d104 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"llvm-symbolizer" }>, align 8
@.d105 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d107 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d108 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&lt;" }>, align 8
@.d109 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"&gt;" }>, align 8
@.d110 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"&amp;" }>, align 8
@.d111 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"&quot;" }>, align 8
@.d112 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d113 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
define internal i1 @olang_lambda_114(ptr %env, ptr %v0, ptr %v1, %"compiler/profile:elfFn" %a0, %"compiler/profile:elfFn" %a1) #0 {
entry:
  %l0 = alloca %"compiler/profile:elfFn"
  %l1 = alloca %"compiler/profile:elfFn"
  %rv = alloca i1
  store %"compiler/profile:elfFn" %a0, ptr %l0
  store %"compiler/profile:elfFn" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/profile:elfFn", ptr %l0, i32 0, i32 0
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/profile:elfFn", ptr %l1, i32 0, i32 0
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp slt i64 %t2, %t4
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d116 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@olang_2esole_2ecompiler_2fprofile_3amapping_2e3 = weak hidden constant i1 false
@.d118 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_PROFILE\00" }>, align 8
@.d119 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\00" }>, align 8
declare i32 @setenv(ptr, ptr, i32)
declare i32 @fork()
declare void @_exit(i32) noreturn
@.d120 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"OLANG_PROFILE\00" }>, align 8
declare i32 @unsetenv(ptr)
declare i64 @signal(i32, i64)
declare i32 @waitpid(i32, ptr, i32)
@.d121 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d122 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OLPROF01" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d125 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"??" }>, align 8
@olang_2esole_2ecompiler__2fprofile__2esymbolIn_2elocal_2e4 = weak hidden constant i1 false
@.d128 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"hot" }>, align 8
@.d129 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
@.d130 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d131 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
@.d132 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"Vec<I64>.Push" }>, align 8
@.d133 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"hot.olang" }>, align 8
@olang_2esole_2ecompiler_2fprofile_3aPlaces_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2fprofile_3aPlaces_2e1 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fprofile_3aPlaces_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aPlaces_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aPlaces_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aPlaces_2e5 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fprofile_3aTally_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aTally_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aTally_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aTally_2e3 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aTally_2e4 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aTally_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3aTally_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fprofile_3anode_2e3 = weak hidden constant i1 false
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2ePush_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:node" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eLen_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0)
declare %"compiler/profile:Sample" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2eAt_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2estack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/profile:Sample" %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRefMut_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/profile:Frame" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eAt_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/profile:node" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eAt_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eLen_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fprofile_2eFrameHeight = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\12\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3anode_3e_2eRef_3ccompiler_2fprofile_3anode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fprofile_2epct(ptr %v0, i64 %a0, i64 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fprofile_2ecompiler_2fprofile_3aProfile_2eTotal(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %a0, i64 %a1)
@G_2ecompiler_2fprofile_2eFlameWidth = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\B0\04\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2fprofile_2eFlameScript = external constant <{ [8 x i8], ptr }>
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eLen__Heb6545c4cbf57678e5e8a74f397c9583(ptr %v0, ptr %a0)
declare %"compiler/profile:mapping" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2eAt_3ccompiler_2fprofile_3amapping_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H67bc384d82ac3ceb3fdc5d6d25b5f02a(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hd2a6d6393d72da4a22d0070783b9e545(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H613fddb0939c6e46b95f2b1f68ba1bdb(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_3866f265829cb50e_54c32d3b9a091762 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2eLen_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
@olang_loc_698502529ad2e54f_f0e75116d399f563 = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fprofile_2ecompiler_2fprofile_3aPlaces_2ename(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/profile:Frame" @compiler_2fprofile_3aFrame_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ePush_3ccompiler_2fprofile_3aFrame_3e(ptr %v0, ptr %a0, %"compiler/profile:Frame" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H509117e81ae737fb138b1f364b80e611(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hb4e1316c13adc554c531dbb9cf254a96(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Hfa095cf457cc3af0cc9715613212afd3(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fprofile_2esymbolAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6b0ecf2869984314_228026d38fe8b188 = external constant [0 x i8]
declare %"compiler/profile:Profile" @compiler_2fprofile_3aProfile_2ector(ptr %v0)
@olang_loc_19eabfe0257f2300_73d07f391b90fd8c = external constant [0 x i8]
declare i64 @compiler_2fprofile_2eword(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/profile:Sample" @compiler_2fprofile_3aSample_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aSample_3e_2ePush_3ccompiler_2fprofile_3aSample_3e(ptr %v0, ptr %a0, %"compiler/profile:Sample" %a1)
@olang_loc_5e6251cd9155695d_6237c97633bfa1b9 = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3603727fe313055_49dd245dfeecf61 = external constant [0 x i8]
@olang_loc_e16765c4a8f41078_55e216e6a7163174 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a05021294fe2b6d3_c60223eeaa2ef05f = external constant [0 x i8]
@olang_loc_efed15e4a0150676_49528d4cd386b8e2 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fprofile_2equalifier(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadEnd(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare { i64, ptr } @compiler_2ftarget_2eWhereIs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d2ae97c2364b59d_ce98559d67a1b5c9 = external constant [0 x i8]
@olang_loc_ec3589048a52ea40_4feb0c814716a05c = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_47d41d181de998ca_407a2b261e632036 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2ePush_3ccompiler_2fprofile_3aelfFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:elfFn" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aelfFn_3e_2eSort_3_H16cb1151e861568c30a5b57cf3c12bc1(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_49a351722641e944_c5b141a1c073228 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3amapping_3e_2ePush_Hc0dd0b8028ee4ec7edce99e352ae7bbd(ptr %v0, ptr %v1, ptr %a0, %"compiler/profile:mapping" %a1)
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_ec22c3592c386ac4_6a748f217c4c44c0 = external constant [0 x i8]
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU8_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2ePush_3cU8_3e(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eToArray_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
@olang_loc_9b07e838cb7ed4ee_978ead1b2c1f88ba = external constant [0 x i8]
@olang_loc_cc2e380c5cd0dda_c071bfd9a740ca6e = external constant [0 x i8]
@olang_loc_4bebebd3fadd2f37_94a97b9fa165786b = external constant [0 x i8]
@olang_loc_ea1fc1fa824e624c_c3d948fe5a073af0 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fprofile_3aFrame_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2fvec_3a_Hdb387e679134e71bf5648ac6d1ce10ff(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
