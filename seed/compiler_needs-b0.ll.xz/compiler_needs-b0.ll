; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/needs:walker" = type { ptr, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/generic:varRow" = type { i64, i32, i32, i32, i32 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
define dso_local { i64, ptr } @compiler_2fneeds_2eLines(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"compiler/needs:walker"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i64
  %l59 = alloca ptr
  %l64 = alloca %"compiler/generic:varRow"
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t3 = alloca %"compiler/needs:walker", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2fneeds_3awalker_2ector(ptr %t3, ptr %v0, ptr %s0, ptr %t1, i64 %t2, i64 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t3, i64 280, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 280, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t6, ptr %l14, i64 280, i1 false)
  store ptr %t6, ptr %l2, !tbaa !29
  %t8 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2erun(ptr %s0, ptr %v0, ptr %t8)
  br label %bb2
bb2:
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l17
  br label %bb3
bb3:
  %t11 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t11, ptr %lp3
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t13 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t13
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t14)
  store i64 %t16, ptr %l19
  br label %bb4
bb4:
  %t17 = load i64, ptr %l19, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"compiler/needs:walker", ptr %t18, i32 0, i32 7
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %s0, ptr %t20)
  store i64 %t22, ptr %l22
  br label %bb5
bb5:
  %t23 = load i64, ptr %l22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb8:
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l7, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l29, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb10
bb10:
  %t50 = load i64, ptr %l29, !tbaa !24
  store i64 %t50, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t51 = load i64, ptr %l26, !tbaa !24
  store i64 %t51, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load i64, ptr %l9, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb14:
  br label %bb15
bb15:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l10, !tbaa !24
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l10, !tbaa !24
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eunpromised(ptr %s0, ptr %s2, ptr %v0, ptr %t70, i64 %t71)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l49
  br label %bb16
bb16:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l11
  %t77 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %l11)
  store i64 %t77, ptr %l51
  br label %bb17
bb17:
  %t78 = load i64, ptr %l51, !tbaa !24
  %t79 = icmp eq i64 %t78, 0
  br i1 %t79, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb19:
  br label %bb20
bb20:
  %t81 = load ptr, ptr %lp3
  store ptr %t81, ptr %l53, !tbaa !29
  %t82 = call ptr @__olang_scope_hold(ptr %v1)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l54, !tbaa !24
  %t84 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t84, label %bb21, label %bb22
bb21:
  %t86 = call ptr @__olang_region_make(ptr %v1)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/generic:Program", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/load:Loader", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l59, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load i64, ptr %l4, !tbaa !24
  %t103 = load i64, ptr %l10, !tbaa !24
  %t107 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %t101, i64 %t102, i64 %t103)
  store %"compiler/generic:varRow" %t107, ptr %l64
  br label %bb23
bb23:
  %t108 = getelementptr %"compiler/generic:varRow", ptr %l64, i32 0, i32 1
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load ptr, ptr %l59, !tbaa !29
  %t112 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s2, ptr %t110, i32 %t109)
  store { i64, ptr } %t112, ptr %l66
  br label %bb24
bb24:
  %t114 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s2, ptr %s2, ptr %s2, ptr %l11, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store { i64, ptr } %t114, ptr %l68
  br label %bb25
bb25:
  %t115 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t121 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t124 = add i64 %t120, %t123
  %t125 = load i64, ptr %l54
  %t126 = inttoptr i64 %t125 to ptr
  %t127 = call ptr @__olang_held_alloc(ptr %t126, i64 %t124)
  call void @olang_textcopy(ptr %t127, ptr %t116, i64 %t117)
  %t128 = getelementptr i8, ptr %t127, i64 %t117
  call void @olang_textcopy(ptr %t128, ptr %t118, i64 %t119)
  %t129 = getelementptr i8, ptr %t128, i64 %t119
  call void @olang_textcopy(ptr %t129, ptr %t122, i64 %t123)
  %t130 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t127, 1
  %t133 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t133, { i64, ptr } %t131)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  %t135 = load i64, ptr %l9, !tbaa !24
  %t138 = add i64 %t135, 1
  store i64 %t138, ptr %l9, !tbaa !24
  br label %bb12
bb28:
  %t140 = load ptr, ptr %lp3
  %t142 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t140)
  store { i64, ptr } %t142, ptr %l75
  br label %bb29
bb29:
  %t143 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t143, ptr %l76, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l77, !tbaa !24
  %t146 = load i64, ptr %l77, !tbaa !24
  %t147 = mul i64 %t146, 16
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  %t149 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l78, !tbaa !27
  %t151 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = load i64, ptr %l77, !tbaa !24
  %t156 = mul i64 %t155, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t152, ptr %t154, i64 %t156, i1 false)
  %t157 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t157, ptr %l76, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fneeds_2ebinaryNeed(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t3 = trunc i64 68 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb59
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t10 = trunc i64 69 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  br label %bb59
bb8:
  %t15 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t17 = trunc i64 70 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  br label %bb59
bb12:
  %t22 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t24 = trunc i64 72 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l1, !tbaa !27
  br label %bb59
bb16:
  %t29 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t31 = trunc i64 73 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t34, ptr %l1, !tbaa !27
  br label %bb59
bb20:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t38 = trunc i64 74 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t41, ptr %l1, !tbaa !27
  br label %bb59
bb24:
  %t43 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t45 = trunc i64 98 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb25, label %bb26
bb25:
  br label %bb33
bb26:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t50 = trunc i64 100 to i32
  %t51 = icmp eq i32 %t48, %t50
  br i1 %t51, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t53 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t55 = trunc i64 99 to i32
  %t56 = icmp eq i32 %t53, %t55
  br i1 %t56, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  %t58 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t60 = trunc i64 101 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t63, ptr %l1, !tbaa !27
  br label %bb59
bb34:
  %t65 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t67 = trunc i64 102 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %l38, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t70, ptr %l1, !tbaa !27
  br label %bb59
bb38:
  %t72 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t74 = trunc i64 103 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t77, ptr %l1, !tbaa !27
  br label %bb59
bb42:
  %t79 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t81 = trunc i64 104 to i32
  %t82 = icmp eq i32 %t79, %t81
  br i1 %t82, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t84, ptr %l1, !tbaa !27
  br label %bb59
bb46:
  %t86 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t88 = trunc i64 108 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t91, ptr %l1, !tbaa !27
  br label %bb59
bb50:
  %t93 = load i32, ptr %l0, !range !{i32 0, i32 116}
  %t95 = trunc i64 109 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t98, ptr %l1, !tbaa !27
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t100, ptr %l1, !tbaa !27
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_eb8dbdd343cc2ec5_7e04d3ec09c5f0b9)
  unreachable
bb59:
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l58, !tbaa !24
  %t104 = load i64, ptr %l58, !tbaa !24
  %t105 = mul i64 %t104, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t105)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l59, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = load i64, ptr %l58, !tbaa !24
  %t114 = mul i64 %t113, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t110, ptr %t112, i64 %t114, i1 false)
  %t115 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t115, ptr %l1, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t116, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 13
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb20
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t28 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i64 %t28, ptr %l21
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i1 @compiler_2fast_2eSlicing(ptr %v1, { i64, ptr } %t29)
  store i1 %t31, ptr %l23
  br label %bb7
bb7:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l24, !tbaa !27
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %l21, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t33, i64 %t34, { i64, ptr } %t35)
  br label %bb11
bb11:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t36, ptr %t37)
  br label %bb12
bb12:
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  %t63 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t63, ptr %t61)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb13
bb19:
  br label %bb26
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t73, ptr %t74)
  br label %bb24
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_e9926bfe55a51c67_a6d583928ea9cdb3)
  unreachable
bb26:
  %t78 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t78, ptr %a2)
  br label %bb27
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ebinary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l17 = alloca ptr
  %l21 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t3 = trunc i64 27 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v2, ptr %t7, ptr %t8)
  store i64 %t12, ptr %l11
  br label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t13 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t15 = call { i64, ptr } @compiler_2fneeds_2ebinaryNeed(ptr %v0, i32 %t13)
  store { i64, ptr } %t15, ptr %l13
  br label %bb5
bb3:
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t17 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t16, i64 %t17, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb4
bb4:
  br label %bb12
bb5:
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t18, ptr %lp4
  %t19 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t20 = load ptr, ptr %lp4
  store { i64, ptr } %t19, ptr %t20, !tbaa !27
  %t21 = load ptr, ptr %lp4
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t22, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load i1, ptr %l15, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l17, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t34 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t29, ptr %t30)
  store i64 %t34, ptr %l21
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t35 = load ptr, ptr %lp4
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t37, i64 %t38, { i64, ptr } %t36)
  br label %bb10
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t40, ptr %t41)
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t45, ptr %t46)
  br label %bb14
bb14:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca i64
  %l43 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l68 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l81 = alloca i64
  %l92 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l17, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 28}
  %t21 = icmp eq i64 %t19, 0
  store i1 %t21, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l18, !tbaa !21
  store i1 %t22, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l15, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t26, i32 0, i32 1
  %t28 = load ptr, ptr %t27
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32 }, ptr %t30, i32 0, i32 1
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l3, !tbaa !23
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [4 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb22
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/needs:walker", ptr %t40, i32 0, i32 4
  %t43 = load i32, ptr %l3, !tbaa !23
  %t46 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l29
  br label %bb11
bb11:
  %t47 = load i1, ptr %l29, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s1
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/needs:walker", ptr %t49, i32 0, i32 4
  %t52 = load i32, ptr %l3, !tbaa !23
  %t55 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t51, i32 %t52)
  %t56 = extractvalue { i32, i64 } %t55, 1
  %t57 = extractvalue { i32, i64 } %t55, 0
  store i32 %t57, ptr %l36
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb15, label %ok.59, !prof !99
ok.59:
  store i64 %t56, ptr %l35
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t60 = load i64, ptr %l35, !tbaa !24
  store i64 %t60, ptr %l31, !tbaa !24
  br label %bb17
bb15:
  br label %bb16
bb16:
  store i64 -1, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t61 = call ptr @__olang_scope_hold(ptr %v0)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l37, !tbaa !24
  %t63 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t65 = call ptr @__olang_region_make(ptr %v0)
  %t66 = ptrtoint ptr %t65 to i64
  store i64 %t66, ptr %l37, !tbaa !24
  br label %bb19
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/needs:walker", ptr %t67, i32 0, i32 0
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/load:Loader", ptr %t76, i32 0, i32 3
  %t79 = load ptr, ptr %t78, !tbaa !29
  store ptr %t79, ptr %l43, !tbaa !29
  %t80 = load i32, ptr %l4, !tbaa !23
  %t81 = load ptr, ptr %l43, !tbaa !29
  %t82 = call ptr @__olang_scope_or(ptr %v3, ptr %t81)
  %t83 = call ptr @__olang_scope_hold(ptr %t82)
  %t84 = ptrtoint ptr %t83 to i64
  %t86 = inttoptr i64 %t84 to ptr
  %t87 = load ptr, ptr %l43, !tbaa !29
  %t89 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t86, ptr %s1, ptr %t87, i32 %t80)
  store { i64, ptr } %t89, ptr %l46
  br label %bb20
bb20:
  %t90 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = load i64, ptr %l37
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = call ptr @__olang_held_alloc(ptr %t97, i64 %t95)
  call void @olang_textcopy(ptr %t98, ptr %t91, i64 %t92)
  %t99 = getelementptr i8, ptr %t98, i64 %t92
  call void @olang_textcopy(ptr %t99, ptr %t93, i64 %t94)
  %t100 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t98, 1
  %t103 = load ptr, ptr %l30, !tbaa !29
  %t104 = load i64, ptr %l31, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t103, i64 %t104, { i64, ptr } %t101)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s1)
  br label %bb42
bb22:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t107 = load ptr, ptr %l49, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb23, label %bb24
bb23:
  %t110 = load ptr, ptr %l49, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 28}
  %t113 = icmp eq i64 %t111, 12
  store i1 %t113, ptr %l50, !tbaa !21
  br label %bb24
bb24:
  %t114 = load i1, ptr %l50, !tbaa !21
  br i1 %t114, label %bb25, label %bb26
bb25:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t117, i32 0, i32 1
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l5, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t123, i32 0, i32 2
  %t125 = load i32, ptr %t124
  store i32 %t125, ptr %l6, !tbaa !23
  br label %bb27
bb26:
  br label %bb34
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l57, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t133 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t128, ptr %t129)
  store i64 %t133, ptr %l61
  br label %bb28
bb28:
  %t134 = call ptr @__olang_scope_hold(ptr %v0)
  %t135 = ptrtoint ptr %t134 to i64
  store i64 %t135, ptr %l62, !tbaa !24
  %t136 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t136, label %bb29, label %bb30
bb29:
  %t138 = call ptr @__olang_region_make(ptr %v0)
  %t139 = ptrtoint ptr %t138 to i64
  store i64 %t139, ptr %l62, !tbaa !24
  br label %bb30
bb30:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/needs:walker", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 0
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = getelementptr %"compiler/load:Loader", ptr %t149, i32 0, i32 3
  %t152 = load ptr, ptr %t151, !tbaa !29
  store ptr %t152, ptr %l68, !tbaa !29
  %t153 = load i32, ptr %l6, !tbaa !23
  %t154 = load ptr, ptr %l68, !tbaa !29
  %t155 = call ptr @__olang_scope_or(ptr %v3, ptr %t154)
  %t156 = call ptr @__olang_scope_hold(ptr %t155)
  %t157 = ptrtoint ptr %t156 to i64
  %t159 = inttoptr i64 %t157 to ptr
  %t160 = load ptr, ptr %l68, !tbaa !29
  %t162 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t159, ptr %s3, ptr %t160, i32 %t153)
  store { i64, ptr } %t162, ptr %l71
  br label %bb31
bb31:
  %t163 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = load i64, ptr %l62
  %t167 = inttoptr i64 %t166 to ptr
  %t168 = call ptr @__olang_held_alloc(ptr %t167, i64 %t165)
  call void @olang_textcopy(ptr %t168, ptr %t164, i64 %t165)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  %t172 = load ptr, ptr %l57, !tbaa !29
  %t173 = load i64, ptr %l61, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t172, i64 %t173, { i64, ptr } %t170)
  br label %bb32
bb32:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v3, ptr %t175, ptr %t176)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l77, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t186 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t181, ptr %t182)
  store i64 %t186, ptr %l81
  br label %bb38
bb38:
  %t187 = load ptr, ptr %l77, !tbaa !29
  %t188 = load i64, ptr %l81, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t187, i64 %t188, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb39
bb39:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t189, ptr %t190, { i64, ptr } %t191)
  br label %bb40
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_585fa5a01a72b2ac_16d8ccfed8d78ee8)
  unreachable
bb42:
  %t195 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t195, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  store i64 %t199, ptr %l9, !tbaa !24
  br label %bb43
bb43:
  %t201 = load i64, ptr %l8, !tbaa !24
  %t202 = load i64, ptr %l9, !tbaa !24
  %t205 = icmp slt i64 %t201, %t202
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb44, label %bb45
bb44:
  br label %bb49
bb45:
  br label %bb46
bb46:
  %t209 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t209, ptr %l92, !tbaa !27
  %t210 = load i64, ptr %l8, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr ptr, ptr %t213, i64 %t210
  %t215 = load ptr, ptr %t214, !tbaa !39
  %t217 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %v3, ptr %t217, ptr %t215)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t222 = load i64, ptr %l8, !tbaa !24
  %t225 = add i64 %t222, 1
  store i64 %t225, ptr %l8, !tbaa !24
  br label %bb43
bb49:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecalled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca %"compiler/names:Ref"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l20 = alloca ptr
  %l25 = alloca %"compiler/names:Ref"
  %l28 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca %"compiler/names:Ref"
  %l55 = alloca i64
  %l58 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/needs:walker", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/needs:walker", ptr %t32, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = call ptr @__olang_scope_or(ptr %v2, ptr %t38)
  %t40 = call ptr @__olang_scope_hold(ptr %t39)
  %t41 = ptrtoint ptr %t40 to i64
  %t43 = inttoptr i64 %t41 to ptr
  %t44 = load ptr, ptr %l20, !tbaa !29
  %t47 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %t43, ptr %t44, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t47, ptr %l25
  br label %bb6
bb6:
  %t48 = load %"compiler/names:Ref", ptr %l25
  store %"compiler/names:Ref" %t48, ptr %l4
  %t49 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 9}
  %t52 = trunc i64 3 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb7, label %bb8
bb7:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/needs:walker", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  store ptr %t61, ptr %l31, !tbaa !29
  %t62 = getelementptr %"compiler/names:Ref", ptr %l4, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load ptr, ptr %l31, !tbaa !29
  %t66 = call ptr @__olang_scope_or(ptr %v2, ptr %t65)
  %t67 = call ptr @__olang_scope_hold(ptr %t66)
  %t68 = ptrtoint ptr %t67 to i64
  %t70 = inttoptr i64 %t68 to ptr
  %t71 = load ptr, ptr %l31, !tbaa !29
  %t74 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %t70, ptr %t71, i64 %t63, i32 %t64)
  store i64 %t74, ptr %l35
  br label %bb9
bb8:
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb10
bb9:
  %t75 = load i64, ptr %l35, !tbaa !24
  store i64 %t75, ptr %l28, !tbaa !24
  br label %bb10
bb10:
  %t76 = load i64, ptr %l28, !tbaa !24
  store i64 %t76, ptr %rv
  br label %ret
bb11:
  %t77 = load ptr, ptr %l1, !tbaa !29
  store ptr %t77, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb12, label %bb13
bb12:
  %t81 = load ptr, ptr %l36, !tbaa !29
  %t82 = load i64, ptr %t81, !range !{i64 0, i64 28}
  %t84 = icmp eq i64 %t82, 12
  store i1 %t84, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t85 = load i1, ptr %l37, !tbaa !21
  br i1 %t85, label %bb14, label %bb15
bb14:
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t88, i32 0, i32 0
  %t90 = load %"compiler/source:Span", ptr %t89
  store %"compiler/source:Span" %t90, ptr %l5
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t94, i32 0, i32 2
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l6, !tbaa !23
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/needs:walker", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/generic:Program", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l47, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/needs:walker", ptr %t108, i32 0, i32 3
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = getelementptr %"compiler/source:Span", ptr %l5, i32 0, i32 1
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load ptr, ptr %l47, !tbaa !29
  %t115 = call ptr @__olang_scope_or(ptr %v2, ptr %t114)
  %t116 = call ptr @__olang_scope_hold(ptr %t115)
  %t117 = ptrtoint ptr %t116 to i64
  %t119 = inttoptr i64 %t117 to ptr
  %t120 = load ptr, ptr %l47, !tbaa !29
  %t123 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %t119, ptr %t120, i64 %t111, i32 %t113)
  store %"compiler/names:Ref" %t123, ptr %l52
  br label %bb17
bb17:
  %t124 = load %"compiler/names:Ref", ptr %l52
  store %"compiler/names:Ref" %t124, ptr %l7
  %t125 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t126 = load i32, ptr %t125, !range !{i32 0, i32 9}
  %t128 = trunc i64 3 to i32
  %t129 = icmp eq i32 %t126, %t128
  br i1 %t129, label %bb18, label %bb19
bb18:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/needs:walker", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  store ptr %t137, ptr %l58, !tbaa !29
  %t138 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = load i32, ptr %l6, !tbaa !23
  %t141 = load ptr, ptr %l58, !tbaa !29
  %t142 = call ptr @__olang_scope_or(ptr %v2, ptr %t141)
  %t143 = call ptr @__olang_scope_hold(ptr %t142)
  %t144 = ptrtoint ptr %t143 to i64
  %t146 = inttoptr i64 %t144 to ptr
  %t147 = load ptr, ptr %l58, !tbaa !29
  %t150 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %t146, ptr %t147, i64 %t139, i32 %t140)
  store i64 %t150, ptr %l62
  br label %bb20
bb19:
  store i64 -1, ptr %l55, !tbaa !24
  br label %bb21
bb20:
  %t151 = load i64, ptr %l62, !tbaa !24
  store i64 %t151, ptr %l55, !tbaa !24
  br label %bb21
bb21:
  %t152 = load i64, ptr %l55, !tbaa !24
  store i64 %t152, ptr %rv
  br label %ret
bb22:
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t154 = load ptr, ptr %l63, !tbaa !29
  %t155 = icmp ne ptr %t154, null
  br i1 %t155, label %bb23, label %bb24
bb23:
  %t157 = load ptr, ptr %l63, !tbaa !29
  %t158 = load i64, ptr %t157, !range !{i64 0, i64 28}
  %t160 = icmp eq i64 %t158, 11
  store i1 %t160, ptr %l64, !tbaa !21
  br label %bb24
bb24:
  %t161 = load i1, ptr %l64, !tbaa !21
  br i1 %t161, label %bb25, label %bb26
bb25:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t164, i32 0, i32 1
  %t166 = load ptr, ptr %t165
  store ptr %t166, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l8, !tbaa !29
  %t172 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecalled(ptr %v0, ptr %v1, ptr %v2, ptr %t168, ptr %t169)
  store i64 %t172, ptr %l71
  br label %bb28
bb28:
  %t173 = load i64, ptr %l71, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i64 -1, ptr %rv
  br label %ret
bb33:
  call void @__olang_check_failed(ptr @olang_loc_905d4a0f3532f957_2b4330c2b114d9a3)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l43 = alloca { i64, ptr }
  %l51 = alloca i1
  %l59 = alloca { i64, ptr }
  %l63 = alloca i64
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l78 = alloca i64
  %l84 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:VarDecl", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb3:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l23, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb5
bb5:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l6, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  br label %bb29
bb9:
  br label %bb10
bb10:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/ast:VarDecl", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l43, !tbaa !27
  %t59 = load i64, ptr %l7, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i32, ptr %t62, i64 %t59
  %t64 = load i32, ptr %t63, !tbaa !33
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = getelementptr %"compiler/ast:VarDecl", ptr %t65, i32 0, i32 2
  %t68 = load ptr, ptr %t67, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eparam(ptr %v0, ptr %v1, ptr %v2, ptr %t54, i32 %t64, ptr %t68)
  br label %bb11
bb11:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/ast:VarDecl", ptr %t72, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb14
bb13:
  %t79 = load i64, ptr %l7, !tbaa !24
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/ast:VarDecl", ptr %t80, i32 0, i32 3
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t88 = icmp sge i64 %t79, %t85
  store i1 %t88, ptr %l51, !tbaa !21
  br label %bb14
bb14:
  %t90 = load i1, ptr %l51, !tbaa !21
  br i1 %t90, label %bb15, label %bb16
bb15:
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/ast:VarDecl", ptr %t92, i32 0, i32 3
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  store { i64, ptr } %t95, ptr %l59, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 %t96
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t105 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t91, ptr %t101)
  store i64 %t105, ptr %l63
  br label %bb18
bb18:
  %t106 = load i64, ptr %l63, !tbaa !24
  store i64 %t106, ptr %l8, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t109 = icmp sge i64 %t107, 0
  br i1 %t109, label %bb19, label %bb20
bb19:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/needs:walker", ptr %t111, i32 0, i32 5
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/ast:VarDecl", ptr %t114, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l69, !tbaa !27
  %t118 = load i64, ptr %l7, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i32, ptr %t121, i64 %t118
  %t123 = load i32, ptr %t122, !tbaa !33
  %t124 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t113, i32 %t123, i64 %t124)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/ast:VarDecl", ptr %t129, i32 0, i32 3
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l75, !tbaa !27
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr ptr, ptr %t136, i64 %t133
  %t138 = load ptr, ptr %t137, !tbaa !39
  %t141 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eelemsOf(ptr %v0, ptr %v1, ptr %t128, ptr %t138)
  store i64 %t141, ptr %l78
  br label %bb23
bb23:
  %t142 = load i64, ptr %l78, !tbaa !24
  store i64 %t142, ptr %l9, !tbaa !24
  %t143 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp sge i64 %t143, 0
  br i1 %t145, label %bb24, label %bb25
bb24:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/needs:walker", ptr %t147, i32 0, i32 6
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr %"compiler/ast:VarDecl", ptr %t150, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  store { i64, ptr } %t153, ptr %l84, !tbaa !27
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i32, ptr %t157, i64 %t154
  %t159 = load i32, ptr %t158, !tbaa !33
  %t160 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t149, i32 %t159, i64 %t160)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t164 = load i64, ptr %l6, !tbaa !24
  %t167 = add i64 %t164, 1
  store i64 %t167, ptr %l6, !tbaa !24
  br label %bb7
bb29:
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t171 = getelementptr %"compiler/ast:VarDecl", ptr %t169, i32 0, i32 3
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  store i64 %t176, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  %t178 = load i64, ptr %l11, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb31, label %bb32
bb31:
  br label %bb36
bb32:
  br label %bb33
bb33:
  %t186 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t186, ptr %l99, !tbaa !27
  %t187 = load i64, ptr %l11, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr ptr, ptr %t190, i64 %t187
  %t192 = load ptr, ptr %t191, !tbaa !39
  %t194 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t194, ptr %t192)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t199 = load i64, ptr %l11, !tbaa !24
  %t202 = add i64 %t199, 1
  store i64 %t202, ptr %l11, !tbaa !24
  br label %bb30
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l41 = alloca ptr
  %l45 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca ptr
  %l75 = alloca i64
  %l82 = alloca ptr
  %l83 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca ptr
  %l103 = alloca i64
  %l110 = alloca ptr
  %l111 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l129 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca i64
  %l140 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i1
  %l157 = alloca ptr
  %l161 = alloca i64
  %l163 = alloca i1
  %l164 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l184 = alloca ptr
  %l185 = alloca i1
  %l194 = alloca ptr
  %l198 = alloca i64
  %l206 = alloca ptr
  %l207 = alloca i1
  %s11 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t6 = load ptr, ptr %l31, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l31, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 28}
  %t12 = icmp eq i64 %t10, 3
  store i1 %t12, ptr %l32, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l32, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 116}
  store i32 %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l3, !tbaa !29
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t26 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t28 = trunc i64 69 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb9, label %bb10
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l41, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t37 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i64 %t37, ptr %l45
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t38 = load ptr, ptr %l41, !tbaa !29
  %t39 = load i64, ptr %l45, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t38, i64 %t39, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d21, i32 0, i32 1) })
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t40, ptr %t41)
  br label %bb14
bb14:
  br label %bb111
bb15:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t46 = load ptr, ptr %l49, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb16, label %bb17
bb16:
  %t49 = load ptr, ptr %l49, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 28}
  %t52 = icmp eq i64 %t50, 5
  store i1 %t52, ptr %l50, !tbaa !21
  br label %bb17
bb17:
  %t53 = load i1, ptr %l50, !tbaa !21
  br i1 %t53, label %bb18, label %bb19
bb18:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [4 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57, !range !{i32 0, i32 116}
  store i32 %t58, ptr %l4
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t62, i32 0, i32 2
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l5, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t66, i32 0, i32 1
  %t69 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t68, i32 0, i32 3
  %t70 = load ptr, ptr %t69
  store ptr %t70, ptr %l6, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t74 = load ptr, ptr %l5, !tbaa !29
  %t75 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ebinary(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t72, i32 %t73, ptr %t74, ptr %t75)
  br label %bb21
bb21:
  br label %bb111
bb22:
  %t80 = load ptr, ptr %l1, !tbaa !29
  store ptr %t80, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t81 = load ptr, ptr %l63, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb23, label %bb24
bb23:
  %t84 = load ptr, ptr %l63, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 28}
  %t87 = icmp eq i64 %t85, 6
  store i1 %t87, ptr %l64, !tbaa !21
  br label %bb24
bb24:
  %t88 = load i1, ptr %l64, !tbaa !21
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t89 = load ptr, ptr %l1, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l7, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l71, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t107 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i64 %t107, ptr %l75
  br label %bb28
bb28:
  %t108 = load ptr, ptr %l71, !tbaa !29
  %t109 = load i64, ptr %l75, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t108, i64 %t109, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb29
bb29:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t110, ptr %t111)
  br label %bb30
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l8, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t115, ptr %t116)
  br label %bb31
bb31:
  br label %bb111
bb32:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t121 = load ptr, ptr %l82, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb33, label %bb34
bb33:
  %t124 = load ptr, ptr %l82, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 28}
  %t127 = icmp eq i64 %t125, 7
  store i1 %t127, ptr %l83, !tbaa !21
  br label %bb34
bb34:
  %t128 = load i1, ptr %l83, !tbaa !21
  br i1 %t128, label %bb35, label %bb36
bb35:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr }, ptr %t131, i32 0, i32 1
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l9, !tbaa !29
  br label %bb37
bb36:
  br label %bb47
bb37:
  %t135 = load ptr, ptr %l9, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Chain", ptr %t135, i32 0, i32 1
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t144 = load i64, ptr %l11, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb39, label %bb40
bb39:
  br label %bb46
bb40:
  br label %bb41
bb41:
  %t152 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t152, ptr %l96, !tbaa !27
  %t153 = load i64, ptr %l11, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr ptr, ptr %t156, i64 %t153
  %t158 = load ptr, ptr %t157, !tbaa !39
  store ptr %t158, ptr %l13, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  store ptr %t160, ptr %l99, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l13, !tbaa !29
  %t166 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t161, ptr %t162)
  store i64 %t166, ptr %l103
  br label %bb42
bb42:
  %t167 = load ptr, ptr %l99, !tbaa !29
  %t168 = load i64, ptr %l103, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t167, i64 %t168, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) })
  br label %bb43
bb43:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t169, ptr %t170)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = add i64 %t174, 1
  store i64 %t177, ptr %l11, !tbaa !24
  br label %bb38
bb46:
  br label %bb111
bb47:
  %t179 = load ptr, ptr %l1, !tbaa !29
  store ptr %t179, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t180 = load ptr, ptr %l110, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb48, label %bb49
bb48:
  %t183 = load ptr, ptr %l110, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 28}
  %t186 = icmp eq i64 %t184, 10
  store i1 %t186, ptr %l111, !tbaa !21
  br label %bb49
bb49:
  %t187 = load i1, ptr %l111, !tbaa !21
  br i1 %t187, label %bb50, label %bb51
bb50:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l14, !tbaa !29
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t196, i32 0, i32 2
  %t198 = load { i64, ptr }, ptr %t197
  store { i64, ptr } %t198, ptr %l15, !tbaa !27
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l14, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t200, ptr %t201, { i64, ptr } %t202)
  br label %bb53
bb53:
  br label %bb111
bb54:
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t207 = load ptr, ptr %l121, !tbaa !29
  %t208 = icmp ne ptr %t207, null
  br i1 %t208, label %bb55, label %bb56
bb55:
  %t210 = load ptr, ptr %l121, !tbaa !29
  %t211 = load i64, ptr %t210, !range !{i64 0, i64 28}
  %t213 = icmp eq i64 %t211, 12
  store i1 %t213, ptr %l122, !tbaa !21
  br label %bb56
bb56:
  %t214 = load i1, ptr %l122, !tbaa !21
  br i1 %t214, label %bb57, label %bb58
bb57:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr { i64, [4 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t217, i32 0, i32 1
  %t219 = load ptr, ptr %t218
  store ptr %t219, ptr %l16, !tbaa !29
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [4 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t223, i32 0, i32 2
  %t225 = load i32, ptr %t224
  store i32 %t225, ptr %l17, !tbaa !23
  br label %bb59
bb58:
  br label %bb66
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l129, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load ptr, ptr %l16, !tbaa !29
  %t233 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t228, ptr %t229)
  store i64 %t233, ptr %l133
  br label %bb60
bb60:
  %t234 = call ptr @__olang_scope_hold(ptr %v0)
  %t235 = ptrtoint ptr %t234 to i64
  store i64 %t235, ptr %l134, !tbaa !24
  %t236 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t236, label %bb61, label %bb62
bb61:
  %t238 = call ptr @__olang_region_make(ptr %v0)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l134, !tbaa !24
  br label %bb62
bb62:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/needs:walker", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = getelementptr %"compiler/check:Checker", ptr %t243, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t248 = getelementptr %"compiler/generic:Program", ptr %t246, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/load:Loader", ptr %t249, i32 0, i32 3
  %t252 = load ptr, ptr %t251, !tbaa !29
  store ptr %t252, ptr %l140, !tbaa !29
  %t253 = load i32, ptr %l17, !tbaa !23
  %t254 = load ptr, ptr %l140, !tbaa !29
  %t255 = call ptr @__olang_scope_or(ptr %v2, ptr %t254)
  %t256 = call ptr @__olang_scope_hold(ptr %t255)
  %t257 = ptrtoint ptr %t256 to i64
  %t259 = inttoptr i64 %t257 to ptr
  %t260 = load ptr, ptr %l140, !tbaa !29
  %t262 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t259, ptr %s11, ptr %t260, i32 %t253)
  store { i64, ptr } %t262, ptr %l143
  br label %bb63
bb63:
  %t263 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t265 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t271 = add i64 %t268, %t270
  %t272 = load i64, ptr %l134
  %t273 = inttoptr i64 %t272 to ptr
  %t274 = call ptr @__olang_held_alloc(ptr %t273, i64 %t271)
  call void @olang_textcopy(ptr %t274, ptr %t263, i64 %t264)
  %t275 = getelementptr i8, ptr %t274, i64 %t264
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = getelementptr i8, ptr %t275, i64 %t267
  call void @olang_textcopy(ptr %t276, ptr %t269, i64 %t270)
  %t277 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  %t280 = load ptr, ptr %l129, !tbaa !29
  %t281 = load i64, ptr %l133, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t280, i64 %t281, { i64, ptr } %t278)
  br label %bb64
bb64:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t283, ptr %t284)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s11)
  br label %bb111
bb66:
  %t288 = load ptr, ptr %l1, !tbaa !29
  store ptr %t288, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t289 = load ptr, ptr %l149, !tbaa !29
  %t290 = icmp ne ptr %t289, null
  br i1 %t290, label %bb67, label %bb68
bb67:
  %t292 = load ptr, ptr %l149, !tbaa !29
  %t293 = load i64, ptr %t292, !range !{i64 0, i64 28}
  %t295 = icmp eq i64 %t293, 13
  store i1 %t295, ptr %l150, !tbaa !21
  br label %bb68
bb68:
  %t296 = load i1, ptr %l150, !tbaa !21
  br i1 %t296, label %bb69, label %bb70
bb69:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr { i64, [4 x i64] }, ptr %t297, i32 0, i32 1
  %t300 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t299, i32 0, i32 1
  %t301 = load ptr, ptr %t300
  store ptr %t301, ptr %l18, !tbaa !29
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr { i64, [4 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t305, i32 0, i32 2
  %t307 = load { i64, ptr }, ptr %t306
  store { i64, ptr } %t307, ptr %l19, !tbaa !27
  br label %bb71
bb70:
  br label %bb86
bb71:
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l157, !tbaa !29
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load ptr, ptr %l18, !tbaa !29
  %t315 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t310, ptr %t311)
  store i64 %t315, ptr %l161
  br label %bb72
bb72:
  %t316 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t318 = call i1 @compiler_2fast_2eSlicing(ptr %v1, { i64, ptr } %t316)
  store i1 %t318, ptr %l163
  br label %bb73
bb73:
  %t319 = load i1, ptr %l163, !tbaa !21
  br i1 %t319, label %bb74, label %bb75
bb74:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l164, !tbaa !27
  br label %bb76
bb75:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l164, !tbaa !27
  br label %bb76
bb76:
  %t320 = load ptr, ptr %l157, !tbaa !29
  %t321 = load i64, ptr %l161, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l164, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t320, i64 %t321, { i64, ptr } %t322)
  br label %bb77
bb77:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t323, ptr %t324)
  br label %bb78
bb78:
  %t328 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t328, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t330 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t332 = extractvalue { i64, ptr } %t330, 0
  store i64 %t332, ptr %l22, !tbaa !24
  br label %bb79
bb79:
  %t334 = load i64, ptr %l21, !tbaa !24
  %t335 = load i64, ptr %l22, !tbaa !24
  %t338 = icmp slt i64 %t334, %t335
  %t340 = xor i1 %t338, true
  br i1 %t340, label %bb80, label %bb81
bb80:
  br label %bb85
bb81:
  br label %bb82
bb82:
  %t342 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t342, ptr %l175, !tbaa !27
  %t343 = load i64, ptr %l21, !tbaa !24
  %t345 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = getelementptr ptr, ptr %t346, i64 %t343
  %t348 = load ptr, ptr %t347, !tbaa !39
  %t350 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t350, ptr %t348)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t355 = load i64, ptr %l21, !tbaa !24
  %t358 = add i64 %t355, 1
  store i64 %t358, ptr %l21, !tbaa !24
  br label %bb79
bb85:
  br label %bb111
bb86:
  %t360 = load ptr, ptr %l1, !tbaa !29
  store ptr %t360, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t361 = load ptr, ptr %l184, !tbaa !29
  %t362 = icmp ne ptr %t361, null
  br i1 %t362, label %bb87, label %bb88
bb87:
  %t364 = load ptr, ptr %l184, !tbaa !29
  %t365 = load i64, ptr %t364, !range !{i64 0, i64 28}
  %t367 = icmp eq i64 %t365, 14
  store i1 %t367, ptr %l185, !tbaa !21
  br label %bb88
bb88:
  %t368 = load i1, ptr %l185, !tbaa !21
  br i1 %t368, label %bb89, label %bb90
bb89:
  %t369 = load ptr, ptr %l1, !tbaa !29
  %t371 = getelementptr { i64, [4 x i64] }, ptr %t369, i32 0, i32 1
  %t372 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t371, i32 0, i32 1
  %t373 = load ptr, ptr %t372
  store ptr %t373, ptr %l24, !tbaa !29
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr { i64, [4 x i64] }, ptr %t375, i32 0, i32 1
  %t378 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t377, i32 0, i32 2
  %t379 = load ptr, ptr %t378
  store ptr %t379, ptr %l25, !tbaa !29
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t383 = getelementptr { i64, [4 x i64] }, ptr %t381, i32 0, i32 1
  %t384 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t383, i32 0, i32 3
  %t385 = load ptr, ptr %t384
  store ptr %t385, ptr %l26, !tbaa !29
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l194, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load ptr, ptr %l24, !tbaa !29
  %t393 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t388, ptr %t389)
  store i64 %t393, ptr %l198
  br label %bb92
bb92:
  %t394 = load ptr, ptr %l194, !tbaa !29
  %t395 = load i64, ptr %l198, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t394, i64 %t395, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb93
bb93:
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t396, ptr %t397)
  br label %bb94
bb94:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t401, ptr %t402)
  br label %bb95
bb95:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t405, ptr %t406)
  br label %bb96
bb96:
  br label %bb111
bb97:
  %t409 = load ptr, ptr %l1, !tbaa !29
  store ptr %t409, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t410 = load ptr, ptr %l206, !tbaa !29
  %t411 = icmp ne ptr %t410, null
  br i1 %t411, label %bb98, label %bb99
bb98:
  %t413 = load ptr, ptr %l206, !tbaa !29
  %t414 = load i64, ptr %t413, !range !{i64 0, i64 28}
  %t416 = icmp eq i64 %t414, 15
  store i1 %t416, ptr %l207, !tbaa !21
  br label %bb99
bb99:
  %t417 = load i1, ptr %l207, !tbaa !21
  br i1 %t417, label %bb100, label %bb101
bb100:
  %t418 = load ptr, ptr %l1, !tbaa !29
  %t420 = getelementptr { i64, [4 x i64] }, ptr %t418, i32 0, i32 1
  %t421 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t420, i32 0, i32 1
  %t422 = load ptr, ptr %t421
  store ptr %t422, ptr %l27, !tbaa !29
  %t424 = load ptr, ptr %l1, !tbaa !29
  %t426 = getelementptr { i64, [4 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t426, i32 0, i32 2
  %t428 = load ptr, ptr %t427
  store ptr %t428, ptr %l28, !tbaa !29
  br label %bb102
bb101:
  br label %bb105
bb102:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t430, ptr %t431)
  br label %bb103
bb103:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t434, ptr %t435)
  br label %bb104
bb104:
  br label %bb111
bb105:
  br i1 true, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %t438, ptr %t439)
  br label %bb109
bb109:
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_21eaca0c6a8c7fc1_c6101a29af81bc15)
  unreachable
bb111:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eforIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i64
  %l14 = alloca ptr
  %l19 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:ForIn", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eelemsOf(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t9 = load i64, ptr %l6, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/needs:walker", ptr %t14, i32 0, i32 5
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:ForIn", ptr %t17, i32 0, i32 1
  %t20 = load i32, ptr %t19, !tbaa !23
  %t21 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t16, i32 %t20, i64 %t21)
  br label %bb4
bb3:
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l14, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:ForIn", ptr %t27, i32 0, i32 2
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t34 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  store i64 %t34, ptr %l19
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t35 = load ptr, ptr %l14, !tbaa !29
  %t36 = load i64, ptr %l19, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t35, i64 %t36, { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr %"compiler/ast:ForIn", ptr %t38, i32 0, i32 2
  %t41 = load ptr, ptr %t40, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t41)
  br label %bb8
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/ast:ForIn", ptr %t46, i32 0, i32 4
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %t45, { i64, ptr } %t49)
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr %"compiler/ast:ForIn", ptr %t53, i32 0, i32 5
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecatches(ptr %v0, ptr %v1, ptr %v2, ptr %t52, { i64, ptr } %t56)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eifStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca ptr
  %l25 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:If", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i1 %t8, ptr %l5
  br label %bb1
bb1:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:If", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t10, ptr %t14)
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l13, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb8, label %bb9
bb7:
  br label %bb12
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9c9e5b16a9737640_c9291bd1f0d77b3c)
  unreachable
bb9:
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/ast:If", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t40 = getelementptr %"compiler/ast:Branch", ptr %t37, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t42 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %t42, { i64, ptr } %t41)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:If", ptr %t44, i32 0, i32 2
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = icmp eq ptr %t47, null
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  store ptr %t53, ptr %l25, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/ast:If", ptr %t54, i32 0, i32 2
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb15, label %bb16
bb14:
  br label %bb19
bb15:
  call void @__olang_check_failed(ptr @olang_loc_8cbabffa04a291df_a080b7e111f166ab)
  unreachable
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/ast:If", ptr %t61, i32 0, i32 2
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t65 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t64)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eparts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l87 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t2 = load ptr, ptr %l16, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l16, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l17, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l17, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb17
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t17 = load ptr, ptr %l22, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 28}
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l23, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l23, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb17
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l28, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 28}
  %t38 = icmp eq i64 %t36, 24
  store i1 %t38, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l29, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t42, i32 0, i32 2
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l2, !tbaa !29
  br label %bb17
bb12:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 28}
  %t53 = icmp eq i64 %t51, 9
  store i1 %t53, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t54 = load i1, ptr %l35, !tbaa !21
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [4 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t57, i32 0, i32 1
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l2, !tbaa !29
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t61, ptr %t62)
  br label %bb18
bb18:
  br label %bb85
bb19:
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t67 = load ptr, ptr %l43, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 28}
  %t73 = icmp eq i64 %t71, 8
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb21
bb21:
  %t74 = load i1, ptr %l44, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l3, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t83, i32 0, i32 2
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t89, i32 0, i32 3
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb28
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t93, ptr %t94)
  br label %bb25
bb25:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t98, ptr %t99)
  br label %bb26
bb26:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t103, ptr %t104)
  br label %bb27
bb27:
  br label %bb85
bb28:
  %t108 = load ptr, ptr %l1, !tbaa !29
  store ptr %t108, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t109 = load ptr, ptr %l62, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l62, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 28}
  %t115 = icmp eq i64 %t113, 16
  store i1 %t115, ptr %l63, !tbaa !21
  br label %bb30
bb30:
  %t116 = load i1, ptr %l63, !tbaa !21
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t119, i32 0, i32 2
  %t121 = load { i64, ptr }, ptr %t120
  store { i64, ptr } %t121, ptr %l6, !tbaa !27
  br label %bb41
bb32:
  %t123 = load ptr, ptr %l1, !tbaa !29
  store ptr %t123, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t124 = load ptr, ptr %l68, !tbaa !29
  %t125 = icmp ne ptr %t124, null
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load ptr, ptr %l68, !tbaa !29
  %t128 = load i64, ptr %t127, !range !{i64 0, i64 28}
  %t130 = icmp eq i64 %t128, 17
  store i1 %t130, ptr %l69, !tbaa !21
  br label %bb34
bb34:
  %t131 = load i1, ptr %l69, !tbaa !21
  br i1 %t131, label %bb35, label %bb36
bb35:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr { i64, [4 x i64] }, ptr %t132, i32 0, i32 1
  %t135 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t134, i32 0, i32 1
  %t136 = load { i64, ptr }, ptr %t135
  store { i64, ptr } %t136, ptr %l6, !tbaa !27
  br label %bb41
bb36:
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t139 = load ptr, ptr %l74, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb37, label %bb38
bb37:
  %t142 = load ptr, ptr %l74, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 28}
  %t145 = icmp eq i64 %t143, 22
  store i1 %t145, ptr %l75, !tbaa !21
  br label %bb38
bb38:
  %t146 = load i1, ptr %l75, !tbaa !21
  br i1 %t146, label %bb39, label %bb40
bb39:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t149, i32 0, i32 1
  %t151 = load { i64, ptr }, ptr %t150
  store { i64, ptr } %t151, ptr %l6, !tbaa !27
  br label %bb41
bb40:
  br label %bb49
bb41:
  %t153 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t153, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  store i64 %t157, ptr %l9, !tbaa !24
  br label %bb42
bb42:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t160 = load i64, ptr %l9, !tbaa !24
  %t163 = icmp slt i64 %t159, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l87, !tbaa !27
  %t168 = load i64, ptr %l8, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr ptr, ptr %t171, i64 %t168
  %t173 = load ptr, ptr %t172, !tbaa !39
  %t175 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t175, ptr %t173)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t180 = load i64, ptr %l8, !tbaa !24
  %t183 = add i64 %t180, 1
  store i64 %t183, ptr %l8, !tbaa !24
  br label %bb42
bb48:
  br label %bb85
bb49:
  %t185 = load ptr, ptr %l1, !tbaa !29
  store ptr %t185, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t186 = load ptr, ptr %l96, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb50, label %bb51
bb50:
  %t189 = load ptr, ptr %l96, !tbaa !29
  %t190 = load i64, ptr %t189, !range !{i64 0, i64 28}
  %t192 = icmp eq i64 %t190, 19
  store i1 %t192, ptr %l97, !tbaa !21
  br label %bb51
bb51:
  %t193 = load i1, ptr %l97, !tbaa !21
  br i1 %t193, label %bb52, label %bb53
bb52:
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr { i64, [4 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t196, i32 0, i32 1
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l11, !tbaa !29
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr { i64, [4 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t202, i32 0, i32 2
  %t204 = load { i64, ptr }, ptr %t203
  store { i64, ptr } %t204, ptr %l12, !tbaa !27
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t207 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t206, ptr %t207)
  br label %bb55
bb55:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecatches(ptr %v0, ptr %v1, ptr %v2, ptr %t211, { i64, ptr } %t212)
  br label %bb56
bb56:
  br label %bb85
bb57:
  %t215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t215, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t216 = load ptr, ptr %l109, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb58, label %bb59
bb58:
  %t219 = load ptr, ptr %l109, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 28}
  %t222 = icmp eq i64 %t220, 21
  store i1 %t222, ptr %l110, !tbaa !21
  br label %bb59
bb59:
  %t223 = load i1, ptr %l110, !tbaa !21
  br i1 %t223, label %bb60, label %bb61
bb60:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr { i64, [4 x i64] }, ptr %t224, i32 0, i32 1
  %t227 = getelementptr { %"compiler/source:Span", ptr }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227
  store ptr %t228, ptr %l13, !tbaa !29
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %t230, ptr %t231)
  br label %bb63
bb63:
  br label %bb85
bb64:
  %t234 = load ptr, ptr %l1, !tbaa !29
  store ptr %t234, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t235 = load ptr, ptr %l117, !tbaa !29
  %t236 = icmp ne ptr %t235, null
  br i1 %t236, label %bb65, label %bb66
bb65:
  %t238 = load ptr, ptr %l117, !tbaa !29
  %t239 = load i64, ptr %t238, !range !{i64 0, i64 28}
  %t241 = icmp eq i64 %t239, 18
  store i1 %t241, ptr %l118, !tbaa !21
  br label %bb66
bb66:
  %t242 = load i1, ptr %l118, !tbaa !21
  br i1 %t242, label %bb67, label %bb68
bb67:
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t243, i32 0, i32 1
  %t246 = getelementptr { %"compiler/source:Span", ptr }, ptr %t245, i32 0, i32 1
  %t247 = load ptr, ptr %t246
  store ptr %t247, ptr %l14, !tbaa !29
  br label %bb69
bb68:
  br label %bb73
bb69:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load ptr, ptr %l14, !tbaa !29
  %t252 = getelementptr %"compiler/ast:Compr", ptr %t250, i32 0, i32 4
  %t253 = load ptr, ptr %t252, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t249, ptr %t253)
  br label %bb70
bb70:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l14, !tbaa !29
  %t260 = getelementptr %"compiler/ast:Compr", ptr %t258, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t257, ptr %t261)
  br label %bb71
bb71:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load ptr, ptr %l14, !tbaa !29
  %t268 = getelementptr %"compiler/ast:Compr", ptr %t266, i32 0, i32 5
  %t269 = load ptr, ptr %t268, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t265, ptr %t269)
  br label %bb72
bb72:
  br label %bb85
bb73:
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t273 = load ptr, ptr %l134, !tbaa !29
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %bb74, label %bb75
bb74:
  %t276 = load ptr, ptr %l134, !tbaa !29
  %t277 = load i64, ptr %t276, !range !{i64 0, i64 28}
  %t279 = icmp eq i64 %t277, 25
  store i1 %t279, ptr %l135, !tbaa !21
  br label %bb75
bb75:
  %t280 = load i1, ptr %l135, !tbaa !21
  br i1 %t280, label %bb76, label %bb77
bb76:
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [4 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", ptr }, ptr %t283, i32 0, i32 1
  %t285 = load ptr, ptr %t284
  store ptr %t285, ptr %l15, !tbaa !29
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t287, ptr %t288)
  br label %bb79
bb79:
  br label %bb85
bb80:
  br i1 true, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_9f3ed7f83038a02_b8cf4e04baa63c1e)
  unreachable
bb85:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l42 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l66 = alloca ptr
  %l67 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l87 = alloca i1
  %l96 = alloca { i64, ptr }
  %l102 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t7 = load ptr, ptr %l16, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l16, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 28}
  %t13 = icmp eq i64 %t11, 12
  store i1 %t13, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l17, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t20 = load ptr, ptr %l22, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb8, label %bb9
bb7:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t23 = load ptr, ptr %l22, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 28}
  %t26 = icmp eq i64 %t24, 0
  store i1 %t26, ptr %l23, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i1, ptr %l23, !tbaa !21
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t28 = load i1, ptr %l20, !tbaa !21
  br i1 %t28, label %bb11, label %bb12
bb11:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l2, !tbaa !23
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/needs:walker", ptr %t39, i32 0, i32 4
  %t42 = load i32, ptr %l2, !tbaa !23
  %t45 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l32
  br label %bb14
bb14:
  %t46 = load i1, ptr %l32, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
bb15:
  %t47 = load ptr, ptr %l1, !tbaa !29
  store ptr %t47, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t51 = load ptr, ptr %l33, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 28}
  %t54 = icmp eq i64 %t52, 12
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb17
bb17:
  %t55 = load i1, ptr %l34, !tbaa !21
  br i1 %t55, label %bb18, label %bb19
bb18:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t58, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  store ptr %t60, ptr %l3, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t67 = call i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i1 %t67, ptr %l42
  br label %bb21
bb21:
  %t68 = load i1, ptr %l42, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
bb22:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb23, label %bb24
bb23:
  %t73 = load ptr, ptr %l43, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 28}
  %t76 = icmp eq i64 %t74, 5
  store i1 %t76, ptr %l44, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t80, i32 0, i32 2
  %t82 = load ptr, ptr %t81
  store ptr %t82, ptr %l4, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t86, i32 0, i32 3
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t95 = call i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %t90, ptr %t91)
  store i1 %t95, ptr %l54
  br label %bb28
bb28:
  %t96 = load i1, ptr %l54, !tbaa !21
  br i1 %t96, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb32
bb30:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l5, !tbaa !29
  %t102 = call i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store i1 %t102, ptr %l59
  br label %bb31
bb31:
  %t103 = load i1, ptr %l59, !tbaa !21
  store i1 %t103, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t104 = load i1, ptr %l55, !tbaa !21
  store i1 %t104, ptr %rv
  br label %ret
bb33:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t106 = load ptr, ptr %l60, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb34, label %bb35
bb34:
  %t109 = load ptr, ptr %l60, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 28}
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l61, !tbaa !21
  br label %bb35
bb35:
  %t113 = load i1, ptr %l61, !tbaa !21
  br i1 %t113, label %bb36, label %bb37
bb36:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l6, !tbaa !29
  br label %bb42
bb37:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t121 = load ptr, ptr %l66, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb38, label %bb39
bb38:
  %t124 = load ptr, ptr %l66, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 28}
  %t127 = icmp eq i64 %t125, 2
  store i1 %t127, ptr %l67, !tbaa !21
  br label %bb39
bb39:
  %t128 = load i1, ptr %l67, !tbaa !21
  br i1 %t128, label %bb40, label %bb41
bb40:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", ptr }, ptr %t131, i32 0, i32 1
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l6, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l6, !tbaa !29
  %t140 = call i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %t135, ptr %t136)
  store i1 %t140, ptr %l75
  br label %bb43
bb43:
  %t141 = load i1, ptr %l75, !tbaa !21
  store i1 %t141, ptr %rv
  br label %ret
bb44:
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t143 = load ptr, ptr %l76, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb45, label %bb46
bb45:
  %t146 = load ptr, ptr %l76, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 28}
  %t149 = icmp eq i64 %t147, 10
  store i1 %t149, ptr %l77, !tbaa !21
  br label %bb46
bb46:
  %t150 = load i1, ptr %l77, !tbaa !21
  br i1 %t150, label %bb47, label %bb48
bb47:
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l7, !tbaa !29
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t159, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160
  store { i64, ptr } %t161, ptr %l8, !tbaa !27
  br label %bb49
bb48:
  br label %bb64
bb49:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l7, !tbaa !29
  %t168 = call i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store i1 %t168, ptr %l87
  br label %bb50
bb50:
  %t169 = load i1, ptr %l87, !tbaa !21
  br i1 %t169, label %bb51, label %bb52
bb51:
  store i1 true, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t171 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t171, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t173, 0
  store i64 %t175, ptr %l11, !tbaa !24
  br label %bb54
bb54:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t178 = load i64, ptr %l11, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb55, label %bb56
bb55:
  br label %bb63
bb56:
  br label %bb57
bb57:
  %t185 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t185, ptr %l96, !tbaa !27
  %t186 = load i64, ptr %l10, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr ptr, ptr %t189, i64 %t186
  %t191 = load ptr, ptr %t190, !tbaa !39
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t198 = call i1 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ereflects(ptr %v0, ptr %v1, ptr %t193, ptr %t191)
  store i1 %t198, ptr %l102
  br label %bb58
bb58:
  %t199 = load i1, ptr %l102, !tbaa !21
  br i1 %t199, label %bb59, label %bb60
bb59:
  store i1 true, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t201 = load i64, ptr %l10, !tbaa !24
  %t204 = add i64 %t201, 1
  store i64 %t204, ptr %l10, !tbaa !24
  br label %bb54
bb63:
  store i1 false, ptr %rv
  br label %ret
bb64:
  br i1 true, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  store i1 false, ptr %rv
  br label %ret
bb68:
  call void @__olang_check_failed(ptr @olang_loc_fa47b13b1fa62ba2_f81ee9a5bb5727e6)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2erun(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l38 = alloca i64
  %l43 = alloca ptr
  %l48 = alloca ptr
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l77 = alloca ptr
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca ptr
  %l85 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca ptr
  %l95 = alloca %"compiler/generic:varRow"
  %l103 = alloca i64
  %l109 = alloca ptr
  %l116 = alloca i32
  %l123 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l148 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/needs:walker", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t4)
  store i64 %t6, ptr %l15
  br label %bb1
bb1:
  %t7 = load i64, ptr %l15, !tbaa !24
  store i64 %t7, ptr %l1, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/needs:walker", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l18, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/needs:walker", ptr %t15, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load ptr, ptr %l18, !tbaa !29
  %t20 = call ptr @__olang_scope_or(ptr %v1, ptr %t19)
  %t21 = call ptr @__olang_scope_hold(ptr %t20)
  %t22 = ptrtoint ptr %t21 to i64
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/needs:walker", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = call ptr @__olang_scope_or(ptr %v1, ptr %t26)
  %t29 = call ptr @__olang_scope_hold(ptr %t28)
  %t30 = ptrtoint ptr %t29 to i64
  %t32 = inttoptr i64 %t22 to ptr
  %t34 = inttoptr i64 %t30 to ptr
  %t35 = load ptr, ptr %l18, !tbaa !29
  %t37 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %t32, ptr %t34, ptr %t35, i64 %t18)
  store ptr %t37, ptr %l25
  br label %bb2
bb2:
  %t38 = load ptr, ptr %l25, !tbaa !29
  store ptr %t38, ptr %l2, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l26, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/needs:walker", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/load:Loader", ptr %t49, i32 0, i32 10
  store ptr %t51, ptr %l31, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/needs:walker", ptr %t52, i32 0, i32 0
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l34, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/needs:walker", ptr %t59, i32 0, i32 1
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = call ptr @__olang_scope_or(ptr %v1, ptr %t63)
  %t65 = call ptr @__olang_scope_hold(ptr %t64)
  %t66 = ptrtoint ptr %t65 to i64
  %t68 = inttoptr i64 %t66 to ptr
  %t69 = load ptr, ptr %l34, !tbaa !29
  %t71 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %t68, ptr %t69, i64 %t62)
  store i64 %t71, ptr %l38
  br label %bb3
bb3:
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = call ptr @__olang_scope_or(ptr %v1, ptr %t72)
  %t74 = call ptr @__olang_scope_hold(ptr %t73)
  %t75 = ptrtoint ptr %t74 to i64
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/needs:walker", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = call ptr @__olang_scope_or(ptr %v1, ptr %t79)
  %t82 = call ptr @__olang_scope_hold(ptr %t81)
  %t83 = ptrtoint ptr %t82 to i64
  %t85 = inttoptr i64 %t75 to ptr
  %t87 = inttoptr i64 %t83 to ptr
  %t88 = load ptr, ptr %l31, !tbaa !29
  %t89 = load i64, ptr %l38, !tbaa !24
  %t90 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %t85, ptr %t87, ptr %t88, i64 %t89)
  store ptr %t90, ptr %l43
  br label %bb4
bb4:
  %t91 = load ptr, ptr %l43, !tbaa !29
  %t93 = getelementptr %"compiler/load:Module", ptr %t91, i32 0, i32 4
  %t94 = load i64, ptr %t93, !tbaa !24
  %t96 = load ptr, ptr %l26, !tbaa !29
  %t97 = getelementptr %"compiler/needs:walker", ptr %t96, i32 0, i32 3
  store i64 %t94, ptr %t97, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/needs:walker", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  store ptr %t104, ptr %l48, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  %t106 = load ptr, ptr %l48, !tbaa !29
  %t107 = call ptr @__olang_scope_or(ptr %v1, ptr %t106)
  %t108 = call ptr @__olang_scope_hold(ptr %t107)
  %t109 = ptrtoint ptr %t108 to i64
  %t111 = inttoptr i64 %t109 to ptr
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t114 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %t111, ptr %t112, i64 %t105)
  store i64 %t114, ptr %l51
  br label %bb5
bb5:
  %t115 = load i64, ptr %l51, !tbaa !24
  store i64 %t115, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t116 = load i64, ptr %l4, !tbaa !24
  %t117 = load i64, ptr %l3, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb6, label %bb7
bb6:
  %t122 = load i64, ptr %l5, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb11
bb8:
  %t126 = load i64, ptr %l4, !tbaa !24
  %t127 = load i64, ptr %l3, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l5, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l5, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l58, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb10
bb10:
  %t142 = load i64, ptr %l58, !tbaa !24
  store i64 %t142, ptr %l55, !tbaa !24
  br label %bb11
bb11:
  %t143 = load i64, ptr %l55, !tbaa !24
  store i64 %t143, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l6, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb13, label %bb14
bb13:
  br label %bb25
bb14:
  br label %bb15
bb15:
  %t152 = load i64, ptr %l3, !tbaa !24
  %t153 = load i64, ptr %l7, !tbaa !24
  %t154 = load i64, ptr %l5, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l8, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/needs:walker", ptr %t162, i32 0, i32 7
  store ptr %t164, ptr %l77, !tbaa !29
  %t165 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %l78
  br label %bb16
bb16:
  %t166 = load ptr, ptr %l77, !tbaa !29
  %t167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %v0, ptr %v0, ptr %t166, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167)
  br label %bb17
bb17:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/needs:walker", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  store ptr %t174, ptr %l81, !tbaa !29
  %t175 = load i64, ptr %l1, !tbaa !24
  %t176 = load i64, ptr %l8, !tbaa !24
  %t177 = load ptr, ptr %l81, !tbaa !29
  %t178 = call ptr @__olang_scope_or(ptr %v1, ptr %t177)
  %t179 = call ptr @__olang_scope_hold(ptr %t178)
  %t180 = ptrtoint ptr %t179 to i64
  %t182 = inttoptr i64 %t180 to ptr
  %t183 = load ptr, ptr %l81, !tbaa !29
  %t186 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %t182, ptr %t183, i64 %t175, i64 %t176)
  store i1 %t186, ptr %l85
  br label %bb18
bb18:
  %t187 = load i1, ptr %l85, !tbaa !21
  %t188 = xor i1 %t187, true
  br i1 %t188, label %bb19, label %bb20
bb19:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/needs:walker", ptr %t190, i32 0, i32 4
  store ptr %t192, ptr %l88, !tbaa !29
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/needs:walker", ptr %t193, i32 0, i32 0
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  store ptr %t199, ptr %l91, !tbaa !29
  %t200 = load i64, ptr %l1, !tbaa !24
  %t201 = load i64, ptr %l8, !tbaa !24
  %t202 = load ptr, ptr %l91, !tbaa !29
  %t203 = call ptr @__olang_scope_or(ptr %v1, ptr %t202)
  %t204 = call ptr @__olang_scope_hold(ptr %t203)
  %t205 = ptrtoint ptr %t204 to i64
  %t207 = inttoptr i64 %t205 to ptr
  %t208 = load ptr, ptr %l91, !tbaa !29
  %t211 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %t207, ptr %t208, i64 %t200, i64 %t201)
  store %"compiler/generic:varRow" %t211, ptr %l95
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t212 = getelementptr %"compiler/generic:varRow", ptr %l95, i32 0, i32 1
  %t213 = load i32, ptr %t212, !tbaa !23
  %t214 = load i64, ptr %l8, !tbaa !24
  %t215 = load ptr, ptr %l88, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %t215, i32 %t213, i64 %t214)
  br label %bb22
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t218 = load i64, ptr %l7, !tbaa !24
  %t221 = add i64 %t218, 1
  store i64 %t221, ptr %l7, !tbaa !24
  br label %bb12
bb25:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/needs:walker", ptr %t223, i32 0, i32 4
  %t227 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H51b81a00fa8bf5fab3fd9fdb4d8e9d32(ptr %v0, ptr %t225)
  store i64 %t227, ptr %l103
  br label %bb26
bb26:
  %t228 = load i64, ptr %l103, !tbaa !24
  %t229 = icmp eq i64 %t228, 0
  br i1 %t229, label %bb27, label %bb28
bb27:
  br label %ret
bb28:
  br label %bb29
bb29:
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t233 = getelementptr %"compiler/ast:Func", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = icmp eq ptr %t234, null
  %t238 = xor i1 %t236, true
  br i1 %t238, label %bb30, label %bb31
bb30:
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l109, !tbaa !29
  %t241 = load ptr, ptr %l2, !tbaa !29
  %t243 = getelementptr %"compiler/ast:Func", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = icmp eq ptr %t244, null
  br i1 %t246, label %bb32, label %bb33
bb31:
  br label %bb39
bb32:
  call void @__olang_check_failed(ptr @olang_loc_7062293b76b04d1c_de3e9d47303f78c0)
  unreachable
bb33:
  br label %bb34
bb34:
  %t248 = load ptr, ptr %l2, !tbaa !29
  %t250 = getelementptr %"compiler/ast:Func", ptr %t248, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t254 = getelementptr %"compiler/ast:Param", ptr %t251, i32 0, i32 1
  %t255 = load i32, ptr %t254, !tbaa !23
  store i32 %t255, ptr %l116, !tbaa !23
  %t256 = load ptr, ptr %l2, !tbaa !29
  %t258 = getelementptr %"compiler/ast:Func", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t261 = icmp eq ptr %t259, null
  br i1 %t261, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_7062293b76b04d1c_de3e9d47303f78c0)
  unreachable
bb36:
  br label %bb37
bb37:
  %t263 = load ptr, ptr %l2, !tbaa !29
  %t265 = getelementptr %"compiler/ast:Func", ptr %t263, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t269 = getelementptr %"compiler/ast:Param", ptr %t266, i32 0, i32 2
  %t270 = load ptr, ptr %t269, !tbaa !29
  store ptr %t270, ptr %l123, !tbaa !29
  %t271 = load ptr, ptr %l123, !tbaa !29
  %t272 = call ptr @__olang_scope_or(ptr %v1, ptr %t271)
  %t273 = call ptr @__olang_scope_hold(ptr %t272)
  %t274 = ptrtoint ptr %t273 to i64
  %t276 = inttoptr i64 %t274 to ptr
  %t277 = load ptr, ptr %l109, !tbaa !29
  %t278 = load i32, ptr %l116, !tbaa !23
  %t279 = load ptr, ptr %l123, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eparam(ptr %v0, ptr %t276, ptr %v1, ptr %t277, i32 %t278, ptr %t279)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t280 = load ptr, ptr %l2, !tbaa !29
  %t282 = getelementptr %"compiler/ast:Func", ptr %t280, i32 0, i32 3
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t285 = getelementptr %"compiler/ast:Sig", ptr %t283, i32 0, i32 0
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  store i64 %t290, ptr %l11, !tbaa !24
  br label %bb40
bb40:
  %t292 = load i64, ptr %l10, !tbaa !24
  %t293 = load i64, ptr %l11, !tbaa !24
  %t296 = icmp slt i64 %t292, %t293
  %t298 = xor i1 %t296, true
  br i1 %t298, label %bb41, label %bb42
bb41:
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t300 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t300, ptr %l134, !tbaa !27
  %t301 = load i64, ptr %l10, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  store ptr %t306, ptr %l12, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l12, !tbaa !29
  %t311 = getelementptr %"compiler/ast:Param", ptr %t309, i32 0, i32 1
  %t312 = load i32, ptr %t311, !tbaa !23
  %t313 = load ptr, ptr %l12, !tbaa !29
  %t315 = getelementptr %"compiler/ast:Param", ptr %t313, i32 0, i32 2
  %t316 = load ptr, ptr %t315, !tbaa !29
  store ptr %t316, ptr %l141, !tbaa !29
  %t317 = load ptr, ptr %l141, !tbaa !29
  %t318 = call ptr @__olang_scope_or(ptr %v1, ptr %t317)
  %t319 = call ptr @__olang_scope_hold(ptr %t318)
  %t320 = ptrtoint ptr %t319 to i64
  %t322 = inttoptr i64 %t320 to ptr
  %t325 = load ptr, ptr %l141, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eparam(ptr %v0, ptr %t322, ptr %v1, ptr %t308, i32 %t312, ptr %t325)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t326 = load i64, ptr %l10, !tbaa !24
  %t329 = add i64 %t326, 1
  store i64 %t329, ptr %l10, !tbaa !24
  br label %bb40
bb46:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l2, !tbaa !29
  %t334 = getelementptr %"compiler/ast:Func", ptr %t332, i32 0, i32 4
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l148, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = call ptr @__olang_scope_or(ptr %v1, ptr %t337)
  %t339 = call ptr @__olang_scope_hold(ptr %t338)
  %t340 = ptrtoint ptr %t339 to i64
  %t342 = inttoptr i64 %t340 to ptr
  %t344 = load { i64, ptr }, ptr %l148, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %t342, ptr %v1, ptr %t331, { i64, ptr } %t344)
  br label %bb47
bb47:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l74 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l120 = alloca ptr
  %l121 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l183 = alloca ptr
  %l184 = alloca i1
  %l196 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l206 = alloca i1
  %l213 = alloca ptr
  %l214 = alloca i1
  %l226 = alloca ptr
  %l227 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i1
  %l255 = alloca ptr
  %l256 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t2 = load ptr, ptr %l31, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l31, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 22}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l32, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l32, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb13
bb4:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t17 = load ptr, ptr %l37, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load ptr, ptr %l37, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 22}
  %t23 = icmp eq i64 %t21, 15
  store i1 %t23, ptr %l38, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l38, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l2, !tbaa !29
  br label %bb13
bb8:
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t32 = load ptr, ptr %l43, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l43, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 22}
  %t38 = icmp eq i64 %t36, 21
  store i1 %t38, ptr %l44, !tbaa !21
  br label %bb10
bb10:
  %t39 = load i1, ptr %l44, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l1, !tbaa !29
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l2, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t46, ptr %t47)
  br label %bb14
bb14:
  br label %bb161
bb15:
  %t51 = load ptr, ptr %l1, !tbaa !29
  store ptr %t51, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t52 = load ptr, ptr %l52, !tbaa !29
  %t53 = icmp ne ptr %t52, null
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l52, !tbaa !29
  %t56 = load i64, ptr %t55, !range !{i64 0, i64 22}
  %t58 = icmp eq i64 %t56, 1
  store i1 %t58, ptr %l53, !tbaa !21
  br label %bb17
bb17:
  %t59 = load i1, ptr %l53, !tbaa !21
  br i1 %t59, label %bb18, label %bb19
bb18:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t60, i32 0, i32 1
  %t63 = getelementptr { %"compiler/source:Span", ptr }, ptr %t62, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  store ptr %t64, ptr %l3, !tbaa !29
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %t66, ptr %t67)
  br label %bb21
bb21:
  br label %bb161
bb22:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t71 = load ptr, ptr %l60, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l60, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 22}
  %t77 = icmp eq i64 %t75, 2
  store i1 %t77, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t78 = load i1, ptr %l61, !tbaa !21
  br i1 %t78, label %bb25, label %bb26
bb25:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l4, !tbaa !29
  br label %bb27
bb26:
  br label %bb35
bb27:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/ast:Multi", ptr %t85, i32 0, i32 2
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 0
  store i64 %t92, ptr %l7, !tbaa !24
  br label %bb28
bb28:
  %t94 = load i64, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb29, label %bb30
bb29:
  br label %bb34
bb30:
  br label %bb31
bb31:
  %t102 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t102, ptr %l74, !tbaa !27
  %t103 = load i64, ptr %l6, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr ptr, ptr %t106, i64 %t103
  %t108 = load ptr, ptr %t107, !tbaa !39
  %t110 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t110, ptr %t108)
  br label %bb32
bb32:
  br label %bb33
bb33:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = add i64 %t115, 1
  store i64 %t118, ptr %l6, !tbaa !24
  br label %bb28
bb34:
  br label %bb161
bb35:
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t121 = load ptr, ptr %l83, !tbaa !29
  %t122 = icmp ne ptr %t121, null
  br i1 %t122, label %bb36, label %bb37
bb36:
  %t124 = load ptr, ptr %l83, !tbaa !29
  %t125 = load i64, ptr %t124, !range !{i64 0, i64 22}
  %t127 = icmp eq i64 %t125, 3
  store i1 %t127, ptr %l84, !tbaa !21
  br label %bb37
bb37:
  %t128 = load i1, ptr %l84, !tbaa !21
  br i1 %t128, label %bb38, label %bb39
bb38:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t131, i32 0, i32 2
  %t133 = load ptr, ptr %t132
  store ptr %t133, ptr %l9, !tbaa !29
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t137, i32 0, i32 3
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l10, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load ptr, ptr %l9, !tbaa !29
  %t143 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eassign(ptr %v0, ptr %v1, ptr %v1, ptr %v2, ptr %t141, ptr %t142, ptr %t143)
  br label %bb41
bb41:
  br label %bb161
bb42:
  %t147 = load ptr, ptr %l1, !tbaa !29
  store ptr %t147, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t148 = load ptr, ptr %l94, !tbaa !29
  %t149 = icmp ne ptr %t148, null
  br i1 %t149, label %bb43, label %bb44
bb43:
  %t151 = load ptr, ptr %l94, !tbaa !29
  %t152 = load i64, ptr %t151, !range !{i64 0, i64 22}
  %t154 = icmp eq i64 %t152, 4
  store i1 %t154, ptr %l95, !tbaa !21
  br label %bb44
bb44:
  %t155 = load i1, ptr %l95, !tbaa !21
  br i1 %t155, label %bb45, label %bb46
bb45:
  %t156 = load ptr, ptr %l1, !tbaa !29
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t156, i32 0, i32 1
  %t159 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t158, i32 0, i32 1
  %t160 = load ptr, ptr %t159
  store ptr %t160, ptr %l11, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr { i64, [4 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t164, i32 0, i32 2
  %t166 = load { i64, ptr }, ptr %t165
  store { i64, ptr } %t166, ptr %l12, !tbaa !27
  br label %bb47
bb46:
  br label %bb50
bb47:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t168, ptr %t169)
  br label %bb48
bb48:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecatches(ptr %v0, ptr %v1, ptr %v2, ptr %t172, { i64, ptr } %t173)
  br label %bb49
bb49:
  br label %bb161
bb50:
  %t176 = load ptr, ptr %l1, !tbaa !29
  store ptr %t176, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t177 = load ptr, ptr %l106, !tbaa !29
  %t178 = icmp ne ptr %t177, null
  br i1 %t178, label %bb51, label %bb52
bb51:
  %t180 = load ptr, ptr %l106, !tbaa !29
  %t181 = load i64, ptr %t180, !range !{i64 0, i64 22}
  %t183 = icmp eq i64 %t181, 5
  store i1 %t183, ptr %l107, !tbaa !21
  br label %bb52
bb52:
  %t184 = load i1, ptr %l107, !tbaa !21
  br i1 %t184, label %bb53, label %bb54
bb53:
  %t185 = load ptr, ptr %l1, !tbaa !29
  %t187 = getelementptr { i64, [4 x i64] }, ptr %t185, i32 0, i32 1
  %t188 = getelementptr { %"compiler/source:Span", ptr }, ptr %t187, i32 0, i32 1
  %t189 = load ptr, ptr %t188
  store ptr %t189, ptr %l13, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eifStmt(ptr %v0, ptr %v1, ptr %v2, ptr %t191, ptr %t192)
  br label %bb56
bb56:
  br label %bb161
bb57:
  %t195 = load ptr, ptr %l1, !tbaa !29
  store ptr %t195, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t196 = load ptr, ptr %l114, !tbaa !29
  %t197 = icmp ne ptr %t196, null
  br i1 %t197, label %bb58, label %bb59
bb58:
  %t199 = load ptr, ptr %l114, !tbaa !29
  %t200 = load i64, ptr %t199, !range !{i64 0, i64 22}
  %t202 = icmp eq i64 %t200, 6
  store i1 %t202, ptr %l115, !tbaa !21
  br label %bb59
bb59:
  %t203 = load i1, ptr %l115, !tbaa !21
  br i1 %t203, label %bb60, label %bb61
bb60:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr { i64, [4 x i64] }, ptr %t204, i32 0, i32 1
  %t207 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t206, i32 0, i32 1
  %t208 = load { i64, ptr }, ptr %t207
  store { i64, ptr } %t208, ptr %l14, !tbaa !27
  br label %bb66
bb61:
  %t210 = load ptr, ptr %l1, !tbaa !29
  store ptr %t210, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t211 = load ptr, ptr %l120, !tbaa !29
  %t212 = icmp ne ptr %t211, null
  br i1 %t212, label %bb62, label %bb63
bb62:
  %t214 = load ptr, ptr %l120, !tbaa !29
  %t215 = load i64, ptr %t214, !range !{i64 0, i64 22}
  %t217 = icmp eq i64 %t215, 20
  store i1 %t217, ptr %l121, !tbaa !21
  br label %bb63
bb63:
  %t218 = load i1, ptr %l121, !tbaa !21
  br i1 %t218, label %bb64, label %bb65
bb64:
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t219, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t221, i32 0, i32 1
  %t223 = load { i64, ptr }, ptr %t222
  store { i64, ptr } %t223, ptr %l14, !tbaa !27
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %t225, { i64, ptr } %t226)
  br label %bb67
bb67:
  br label %bb161
bb68:
  %t229 = load ptr, ptr %l1, !tbaa !29
  store ptr %t229, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t230 = load ptr, ptr %l128, !tbaa !29
  %t231 = icmp ne ptr %t230, null
  br i1 %t231, label %bb69, label %bb70
bb69:
  %t233 = load ptr, ptr %l128, !tbaa !29
  %t234 = load i64, ptr %t233, !range !{i64 0, i64 22}
  %t236 = icmp eq i64 %t234, 7
  store i1 %t236, ptr %l129, !tbaa !21
  br label %bb70
bb70:
  %t237 = load i1, ptr %l129, !tbaa !21
  br i1 %t237, label %bb71, label %bb72
bb71:
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr { i64, [4 x i64] }, ptr %t238, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t240, i32 0, i32 1
  %t242 = load ptr, ptr %t241
  store ptr %t242, ptr %l15, !tbaa !29
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t246, i32 0, i32 2
  %t248 = load { i64, ptr }, ptr %t247
  store { i64, ptr } %t248, ptr %l16, !tbaa !27
  br label %bb77
bb72:
  %t250 = load ptr, ptr %l1, !tbaa !29
  store ptr %t250, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t251 = load ptr, ptr %l136, !tbaa !29
  %t252 = icmp ne ptr %t251, null
  br i1 %t252, label %bb73, label %bb74
bb73:
  %t254 = load ptr, ptr %l136, !tbaa !29
  %t255 = load i64, ptr %t254, !range !{i64 0, i64 22}
  %t257 = icmp eq i64 %t255, 10
  store i1 %t257, ptr %l137, !tbaa !21
  br label %bb74
bb74:
  %t258 = load i1, ptr %l137, !tbaa !21
  br i1 %t258, label %bb75, label %bb76
bb75:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t261 = getelementptr { i64, [4 x i64] }, ptr %t259, i32 0, i32 1
  %t262 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t261, i32 0, i32 1
  %t263 = load { i64, ptr }, ptr %t262
  store { i64, ptr } %t263, ptr %l16, !tbaa !27
  %t265 = load ptr, ptr %l1, !tbaa !29
  %t267 = getelementptr { i64, [4 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t267, i32 0, i32 2
  %t269 = load ptr, ptr %t268
  store ptr %t269, ptr %l15, !tbaa !29
  br label %bb77
bb76:
  br label %bb80
bb77:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t271, ptr %t272)
  br label %bb78
bb78:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %t276, { i64, ptr } %t277)
  br label %bb79
bb79:
  br label %bb161
bb80:
  %t280 = load ptr, ptr %l1, !tbaa !29
  store ptr %t280, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t281 = load ptr, ptr %l149, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb81, label %bb82
bb81:
  %t284 = load ptr, ptr %l149, !tbaa !29
  %t285 = load i64, ptr %t284, !range !{i64 0, i64 22}
  %t287 = icmp eq i64 %t285, 8
  store i1 %t287, ptr %l150, !tbaa !21
  br label %bb82
bb82:
  %t288 = load i1, ptr %l150, !tbaa !21
  br i1 %t288, label %bb83, label %bb84
bb83:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr { i64, [4 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", ptr }, ptr %t291, i32 0, i32 1
  %t293 = load ptr, ptr %t292
  store ptr %t293, ptr %l17, !tbaa !29
  br label %bb85
bb84:
  br label %bb90
bb85:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l17, !tbaa !29
  %t298 = getelementptr %"compiler/ast:For3", ptr %t296, i32 0, i32 0
  %t299 = load ptr, ptr %t298, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t295, ptr %t299)
  br label %bb86
bb86:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l17, !tbaa !29
  %t305 = getelementptr %"compiler/ast:For3", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t302, ptr %t306)
  br label %bb87
bb87:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l17, !tbaa !29
  %t312 = getelementptr %"compiler/ast:For3", ptr %t310, i32 0, i32 2
  %t313 = load ptr, ptr %t312, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t309, ptr %t313)
  br label %bb88
bb88:
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l17, !tbaa !29
  %t319 = getelementptr %"compiler/ast:For3", ptr %t317, i32 0, i32 3
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %t316, { i64, ptr } %t320)
  br label %bb89
bb89:
  br label %bb161
bb90:
  %t323 = load ptr, ptr %l1, !tbaa !29
  store ptr %t323, ptr %l167, !tbaa !29
  store i1 false, ptr %l168, !tbaa !21
  %t324 = load ptr, ptr %l167, !tbaa !29
  %t325 = icmp ne ptr %t324, null
  br i1 %t325, label %bb91, label %bb92
bb91:
  %t327 = load ptr, ptr %l167, !tbaa !29
  %t328 = load i64, ptr %t327, !range !{i64 0, i64 22}
  %t330 = icmp eq i64 %t328, 9
  store i1 %t330, ptr %l168, !tbaa !21
  br label %bb92
bb92:
  %t331 = load i1, ptr %l168, !tbaa !21
  br i1 %t331, label %bb93, label %bb94
bb93:
  %t332 = load ptr, ptr %l1, !tbaa !29
  %t334 = getelementptr { i64, [4 x i64] }, ptr %t332, i32 0, i32 1
  %t335 = getelementptr { %"compiler/source:Span", ptr }, ptr %t334, i32 0, i32 1
  %t336 = load ptr, ptr %t335
  store ptr %t336, ptr %l18, !tbaa !29
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l18, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eforIn(ptr %v0, ptr %v1, ptr %v2, ptr %t338, ptr %t339)
  br label %bb96
bb96:
  br label %bb161
bb97:
  %t342 = load ptr, ptr %l1, !tbaa !29
  store ptr %t342, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t343 = load ptr, ptr %l175, !tbaa !29
  %t344 = icmp ne ptr %t343, null
  br i1 %t344, label %bb98, label %bb99
bb98:
  %t346 = load ptr, ptr %l175, !tbaa !29
  %t347 = load i64, ptr %t346, !range !{i64 0, i64 22}
  %t349 = icmp eq i64 %t347, 11
  store i1 %t349, ptr %l176, !tbaa !21
  br label %bb99
bb99:
  %t350 = load i1, ptr %l176, !tbaa !21
  br i1 %t350, label %bb100, label %bb101
bb100:
  %t351 = load ptr, ptr %l1, !tbaa !29
  %t353 = getelementptr { i64, [4 x i64] }, ptr %t351, i32 0, i32 1
  %t354 = getelementptr { %"compiler/source:Span", ptr }, ptr %t353, i32 0, i32 1
  %t355 = load ptr, ptr %t354
  store ptr %t355, ptr %l19, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %t357, ptr %t358)
  br label %bb103
bb103:
  br label %bb161
bb104:
  %t361 = load ptr, ptr %l1, !tbaa !29
  store ptr %t361, ptr %l183, !tbaa !29
  store i1 false, ptr %l184, !tbaa !21
  %t362 = load ptr, ptr %l183, !tbaa !29
  %t363 = icmp ne ptr %t362, null
  br i1 %t363, label %bb105, label %bb106
bb105:
  %t365 = load ptr, ptr %l183, !tbaa !29
  %t366 = load i64, ptr %t365, !range !{i64 0, i64 22}
  %t368 = icmp eq i64 %t366, 12
  store i1 %t368, ptr %l184, !tbaa !21
  br label %bb106
bb106:
  %t369 = load i1, ptr %l184, !tbaa !21
  br i1 %t369, label %bb107, label %bb108
bb107:
  %t370 = load ptr, ptr %l1, !tbaa !29
  %t372 = getelementptr { i64, [4 x i64] }, ptr %t370, i32 0, i32 1
  %t373 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t372, i32 0, i32 1
  %t374 = load { i64, ptr }, ptr %t373
  store { i64, ptr } %t374, ptr %l20, !tbaa !27
  br label %bb109
bb108:
  br label %bb117
bb109:
  %t376 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t376, ptr %l21, !tbaa !27
  store i64 0, ptr %l22, !tbaa !24
  %t378 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t378, 0
  store i64 %t380, ptr %l23, !tbaa !24
  br label %bb110
bb110:
  %t382 = load i64, ptr %l22, !tbaa !24
  %t383 = load i64, ptr %l23, !tbaa !24
  %t386 = icmp slt i64 %t382, %t383
  %t388 = xor i1 %t386, true
  br i1 %t388, label %bb111, label %bb112
bb111:
  br label %bb116
bb112:
  br label %bb113
bb113:
  %t390 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t390, ptr %l196, !tbaa !27
  %t391 = load i64, ptr %l22, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr ptr, ptr %t394, i64 %t391
  %t396 = load ptr, ptr %t395, !tbaa !39
  %t398 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t398, ptr %t396)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t403 = load i64, ptr %l22, !tbaa !24
  %t406 = add i64 %t403, 1
  store i64 %t406, ptr %l22, !tbaa !24
  br label %bb110
bb116:
  br label %bb161
bb117:
  %t408 = load ptr, ptr %l1, !tbaa !29
  store ptr %t408, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t409 = load ptr, ptr %l205, !tbaa !29
  %t410 = icmp ne ptr %t409, null
  br i1 %t410, label %bb118, label %bb119
bb118:
  %t412 = load ptr, ptr %l205, !tbaa !29
  %t413 = load i64, ptr %t412, !range !{i64 0, i64 22}
  %t415 = icmp eq i64 %t413, 13
  store i1 %t415, ptr %l206, !tbaa !21
  br label %bb119
bb119:
  %t416 = load i1, ptr %l206, !tbaa !21
  br i1 %t416, label %bb120, label %bb121
bb120:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 1
  %t420 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t419, i32 0, i32 2
  %t421 = load ptr, ptr %t420
  store ptr %t421, ptr %l25, !tbaa !29
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load ptr, ptr %l25, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t423, ptr %t424)
  br label %bb123
bb123:
  br label %bb161
bb124:
  %t427 = load ptr, ptr %l1, !tbaa !29
  store ptr %t427, ptr %l213, !tbaa !29
  store i1 false, ptr %l214, !tbaa !21
  %t428 = load ptr, ptr %l213, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb125, label %bb126
bb125:
  %t431 = load ptr, ptr %l213, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 22}
  %t434 = icmp eq i64 %t432, 14
  store i1 %t434, ptr %l214, !tbaa !21
  br label %bb126
bb126:
  %t435 = load i1, ptr %l214, !tbaa !21
  br i1 %t435, label %bb127, label %bb128
bb127:
  %t436 = load ptr, ptr %l1, !tbaa !29
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t438, i32 0, i32 1
  %t440 = load ptr, ptr %t439
  store ptr %t440, ptr %l26, !tbaa !29
  %t442 = load ptr, ptr %l1, !tbaa !29
  %t444 = getelementptr { i64, [4 x i64] }, ptr %t442, i32 0, i32 1
  %t445 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t444, i32 0, i32 2
  %t446 = load ptr, ptr %t445
  store ptr %t446, ptr %l27, !tbaa !29
  br label %bb129
bb128:
  br label %bb132
bb129:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t448, ptr %t449)
  br label %bb130
bb130:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t454 = load ptr, ptr %l27, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t453, ptr %t454)
  br label %bb131
bb131:
  br label %bb161
bb132:
  %t457 = load ptr, ptr %l1, !tbaa !29
  store ptr %t457, ptr %l226, !tbaa !29
  store i1 false, ptr %l227, !tbaa !21
  %t458 = load ptr, ptr %l226, !tbaa !29
  %t459 = icmp ne ptr %t458, null
  br i1 %t459, label %bb133, label %bb134
bb133:
  %t461 = load ptr, ptr %l226, !tbaa !29
  %t462 = load i64, ptr %t461, !range !{i64 0, i64 22}
  %t464 = icmp eq i64 %t462, 17
  store i1 %t464, ptr %l227, !tbaa !21
  br label %bb134
bb134:
  %t465 = load i1, ptr %l227, !tbaa !21
  br i1 %t465, label %bb135, label %bb136
bb135:
  %t466 = load ptr, ptr %l1, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t468, i32 0, i32 2
  %t470 = load ptr, ptr %t469
  store ptr %t470, ptr %l28, !tbaa !29
  br label %bb137
bb136:
  br label %bb139
bb137:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load ptr, ptr %l28, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t472, ptr %t473)
  br label %bb138
bb138:
  br label %bb161
bb139:
  %t477 = load ptr, ptr %l1, !tbaa !29
  store ptr %t477, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t478 = load ptr, ptr %l235, !tbaa !29
  %t479 = icmp ne ptr %t478, null
  br i1 %t479, label %bb140, label %bb141
bb140:
  %t481 = load ptr, ptr %l235, !tbaa !29
  %t482 = load i64, ptr %t481, !range !{i64 0, i64 22}
  %t484 = icmp eq i64 %t482, 18
  store i1 %t484, ptr %l236, !tbaa !21
  br label %bb141
bb141:
  %t485 = load i1, ptr %l236, !tbaa !21
  br i1 %t485, label %bb142, label %bb143
bb142:
  %t486 = load ptr, ptr %l1, !tbaa !29
  %t488 = getelementptr { i64, [4 x i64] }, ptr %t486, i32 0, i32 1
  %t489 = getelementptr { %"compiler/source:Span", ptr }, ptr %t488, i32 0, i32 1
  %t490 = load ptr, ptr %t489
  store ptr %t490, ptr %l29, !tbaa !29
  br label %bb144
bb143:
  br label %bb147
bb144:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l29, !tbaa !29
  %t495 = getelementptr %"compiler/ast:JoinS", ptr %t493, i32 0, i32 1
  %t496 = load { i64, ptr }, ptr %t495, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %t492, { i64, ptr } %t496)
  br label %bb145
bb145:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load ptr, ptr %l29, !tbaa !29
  %t502 = getelementptr %"compiler/ast:JoinS", ptr %t500, i32 0, i32 2
  %t503 = load { i64, ptr }, ptr %t502, !tbaa !27
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecatches(ptr %v0, ptr %v1, ptr %v2, ptr %t499, { i64, ptr } %t503)
  br label %bb146
bb146:
  br label %bb161
bb147:
  %t506 = load ptr, ptr %l1, !tbaa !29
  store ptr %t506, ptr %l247, !tbaa !29
  store i1 false, ptr %l248, !tbaa !21
  %t507 = load ptr, ptr %l247, !tbaa !29
  %t508 = icmp ne ptr %t507, null
  br i1 %t508, label %bb148, label %bb149
bb148:
  %t510 = load ptr, ptr %l247, !tbaa !29
  %t511 = load i64, ptr %t510, !range !{i64 0, i64 22}
  %t513 = icmp eq i64 %t511, 19
  store i1 %t513, ptr %l248, !tbaa !21
  br label %bb149
bb149:
  %t514 = load i1, ptr %l248, !tbaa !21
  br i1 %t514, label %bb150, label %bb151
bb150:
  %t515 = load ptr, ptr %l1, !tbaa !29
  %t517 = getelementptr { i64, [4 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { %"compiler/source:Span", ptr, i1 }, ptr %t517, i32 0, i32 1
  %t519 = load ptr, ptr %t518
  store ptr %t519, ptr %l30, !tbaa !29
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load ptr, ptr %l30, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %t521, ptr %t522)
  br label %bb153
bb153:
  br label %bb161
bb154:
  %t525 = load ptr, ptr %l1, !tbaa !29
  store ptr %t525, ptr %l255, !tbaa !29
  store i1 false, ptr %l256, !tbaa !21
  %t526 = load ptr, ptr %l255, !tbaa !29
  %t527 = icmp ne ptr %t526, null
  br i1 %t527, label %bb155, label %bb156
bb155:
  %t529 = load ptr, ptr %l255, !tbaa !29
  %t530 = load i64, ptr %t529, !range !{i64 0, i64 22}
  %t532 = icmp eq i64 %t530, 16
  store i1 %t532, ptr %l256, !tbaa !21
  br label %bb156
bb156:
  %t533 = load i1, ptr %l256, !tbaa !21
  br i1 %t533, label %bb157, label %bb158
bb157:
  br label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  call void @__olang_check_failed(ptr @olang_loc_d978440131377666_280c73c325bb4b5a)
  unreachable
bb161:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i1
  %l28 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca i64
  %l35 = alloca i64
  %l39 = alloca ptr
  %l45 = alloca ptr
  %l54 = alloca i64
  %l57 = alloca i64
  %l76 = alloca { i64, ptr }
  %l80 = alloca i64
  %l83 = alloca i1
  %l89 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca i64
  %l104 = alloca i64
  %l109 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/needs:walker", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sge i64 %t4, 3
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecalled(ptr %v0, ptr %v1, ptr %v3, ptr %t8, ptr %a1)
  store i64 %t12, ptr %l20
  br label %bb4
bb4:
  %t13 = load i64, ptr %l20, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp slt i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/needs:walker", ptr %t19, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  %t25 = icmp eq i64 %t18, %t22
  store i1 %t25, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l23, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/needs:walker", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l31, !tbaa !29
  %t35 = load i64, ptr %l3, !tbaa !24
  %t37 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t35)
  store i64 %t37, ptr %l33
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l31, !tbaa !29
  %t39 = call ptr @__olang_scope_or(ptr %v3, ptr %t38)
  %t40 = call ptr @__olang_scope_hold(ptr %t39)
  %t41 = ptrtoint ptr %t40 to i64
  %t43 = inttoptr i64 %t41 to ptr
  %t44 = load ptr, ptr %l31, !tbaa !29
  %t45 = load i64, ptr %l33, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %t43, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l35
  br label %bb11
bb11:
  %t47 = load i64, ptr %l35, !tbaa !24
  %t48 = icmp eq i64 %t47, 0
  store i1 %t48, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  br label %ret
bb14:
  br label %bb15
bb15:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/needs:walker", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l39, !tbaa !29
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load ptr, ptr %l39, !tbaa !29
  %t60 = call ptr @__olang_scope_or(ptr %v3, ptr %t59)
  %t61 = call ptr @__olang_scope_hold(ptr %t60)
  %t62 = ptrtoint ptr %t61 to i64
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/needs:walker", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call ptr @__olang_scope_or(ptr %v3, ptr %t66)
  %t69 = call ptr @__olang_scope_hold(ptr %t68)
  %t70 = ptrtoint ptr %t69 to i64
  %t72 = inttoptr i64 %t62 to ptr
  %t74 = inttoptr i64 %t70 to ptr
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t77 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %t72, ptr %t74, ptr %t75, i64 %t58)
  store ptr %t77, ptr %l45
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l45, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Func", ptr %t78, i32 0, i32 3
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/ast:Sig", ptr %t81, i32 0, i32 0
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  store i64 %t88, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = icmp sgt i64 %t90, %t91
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp sgt i64 %t96, 0
  br i1 %t98, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb22
bb19:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t101 = load i64, ptr %l5, !tbaa !24
  %t104 = sub i64 %t100, %t101
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = add i64 %t104, %t105
  %t110 = sub i64 %t108, 1
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = sdiv i64 %t110, %t111
  store i64 %t114, ptr %l57, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb21
bb21:
  %t116 = load i64, ptr %l57, !tbaa !24
  store i64 %t116, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t117 = load i64, ptr %l54, !tbaa !24
  store i64 %t117, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t118 = load i64, ptr %l9, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  %t122 = icmp slt i64 %t118, %t119
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb24, label %bb25
bb24:
  br label %bb45
bb25:
  br label %bb26
bb26:
  %t126 = load i64, ptr %l5, !tbaa !24
  %t127 = load i64, ptr %l9, !tbaa !24
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = mul i64 %t127, %t128
  %t134 = add i64 %t126, %t131
  store i64 %t134, ptr %l10, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t137, ptr %l76, !tbaa !27
  %t138 = load i64, ptr %l10, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  %t147 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v2, ptr %t136, ptr %t143)
  store i64 %t147, ptr %l80
  br label %bb27
bb27:
  %t148 = load i64, ptr %l80, !tbaa !24
  store i64 %t148, ptr %l11, !tbaa !24
  %t149 = load i64, ptr %l11, !tbaa !24
  %t151 = icmp slt i64 %t149, 0
  br i1 %t151, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb30
bb29:
  %t153 = load i64, ptr %l10, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t159 = icmp sge i64 %t153, %t156
  store i1 %t159, ptr %l83, !tbaa !21
  br label %bb30
bb30:
  %t161 = load i1, ptr %l83, !tbaa !21
  br i1 %t161, label %bb31, label %bb32
bb31:
  br label %bb44
bb32:
  br label %bb33
bb33:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/needs:walker", ptr %t162, i32 0, i32 0
  %t165 = load ptr, ptr %t164, !tbaa !29
  store ptr %t165, ptr %l89, !tbaa !29
  %t166 = load i64, ptr %l3, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t167, ptr %l91, !tbaa !27
  %t168 = load i64, ptr %l10, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr ptr, ptr %t171, i64 %t168
  %t173 = load ptr, ptr %t172, !tbaa !39
  %t175 = getelementptr %"compiler/ast:Param", ptr %t173, i32 0, i32 2
  %t176 = load ptr, ptr %t175, !tbaa !29
  store ptr %t176, ptr %l94, !tbaa !29
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/needs:walker", ptr %t177, i32 0, i32 2
  %t180 = load i64, ptr %t179, !tbaa !24
  %t182 = add i64 %t180, 1
  %t183 = load ptr, ptr %l89, !tbaa !29
  %t184 = call ptr @__olang_scope_or(ptr %v3, ptr %t183)
  %t185 = call ptr @__olang_scope_hold(ptr %t184)
  %t186 = ptrtoint ptr %t185 to i64
  %t187 = load ptr, ptr %l94, !tbaa !29
  %t188 = call ptr @__olang_scope_or(ptr %v3, ptr %t187)
  %t189 = call ptr @__olang_scope_hold(ptr %t188)
  %t190 = ptrtoint ptr %t189 to i64
  %t192 = inttoptr i64 %t186 to ptr
  %t194 = inttoptr i64 %t190 to ptr
  %t195 = load ptr, ptr %l89, !tbaa !29
  %t197 = load ptr, ptr %l94, !tbaa !29
  %t199 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fneeds_2einnerNeeds(ptr %t192, ptr %t194, ptr %v0, ptr %t195, i64 %t166, ptr %t197, i64 %t182)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t199, ptr %l100
  br label %bb34
bb34:
  %t200 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t200, ptr %t201
  store ptr %t201, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb35
bb35:
  %t203 = load i64, ptr %l13, !tbaa !24
  store i64 %t203, ptr %l102, !tbaa !24
  %t204 = load ptr, ptr %l12, !tbaa !29
  %t206 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t204)
  store i64 %t206, ptr %l104
  br label %bb36
bb36:
  %t207 = load i64, ptr %l102, !tbaa !24
  %t208 = load i64, ptr %l104, !tbaa !24
  %t209 = icmp slt i64 %t207, %t208
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb37, label %bb38
bb37:
  br label %bb43
bb38:
  br label %bb39
bb39:
  %t213 = load ptr, ptr %l12, !tbaa !29
  %t214 = load i64, ptr %l13, !tbaa !24
  %t217 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t213, i64 %t214)
  store { i64, ptr } %t217, ptr %l109
  br label %bb40
bb40:
  %t218 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v0, ptr %t219, i64 %t220, { i64, ptr } %t218)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t225 = load i64, ptr %l13, !tbaa !24
  %t228 = add i64 %t225, 1
  store i64 %t228, ptr %l13, !tbaa !24
  br label %bb35
bb43:
  br label %bb44
bb44:
  %t230 = load i64, ptr %l9, !tbaa !24
  %t233 = add i64 %t230, 1
  store i64 %t233, ptr %l9, !tbaa !24
  br label %bb23
bb45:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2etraitMethods(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l16 = alloca i32
  %l22 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i32
  %l34 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i1
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i64
  %l65 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i64
  %l79 = alloca ptr
  %l83 = alloca { i64, ptr }
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/needs:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t11 = load ptr, ptr %l13, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v2, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t16, ptr %t17, i32 %t10)
  store i32 %t19, ptr %l16
  br label %bb1
bb1:
  %t20 = load i32, ptr %l16, !range !{i32 0, i32 33}
  %t22 = trunc i64 18 to i32
  %t23 = icmp eq i32 %t20, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/needs:walker", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  store ptr %t33, ptr %l22, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/needs:walker", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t44 = load ptr, ptr %l26, !tbaa !29
  %t45 = call ptr @__olang_scope_or(ptr %v2, ptr %t44)
  %t46 = call ptr @__olang_scope_hold(ptr %t45)
  %t47 = ptrtoint ptr %t46 to i64
  %t49 = inttoptr i64 %t47 to ptr
  %t50 = load ptr, ptr %l26, !tbaa !29
  %t52 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t49, ptr %t50, i32 %t43)
  store i32 %t52, ptr %l29
  br label %bb5
bb5:
  %t53 = load ptr, ptr %l22, !tbaa !29
  %t54 = call ptr @__olang_scope_or(ptr %v2, ptr %t53)
  %t55 = call ptr @__olang_scope_hold(ptr %t54)
  %t56 = ptrtoint ptr %t55 to i64
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/needs:walker", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = call ptr @__olang_scope_or(ptr %v2, ptr %t60)
  %t63 = call ptr @__olang_scope_hold(ptr %t62)
  %t64 = ptrtoint ptr %t63 to i64
  %t66 = inttoptr i64 %t56 to ptr
  %t68 = inttoptr i64 %t64 to ptr
  %t69 = load ptr, ptr %l22, !tbaa !29
  %t70 = load i32, ptr %l29, !tbaa !23
  %t71 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %t66, ptr %t68, ptr %t69, i32 %t70)
  store ptr %t71, ptr %l34
  br label %bb6
bb6:
  %t72 = load ptr, ptr %l34, !tbaa !29
  store ptr %t72, ptr %l3, !tbaa !29
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = getelementptr %"compiler/ast:TypeDecl", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  store ptr %t80, ptr %l4, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  store ptr %t82, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t83 = load ptr, ptr %l39, !tbaa !29
  %t84 = icmp ne ptr %t83, null
  br i1 %t84, label %bb10, label %bb11
bb10:
  %t86 = load ptr, ptr %l39, !tbaa !29
  %t87 = load i64, ptr %t86, !range !{i64 0, i64 5}
  %t89 = icmp eq i64 %t87, 2
  store i1 %t89, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t90 = load i1, ptr %l40, !tbaa !21
  br i1 %t90, label %bb12, label %bb13
bb12:
  %t91 = load ptr, ptr %l4, !tbaa !29
  %t93 = getelementptr { i64, [6 x i64] }, ptr %t91, i32 0, i32 1
  %t94 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t93, i32 0, i32 0
  %t95 = load { i64, ptr }, ptr %t94
  store { i64, ptr } %t95, ptr %l5, !tbaa !27
  br label %bb14
bb13:
  br label %bb33
bb14:
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t99, 0
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l8, !tbaa !24
  %t107 = icmp slt i64 %t103, %t104
  %t109 = xor i1 %t107, true
  br i1 %t109, label %bb16, label %bb17
bb16:
  br label %bb32
bb17:
  br label %bb18
bb18:
  %t111 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t111, ptr %l52, !tbaa !27
  %t112 = load i64, ptr %l7, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  store ptr %t117, ptr %l9, !tbaa !29
  %t119 = load ptr, ptr %l9, !tbaa !29
  store ptr %t119, ptr %l55, !tbaa !29
  %t120 = load ptr, ptr %l55, !tbaa !29
  %t121 = call ptr @__olang_scope_or(ptr %v2, ptr %t120)
  %t122 = call ptr @__olang_scope_hold(ptr %t121)
  %t123 = ptrtoint ptr %t122 to i64
  %t125 = inttoptr i64 %t123 to ptr
  %t126 = load ptr, ptr %l55, !tbaa !29
  %t127 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %t125, ptr %t126)
  store i1 %t127, ptr %l57
  br label %bb19
bb19:
  %t128 = load i1, ptr %l57, !tbaa !21
  br i1 %t128, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load ptr, ptr %l2, !tbaa !29
  store ptr %t129, ptr %l58, !tbaa !29
  %t130 = call ptr @__olang_scope_hold(ptr %v1)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l59, !tbaa !24
  %t132 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t132, label %bb22, label %bb23
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t134 = load ptr, ptr %l2, !tbaa !29
  store ptr %t134, ptr %l72, !tbaa !29
  %t135 = call ptr @__olang_scope_hold(ptr %v1)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l73, !tbaa !24
  %t137 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t137, label %bb26, label %bb27
bb22:
  %t139 = call ptr @__olang_region_make(ptr %v1)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l59, !tbaa !24
  br label %bb23
bb23:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/needs:walker", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 0
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/load:Loader", ptr %t150, i32 0, i32 3
  %t153 = load ptr, ptr %t152, !tbaa !29
  store ptr %t153, ptr %l65, !tbaa !29
  %t154 = load ptr, ptr %l9, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Func", ptr %t154, i32 0, i32 9
  %t157 = load i32, ptr %t156, !tbaa !23
  %t158 = load ptr, ptr %l65, !tbaa !29
  %t159 = call ptr @__olang_scope_or(ptr %v2, ptr %t158)
  %t160 = call ptr @__olang_scope_hold(ptr %t159)
  %t161 = ptrtoint ptr %t160 to i64
  %t163 = inttoptr i64 %t161 to ptr
  %t164 = load ptr, ptr %l65, !tbaa !29
  %t166 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t163, ptr %s6, ptr %t164, i32 %t157)
  store { i64, ptr } %t166, ptr %l69
  br label %bb24
bb24:
  %t167 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = load i64, ptr %l59
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = call ptr @__olang_held_alloc(ptr %t174, i64 %t172)
  call void @olang_textcopy(ptr %t175, ptr %t168, i64 %t169)
  %t176 = getelementptr i8, ptr %t175, i64 %t169
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t180, { i64, ptr } %t178)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb26:
  %t182 = call ptr @__olang_region_make(ptr %v1)
  %t183 = ptrtoint ptr %t182 to i64
  store i64 %t183, ptr %l73, !tbaa !24
  br label %bb27
bb27:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/needs:walker", ptr %t184, i32 0, i32 0
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/generic:Program", ptr %t190, i32 0, i32 0
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = getelementptr %"compiler/load:Loader", ptr %t193, i32 0, i32 3
  %t196 = load ptr, ptr %t195, !tbaa !29
  store ptr %t196, ptr %l79, !tbaa !29
  %t197 = load ptr, ptr %l9, !tbaa !29
  %t199 = getelementptr %"compiler/ast:Func", ptr %t197, i32 0, i32 2
  %t200 = load i32, ptr %t199, !tbaa !23
  %t201 = load ptr, ptr %l79, !tbaa !29
  %t202 = call ptr @__olang_scope_or(ptr %v2, ptr %t201)
  %t203 = call ptr @__olang_scope_hold(ptr %t202)
  %t204 = ptrtoint ptr %t203 to i64
  %t206 = inttoptr i64 %t204 to ptr
  %t207 = load ptr, ptr %l79, !tbaa !29
  %t209 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t206, ptr %s8, ptr %t207, i32 %t200)
  store { i64, ptr } %t209, ptr %l83
  br label %bb28
bb28:
  %t210 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = load i64, ptr %l73
  %t214 = inttoptr i64 %t213 to ptr
  %t215 = call ptr @__olang_held_alloc(ptr %t214, i64 %t212)
  call void @olang_textcopy(ptr %t215, ptr %t211, i64 %t212)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t219 = load ptr, ptr %l72, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t219, { i64, ptr } %t217)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t221 = load i64, ptr %l7, !tbaa !24
  %t224 = add i64 %t221, 1
  store i64 %t224, ptr %l7, !tbaa !24
  br label %bb15
bb32:
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_cca6d9a3ad2d5c7a_8d3fd43a7368455e)
  unreachable
bb38:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eunpromised(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/generic:varRow"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l18 = alloca i64
  %l21 = alloca %"compiler/generic:varRow"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l48 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca { i64, ptr }
  %l69 = alloca i1
  %l70 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/needs:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/check:Checker", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l15, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/needs:walker", ptr %t8, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t11)
  store i64 %t13, ptr %l18
  br label %bb1
bb1:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load ptr, ptr %l15, !tbaa !29
  %t16 = call ptr @__olang_scope_or(ptr %v2, ptr %t15)
  %t17 = call ptr @__olang_scope_hold(ptr %t16)
  %t18 = ptrtoint ptr %t17 to i64
  %t20 = inttoptr i64 %t18 to ptr
  %t21 = load ptr, ptr %l15, !tbaa !29
  %t22 = load i64, ptr %l18, !tbaa !24
  %t24 = call %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %t20, ptr %t21, i64 %t22, i64 %t14)
  store %"compiler/generic:varRow" %t24, ptr %l21
  br label %bb2
bb2:
  %t25 = load %"compiler/generic:varRow", ptr %l21
  store %"compiler/generic:varRow" %t25, ptr %l2
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l22
  br label %bb3
bb3:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l3
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l23
  br label %bb4
bb4:
  %t29 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l4
  store i1 false, ptr %l5, !tbaa !21
  %t30 = getelementptr %"compiler/generic:varRow", ptr %l2, i32 0, i32 3
  %t31 = load i32, ptr %t30, !tbaa !23
  %t32 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t35 = icmp ne i32 %t31, %t32
  br i1 %t35, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/needs:walker", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  store ptr %t43, ptr %l29, !tbaa !29
  %t44 = getelementptr %"compiler/generic:varRow", ptr %l2, i32 0, i32 3
  %t45 = load i32, ptr %t44, !tbaa !23
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t47 = call ptr @__olang_scope_or(ptr %v2, ptr %t46)
  %t48 = call ptr @__olang_scope_hold(ptr %t47)
  %t49 = ptrtoint ptr %t48 to i64
  %t51 = inttoptr i64 %t49 to ptr
  %t52 = load ptr, ptr %l29, !tbaa !29
  %t54 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %t51, ptr %s2, ptr %t52, i32 %t45)
  store { i64, ptr } %t54, ptr %l32
  br label %bb7
bb6:
  br label %bb19
bb7:
  %t55 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t55, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  store i64 %t59, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb9, label %bb10
bb9:
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l40, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  store i32 %t75, ptr %l9, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/needs:walker", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l45, !tbaa !29
  %t84 = load i32, ptr %l9, !tbaa !23
  %t85 = load ptr, ptr %l45, !tbaa !29
  %t86 = call ptr @__olang_scope_or(ptr %v2, ptr %t85)
  %t87 = call ptr @__olang_scope_hold(ptr %t86)
  %t88 = ptrtoint ptr %t87 to i64
  %t90 = inttoptr i64 %t88 to ptr
  %t91 = load ptr, ptr %l45, !tbaa !29
  %t93 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %t90, ptr %t91, i32 %t84)
  store i1 %t93, ptr %l48
  br label %bb12
bb12:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i32, ptr %l9, !tbaa !23
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2etraitMethods(ptr %v0, ptr %s0, ptr %v2, ptr %t95, i32 %t96, ptr %l4)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = add i64 %t100, 1
  store i64 %t103, ptr %l7, !tbaa !24
  br label %bb8
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/needs:walker", ptr %t105, i32 0, i32 7
  %t108 = load i64, ptr %l1, !tbaa !24
  %t111 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H7b5f712395151d264e9eac052c719793(ptr %v0, ptr %v0, ptr %t107, i64 %t108)
  store ptr %t111, ptr %l58
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l58, !tbaa !29
  store ptr %t112, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb21
bb21:
  %t113 = load i64, ptr %l11, !tbaa !24
  store i64 %t113, ptr %l59, !tbaa !24
  %t114 = load ptr, ptr %l10, !tbaa !29
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l61
  br label %bb22
bb22:
  %t117 = load i64, ptr %l59, !tbaa !24
  %t118 = load i64, ptr %l61, !tbaa !24
  %t119 = icmp slt i64 %t117, %t118
  %t121 = xor i1 %t119, true
  br i1 %t121, label %bb23, label %bb24
bb23:
  br label %bb40
bb24:
  br label %bb25
bb25:
  %t123 = load ptr, ptr %l10, !tbaa !29
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t123, i64 %t124)
  store { i64, ptr } %t127, ptr %l66
  br label %bb26
bb26:
  %t128 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t128, ptr %l12, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t132 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %s0, ptr %v0, ptr %l4, { i64, ptr } %t129)
  store i1 %t132, ptr %l69
  br label %bb27
bb27:
  %t133 = load i1, ptr %l69, !tbaa !21
  br i1 %t133, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb34
bb29:
  %t134 = load i1, ptr %l5, !tbaa !21
  br i1 %t134, label %bb30, label %bb31
bb30:
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t138 = call i1 @compiler_2fneeds_2eopNeed(ptr %v0, { i64, ptr } %t136)
  store i1 %t138, ptr %l74
  br label %bb32
bb31:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb33
bb32:
  %t139 = load i1, ptr %l74, !tbaa !21
  store i1 %t139, ptr %l72, !tbaa !21
  br label %bb33
bb33:
  %t140 = load i1, ptr %l72, !tbaa !21
  store i1 %t140, ptr %l70, !tbaa !21
  br label %bb34
bb34:
  %t141 = load i1, ptr %l70, !tbaa !21
  br i1 %t141, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  br label %bb37
bb37:
  %t142 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v0, ptr %l3, { i64, ptr } %t142)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t145 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t145, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb21
bb40:
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fneeds_2einnerNeeds(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l13 = alloca %"compiler/needs:walker"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l26 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t4 = alloca %"compiler/needs:walker", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fneeds_3awalker_2ector(ptr %t4, ptr %v0, ptr %v2, ptr %a0, i64 %a1, i64 %a3)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t4, i64 280, i1 false)
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 280, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t8, ptr %l13, i64 280, i1 false)
  store ptr %t8, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2erun(ptr %v2, ptr %v0, ptr %t10)
  br label %bb2
bb2:
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l16
  br label %bb3
bb3:
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l5
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t18 = call i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evarOf(ptr %v2, ptr %v1, ptr %t14, ptr %a2)
  store i64 %t18, ptr %l19
  br label %bb4
bb4:
  %t19 = load i64, ptr %l19, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp slt i64 %t20, 0
  br i1 %t22, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb6:
  %t24 = load i64, ptr %l6, !tbaa !24
  store i64 %t24, ptr %l23, !tbaa !24
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/needs:walker", ptr %t25, i32 0, i32 7
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %v2, ptr %t27)
  store i64 %t29, ptr %l26
  br label %bb7
bb7:
  %t30 = load i64, ptr %l23, !tbaa !24
  %t31 = load i64, ptr %l26, !tbaa !24
  %t32 = icmp sge i64 %t30, %t31
  store i1 %t32, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = getelementptr %"compiler/needs:walker", ptr %t37, i32 0, i32 7
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H21d8db2bdfeb46fab755f8173a35f95e(ptr %v2, ptr %v2, ptr %t39, i64 %t40)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l32
  br label %bb12
bb12:
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v2, ptr %l32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l34
  br label %bb13
bb13:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t47 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t47
  store ptr %t47, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t49 = load i64, ptr %l8, !tbaa !24
  store i64 %t49, ptr %l36, !tbaa !24
  %t50 = load ptr, ptr %l7, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t50)
  store i64 %t52, ptr %l38
  br label %bb15
bb15:
  %t53 = load i64, ptr %l36, !tbaa !24
  %t54 = load i64, ptr %l38, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb16, label %bb17
bb16:
  br label %bb22
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l7, !tbaa !29
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t59, i64 %t60)
  store { i64, ptr } %t63, ptr %l43
  br label %bb19
bb19:
  %t64 = load { i64, ptr }, ptr %l43, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %l5, { i64, ptr } %t64)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = add i64 %t68, 1
  store i64 %t71, ptr %l8, !tbaa !24
  br label %bb14
bb22:
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2fneeds_2eopNeed(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca [12 x { i64, ptr }]
  %l18 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t1, !tbaa !37
  %t2 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %t2, !tbaa !37
  %t3 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 2
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %t3, !tbaa !37
  %t4 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 3
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t4, !tbaa !37
  %t5 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 4
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %t5, !tbaa !37
  %t6 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 5
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %t6, !tbaa !37
  %t7 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 6
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %t7, !tbaa !37
  %t8 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 7
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t8, !tbaa !37
  %t9 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 8
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t9, !tbaa !37
  %t10 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 9
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t10, !tbaa !37
  %t11 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 10
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t11, !tbaa !37
  %t12 = getelementptr [12 x { i64, ptr }], ptr %l5, i64 0, i64 11
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t12, !tbaa !37
  %t13 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 192, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %l5, i64 192, i1 false)
  store ptr %t13, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l1
  store i64 12, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l1
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr [12 x { i64, ptr }], ptr %t26, i64 0, i64 %t27
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !37
  %t35 = load ptr, ptr @__olang_prog_scope
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t35, { i64, ptr } %a0, { i64, ptr } %t31)
  store i1 %t38, ptr %l18
  br label %bb5
bb5:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t41, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fneeds_3awalker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l8 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca i64
  %l24 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l26 = alloca i64
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"compiler/needs:walker"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  store i64 %a2, ptr %l5, !tbaa !24
  store i64 -1, ptr %l6, !tbaa !24
  %t7 = call ptr @__olang_scope_hold(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e4
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = call ptr @__olang_region_make(ptr %v1)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l14, !tbaa !24
  br label %bb2
bb2:
  %t13 = load i64, ptr %l14
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t14)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t15, ptr %l16
  br label %bb3
bb3:
  %t16 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e4
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l14
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 2
  %t21 = load { i64, ptr }, ptr %t20
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = call ptr @__olang_region_or(ptr %t22, ptr null)
  %t24 = call ptr @__olang_region_home(ptr %t23)
  %t25 = icmp ne ptr %t24, null
  %t26 = select i1 %t25, ptr %t24, ptr null
  %t27 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27
  %t29 = extractvalue { i64, ptr } %t28, 1
  %t30 = call ptr @__olang_region_or(ptr %t29, ptr null)
  %t31 = call ptr @__olang_region_home(ptr %t30)
  %t32 = icmp ne ptr %t31, null
  %t33 = select i1 %t32, ptr %t31, ptr %t26
  %t34 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = call ptr @__olang_region_or(ptr %t36, ptr null)
  %t38 = call ptr @__olang_region_home(ptr %t37)
  %t39 = icmp ne ptr %t38, null
  %t40 = select i1 %t39, ptr %t38, ptr %t33
  call void @__olang_region_settle_in(ptr %t19, ptr %t40)
  br label %bb5
bb5:
  %t41 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t41, ptr %l7
  %t42 = call ptr @__olang_scope_hold(ptr %v1)
  %t43 = ptrtoint ptr %t42 to i64
  store i64 %t43, ptr %l18, !tbaa !24
  %t44 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e5
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = call ptr @__olang_region_make(ptr %v1)
  %t47 = ptrtoint ptr %t46 to i64
  store i64 %t47, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t48 = load i64, ptr %l18
  %t49 = inttoptr i64 %t48 to ptr
  %t50 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t49)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t50, ptr %l20
  br label %bb8
bb8:
  %t51 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e5
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = load i64, ptr %l18
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 2
  %t56 = load { i64, ptr }, ptr %t55
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = call ptr @__olang_region_or(ptr %t57, ptr null)
  %t59 = call ptr @__olang_region_home(ptr %t58)
  %t60 = icmp ne ptr %t59, null
  %t61 = select i1 %t60, ptr %t59, ptr null
  %t62 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62
  %t64 = extractvalue { i64, ptr } %t63, 1
  %t65 = call ptr @__olang_region_or(ptr %t64, ptr null)
  %t66 = call ptr @__olang_region_home(ptr %t65)
  %t67 = icmp ne ptr %t66, null
  %t68 = select i1 %t67, ptr %t66, ptr %t61
  %t69 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69
  %t71 = extractvalue { i64, ptr } %t70, 1
  %t72 = call ptr @__olang_region_or(ptr %t71, ptr null)
  %t73 = call ptr @__olang_region_home(ptr %t72)
  %t74 = icmp ne ptr %t73, null
  %t75 = select i1 %t74, ptr %t73, ptr %t68
  call void @__olang_region_settle_in(ptr %t54, ptr %t75)
  br label %bb10
bb10:
  %t76 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t76, ptr %l8
  %t77 = call ptr @__olang_scope_hold(ptr %v1)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l22, !tbaa !24
  %t79 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e6
  br i1 %t79, label %bb11, label %bb12
bb11:
  %t81 = call ptr @__olang_region_make(ptr %v1)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t83 = load i64, ptr %l22
  %t84 = inttoptr i64 %t83 to ptr
  %t85 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t84)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t85, ptr %l24
  br label %bb13
bb13:
  %t86 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e6
  br i1 %t86, label %bb14, label %bb15
bb14:
  %t88 = load i64, ptr %l22
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = call ptr @__olang_region_or(ptr %t92, ptr null)
  %t94 = call ptr @__olang_region_home(ptr %t93)
  %t95 = icmp ne ptr %t94, null
  %t96 = select i1 %t95, ptr %t94, ptr null
  %t97 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = call ptr @__olang_region_or(ptr %t99, ptr null)
  %t101 = call ptr @__olang_region_home(ptr %t100)
  %t102 = icmp ne ptr %t101, null
  %t103 = select i1 %t102, ptr %t101, ptr %t96
  %t104 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = call ptr @__olang_region_or(ptr %t106, ptr null)
  %t108 = call ptr @__olang_region_home(ptr %t107)
  %t109 = icmp ne ptr %t108, null
  %t110 = select i1 %t109, ptr %t108, ptr %t103
  call void @__olang_region_settle_in(ptr %t89, ptr %t110)
  br label %bb15
bb15:
  %t111 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l24
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t111, ptr %l9
  %t112 = call ptr @__olang_scope_hold(ptr %v1)
  %t113 = ptrtoint ptr %t112 to i64
  store i64 %t113, ptr %l26, !tbaa !24
  %t114 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e7
  br i1 %t114, label %bb16, label %bb17
bb16:
  %t116 = call ptr @__olang_region_make(ptr %v1)
  %t117 = ptrtoint ptr %t116 to i64
  store i64 %t117, ptr %l26, !tbaa !24
  br label %bb17
bb17:
  %t118 = load i64, ptr %l26
  %t119 = inttoptr i64 %t118 to ptr
  %t120 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %t119, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %l28
  br label %bb18
bb18:
  %t121 = load i1, ptr @olang_2esole_2ecompiler_2fneeds_3awalker_2e7
  br i1 %t121, label %bb19, label %bb20
bb19:
  %t123 = load i64, ptr %l26
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28, i32 0, i32 0
  %t126 = load { i64, ptr }, ptr %t125
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = call ptr @__olang_region_or(ptr %t127, ptr null)
  %t129 = call ptr @__olang_region_home(ptr %t128)
  %t130 = icmp ne ptr %t129, null
  %t131 = select i1 %t130, ptr %t129, ptr null
  call void @__olang_region_settle_in(ptr %t124, ptr %t131)
  br label %bb20
bb20:
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  %t133 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 0
  %t134 = load ptr, ptr %l3, !tbaa !29
  store ptr %t134, ptr %t133, !tbaa !29
  %t135 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 1
  %t136 = load i64, ptr %l4, !tbaa !24
  store i64 %t136, ptr %t135, !tbaa !24
  %t137 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 2
  %t138 = load i64, ptr %l5, !tbaa !24
  store i64 %t138, ptr %t137, !tbaa !24
  %t139 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 3
  %t140 = load i64, ptr %l6, !tbaa !24
  store i64 %t140, ptr %t139, !tbaa !24
  %t141 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 4
  %t142 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t142, ptr %t141
  %t143 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 5
  %t144 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t144, ptr %t143
  %t145 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 6
  %t146 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t146, ptr %t145
  %t147 = getelementptr %"compiler/needs:walker", ptr %l30, i32 0, i32 7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %t147
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 280, i1 false)
  br label %ret
ret:
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d1 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" needs: " }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d4 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Div" }>, align 8
@.d6 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Rem" }>, align 8
@.d7 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d8 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d11 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d12 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ShiftLeft" }>, align 8
@.d13 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ShiftRight" }>, align 8
@.d14 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d15 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"SetSlice" }>, align 8
@.d16 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d17 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
@.d19 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" (a builder)" }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
@.d21 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d24 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"a field '" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d29 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"a walk (Next, Iter, or At and Len)" }>, align 8
@.d30 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" (a builder)" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d33 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d34 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d35 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Div" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Rem" }>, align 8
@.d37 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d39 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d41 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ShiftLeft" }>, align 8
@.d42 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"ShiftRight" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@olang_2esole_2ecompiler_2fneeds_3awalker_2e4 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2fneeds_3awalker_2e5 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fneeds_3awalker_2e6 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fneeds_3awalker_2e7 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_Hbb0b9cf8ae0bb786ffc6cf28ae45ef64(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare %"compiler/generic:varRow" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_eb8dbdd343cc2ec5_7e04d3ec09c5f0b9 = external constant [0 x i8]
declare i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evalOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fast_2eSlicing(ptr %v0, { i64, ptr } %a0)
declare void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eneed(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_e9926bfe55a51c67_a6d583928ea9cdb3 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_Hf575c52a5a9e8993bae2b73c9c2548b3(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_585fa5a01a72b2ac_16d8ccfed8d78ee8 = external constant [0 x i8]
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_905d4a0f3532f957_2b4330c2b114d9a3 = external constant [0 x i8]
declare void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eparam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H862756c16d115e5c03a79726209f69fa(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2eelemsOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_21eaca0c6a8c7fc1_c6101a29af81bc15 = external constant [0 x i8]
declare void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2estmts(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ecatches(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_9c9e5b16a9737640_c9291bd1f0d77b3c = external constant [0 x i8]
@olang_loc_8cbabffa04a291df_a080b7e111f166ab = external constant [0 x i8]
declare void @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2ematchOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_9f3ed7f83038a02_b8cf4e04baa63c1e = external constant [0 x i8]
@olang_loc_fa47b13b1fa62ba2_f81ee9a5bb5727e6 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H40771be639b3022d183b79789a9eab56(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H51b81a00fa8bf5fab3fd9fdb4d8e9d32(ptr %v0, ptr %a0)
@olang_loc_7062293b76b04d1c_de3e9d47303f78c0 = external constant [0 x i8]
@olang_loc_d978440131377666_280c73c325bb4b5a = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
@olang_loc_cca6d9a3ad2d5c7a_8d3fd43a7368455e = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBoundTraits(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H7b5f712395151d264e9eac052c719793(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fneeds_2ecompiler_2fneeds_3awalker_2evarOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprel_H21d8db2bdfeb46fab755f8173a35f95e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
