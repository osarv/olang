; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
define dso_local void @std_2fprelude_2farray_2esortByPositions_3cstd_2fprelude_2ftext_3aString_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { ptr, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l26 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l57 = alloca i64
  %l60 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i1
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t170 = alloca { { ptr, ptr }, { i64, ptr }, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  store { ptr, ptr } %pg1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i64, ptr @G_2estd_2fprelude_2farray_2esortRun, !tbaa !24
  %t9 = icmp sle i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load { ptr, ptr }, ptr %l1
  %t17 = extractvalue { ptr, ptr } %t13, 0
  %t18 = extractvalue { ptr, ptr } %t13, 1
  call void @std_2fprelude_2farray_2esortInsertion_3cstd_2fprelude_2ftext_3aString_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t11, i64 0, i64 %t12, ptr %t17, ptr %t18)
  br label %bb3
bb2:
  br label %bb5
bb3:
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t25, ptr %l26, !tbaa !24
  br label %bb8
bb7:
  %t27 = load i64, ptr %l2, !tbaa !24
  store i64 %t27, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = icmp sge i64 %t29, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = icmp sle i64 %t32, 1152921504606846975
  br i1 %t33, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f5954356a94cfd1d_57c8a908dd11d469)
  unreachable
bb11:
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = mul i64 %t35, 8
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_f5954356a94cfd1d_57c8a908dd11d469)
  unreachable
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb15:
  br label %bb16
bb16:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  %t53 = add i64 %t49, %t50
  store i64 %t53, ptr %l5, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l2, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t61 = load i64, ptr %l2, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = sub i64 %t63, %t64
  store i64 %t67, ptr %l45, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l46, !tbaa !24
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = load i64, ptr %l45, !tbaa !24
  %t73 = icmp sle i64 0, %t72
  br i1 %t73, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_bd57bfee552aaf80_4db8901b79077054)
  unreachable
bb22:
  %t75 = load i64, ptr %l45, !tbaa !24
  %t76 = load i64, ptr %l46, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  br i1 %t77, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_bd57bfee552aaf80_4db8901b79077054)
  unreachable
bb24:
  %t79 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l45, !tbaa !24
  %t82 = getelementptr i64, ptr %t80, i64 0
  %t83 = sub i64 %t81, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sub i64 %t87, %t88
  store i64 %t91, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_bd57bfee552aaf80_4db8901b79077054)
  unreachable
bb26:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb31
bb28:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l60, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l60, !tbaa !24
  store i64 %t119, ptr %l57, !tbaa !24
  br label %bb31
bb31:
  %t120 = load i64, ptr %l57, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  %t121 = load i64, ptr %l10, !tbaa !24
  %t122 = sub i64 %t121, 1
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = icmp slt i64 %t123, 2147483648
  %t125 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sge i64 %t125, 0
  %t129 = and i1 %t124, %t126
  store i1 %t129, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t140 = load i64, ptr %l9, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l12, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t148, ptr %l82, !tbaa !27
  %t149 = load i64, ptr %l12, !tbaa !24
  %t150 = load i64, ptr %l4, !tbaa !24
  %t151 = load i64, ptr %l12, !tbaa !24
  %t154 = add i64 %t150, %t151
  %t157 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t149
  store i64 %t154, ptr %t159, !tbaa !34
  br label %bb36
bb36:
  %t160 = load i64, ptr %l11, !tbaa !24
  %t163 = add i64 %t160, 1
  store i64 %t163, ptr %l11, !tbaa !24
  br label %bb32
bb37:
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = load { ptr, ptr }, ptr %l1
  %t167 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t168 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr null, i32 1
  %t169 = ptrtoint ptr %t168 to i64
  %t171 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 0
  store { ptr, ptr } %t166, ptr %t171, !tbaa !28
  %t173 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 1
  store { i64, ptr } %t167, ptr %t173, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t175 = call ptr @__olang_scope_hold(ptr %v1)
  %t176 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 2
  store ptr %t175, ptr %t176, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t177 = call ptr @__olang_scope_hold(ptr %v0)
  %t178 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %t170, i32 0, i32 3
  store ptr %t177, ptr %t178, !tbaa !28
  %t179 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_0, 0
  %t180 = insertvalue { ptr, ptr } %t179, ptr %t170, 1
  %t183 = extractvalue { ptr, ptr } %t180, 0
  %t184 = extractvalue { ptr, ptr } %t180, 1
  call void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_16780(ptr %s0, ptr %s2, { i64, ptr } %t165, ptr %t183, ptr %t184)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t185 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t186 = load i64, ptr %l4, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @std_2fprelude_2farray_2esortPermute_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %s0, { i64, ptr } %t185, i64 %t186, { i64, ptr } %t187)
  br label %bb40
bb40:
  %t191 = load i64, ptr %l5, !tbaa !24
  store i64 %t191, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb41
bb41:
  br label %bb13
bb42:
  %t193 = load i64, ptr @G_2estd_2fprelude_2farray_2esortBlock, !tbaa !24
  store i64 %t193, ptr %l13, !tbaa !24
  br label %bb43
bb43:
  %t195 = load i64, ptr %l13, !tbaa !24
  %t196 = load i64, ptr %l2, !tbaa !24
  %t199 = icmp slt i64 %t195, %t196
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb44, label %bb45
bb44:
  br label %bb59
bb45:
  br label %bb46
bb46:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb47
bb47:
  %t203 = load i64, ptr %l4, !tbaa !24
  %t204 = load i64, ptr %l13, !tbaa !24
  %t207 = add i64 %t203, %t204
  %t208 = load i64, ptr %l2, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb48, label %bb49
bb48:
  br label %bb57
bb49:
  br label %bb50
bb50:
  %t215 = load i64, ptr %l4, !tbaa !24
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = mul i64 2, %t216
  %t221 = add i64 %t215, %t218
  store i64 %t221, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l14, !tbaa !24
  %t224 = load i64, ptr %l2, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb51, label %bb52
bb51:
  %t229 = load i64, ptr %l2, !tbaa !24
  store i64 %t229, ptr %l14, !tbaa !24
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t231 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t232 = load i64, ptr %l4, !tbaa !24
  %t233 = load i64, ptr %l4, !tbaa !24
  %t234 = load i64, ptr %l13, !tbaa !24
  %t237 = add i64 %t233, %t234
  %t238 = load i64, ptr %l14, !tbaa !24
  %t239 = load { ptr, ptr }, ptr %l1
  %t245 = extractvalue { ptr, ptr } %t239, 0
  %t246 = extractvalue { ptr, ptr } %t239, 1
  call void @std_2fprelude_2farray_2esortMerge_3cstd_2fprelude_2ftext_3aString_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t231, i64 %t232, i64 %t237, i64 %t238, ptr %t245, ptr %t246)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t247 = load i64, ptr %l14, !tbaa !24
  store i64 %t247, ptr %l4, !tbaa !24
  br label %bb56
bb56:
  br label %bb47
bb57:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t252 = mul i64 %t249, 2
  store i64 %t252, ptr %l13, !tbaa !24
  br label %bb58
bb58:
  br label %bb43
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortMerge_3cstd_2fprelude_2ftext_3aString_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3, ptr %a4c, ptr %a4e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { ptr, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l39 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca i1
  %l57 = alloca i64
  %l60 = alloca i64
  %l99 = alloca i1
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l107 = alloca i1
  %l150 = alloca i1
  %l152 = alloca { i64, ptr }
  %l157 = alloca { i64, ptr }
  %l160 = alloca i1
  %l171 = alloca i1
  %l182 = alloca i1
  %l194 = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  %pf4 = insertvalue { ptr, ptr } undef, ptr %a4c, 0
  %pg4 = insertvalue { ptr, ptr } %pf4, ptr %a4e, 1
  store { ptr, ptr } %pg4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = sub i64 %t1, %t2
  %t7 = icmp eq i64 %t5, 1
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l2, !tbaa !24
  store i64 %t9, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  br label %bb3
bb2:
  br label %bb27
bb3:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sdiv i64 %t25, 2
  store i64 %t27, ptr %l7, !tbaa !24
  %t29 = load { ptr, ptr }, ptr %l4
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l41, !tbaa !27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %t34, i64 %t31
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !37
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l44, !tbaa !27
  %t38 = load i64, ptr %l1, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  %t45 = extractvalue { ptr, ptr } %t29, 0
  %t46 = extractvalue { ptr, ptr } %t29, 1
  %t49 = call i1 %t45(ptr %t46, ptr %v0, ptr %v0, { i64, ptr } %t36, { i64, ptr } %t43)
  store i1 %t49, ptr %l47
  br label %bb7
bb7:
  %t50 = load i1, ptr %l47, !tbaa !21
  store i1 %t50, ptr %l39, !tbaa !21
  br label %bb8
bb8:
  %t51 = load i1, ptr %l39, !tbaa !21
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l5, !tbaa !24
  br label %bb11
bb10:
  %t56 = load i64, ptr %l7, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  br label %bb12
bb12:
  br label %bb3
bb13:
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t62 = sub i64 %t60, 1
  store i64 %t62, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t70 = load i64, ptr %l10, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb19
bb16:
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l60, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb18
bb18:
  %t90 = load i64, ptr %l60, !tbaa !24
  store i64 %t90, ptr %l57, !tbaa !24
  br label %bb19
bb19:
  %t91 = load i64, ptr %l57, !tbaa !24
  store i64 %t91, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t92 = load i64, ptr %l12, !tbaa !24
  %t93 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb21, label %bb22
bb21:
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t105 = mul i64 %t101, %t102
  %t108 = add i64 %t100, %t105
  store i64 %t108, ptr %l13, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t111 = load i64, ptr %l13, !tbaa !24
  %t112 = load i64, ptr %l13, !tbaa !24
  %t114 = add i64 %t112, 1
  call void @std_2fprelude_2farray_2esortSwap_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t110, i64 %t111, i64 %t114)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = add i64 %t118, 1
  store i64 %t121, ptr %l12, !tbaa !24
  br label %bb20
bb26:
  br label %ret
bb27:
  %t123 = load i64, ptr %l3, !tbaa !24
  %t124 = load i64, ptr %l2, !tbaa !24
  %t127 = sub i64 %t123, %t124
  %t129 = icmp eq i64 %t127, 1
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t131 = load i64, ptr %l1, !tbaa !24
  store i64 %t131, ptr %l14, !tbaa !24
  %t133 = load i64, ptr %l2, !tbaa !24
  store i64 %t133, ptr %l15, !tbaa !24
  br label %bb30
bb29:
  br label %bb48
bb30:
  %t135 = load i64, ptr %l14, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t143 = load i64, ptr %l14, !tbaa !24
  %t144 = load i64, ptr %l15, !tbaa !24
  %t147 = add i64 %t143, %t144
  %t149 = sdiv i64 %t147, 2
  store i64 %t149, ptr %l16, !tbaa !24
  %t151 = load { ptr, ptr }, ptr %l4
  %t152 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t152, ptr %l101, !tbaa !27
  %t153 = load i64, ptr %l2, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %t156, i64 %t153
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !37
  %t159 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t159, ptr %l104, !tbaa !27
  %t160 = load i64, ptr %l16, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %t163, i64 %t160
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !37
  %t167 = extractvalue { ptr, ptr } %t151, 0
  %t168 = extractvalue { ptr, ptr } %t151, 1
  %t171 = call i1 %t167(ptr %t168, ptr %v0, ptr %v0, { i64, ptr } %t158, { i64, ptr } %t165)
  store i1 %t171, ptr %l107
  br label %bb34
bb34:
  %t172 = load i1, ptr %l107, !tbaa !21
  store i1 %t172, ptr %l99, !tbaa !21
  br label %bb35
bb35:
  %t173 = load i1, ptr %l99, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb36, label %bb37
bb36:
  %t176 = load i64, ptr %l16, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l14, !tbaa !24
  br label %bb38
bb37:
  %t180 = load i64, ptr %l16, !tbaa !24
  store i64 %t180, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb30
bb40:
  %t182 = load i64, ptr %l2, !tbaa !24
  store i64 %t182, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  %t184 = load i64, ptr %l17, !tbaa !24
  %t185 = load i64, ptr %l14, !tbaa !24
  %t188 = icmp sgt i64 %t184, %t185
  %t190 = xor i1 %t188, true
  br i1 %t190, label %bb42, label %bb43
bb42:
  br label %bb47
bb43:
  br label %bb44
bb44:
  %t192 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t193 = load i64, ptr %l17, !tbaa !24
  %t194 = load i64, ptr %l17, !tbaa !24
  %t196 = sub i64 %t194, 1
  call void @std_2fprelude_2farray_2esortSwap_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t192, i64 %t193, i64 %t196)
  br label %bb45
bb45:
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = sub i64 %t200, 1
  store i64 %t203, ptr %l17, !tbaa !24
  br label %bb46
bb46:
  br label %bb41
bb47:
  br label %ret
bb48:
  %t205 = load i64, ptr %l1, !tbaa !24
  %t206 = load i64, ptr %l3, !tbaa !24
  %t209 = add i64 %t205, %t206
  %t211 = sdiv i64 %t209, 2
  store i64 %t211, ptr %l18, !tbaa !24
  %t213 = load i64, ptr %l18, !tbaa !24
  %t214 = load i64, ptr %l2, !tbaa !24
  %t217 = add i64 %t213, %t214
  store i64 %t217, ptr %l19, !tbaa !24
  %t219 = load i64, ptr %l1, !tbaa !24
  store i64 %t219, ptr %l20, !tbaa !24
  %t221 = load i64, ptr %l2, !tbaa !24
  store i64 %t221, ptr %l21, !tbaa !24
  %t223 = load i64, ptr %l2, !tbaa !24
  %t224 = load i64, ptr %l18, !tbaa !24
  %t227 = icmp sgt i64 %t223, %t224
  br i1 %t227, label %bb49, label %bb50
bb49:
  %t229 = load i64, ptr %l19, !tbaa !24
  %t230 = load i64, ptr %l3, !tbaa !24
  %t233 = sub i64 %t229, %t230
  store i64 %t233, ptr %l20, !tbaa !24
  %t235 = load i64, ptr %l18, !tbaa !24
  store i64 %t235, ptr %l21, !tbaa !24
  br label %bb51
bb50:
  br label %bb51
bb51:
  %t237 = load i64, ptr %l19, !tbaa !24
  %t239 = sub i64 %t237, 1
  store i64 %t239, ptr %l22, !tbaa !24
  br label %bb52
bb52:
  %t241 = load i64, ptr %l20, !tbaa !24
  %t242 = load i64, ptr %l21, !tbaa !24
  %t245 = icmp slt i64 %t241, %t242
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb53, label %bb54
bb53:
  br label %bb62
bb54:
  br label %bb55
bb55:
  %t249 = load i64, ptr %l20, !tbaa !24
  %t250 = load i64, ptr %l21, !tbaa !24
  %t253 = add i64 %t249, %t250
  %t255 = sdiv i64 %t253, 2
  store i64 %t255, ptr %l23, !tbaa !24
  %t257 = load { ptr, ptr }, ptr %l4
  %t258 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t258, ptr %l152, !tbaa !27
  %t259 = load i64, ptr %l22, !tbaa !24
  %t260 = load i64, ptr %l23, !tbaa !24
  %t263 = sub i64 %t259, %t260
  %t265 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t266 = load ptr, ptr %t265, !tbaa !27
  %t267 = getelementptr { i64, ptr }, ptr %t266, i64 %t263
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !37
  %t269 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t269, ptr %l157, !tbaa !27
  %t270 = load i64, ptr %l23, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr { i64, ptr }, ptr %t273, i64 %t270
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !37
  %t277 = extractvalue { ptr, ptr } %t257, 0
  %t278 = extractvalue { ptr, ptr } %t257, 1
  %t281 = call i1 %t277(ptr %t278, ptr %v0, ptr %v0, { i64, ptr } %t268, { i64, ptr } %t275)
  store i1 %t281, ptr %l160
  br label %bb56
bb56:
  %t282 = load i1, ptr %l160, !tbaa !21
  store i1 %t282, ptr %l150, !tbaa !21
  br label %bb57
bb57:
  %t283 = load i1, ptr %l150, !tbaa !21
  %t284 = xor i1 %t283, true
  br i1 %t284, label %bb58, label %bb59
bb58:
  %t286 = load i64, ptr %l23, !tbaa !24
  %t288 = add i64 %t286, 1
  store i64 %t288, ptr %l20, !tbaa !24
  br label %bb60
bb59:
  %t290 = load i64, ptr %l23, !tbaa !24
  store i64 %t290, ptr %l21, !tbaa !24
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb52
bb62:
  %t292 = load i64, ptr %l19, !tbaa !24
  %t293 = load i64, ptr %l20, !tbaa !24
  %t296 = sub i64 %t292, %t293
  store i64 %t296, ptr %l24, !tbaa !24
  %t298 = load i64, ptr %l20, !tbaa !24
  %t299 = load i64, ptr %l2, !tbaa !24
  %t302 = icmp slt i64 %t298, %t299
  br i1 %t302, label %bb63, label %bb64
bb63:
  %t304 = load i64, ptr %l2, !tbaa !24
  %t305 = load i64, ptr %l24, !tbaa !24
  %t308 = icmp slt i64 %t304, %t305
  store i1 %t308, ptr %l171, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb65
bb65:
  %t310 = load i1, ptr %l171, !tbaa !21
  br i1 %t310, label %bb66, label %bb67
bb66:
  %t311 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t312 = load i64, ptr %l20, !tbaa !24
  %t313 = load i64, ptr %l2, !tbaa !24
  %t314 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2farray_2esortRotate_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t311, i64 %t312, i64 %t313, i64 %t314)
  br label %bb68
bb67:
  br label %bb69
bb68:
  br label %bb69
bb69:
  %t319 = load i64, ptr %l1, !tbaa !24
  %t320 = load i64, ptr %l20, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  br i1 %t323, label %bb70, label %bb71
bb70:
  %t325 = load i64, ptr %l20, !tbaa !24
  %t326 = load i64, ptr %l18, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  store i1 %t329, ptr %l182, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb72
bb72:
  %t331 = load i1, ptr %l182, !tbaa !21
  br i1 %t331, label %bb73, label %bb74
bb73:
  %t332 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t333 = load i64, ptr %l1, !tbaa !24
  %t334 = load i64, ptr %l20, !tbaa !24
  %t335 = load i64, ptr %l18, !tbaa !24
  %t336 = load { ptr, ptr }, ptr %l4
  %t342 = extractvalue { ptr, ptr } %t336, 0
  %t343 = extractvalue { ptr, ptr } %t336, 1
  call void @std_2fprelude_2farray_2esortMerge_3cstd_2fprelude_2ftext_3aString_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t332, i64 %t333, i64 %t334, i64 %t335, ptr %t342, ptr %t343)
  br label %bb75
bb74:
  br label %bb77
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t344 = load i64, ptr %l18, !tbaa !24
  %t345 = load i64, ptr %l24, !tbaa !24
  %t348 = icmp slt i64 %t344, %t345
  br i1 %t348, label %bb78, label %bb79
bb78:
  %t350 = load i64, ptr %l24, !tbaa !24
  %t351 = load i64, ptr %l3, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  store i1 %t354, ptr %l194, !tbaa !21
  br label %bb80
bb79:
  store i1 false, ptr %l194, !tbaa !21
  br label %bb80
bb80:
  %t356 = load i1, ptr %l194, !tbaa !21
  br i1 %t356, label %bb81, label %bb82
bb81:
  %t357 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t358 = load i64, ptr %l18, !tbaa !24
  %t359 = load i64, ptr %l24, !tbaa !24
  %t360 = load i64, ptr %l3, !tbaa !24
  %t361 = load { ptr, ptr }, ptr %l4
  %t367 = extractvalue { ptr, ptr } %t361, 0
  %t368 = extractvalue { ptr, ptr } %t361, 1
  call void @std_2fprelude_2farray_2esortMerge_3cstd_2fprelude_2ftext_3aString_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t357, i64 %t358, i64 %t359, i64 %t360, ptr %t367, ptr %t368)
  br label %bb83
bb82:
  br label %bb85
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2esortRotate_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l41 = alloca i64
  %l44 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i64
  %l127 = alloca i64
  %l130 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t5 = sub i64 %t1, %a1
  store i64 %t5, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = sub i64 %a3, %t8
  store i64 %t11, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp ne i64 %t13, %t14
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb2, label %bb3
bb2:
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i64 0, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  store i64 %t27, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l12, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  store i64 %t35, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb20, label %bb21
bb7:
  %t43 = load i64, ptr %l8, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l8, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l44, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l44, !tbaa !24
  store i64 %t63, ptr %l41, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l41, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l10, !tbaa !24
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t74 = load i64, ptr %l10, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l11, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = load i64, ptr %l2, !tbaa !24
  %t85 = load i64, ptr %l4, !tbaa !24
  %t88 = sub i64 %t84, %t85
  %t89 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t88, %t89
  %t93 = load i64, ptr %l2, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t97 = add i64 %t93, %t94
  call void @std_2fprelude_2farray_2esortSwap_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t83, i64 %t92, i64 %t97)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l10, !tbaa !24
  br label %bb13
bb19:
  %t106 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l5, !tbaa !24
  %t111 = sub i64 %t106, %t108
  store i64 %t111, ptr %l4, !tbaa !24
  br label %bb33
bb20:
  %t113 = load i64, ptr %l14, !tbaa !24
  %t115 = icmp sgt i64 %t113, 0
  br i1 %t115, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb25
bb22:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sub i64 %t117, %t118
  %t122 = load i64, ptr %l14, !tbaa !24
  %t125 = add i64 %t121, %t122
  %t127 = sub i64 %t125, 1
  %t128 = load i64, ptr %l14, !tbaa !24
  %t131 = sdiv i64 %t127, %t128
  store i64 %t131, ptr %l85, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb24
bb24:
  %t133 = load i64, ptr %l85, !tbaa !24
  store i64 %t133, ptr %l82, !tbaa !24
  br label %bb25
bb25:
  %t134 = load i64, ptr %l82, !tbaa !24
  store i64 %t134, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb26
bb26:
  %t135 = load i64, ptr %l16, !tbaa !24
  %t136 = load i64, ptr %l15, !tbaa !24
  %t139 = icmp slt i64 %t135, %t136
  %t141 = xor i1 %t139, true
  br i1 %t141, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t143 = load i64, ptr %l12, !tbaa !24
  %t144 = load i64, ptr %l16, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = mul i64 %t144, %t145
  %t151 = add i64 %t143, %t148
  store i64 %t151, ptr %l17, !tbaa !24
  %t153 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t154 = load i64, ptr %l2, !tbaa !24
  %t155 = load i64, ptr %l4, !tbaa !24
  %t158 = sub i64 %t154, %t155
  %t159 = load i64, ptr %l17, !tbaa !24
  %t162 = add i64 %t158, %t159
  %t163 = load i64, ptr %l2, !tbaa !24
  %t164 = load i64, ptr %l5, !tbaa !24
  %t167 = add i64 %t163, %t164
  %t168 = load i64, ptr %l4, !tbaa !24
  %t171 = sub i64 %t167, %t168
  %t172 = load i64, ptr %l17, !tbaa !24
  %t175 = add i64 %t171, %t172
  call void @std_2fprelude_2farray_2esortSwap_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t153, i64 %t162, i64 %t175)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l16, !tbaa !24
  br label %bb26
bb32:
  %t184 = load i64, ptr %l5, !tbaa !24
  %t186 = load i64, ptr %l4, !tbaa !24
  %t189 = sub i64 %t184, %t186
  store i64 %t189, ptr %l5, !tbaa !24
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb1
bb35:
  store i64 0, ptr %l18, !tbaa !24
  %t191 = load i64, ptr %l4, !tbaa !24
  store i64 %t191, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t193 = load i64, ptr %l19, !tbaa !24
  %t194 = load i64, ptr %l18, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb36, label %bb37
bb36:
  %t199 = load i64, ptr %l20, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb38, label %bb39
bb37:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb41
bb38:
  %t203 = load i64, ptr %l19, !tbaa !24
  %t204 = load i64, ptr %l18, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i64, ptr %l20, !tbaa !24
  %t211 = add i64 %t207, %t208
  %t213 = sub i64 %t211, 1
  %t214 = load i64, ptr %l20, !tbaa !24
  %t217 = sdiv i64 %t213, %t214
  store i64 %t217, ptr %l130, !tbaa !24
  br label %bb40
bb39:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb40
bb40:
  %t219 = load i64, ptr %l130, !tbaa !24
  store i64 %t219, ptr %l127, !tbaa !24
  br label %bb41
bb41:
  %t220 = load i64, ptr %l127, !tbaa !24
  store i64 %t220, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb42
bb42:
  %t221 = load i64, ptr %l22, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb43, label %bb44
bb43:
  br label %bb48
bb44:
  br label %bb45
bb45:
  %t229 = load i64, ptr %l18, !tbaa !24
  %t230 = load i64, ptr %l22, !tbaa !24
  %t231 = load i64, ptr %l20, !tbaa !24
  %t234 = mul i64 %t230, %t231
  %t237 = add i64 %t229, %t234
  store i64 %t237, ptr %l23, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t240 = load i64, ptr %l2, !tbaa !24
  %t241 = load i64, ptr %l4, !tbaa !24
  %t244 = sub i64 %t240, %t241
  %t245 = load i64, ptr %l23, !tbaa !24
  %t248 = add i64 %t244, %t245
  %t249 = load i64, ptr %l2, !tbaa !24
  %t250 = load i64, ptr %l23, !tbaa !24
  %t253 = add i64 %t249, %t250
  call void @std_2fprelude_2farray_2esortSwap_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t239, i64 %t248, i64 %t253)
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t257 = load i64, ptr %l22, !tbaa !24
  %t260 = add i64 %t257, 1
  store i64 %t260, ptr %l22, !tbaa !24
  br label %bb42
bb48:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
define internal i1 @olang_lambda_0(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { ptr, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  store { i64, ptr } %cv1, ptr %l3
  %vq0 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { ptr, ptr }, { i64, ptr }, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %t6, i64 %a0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !37
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t9, ptr %l9, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %t13, i64 %a1
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !37
  %t17 = extractvalue { ptr, ptr } %cv0, 0
  %t18 = extractvalue { ptr, ptr } %cv0, 1
  %t21 = call i1 %t17(ptr %t18, ptr %vc1, ptr %vc1, { i64, ptr } %t8, { i64, ptr } %t15)
  store i1 %t21, ptr %l12
  br label %bb1
bb1:
  %t22 = load i1, ptr %l12, !tbaa !21
  store i1 %t22, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t23 = load i1, ptr %l4, !tbaa !21
  store i1 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2estd_2fprelude_2farray_2esortRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2farray_2esortInsertion_3cstd_2fprelude_2ftext_3aString_26_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, ptr %a3c, ptr %a3e)
@G_2estd_2fprelude_2farray_2esortBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\30\00\00\00\00\00\00" }>, align 8
@olang_loc_f5954356a94cfd1d_57c8a908dd11d469 = external constant [0 x i8]
@olang_loc_bd57bfee552aaf80_4db8901b79077054 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e_clone1_olang_lambda_16780(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fprelude_2farray_2esortPermute_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2farray_2esortSwap_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
