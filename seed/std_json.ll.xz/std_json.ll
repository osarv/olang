; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/json:reader" = type { { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/json:writer" = type { { i64, ptr }, i32, %"std/prelude/text:StringBuilder" }
@G_2estd_2fjson_2eCamel = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2estd_2fjson_2eExact = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2estd_2fjson_2eKebab = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2estd_2fjson_2eMaxDepth = constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\03\00\00\00\00\00\00" }>, align 8
@G_2estd_2fjson_2eSnake = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2estd_2fjson_2ehexDigits = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2estd_2fjson_2ehexDigits.k1 }>, align 8
@G_2estd_2fjson_2ehexDigits.k1 = internal global <{ [16 x i8] }> <{ [16 x i8] c"\30\31\32\33\34\35\36\37\38\39\61\62\63\64\65\66" }>, align 8
define dso_local { i32, ptr } @std_2fjson_2eJson_2eParse(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca %"std/json:reader"
  %l6 = alloca i32
  %l9 = alloca { i64, ptr }
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/json:reader" @std_2fjson_3areader_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
  store %"std/json:reader" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/json:reader", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 112, i64 8)
  store %"std/json:reader" %t4, ptr %t5
  store ptr %t5, ptr %l1, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i32 @std_2fjson_2estd_2fjson_3areader_2erun(ptr %v1, ptr %t7)
  store i32 %t9, ptr %l6
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  br label %bb2
bb2:
  br label %bb4
bb3:
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = lshr i32 %t12, 16
  %t14 = and i32 %t12, 65535
  %t15 = icmp eq i32 %t13, 1
  %t16 = select i1 %t15, i32 1, i32 0
  %t17 = icmp eq i32 %t12, 0
  %t18 = shl i32 %t16, 16
  %t19 = or i32 %t18, %t14
  %t20 = select i1 %t17, i32 0, i32 %t19
  %t22 = insertvalue { i32, ptr } zeroinitializer, i32 %t20, 0
  store { i32, ptr } %t22, ptr %rv
  br label %ret
bb4:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"std/json:reader", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l9, !tbaa !27
  %t27 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr ptr, ptr %t28, i64 0
  %t30 = load ptr, ptr %t29, !tbaa !39
  %t32 = insertvalue { i32, ptr } zeroinitializer, ptr %t30, 1
  store { i32, ptr } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i64, ptr } @std_2fjson_2eKeyOf(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 4}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t14 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t14, ptr %l7
  br label %bb4
bb4:
  %t15 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = load i32, ptr %l1, !range !{i32 0, i32 4}
  call void @std_2fjson_2ekeyInto(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t16, i32 %t17)
  br label %bb5
bb5:
  %t22 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t22, ptr %l12
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fjson_2espaceEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i8
  %l10 = alloca { i64, ptr }
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l3, !tbaa !22
  %t21 = load i8, ptr %l3, !tbaa !22
  %t23 = icmp ne i8 %t21, 32
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i8, ptr %l3, !tbaa !22
  %t27 = icmp ne i8 %t25, 10
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load i8, ptr %l3, !tbaa !22
  %t32 = icmp ne i8 %t30, 13
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i8, ptr %l3, !tbaa !22
  %t37 = icmp ne i8 %t35, 9
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, ptr } }
  %t19 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t16, 1
  store { i32, { i64, ptr } } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 8, ptr %t20
  %t21 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t21, ptr %l9
  %t22 = call ptr @__olang_errpay_push()
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10
  %t25 = inttoptr i64 %t24 to ptr
  %t27 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t25, ptr %l9)
  store { i64, [2 x i64] } %t27, ptr %l12
  br label %bb10
bb10:
  %t28 = load { i64, [2 x i64] }, ptr %l12
  %t29 = load i64, ptr %l10
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call ptr @__olang_scope_alloc_a(ptr %t30, i64 24, i64 8)
  store { i64, [2 x i64] } %t28, ptr %t31
  call void @__olang_errpay_set(ptr %t31)
  %t34 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65544, 0
  store { i32, { i64, ptr } } %t34, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7a4bfc7c7b524c63_98397af697b8e9df)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i1 } @std_2fjson_2estd_2fjson_3aJson_2eAsBool(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, i1 }
  %t19 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i1 }, ptr %t12, i32 0, i32 0
  %t14 = load i1, ptr %t13
  store i1 %t14, ptr %l1, !tbaa !21
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i1, ptr %l1, !tbaa !21
  %t18 = insertvalue { i32, i1 } zeroinitializer, i1 %t16, 1
  store { i32, i1 } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 8, ptr %t20
  %t21 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t21, ptr %l9
  %t22 = call ptr @__olang_errpay_push()
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10
  %t25 = inttoptr i64 %t24 to ptr
  %t27 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t25, ptr %l9)
  store { i64, [2 x i64] } %t27, ptr %l12
  br label %bb10
bb10:
  %t28 = load { i64, [2 x i64] }, ptr %l12
  %t29 = load i64, ptr %l10
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call ptr @__olang_scope_alloc_a(ptr %t30, i64 24, i64 8)
  store { i64, [2 x i64] } %t28, ptr %t31
  call void @__olang_errpay_set(ptr %t31)
  %t34 = insertvalue { i32, i1 } zeroinitializer, i32 65544, 0
  store { i32, i1 } %t34, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_fa9f38c9682d865a_6f1f2fc1eaeb7f26)
  unreachable
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca i128
  %l4 = alloca i128
  %l5 = alloca i32
  %l10 = alloca i1
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i64
  %l17 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, i64 }
  %t34 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, i128 } %t3, 1
  %t5 = extractvalue { i32, i128 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i128 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i128, ptr %l4
  store i128 %t8, ptr %l2
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, i64 } zeroinitializer, i32 %t17, 0
  store { i32, i64 } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i128, ptr %l2
  store i128 %t20, ptr %l1
  %t21 = load i128, ptr %l1
  %t22 = sext i64 -9223372036854775808 to i128
  %t25 = icmp slt i128 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i128, ptr %l1
  %t28 = sext i64 9223372036854775807 to i128
  %t31 = icmp sgt i128 %t27, %t28
  store i1 %t31, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l10, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  store { i64, [2 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 0
  store i64 8, ptr %t35
  %t36 = load { i64, [2 x i64] }, ptr %t34
  store { i64, [2 x i64] } %t36, ptr %l14
  %t37 = call ptr @__olang_errpay_push()
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l15, !tbaa !24
  %t39 = load i64, ptr %l15
  %t40 = inttoptr i64 %t39 to ptr
  %t42 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t40, ptr %l14)
  store { i64, [2 x i64] } %t42, ptr %l17
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t43 = load { i64, [2 x i64] }, ptr %l17
  %t44 = load i64, ptr %l15
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = call ptr @__olang_scope_alloc_a(ptr %t45, i64 24, i64 8)
  store { i64, [2 x i64] } %t43, ptr %t46
  call void @__olang_errpay_set(ptr %t46)
  %t49 = insertvalue { i32, i64 } zeroinitializer, i32 65544, 0
  store { i32, i64 } %t49, ptr %rv
  br label %ret
bb10:
  %t50 = load i128, ptr %l1
  %t52 = trunc i128 %t50 to i64
  %t54 = insertvalue { i32, i64 } zeroinitializer, i64 %t52, 1
  store { i32, i64 } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, double } @std_2fjson_2estd_2fjson_3aJson_2eAsNum(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca double
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca { i64, [2 x i64] }
  %l28 = alloca i64
  %l30 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, double }
  %t59 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { double }, ptr %t12, i32 0, i32 0
  %t14 = load double, ptr %t13
  store double %t14, ptr %l1, !tbaa !26
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load double, ptr %l1, !tbaa !26
  %t18 = insertvalue { i32, double } zeroinitializer, double %t16, 1
  store { i32, double } %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l11, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { i64 }, ptr %t30, i32 0, i32 0
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = sitofp i64 %t34 to double
  %t38 = insertvalue { i32, double } zeroinitializer, double %t36, 1
  store { i32, double } %t38, ptr %rv
  br label %ret
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load ptr, ptr %l19, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 4
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l20, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { i64 }, ptr %t50, i32 0, i32 0
  %t52 = load i64, ptr %t51
  store i64 %t52, ptr %l3, !tbaa !65
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t54 = load i64, ptr %l3, !tbaa !65
  %t56 = uitofp i64 %t54 to double
  %t58 = insertvalue { i32, double } zeroinitializer, double %t56, 1
  store { i32, double } %t58, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  store { i64, [2 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 0
  store i64 8, ptr %t60
  %t61 = load { i64, [2 x i64] }, ptr %t59
  store { i64, [2 x i64] } %t61, ptr %l27
  %t62 = call ptr @__olang_errpay_push()
  %t63 = ptrtoint ptr %t62 to i64
  store i64 %t63, ptr %l28, !tbaa !24
  %t64 = load i64, ptr %l28
  %t65 = inttoptr i64 %t64 to ptr
  %t67 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t65, ptr %l27)
  store { i64, [2 x i64] } %t67, ptr %l30
  br label %bb22
bb22:
  %t68 = load { i64, [2 x i64] }, ptr %l30
  %t69 = load i64, ptr %l28
  %t70 = inttoptr i64 %t69 to ptr
  %t71 = call ptr @__olang_scope_alloc_a(ptr %t70, i64 24, i64 8)
  store { i64, [2 x i64] } %t68, ptr %t71
  call void @__olang_errpay_set(ptr %t71)
  %t74 = insertvalue { i32, double } zeroinitializer, i32 65544, 0
  store { i32, double } %t74, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c3fd3a937aadf066_df3562c3c4e6c4da)
  unreachable
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAsObj(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, ptr }
  %t19 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = insertvalue { i32, ptr } zeroinitializer, ptr %t16, 1
  store { i32, ptr } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 8, ptr %t20
  %t21 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t21, ptr %l9
  %t22 = call ptr @__olang_errpay_push()
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10
  %t25 = inttoptr i64 %t24 to ptr
  %t27 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t25, ptr %l9)
  store { i64, [2 x i64] } %t27, ptr %l12
  br label %bb10
bb10:
  %t28 = load { i64, [2 x i64] }, ptr %l12
  %t29 = load i64, ptr %l10
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call ptr @__olang_scope_alloc_a(ptr %t30, i64 24, i64 8)
  store { i64, [2 x i64] } %t28, ptr %t31
  call void @__olang_errpay_set(ptr %t31)
  %t34 = insertvalue { i32, ptr } zeroinitializer, i32 65544, 0
  store { i32, ptr } %t34, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_9bf067a17252b335_30d904505e687d39)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, { i64, ptr } }
  %t19 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t16, 1
  store { i32, { i64, ptr } } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb11
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t19
  %t20 = getelementptr { i64, [2 x i64] }, ptr %t19, i32 0, i32 0
  store i64 8, ptr %t20
  %t21 = load { i64, [2 x i64] }, ptr %t19
  store { i64, [2 x i64] } %t21, ptr %l9
  %t22 = call ptr @__olang_errpay_push()
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l10, !tbaa !24
  %t24 = load i64, ptr %l10
  %t25 = inttoptr i64 %t24 to ptr
  %t27 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t25, ptr %l9)
  store { i64, [2 x i64] } %t27, ptr %l12
  br label %bb10
bb10:
  %t28 = load { i64, [2 x i64] }, ptr %l12
  %t29 = load i64, ptr %l10
  %t30 = inttoptr i64 %t29 to ptr
  %t31 = call ptr @__olang_scope_alloc_a(ptr %t30, i64 24, i64 8)
  store { i64, [2 x i64] } %t28, ptr %t31
  call void @__olang_errpay_set(ptr %t31)
  %t34 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65544, 0
  store { i32, { i64, ptr } } %t34, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_d2781e368edd9e2f_3a33f3735a4c4ba3)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsUint(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca i128
  %l4 = alloca i128
  %l5 = alloca i32
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i64
  %l12 = alloca { i64, [2 x i64] }
  %rv = alloca { i32, i64 }
  %t25 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, i128 } %t3, 1
  %t5 = extractvalue { i32, i128 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i128 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i128, ptr %l4
  store i128 %t8, ptr %l2
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, i64 } zeroinitializer, i32 %t17, 0
  store { i32, i64 } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i128, ptr %l2
  store i128 %t20, ptr %l1
  %t21 = load i128, ptr %l1
  %t23 = icmp slt i128 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  store { i64, [2 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 0
  store i64 8, ptr %t26
  %t27 = load { i64, [2 x i64] }, ptr %t25
  store { i64, [2 x i64] } %t27, ptr %l9
  %t28 = call ptr @__olang_errpay_push()
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l10
  %t31 = inttoptr i64 %t30 to ptr
  %t33 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t31, ptr %l9)
  store { i64, [2 x i64] } %t33, ptr %l12
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t34 = load { i64, [2 x i64] }, ptr %l12
  %t35 = load i64, ptr %l10
  %t36 = inttoptr i64 %t35 to ptr
  %t37 = call ptr @__olang_scope_alloc_a(ptr %t36, i64 24, i64 8)
  store { i64, [2 x i64] } %t34, ptr %t37
  call void @__olang_errpay_set(ptr %t37)
  %t40 = insertvalue { i32, i64 } zeroinitializer, i32 65544, 0
  store { i32, i64 } %t40, ptr %rv
  br label %ret
bb7:
  %t41 = load i128, ptr %l1
  %t43 = trunc i128 %t41 to i64
  %t45 = insertvalue { i32, i64 } zeroinitializer, i64 %t43, 1
  store { i32, i64 } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aJson_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @std_2fjson_2estd_2fjson_3aObject_2eHas(ptr %v0, ptr %v1, ptr %t16, { i64, ptr } %a1)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_a95109d49c9a5ab2_e7f3aa33cdaf23de)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aJson_2eIsNull(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @std_2fjson_2estd_2fjson_3aJson_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t4 = call { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %s0, ptr %v1, ptr %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, i32 0)
  store { i64, ptr } %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, ptr } @std_2fjson_2estd_2fjson_3aObject_2eAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, [2 x i64] }
  %l14 = alloca i64
  %l16 = alloca { i64, [2 x i64] }
  %s1 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t30 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:Object", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %t6)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l8
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  br label %bb5
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l10, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l11, !tbaa !24
  %t19 = load i64, ptr %l11, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l12, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l11, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  store { i64, [2 x i64] } zeroinitializer, ptr %t30
  %t31 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 0
  store i64 7, ptr %t31
  %t32 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t33 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t32, 0
  %t34 = getelementptr { i64, [2 x i64] }, ptr %t30, i32 0, i32 1
  store { { i64, ptr } } %t33, ptr %t34
  %t35 = load { i64, [2 x i64] }, ptr %t30
  store { i64, [2 x i64] } %t35, ptr %l13
  %t36 = call ptr @__olang_errpay_push()
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l14, !tbaa !24
  %t38 = load i64, ptr %l14
  %t39 = inttoptr i64 %t38 to ptr
  %t41 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t39, ptr %l13)
  store { i64, [2 x i64] } %t41, ptr %l16
  br label %bb4
bb4:
  %t42 = load { i64, [2 x i64] }, ptr %l16
  %t43 = load i64, ptr %l14
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = call ptr @__olang_scope_alloc_a(ptr %t44, i64 24, i64 8)
  store { i64, [2 x i64] } %t42, ptr %t45
  call void @__olang_errpay_set(ptr %t45)
  call void @__olang_scope_close(ptr %s1)
  %t48 = insertvalue { i32, ptr } zeroinitializer, i32 65543, 0
  store { i32, ptr } %t48, ptr %rv
  br label %ret
bb5:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t49
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t55 = insertvalue { i32, ptr } zeroinitializer, ptr %t53, 1
  store { i32, ptr } %t55, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aObject_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %rv
  br label %ret
bb4:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/json:Object", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fjson_2estd_2fjson_3areader_2ecol(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i8
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i1
  %l44 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t4, i64 %t10)
  store i64 %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load i64, ptr %l14, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb7
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l21, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = sub i64 %t43, 1
  store i64 %t44, ptr %l30, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp slt i64 %t45, 2147483648
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sge i64 %t47, 0
  %t51 = and i1 %t46, %t48
  store i1 %t51, ptr %l33, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb9, label %bb10
bb9:
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/json:reader", ptr %t70, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l44, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t68
  %t79 = load i8, ptr %t78, !tbaa !32
  store i8 %t79, ptr %l8, !tbaa !22
  %t81 = load i8, ptr %l8, !tbaa !22
  %t83 = icmp eq i8 %t81, 10
  br i1 %t83, label %bb12, label %bb13
bb12:
  store i64 1, ptr %l1, !tbaa !24
  br label %bb17
bb13:
  %t85 = load i8, ptr %l8, !tbaa !22
  %t87 = and i8 %t85, -64
  %t89 = icmp ne i8 %t87, -128
  br i1 %t89, label %bb14, label %bb15
bb14:
  %t91 = load i64, ptr %l1, !tbaa !24
  %t94 = add i64 %t91, 1
  store i64 %t94, ptr %l1, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = add i64 %t96, 1
  store i64 %t99, ptr %l6, !tbaa !24
  br label %bb8
bb19:
  %t101 = load i64, ptr %l1, !tbaa !24
  store i64 %t101, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fjson_2estd_2fjson_3areader_2eline(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l29 = alloca i64
  %l32 = alloca i1
  %l43 = alloca { i64, ptr }
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t4, i64 %t10)
  store i64 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load i64, ptr %l13, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l20, !tbaa !24
  store i64 %t41, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l17, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t44 = sub i64 %t43, 1
  store i64 %t44, ptr %l29, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp slt i64 %t45, 2147483648
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sge i64 %t47, 0
  %t51 = and i1 %t46, %t48
  store i1 %t51, ptr %l32, !tbaa !21
  br label %bb8
bb8:
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb9, label %bb10
bb9:
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t60 = load i64, ptr %l2, !tbaa !24
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l4, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/json:reader", ptr %t70, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l43, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t68
  %t79 = load i8, ptr %t78, !tbaa !32
  %t81 = icmp eq i8 %t79, 10
  br i1 %t81, label %bb12, label %bb13
bb12:
  %t83 = load i64, ptr %l1, !tbaa !24
  %t86 = add i64 %t83, 1
  store i64 %t86, ptr %l1, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t91 = add i64 %t88, 1
  store i64 %t91, ptr %l6, !tbaa !24
  br label %bb8
bb16:
  %t93 = load i64, ptr %l1, !tbaa !24
  store i64 %t93, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l66 = alloca ptr
  %t42 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/json:reader", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/json:reader", ptr %t21, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = mul i64 %t24, 2
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 0
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb3, label %bb4
bb2:
  br label %bb19
bb3:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = icmp sle i64 %t35, 1152921504606846975
  br i1 %t36, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_8fccbc1a4d1c0f20_785a6b4725d4309c)
  unreachable
bb5:
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = mul i64 %t38, 8
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  %t41 = load ptr, ptr %l22, !tbaa !29
  store i64 0, ptr %t42
  br label %fill.43
fill.43:
  %t46 = load i64, ptr %t42
  %t47 = icmp slt i64 %t46, %t38
  br i1 %t47, label %fillb.44, label %filld.45
fillb.44:
  %t48 = getelementptr ptr, ptr %t40, i64 %t46
  store ptr %t41, ptr %t48
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %t42
  br label %fill.43
filld.45:
  %t50 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t40, 1
  %t53 = load ptr, ptr %l17, !tbaa !29
  %t54 = getelementptr %"std/json:reader", ptr %t53, i32 0, i32 2
  store { i64, ptr } %t51, ptr %t54, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 3
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8fccbc1a4d1c0f20_785a6b4725d4309c)
  unreachable
bb7:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb9:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t86 = load i64, ptr %l34, !tbaa !24
  store i64 %t86, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t87 = load i64, ptr %l31, !tbaa !24
  store i64 %t87, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l8, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"std/json:reader", ptr %t106, i32 0, i32 2
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l53, !tbaa !27
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t111, ptr %l55, !tbaa !27
  %t112 = load i64, ptr %l8, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t110
  store ptr %t117, ptr %t122, !tbaa !39
  br label %bb17
bb17:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t126 = add i64 %t123, 1
  store i64 %t126, ptr %l7, !tbaa !24
  br label %bb13
bb18:
  br label %bb19
bb19:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"std/json:reader", ptr %t128, i32 0, i32 2
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l62, !tbaa !27
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"std/json:reader", ptr %t132, i32 0, i32 3
  %t135 = load i64, ptr %t134, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr ptr, ptr %t140, i64 %t135
  store ptr %a1, ptr %t141, !tbaa !39
  %t142 = load ptr, ptr %l0, !tbaa !29
  store ptr %t142, ptr %l66, !tbaa !29
  %t143 = load ptr, ptr %l66, !tbaa !29
  %t144 = getelementptr %"std/json:reader", ptr %t143, i32 0, i32 3
  %t145 = load i64, ptr %t144, !tbaa !24
  %t148 = add i64 %t145, 1
  %t150 = load ptr, ptr %l66, !tbaa !29
  %t151 = getelementptr %"std/json:reader", ptr %t150, i32 0, i32 3
  store i64 %t148, ptr %t151, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/json:reader", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/json:reader", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call i64 @std_2fjson_2espaceEnd(ptr %v0, { i64, ptr } %t5, i64 %t9)
  store i64 %t12, ptr %l6
  br label %bb1
bb1:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"std/json:reader", ptr %t14, i32 0, i32 1
  store i64 %t13, ptr %t15, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"std/json:Object" } @std_2fjson_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i64
  %l13 = alloca { i64, [2 x i64] }
  %l18 = alloca i64
  %l21 = alloca { i64, ptr }
  %rv = alloca { i32, %"std/json:Object" }
  %t11 = alloca { i64, [2 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp ne i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store { i64, [2 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t11, i32 0, i32 0
  store i64 9, ptr %t12
  %t13 = load { i64, [2 x i64] }, ptr %t11
  store { i64, [2 x i64] } %t13, ptr %l10
  %t14 = call ptr @__olang_errpay_push()
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l11, !tbaa !24
  %t16 = load i64, ptr %l11
  %t17 = inttoptr i64 %t16 to ptr
  %t19 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %t17, ptr %l10)
  store { i64, [2 x i64] } %t19, ptr %l13
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t20 = load { i64, [2 x i64] }, ptr %l13
  %t21 = load i64, ptr %l11
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call ptr @__olang_scope_alloc_a(ptr %t22, i64 24, i64 8)
  store { i64, [2 x i64] } %t20, ptr %t23
  call void @__olang_errpay_set(ptr %t23)
  %t26 = insertvalue { i32, %"std/json:Object" } zeroinitializer, i32 65545, 0
  store { i32, %"std/json:Object" } %t26, ptr %rv
  br label %ret
bb4:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l2, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v2)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l18, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2estd_2fjson_3aObject_2e2
  br i1 %t33, label %bb5, label %bb6
bb5:
  %t35 = call ptr @__olang_region_make(ptr %v2)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t38 = load i64, ptr %l18
  %t39 = inttoptr i64 %t38 to ptr
  %t41 = call { i64, ptr } @std_2fjson_2enameIndex(ptr %v0, ptr %t39, { i64, ptr } %t37)
  store { i64, ptr } %t41, ptr %l21
  br label %bb7
bb7:
  %t42 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t44 = insertvalue %"std/json:Object" undef, { i64, ptr } %t43, 0
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = insertvalue %"std/json:Object" %t44, { i64, ptr } %t45, 1
  %t48 = insertvalue %"std/json:Object" %t46, { i64, ptr } %t42, 2
  %t50 = insertvalue { i32, %"std/json:Object" } zeroinitializer, %"std/json:Object" %t48, 1
  store { i32, %"std/json:Object" } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/json:Object" }, ptr %rv
  ret { i32, %"std/json:Object" } %rr
}

define dso_local %"std/json:writer" @std_2fjson_3awriter_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l7 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/json:writer"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i32 %a1, ptr %l3
  %t5 = call ptr @__olang_scope_hold(ptr %v1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l7, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2estd_2fjson_3awriter_2e2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call ptr @__olang_region_make(ptr %v1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l7
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %t12)
  store %"std/prelude/text:StringBuilder" %t13, ptr %l9
  br label %bb3
bb3:
  %t14 = load i1, ptr @olang_2esole_2estd_2fjson_3awriter_2e2
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i64, ptr %l7
  %t17 = inttoptr i64 %t16 to ptr
  %t18 = getelementptr %"std/prelude/text:StringBuilder", ptr %l9, i32 0, i32 0
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t18, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = call ptr @__olang_region_or(ptr %t21, ptr null)
  %t23 = call ptr @__olang_region_home(ptr %t22)
  %t24 = icmp ne ptr %t23, null
  %t25 = select i1 %t24, ptr %t23, ptr null
  call void @__olang_region_settle_in(ptr %t17, ptr %t25)
  br label %bb5
bb5:
  %t26 = load %"std/prelude/text:StringBuilder", ptr %l9
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = insertvalue %"std/json:writer" undef, { i64, ptr } %t27, 0
  %t29 = load i32, ptr %l3, !range !{i32 0, i32 4}
  %t30 = insertvalue %"std/json:writer" %t28, i32 %t29, 1
  %t32 = insertvalue %"std/json:writer" %t30, %"std/prelude/text:StringBuilder" %t26, 2
  store %"std/json:writer" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"std/json:writer", ptr %rv
  ret %"std/json:writer" %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fjson_3aError_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 10}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 i64 1, label %bb3 i64 2, label %bb4 i64 3, label %bb5 i64 4, label %bb6 i64 5, label %bb7 i64 6, label %bb8 i64 7, label %bb9 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  br label %bb1
bb3:
  br label %bb1
bb4:
  br label %bb1
bb5:
  br label %bb1
bb6:
  br label %bb1
bb7:
  br label %bb1
bb8:
  br label %bb1
bb9:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

declare void @__olang_errpay_set(ptr) cold
declare void @__olang_check_failed(ptr) cold noreturn
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd_2fjson_3aObject_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@olang_2esole_2estd_2fjson_3awriter_2e2 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare %"std/json:reader" @std_2fjson_3areader_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @std_2fjson_2estd_2fjson_3areader_2erun(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fjson_2ekeyInto(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_7a4bfc7c7b524c63_98397af697b8e9df = external constant [0 x i8]
@olang_loc_fa9f38c9682d865a_6f1f2fc1eaeb7f26 = external constant [0 x i8]
declare { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %a0)
@olang_loc_c3fd3a937aadf066_df3562c3c4e6c4da = external constant [0 x i8]
@olang_loc_9bf067a17252b335_30d904505e687d39 = external constant [0 x i8]
@olang_loc_d2781e368edd9e2f_3a33f3735a4c4ba3 = external constant [0 x i8]
@olang_loc_a95109d49c9a5ab2_e7f3aa33cdaf23de = external constant [0 x i8]
declare { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_8fccbc1a4d1c0f20_785a6b4725d4309c = external constant [0 x i8]
declare { i64, ptr } @std_2fjson_2enameIndex(ptr %v0, ptr %v1, { i64, ptr } %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
