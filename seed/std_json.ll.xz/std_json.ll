; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/json:reader" = type { { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64 }
%"std/json:Object" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/json:Position" = type { i64, i64, i64 }
%"std/json:writer" = type { { i64, ptr }, i32, %"std/prelude/text:StringBuilder" }
%"std/json:Key" = type { { i64, ptr } }
%"std/json:Skip" = type { }
@G_2estd_2fjson_2eMaxDepth = constant <{ [8 x i8] }> <{ [8 x i8] c"\E8\03\00\00\00\00\00\00" }>, align 8
@G_2estd_2fjson_2ehexDigits = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00", ptr @G_2estd_2fjson_2ehexDigits.k1 }>, align 8
@G_2estd_2fjson_2ehexDigits.k1 = internal global <{ [16 x i8] }> <{ [16 x i8] c"\30\31\32\33\34\35\36\37\38\39\61\62\63\64\65\66" }>, align 8
define dso_local { i64, ptr } @std_2fjson_2eKeyOf(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !range !{i32 0, i32 4}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t14 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t14, ptr %l7
  br label %bb4
bb4:
  %t15 = load %"std/prelude/text:StringBuilder", ptr %l7
  store %"std/prelude/text:StringBuilder" %t15, ptr %l2
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = load i32, ptr %l1, !range !{i32 0, i32 4}
  call void @std_2fjson_2ekeyInto(ptr %s0, ptr %v0, ptr %l2, { i64, ptr } %t16, i32 %t17)
  br label %bb5
bb5:
  %t22 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t22, ptr %l12
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t23, ptr %l13, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t24, 0
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = mul i64 %t26, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  %t29 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = load i64, ptr %l14, !tbaa !24
  %t36 = mul i64 %t35, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %t34, i64 %t36, i1 false)
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t38 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t38, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, ptr } @std_2fjson_2eParse(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca %"std/json:reader"
  %l7 = alloca i32
  %l8 = alloca i32
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %rv = alloca { i32, ptr }
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/json:reader" @std_2fjson_3areader_2ector(ptr %v0, ptr %v2, { i64, ptr } %a0)
  store %"std/json:reader" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"std/json:reader", ptr %l4
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 112, i64 8)
  store %"std/json:reader" %t4, ptr %t5
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t6, ptr %lp2
  %t8 = load ptr, ptr %lp2
  store ptr %t5, ptr %t8, !tbaa !29
  %t9 = load ptr, ptr %lp2
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i32 @std_2fjson_2estd_2fjson_3areader_2erun(ptr %v2, ptr %t10)
  store i32 %t12, ptr %l7
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb8
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  store i32 %t23, ptr %l8, !tbaa !23
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load ptr, ptr %lp2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eplace(ptr %v2, ptr %v1, ptr %t31, ptr %t32)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  %t35 = load i32, ptr %l8, !tbaa !23
  %t36 = insertvalue { i32, ptr } zeroinitializer, i32 %t35, 0
  store { i32, ptr } %t36, ptr %rv
  br label %ret
bb8:
  %t37 = load ptr, ptr %lp2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"std/json:reader", ptr %t38, i32 0, i32 2
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l15, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  store ptr %t45, ptr %l16, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load ptr, ptr %lp2
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eplace(ptr %v2, ptr %v1, ptr %t53, ptr %t54)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t57 = load ptr, ptr %l16, !tbaa !29
  %t58 = insertvalue { i32, ptr } zeroinitializer, ptr %t57, 1
  store { i32, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @std_2fjson_2ekeyInto(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i8
  %l13 = alloca i8
  %l14 = alloca i8
  %l21 = alloca i8
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l67 = alloca i8
  %l68 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l82 = alloca i1
  %l87 = alloca i1
  %l93 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca i8
  %l101 = alloca i8
  %l103 = alloca i8
  %l106 = alloca ptr
  %l108 = alloca i8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t6, { i64, ptr } %t7)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t10 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t12 = trunc i64 2 to i32
  %t13 = icmp eq i32 %t10, %t12
  br i1 %t13, label %bb5, label %bb6
bb5:
  store i8 95, ptr %l21, !tbaa !22
  br label %bb7
bb6:
  store i8 45, ptr %l21, !tbaa !22
  br label %bb7
bb7:
  %t15 = load i8, ptr %l21, !tbaa !22
  store i8 %t15, ptr %l3, !tbaa !22
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t21 = load i64, ptr %l6, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load i64, ptr %l8, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb13
bb10:
  %t30 = load i64, ptr %l7, !tbaa !24
  %t31 = load i64, ptr %l6, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l8, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l30, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t46 = load i64, ptr %l30, !tbaa !24
  store i64 %t46, ptr %l27, !tbaa !24
  br label %bb13
bb13:
  %t47 = load i64, ptr %l27, !tbaa !24
  store i64 %t47, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t48 = load i64, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l9, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb15, label %bb16
bb15:
  br label %bb69
bb16:
  br label %bb17
bb17:
  %t56 = load i64, ptr %l6, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l11, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t66, ptr %l48, !tbaa !27
  %t67 = load i64, ptr %l11, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i8, ptr %t70, i64 %t67
  %t72 = load i8, ptr %t71, !tbaa !32
  store i8 %t72, ptr %l12, !tbaa !22
  %t74 = load i8, ptr %l12, !tbaa !22
  %t76 = icmp eq i8 %t74, 95
  br i1 %t76, label %bb18, label %bb19
bb18:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb68
bb19:
  br label %bb20
bb20:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb21, label %bb22
bb21:
  %t82 = load i8, ptr %l12, !tbaa !22
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t82)
  store i1 %t84, ptr %l57
  br label %bb23
bb22:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb24
bb23:
  %t85 = load i1, ptr %l57, !tbaa !21
  store i1 %t85, ptr %l55, !tbaa !21
  br label %bb24
bb24:
  %t86 = load i1, ptr %l55, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t87, ptr %l58, !tbaa !27
  %t88 = load i64, ptr %l11, !tbaa !24
  %t90 = sub i64 %t88, 1
  %t92 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i8, ptr %t93, i64 %t90
  %t95 = load i8, ptr %t94, !tbaa !32
  store i8 %t95, ptr %l13, !tbaa !22
  %t97 = load i64, ptr %l11, !tbaa !24
  %t99 = add i64 %t97, 1
  %t100 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t105 = icmp slt i64 %t99, %t102
  br i1 %t105, label %bb27, label %bb28
bb26:
  br label %bb46
bb27:
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l68, !tbaa !27
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = add i64 %t108, 1
  %t112 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  store i8 %t115, ptr %l67, !tbaa !22
  br label %bb29
bb28:
  store i8 32, ptr %l67, !tbaa !22
  br label %bb29
bb29:
  %t117 = load i8, ptr %l67, !tbaa !22
  store i8 %t117, ptr %l14, !tbaa !22
  %t118 = load i8, ptr %l13, !tbaa !22
  %t120 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t118)
  store i1 %t120, ptr %l73
  br label %bb30
bb30:
  %t121 = load i1, ptr %l73, !tbaa !21
  br i1 %t121, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb34
bb32:
  %t122 = load i8, ptr %l13, !tbaa !22
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t122)
  store i1 %t124, ptr %l76
  br label %bb33
bb33:
  %t125 = load i1, ptr %l76, !tbaa !21
  store i1 %t125, ptr %l74, !tbaa !21
  br label %bb34
bb34:
  %t126 = load i1, ptr %l74, !tbaa !21
  br i1 %t126, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb42
bb36:
  %t127 = load i8, ptr %l13, !tbaa !22
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t127)
  store i1 %t129, ptr %l79
  br label %bb37
bb37:
  %t130 = load i1, ptr %l79, !tbaa !21
  br i1 %t130, label %bb38, label %bb39
bb38:
  %t131 = load i8, ptr %l14, !tbaa !22
  %t133 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t131)
  store i1 %t133, ptr %l82
  br label %bb40
bb39:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb41
bb40:
  %t134 = load i1, ptr %l82, !tbaa !21
  store i1 %t134, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t135 = load i1, ptr %l80, !tbaa !21
  store i1 %t135, ptr %l77, !tbaa !21
  br label %bb42
bb42:
  %t136 = load i1, ptr %l77, !tbaa !21
  br i1 %t136, label %bb43, label %bb44
bb43:
  store i64 0, ptr %l5, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t137 = load i64, ptr %l5, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  br i1 %t139, label %bb47, label %bb48
bb47:
  %t141 = load i64, ptr %l4, !tbaa !24
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb49, label %bb50
bb48:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l106, !tbaa !29
  %t146 = load i8, ptr %l12, !tbaa !22
  %t148 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t146)
  store i8 %t148, ptr %l108
  br label %bb65
bb49:
  %t149 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t151 = trunc i64 1 to i32
  %t152 = icmp eq i32 %t149, %t151
  %t154 = xor i1 %t152, true
  store i1 %t154, ptr %l87, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb51
bb51:
  %t156 = load i1, ptr %l87, !tbaa !21
  br i1 %t156, label %bb52, label %bb53
bb52:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i8, ptr %l3, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t157, i8 %t158)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l93, !tbaa !29
  %t162 = load i32, ptr %l2, !range !{i32 0, i32 4}
  %t164 = trunc i64 1 to i32
  %t165 = icmp eq i32 %t162, %t164
  br i1 %t165, label %bb56, label %bb57
bb56:
  %t167 = load i64, ptr %l4, !tbaa !24
  %t169 = icmp sgt i64 %t167, 0
  store i1 %t169, ptr %l96, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb58
bb58:
  %t171 = load i1, ptr %l96, !tbaa !21
  br i1 %t171, label %bb59, label %bb60
bb59:
  %t172 = load i8, ptr %l12, !tbaa !22
  %t174 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t172)
  store i8 %t174, ptr %l101
  br label %bb61
bb60:
  %t175 = load i8, ptr %l12, !tbaa !22
  %t177 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t175)
  store i8 %t177, ptr %l103
  br label %bb62
bb61:
  %t178 = load i8, ptr %l101, !tbaa !22
  store i8 %t178, ptr %l99, !tbaa !22
  br label %bb63
bb62:
  %t179 = load i8, ptr %l103, !tbaa !22
  store i8 %t179, ptr %l99, !tbaa !22
  br label %bb63
bb63:
  %t180 = load ptr, ptr %l93, !tbaa !29
  %t181 = load i8, ptr %l99, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t180, i8 %t181)
  br label %bb64
bb64:
  %t182 = load i64, ptr %l4, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l4, !tbaa !24
  br label %bb67
bb65:
  %t186 = load ptr, ptr %l106, !tbaa !29
  %t187 = load i8, ptr %l108, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t186, i8 %t187)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t188 = load i64, ptr %l5, !tbaa !24
  %t190 = add i64 %t188, 1
  store i64 %t190, ptr %l5, !tbaa !24
  br label %bb68
bb68:
  %t192 = load i64, ptr %l10, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l10, !tbaa !24
  br label %bb14
bb69:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fjson_2enameIndex(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l26 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca i64
  %l63 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l78 = alloca i1
  %l85 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sle i64 %t5, 8
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t11 = icmp sle i64 0, 2305843009213693951
  br i1 %t11, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_bc241580f27121ab_ca64d2d20e518e77)
  unreachable
bb5:
  %t13 = mul i64 0, 4
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_bc241580f27121ab_ca64d2d20e518e77)
  unreachable
bb7:
  store i64 16, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t20 = mul i64 2, %t18
  %t23 = icmp slt i64 %t17, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb9, label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = mul i64 %t27, 2
  store i64 %t29, ptr %l2, !tbaa !24
  br label %bb12
bb12:
  br label %bb8
bb13:
  %t31 = load i64, ptr %l2, !tbaa !24
  store i64 %t31, ptr %l26, !tbaa !24
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb14, label %bb15
bb14:
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = icmp sle i64 %t35, 2305843009213693951
  br i1 %t36, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_19fd7578c5cb7196_ea7f2a837a8496c2)
  unreachable
bb16:
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = mul i64 %t38, 4
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  %t43 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t43, ptr %lp3
  %t45 = load ptr, ptr %lp3
  store { i64, ptr } %t42, ptr %t45, !tbaa !27
  %t46 = load i64, ptr %l2, !tbaa !24
  %t48 = sub i64 %t46, 1
  store i64 %t48, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l1, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = icmp sgt i64 %t52, %t53
  br i1 %t56, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_19fd7578c5cb7196_ea7f2a837a8496c2)
  unreachable
bb18:
  %t58 = load i64, ptr %l7, !tbaa !24
  %t60 = icmp sgt i64 %t58, 0
  br i1 %t60, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb23
bb20:
  %t62 = load i64, ptr %l6, !tbaa !24
  %t63 = load i64, ptr %l5, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = add i64 %t66, %t67
  %t72 = sub i64 %t70, 1
  %t73 = load i64, ptr %l7, !tbaa !24
  %t76 = sdiv i64 %t72, %t73
  store i64 %t76, ptr %l39, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb22
bb22:
  %t78 = load i64, ptr %l39, !tbaa !24
  store i64 %t78, ptr %l36, !tbaa !24
  br label %bb23
bb23:
  %t79 = load i64, ptr %l36, !tbaa !24
  store i64 %t79, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb24
bb24:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb25, label %bb26
bb25:
  br label %bb40
bb26:
  br label %bb27
bb27:
  %t88 = load i64, ptr %l5, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = mul i64 %t89, %t90
  %t96 = add i64 %t88, %t93
  store i64 %t96, ptr %l10, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t98, ptr %l57, !tbaa !27
  %t99 = load i64, ptr %l10, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %t102, i64 %t99
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !37
  %t106 = call i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t104)
  store i64 %t106, ptr %l60
  br label %bb28
bb28:
  %t107 = load i64, ptr %l4, !tbaa !24
  %t108 = load i64, ptr %l60, !tbaa !24
  %t110 = and i64 %t108, %t107
  store i64 %t110, ptr %l11, !tbaa !24
  br label %bb29
bb29:
  %t112 = load ptr, ptr %lp3
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l63, !tbaa !27
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr i32, ptr %t117, i64 %t114
  %t119 = load i32, ptr %t118, !tbaa !33
  %t121 = icmp ne i32 %t119, 0
  br i1 %t121, label %bb30, label %bb31
bb30:
  %t123 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t123, ptr %l68, !tbaa !27
  %t124 = load ptr, ptr %lp3
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l69, !tbaa !27
  %t126 = load i64, ptr %l11, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i32, ptr %t129, i64 %t126
  %t131 = load i32, ptr %t130, !tbaa !33
  %t133 = sext i32 %t131 to i64
  %t135 = sub i64 %t133, 1
  %t137 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %t138, i64 %t135
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !37
  %t141 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t141, ptr %l75, !tbaa !27
  %t142 = load i64, ptr %l10, !tbaa !24
  %t144 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %t145, i64 %t142
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !37
  %t150 = call i1 @std_2fjson_2esameName_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v0, { i64, ptr } %t140, { i64, ptr } %t147)
  store i1 %t150, ptr %l78
  br label %bb32
bb31:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb33
bb32:
  %t151 = load i1, ptr %l78, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l67, !tbaa !21
  br label %bb33
bb33:
  %t154 = load i1, ptr %l67, !tbaa !21
  %t155 = xor i1 %t154, true
  br i1 %t155, label %bb34, label %bb35
bb34:
  br label %bb38
bb35:
  br label %bb36
bb36:
  %t157 = load i64, ptr %l11, !tbaa !24
  %t159 = add i64 %t157, 1
  %t160 = load i64, ptr %l4, !tbaa !24
  %t163 = and i64 %t159, %t160
  store i64 %t163, ptr %l11, !tbaa !24
  br label %bb37
bb37:
  br label %bb29
bb38:
  %t165 = load ptr, ptr %lp3
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  store { i64, ptr } %t166, ptr %l85, !tbaa !27
  %t167 = load i64, ptr %l11, !tbaa !24
  %t168 = load i64, ptr %l10, !tbaa !24
  %t170 = add i64 %t168, 1
  %t172 = trunc i64 %t170 to i32
  %t175 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i32, ptr %t176, i64 %t167
  store i32 %t172, ptr %t177, !tbaa !33
  br label %bb39
bb39:
  %t178 = load i64, ptr %l9, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l9, !tbaa !24
  br label %bb24
bb40:
  %t182 = load ptr, ptr %lp3
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @std_2fjson_2enumEq(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca double
  %l3 = alloca double
  %l4 = alloca i128
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l34 = alloca i128
  %l36 = alloca i128
  %l37 = alloca i32
  %l39 = alloca i128
  %l41 = alloca i128
  %l42 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { double }, ptr %t12, i32 0, i32 0
  %t14 = load double, ptr %t13
  store double %t14, ptr %l2, !tbaa !26
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { double }, ptr %t27, i32 0, i32 0
  %t29 = load double, ptr %t28
  store double %t29, ptr %l3, !tbaa !26
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load double, ptr %l2, !tbaa !26
  %t32 = load double, ptr %l3, !tbaa !26
  %t35 = fcmp oeq double %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_6a96f216a7a18db5_c7851721732fae9)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2a2c934c6745fec4_9721022dc2e60418)
  unreachable
bb22:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb23, label %bb24
bb23:
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 8}
  %t44 = icmp eq i64 %t42, 2
  store i1 %t44, ptr %l22, !tbaa !21
  br label %bb24
bb24:
  %t45 = load i1, ptr %l22, !tbaa !21
  br i1 %t45, label %bb25, label %bb26
bb25:
  br label %bb35
bb26:
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = icmp ne ptr %t47, null
  br i1 %t48, label %bb27, label %bb28
bb27:
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %t50, !range !{i64 0, i64 8}
  %t53 = icmp eq i64 %t51, 3
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb28
bb28:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb31, label %bb32
bb31:
  %t59 = load ptr, ptr %l29, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 8}
  %t62 = icmp eq i64 %t60, 4
  store i1 %t62, ptr %l30, !tbaa !21
  br label %bb32
bb32:
  %t63 = load i1, ptr %l30, !tbaa !21
  br i1 %t63, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_247b9c864b1325ff_f9e87c5eec2e2b33)
  unreachable
bb41:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %t65)
  %t68 = extractvalue { i32, i128 } %t67, 1
  %t69 = extractvalue { i32, i128 } %t67, 0
  store i32 %t69, ptr %l37
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb43, label %ok.71, !prof !99
ok.71:
  store i128 %t68, ptr %l36
  br label %bb42
bb42:
  %t72 = load i128, ptr %l36
  store i128 %t72, ptr %l34
  br label %bb45
bb43:
  br label %bb44
bb44:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb45:
  %t74 = load i128, ptr %l34
  store i128 %t74, ptr %l4
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v1, ptr %t75)
  %t78 = extractvalue { i32, i128 } %t77, 1
  %t79 = extractvalue { i32, i128 } %t77, 0
  store i32 %t79, ptr %l42
  %t80 = icmp ne i32 %t79, 0
  br i1 %t80, label %bb47, label %ok.81, !prof !99
ok.81:
  store i128 %t78, ptr %l41
  br label %bb46
bb46:
  %t82 = load i128, ptr %l41
  store i128 %t82, ptr %l39
  br label %bb49
bb47:
  br label %bb48
bb48:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb49:
  %t84 = load i128, ptr %l39
  %t85 = load i128, ptr %l4
  %t89 = icmp eq i128 %t85, %t84
  store i1 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fjson_2eplainEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i8
  %l10 = alloca { i64, ptr }
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l3, !tbaa !22
  %t21 = load i8, ptr %l3, !tbaa !22
  %t23 = icmp eq i8 %t21, 34
  br i1 %t23, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  %t25 = load i8, ptr %l3, !tbaa !22
  %t27 = icmp eq i8 %t25, 92
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  %t30 = load i8, ptr %l3, !tbaa !22
  %t32 = icmp ult i8 %t30, 32
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t35 = load i8, ptr %l3, !tbaa !22
  %t37 = icmp uge i8 %t35, -128
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t46 = load i64, ptr %l2, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fjson_2eputUtf8(ptr %v0, i64 %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 128
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  br label %bb6
bb3:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load i64, ptr %l1, !tbaa !24
  %t13 = load i64, ptr %l0, !tbaa !24
  %t15 = trunc i64 %t13 to i8
  %t18 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t12
  store i8 %t15, ptr %t20, !tbaa !32
  br label %bb5
bb4:
  br label %bb5
bb5:
  store i64 1, ptr %rv
  br label %ret
bb6:
  %t22 = load i64, ptr %l0, !tbaa !24
  %t24 = icmp slt i64 %t22, 2048
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb9, label %bb10
bb8:
  br label %bb12
bb9:
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  %t34 = load i64, ptr %l0, !tbaa !24
  %t36 = ashr i64 %t34, 6
  %t38 = or i64 192, %t36
  %t40 = trunc i64 %t38 to i8
  %t43 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t33
  store i8 %t40, ptr %t45, !tbaa !32
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t46, ptr %l24, !tbaa !27
  %t47 = load i64, ptr %l1, !tbaa !24
  %t49 = add i64 %t47, 1
  %t50 = load i64, ptr %l0, !tbaa !24
  %t52 = and i64 %t50, 63
  %t54 = or i64 128, %t52
  %t56 = trunc i64 %t54 to i8
  %t59 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t49
  store i8 %t56, ptr %t61, !tbaa !32
  br label %bb11
bb10:
  br label %bb11
bb11:
  store i64 2, ptr %rv
  br label %ret
bb12:
  %t63 = load i64, ptr %l0, !tbaa !24
  %t65 = icmp slt i64 %t63, 65536
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb15, label %bb16
bb14:
  br label %bb18
bb15:
  %t73 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t73, ptr %l37, !tbaa !27
  %t74 = load i64, ptr %l1, !tbaa !24
  %t75 = load i64, ptr %l0, !tbaa !24
  %t77 = ashr i64 %t75, 12
  %t79 = or i64 224, %t77
  %t81 = trunc i64 %t79 to i8
  %t84 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i8, ptr %t85, i64 %t74
  store i8 %t81, ptr %t86, !tbaa !32
  %t87 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t87, ptr %l43, !tbaa !27
  %t88 = load i64, ptr %l1, !tbaa !24
  %t90 = add i64 %t88, 1
  %t91 = load i64, ptr %l0, !tbaa !24
  %t93 = ashr i64 %t91, 6
  %t95 = and i64 %t93, 63
  %t97 = or i64 128, %t95
  %t99 = trunc i64 %t97 to i8
  %t102 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i8, ptr %t103, i64 %t90
  store i8 %t99, ptr %t104, !tbaa !32
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l51, !tbaa !27
  %t106 = load i64, ptr %l1, !tbaa !24
  %t108 = add i64 %t106, 2
  %t109 = load i64, ptr %l0, !tbaa !24
  %t111 = and i64 %t109, 63
  %t113 = or i64 128, %t111
  %t115 = trunc i64 %t113 to i8
  %t118 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 %t108
  store i8 %t115, ptr %t120, !tbaa !32
  br label %bb17
bb16:
  br label %bb17
bb17:
  store i64 3, ptr %rv
  br label %ret
bb18:
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb19, label %bb20
bb19:
  %t128 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t128, ptr %l62, !tbaa !27
  %t129 = load i64, ptr %l1, !tbaa !24
  %t130 = load i64, ptr %l0, !tbaa !24
  %t132 = ashr i64 %t130, 18
  %t134 = or i64 240, %t132
  %t136 = trunc i64 %t134 to i8
  %t139 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t129
  store i8 %t136, ptr %t141, !tbaa !32
  %t142 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t142, ptr %l68, !tbaa !27
  %t143 = load i64, ptr %l1, !tbaa !24
  %t145 = add i64 %t143, 1
  %t146 = load i64, ptr %l0, !tbaa !24
  %t148 = ashr i64 %t146, 12
  %t150 = and i64 %t148, 63
  %t152 = or i64 128, %t150
  %t154 = trunc i64 %t152 to i8
  %t157 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t145
  store i8 %t154, ptr %t159, !tbaa !32
  %t160 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t160, ptr %l76, !tbaa !27
  %t161 = load i64, ptr %l1, !tbaa !24
  %t163 = add i64 %t161, 2
  %t164 = load i64, ptr %l0, !tbaa !24
  %t166 = ashr i64 %t164, 6
  %t168 = and i64 %t166, 63
  %t170 = or i64 128, %t168
  %t172 = trunc i64 %t170 to i8
  %t175 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i8, ptr %t176, i64 %t163
  store i8 %t172, ptr %t177, !tbaa !32
  %t178 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t178, ptr %l84, !tbaa !27
  %t179 = load i64, ptr %l1, !tbaa !24
  %t181 = add i64 %t179, 3
  %t182 = load i64, ptr %l0, !tbaa !24
  %t184 = and i64 %t182, 63
  %t186 = or i64 128, %t184
  %t188 = trunc i64 %t186 to i8
  %t191 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i8, ptr %t192, i64 %t181
  store i8 %t188, ptr %t193, !tbaa !32
  br label %bb21
bb20:
  br label %bb21
bb21:
  store i64 4, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fjson_2espaceEnd(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i8
  %l10 = alloca { i64, ptr }
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %bb18
bb3:
  br label %bb4
bb4:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l10, !tbaa !27
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  store i8 %t19, ptr %l3, !tbaa !22
  %t21 = load i8, ptr %l3, !tbaa !22
  %t23 = icmp ne i8 %t21, 32
  br i1 %t23, label %bb5, label %bb6
bb5:
  %t25 = load i8, ptr %l3, !tbaa !22
  %t27 = icmp ne i8 %t25, 10
  store i1 %t27, ptr %l15, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load i8, ptr %l3, !tbaa !22
  %t32 = icmp ne i8 %t30, 13
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load i8, ptr %l3, !tbaa !22
  %t37 = icmp ne i8 %t35, 9
  store i1 %t37, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l21, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load i64, ptr %l2, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t42 = load i64, ptr %l2, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l2, !tbaa !24
  br label %bb17
bb17:
  br label %bb1
bb18:
  %t46 = load i64, ptr %l2, !tbaa !24
  store i64 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsArr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t16, 1
  store { i32, { i64, ptr } } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65544, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_7a4bfc7c7b524c63_98397af697b8e9df)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i1 } @std_2fjson_2estd_2fjson_3aJson_2eAsBool(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca { i32, i1 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i1 }, ptr %t12, i32 0, i32 0
  %t14 = load i1, ptr %t13
  store i1 %t14, ptr %l1, !tbaa !21
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i1, ptr %l1, !tbaa !21
  %t18 = insertvalue { i32, i1 } zeroinitializer, i1 %t16, 1
  store { i32, i1 } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t20 = insertvalue { i32, i1 } zeroinitializer, i32 65544, 0
  store { i32, i1 } %t20, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_fa9f38c9682d865a_6f1f2fc1eaeb7f26)
  unreachable
ret:
  %rr = load { i32, i1 }, ptr %rv
  ret { i32, i1 } %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsInt(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca i128
  %l4 = alloca i128
  %l5 = alloca i32
  %l10 = alloca i1
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, i128 } %t3, 1
  %t5 = extractvalue { i32, i128 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i128 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i128, ptr %l4
  store i128 %t8, ptr %l2
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, i64 } zeroinitializer, i32 %t17, 0
  store { i32, i64 } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i128, ptr %l2
  store i128 %t20, ptr %l1
  %t21 = load i128, ptr %l1
  %t22 = sext i64 -9223372036854775808 to i128
  %t25 = icmp slt i128 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i128, ptr %l1
  %t28 = sext i64 9223372036854775807 to i128
  %t31 = icmp sgt i128 %t27, %t28
  store i1 %t31, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l10, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = insertvalue { i32, i64 } zeroinitializer, i32 65544, 0
  store { i32, i64 } %t35, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t36 = load i128, ptr %l1
  %t38 = trunc i128 %t36 to i64
  %t40 = insertvalue { i32, i64 } zeroinitializer, i64 %t38, 1
  store { i32, i64 } %t40, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local { i32, double } @std_2fjson_2estd_2fjson_3aJson_2eAsNum(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca double
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %rv = alloca { i32, double }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { double }, ptr %t12, i32 0, i32 0
  %t14 = load double, ptr %t13
  store double %t14, ptr %l1, !tbaa !26
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load double, ptr %l1, !tbaa !26
  %t18 = insertvalue { i32, double } zeroinitializer, double %t16, 1
  store { i32, double } %t18, ptr %rv
  br label %ret
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l11, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { i64 }, ptr %t30, i32 0, i32 0
  %t32 = load i64, ptr %t31
  store i64 %t32, ptr %l2, !tbaa !24
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = sitofp i64 %t34 to double
  %t38 = insertvalue { i32, double } zeroinitializer, double %t36, 1
  store { i32, double } %t38, ptr %rv
  br label %ret
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = load ptr, ptr %l19, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 8}
  %t46 = icmp eq i64 %t44, 4
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l20, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr { i64, [2 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { i64 }, ptr %t50, i32 0, i32 0
  %t52 = load i64, ptr %t51
  store i64 %t52, ptr %l3, !tbaa !65
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t54 = load i64, ptr %l3, !tbaa !65
  %t56 = uitofp i64 %t54 to double
  %t58 = insertvalue { i32, double } zeroinitializer, double %t56, 1
  store { i32, double } %t58, ptr %rv
  br label %ret
bb18:
  br i1 true, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  %t60 = insertvalue { i32, double } zeroinitializer, i32 65544, 0
  store { i32, double } %t60, ptr %rv
  br label %ret
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c3fd3a937aadf066_df3562c3c4e6c4da)
  unreachable
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local { i32, ptr } @std_2fjson_2estd_2fjson_3aJson_2eAsObj(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = insertvalue { i32, ptr } zeroinitializer, ptr %t16, 1
  store { i32, ptr } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 65544, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9bf067a17252b335_30d904505e687d39)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3aJson_2eAsStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load { i64, ptr }, ptr %t13
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t16, 1
  store { i32, { i64, ptr } } %t18, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65544, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d2781e368edd9e2f_3a33f3735a4c4ba3)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3aJson_2eAsUint(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i128
  %l2 = alloca i128
  %l4 = alloca i128
  %l5 = alloca i32
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, i128 } %t3, 1
  %t5 = extractvalue { i32, i128 } %t3, 0
  store i32 %t5, ptr %l5
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store i128 %t4, ptr %l4
  br label %bb1
bb1:
  %t8 = load i128, ptr %l4
  store i128 %t8, ptr %l2
  br label %bb3
bb2:
  %t9 = load i32, ptr %l5, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, i64 } zeroinitializer, i32 %t17, 0
  store { i32, i64 } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load i128, ptr %l2
  store i128 %t20, ptr %l1
  %t21 = load i128, ptr %l1
  %t23 = icmp slt i128 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t26 = insertvalue { i32, i64 } zeroinitializer, i32 65544, 0
  store { i32, i64 } %t26, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load i128, ptr %l1
  %t29 = trunc i128 %t27 to i64
  %t31 = insertvalue { i32, i64 } zeroinitializer, i64 %t29, 1
  store { i32, i64 } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aJson_2eEq(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l77 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i1
  %l102 = alloca i64
  %l105 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l129 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca i1
  %l149 = alloca i64
  %l151 = alloca i64
  %l155 = alloca i64
  %l159 = alloca i64
  %l162 = alloca i64
  %l180 = alloca i64
  %l183 = alloca { i64, ptr }
  %l186 = alloca i64
  %l187 = alloca i32
  %l189 = alloca i64
  %l192 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca i32
  %l199 = alloca { i64, ptr }
  %l203 = alloca { i64, ptr }
  %l206 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t2 = load ptr, ptr %l24, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l24, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l25, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l25, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t11 = load ptr, ptr %l28, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l28, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t18 = load i1, ptr %l29, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t20 = load ptr, ptr %l32, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l32, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 1
  store i1 %t26, ptr %l33, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l33, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { i1 }, ptr %t30, i32 0, i32 0
  %t32 = load i1, ptr %t31
  store i1 %t32, ptr %l2, !tbaa !21
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t35 = load ptr, ptr %l38, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l38, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 8}
  %t41 = icmp eq i64 %t39, 1
  store i1 %t41, ptr %l39, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l39, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [2 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { i1 }, ptr %t45, i32 0, i32 0
  %t47 = load i1, ptr %t46
  store i1 %t47, ptr %l3, !tbaa !21
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t49 = load i1, ptr %l2, !tbaa !21
  %t50 = load i1, ptr %l3, !tbaa !21
  %t53 = icmp eq i1 %t49, %t50
  store i1 %t53, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a7b0a92300089828_a6e8a6d400231804)
  unreachable
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t60 = load ptr, ptr %l48, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 2
  store i1 %t63, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t64 = load i1, ptr %l49, !tbaa !21
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb37
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t66 = load ptr, ptr %l52, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb29, label %bb30
bb29:
  %t69 = load ptr, ptr %l52, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 3
  store i1 %t72, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t73 = load i1, ptr %l53, !tbaa !21
  br i1 %t73, label %bb31, label %bb32
bb31:
  br label %bb37
bb32:
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t75 = load ptr, ptr %l56, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb33, label %bb34
bb33:
  %t78 = load ptr, ptr %l56, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 8}
  %t81 = icmp eq i64 %t79, 4
  store i1 %t81, ptr %l57, !tbaa !21
  br label %bb34
bb34:
  %t82 = load i1, ptr %l57, !tbaa !21
  br i1 %t82, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t87 = call i1 @std_2fjson_2enumEq(ptr %v0, ptr %v1, ptr %t83, ptr %t84)
  store i1 %t87, ptr %l62
  br label %bb38
bb38:
  %t88 = load i1, ptr %l62, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb39:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t90 = load ptr, ptr %l63, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb40, label %bb41
bb40:
  %t93 = load ptr, ptr %l63, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 5
  store i1 %t96, ptr %l64, !tbaa !21
  br label %bb41
bb41:
  %t97 = load i1, ptr %l64, !tbaa !21
  br i1 %t97, label %bb42, label %bb43
bb42:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { { i64, ptr } }, ptr %t100, i32 0, i32 0
  %t102 = load { i64, ptr }, ptr %t101
  store { i64, ptr } %t102, ptr %l4, !tbaa !27
  br label %bb44
bb43:
  br label %bb56
bb44:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t105 = load ptr, ptr %l69, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb45, label %bb46
bb45:
  %t108 = load ptr, ptr %l69, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l70, !tbaa !21
  br label %bb46
bb46:
  %t112 = load i1, ptr %l70, !tbaa !21
  br i1 %t112, label %bb47, label %bb48
bb47:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [2 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { { i64, ptr } }, ptr %t115, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116
  store { i64, ptr } %t117, ptr %l5, !tbaa !27
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t123 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t119, { i64, ptr } %t120)
  store i1 %t123, ptr %l77
  br label %bb50
bb50:
  %t124 = load i1, ptr %l77, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
bb51:
  br i1 true, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  store i1 false, ptr %rv
  br label %ret
bb55:
  call void @__olang_check_failed(ptr @olang_loc_a07ba4d7ff0a56f9_d8356302010b83f5)
  unreachable
bb56:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t127 = load ptr, ptr %l79, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb57, label %bb58
bb57:
  %t130 = load ptr, ptr %l79, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 8}
  %t133 = icmp eq i64 %t131, 6
  store i1 %t133, ptr %l80, !tbaa !21
  br label %bb58
bb58:
  %t134 = load i1, ptr %l80, !tbaa !21
  br i1 %t134, label %bb59, label %bb60
bb59:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr { i64, [2 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { { i64, ptr } }, ptr %t137, i32 0, i32 0
  %t139 = load { i64, ptr }, ptr %t138
  store { i64, ptr } %t139, ptr %l6, !tbaa !27
  br label %bb61
bb60:
  br label %bb91
bb61:
  %t141 = load ptr, ptr %l1, !tbaa !29
  store ptr %t141, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t142 = load ptr, ptr %l85, !tbaa !29
  %t143 = icmp ne ptr %t142, null
  br i1 %t143, label %bb62, label %bb63
bb62:
  %t145 = load ptr, ptr %l85, !tbaa !29
  %t146 = load i64, ptr %t145, !range !{i64 0, i64 8}
  %t148 = icmp eq i64 %t146, 6
  store i1 %t148, ptr %l86, !tbaa !21
  br label %bb63
bb63:
  %t149 = load i1, ptr %l86, !tbaa !21
  br i1 %t149, label %bb64, label %bb65
bb64:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t152 = getelementptr { i64, [2 x i64] }, ptr %t150, i32 0, i32 1
  %t153 = getelementptr { { i64, ptr } }, ptr %t152, i32 0, i32 0
  %t154 = load { i64, ptr }, ptr %t153
  store { i64, ptr } %t154, ptr %l7, !tbaa !27
  br label %bb66
bb65:
  br label %bb86
bb66:
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t164 = icmp ne i64 %t158, %t161
  br i1 %t164, label %bb67, label %bb68
bb67:
  store i1 false, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  store i64 0, ptr %l8, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t171 = load i64, ptr %l9, !tbaa !24
  %t172 = load i64, ptr %l8, !tbaa !24
  %t175 = icmp sgt i64 %t171, %t172
  br i1 %t175, label %bb70, label %bb71
bb70:
  %t177 = load i64, ptr %l10, !tbaa !24
  %t179 = icmp sgt i64 %t177, 0
  br i1 %t179, label %bb72, label %bb73
bb71:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb75
bb72:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t182 = load i64, ptr %l8, !tbaa !24
  %t185 = sub i64 %t181, %t182
  %t186 = load i64, ptr %l10, !tbaa !24
  %t189 = add i64 %t185, %t186
  %t191 = sub i64 %t189, 1
  %t192 = load i64, ptr %l10, !tbaa !24
  %t195 = sdiv i64 %t191, %t192
  store i64 %t195, ptr %l105, !tbaa !24
  br label %bb74
bb73:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb74
bb74:
  %t197 = load i64, ptr %l105, !tbaa !24
  store i64 %t197, ptr %l102, !tbaa !24
  br label %bb75
bb75:
  %t198 = load i64, ptr %l102, !tbaa !24
  store i64 %t198, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb76
bb76:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l11, !tbaa !24
  %t203 = icmp slt i64 %t199, %t200
  %t205 = xor i1 %t203, true
  br i1 %t205, label %bb77, label %bb78
bb77:
  br label %bb85
bb78:
  br label %bb79
bb79:
  %t207 = load i64, ptr %l8, !tbaa !24
  %t208 = load i64, ptr %l12, !tbaa !24
  %t209 = load i64, ptr %l10, !tbaa !24
  %t212 = mul i64 %t208, %t209
  %t215 = add i64 %t207, %t212
  store i64 %t215, ptr %l13, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t217, ptr %l123, !tbaa !27
  %t218 = load i64, ptr %l13, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 %t218
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t224 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t224, ptr %l126, !tbaa !27
  %t225 = load i64, ptr %l13, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr ptr, ptr %t228, i64 %t225
  %t230 = load ptr, ptr %t229, !tbaa !39
  %t233 = call i1 @std_2fjson_2estd_2fjson_3aJson_2eEq(ptr %v0, ptr %v1, ptr %t223, ptr %t230)
  store i1 %t233, ptr %l129
  br label %bb80
bb80:
  %t234 = load i1, ptr %l129, !tbaa !21
  %t235 = xor i1 %t234, true
  br i1 %t235, label %bb81, label %bb82
bb81:
  store i1 false, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t238 = load i64, ptr %l12, !tbaa !24
  %t240 = add i64 %t238, 1
  store i64 %t240, ptr %l12, !tbaa !24
  br label %bb76
bb85:
  store i1 true, ptr %rv
  br label %ret
bb86:
  br i1 true, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb90
bb89:
  store i1 false, ptr %rv
  br label %ret
bb90:
  call void @__olang_check_failed(ptr @olang_loc_22f1698915dd4682_a0313dce564b9a3e)
  unreachable
bb91:
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t245 = load ptr, ptr %l136, !tbaa !29
  %t246 = icmp ne ptr %t245, null
  br i1 %t246, label %bb92, label %bb93
bb92:
  %t248 = load ptr, ptr %l136, !tbaa !29
  %t249 = load i64, ptr %t248, !range !{i64 0, i64 8}
  %t251 = icmp eq i64 %t249, 7
  store i1 %t251, ptr %l137, !tbaa !21
  br label %bb93
bb93:
  %t252 = load i1, ptr %l137, !tbaa !21
  br i1 %t252, label %bb94, label %bb95
bb94:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr { i64, [2 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { ptr }, ptr %t255, i32 0, i32 0
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l14, !tbaa !29
  br label %bb96
bb95:
  br label %bb137
bb96:
  %t259 = load ptr, ptr %l1, !tbaa !29
  store ptr %t259, ptr %l142, !tbaa !29
  store i1 false, ptr %l143, !tbaa !21
  %t260 = load ptr, ptr %l142, !tbaa !29
  %t261 = icmp ne ptr %t260, null
  br i1 %t261, label %bb97, label %bb98
bb97:
  %t263 = load ptr, ptr %l142, !tbaa !29
  %t264 = load i64, ptr %t263, !range !{i64 0, i64 8}
  %t266 = icmp eq i64 %t264, 7
  store i1 %t266, ptr %l143, !tbaa !21
  br label %bb98
bb98:
  %t267 = load i1, ptr %l143, !tbaa !21
  br i1 %t267, label %bb99, label %bb100
bb99:
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr { i64, [2 x i64] }, ptr %t268, i32 0, i32 1
  %t271 = getelementptr { ptr }, ptr %t270, i32 0, i32 0
  %t272 = load ptr, ptr %t271
  store ptr %t272, ptr %l15, !tbaa !29
  br label %bb101
bb100:
  br label %bb132
bb101:
  %t274 = load ptr, ptr %l14, !tbaa !29
  %t276 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t274)
  store i64 %t276, ptr %l149
  br label %bb102
bb102:
  %t277 = load ptr, ptr %l15, !tbaa !29
  %t279 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t277)
  store i64 %t279, ptr %l151
  br label %bb103
bb103:
  %t280 = load i64, ptr %l149, !tbaa !24
  %t281 = load i64, ptr %l151, !tbaa !24
  %t282 = icmp ne i64 %t280, %t281
  br i1 %t282, label %bb104, label %bb105
bb104:
  store i1 false, ptr %rv
  br label %ret
bb105:
  br label %bb106
bb106:
  store i64 0, ptr %l16, !tbaa !24
  %t285 = load ptr, ptr %l14, !tbaa !29
  %t287 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t285)
  store i64 %t287, ptr %l155
  br label %bb107
bb107:
  %t288 = load i64, ptr %l155, !tbaa !24
  store i64 %t288, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t290 = load i64, ptr %l16, !tbaa !24
  %t293 = icmp sgt i64 %t289, %t290
  br i1 %t293, label %bb108, label %bb109
bb108:
  %t295 = load i64, ptr %l18, !tbaa !24
  %t297 = icmp sgt i64 %t295, 0
  br i1 %t297, label %bb110, label %bb111
bb109:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb113
bb110:
  %t299 = load i64, ptr %l17, !tbaa !24
  %t300 = load i64, ptr %l16, !tbaa !24
  %t303 = sub i64 %t299, %t300
  %t304 = load i64, ptr %l18, !tbaa !24
  %t307 = add i64 %t303, %t304
  %t309 = sub i64 %t307, 1
  %t310 = load i64, ptr %l18, !tbaa !24
  %t313 = sdiv i64 %t309, %t310
  store i64 %t313, ptr %l162, !tbaa !24
  br label %bb112
bb111:
  store i64 0, ptr %l162, !tbaa !24
  br label %bb112
bb112:
  %t315 = load i64, ptr %l162, !tbaa !24
  store i64 %t315, ptr %l159, !tbaa !24
  br label %bb113
bb113:
  %t316 = load i64, ptr %l159, !tbaa !24
  store i64 %t316, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb114
bb114:
  %t317 = load i64, ptr %l20, !tbaa !24
  %t318 = load i64, ptr %l19, !tbaa !24
  %t321 = icmp slt i64 %t317, %t318
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb115, label %bb116
bb115:
  br label %bb131
bb116:
  br label %bb117
bb117:
  %t325 = load i64, ptr %l16, !tbaa !24
  %t326 = load i64, ptr %l20, !tbaa !24
  %t327 = load i64, ptr %l18, !tbaa !24
  %t330 = mul i64 %t326, %t327
  %t333 = add i64 %t325, %t330
  store i64 %t333, ptr %l21, !tbaa !24
  %t335 = load ptr, ptr %l15, !tbaa !29
  %t336 = load ptr, ptr %l14, !tbaa !29
  %t338 = getelementptr %"std/json:Object", ptr %t336, i32 0, i32 0
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  store { i64, ptr } %t339, ptr %l183, !tbaa !27
  %t340 = load i64, ptr %l21, !tbaa !24
  %t342 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %t343, i64 %t340
  %t345 = load { i64, ptr }, ptr %t344, !tbaa !37
  %t348 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1, ptr %v0, ptr %t335, { i64, ptr } %t345)
  %t349 = extractvalue { i32, i64 } %t348, 1
  %t350 = extractvalue { i32, i64 } %t348, 0
  store i32 %t350, ptr %l187
  %t351 = icmp ne i32 %t350, 0
  br i1 %t351, label %bb119, label %ok.352, !prof !99
ok.352:
  store i64 %t349, ptr %l186
  br label %bb118
bb118:
  %t353 = load i64, ptr %l186, !tbaa !24
  store i64 %t353, ptr %l180, !tbaa !24
  br label %bb121
bb119:
  br label %bb120
bb120:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb121:
  %t355 = load i64, ptr %l180, !tbaa !24
  store i64 %t355, ptr %l22, !tbaa !24
  %t356 = load ptr, ptr %l14, !tbaa !29
  %t357 = load ptr, ptr %l14, !tbaa !29
  %t359 = getelementptr %"std/json:Object", ptr %t357, i32 0, i32 0
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  store { i64, ptr } %t360, ptr %l192, !tbaa !27
  %t361 = load i64, ptr %l21, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l192, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr { i64, ptr }, ptr %t364, i64 %t361
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !37
  %t369 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v0, ptr %t356, { i64, ptr } %t366)
  %t370 = extractvalue { i32, i64 } %t369, 1
  %t371 = extractvalue { i32, i64 } %t369, 0
  store i32 %t371, ptr %l196
  %t372 = icmp ne i32 %t371, 0
  br i1 %t372, label %bb123, label %ok.373, !prof !99
ok.373:
  store i64 %t370, ptr %l195
  br label %bb122
bb122:
  %t374 = load i64, ptr %l195, !tbaa !24
  store i64 %t374, ptr %l189, !tbaa !24
  br label %bb125
bb123:
  br label %bb124
bb124:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb125:
  %t376 = load i64, ptr %l189, !tbaa !24
  %t377 = load ptr, ptr %l14, !tbaa !29
  %t379 = getelementptr %"std/json:Object", ptr %t377, i32 0, i32 1
  %t380 = load { i64, ptr }, ptr %t379, !tbaa !27
  store { i64, ptr } %t380, ptr %l199, !tbaa !27
  %t383 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !27
  %t385 = getelementptr ptr, ptr %t384, i64 %t376
  %t386 = load ptr, ptr %t385, !tbaa !39
  %t387 = load ptr, ptr %l15, !tbaa !29
  %t389 = getelementptr %"std/json:Object", ptr %t387, i32 0, i32 1
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !27
  store { i64, ptr } %t390, ptr %l203, !tbaa !27
  %t391 = load i64, ptr %l22, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr ptr, ptr %t394, i64 %t391
  %t396 = load ptr, ptr %t395, !tbaa !39
  %t399 = call i1 @std_2fjson_2estd_2fjson_3aJson_2eEq(ptr %v0, ptr %v1, ptr %t386, ptr %t396)
  store i1 %t399, ptr %l206
  br label %bb126
bb126:
  %t400 = load i1, ptr %l206, !tbaa !21
  %t401 = xor i1 %t400, true
  br i1 %t401, label %bb127, label %bb128
bb127:
  store i1 false, ptr %rv
  br label %ret
bb128:
  br label %bb129
bb129:
  br label %bb130
bb130:
  %t404 = load i64, ptr %l20, !tbaa !24
  %t406 = add i64 %t404, 1
  store i64 %t406, ptr %l20, !tbaa !24
  br label %bb114
bb131:
  store i1 true, ptr %rv
  br label %ret
bb132:
  br i1 true, label %bb133, label %bb134
bb133:
  br label %bb135
bb134:
  br label %bb136
bb135:
  store i1 false, ptr %rv
  br label %ret
bb136:
  call void @__olang_check_failed(ptr @olang_loc_e7435678738af803_3f3d624b6ec28d3f)
  unreachable
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  store i1 false, ptr %rv
  br label %ret
bb141:
  call void @__olang_check_failed(ptr @olang_loc_cd6f075822d3ba64_2e9ce5061183e548)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aJson_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i1 @std_2fjson_2estd_2fjson_3aObject_2eHas(ptr %v0, ptr %v1, ptr %t16, { i64, ptr } %a1)
  store i1 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i1, ptr %l11, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %rv
  br label %ret
bb11:
  call void @__olang_check_failed(ptr @olang_loc_a95109d49c9a5ab2_e7f3aa33cdaf23de)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca double
  %l3 = alloca i128
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca double
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca i128
  %l58 = alloca i128
  %l59 = alloca i32
  %l64 = alloca i128
  %l73 = alloca i1
  %l79 = alloca double
  %l85 = alloca i64
  %l88 = alloca i64
  %l90 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i1
  %l99 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i1
  %l113 = alloca { i64, ptr }
  %l117 = alloca i64
  %l119 = alloca i64
  %l124 = alloca ptr
  %l125 = alloca i1
  %l131 = alloca i64
  %l135 = alloca i64
  %l138 = alloca i64
  %l156 = alloca i64
  %l158 = alloca { i64, ptr }
  %l161 = alloca i64
  %l163 = alloca { i64, ptr }
  %l166 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i64
  %t124 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i64 1, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t12 = load ptr, ptr %l27, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l27, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 1
  store i1 %t18, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l28, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { i1 }, ptr %t22, i32 0, i32 0
  %t24 = load i1, ptr %t23
  store i1 %t24, ptr %l1, !tbaa !21
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t26 = load i1, ptr %l1, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  store i64 2, ptr %l34, !tbaa !24
  br label %bb14
bb13:
  store i64 3, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t28 = load i64, ptr %l34, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
bb15:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t30 = load ptr, ptr %l35, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb16, label %bb17
bb16:
  %t33 = load ptr, ptr %l35, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t37 = load i1, ptr %l36, !tbaa !21
  br i1 %t37, label %bb18, label %bb19
bb18:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { double }, ptr %t40, i32 0, i32 0
  %t42 = load double, ptr %t41
  store double %t42, ptr %l2, !tbaa !26
  br label %bb20
bb19:
  br label %bb24
bb20:
  %t44 = load double, ptr %l2, !tbaa !26
  %t46 = fcmp oeq double %t44, 0x0000000000000000
  br i1 %t46, label %bb21, label %bb22
bb21:
  store i64 4, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t49 = load double, ptr %l2, !tbaa !26
  %t51 = bitcast double %t49 to i64
  %t54 = mul i64 %t51, 1099511628211
  store i64 %t54, ptr %rv
  br label %ret
bb24:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb25, label %bb26
bb25:
  %t60 = load ptr, ptr %l48, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 8}
  %t63 = icmp eq i64 %t61, 3
  store i1 %t63, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t64 = load i1, ptr %l49, !tbaa !21
  br i1 %t64, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t66 = load ptr, ptr %l52, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb29, label %bb30
bb29:
  %t69 = load ptr, ptr %l52, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t73 = load i1, ptr %l53, !tbaa !21
  br i1 %t73, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb54
bb33:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %t74)
  %t77 = extractvalue { i32, i128 } %t76, 1
  %t78 = extractvalue { i32, i128 } %t76, 0
  store i32 %t78, ptr %l59
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb35, label %ok.80, !prof !99
ok.80:
  store i128 %t77, ptr %l58
  br label %bb34
bb34:
  %t81 = load i128, ptr %l58
  store i128 %t81, ptr %l56
  br label %bb37
bb35:
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %rv
  br label %ret
bb37:
  %t83 = load i128, ptr %l56
  store i128 %t83, ptr %l3
  %t84 = load i128, ptr %l3
  %t86 = icmp slt i128 %t84, 0
  store i1 %t86, ptr %l4, !tbaa !21
  %t88 = load i1, ptr %l4, !tbaa !21
  br i1 %t88, label %bb38, label %bb39
bb38:
  %t90 = load i128, ptr %l3
  %t92 = sub i128 0, %t90
  store i128 %t92, ptr %l64
  br label %bb40
bb39:
  %t94 = load i128, ptr %l3
  store i128 %t94, ptr %l64
  br label %bb40
bb40:
  %t96 = load i128, ptr %l64
  %t97 = trunc i128 %t96 to i64
  store i64 %t97, ptr %l5, !tbaa !65
  %t99 = load i64, ptr %l5, !tbaa !65
  %t101 = uitofp i64 %t99 to double
  store double %t101, ptr %l6, !tbaa !26
  %t103 = load double, ptr %l6, !tbaa !26
  %t105 = fcmp olt double %t103, 0x43f0000000000000
  br i1 %t105, label %bb41, label %bb42
bb41:
  %t107 = load double, ptr %l6, !tbaa !26
  %t109 = fptoui double %t107 to i64
  %t110 = load i64, ptr %l5, !tbaa !65
  %t113 = icmp eq i64 %t109, %t110
  store i1 %t113, ptr %l73, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb43
bb43:
  %t115 = load i1, ptr %l73, !tbaa !21
  br i1 %t115, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t116 = load i1, ptr %l4, !tbaa !21
  br i1 %t116, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  %t118 = load double, ptr %l6, !tbaa !26
  %t120 = fneg double %t118
  store double %t120, ptr %l79, !tbaa !26
  br label %bb48
bb47:
  %t122 = load double, ptr %l6, !tbaa !26
  store double %t122, ptr %l79, !tbaa !26
  br label %bb48
bb48:
  store { i64, [2 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [2 x i64] }, ptr %t124, i32 0, i32 0
  store i64 2, ptr %t125
  %t126 = load double, ptr %l79, !tbaa !26
  %t127 = insertvalue { double } undef, double %t126, 0
  %t128 = getelementptr { i64, [2 x i64] }, ptr %t124, i32 0, i32 1
  store { double } %t127, ptr %t128
  %t129 = load { i64, [2 x i64] }, ptr %t124
  %t131 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 24, i64 8)
  store { i64, [2 x i64] } %t129, ptr %t131
  %t133 = call i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %s7, ptr %t131)
  store i64 %t133, ptr %l85
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  %t134 = load i64, ptr %l85, !tbaa !24
  store i64 %t134, ptr %rv
  br label %ret
bb50:
  %t135 = load i64, ptr %l5, !tbaa !65
  %t138 = mul i64 %t135, 1099511628211
  store i64 %t138, ptr %l88, !tbaa !24
  %t139 = load i1, ptr %l4, !tbaa !21
  br i1 %t139, label %bb51, label %bb52
bb51:
  store i64 7, ptr %l90, !tbaa !24
  br label %bb53
bb52:
  store i64 9, ptr %l90, !tbaa !24
  br label %bb53
bb53:
  %t141 = load i64, ptr %l88, !tbaa !24
  %t142 = load i64, ptr %l90, !tbaa !24
  %t143 = add i64 %t141, %t142
  store i64 %t143, ptr %rv
  br label %ret
bb54:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l92, !tbaa !29
  store i1 false, ptr %l93, !tbaa !21
  %t146 = load ptr, ptr %l92, !tbaa !29
  %t147 = icmp ne ptr %t146, null
  br i1 %t147, label %bb55, label %bb56
bb55:
  %t149 = load ptr, ptr %l92, !tbaa !29
  %t150 = load i64, ptr %t149, !range !{i64 0, i64 8}
  %t152 = icmp eq i64 %t150, 5
  store i1 %t152, ptr %l93, !tbaa !21
  br label %bb56
bb56:
  %t153 = load i1, ptr %l93, !tbaa !21
  br i1 %t153, label %bb57, label %bb58
bb57:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr { i64, [2 x i64] }, ptr %t154, i32 0, i32 1
  %t157 = getelementptr { { i64, ptr } }, ptr %t156, i32 0, i32 0
  %t158 = load { i64, ptr }, ptr %t157
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t162 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %t160)
  store i64 %t162, ptr %l99
  br label %bb60
bb60:
  %t163 = load i64, ptr %l99, !tbaa !24
  store i64 %t163, ptr %rv
  br label %ret
bb61:
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t165 = load ptr, ptr %l100, !tbaa !29
  %t166 = icmp ne ptr %t165, null
  br i1 %t166, label %bb62, label %bb63
bb62:
  %t168 = load ptr, ptr %l100, !tbaa !29
  %t169 = load i64, ptr %t168, !range !{i64 0, i64 8}
  %t171 = icmp eq i64 %t169, 6
  store i1 %t171, ptr %l101, !tbaa !21
  br label %bb63
bb63:
  %t172 = load i1, ptr %l101, !tbaa !21
  br i1 %t172, label %bb64, label %bb65
bb64:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [2 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { { i64, ptr } }, ptr %t175, i32 0, i32 0
  %t177 = load { i64, ptr }, ptr %t176
  store { i64, ptr } %t177, ptr %l8, !tbaa !27
  br label %bb66
bb65:
  br label %bb74
bb66:
  store i64 5, ptr %l9, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t179, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t181 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l12, !tbaa !24
  br label %bb67
bb67:
  %t185 = load i64, ptr %l11, !tbaa !24
  %t186 = load i64, ptr %l12, !tbaa !24
  %t189 = icmp slt i64 %t185, %t186
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb68, label %bb69
bb68:
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t193 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t193, ptr %l113, !tbaa !27
  %t194 = load i64, ptr %l11, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr ptr, ptr %t197, i64 %t194
  %t199 = load ptr, ptr %t198, !tbaa !39
  %t201 = load i64, ptr %l9, !tbaa !24
  %t203 = mul i64 %t201, 31
  store i64 %t203, ptr %l117, !tbaa !24
  %t206 = call i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %v0, ptr %t199)
  store i64 %t206, ptr %l119
  br label %bb71
bb71:
  %t207 = load i64, ptr %l117, !tbaa !24
  %t208 = load i64, ptr %l119, !tbaa !24
  %t209 = add i64 %t207, %t208
  store i64 %t209, ptr %l9, !tbaa !24
  br label %bb72
bb72:
  %t211 = load i64, ptr %l11, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l11, !tbaa !24
  br label %bb67
bb73:
  %t215 = load i64, ptr %l9, !tbaa !24
  store i64 %t215, ptr %rv
  br label %ret
bb74:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t218 = load ptr, ptr %l124, !tbaa !29
  %t219 = icmp ne ptr %t218, null
  br i1 %t219, label %bb75, label %bb76
bb75:
  %t221 = load ptr, ptr %l124, !tbaa !29
  %t222 = load i64, ptr %t221, !range !{i64 0, i64 8}
  %t224 = icmp eq i64 %t222, 7
  store i1 %t224, ptr %l125, !tbaa !21
  br label %bb76
bb76:
  %t225 = load i1, ptr %l125, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb77:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [2 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { ptr }, ptr %t228, i32 0, i32 0
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l14, !tbaa !29
  br label %bb79
bb78:
  br label %bb95
bb79:
  store i64 6, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t232 = load ptr, ptr %l14, !tbaa !29
  %t234 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %t232)
  store i64 %t234, ptr %l131
  br label %bb80
bb80:
  %t235 = load i64, ptr %l131, !tbaa !24
  store i64 %t235, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t236 = load i64, ptr %l17, !tbaa !24
  %t237 = load i64, ptr %l16, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb81, label %bb82
bb81:
  %t242 = load i64, ptr %l18, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb83, label %bb84
bb82:
  store i64 0, ptr %l135, !tbaa !24
  br label %bb86
bb83:
  %t246 = load i64, ptr %l17, !tbaa !24
  %t247 = load i64, ptr %l16, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l18, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l138, !tbaa !24
  br label %bb85
bb84:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb85
bb85:
  %t262 = load i64, ptr %l138, !tbaa !24
  store i64 %t262, ptr %l135, !tbaa !24
  br label %bb86
bb86:
  %t263 = load i64, ptr %l135, !tbaa !24
  store i64 %t263, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb87
bb87:
  %t264 = load i64, ptr %l20, !tbaa !24
  %t265 = load i64, ptr %l19, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb88, label %bb89
bb88:
  br label %bb94
bb89:
  br label %bb90
bb90:
  %t272 = load i64, ptr %l16, !tbaa !24
  %t273 = load i64, ptr %l20, !tbaa !24
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l21, !tbaa !24
  %t282 = load i64, ptr %l15, !tbaa !24
  store i64 %t282, ptr %l156, !tbaa !24
  %t283 = load ptr, ptr %l14, !tbaa !29
  %t285 = getelementptr %"std/json:Object", ptr %t283, i32 0, i32 0
  %t286 = load { i64, ptr }, ptr %t285, !tbaa !27
  store { i64, ptr } %t286, ptr %l158, !tbaa !27
  %t287 = load i64, ptr %l21, !tbaa !24
  %t289 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr { i64, ptr }, ptr %t290, i64 %t287
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !37
  %t294 = call i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %t292)
  store i64 %t294, ptr %l161
  br label %bb91
bb91:
  %t295 = load ptr, ptr %l14, !tbaa !29
  %t297 = getelementptr %"std/json:Object", ptr %t295, i32 0, i32 1
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l163, !tbaa !27
  %t299 = load i64, ptr %l21, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr ptr, ptr %t302, i64 %t299
  %t304 = load ptr, ptr %t303, !tbaa !39
  %t306 = call i64 @std_2fjson_2estd_2fjson_3aJson_2eHash(ptr %v0, ptr %t304)
  store i64 %t306, ptr %l166
  br label %bb92
bb92:
  %t307 = load i64, ptr %l161, !tbaa !24
  %t308 = load i64, ptr %l166, !tbaa !24
  %t309 = xor i64 %t307, %t308
  %t311 = mul i64 %t309, 1099511628211
  %t312 = load i64, ptr %l156, !tbaa !24
  %t314 = add i64 %t312, %t311
  store i64 %t314, ptr %l15, !tbaa !24
  br label %bb93
bb93:
  %t316 = load i64, ptr %l20, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l20, !tbaa !24
  br label %bb87
bb94:
  %t320 = load i64, ptr %l15, !tbaa !24
  store i64 %t320, ptr %rv
  br label %ret
bb95:
  br i1 true, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb99
bb98:
  store i64 0, ptr %rv
  br label %ret
bb99:
  call void @__olang_check_failed(ptr @olang_loc_664da5dbc2e51de6_83a7e6ee135f5f2a)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aJson_2eIsNull(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @std_2fjson_2estd_2fjson_3aJson_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v1, ptr %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, i32 0)
  store { i64, ptr } %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l6, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t19, ptr %l4, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, i128 } @std_2fjson_2estd_2fjson_3aJson_2ewhole(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca double
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %rv = alloca { i32, i128 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { double }, ptr %t12, i32 0, i32 0
  %t14 = load double, ptr %t13
  store double %t14, ptr %l1, !tbaa !26
  br label %bb5
bb4:
  br label %bb24
bb5:
  %t16 = load double, ptr %l1, !tbaa !26
  %t17 = load double, ptr %l1, !tbaa !26
  %t20 = fcmp une double %t16, %t17
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  %t22 = load double, ptr %l1, !tbaa !26
  %t23 = load double, ptr %l1, !tbaa !26
  %t26 = fsub double %t22, %t23
  %t28 = fcmp une double %t26, 0x0000000000000000
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l13, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb11
bb10:
  %t31 = load double, ptr %l1, !tbaa !26
  %t33 = fcmp oge double %t31, 0x43f0000000000000
  store i1 %t33, ptr %l18, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l18, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t36 = load double, ptr %l1, !tbaa !26
  %t38 = fcmp olt double %t36, 0xc3e0000000000000
  store i1 %t38, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb15, label %bb16
bb15:
  %t42 = insertvalue { i32, i128 } zeroinitializer, i32 65544, 0
  store { i32, i128 } %t42, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t43 = load double, ptr %l1, !tbaa !26
  %t45 = fcmp oge double %t43, 0x43e0000000000000
  br i1 %t45, label %bb18, label %bb19
bb18:
  %t47 = load double, ptr %l1, !tbaa !26
  %t49 = fptoui double %t47 to i64
  %t51 = zext i64 %t49 to i128
  %t53 = insertvalue { i32, i128 } zeroinitializer, i128 %t51, 1
  store { i32, i128 } %t53, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t54 = load double, ptr %l1, !tbaa !26
  %t56 = fptosi double %t54 to i64
  %t58 = sitofp i64 %t56 to double
  %t59 = load double, ptr %l1, !tbaa !26
  %t62 = fcmp une double %t58, %t59
  br i1 %t62, label %bb21, label %bb22
bb21:
  %t65 = insertvalue { i32, i128 } zeroinitializer, i32 65544, 0
  store { i32, i128 } %t65, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t66 = load double, ptr %l1, !tbaa !26
  %t68 = fptosi double %t66 to i64
  %t70 = sext i64 %t68 to i128
  %t72 = insertvalue { i32, i128 } zeroinitializer, i128 %t70, 1
  store { i32, i128 } %t72, ptr %rv
  br label %ret
bb24:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb25, label %bb26
bb25:
  %t77 = load ptr, ptr %l39, !tbaa !29
  %t78 = load i64, ptr %t77, !range !{i64 0, i64 8}
  %t80 = icmp eq i64 %t78, 3
  store i1 %t80, ptr %l40, !tbaa !21
  br label %bb26
bb26:
  %t81 = load i1, ptr %l40, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr { i64, [2 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { i64 }, ptr %t84, i32 0, i32 0
  %t86 = load i64, ptr %t85
  store i64 %t86, ptr %l2, !tbaa !24
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t90 = sext i64 %t88 to i128
  %t92 = insertvalue { i32, i128 } zeroinitializer, i128 %t90, 1
  store { i32, i128 } %t92, ptr %rv
  br label %ret
bb30:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t94 = load ptr, ptr %l47, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l47, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 4
  store i1 %t100, ptr %l48, !tbaa !21
  br label %bb32
bb32:
  %t101 = load i1, ptr %l48, !tbaa !21
  br i1 %t101, label %bb33, label %bb34
bb33:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr { i64, [2 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { i64 }, ptr %t104, i32 0, i32 0
  %t106 = load i64, ptr %t105
  store i64 %t106, ptr %l3, !tbaa !65
  br label %bb35
bb34:
  br label %bb36
bb35:
  %t108 = load i64, ptr %l3, !tbaa !65
  %t110 = zext i64 %t108 to i128
  %t112 = insertvalue { i32, i128 } zeroinitializer, i128 %t110, 1
  store { i32, i128 } %t112, ptr %rv
  br label %ret
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t114 = insertvalue { i32, i128 } zeroinitializer, i32 65544, 0
  store { i32, i128 } %t114, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3d7deb9fd92cdf7_48602bd2c42c5c33)
  unreachable
ret:
  %rr = load { i32, i128 }, ptr %rv
  ret { i32, i128 } %rr
}

define dso_local { i32, ptr } @std_2fjson_2estd_2fjson_3aObject_2eAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:Object", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t9 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %t5, { i64, ptr } %a1)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l8
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb2, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l7
  br label %bb1
bb1:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t16 = insertvalue { i32, ptr } zeroinitializer, i32 65543, 0
  store { i32, ptr } %t16, ptr %rv
  br label %ret
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t17
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t23 = insertvalue { i32, ptr } zeroinitializer, ptr %t21, 1
  store { i32, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3aObject_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %rv
  br label %ret
bb4:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/json:Object", ptr %a0, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2fjson_2estd_2fjson_3aPosition_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:Position", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:Position", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = call i64 @__olang_fmt_i64(ptr null, i64 %t4)
  %t11 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t13 = add i64 %t10, %t12
  %t15 = call i64 @__olang_fmt_i64(ptr null, i64 %t8)
  %t16 = add i64 %t13, %t15
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = call i64 @__olang_fmt_i64(ptr %t17, i64 %t4)
  %t19 = getelementptr i8, ptr %t17, i64 %t10
  call void @olang_textcopy(ptr %t19, ptr %t11, i64 %t12)
  %t20 = getelementptr i8, ptr %t19, i64 %t12
  %t21 = call i64 @__olang_fmt_i64(ptr %t20, i64 %t8)
  %t22 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t17, 1
  store { i64, ptr } %t23, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l41 = alloca i64
  %l44 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l85 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l96 = alloca i64
  %l99 = alloca i64
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca %"std/json:Object"
  %l133 = alloca %"std/json:Object"
  %l134 = alloca i32
  %l138 = alloca ptr
  %t52 = alloca i64
  %t161 = alloca { i64, [2 x i64] }, align 8
  %t190 = alloca i64
  %t292 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load ptr, ptr %l18, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t2, i32 0, i32 8
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  %t8 = load ptr, ptr %l18, !tbaa !29
  %t9 = getelementptr %"std/json:reader", ptr %t8, i32 0, i32 8
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:reader", ptr %t10, i32 0, i32 6
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l22, !tbaa !27
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"std/json:reader", ptr %t14, i32 0, i32 8
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i64, ptr %t20, i64 %t17
  %t22 = load i64, ptr %t21, !tbaa !34
  store i64 %t22, ptr %l1, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/json:reader", ptr %t24, i32 0, i32 3
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = sub i64 %t27, %t28
  store i64 %t31, ptr %l2, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %l30, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/json:reader", ptr %t34, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l32, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  store ptr %t41, ptr %l33, !tbaa !29
  %t42 = load i64, ptr %l30, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb1, label %bb2
bb1:
  %t45 = load i64, ptr %l30, !tbaa !24
  %t46 = icmp sle i64 %t45, 1152921504606846975
  br i1 %t46, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4cf869d60c4ca172_ef56e6f5157a9496)
  unreachable
bb3:
  %t48 = load i64, ptr %l30, !tbaa !24
  %t49 = mul i64 %t48, 8
  %t50 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t49)
  %t51 = load ptr, ptr %l33, !tbaa !29
  store i64 0, ptr %t52
  br label %fill.53
fill.53:
  %t56 = load i64, ptr %t52
  %t57 = icmp slt i64 %t56, %t48
  br i1 %t57, label %fillb.54, label %filld.55
fillb.54:
  %t58 = getelementptr ptr, ptr %t50, i64 %t56
  store ptr %t51, ptr %t58
  %t59 = add i64 %t56, 1
  store i64 %t59, ptr %t52
  br label %fill.53
filld.55:
  %t60 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t50, 1
  store { i64, ptr } %t61, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t63 = load i64, ptr %l2, !tbaa !24
  store i64 %t63, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l4, !tbaa !24
  %t69 = icmp sgt i64 %t65, %t66
  br i1 %t69, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4cf869d60c4ca172_ef56e6f5157a9496)
  unreachable
bb5:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t73 = icmp sgt i64 %t71, 0
  br i1 %t73, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb10
bb7:
  %t75 = load i64, ptr %l5, !tbaa !24
  %t76 = load i64, ptr %l4, !tbaa !24
  %t79 = sub i64 %t75, %t76
  %t80 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t79, %t80
  %t85 = sub i64 %t83, 1
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = sdiv i64 %t85, %t86
  store i64 %t89, ptr %l44, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb9
bb9:
  %t91 = load i64, ptr %l44, !tbaa !24
  store i64 %t91, ptr %l41, !tbaa !24
  br label %bb10
bb10:
  %t92 = load i64, ptr %l41, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp slt i64 %t93, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t101 = load i64, ptr %l4, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = mul i64 %t102, %t103
  %t109 = add i64 %t101, %t106
  store i64 %t109, ptr %l9, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t111, ptr %l62, !tbaa !27
  %t112 = load i64, ptr %l9, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"std/json:reader", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l65, !tbaa !27
  %t117 = load i64, ptr %l1, !tbaa !24
  %t118 = load i64, ptr %l9, !tbaa !24
  %t121 = add i64 %t117, %t118
  %t123 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t129 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr ptr, ptr %t130, i64 %t112
  store ptr %t126, ptr %t131, !tbaa !39
  br label %bb15
bb15:
  %t132 = load i64, ptr %l8, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l8, !tbaa !24
  br label %bb11
bb16:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l1, !tbaa !24
  %t140 = getelementptr %"std/json:reader", ptr %t136, i32 0, i32 3
  store i64 %t137, ptr %t140, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"std/json:reader", ptr %t141, i32 0, i32 7
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l75, !tbaa !27
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"std/json:reader", ptr %t145, i32 0, i32 8
  %t148 = load i64, ptr %t147, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i64, ptr %t151, i64 %t148
  %t153 = load i64, ptr %t152, !tbaa !34
  store i64 %t153, ptr %l10, !tbaa !24
  %t155 = load i64, ptr %l10, !tbaa !24
  %t157 = icmp slt i64 %t155, 0
  br i1 %t157, label %bb17, label %bb18
bb17:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [2 x i64] }, ptr %t161, i32 0, i32 0
  store i64 6, ptr %t162
  %t164 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t160, 0
  %t165 = getelementptr { i64, [2 x i64] }, ptr %t161, i32 0, i32 1
  store { { i64, ptr } } %t164, ptr %t165
  %t166 = load { i64, [2 x i64] }, ptr %t161
  %t168 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t166, ptr %t168
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t159, ptr %t168)
  br label %bb19
bb18:
  %t171 = load i64, ptr %l2, !tbaa !24
  store i64 %t171, ptr %l85, !tbaa !24
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"std/json:reader", ptr %t172, i32 0, i32 4
  %t175 = load { i64, ptr }, ptr %t174, !tbaa !27
  store { i64, ptr } %t175, ptr %l87, !tbaa !27
  %t176 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %t177, i64 0
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !37
  store { i64, ptr } %t179, ptr %l88, !tbaa !27
  %t180 = load i64, ptr %l85, !tbaa !24
  %t181 = icmp sge i64 %t180, 0
  br i1 %t181, label %bb20, label %bb21
bb19:
  br label %bb41
bb20:
  %t183 = load i64, ptr %l85, !tbaa !24
  %t184 = icmp sle i64 %t183, 576460752303423487
  br i1 %t184, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a4e4729341d0d567_917d86fd422044ab)
  unreachable
bb22:
  %t186 = load i64, ptr %l85, !tbaa !24
  %t187 = mul i64 %t186, 16
  %t188 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t187)
  %t189 = load { i64, ptr }, ptr %l88, !tbaa !27
  store i64 0, ptr %t190
  br label %fill.191
fill.191:
  %t194 = load i64, ptr %t190
  %t195 = icmp slt i64 %t194, %t186
  br i1 %t195, label %fillb.192, label %filld.193
fillb.192:
  %t196 = getelementptr { i64, ptr }, ptr %t188, i64 %t194
  store { i64, ptr } %t189, ptr %t196
  %t197 = add i64 %t194, 1
  store i64 %t197, ptr %t190
  br label %fill.191
filld.193:
  %t198 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t188, 1
  store { i64, ptr } %t199, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t201 = load i64, ptr %l2, !tbaa !24
  store i64 %t201, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t203 = load i64, ptr %l13, !tbaa !24
  %t204 = load i64, ptr %l12, !tbaa !24
  %t207 = icmp sgt i64 %t203, %t204
  br i1 %t207, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_a4e4729341d0d567_917d86fd422044ab)
  unreachable
bb24:
  %t209 = load i64, ptr %l14, !tbaa !24
  %t211 = icmp sgt i64 %t209, 0
  br i1 %t211, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb29
bb26:
  %t213 = load i64, ptr %l13, !tbaa !24
  %t214 = load i64, ptr %l12, !tbaa !24
  %t217 = sub i64 %t213, %t214
  %t218 = load i64, ptr %l14, !tbaa !24
  %t221 = add i64 %t217, %t218
  %t223 = sub i64 %t221, 1
  %t224 = load i64, ptr %l14, !tbaa !24
  %t227 = sdiv i64 %t223, %t224
  store i64 %t227, ptr %l99, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb28
bb28:
  %t229 = load i64, ptr %l99, !tbaa !24
  store i64 %t229, ptr %l96, !tbaa !24
  br label %bb29
bb29:
  %t230 = load i64, ptr %l96, !tbaa !24
  store i64 %t230, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  %t231 = load i64, ptr %l16, !tbaa !24
  %t232 = load i64, ptr %l15, !tbaa !24
  %t235 = icmp slt i64 %t231, %t232
  %t237 = xor i1 %t235, true
  br i1 %t237, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t239 = load i64, ptr %l12, !tbaa !24
  %t240 = load i64, ptr %l16, !tbaa !24
  %t241 = load i64, ptr %l14, !tbaa !24
  %t244 = mul i64 %t240, %t241
  %t247 = add i64 %t239, %t244
  store i64 %t247, ptr %l17, !tbaa !24
  %t249 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t249, ptr %l117, !tbaa !27
  %t250 = load i64, ptr %l17, !tbaa !24
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"std/json:reader", ptr %t251, i32 0, i32 4
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l120, !tbaa !27
  %t255 = load i64, ptr %l10, !tbaa !24
  %t256 = load i64, ptr %l17, !tbaa !24
  %t259 = add i64 %t255, %t256
  %t261 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr { i64, ptr }, ptr %t262, i64 %t259
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !37
  %t267 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t268 = load ptr, ptr %t267, !tbaa !27
  %t269 = getelementptr { i64, ptr }, ptr %t268, i64 %t250
  store { i64, ptr } %t264, ptr %t269, !tbaa !37
  br label %bb34
bb34:
  %t270 = load i64, ptr %l16, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l16, !tbaa !24
  br label %bb30
bb35:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i64, ptr %l10, !tbaa !24
  %t278 = getelementptr %"std/json:reader", ptr %t274, i32 0, i32 5
  store i64 %t275, ptr %t278, !tbaa !24
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l129, !tbaa !29
  %t280 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t284 = call { i32, %"std/json:Object" } @std_2fjson_3aObject_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t280, { i64, ptr } %t281)
  %t285 = extractvalue { i32, %"std/json:Object" } %t284, 1
  %t286 = extractvalue { i32, %"std/json:Object" } %t284, 0
  store i32 %t286, ptr %l134
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb37, label %ok.288, !prof !99
ok.288:
  store %"std/json:Object" %t285, ptr %l133
  br label %bb36
bb36:
  %t289 = load %"std/json:Object", ptr %l133
  store %"std/json:Object" %t289, ptr %l130
  br label %bb39
bb37:
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_78dc4052a96c39eb_b95510f79f72ba17)
  unreachable
bb39:
  %t290 = load %"std/json:Object", ptr %l130
  %t291 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"std/json:Object" %t290, ptr %t291
  store { i64, [2 x i64] } zeroinitializer, ptr %t292
  %t293 = getelementptr { i64, [2 x i64] }, ptr %t292, i32 0, i32 0
  store i64 7, ptr %t293
  %t295 = insertvalue { ptr } undef, ptr %t291, 0
  %t296 = getelementptr { i64, [2 x i64] }, ptr %t292, i32 0, i32 1
  store { ptr } %t295, ptr %t296
  %t297 = load { i64, [2 x i64] }, ptr %t292
  %t299 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t297, ptr %t299
  %t300 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t300, ptr %t299)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t302 = load ptr, ptr %l0, !tbaa !29
  store ptr %t302, ptr %l138, !tbaa !29
  %t303 = load ptr, ptr %l138, !tbaa !29
  %t304 = getelementptr %"std/json:reader", ptr %t303, i32 0, i32 1
  %t305 = load i64, ptr %t304, !tbaa !24
  %t307 = add i64 %t305, 1
  %t309 = load ptr, ptr %l138, !tbaa !29
  %t310 = getelementptr %"std/json:reader", ptr %t309, i32 0, i32 1
  store i64 %t307, ptr %t310, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/json:reader", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp slt i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/json:reader", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = load i64, ptr %l1, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t21)
  store i1 %t23, ptr %l12
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  %t24 = load i1, ptr %l12, !tbaa !21
  store i1 %t24, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t25 = load i1, ptr %l7, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eescape(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l15 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l27 = alloca i1
  %l30 = alloca i1
  %l46 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i32
  %l56 = alloca ptr
  %l61 = alloca i1
  %l69 = alloca i1
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l86 = alloca i1
  %l88 = alloca { i64, ptr }
  %l97 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i32
  %l107 = alloca i1
  %l113 = alloca ptr
  %l126 = alloca i64
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/json:reader", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp eq i64 %t6, %t12
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l15, !tbaa !29
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = getelementptr %"std/json:reader", ptr %t18, i32 0, i32 1
  %t20 = load i64, ptr %t19, !tbaa !24
  %t22 = add i64 %t20, 1
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t25 = getelementptr %"std/json:reader", ptr %t24, i32 0, i32 1
  store i64 %t22, ptr %t25, !tbaa !24
  %t27 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t27, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"std/json:reader", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l20, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/json:reader", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  %t37 = add i64 %t35, 1
  %t39 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i8, ptr %t40, i64 %t37
  %t42 = load i8, ptr %t41, !tbaa !32
  store i8 %t42, ptr %l3, !tbaa !22
  store i8 0, ptr %l4, !tbaa !22
  %t44 = load i8, ptr %l3, !tbaa !22
  %t46 = icmp eq i8 %t44, 34
  br i1 %t46, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb5:
  %t48 = load i8, ptr %l3, !tbaa !22
  %t50 = icmp eq i8 %t48, 92
  store i1 %t50, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb9
bb8:
  %t53 = load i8, ptr %l3, !tbaa !22
  %t55 = icmp eq i8 %t53, 47
  store i1 %t55, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t58 = load i8, ptr %l3, !tbaa !22
  store i8 %t58, ptr %l4, !tbaa !22
  br label %bb63
bb11:
  %t60 = load i8, ptr %l3, !tbaa !22
  %t62 = icmp eq i8 %t60, 110
  br i1 %t62, label %bb12, label %bb13
bb12:
  store i8 10, ptr %l4, !tbaa !22
  br label %bb62
bb13:
  %t64 = load i8, ptr %l3, !tbaa !22
  %t66 = icmp eq i8 %t64, 116
  br i1 %t66, label %bb14, label %bb15
bb14:
  store i8 9, ptr %l4, !tbaa !22
  br label %bb61
bb15:
  %t68 = load i8, ptr %l3, !tbaa !22
  %t70 = icmp eq i8 %t68, 114
  br i1 %t70, label %bb16, label %bb17
bb16:
  store i8 13, ptr %l4, !tbaa !22
  br label %bb60
bb17:
  %t72 = load i8, ptr %l3, !tbaa !22
  %t74 = icmp eq i8 %t72, 98
  br i1 %t74, label %bb18, label %bb19
bb18:
  store i8 8, ptr %l4, !tbaa !22
  br label %bb59
bb19:
  %t76 = load i8, ptr %l3, !tbaa !22
  %t78 = icmp eq i8 %t76, 102
  br i1 %t78, label %bb20, label %bb21
bb20:
  store i8 12, ptr %l4, !tbaa !22
  br label %bb58
bb21:
  %t80 = load i8, ptr %l3, !tbaa !22
  %t82 = icmp eq i8 %t80, 117
  br i1 %t82, label %bb22, label %bb23
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"std/json:reader", ptr %t85, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t90 = add i64 %t88, 2
  %t93 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2ehex4(ptr %v0, ptr %t84, i64 %t90)
  %t94 = extractvalue { i32, i64 } %t93, 1
  %t95 = extractvalue { i32, i64 } %t93, 0
  store i32 %t95, ptr %l52
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb25, label %ok.97, !prof !99
ok.97:
  store i64 %t94, ptr %l51
  br label %bb24
bb23:
  %t99 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t99, ptr %rv
  br label %ret
bb24:
  %t100 = load i64, ptr %l51, !tbaa !24
  store i64 %t100, ptr %l46, !tbaa !24
  br label %bb26
bb25:
  %t101 = load i32, ptr %l52, !tbaa !23
  %t102 = lshr i32 %t101, 16
  %t103 = and i32 %t101, 65535
  %t104 = icmp eq i32 %t102, 1
  %t105 = select i1 %t104, i32 1, i32 0
  %t106 = icmp eq i32 %t101, 0
  %t107 = shl i32 %t105, 16
  %t108 = or i32 %t107, %t103
  %t109 = select i1 %t106, i32 0, i32 %t108
  %t111 = insertvalue { i32, i64 } zeroinitializer, i32 %t109, 0
  store { i32, i64 } %t111, ptr %rv
  br label %ret
bb26:
  %t112 = load i64, ptr %l46, !tbaa !24
  store i64 %t112, ptr %l5, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"std/json:reader", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l6, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l56, !tbaa !29
  %t119 = load ptr, ptr %l56, !tbaa !29
  %t120 = getelementptr %"std/json:reader", ptr %t119, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = add i64 %t121, 6
  %t125 = load ptr, ptr %l56, !tbaa !29
  %t126 = getelementptr %"std/json:reader", ptr %t125, i32 0, i32 1
  store i64 %t123, ptr %t126, !tbaa !24
  %t127 = load i64, ptr %l5, !tbaa !24
  %t129 = icmp sge i64 %t127, 56320
  br i1 %t129, label %bb27, label %bb28
bb27:
  %t131 = load i64, ptr %l5, !tbaa !24
  %t133 = icmp sle i64 %t131, 57343
  store i1 %t133, ptr %l61, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb29
bb29:
  %t135 = load i1, ptr %l61, !tbaa !21
  br i1 %t135, label %bb30, label %bb31
bb30:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l6, !tbaa !24
  %t140 = getelementptr %"std/json:reader", ptr %t136, i32 0, i32 1
  store i64 %t137, ptr %t140, !tbaa !24
  %t142 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t142, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t143 = load i64, ptr %l5, !tbaa !24
  %t145 = icmp sge i64 %t143, 55296
  br i1 %t145, label %bb33, label %bb34
bb33:
  %t147 = load i64, ptr %l5, !tbaa !24
  %t149 = icmp sle i64 %t147, 56319
  store i1 %t149, ptr %l69, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb35
bb35:
  %t151 = load i1, ptr %l69, !tbaa !21
  br i1 %t151, label %bb36, label %bb37
bb36:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"std/json:reader", ptr %t152, i32 0, i32 1
  %t155 = load i64, ptr %t154, !tbaa !24
  %t157 = add i64 %t155, 1
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"std/json:reader", ptr %t158, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t161, 0
  %t166 = icmp sge i64 %t157, %t163
  br i1 %t166, label %bb38, label %bb39
bb37:
  br label %bb56
bb38:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb40
bb39:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"std/json:reader", ptr %t168, i32 0, i32 0
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l81, !tbaa !27
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"std/json:reader", ptr %t172, i32 0, i32 1
  %t175 = load i64, ptr %t174, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i8, ptr %t178, i64 %t175
  %t180 = load i8, ptr %t179, !tbaa !32
  %t182 = icmp ne i8 %t180, 92
  store i1 %t182, ptr %l79, !tbaa !21
  br label %bb40
bb40:
  %t184 = load i1, ptr %l79, !tbaa !21
  br i1 %t184, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb43
bb42:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"std/json:reader", ptr %t185, i32 0, i32 0
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l88, !tbaa !27
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"std/json:reader", ptr %t189, i32 0, i32 1
  %t192 = load i64, ptr %t191, !tbaa !24
  %t194 = add i64 %t192, 1
  %t196 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i8, ptr %t197, i64 %t194
  %t199 = load i8, ptr %t198, !tbaa !32
  %t201 = icmp ne i8 %t199, 117
  store i1 %t201, ptr %l86, !tbaa !21
  br label %bb43
bb43:
  %t203 = load i1, ptr %l86, !tbaa !21
  br i1 %t203, label %bb44, label %bb45
bb44:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i64, ptr %l6, !tbaa !24
  %t208 = getelementptr %"std/json:reader", ptr %t204, i32 0, i32 1
  store i64 %t205, ptr %t208, !tbaa !24
  %t210 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t210, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"std/json:reader", ptr %t212, i32 0, i32 1
  %t215 = load i64, ptr %t214, !tbaa !24
  %t217 = add i64 %t215, 2
  %t220 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2ehex4(ptr %v0, ptr %t211, i64 %t217)
  %t221 = extractvalue { i32, i64 } %t220, 1
  %t222 = extractvalue { i32, i64 } %t220, 0
  store i32 %t222, ptr %l103
  %t223 = icmp ne i32 %t222, 0
  br i1 %t223, label %bb48, label %ok.224, !prof !99
ok.224:
  store i64 %t221, ptr %l102
  br label %bb47
bb47:
  %t225 = load i64, ptr %l102, !tbaa !24
  store i64 %t225, ptr %l97, !tbaa !24
  br label %bb49
bb48:
  %t226 = load i32, ptr %l103, !tbaa !23
  %t227 = lshr i32 %t226, 16
  %t228 = and i32 %t226, 65535
  %t229 = icmp eq i32 %t227, 1
  %t230 = select i1 %t229, i32 1, i32 0
  %t231 = icmp eq i32 %t226, 0
  %t232 = shl i32 %t230, 16
  %t233 = or i32 %t232, %t228
  %t234 = select i1 %t231, i32 0, i32 %t233
  %t236 = insertvalue { i32, i64 } zeroinitializer, i32 %t234, 0
  store { i32, i64 } %t236, ptr %rv
  br label %ret
bb49:
  %t237 = load i64, ptr %l97, !tbaa !24
  store i64 %t237, ptr %l7, !tbaa !24
  %t238 = load i64, ptr %l7, !tbaa !24
  %t240 = icmp slt i64 %t238, 56320
  br i1 %t240, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb52
bb51:
  %t242 = load i64, ptr %l7, !tbaa !24
  %t244 = icmp sgt i64 %t242, 57343
  store i1 %t244, ptr %l107, !tbaa !21
  br label %bb52
bb52:
  %t246 = load i1, ptr %l107, !tbaa !21
  br i1 %t246, label %bb53, label %bb54
bb53:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l6, !tbaa !24
  %t251 = getelementptr %"std/json:reader", ptr %t247, i32 0, i32 1
  store i64 %t248, ptr %t251, !tbaa !24
  %t253 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t253, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  %t254 = load ptr, ptr %l0, !tbaa !29
  store ptr %t254, ptr %l113, !tbaa !29
  %t255 = load ptr, ptr %l113, !tbaa !29
  %t256 = getelementptr %"std/json:reader", ptr %t255, i32 0, i32 1
  %t257 = load i64, ptr %t256, !tbaa !24
  %t259 = add i64 %t257, 6
  %t261 = load ptr, ptr %l113, !tbaa !29
  %t262 = getelementptr %"std/json:reader", ptr %t261, i32 0, i32 1
  store i64 %t259, ptr %t262, !tbaa !24
  %t263 = load i64, ptr %l5, !tbaa !24
  %t265 = sub i64 %t263, 55296
  %t267 = shl i64 %t265, 10
  %t269 = add i64 65536, %t267
  %t270 = load i64, ptr %l7, !tbaa !24
  %t272 = sub i64 %t270, 56320
  %t275 = add i64 %t269, %t272
  store i64 %t275, ptr %l5, !tbaa !24
  br label %bb56
bb56:
  %t277 = load i64, ptr %l5, !tbaa !24
  %t278 = load i64, ptr %l1, !tbaa !24
  %t279 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t283 = call i64 @std_2fjson_2eputUtf8(ptr %v1, i64 %t277, i64 %t278, { i64, ptr } %t279)
  store i64 %t283, ptr %l126
  br label %bb57
bb57:
  %t284 = load i64, ptr %l126, !tbaa !24
  %t285 = insertvalue { i32, i64 } zeroinitializer, i64 %t284, 1
  store { i32, i64 } %t285, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t286 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t290 = icmp sgt i64 %t288, 0
  br i1 %t290, label %bb64, label %bb65
bb64:
  %t292 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t292, ptr %l131, !tbaa !27
  %t293 = load i64, ptr %l1, !tbaa !24
  %t294 = load i8, ptr %l4, !tbaa !22
  %t297 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t298 = load ptr, ptr %t297, !tbaa !27
  %t299 = getelementptr i8, ptr %t298, i64 %t293
  store i8 %t294, ptr %t299, !tbaa !32
  br label %bb66
bb65:
  br label %bb66
bb66:
  %t300 = load ptr, ptr %l0, !tbaa !29
  store ptr %t300, ptr %l134, !tbaa !29
  %t301 = load ptr, ptr %l134, !tbaa !29
  %t302 = getelementptr %"std/json:reader", ptr %t301, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  %t305 = add i64 %t303, 2
  %t307 = load ptr, ptr %l134, !tbaa !29
  %t308 = getelementptr %"std/json:reader", ptr %t307, i32 0, i32 1
  store i64 %t305, ptr %t308, !tbaa !24
  %t310 = insertvalue { i32, i64 } zeroinitializer, i64 1, 1
  store { i32, i64 } %t310, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local ptr @std_2fjson_2estd_2fjson_3areader_2eexact(ptr %v0, ptr %v1, ptr %a0, i64 %a1, double %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca double
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l25 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca i1
  %l54 = alloca i64
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i32
  %l58 = alloca i64
  %l59 = alloca i32
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l62 = alloca i64
  %l63 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %l71 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t50 = alloca { i64, [2 x i64] }, align 8
  %t96 = alloca { i64, [2 x i64] }, align 8
  %t137 = alloca { i64, [2 x i64] }, align 8
  %t162 = alloca { i64, [2 x i64] }, align 8
  %t172 = alloca { i64, [2 x i64] }, align 8
  %t201 = alloca { i64, [2 x i64] }, align 8
  %t211 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store double %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l11, !tbaa !27
  store i64 %a1, ptr %l12, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/json:reader", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  store i64 %t9, ptr %l14, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l15, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l12, !tbaa !24
  %t16 = load i64, ptr %l14, !tbaa !24
  %t17 = icmp sle i64 %t15, %t16
  br i1 %t17, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_9ab7127216e6ddd3_9523f6c3485c577)
  unreachable
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = icmp sle i64 %t19, %t20
  br i1 %t21, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9ab7127216e6ddd3_9523f6c3485c577)
  unreachable
bb5:
  %t23 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l12, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = getelementptr i8, ptr %t24, i64 %t25
  %t28 = sub i64 %t26, %t25
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t35, ptr %l22, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i8, ptr %t37, i64 0
  %t39 = load i8, ptr %t38, !tbaa !32
  %t41 = icmp eq i8 %t39, 45
  br i1 %t41, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9ab7127216e6ddd3_9523f6c3485c577)
  unreachable
bb7:
  store i64 1, ptr %l25, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l21, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t45 = sub i64 %t43, %t44
  %t47 = icmp sle i64 %t45, 15
  br i1 %t47, label %bb10, label %bb11
bb10:
  %t49 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 0
  store i64 2, ptr %t51
  %t53 = insertvalue { double } undef, double %t49, 0
  %t54 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  store { double } %t53, ptr %t54
  %t55 = load { i64, [2 x i64] }, ptr %t50
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t55, ptr %t57
  call void @__olang_scope_close(ptr %s0)
  store ptr %t57, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l6, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t73 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t73, ptr %l38, !tbaa !27
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i8, ptr %t77, i64 %t74
  %t79 = load i8, ptr %t78, !tbaa !32
  store i8 %t79, ptr %l7, !tbaa !22
  %t81 = load i8, ptr %l7, !tbaa !22
  %t83 = icmp eq i8 %t81, 46
  br i1 %t83, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb19
bb18:
  %t85 = load i8, ptr %l7, !tbaa !22
  %t87 = icmp eq i8 %t85, 101
  store i1 %t87, ptr %l43, !tbaa !21
  br label %bb19
bb19:
  %t89 = load i1, ptr %l43, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb22
bb21:
  %t90 = load i8, ptr %l7, !tbaa !22
  %t92 = icmp eq i8 %t90, 69
  store i1 %t92, ptr %l46, !tbaa !21
  br label %bb22
bb22:
  %t94 = load i1, ptr %l46, !tbaa !21
  br i1 %t94, label %bb23, label %bb24
bb23:
  %t95 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 0
  store i64 2, ptr %t97
  %t99 = insertvalue { double } undef, double %t95, 0
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t96, i32 0, i32 1
  store { double } %t99, ptr %t100
  %t101 = load { i64, [2 x i64] }, ptr %t96
  %t103 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t101, ptr %t103
  call void @__olang_scope_close(ptr %s0)
  store ptr %t103, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = add i64 %t105, 1
  store i64 %t107, ptr %l5, !tbaa !24
  br label %bb13
bb27:
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t109, ptr %l55, !tbaa !27
  %t110 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 10)
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l57
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb29, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l56
  br label %bb28
bb28:
  %t115 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t116 = load i64, ptr %l56, !tbaa !24
  %t117 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %t115, i64 %t116)
  %t118 = extractvalue { i32, i64 } %t117, 1
  %t119 = extractvalue { i32, i64 } %t117, 0
  store i32 %t119, ptr %l59
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb32, label %ok.121, !prof !99
ok.121:
  store i64 %t118, ptr %l58
  br label %bb31
bb29:
  br label %bb30
bb30:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t122, ptr %l61, !tbaa !27
  %t123 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 10)
  %t124 = extractvalue { i32, i64 } %t123, 1
  %t125 = extractvalue { i32, i64 } %t123, 0
  store i32 %t125, ptr %l63
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb34, label %ok.127, !prof !99
ok.127:
  store i64 %t124, ptr %l62
  br label %bb33
bb31:
  %t128 = load i64, ptr %l58, !tbaa !24
  store i64 %t128, ptr %l54, !tbaa !24
  br label %bb45
bb32:
  br label %bb30
bb33:
  %t129 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t130 = load i64, ptr %l62, !tbaa !24
  %t131 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %t129, i64 %t130)
  %t132 = extractvalue { i32, i64 } %t131, 1
  %t133 = extractvalue { i32, i64 } %t131, 0
  store i32 %t133, ptr %l65
  %t134 = icmp ne i32 %t133, 0
  br i1 %t134, label %bb37, label %ok.135, !prof !99
ok.135:
  store i64 %t132, ptr %l64
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  %t136 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t137
  %t138 = getelementptr { i64, [2 x i64] }, ptr %t137, i32 0, i32 0
  store i64 2, ptr %t138
  %t140 = insertvalue { double } undef, double %t136, 0
  %t141 = getelementptr { i64, [2 x i64] }, ptr %t137, i32 0, i32 1
  store { double } %t140, ptr %t141
  %t142 = load { i64, [2 x i64] }, ptr %t137
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t142, ptr %t144
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t144, ptr %rv
  br label %ret
bb36:
  %t146 = load i64, ptr %l64, !tbaa !65
  store i64 %t146, ptr %l60, !tbaa !65
  br label %bb38
bb37:
  br label %bb35
bb38:
  %t147 = load i64, ptr %l60, !tbaa !65
  store i64 %t147, ptr %l8, !tbaa !65
  %t148 = load double, ptr %l2, !tbaa !26
  %t150 = fcmp olt double %t148, 0x43f0000000000000
  br i1 %t150, label %bb39, label %bb40
bb39:
  %t152 = load double, ptr %l2, !tbaa !26
  %t154 = fptoui double %t152 to i64
  %t155 = load i64, ptr %l8, !tbaa !65
  %t158 = icmp eq i64 %t154, %t155
  store i1 %t158, ptr %l71, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb41
bb41:
  %t160 = load i1, ptr %l71, !tbaa !21
  br i1 %t160, label %bb42, label %bb43
bb42:
  %t161 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t162
  %t163 = getelementptr { i64, [2 x i64] }, ptr %t162, i32 0, i32 0
  store i64 2, ptr %t163
  %t165 = insertvalue { double } undef, double %t161, 0
  %t166 = getelementptr { i64, [2 x i64] }, ptr %t162, i32 0, i32 1
  store { double } %t165, ptr %t166
  %t167 = load { i64, [2 x i64] }, ptr %t162
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t167, ptr %t169
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t169, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t171 = load i64, ptr %l8, !tbaa !65
  store { i64, [2 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 0
  store i64 4, ptr %t173
  %t175 = insertvalue { i64 } undef, i64 %t171, 0
  %t176 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 1
  store { i64 } %t175, ptr %t176
  %t177 = load { i64, [2 x i64] }, ptr %t172
  %t179 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t177, ptr %t179
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t179, ptr %rv
  br label %ret
bb45:
  %t181 = load i64, ptr %l54, !tbaa !24
  store i64 %t181, ptr %l9, !tbaa !24
  %t182 = load double, ptr %l2, !tbaa !26
  %t184 = fcmp oge double %t182, 0xc3e0000000000000
  br i1 %t184, label %bb46, label %bb47
bb46:
  %t186 = load double, ptr %l2, !tbaa !26
  %t188 = fcmp olt double %t186, 0x43e0000000000000
  store i1 %t188, ptr %l84, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb48
bb48:
  %t190 = load i1, ptr %l84, !tbaa !21
  br i1 %t190, label %bb49, label %bb50
bb49:
  %t191 = load double, ptr %l2, !tbaa !26
  %t193 = fptosi double %t191 to i64
  %t194 = load i64, ptr %l9, !tbaa !24
  %t197 = icmp eq i64 %t193, %t194
  store i1 %t197, ptr %l87, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb51
bb51:
  %t199 = load i1, ptr %l87, !tbaa !21
  br i1 %t199, label %bb52, label %bb53
bb52:
  %t200 = load double, ptr %l2, !tbaa !26
  store { i64, [2 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [2 x i64] }, ptr %t201, i32 0, i32 0
  store i64 2, ptr %t202
  %t204 = insertvalue { double } undef, double %t200, 0
  %t205 = getelementptr { i64, [2 x i64] }, ptr %t201, i32 0, i32 1
  store { double } %t204, ptr %t205
  %t206 = load { i64, [2 x i64] }, ptr %t201
  %t208 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t206, ptr %t208
  call void @__olang_scope_close(ptr %s0)
  store ptr %t208, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t210 = load i64, ptr %l9, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [2 x i64] }, ptr %t211, i32 0, i32 0
  store i64 3, ptr %t212
  %t214 = insertvalue { i64 } undef, i64 %t210, 0
  %t215 = getelementptr { i64, [2 x i64] }, ptr %t211, i32 0, i32 1
  store { i64 } %t214, ptr %t215
  %t216 = load { i64, [2 x i64] }, ptr %t211
  %t218 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t216, ptr %t218
  call void @__olang_scope_close(ptr %s0)
  store ptr %t218, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2ehex4(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l10 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i64
  %l49 = alloca { i64, ptr }
  %l54 = alloca i1
  %l62 = alloca i1
  %l71 = alloca i1
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t5 = add i64 %t3, 4
  store i64 %t5, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb3:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l20, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb5
bb5:
  %t33 = load i64, ptr %l20, !tbaa !24
  store i64 %t33, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l17, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb8, label %bb9
bb8:
  br label %bb33
bb9:
  br label %bb10
bb10:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l8, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/json:reader", ptr %t54, i32 0, i32 0
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t62 = icmp sge i64 %t53, %t59
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/json:reader", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t73 = getelementptr %"std/json:reader", ptr %t64, i32 0, i32 1
  store i64 %t70, ptr %t73, !tbaa !24
  %t75 = insertvalue { i32, i64 } zeroinitializer, i32 65537, 0
  store { i32, i64 } %t75, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/json:reader", ptr %t76, i32 0, i32 0
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  store { i64, ptr } %t79, ptr %l49, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  store i8 %t85, ptr %l9, !tbaa !22
  store i64 0, ptr %l10, !tbaa !24
  %t87 = load i8, ptr %l9, !tbaa !22
  %t89 = icmp uge i8 %t87, 48
  br i1 %t89, label %bb14, label %bb15
bb14:
  %t91 = load i8, ptr %l9, !tbaa !22
  %t93 = icmp ule i8 %t91, 57
  store i1 %t93, ptr %l54, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb16
bb16:
  %t95 = load i1, ptr %l54, !tbaa !21
  br i1 %t95, label %bb17, label %bb18
bb17:
  %t96 = load i8, ptr %l9, !tbaa !22
  %t98 = sub i8 %t96, 48
  %t100 = zext i8 %t98 to i64
  store i64 %t100, ptr %l10, !tbaa !24
  br label %bb31
bb18:
  %t102 = load i8, ptr %l9, !tbaa !22
  %t104 = icmp uge i8 %t102, 97
  br i1 %t104, label %bb19, label %bb20
bb19:
  %t106 = load i8, ptr %l9, !tbaa !22
  %t108 = icmp ule i8 %t106, 102
  store i1 %t108, ptr %l62, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb21
bb21:
  %t110 = load i1, ptr %l62, !tbaa !21
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t111 = load i8, ptr %l9, !tbaa !22
  %t113 = sub i8 %t111, 97
  %t115 = zext i8 %t113 to i64
  %t117 = add i64 %t115, 10
  store i64 %t117, ptr %l10, !tbaa !24
  br label %bb30
bb23:
  %t119 = load i8, ptr %l9, !tbaa !22
  %t121 = icmp uge i8 %t119, 65
  br i1 %t121, label %bb24, label %bb25
bb24:
  %t123 = load i8, ptr %l9, !tbaa !22
  %t125 = icmp ule i8 %t123, 70
  store i1 %t125, ptr %l71, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb26
bb26:
  %t127 = load i1, ptr %l71, !tbaa !21
  br i1 %t127, label %bb27, label %bb28
bb27:
  %t128 = load i8, ptr %l9, !tbaa !22
  %t130 = sub i8 %t128, 65
  %t132 = zext i8 %t130 to i64
  %t134 = add i64 %t132, 10
  store i64 %t134, ptr %l10, !tbaa !24
  br label %bb29
bb28:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = getelementptr %"std/json:reader", ptr %t136, i32 0, i32 1
  store i64 %t137, ptr %t140, !tbaa !24
  %t142 = insertvalue { i32, i64 } zeroinitializer, i32 65538, 0
  store { i32, i64 } %t142, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t143 = load i64, ptr %l2, !tbaa !24
  %t145 = mul i64 %t143, 16
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = add i64 %t145, %t146
  store i64 %t149, ptr %l2, !tbaa !24
  br label %bb32
bb32:
  %t151 = load i64, ptr %l7, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l7, !tbaa !24
  br label %bb7
bb33:
  %t155 = load i64, ptr %l2, !tbaa !24
  %t157 = insertvalue { i32, i64 } zeroinitializer, i64 %t155, 1
  store { i32, i64 } %t157, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i1 @std_2fjson_2estd_2fjson_3areader_2einObject(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 7
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 8
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t10
  %t15 = load i64, ptr %t14, !tbaa !34
  %t17 = icmp sge i64 %t15, 0
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2ename(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i32
  %l31 = alloca { i64, ptr }
  %l37 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t1)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/json:reader", ptr %t3, i32 0, i32 1
  %t6 = load i64, ptr %t5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"std/json:reader", ptr %t7, i32 0, i32 0
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp eq i64 %t6, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i32 65537, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"std/json:reader", ptr %t18, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/json:reader", ptr %t22, i32 0, i32 1
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i8, ptr %t28, i64 %t25
  %t30 = load i8, ptr %t29, !tbaa !32
  %t32 = icmp ne i8 %t30, 34
  br i1 %t32, label %bb5, label %bb6
bb5:
  store i32 65536, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l16, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3areader_2estring(ptr %v0, ptr %v0, ptr %t36)
  %t39 = extractvalue { i32, { i64, ptr } } %t38, 1
  %t40 = extractvalue { i32, { i64, ptr } } %t38, 0
  store i32 %t40, ptr %l20
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb9, label %ok.42, !prof !99
ok.42:
  store { i64, ptr } %t39, ptr %l19
  br label %bb8
bb8:
  %t43 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t43, ptr %l17, !tbaa !27
  br label %bb10
bb9:
  %t44 = load i32, ptr %l20, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  store i32 %t52, ptr %rv
  br label %ret
bb10:
  %t54 = load ptr, ptr %l16, !tbaa !29
  %t55 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @std_2fjson_2estd_2fjson_3areader_2epushName(ptr %v0, ptr %v0, ptr %t54, { i64, ptr } %t55)
  br label %bb11
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t56)
  br label %bb12
bb12:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"std/json:reader", ptr %t58, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"std/json:reader", ptr %t62, i32 0, i32 0
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t70 = icmp eq i64 %t61, %t67
  br i1 %t70, label %bb13, label %bb14
bb13:
  store i32 65537, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"std/json:reader", ptr %t73, i32 0, i32 0
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l31, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"std/json:reader", ptr %t77, i32 0, i32 1
  %t80 = load i64, ptr %t79, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = icmp ne i8 %t85, 58
  br i1 %t87, label %bb16, label %bb17
bb16:
  store i32 65536, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l37, !tbaa !29
  %t91 = load ptr, ptr %l37, !tbaa !29
  %t92 = getelementptr %"std/json:reader", ptr %t91, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t95 = add i64 %t93, 1
  %t97 = load ptr, ptr %l37, !tbaa !29
  %t98 = getelementptr %"std/json:reader", ptr %t97, i32 0, i32 1
  store i64 %t95, ptr %t98, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, double } @std_2fjson_2estd_2fjson_3areader_2enumber(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l10 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca i1
  %l47 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l67 = alloca i1
  %l69 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l80 = alloca i1
  %l86 = alloca i1
  %l88 = alloca ptr
  %l97 = alloca i1
  %l99 = alloca { i64, ptr }
  %l104 = alloca i1
  %l106 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l120 = alloca i1
  %l122 = alloca { i64, ptr }
  %l127 = alloca i1
  %l129 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l140 = alloca i1
  %l146 = alloca i1
  %l148 = alloca ptr
  %l153 = alloca double
  %l159 = alloca double
  %l161 = alloca { i64, ptr }
  %l162 = alloca i64
  %l164 = alloca i64
  %l165 = alloca i64
  %l170 = alloca double
  %l171 = alloca i32
  %rv = alloca { i32, double }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/json:reader", ptr %t6, i32 0, i32 0
  %t9 = load { i64, ptr }, ptr %t8, !tbaa !27
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:reader", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i8, ptr %t16, i64 %t13
  %t18 = load i8, ptr %t17, !tbaa !32
  %t20 = icmp eq i8 %t18, 45
  store i1 %t20, ptr %l2, !tbaa !21
  %t22 = load i1, ptr %l2, !tbaa !21
  br i1 %t22, label %bb1, label %bb2
bb1:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l16, !tbaa !29
  %t25 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"std/json:reader", ptr %t25, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  %t29 = add i64 %t27, 1
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = getelementptr %"std/json:reader", ptr %t31, i32 0, i32 1
  store i64 %t29, ptr %t32, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/json:reader", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t33, i64 %t37)
  store i1 %t40, ptr %l22
  br label %bb4
bb4:
  %t41 = load i1, ptr %l22, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb5, label %bb6
bb5:
  %t45 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t45, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/json:reader", ptr %t46, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l26, !tbaa !27
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"std/json:reader", ptr %t50, i32 0, i32 1
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i8, ptr %t56, i64 %t53
  %t58 = load i8, ptr %t57, !tbaa !32
  %t60 = icmp eq i8 %t58, 48
  br i1 %t60, label %bb8, label %bb9
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l31, !tbaa !29
  %t63 = load ptr, ptr %l31, !tbaa !29
  %t64 = getelementptr %"std/json:reader", ptr %t63, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = add i64 %t65, 1
  %t69 = load ptr, ptr %l31, !tbaa !29
  %t70 = getelementptr %"std/json:reader", ptr %t69, i32 0, i32 1
  store i64 %t67, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/json:reader", ptr %t72, i32 0, i32 1
  %t75 = load i64, ptr %t74, !tbaa !24
  %t78 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t71, i64 %t75)
  store i1 %t78, ptr %l37
  br label %bb10
bb9:
  br label %bb14
bb10:
  %t79 = load i1, ptr %l37, !tbaa !21
  br i1 %t79, label %bb11, label %bb12
bb11:
  %t81 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t81, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  br label %bb21
bb14:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"std/json:reader", ptr %t83, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t89 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t82, i64 %t86)
  store i1 %t89, ptr %l42
  br label %bb15
bb15:
  %t90 = load i1, ptr %l42, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t93 = load i64, ptr %l3, !tbaa !24
  %t95 = mul i64 %t93, 10
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"std/json:reader", ptr %t96, i32 0, i32 0
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"std/json:reader", ptr %t100, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t105 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i8, ptr %t106, i64 %t103
  %t108 = load i8, ptr %t107, !tbaa !32
  %t110 = sub i8 %t108, 48
  %t112 = zext i8 %t110 to i64
  %t115 = add i64 %t95, %t112
  store i64 %t115, ptr %l3, !tbaa !24
  %t117 = load i64, ptr %l4, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l4, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l56, !tbaa !29
  %t122 = load ptr, ptr %l56, !tbaa !29
  %t123 = getelementptr %"std/json:reader", ptr %t122, i32 0, i32 1
  %t124 = load i64, ptr %t123, !tbaa !24
  %t126 = add i64 %t124, 1
  %t128 = load ptr, ptr %l56, !tbaa !29
  %t129 = getelementptr %"std/json:reader", ptr %t128, i32 0, i32 1
  store i64 %t126, ptr %t129, !tbaa !24
  br label %bb19
bb19:
  br label %bb14
bb20:
  br label %bb21
bb21:
  %t130 = load i64, ptr %l4, !tbaa !24
  %t132 = icmp sle i64 %t130, 15
  store i1 %t132, ptr %l5, !tbaa !21
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"std/json:reader", ptr %t134, i32 0, i32 1
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"std/json:reader", ptr %t138, i32 0, i32 0
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t146 = icmp slt i64 %t137, %t143
  br i1 %t146, label %bb22, label %bb23
bb22:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"std/json:reader", ptr %t148, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  store { i64, ptr } %t151, ptr %l69, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"std/json:reader", ptr %t152, i32 0, i32 1
  %t155 = load i64, ptr %t154, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t155
  %t160 = load i8, ptr %t159, !tbaa !32
  %t162 = icmp eq i8 %t160, 46
  store i1 %t162, ptr %l67, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t164 = load i1, ptr %l67, !tbaa !21
  br i1 %t164, label %bb25, label %bb26
bb25:
  store i1 false, ptr %l5, !tbaa !21
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l74, !tbaa !29
  %t166 = load ptr, ptr %l74, !tbaa !29
  %t167 = getelementptr %"std/json:reader", ptr %t166, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  %t170 = add i64 %t168, 1
  %t172 = load ptr, ptr %l74, !tbaa !29
  %t173 = getelementptr %"std/json:reader", ptr %t172, i32 0, i32 1
  store i64 %t170, ptr %t173, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"std/json:reader", ptr %t175, i32 0, i32 1
  %t178 = load i64, ptr %t177, !tbaa !24
  %t181 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t174, i64 %t178)
  store i1 %t181, ptr %l80
  br label %bb27
bb26:
  br label %bb38
bb27:
  %t182 = load i1, ptr %l80, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb28, label %bb29
bb28:
  %t186 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t186, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"std/json:reader", ptr %t188, i32 0, i32 1
  %t191 = load i64, ptr %t190, !tbaa !24
  %t194 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t187, i64 %t191)
  store i1 %t194, ptr %l86
  br label %bb32
bb32:
  %t195 = load i1, ptr %l86, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l88, !tbaa !29
  %t199 = load ptr, ptr %l88, !tbaa !29
  %t200 = getelementptr %"std/json:reader", ptr %t199, i32 0, i32 1
  %t201 = load i64, ptr %t200, !tbaa !24
  %t203 = add i64 %t201, 1
  %t205 = load ptr, ptr %l88, !tbaa !29
  %t206 = getelementptr %"std/json:reader", ptr %t205, i32 0, i32 1
  store i64 %t203, ptr %t206, !tbaa !24
  br label %bb36
bb36:
  br label %bb31
bb37:
  br label %bb38
bb38:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"std/json:reader", ptr %t207, i32 0, i32 1
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"std/json:reader", ptr %t211, i32 0, i32 0
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t219 = icmp slt i64 %t210, %t216
  br i1 %t219, label %bb39, label %bb40
bb39:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"std/json:reader", ptr %t221, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l99, !tbaa !27
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"std/json:reader", ptr %t225, i32 0, i32 1
  %t228 = load i64, ptr %t227, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i8, ptr %t231, i64 %t228
  %t233 = load i8, ptr %t232, !tbaa !32
  %t235 = icmp eq i8 %t233, 101
  br i1 %t235, label %bb41, label %bb42
bb40:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb44
bb41:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb43
bb42:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"std/json:reader", ptr %t237, i32 0, i32 0
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, ptr } %t240, ptr %l106, !tbaa !27
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"std/json:reader", ptr %t241, i32 0, i32 1
  %t244 = load i64, ptr %t243, !tbaa !24
  %t246 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i8, ptr %t247, i64 %t244
  %t249 = load i8, ptr %t248, !tbaa !32
  %t251 = icmp eq i8 %t249, 69
  store i1 %t251, ptr %l104, !tbaa !21
  br label %bb43
bb43:
  %t253 = load i1, ptr %l104, !tbaa !21
  store i1 %t253, ptr %l97, !tbaa !21
  br label %bb44
bb44:
  %t254 = load i1, ptr %l97, !tbaa !21
  br i1 %t254, label %bb45, label %bb46
bb45:
  store i1 false, ptr %l5, !tbaa !21
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l111, !tbaa !29
  %t256 = load ptr, ptr %l111, !tbaa !29
  %t257 = getelementptr %"std/json:reader", ptr %t256, i32 0, i32 1
  %t258 = load i64, ptr %t257, !tbaa !24
  %t260 = add i64 %t258, 1
  %t262 = load ptr, ptr %l111, !tbaa !29
  %t263 = getelementptr %"std/json:reader", ptr %t262, i32 0, i32 1
  store i64 %t260, ptr %t263, !tbaa !24
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = getelementptr %"std/json:reader", ptr %t264, i32 0, i32 1
  %t267 = load i64, ptr %t266, !tbaa !24
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"std/json:reader", ptr %t268, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t276 = icmp slt i64 %t267, %t273
  br i1 %t276, label %bb47, label %bb48
bb46:
  br label %bb67
bb47:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"std/json:reader", ptr %t278, i32 0, i32 0
  %t281 = load { i64, ptr }, ptr %t280, !tbaa !27
  store { i64, ptr } %t281, ptr %l122, !tbaa !27
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"std/json:reader", ptr %t282, i32 0, i32 1
  %t285 = load i64, ptr %t284, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr i8, ptr %t288, i64 %t285
  %t290 = load i8, ptr %t289, !tbaa !32
  %t292 = icmp eq i8 %t290, 43
  br i1 %t292, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l120, !tbaa !21
  br label %bb52
bb49:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb51
bb50:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"std/json:reader", ptr %t294, i32 0, i32 0
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  store { i64, ptr } %t297, ptr %l129, !tbaa !27
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"std/json:reader", ptr %t298, i32 0, i32 1
  %t301 = load i64, ptr %t300, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr i8, ptr %t304, i64 %t301
  %t306 = load i8, ptr %t305, !tbaa !32
  %t308 = icmp eq i8 %t306, 45
  store i1 %t308, ptr %l127, !tbaa !21
  br label %bb51
bb51:
  %t310 = load i1, ptr %l127, !tbaa !21
  store i1 %t310, ptr %l120, !tbaa !21
  br label %bb52
bb52:
  %t311 = load i1, ptr %l120, !tbaa !21
  br i1 %t311, label %bb53, label %bb54
bb53:
  %t312 = load ptr, ptr %l0, !tbaa !29
  store ptr %t312, ptr %l134, !tbaa !29
  %t313 = load ptr, ptr %l134, !tbaa !29
  %t314 = getelementptr %"std/json:reader", ptr %t313, i32 0, i32 1
  %t315 = load i64, ptr %t314, !tbaa !24
  %t317 = add i64 %t315, 1
  %t319 = load ptr, ptr %l134, !tbaa !29
  %t320 = getelementptr %"std/json:reader", ptr %t319, i32 0, i32 1
  store i64 %t317, ptr %t320, !tbaa !24
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"std/json:reader", ptr %t322, i32 0, i32 1
  %t325 = load i64, ptr %t324, !tbaa !24
  %t328 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t321, i64 %t325)
  store i1 %t328, ptr %l140
  br label %bb56
bb56:
  %t329 = load i1, ptr %l140, !tbaa !21
  %t330 = xor i1 %t329, true
  br i1 %t330, label %bb57, label %bb58
bb57:
  %t333 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t333, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"std/json:reader", ptr %t335, i32 0, i32 1
  %t338 = load i64, ptr %t337, !tbaa !24
  %t341 = call i1 @std_2fjson_2estd_2fjson_3areader_2edigitAt(ptr %v0, ptr %t334, i64 %t338)
  store i1 %t341, ptr %l146
  br label %bb61
bb61:
  %t342 = load i1, ptr %l146, !tbaa !21
  %t343 = xor i1 %t342, true
  br i1 %t343, label %bb62, label %bb63
bb62:
  br label %bb66
bb63:
  br label %bb64
bb64:
  %t345 = load ptr, ptr %l0, !tbaa !29
  store ptr %t345, ptr %l148, !tbaa !29
  %t346 = load ptr, ptr %l148, !tbaa !29
  %t347 = getelementptr %"std/json:reader", ptr %t346, i32 0, i32 1
  %t348 = load i64, ptr %t347, !tbaa !24
  %t350 = add i64 %t348, 1
  %t352 = load ptr, ptr %l148, !tbaa !29
  %t353 = getelementptr %"std/json:reader", ptr %t352, i32 0, i32 1
  store i64 %t350, ptr %t353, !tbaa !24
  br label %bb65
bb65:
  br label %bb60
bb66:
  br label %bb67
bb67:
  %t354 = load i1, ptr %l5, !tbaa !21
  br i1 %t354, label %bb68, label %bb69
bb68:
  %t356 = load i1, ptr %l2, !tbaa !21
  br i1 %t356, label %bb70, label %bb71
bb69:
  br label %bb73
bb70:
  %t358 = load i64, ptr %l3, !tbaa !24
  %t360 = sitofp i64 %t358 to double
  %t362 = fneg double %t360
  store double %t362, ptr %l153, !tbaa !26
  br label %bb72
bb71:
  %t364 = load i64, ptr %l3, !tbaa !24
  %t366 = sitofp i64 %t364 to double
  store double %t366, ptr %l153, !tbaa !26
  br label %bb72
bb72:
  %t368 = load double, ptr %l153, !tbaa !26
  %t369 = insertvalue { i32, double } zeroinitializer, double %t368, 1
  store { i32, double } %t369, ptr %rv
  br label %ret
bb73:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"std/json:reader", ptr %t370, i32 0, i32 0
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  store { i64, ptr } %t373, ptr %l161, !tbaa !27
  %t374 = load i64, ptr %l1, !tbaa !24
  store i64 %t374, ptr %l162, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"std/json:reader", ptr %t375, i32 0, i32 1
  %t378 = load i64, ptr %t377, !tbaa !24
  store i64 %t378, ptr %l164, !tbaa !24
  %t379 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 0
  store i64 %t380, ptr %l165, !tbaa !24
  %t381 = load i64, ptr %l162, !tbaa !24
  %t382 = icmp sge i64 %t381, 0
  br i1 %t382, label %bb74, label %bb75
bb74:
  %t384 = load i64, ptr %l162, !tbaa !24
  %t385 = load i64, ptr %l164, !tbaa !24
  %t386 = icmp sle i64 %t384, %t385
  br i1 %t386, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_1d597537a8745baf_fba5a5429ece169b)
  unreachable
bb76:
  %t388 = load i64, ptr %l164, !tbaa !24
  %t389 = load i64, ptr %l165, !tbaa !24
  %t390 = icmp sle i64 %t388, %t389
  br i1 %t390, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_1d597537a8745baf_fba5a5429ece169b)
  unreachable
bb78:
  %t392 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = load i64, ptr %l162, !tbaa !24
  %t395 = load i64, ptr %l164, !tbaa !24
  %t396 = getelementptr i8, ptr %t393, i64 %t394
  %t397 = sub i64 %t395, %t394
  %t398 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t396, 1
  %t401 = call { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %t399)
  %t402 = extractvalue { i32, double } %t401, 1
  %t403 = extractvalue { i32, double } %t401, 0
  store i32 %t403, ptr %l171
  %t404 = icmp ne i32 %t403, 0
  br i1 %t404, label %bb81, label %ok.405, !prof !99
ok.405:
  store double %t402, ptr %l170
  br label %bb80
bb79:
  call void @__olang_check_failed(ptr @olang_loc_1d597537a8745baf_fba5a5429ece169b)
  unreachable
bb80:
  %t406 = load double, ptr %l170, !tbaa !26
  store double %t406, ptr %l159, !tbaa !26
  br label %bb83
bb81:
  br label %bb82
bb82:
  call void @__olang_ert_req_clear()
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load i64, ptr %l1, !tbaa !24
  %t411 = getelementptr %"std/json:reader", ptr %t407, i32 0, i32 1
  store i64 %t408, ptr %t411, !tbaa !24
  %t413 = insertvalue { i32, double } zeroinitializer, i32 65539, 0
  store { i32, double } %t413, ptr %rv
  br label %ret
bb83:
  %t414 = load double, ptr %l159, !tbaa !26
  %t417 = insertvalue { i32, double } zeroinitializer, double %t414, 1
  store { i32, double } %t417, ptr %rv
  br label %ret
ret:
  %rr = load { i32, double }, ptr %rv
  ret { i32, double } %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2eopen(ptr %v0, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l25 = alloca ptr
  %l28 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca i64
  %l90 = alloca i64
  %l93 = alloca ptr
  %l96 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 8
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr @G_2estd_2fjson_2eMaxDepth, !tbaa !24
  %t8 = icmp eq i64 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i32 65542, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/json:reader", ptr %t11, i32 0, i32 8
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/json:reader", ptr %t15, i32 0, i32 6
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  %t23 = icmp eq i64 %t14, %t20
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/json:reader", ptr %t25, i32 0, i32 6
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l2, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"std/json:reader", ptr %t30, i32 0, i32 7
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l25, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/json:reader", ptr %t36, i32 0, i32 8
  %t39 = load i64, ptr %t38, !tbaa !24
  %t41 = mul i64 %t39, 2
  store i64 %t41, ptr %l28, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sge i64 %t42, 0
  br i1 %t43, label %bb6, label %bb7
bb5:
  br label %bb26
bb6:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = icmp sle i64 %t45, 1152921504606846975
  br i1 %t46, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_85df472c87ddc01c_576e573e0ca51428)
  unreachable
bb8:
  %t48 = load i64, ptr %l28, !tbaa !24
  %t49 = mul i64 %t48, 8
  %t50 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t49)
  %t51 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t55 = getelementptr %"std/json:reader", ptr %t54, i32 0, i32 6
  store { i64, ptr } %t52, ptr %t55, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"std/json:reader", ptr %t57, i32 0, i32 8
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = mul i64 %t60, 2
  store i64 %t62, ptr %l35, !tbaa !24
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = icmp sge i64 %t63, 0
  br i1 %t64, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_85df472c87ddc01c_576e573e0ca51428)
  unreachable
bb10:
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = icmp sle i64 %t66, 1152921504606846975
  br i1 %t67, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_99863128c17f1e9_63398a4432912015)
  unreachable
bb12:
  %t69 = load i64, ptr %l35, !tbaa !24
  %t70 = mul i64 %t69, 8
  %t71 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t75 = load ptr, ptr %l32, !tbaa !29
  %t76 = getelementptr %"std/json:reader", ptr %t75, i32 0, i32 7
  store { i64, ptr } %t73, ptr %t76, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"std/json:reader", ptr %t77, i32 0, i32 8
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_99863128c17f1e9_63398a4432912015)
  unreachable
bb14:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb19
bb16:
  %t92 = load i64, ptr %l5, !tbaa !24
  %t93 = load i64, ptr %l4, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l6, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l47, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb18
bb18:
  %t108 = load i64, ptr %l47, !tbaa !24
  store i64 %t108, ptr %l44, !tbaa !24
  br label %bb19
bb19:
  %t109 = load i64, ptr %l44, !tbaa !24
  store i64 %t109, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb21, label %bb22
bb21:
  br label %bb25
bb22:
  br label %bb23
bb23:
  %t118 = load i64, ptr %l4, !tbaa !24
  %t119 = load i64, ptr %l8, !tbaa !24
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l9, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"std/json:reader", ptr %t128, i32 0, i32 6
  %t131 = load { i64, ptr }, ptr %t130, !tbaa !27
  store { i64, ptr } %t131, ptr %l66, !tbaa !27
  %t132 = load i64, ptr %l9, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t133, ptr %l68, !tbaa !27
  %t134 = load i64, ptr %l9, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i64, ptr %t137, i64 %t134
  %t139 = load i64, ptr %t138, !tbaa !34
  %t142 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i64, ptr %t143, i64 %t132
  store i64 %t139, ptr %t144, !tbaa !34
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"std/json:reader", ptr %t145, i32 0, i32 7
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l72, !tbaa !27
  %t149 = load i64, ptr %l9, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t150, ptr %l74, !tbaa !27
  %t151 = load i64, ptr %l9, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i64, ptr %t154, i64 %t151
  %t156 = load i64, ptr %t155, !tbaa !34
  %t159 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i64, ptr %t160, i64 %t149
  store i64 %t156, ptr %t161, !tbaa !34
  br label %bb24
bb24:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l8, !tbaa !24
  br label %bb20
bb25:
  br label %bb26
bb26:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"std/json:reader", ptr %t166, i32 0, i32 6
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  store { i64, ptr } %t169, ptr %l80, !tbaa !27
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"std/json:reader", ptr %t170, i32 0, i32 8
  %t173 = load i64, ptr %t172, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"std/json:reader", ptr %t174, i32 0, i32 3
  %t177 = load i64, ptr %t176, !tbaa !24
  %t180 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i64, ptr %t181, i64 %t173
  store i64 %t177, ptr %t182, !tbaa !34
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"std/json:reader", ptr %t183, i32 0, i32 7
  %t186 = load { i64, ptr }, ptr %t185, !tbaa !27
  store { i64, ptr } %t186, ptr %l86, !tbaa !27
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"std/json:reader", ptr %t187, i32 0, i32 8
  %t190 = load i64, ptr %t189, !tbaa !24
  store i64 %t190, ptr %l88, !tbaa !24
  br i1 %a1, label %bb27, label %bb28
bb27:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"std/json:reader", ptr %t193, i32 0, i32 5
  %t196 = load i64, ptr %t195, !tbaa !24
  store i64 %t196, ptr %l90, !tbaa !24
  br label %bb29
bb28:
  store i64 -1, ptr %l90, !tbaa !24
  br label %bb29
bb29:
  %t198 = load i64, ptr %l90, !tbaa !24
  %t199 = load i64, ptr %l88, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i64, ptr %t201, i64 %t199
  store i64 %t198, ptr %t202, !tbaa !34
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l93, !tbaa !29
  %t204 = load ptr, ptr %l93, !tbaa !29
  %t205 = getelementptr %"std/json:reader", ptr %t204, i32 0, i32 8
  %t206 = load i64, ptr %t205, !tbaa !24
  %t208 = add i64 %t206, 1
  %t210 = load ptr, ptr %l93, !tbaa !29
  %t211 = getelementptr %"std/json:reader", ptr %t210, i32 0, i32 8
  store i64 %t208, ptr %t211, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l96, !tbaa !29
  %t213 = load ptr, ptr %l96, !tbaa !29
  %t214 = getelementptr %"std/json:reader", ptr %t213, i32 0, i32 1
  %t215 = load i64, ptr %t214, !tbaa !24
  %t217 = add i64 %t215, 1
  %t219 = load ptr, ptr %l96, !tbaa !29
  %t220 = getelementptr %"std/json:reader", ptr %t219, i32 0, i32 1
  store i64 %t217, ptr %t220, !tbaa !24
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i8
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l53 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/json:reader", ptr %t2, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = getelementptr %"std/json:Position", ptr %t1, i32 0, i32 0
  store i64 %t5, ptr %t8, !tbaa !24
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"std/json:Position", ptr %t9, i32 0, i32 1
  store i64 1, ptr %t11, !tbaa !24
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"std/json:Position", ptr %t12, i32 0, i32 2
  store i64 1, ptr %t14, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/json:reader", ptr %t15, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb1, label %bb2
bb1:
  %t26 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l4, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t46 = load i64, ptr %l22, !tbaa !24
  store i64 %t46, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t47 = load i64, ptr %l19, !tbaa !24
  store i64 %t47, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t56 = load i64, ptr %l2, !tbaa !24
  %t57 = load i64, ptr %l6, !tbaa !24
  %t58 = load i64, ptr %l4, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/json:reader", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l41, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t64
  %t75 = load i8, ptr %t74, !tbaa !32
  store i8 %t75, ptr %l8, !tbaa !22
  %t77 = load i8, ptr %l8, !tbaa !22
  %t79 = icmp eq i8 %t77, 10
  br i1 %t79, label %bb11, label %bb12
bb11:
  %t81 = load ptr, ptr %l1, !tbaa !29
  store ptr %t81, ptr %l46, !tbaa !29
  %t82 = load ptr, ptr %l46, !tbaa !29
  %t83 = getelementptr %"std/json:Position", ptr %t82, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t88 = load ptr, ptr %l46, !tbaa !29
  %t89 = getelementptr %"std/json:Position", ptr %t88, i32 0, i32 1
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t92 = getelementptr %"std/json:Position", ptr %t90, i32 0, i32 2
  store i64 1, ptr %t92, !tbaa !24
  br label %bb16
bb12:
  %t93 = load i8, ptr %l8, !tbaa !22
  %t95 = and i8 %t93, -64
  %t97 = icmp ne i8 %t95, -128
  br i1 %t97, label %bb13, label %bb14
bb13:
  %t99 = load ptr, ptr %l1, !tbaa !29
  store ptr %t99, ptr %l53, !tbaa !29
  %t100 = load ptr, ptr %l53, !tbaa !29
  %t101 = getelementptr %"std/json:Position", ptr %t100, i32 0, i32 2
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = add i64 %t102, 1
  %t106 = load ptr, ptr %l53, !tbaa !29
  %t107 = getelementptr %"std/json:Position", ptr %t106, i32 0, i32 2
  store i64 %t104, ptr %t107, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = add i64 %t108, 1
  store i64 %t110, ptr %l6, !tbaa !24
  br label %bb7
bb18:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l65 = alloca ptr
  %t42 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/json:reader", ptr %t15, i32 0, i32 2
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/json:reader", ptr %t21, i32 0, i32 3
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = mul i64 %t24, 2
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 0
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb3, label %bb4
bb2:
  br label %bb19
bb3:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = icmp sle i64 %t35, 1152921504606846975
  br i1 %t36, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_8fccbc1a4d1c0f20_785a6b4725d4309c)
  unreachable
bb5:
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = mul i64 %t38, 8
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  %t41 = load ptr, ptr %l22, !tbaa !29
  store i64 0, ptr %t42
  br label %fill.43
fill.43:
  %t46 = load i64, ptr %t42
  %t47 = icmp slt i64 %t46, %t38
  br i1 %t47, label %fillb.44, label %filld.45
fillb.44:
  %t48 = getelementptr ptr, ptr %t40, i64 %t46
  store ptr %t41, ptr %t48
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %t42
  br label %fill.43
filld.45:
  %t50 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t40, 1
  %t53 = load ptr, ptr %l17, !tbaa !29
  %t54 = getelementptr %"std/json:reader", ptr %t53, i32 0, i32 2
  store { i64, ptr } %t51, ptr %t54, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 3
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8fccbc1a4d1c0f20_785a6b4725d4309c)
  unreachable
bb7:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb9:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t86 = load i64, ptr %l34, !tbaa !24
  store i64 %t86, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t87 = load i64, ptr %l31, !tbaa !24
  store i64 %t87, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l8, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"std/json:reader", ptr %t106, i32 0, i32 2
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l53, !tbaa !27
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t111, ptr %l55, !tbaa !27
  %t112 = load i64, ptr %l8, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 %t112
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t110
  store ptr %t117, ptr %t122, !tbaa !39
  br label %bb17
bb17:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l7, !tbaa !24
  br label %bb13
bb18:
  br label %bb19
bb19:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"std/json:reader", ptr %t127, i32 0, i32 2
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l61, !tbaa !27
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"std/json:reader", ptr %t131, i32 0, i32 3
  %t134 = load i64, ptr %t133, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr ptr, ptr %t139, i64 %t134
  store ptr %a1, ptr %t140, !tbaa !39
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l65, !tbaa !29
  %t142 = load ptr, ptr %l65, !tbaa !29
  %t143 = getelementptr %"std/json:reader", ptr %t142, i32 0, i32 3
  %t144 = load i64, ptr %t143, !tbaa !24
  %t146 = add i64 %t144, 1
  %t148 = load ptr, ptr %l65, !tbaa !29
  %t149 = getelementptr %"std/json:reader", ptr %t148, i32 0, i32 3
  store i64 %t146, ptr %t149, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2epushName(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l65 = alloca ptr
  %t42 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 5
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 4
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/json:reader", ptr %t15, i32 0, i32 4
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l2, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/json:reader", ptr %t21, i32 0, i32 5
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = mul i64 %t24, 2
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t27, ptr %l21, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %t29, i64 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !37
  store { i64, ptr } %t31, ptr %l22, !tbaa !27
  %t32 = load i64, ptr %l20, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb3, label %bb4
bb2:
  br label %bb19
bb3:
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = icmp sle i64 %t35, 576460752303423487
  br i1 %t36, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5eafb5e9a23aa169_cec655d358f6ab8d)
  unreachable
bb5:
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = mul i64 %t38, 16
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  %t41 = load { i64, ptr }, ptr %l22, !tbaa !27
  store i64 0, ptr %t42
  br label %fill.43
fill.43:
  %t46 = load i64, ptr %t42
  %t47 = icmp slt i64 %t46, %t38
  br i1 %t47, label %fillb.44, label %filld.45
fillb.44:
  %t48 = getelementptr { i64, ptr }, ptr %t40, i64 %t46
  store { i64, ptr } %t41, ptr %t48
  %t49 = add i64 %t46, 1
  store i64 %t49, ptr %t42
  br label %fill.43
filld.45:
  %t50 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t40, 1
  %t53 = load ptr, ptr %l17, !tbaa !29
  %t54 = getelementptr %"std/json:reader", ptr %t53, i32 0, i32 4
  store { i64, ptr } %t51, ptr %t54, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 5
  %t58 = load i64, ptr %t57, !tbaa !24
  store i64 %t58, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  %t64 = icmp sgt i64 %t60, %t61
  br i1 %t64, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_5eafb5e9a23aa169_cec655d358f6ab8d)
  unreachable
bb7:
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp sgt i64 %t66, 0
  br i1 %t68, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb9:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l3, !tbaa !24
  %t74 = sub i64 %t70, %t71
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = add i64 %t74, %t75
  %t80 = sub i64 %t78, 1
  %t81 = load i64, ptr %l5, !tbaa !24
  %t84 = sdiv i64 %t80, %t81
  store i64 %t84, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t86 = load i64, ptr %l34, !tbaa !24
  store i64 %t86, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t87 = load i64, ptr %l31, !tbaa !24
  store i64 %t87, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t88, %t89
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t97 = load i64, ptr %l7, !tbaa !24
  %t98 = load i64, ptr %l5, !tbaa !24
  %t101 = mul i64 %t97, %t98
  %t104 = add i64 %t96, %t101
  store i64 %t104, ptr %l8, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"std/json:reader", ptr %t106, i32 0, i32 4
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  store { i64, ptr } %t109, ptr %l53, !tbaa !27
  %t110 = load i64, ptr %l8, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t111, ptr %l55, !tbaa !27
  %t112 = load i64, ptr %l8, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %t115, i64 %t112
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !37
  %t120 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %t121, i64 %t110
  store { i64, ptr } %t117, ptr %t122, !tbaa !37
  br label %bb17
bb17:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l7, !tbaa !24
  br label %bb13
bb18:
  br label %bb19
bb19:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"std/json:reader", ptr %t127, i32 0, i32 4
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  store { i64, ptr } %t130, ptr %l61, !tbaa !27
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"std/json:reader", ptr %t131, i32 0, i32 5
  %t134 = load i64, ptr %t133, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %t139, i64 %t134
  store { i64, ptr } %a1, ptr %t140, !tbaa !37
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l65, !tbaa !29
  %t142 = load ptr, ptr %l65, !tbaa !29
  %t143 = getelementptr %"std/json:reader", ptr %t142, i32 0, i32 5
  %t144 = load i64, ptr %t143, !tbaa !24
  %t146 = add i64 %t144, 1
  %t148 = load ptr, ptr %l65, !tbaa !29
  %t149 = getelementptr %"std/json:reader", ptr %t148, i32 0, i32 5
  store i64 %t146, ptr %t149, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2erun(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i8
  %l7 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l17 = alloca i1
  %l19 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l39 = alloca i32
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l59 = alloca i32
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l77 = alloca i32
  %l81 = alloca i32
  %l103 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l113 = alloca i1
  %l115 = alloca i32
  %l117 = alloca i8
  %l119 = alloca i1
  %l120 = alloca i8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp sge i64 %t6, 3
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:reader", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr i8, ptr %t15, i64 0
  %t17 = load i8, ptr %t16, !tbaa !32
  %t19 = icmp eq i8 %t17, -17
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/json:reader", ptr %t22, i32 0, i32 0
  %t25 = load { i64, ptr }, ptr %t24, !tbaa !27
  store { i64, ptr } %t25, ptr %l14, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr i8, ptr %t27, i64 1
  %t29 = load i8, ptr %t28, !tbaa !32
  %t31 = icmp eq i8 %t29, -69
  store i1 %t31, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t33 = load i1, ptr %l12, !tbaa !21
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/json:reader", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l19, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i8, ptr %t39, i64 2
  %t41 = load i8, ptr %t40, !tbaa !32
  %t43 = icmp eq i8 %t41, -65
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l17, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/json:reader", ptr %t46, i32 0, i32 1
  store i64 3, ptr %t48, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t49)
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"std/json:reader", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp eq i64 %t54, %t60
  br i1 %t63, label %bb15, label %bb16
bb15:
  store i32 65537, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/json:reader", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l32, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/json:reader", ptr %t70, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  store i8 %t78, ptr %l1, !tbaa !22
  %t80 = load i8, ptr %l1, !tbaa !22
  %t82 = icmp eq i8 %t80, 91
  br i1 %t82, label %bb18, label %bb19
bb18:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call i32 @std_2fjson_2estd_2fjson_3areader_2eopen(ptr %v0, ptr %t84, i1 false)
  store i32 %t86, ptr %l39
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb21, label %ok.88, !prof !99
ok.88:
  br label %bb20
bb19:
  %t89 = load i8, ptr %l1, !tbaa !22
  %t91 = icmp eq i8 %t89, 123
  br i1 %t91, label %bb31, label %bb32
bb20:
  br label %bb22
bb21:
  %t93 = load i32, ptr %l39, !tbaa !23
  %t94 = lshr i32 %t93, 16
  %t95 = and i32 %t93, 65535
  %t96 = icmp eq i32 %t94, 1
  %t97 = select i1 %t96, i32 1, i32 0
  %t98 = icmp eq i32 %t93, 0
  %t99 = shl i32 %t97, 16
  %t100 = or i32 %t99, %t95
  %t101 = select i1 %t98, i32 0, i32 %t100
  store i32 %t101, ptr %rv
  br label %ret
bb22:
  %t103 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t103)
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"std/json:reader", ptr %t105, i32 0, i32 1
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"std/json:reader", ptr %t109, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t117 = icmp slt i64 %t108, %t114
  br i1 %t117, label %bb24, label %bb25
bb24:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/json:reader", ptr %t119, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  store { i64, ptr } %t122, ptr %l50, !tbaa !27
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"std/json:reader", ptr %t123, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 %t126
  %t131 = load i8, ptr %t130, !tbaa !32
  %t133 = icmp eq i8 %t131, 93
  store i1 %t133, ptr %l48, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t135 = load i1, ptr %l48, !tbaa !21
  br i1 %t135, label %bb27, label %bb28
bb27:
  %t136 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %t136)
  br label %bb29
bb28:
  br label %bb84
bb29:
  br label %bb30
bb30:
  br label %bb51
bb31:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = call i32 @std_2fjson_2estd_2fjson_3areader_2eopen(ptr %v0, ptr %t138, i1 true)
  store i32 %t140, ptr %l59
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb34, label %ok.142, !prof !99
ok.142:
  br label %bb33
bb32:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i8, ptr %l1, !tbaa !22
  %t147 = call i32 @std_2fjson_2estd_2fjson_3areader_2escalar(ptr %v0, ptr %t143, i8 %t144)
  store i32 %t147, ptr %l81
  %t148 = icmp ne i32 %t147, 0
  br i1 %t148, label %bb48, label %ok.149, !prof !99
ok.149:
  br label %bb47
bb33:
  br label %bb35
bb34:
  %t150 = load i32, ptr %l59, !tbaa !23
  %t151 = lshr i32 %t150, 16
  %t152 = and i32 %t150, 65535
  %t153 = icmp eq i32 %t151, 1
  %t154 = select i1 %t153, i32 1, i32 0
  %t155 = icmp eq i32 %t150, 0
  %t156 = shl i32 %t154, 16
  %t157 = or i32 %t156, %t152
  %t158 = select i1 %t155, i32 0, i32 %t157
  store i32 %t158, ptr %rv
  br label %ret
bb35:
  %t160 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t160)
  br label %bb36
bb36:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"std/json:reader", ptr %t162, i32 0, i32 1
  %t165 = load i64, ptr %t164, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"std/json:reader", ptr %t166, i32 0, i32 0
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t174 = icmp slt i64 %t165, %t171
  br i1 %t174, label %bb37, label %bb38
bb37:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"std/json:reader", ptr %t176, i32 0, i32 0
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  store { i64, ptr } %t179, ptr %l70, !tbaa !27
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"std/json:reader", ptr %t180, i32 0, i32 1
  %t183 = load i64, ptr %t182, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i8, ptr %t186, i64 %t183
  %t188 = load i8, ptr %t187, !tbaa !32
  %t190 = icmp eq i8 %t188, 125
  store i1 %t190, ptr %l68, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t192 = load i1, ptr %l68, !tbaa !21
  br i1 %t192, label %bb40, label %bb41
bb40:
  %t193 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %t193)
  br label %bb42
bb41:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = call i32 @std_2fjson_2estd_2fjson_3areader_2ename(ptr %v0, ptr %t195)
  store i32 %t197, ptr %l77
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb44, label %ok.199, !prof !99
ok.199:
  br label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb45
bb44:
  %t200 = load i32, ptr %l77, !tbaa !23
  %t201 = lshr i32 %t200, 16
  %t202 = and i32 %t200, 65535
  %t203 = icmp eq i32 %t201, 1
  %t204 = select i1 %t203, i32 1, i32 0
  %t205 = icmp eq i32 %t200, 0
  %t206 = shl i32 %t204, 16
  %t207 = or i32 %t206, %t202
  %t208 = select i1 %t205, i32 0, i32 %t207
  store i32 %t208, ptr %rv
  br label %ret
bb45:
  br label %bb84
bb46:
  br label %bb50
bb47:
  br label %bb49
bb48:
  %t210 = load i32, ptr %l81, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  store i32 %t218, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"std/json:reader", ptr %t220, i32 0, i32 8
  %t223 = load i64, ptr %t222, !tbaa !24
  %t225 = icmp eq i64 %t223, 0
  br i1 %t225, label %bb53, label %bb54
bb53:
  %t227 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t227)
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"std/json:reader", ptr %t229, i32 0, i32 1
  %t232 = load i64, ptr %t231, !tbaa !24
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"std/json:reader", ptr %t233, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t241 = icmp slt i64 %t232, %t238
  br i1 %t241, label %bb56, label %bb57
bb56:
  store i32 65541, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  store i32 0, ptr %rv
  br label %ret
bb59:
  %t244 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %t244)
  br label %bb60
bb60:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"std/json:reader", ptr %t246, i32 0, i32 1
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"std/json:reader", ptr %t250, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t258 = icmp eq i64 %t249, %t255
  br i1 %t258, label %bb61, label %bb62
bb61:
  store i32 65537, ptr %rv
  br label %ret
bb62:
  br label %bb63
bb63:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"std/json:reader", ptr %t261, i32 0, i32 0
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l103, !tbaa !27
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"std/json:reader", ptr %t265, i32 0, i32 1
  %t268 = load i64, ptr %t267, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i8, ptr %t271, i64 %t268
  %t273 = load i8, ptr %t272, !tbaa !32
  store i8 %t273, ptr %l2, !tbaa !22
  %t275 = load i8, ptr %l2, !tbaa !22
  %t277 = icmp eq i8 %t275, 44
  br i1 %t277, label %bb64, label %bb65
bb64:
  %t279 = load ptr, ptr %l0, !tbaa !29
  store ptr %t279, ptr %l109, !tbaa !29
  %t280 = load ptr, ptr %l109, !tbaa !29
  %t281 = getelementptr %"std/json:reader", ptr %t280, i32 0, i32 1
  %t282 = load i64, ptr %t281, !tbaa !24
  %t284 = add i64 %t282, 1
  %t286 = load ptr, ptr %l109, !tbaa !29
  %t287 = getelementptr %"std/json:reader", ptr %t286, i32 0, i32 1
  store i64 %t284, ptr %t287, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = call i1 @std_2fjson_2estd_2fjson_3areader_2einObject(ptr %v0, ptr %t288)
  store i1 %t290, ptr %l113
  br label %bb66
bb65:
  br label %bb73
bb66:
  %t291 = load i1, ptr %l113, !tbaa !21
  br i1 %t291, label %bb67, label %bb68
bb67:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = call i32 @std_2fjson_2estd_2fjson_3areader_2ename(ptr %v0, ptr %t292)
  store i32 %t294, ptr %l115
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb70, label %ok.296, !prof !99
ok.296:
  br label %bb69
bb68:
  br label %bb72
bb69:
  br label %bb71
bb70:
  %t297 = load i32, ptr %l115, !tbaa !23
  %t298 = lshr i32 %t297, 16
  %t299 = and i32 %t297, 65535
  %t300 = icmp eq i32 %t298, 1
  %t301 = select i1 %t300, i32 1, i32 0
  %t302 = icmp eq i32 %t297, 0
  %t303 = shl i32 %t301, 16
  %t304 = or i32 %t303, %t299
  %t305 = select i1 %t302, i32 0, i32 %t304
  store i32 %t305, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  br label %bb83
bb73:
  %t307 = load i8, ptr %l2, !tbaa !22
  store i8 %t307, ptr %l117, !tbaa !22
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = call i1 @std_2fjson_2estd_2fjson_3areader_2einObject(ptr %v0, ptr %t308)
  store i1 %t310, ptr %l119
  br label %bb74
bb74:
  %t311 = load i1, ptr %l119, !tbaa !21
  br i1 %t311, label %bb75, label %bb76
bb75:
  store i8 125, ptr %l120, !tbaa !22
  br label %bb77
bb76:
  store i8 93, ptr %l120, !tbaa !22
  br label %bb77
bb77:
  %t312 = load i8, ptr %l117, !tbaa !22
  %t313 = load i8, ptr %l120, !tbaa !22
  %t314 = icmp eq i8 %t312, %t313
  br i1 %t314, label %bb78, label %bb79
bb78:
  %t316 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2eclose(ptr %v0, ptr %t316)
  br label %bb80
bb79:
  store i32 65536, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  br label %bb52
bb83:
  br label %bb84
bb84:
  br label %bb13
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2escalar(ptr %v0, ptr %a0, i8 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l16 = alloca i1
  %l18 = alloca i1
  %l21 = alloca double
  %l23 = alloca double
  %l24 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca i32
  %l42 = alloca i32
  %l50 = alloca i32
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t28 = alloca { i64, [2 x i64] }, align 8
  %t101 = alloca { i64, [2 x i64] }, align 8
  %t130 = alloca { i64, [2 x i64] }, align 8
  %t156 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i8 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp eq i8 %t1, 34
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3areader_2estring(ptr %v0, ptr %v0, ptr %t6)
  %t9 = extractvalue { i32, { i64, ptr } } %t8, 1
  %t10 = extractvalue { i32, { i64, ptr } } %t8, 0
  store i32 %t10, ptr %l10
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb4, label %ok.12, !prof !99
ok.12:
  store { i64, ptr } %t9, ptr %l9
  br label %bb3
bb2:
  %t13 = load i8, ptr %l1, !tbaa !22
  %t15 = icmp eq i8 %t13, 45
  br i1 %t15, label %bb7, label %bb8
bb3:
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t17, ptr %l7, !tbaa !27
  br label %bb5
bb4:
  %t18 = load i32, ptr %l10, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  store i32 %t26, ptr %rv
  br label %ret
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 0
  store i64 5, ptr %t29
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t30, 0
  %t32 = getelementptr { i64, [2 x i64] }, ptr %t28, i32 0, i32 1
  store { { i64, ptr } } %t31, ptr %t32
  %t33 = load { i64, [2 x i64] }, ptr %t28
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t33, ptr %t35
  %t36 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t36, ptr %t35)
  br label %bb6
bb6:
  br label %bb40
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb10
bb8:
  %t38 = load i8, ptr %l1, !tbaa !22
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t38)
  store i1 %t40, ptr %l18
  br label %bb9
bb9:
  %t41 = load i1, ptr %l18, !tbaa !21
  store i1 %t41, ptr %l16, !tbaa !21
  br label %bb10
bb10:
  %t42 = load i1, ptr %l16, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/json:reader", ptr %t43, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l2, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, double } @std_2fjson_2estd_2fjson_3areader_2enumber(ptr %v0, ptr %t48)
  %t51 = extractvalue { i32, double } %t50, 1
  %t52 = extractvalue { i32, double } %t50, 0
  store i32 %t52, ptr %l24
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb14, label %ok.54, !prof !99
ok.54:
  store double %t51, ptr %l23
  br label %bb13
bb12:
  %t55 = load i8, ptr %l1, !tbaa !22
  %t57 = icmp eq i8 %t55, 116
  br i1 %t57, label %bb18, label %bb19
bb13:
  %t59 = load double, ptr %l23, !tbaa !26
  store double %t59, ptr %l21, !tbaa !26
  br label %bb15
bb14:
  %t60 = load i32, ptr %l24, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %rv
  br label %ret
bb15:
  %t70 = load double, ptr %l21, !tbaa !26
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l26, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l2, !tbaa !24
  %t78 = call ptr @std_2fjson_2estd_2fjson_3areader_2eexact(ptr %v0, ptr %v0, ptr %t72, i64 %t73, double %t70)
  store ptr %t78, ptr %l30
  br label %bb16
bb16:
  %t79 = load ptr, ptr %l26, !tbaa !29
  %t80 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t79, ptr %t80)
  br label %bb17
bb17:
  br label %bb39
bb18:
  store %olang.scope zeroinitializer, ptr %s5
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %s5, ptr %t81, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t83, ptr %l34
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb21, label %ok.85, !prof !99
ok.85:
  br label %bb20
bb19:
  %t86 = load i8, ptr %l1, !tbaa !22
  %t88 = icmp eq i8 %t86, 102
  br i1 %t88, label %bb24, label %bb25
bb20:
  br label %bb22
bb21:
  %t90 = load i32, ptr %l34, !tbaa !23
  %t91 = lshr i32 %t90, 16
  %t92 = and i32 %t90, 65535
  %t93 = icmp eq i32 %t91, 1
  %t94 = select i1 %t93, i32 1, i32 0
  %t95 = icmp eq i32 %t90, 0
  %t96 = shl i32 %t94, 16
  %t97 = or i32 %t96, %t92
  %t98 = select i1 %t95, i32 0, i32 %t97
  call void @__olang_scope_close(ptr %s5)
  store i32 %t98, ptr %rv
  br label %ret
bb22:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 0
  store i64 1, ptr %t102
  %t103 = insertvalue { i1 } undef, i1 true, 0
  %t104 = getelementptr { i64, [2 x i64] }, ptr %t101, i32 0, i32 1
  store { i1 } %t103, ptr %t104
  %t105 = load { i64, [2 x i64] }, ptr %t101
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t105, ptr %t107
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t100, ptr %t107)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %s7, ptr %t110, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t112, ptr %l42
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb27, label %ok.114, !prof !99
ok.114:
  br label %bb26
bb25:
  %t115 = load i8, ptr %l1, !tbaa !22
  %t117 = icmp eq i8 %t115, 110
  br i1 %t117, label %bb30, label %bb31
bb26:
  br label %bb28
bb27:
  %t119 = load i32, ptr %l42, !tbaa !23
  %t120 = lshr i32 %t119, 16
  %t121 = and i32 %t119, 65535
  %t122 = icmp eq i32 %t120, 1
  %t123 = select i1 %t122, i32 1, i32 0
  %t124 = icmp eq i32 %t119, 0
  %t125 = shl i32 %t123, 16
  %t126 = or i32 %t125, %t121
  %t127 = select i1 %t124, i32 0, i32 %t126
  call void @__olang_scope_close(ptr %s7)
  store i32 %t127, ptr %rv
  br label %ret
bb28:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t130
  %t131 = getelementptr { i64, [2 x i64] }, ptr %t130, i32 0, i32 0
  store i64 1, ptr %t131
  %t132 = insertvalue { i1 } undef, i1 false, 0
  %t133 = getelementptr { i64, [2 x i64] }, ptr %t130, i32 0, i32 1
  store { i1 } %t132, ptr %t133
  %t134 = load { i64, [2 x i64] }, ptr %t130
  %t136 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t134, ptr %t136
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t129, ptr %t136)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %s9, ptr %t139, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i32 %t141, ptr %l50
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb33, label %ok.143, !prof !99
ok.143:
  br label %bb32
bb31:
  store i32 65536, ptr %rv
  br label %ret
bb32:
  br label %bb34
bb33:
  %t145 = load i32, ptr %l50, !tbaa !23
  %t146 = lshr i32 %t145, 16
  %t147 = and i32 %t145, 65535
  %t148 = icmp eq i32 %t146, 1
  %t149 = select i1 %t148, i32 1, i32 0
  %t150 = icmp eq i32 %t145, 0
  %t151 = shl i32 %t149, 16
  %t152 = or i32 %t151, %t147
  %t153 = select i1 %t150, i32 0, i32 %t152
  call void @__olang_scope_close(ptr %s9)
  store i32 %t153, ptr %rv
  br label %ret
bb34:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t158 = load { i64, [2 x i64] }, ptr %t156
  %t160 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t158, ptr %t160
  call void @std_2fjson_2estd_2fjson_3areader_2epush(ptr %v0, ptr %v0, ptr %t155, ptr %t160)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3areader_2eskipSpace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/json:reader", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/json:reader", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t12 = call i64 @std_2fjson_2espaceEnd(ptr %v0, { i64, ptr } %t5, i64 %t9)
  store i64 %t12, ptr %l6
  br label %bb1
bb1:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"std/json:reader", ptr %t14, i32 0, i32 1
  store i64 %t13, ptr %t15, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @std_2fjson_2estd_2fjson_3areader_2estring(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i64
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i8
  %l12 = alloca ptr
  %l16 = alloca i64
  %l23 = alloca i1
  %l25 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca i64
  %l70 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i32
  %l95 = alloca ptr
  %l101 = alloca i64
  %l114 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i32
  %l129 = alloca { i64, ptr }
  %l134 = alloca ptr
  %s6 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  store i64 %t6, ptr %l1, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"std/json:reader", ptr %t9, i32 0, i32 0
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call i64 @std_2fjson_2eplainEnd(ptr %v0, { i64, ptr } %t12, i64 %t13)
  store i64 %t16, ptr %l16
  br label %bb1
bb1:
  %t17 = load i64, ptr %l16, !tbaa !24
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = getelementptr %"std/json:reader", ptr %t18, i32 0, i32 1
  store i64 %t17, ptr %t19, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/json:reader", ptr %t20, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/json:reader", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t32 = icmp slt i64 %t23, %t29
  br i1 %t32, label %bb2, label %bb3
bb2:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/json:reader", ptr %t34, i32 0, i32 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l25, !tbaa !27
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"std/json:reader", ptr %t38, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i8, ptr %t44, i64 %t41
  %t46 = load i8, ptr %t45, !tbaa !32
  %t48 = icmp eq i8 %t46, 34
  store i1 %t48, ptr %l23, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb4
bb4:
  %t50 = load i1, ptr %l23, !tbaa !21
  br i1 %t50, label %bb5, label %bb6
bb5:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l30, !tbaa !29
  %t52 = load ptr, ptr %l30, !tbaa !29
  %t53 = getelementptr %"std/json:reader", ptr %t52, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t56 = add i64 %t54, 1
  %t58 = load ptr, ptr %l30, !tbaa !29
  %t59 = getelementptr %"std/json:reader", ptr %t58, i32 0, i32 1
  store i64 %t56, ptr %t59, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/json:reader", ptr %t60, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l34, !tbaa !27
  %t64 = load i64, ptr %l1, !tbaa !24
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/json:reader", ptr %t65, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = sub i64 %t68, 1
  store i64 %t70, ptr %l38, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l39, !tbaa !24
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = icmp sge i64 %t73, 0
  br i1 %t74, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  %t76 = load i64, ptr %l35, !tbaa !24
  %t77 = load i64, ptr %l38, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3)
  unreachable
bb9:
  %t80 = load i64, ptr %l38, !tbaa !24
  %t81 = load i64, ptr %l39, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3)
  unreachable
bb11:
  %t84 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l35, !tbaa !24
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = getelementptr i8, ptr %t85, i64 %t86
  %t89 = sub i64 %t87, %t86
  %t90 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t88, 1
  %t93 = extractvalue { i64, ptr } %t91, 1
  %t94 = extractvalue { i64, ptr } %t91, 0
  %t95 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t94)
  call void @olang_textcopy(ptr %t95, ptr %t93, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = extractvalue { i64, ptr } %t97, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t106 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t104, 1
  store { i32, { i64, ptr } } %t106, ptr %rv
  br label %ret
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3)
  unreachable
bb13:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"std/json:reader", ptr %t107, i32 0, i32 1
  %t110 = load i64, ptr %t109, !tbaa !24
  %t111 = load i64, ptr %l1, !tbaa !24
  %t114 = sub i64 %t110, %t111
  store i64 %t114, ptr %l2, !tbaa !24
  br label %bb14
bb14:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"std/json:reader", ptr %t116, i32 0, i32 1
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"std/json:reader", ptr %t120, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t128 = icmp eq i64 %t119, %t125
  br i1 %t128, label %bb15, label %bb16
bb15:
  %t131 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65537, 0
  store { i32, { i64, ptr } } %t131, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"std/json:reader", ptr %t132, i32 0, i32 0
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  store { i64, ptr } %t135, ptr %l58, !tbaa !27
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"std/json:reader", ptr %t136, i32 0, i32 1
  %t139 = load i64, ptr %t138, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i8, ptr %t142, i64 %t139
  %t144 = load i8, ptr %t143, !tbaa !32
  store i8 %t144, ptr %l3, !tbaa !22
  %t146 = load i8, ptr %l3, !tbaa !22
  %t148 = icmp eq i8 %t146, 34
  br i1 %t148, label %bb18, label %bb19
bb18:
  br label %bb37
bb19:
  br label %bb20
bb20:
  %t150 = load i8, ptr %l3, !tbaa !22
  %t152 = icmp eq i8 %t150, 92
  br i1 %t152, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s6
  %t154 = load i64, ptr %l2, !tbaa !24
  store i64 %t154, ptr %l66, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load i64, ptr %l1, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  %t168 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eescape(ptr %v0, ptr %s6, ptr %t155, i64 %t156, { i64, ptr } %t164)
  %t169 = extractvalue { i32, i64 } %t168, 1
  %t170 = extractvalue { i32, i64 } %t168, 0
  store i32 %t170, ptr %l74
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb24, label %ok.172, !prof !99
ok.172:
  store i64 %t169, ptr %l73
  br label %bb23
bb22:
  %t173 = load i8, ptr %l3, !tbaa !22
  %t175 = icmp ult i8 %t173, 32
  br i1 %t175, label %bb26, label %bb27
bb23:
  %t177 = load i64, ptr %l73, !tbaa !24
  store i64 %t177, ptr %l67, !tbaa !24
  br label %bb25
bb24:
  %t178 = load i32, ptr %l74, !tbaa !23
  %t179 = lshr i32 %t178, 16
  %t180 = and i32 %t178, 65535
  %t181 = icmp eq i32 %t179, 1
  %t182 = select i1 %t181, i32 1, i32 0
  %t183 = icmp eq i32 %t178, 0
  %t184 = shl i32 %t182, 16
  %t185 = or i32 %t184, %t180
  %t186 = select i1 %t183, i32 0, i32 %t185
  call void @__olang_scope_close(ptr %s6)
  %t188 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t186, 0
  store { i32, { i64, ptr } } %t188, ptr %rv
  br label %ret
bb25:
  %t189 = load i64, ptr %l66, !tbaa !24
  %t190 = load i64, ptr %l67, !tbaa !24
  %t191 = add i64 %t189, %t190
  store i64 %t191, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb26:
  %t194 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t194, ptr %rv
  br label %ret
bb27:
  %t195 = load i8, ptr %l3, !tbaa !22
  %t197 = icmp ult i8 %t195, -128
  br i1 %t197, label %bb28, label %bb29
bb28:
  %t199 = load i64, ptr %l2, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l2, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l84, !tbaa !29
  %t204 = load ptr, ptr %l84, !tbaa !29
  %t205 = getelementptr %"std/json:reader", ptr %t204, i32 0, i32 1
  %t206 = load i64, ptr %t205, !tbaa !24
  %t208 = add i64 %t206, 1
  %t210 = load ptr, ptr %l84, !tbaa !29
  %t211 = getelementptr %"std/json:reader", ptr %t210, i32 0, i32 1
  store i64 %t208, ptr %t211, !tbaa !24
  br label %bb33
bb29:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eutf8(ptr %v0, ptr %t212)
  %t215 = extractvalue { i32, i64 } %t214, 1
  %t216 = extractvalue { i32, i64 } %t214, 0
  store i32 %t216, ptr %l90
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb31, label %ok.218, !prof !99
ok.218:
  store i64 %t215, ptr %l89
  br label %bb30
bb30:
  %t219 = load i64, ptr %l89, !tbaa !24
  store i64 %t219, ptr %l87, !tbaa !24
  br label %bb32
bb31:
  %t220 = load i32, ptr %l90, !tbaa !23
  %t221 = lshr i32 %t220, 16
  %t222 = and i32 %t220, 65535
  %t223 = icmp eq i32 %t221, 1
  %t224 = select i1 %t223, i32 1, i32 0
  %t225 = icmp eq i32 %t220, 0
  %t226 = shl i32 %t224, 16
  %t227 = or i32 %t226, %t222
  %t228 = select i1 %t225, i32 0, i32 %t227
  %t230 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t228, 0
  store { i32, { i64, ptr } } %t230, ptr %rv
  br label %ret
bb32:
  %t231 = load i64, ptr %l87, !tbaa !24
  store i64 %t231, ptr %l4, !tbaa !24
  %t232 = load i64, ptr %l2, !tbaa !24
  %t233 = load i64, ptr %l4, !tbaa !24
  %t236 = add i64 %t232, %t233
  store i64 %t236, ptr %l2, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l95, !tbaa !29
  %t239 = load ptr, ptr %l95, !tbaa !29
  %t240 = getelementptr %"std/json:reader", ptr %t239, i32 0, i32 1
  %t241 = load i64, ptr %t240, !tbaa !24
  %t242 = load i64, ptr %l4, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = load ptr, ptr %l95, !tbaa !29
  %t248 = getelementptr %"std/json:reader", ptr %t247, i32 0, i32 1
  store i64 %t245, ptr %t248, !tbaa !24
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb14
bb37:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"std/json:reader", ptr %t249, i32 0, i32 1
  %t252 = load i64, ptr %t251, !tbaa !24
  store i64 %t252, ptr %l5, !tbaa !24
  %t254 = load i64, ptr %l2, !tbaa !24
  store i64 %t254, ptr %l101, !tbaa !24
  %t255 = load i64, ptr %l101, !tbaa !24
  %t256 = icmp sge i64 %t255, 0
  br i1 %t256, label %bb38, label %bb39
bb38:
  %t258 = load i64, ptr %l101, !tbaa !24
  %t259 = mul i64 %t258, 1
  %t260 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t259)
  %t261 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t265 = extractvalue { i64, ptr } %t262, 0
  %t266 = extractvalue { i64, ptr } %t262, 1
  %t267 = mul i64 %t265, 1
  %t268 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t267)
  call void @llvm.memcpy.p0.p0.i64(ptr %t268, ptr %t266, i64 %t267, i1 false)
  %t269 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %t268, 1
  %t271 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t271, ptr %lp6
  %t273 = load ptr, ptr %lp6
  store { i64, ptr } %t270, ptr %t273, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i64, ptr %l1, !tbaa !24
  %t278 = getelementptr %"std/json:reader", ptr %t274, i32 0, i32 1
  store i64 %t275, ptr %t278, !tbaa !24
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_c68c402cf703814a_d8009281770a12f6)
  unreachable
bb40:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"std/json:reader", ptr %t279, i32 0, i32 1
  %t282 = load i64, ptr %t281, !tbaa !24
  %t283 = load i64, ptr %l5, !tbaa !24
  %t286 = icmp slt i64 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb41, label %bb42
bb41:
  br label %bb51
bb42:
  br label %bb43
bb43:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"std/json:reader", ptr %t290, i32 0, i32 0
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  store { i64, ptr } %t293, ptr %l114, !tbaa !27
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"std/json:reader", ptr %t294, i32 0, i32 1
  %t297 = load i64, ptr %t296, !tbaa !24
  %t299 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t300 = load ptr, ptr %t299, !tbaa !27
  %t301 = getelementptr i8, ptr %t300, i64 %t297
  %t302 = load i8, ptr %t301, !tbaa !32
  store i8 %t302, ptr %l8, !tbaa !22
  %t304 = load i8, ptr %l8, !tbaa !22
  %t306 = icmp eq i8 %t304, 92
  br i1 %t306, label %bb44, label %bb45
bb44:
  %t308 = load i64, ptr %l7, !tbaa !24
  store i64 %t308, ptr %l120, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load i64, ptr %l7, !tbaa !24
  %t311 = load ptr, ptr %lp6
  %t312 = load { i64, ptr }, ptr %t311, !tbaa !27
  %t316 = call { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eescape(ptr %v0, ptr %v1, ptr %t309, i64 %t310, { i64, ptr } %t312)
  %t317 = extractvalue { i32, i64 } %t316, 1
  %t318 = extractvalue { i32, i64 } %t316, 0
  store i32 %t318, ptr %l126
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb47, label %ok.320, !prof !99
ok.320:
  store i64 %t317, ptr %l125
  br label %bb46
bb45:
  %t321 = load ptr, ptr %lp6
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l129, !tbaa !27
  %t323 = load i64, ptr %l7, !tbaa !24
  %t324 = load i8, ptr %l8, !tbaa !22
  %t327 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr i8, ptr %t328, i64 %t323
  store i8 %t324, ptr %t329, !tbaa !32
  %t330 = load i64, ptr %l7, !tbaa !24
  %t332 = add i64 %t330, 1
  store i64 %t332, ptr %l7, !tbaa !24
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l134, !tbaa !29
  %t335 = load ptr, ptr %l134, !tbaa !29
  %t336 = getelementptr %"std/json:reader", ptr %t335, i32 0, i32 1
  %t337 = load i64, ptr %t336, !tbaa !24
  %t339 = add i64 %t337, 1
  %t341 = load ptr, ptr %l134, !tbaa !29
  %t342 = getelementptr %"std/json:reader", ptr %t341, i32 0, i32 1
  store i64 %t339, ptr %t342, !tbaa !24
  br label %bb49
bb46:
  %t343 = load i64, ptr %l125, !tbaa !24
  store i64 %t343, ptr %l121, !tbaa !24
  br label %bb48
bb47:
  %t344 = load i32, ptr %l126, !tbaa !23
  %t345 = lshr i32 %t344, 16
  %t346 = and i32 %t344, 65535
  %t347 = icmp eq i32 %t345, 1
  %t348 = select i1 %t347, i32 1, i32 0
  %t349 = icmp eq i32 %t344, 0
  %t350 = shl i32 %t348, 16
  %t351 = or i32 %t350, %t346
  %t352 = select i1 %t349, i32 0, i32 %t351
  %t354 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t352, 0
  store { i32, { i64, ptr } } %t354, ptr %rv
  br label %ret
bb48:
  %t355 = load i64, ptr %l120, !tbaa !24
  %t356 = load i64, ptr %l121, !tbaa !24
  %t357 = add i64 %t355, %t356
  store i64 %t357, ptr %l7, !tbaa !24
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb40
bb51:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i64, ptr %l5, !tbaa !24
  %t362 = add i64 %t360, 1
  %t365 = getelementptr %"std/json:reader", ptr %t359, i32 0, i32 1
  store i64 %t362, ptr %t365, !tbaa !24
  %t366 = load ptr, ptr %lp6
  %t367 = load { i64, ptr }, ptr %t366, !tbaa !27
  %t369 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t367, 1
  store { i32, { i64, ptr } } %t369, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i64 } @std_2fjson_2estd_2fjson_3areader_2eutf8(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i8
  %l2 = alloca i64
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i8
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i1
  %l24 = alloca i1
  %l33 = alloca i1
  %l51 = alloca { i64, ptr }
  %l59 = alloca i1
  %l68 = alloca i64
  %l71 = alloca i64
  %l90 = alloca { i64, ptr }
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:reader", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l13, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/json:reader", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i8, ptr %t11, i64 %t8
  %t13 = load i8, ptr %t12, !tbaa !32
  store i8 %t13, ptr %l1, !tbaa !22
  store i64 0, ptr %l2, !tbaa !24
  store i8 -128, ptr %l3, !tbaa !22
  store i8 -65, ptr %l4, !tbaa !22
  %t15 = load i8, ptr %l1, !tbaa !22
  %t17 = icmp uge i8 %t15, -62
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i8, ptr %l1, !tbaa !22
  %t21 = icmp ule i8 %t19, -33
  store i1 %t21, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l19, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  store i64 2, ptr %l2, !tbaa !24
  br label %bb30
bb5:
  %t24 = load i8, ptr %l1, !tbaa !22
  %t26 = icmp uge i8 %t24, -32
  br i1 %t26, label %bb6, label %bb7
bb6:
  %t28 = load i8, ptr %l1, !tbaa !22
  %t30 = icmp ule i8 %t28, -17
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l24, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  store i64 3, ptr %l2, !tbaa !24
  %t33 = load i8, ptr %l1, !tbaa !22
  %t35 = icmp eq i8 %t33, -32
  br i1 %t35, label %bb11, label %bb12
bb10:
  %t37 = load i8, ptr %l1, !tbaa !22
  %t39 = icmp uge i8 %t37, -16
  br i1 %t39, label %bb17, label %bb18
bb11:
  store i8 -96, ptr %l3, !tbaa !22
  br label %bb13
bb12:
  br label %bb13
bb13:
  %t41 = load i8, ptr %l1, !tbaa !22
  %t43 = icmp eq i8 %t41, -19
  br i1 %t43, label %bb14, label %bb15
bb14:
  store i8 -97, ptr %l4, !tbaa !22
  br label %bb16
bb15:
  br label %bb16
bb16:
  br label %bb29
bb17:
  %t45 = load i8, ptr %l1, !tbaa !22
  %t47 = icmp ule i8 %t45, -12
  store i1 %t47, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t49 = load i1, ptr %l33, !tbaa !21
  br i1 %t49, label %bb20, label %bb21
bb20:
  store i64 4, ptr %l2, !tbaa !24
  %t50 = load i8, ptr %l1, !tbaa !22
  %t52 = icmp eq i8 %t50, -16
  br i1 %t52, label %bb22, label %bb23
bb21:
  %t55 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t55, ptr %rv
  br label %ret
bb22:
  store i8 -112, ptr %l3, !tbaa !22
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t56 = load i8, ptr %l1, !tbaa !22
  %t58 = icmp eq i8 %t56, -12
  br i1 %t58, label %bb25, label %bb26
bb25:
  store i8 -113, ptr %l4, !tbaa !22
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/json:reader", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t64 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t63, %t64
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"std/json:reader", ptr %t68, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t76 = icmp sgt i64 %t67, %t73
  br i1 %t76, label %bb31, label %bb32
bb31:
  %t79 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t79, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"std/json:reader", ptr %t80, i32 0, i32 0
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l51, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/json:reader", ptr %t84, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t89 = add i64 %t87, 1
  %t91 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i8, ptr %t92, i64 %t89
  %t94 = load i8, ptr %t93, !tbaa !32
  store i8 %t94, ptr %l5, !tbaa !22
  %t96 = load i8, ptr %l5, !tbaa !22
  %t97 = load i8, ptr %l3, !tbaa !22
  %t100 = icmp ult i8 %t96, %t97
  br i1 %t100, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb36
bb35:
  %t102 = load i8, ptr %l5, !tbaa !22
  %t103 = load i8, ptr %l4, !tbaa !22
  %t106 = icmp ugt i8 %t102, %t103
  store i1 %t106, ptr %l59, !tbaa !21
  br label %bb36
bb36:
  %t108 = load i1, ptr %l59, !tbaa !21
  br i1 %t108, label %bb37, label %bb38
bb37:
  %t110 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t110, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  store i64 2, ptr %l6, !tbaa !24
  %t111 = load i64, ptr %l2, !tbaa !24
  store i64 %t111, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l6, !tbaa !24
  %t117 = icmp sgt i64 %t113, %t114
  br i1 %t117, label %bb40, label %bb41
bb40:
  %t119 = load i64, ptr %l8, !tbaa !24
  %t121 = icmp sgt i64 %t119, 0
  br i1 %t121, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb45
bb42:
  %t123 = load i64, ptr %l7, !tbaa !24
  %t124 = load i64, ptr %l6, !tbaa !24
  %t127 = sub i64 %t123, %t124
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = add i64 %t127, %t128
  %t133 = sub i64 %t131, 1
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = sdiv i64 %t133, %t134
  store i64 %t137, ptr %l71, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb44
bb44:
  %t139 = load i64, ptr %l71, !tbaa !24
  store i64 %t139, ptr %l68, !tbaa !24
  br label %bb45
bb45:
  %t140 = load i64, ptr %l68, !tbaa !24
  store i64 %t140, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb46
bb46:
  %t141 = load i64, ptr %l10, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb47, label %bb48
bb47:
  br label %bb54
bb48:
  br label %bb49
bb49:
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load i64, ptr %l10, !tbaa !24
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = mul i64 %t150, %t151
  %t157 = add i64 %t149, %t154
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"std/json:reader", ptr %t159, i32 0, i32 0
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l90, !tbaa !27
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"std/json:reader", ptr %t163, i32 0, i32 1
  %t166 = load i64, ptr %t165, !tbaa !24
  %t170 = add i64 %t166, %t157
  %t172 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr i8, ptr %t173, i64 %t170
  %t175 = load i8, ptr %t174, !tbaa !32
  %t177 = and i8 %t175, -64
  %t179 = icmp ne i8 %t177, -128
  br i1 %t179, label %bb50, label %bb51
bb50:
  %t182 = insertvalue { i32, i64 } zeroinitializer, i32 65540, 0
  store { i32, i64 } %t182, ptr %rv
  br label %ret
bb51:
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t183 = load i64, ptr %l10, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l10, !tbaa !24
  br label %bb46
bb54:
  %t187 = load i64, ptr %l2, !tbaa !24
  %t189 = insertvalue { i32, i64 } zeroinitializer, i64 %t187, 1
  store { i32, i64 } %t189, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2fjson_2estd_2fjson_3areader_2eword(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l51 = alloca ptr
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb6
bb3:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l16, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb5
bb5:
  %t31 = load i64, ptr %l16, !tbaa !24
  store i64 %t31, ptr %l13, !tbaa !24
  br label %bb6
bb6:
  %t32 = load i64, ptr %l13, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  br label %bb18
bb9:
  br label %bb10
bb10:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"std/json:reader", ptr %t51, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/json:reader", ptr %t55, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t63 = icmp eq i64 %t54, %t60
  br i1 %t63, label %bb11, label %bb12
bb11:
  store i32 65537, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/json:reader", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l42, !tbaa !27
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/json:reader", ptr %t70, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t79, ptr %l46, !tbaa !27
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t88 = icmp ne i8 %t78, %t85
  br i1 %t88, label %bb14, label %bb15
bb14:
  store i32 65536, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l51, !tbaa !29
  %t92 = load ptr, ptr %l51, !tbaa !29
  %t93 = getelementptr %"std/json:reader", ptr %t92, i32 0, i32 1
  %t94 = load i64, ptr %t93, !tbaa !24
  %t96 = add i64 %t94, 1
  %t98 = load ptr, ptr %l51, !tbaa !29
  %t99 = getelementptr %"std/json:reader", ptr %t98, i32 0, i32 1
  store i64 %t96, ptr %t99, !tbaa !24
  br label %bb17
bb17:
  %t100 = load i64, ptr %l6, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l6, !tbaa !24
  br label %bb7
bb18:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fjson_2estd_2fjson_3awriter_2ecolon(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:writer", ptr %t1, i32 0, i32 2
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"std/json:writer", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l7, !tbaa !27
  br label %bb3
bb3:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t13, { i64, ptr } %t14)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:writer", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:writer", ptr %t10, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t12, i8 10)
  br label %bb4
bb4:
  store i64 0, ptr %l2, !tbaa !24
  store i64 %a1, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l21, !tbaa !24
  store i64 %t42, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l18, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l7, !tbaa !24
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"std/json:writer", ptr %t62, i32 0, i32 2
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"std/json:writer", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v0, ptr %t64, { i64, ptr } %t68)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l6, !tbaa !24
  br label %bb11
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3awriter_2etext(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i8
  %l17 = alloca i64
  %l20 = alloca i64
  %l38 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/json:writer", ptr %t1, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t3, i8 34)
  br label %bb1
bb1:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l4, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l5, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l17, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l17, !tbaa !24
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l7, !tbaa !24
  %t38 = load i64, ptr %l6, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb52
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l3, !tbaa !24
  %t46 = load i64, ptr %l7, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l8, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t56
  %t61 = load i8, ptr %t60, !tbaa !32
  store i8 %t61, ptr %l9, !tbaa !22
  %t63 = load i8, ptr %l9, !tbaa !22
  %t65 = icmp uge i8 %t63, 32
  br i1 %t65, label %bb12, label %bb13
bb12:
  %t67 = load i8, ptr %l9, !tbaa !22
  %t69 = icmp ne i8 %t67, 34
  store i1 %t69, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t71 = load i1, ptr %l43, !tbaa !21
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t72 = load i8, ptr %l9, !tbaa !22
  %t74 = icmp ne i8 %t72, 92
  store i1 %t74, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l46, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  br label %bb51
bb19:
  br label %bb20
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"std/json:writer", ptr %t77, i32 0, i32 2
  store ptr %t79, ptr %l50, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l51, !tbaa !27
  %t81 = load i64, ptr %l2, !tbaa !24
  store i64 %t81, ptr %l52, !tbaa !24
  %t82 = load i64, ptr %l8, !tbaa !24
  store i64 %t82, ptr %l53, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l54, !tbaa !24
  %t85 = load i64, ptr %l52, !tbaa !24
  %t86 = icmp sge i64 %t85, 0
  br i1 %t86, label %bb21, label %bb22
bb21:
  %t88 = load i64, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = icmp sle i64 %t88, %t89
  br i1 %t90, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_b05733ff18c427e5_772a385d9f13c959)
  unreachable
bb23:
  %t92 = load i64, ptr %l53, !tbaa !24
  %t93 = load i64, ptr %l54, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b05733ff18c427e5_772a385d9f13c959)
  unreachable
bb25:
  %t96 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = load i64, ptr %l52, !tbaa !24
  %t99 = load i64, ptr %l53, !tbaa !24
  %t100 = getelementptr i8, ptr %t97, i64 %t98
  %t101 = sub i64 %t99, %t98
  %t102 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t100, 1
  %t104 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t104, { i64, ptr } %t103)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_b05733ff18c427e5_772a385d9f13c959)
  unreachable
bb27:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l2, !tbaa !24
  %t110 = load i8, ptr %l9, !tbaa !22
  %t112 = icmp eq i8 %t110, 34
  br i1 %t112, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"std/json:writer", ptr %t114, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t116, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb30
bb29:
  %t118 = load i8, ptr %l9, !tbaa !22
  %t120 = icmp eq i8 %t118, 92
  br i1 %t120, label %bb31, label %bb32
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"std/json:writer", ptr %t122, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t124, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb33
bb32:
  %t126 = load i8, ptr %l9, !tbaa !22
  %t128 = icmp eq i8 %t126, 10
  br i1 %t128, label %bb34, label %bb35
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/json:writer", ptr %t130, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t132, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb36
bb35:
  %t134 = load i8, ptr %l9, !tbaa !22
  %t136 = icmp eq i8 %t134, 9
  br i1 %t136, label %bb37, label %bb38
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"std/json:writer", ptr %t138, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s10, ptr %t140, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) })
  br label %bb39
bb38:
  %t142 = load i8, ptr %l9, !tbaa !22
  %t144 = icmp eq i8 %t142, 13
  br i1 %t144, label %bb40, label %bb41
bb39:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"std/json:writer", ptr %t146, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s12, ptr %t148, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s13
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"std/json:writer", ptr %t150, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s13, ptr %t152, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb43:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"std/json:writer", ptr %t154, i32 0, i32 2
  %t157 = load i8, ptr %l9, !tbaa !22
  %t159 = lshr i8 %t157, 4
  %t161 = zext i8 %t159 to i64
  %t163 = getelementptr { i64, ptr }, ptr @G_2estd_2fjson_2ehexDigits, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t161
  %t166 = load i8, ptr %t165, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t156, i8 %t166)
  br label %bb44
bb44:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"std/json:writer", ptr %t169, i32 0, i32 2
  %t172 = load i8, ptr %l9, !tbaa !22
  %t174 = and i8 %t172, 15
  %t176 = zext i8 %t174 to i64
  %t178 = getelementptr { i64, ptr }, ptr @G_2estd_2fjson_2ehexDigits, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i8, ptr %t179, i64 %t176
  %t181 = load i8, ptr %t180, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t171, i8 %t181)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s13)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t184 = load i64, ptr %l7, !tbaa !24
  %t186 = add i64 %t184, 1
  store i64 %t186, ptr %l7, !tbaa !24
  br label %bb8
bb52:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"std/json:writer", ptr %t188, i32 0, i32 2
  store ptr %t190, ptr %l98, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t191, ptr %l99, !tbaa !27
  %t192 = load i64, ptr %l2, !tbaa !24
  store i64 %t192, ptr %l100, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t193, 0
  store i64 %t196, ptr %l103, !tbaa !24
  %t197 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l104, !tbaa !24
  %t199 = load i64, ptr %l100, !tbaa !24
  %t200 = icmp sge i64 %t199, 0
  br i1 %t200, label %bb53, label %bb54
bb53:
  %t202 = load i64, ptr %l100, !tbaa !24
  %t203 = load i64, ptr %l103, !tbaa !24
  %t204 = icmp sle i64 %t202, %t203
  br i1 %t204, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_619d2740d221a188_b21ca0b40d9629ac)
  unreachable
bb55:
  %t206 = load i64, ptr %l103, !tbaa !24
  %t207 = load i64, ptr %l104, !tbaa !24
  %t208 = icmp sle i64 %t206, %t207
  br i1 %t208, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_619d2740d221a188_b21ca0b40d9629ac)
  unreachable
bb57:
  %t210 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !27
  %t212 = load i64, ptr %l100, !tbaa !24
  %t213 = load i64, ptr %l103, !tbaa !24
  %t214 = getelementptr i8, ptr %t211, i64 %t212
  %t215 = sub i64 %t213, %t212
  %t216 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t214, 1
  %t218 = load ptr, ptr %l98, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %t218, { i64, ptr } %t217)
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_619d2740d221a188_b21ca0b40d9629ac)
  unreachable
bb59:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"std/json:writer", ptr %t220, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t222, i8 34)
  br label %bb60
bb60:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2estd_2fjson_3awriter_2evalue(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca double
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l87 = alloca ptr
  %l88 = alloca i1
  %l105 = alloca i64
  %l108 = alloca i64
  %l134 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l146 = alloca i1
  %l152 = alloca i64
  %l159 = alloca i64
  %l163 = alloca i64
  %l166 = alloca i64
  %l193 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l202 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/json:writer", ptr %t10, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s1, ptr %t12, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb127
bb7:
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t15 = load ptr, ptr %l28, !tbaa !29
  %t16 = icmp ne ptr %t15, null
  br i1 %t16, label %bb8, label %bb9
bb8:
  %t18 = load ptr, ptr %l28, !tbaa !29
  %t19 = load i64, ptr %t18, !range !{i64 0, i64 8}
  %t21 = icmp eq i64 %t19, 1
  store i1 %t21, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t22 = load i1, ptr %l29, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb10:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr { i64, [2 x i64] }, ptr %t23, i32 0, i32 1
  %t26 = getelementptr { i1 }, ptr %t25, i32 0, i32 0
  %t27 = load i1, ptr %t26
  store i1 %t27, ptr %l3, !tbaa !21
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/json:writer", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l35, !tbaa !29
  %t32 = load i1, ptr %l3, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l37, !tbaa !27
  br label %bb15
bb15:
  %t34 = load ptr, ptr %l35, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t34, { i64, ptr } %t35)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb127
bb17:
  %t36 = load ptr, ptr %l1, !tbaa !29
  store ptr %t36, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t37 = load ptr, ptr %l38, !tbaa !29
  %t38 = icmp ne ptr %t37, null
  br i1 %t38, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l38, !tbaa !29
  %t41 = load i64, ptr %t40, !range !{i64 0, i64 8}
  %t43 = icmp eq i64 %t41, 2
  store i1 %t43, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l39, !tbaa !21
  br i1 %t44, label %bb20, label %bb21
bb20:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { double }, ptr %t47, i32 0, i32 0
  %t49 = load double, ptr %t48
  store double %t49, ptr %l4, !tbaa !26
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t51 = load double, ptr %l4, !tbaa !26
  %t52 = load double, ptr %l4, !tbaa !26
  %t55 = fcmp une double %t51, %t52
  br i1 %t55, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l47, !tbaa !21
  br label %bb25
bb24:
  %t57 = load double, ptr %l4, !tbaa !26
  %t58 = load double, ptr %l4, !tbaa !26
  %t61 = fsub double %t57, %t58
  %t63 = fcmp une double %t61, 0x0000000000000000
  store i1 %t63, ptr %l47, !tbaa !21
  br label %bb25
bb25:
  %t65 = load i1, ptr %l47, !tbaa !21
  br i1 %t65, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"std/json:writer", ptr %t66, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s4, ptr %t68, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) })
  br label %bb28
bb27:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"std/json:writer", ptr %t70, i32 0, i32 2
  %t73 = load double, ptr %l4, !tbaa !26
  call void @std_2fjson_2ewriteNumber(ptr %v0, ptr %t72, double %t73)
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb29:
  br label %bb30
bb30:
  br label %bb127
bb31:
  %t76 = load ptr, ptr %l1, !tbaa !29
  store ptr %t76, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t77 = load ptr, ptr %l57, !tbaa !29
  %t78 = icmp ne ptr %t77, null
  br i1 %t78, label %bb32, label %bb33
bb32:
  %t80 = load ptr, ptr %l57, !tbaa !29
  %t81 = load i64, ptr %t80, !range !{i64 0, i64 8}
  %t83 = icmp eq i64 %t81, 3
  store i1 %t83, ptr %l58, !tbaa !21
  br label %bb33
bb33:
  %t84 = load i1, ptr %l58, !tbaa !21
  br i1 %t84, label %bb34, label %bb35
bb34:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr { i64, [2 x i64] }, ptr %t85, i32 0, i32 1
  %t88 = getelementptr { i64 }, ptr %t87, i32 0, i32 0
  %t89 = load i64, ptr %t88
  store i64 %t89, ptr %l5, !tbaa !24
  br label %bb36
bb35:
  br label %bb38
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/json:writer", ptr %t91, i32 0, i32 2
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t94)
  %t97 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t96)
  %t98 = call i64 @__olang_fmt_i64(ptr %t97, i64 %t94)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s6, ptr %t93, { i64, ptr } %t107)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb127
bb38:
  %t110 = load ptr, ptr %l1, !tbaa !29
  store ptr %t110, ptr %l68, !tbaa !29
  store i1 false, ptr %l69, !tbaa !21
  %t111 = load ptr, ptr %l68, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb39, label %bb40
bb39:
  %t114 = load ptr, ptr %l68, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 8}
  %t117 = icmp eq i64 %t115, 4
  store i1 %t117, ptr %l69, !tbaa !21
  br label %bb40
bb40:
  %t118 = load i1, ptr %l69, !tbaa !21
  br i1 %t118, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr { i64, [2 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { i64 }, ptr %t121, i32 0, i32 0
  %t123 = load i64, ptr %t122
  store i64 %t123, ptr %l6, !tbaa !65
  br label %bb43
bb42:
  br label %bb45
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"std/json:writer", ptr %t125, i32 0, i32 2
  %t128 = load i64, ptr %l6, !tbaa !65
  %t130 = call i64 @__olang_fmt_u64(ptr null, i64 %t128)
  %t131 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t130)
  %t132 = call i64 @__olang_fmt_u64(ptr %t131, i64 %t128)
  %t133 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t131, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = extractvalue { i64, ptr } %t134, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s8, ptr %t127, { i64, ptr } %t141)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s8)
  br label %bb127
bb45:
  %t144 = load ptr, ptr %l1, !tbaa !29
  store ptr %t144, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t145 = load ptr, ptr %l79, !tbaa !29
  %t146 = icmp ne ptr %t145, null
  br i1 %t146, label %bb46, label %bb47
bb46:
  %t148 = load ptr, ptr %l79, !tbaa !29
  %t149 = load i64, ptr %t148, !range !{i64 0, i64 8}
  %t151 = icmp eq i64 %t149, 5
  store i1 %t151, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t152 = load i1, ptr %l80, !tbaa !21
  br i1 %t152, label %bb48, label %bb49
bb48:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [2 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { { i64, ptr } }, ptr %t155, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156
  store { i64, ptr } %t157, ptr %l7, !tbaa !27
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @std_2fjson_2estd_2fjson_3awriter_2etext(ptr %v0, ptr %v1, ptr %t159, { i64, ptr } %t160)
  br label %bb51
bb51:
  br label %bb127
bb52:
  %t163 = load ptr, ptr %l1, !tbaa !29
  store ptr %t163, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t164 = load ptr, ptr %l87, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb53, label %bb54
bb53:
  %t167 = load ptr, ptr %l87, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 8}
  %t170 = icmp eq i64 %t168, 6
  store i1 %t170, ptr %l88, !tbaa !21
  br label %bb54
bb54:
  %t171 = load i1, ptr %l88, !tbaa !21
  br i1 %t171, label %bb55, label %bb56
bb55:
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { { i64, ptr } }, ptr %t174, i32 0, i32 0
  %t176 = load { i64, ptr }, ptr %t175
  store { i64, ptr } %t176, ptr %l8, !tbaa !27
  br label %bb57
bb56:
  br label %bb83
bb57:
  %t178 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t182 = icmp eq i64 %t180, 0
  br i1 %t182, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s12
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"std/json:writer", ptr %t184, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s12, ptr %t186, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb61:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"std/json:writer", ptr %t188, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t190, i8 91)
  br label %bb62
bb62:
  store i64 0, ptr %l9, !tbaa !24
  %t192 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t192, 0
  store i64 %t194, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t196 = load i64, ptr %l10, !tbaa !24
  %t197 = load i64, ptr %l9, !tbaa !24
  %t200 = icmp sgt i64 %t196, %t197
  br i1 %t200, label %bb63, label %bb64
bb63:
  %t202 = load i64, ptr %l11, !tbaa !24
  %t204 = icmp sgt i64 %t202, 0
  br i1 %t204, label %bb65, label %bb66
bb64:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb68
bb65:
  %t206 = load i64, ptr %l10, !tbaa !24
  %t207 = load i64, ptr %l9, !tbaa !24
  %t210 = sub i64 %t206, %t207
  %t211 = load i64, ptr %l11, !tbaa !24
  %t214 = add i64 %t210, %t211
  %t216 = sub i64 %t214, 1
  %t217 = load i64, ptr %l11, !tbaa !24
  %t220 = sdiv i64 %t216, %t217
  store i64 %t220, ptr %l108, !tbaa !24
  br label %bb67
bb66:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb67
bb67:
  %t222 = load i64, ptr %l108, !tbaa !24
  store i64 %t222, ptr %l105, !tbaa !24
  br label %bb68
bb68:
  %t223 = load i64, ptr %l105, !tbaa !24
  store i64 %t223, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb69
bb69:
  %t224 = load i64, ptr %l13, !tbaa !24
  %t225 = load i64, ptr %l12, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb70, label %bb71
bb70:
  br label %bb80
bb71:
  br label %bb72
bb72:
  %t232 = load i64, ptr %l9, !tbaa !24
  %t233 = load i64, ptr %l13, !tbaa !24
  %t234 = load i64, ptr %l11, !tbaa !24
  %t237 = mul i64 %t233, %t234
  %t240 = add i64 %t232, %t237
  store i64 %t240, ptr %l14, !tbaa !24
  %t242 = load i64, ptr %l14, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb73, label %bb74
bb73:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t248 = getelementptr %"std/json:writer", ptr %t246, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t248, i8 44)
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l2, !tbaa !24
  %t253 = add i64 %t251, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t250, i64 %t253)
  br label %bb77
bb77:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t257, ptr %l134, !tbaa !27
  %t258 = load i64, ptr %l14, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  %t264 = load i64, ptr %l2, !tbaa !24
  %t266 = add i64 %t264, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2evalue(ptr %v0, ptr %v1, ptr %t256, ptr %t263, i64 %t266)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t270 = load i64, ptr %l13, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l13, !tbaa !24
  br label %bb69
bb80:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i64, ptr %l2, !tbaa !24
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t274, i64 %t275)
  br label %bb81
bb81:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"std/json:writer", ptr %t278, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t280, i8 93)
  br label %bb82
bb82:
  br label %bb127
bb83:
  %t282 = load ptr, ptr %l1, !tbaa !29
  store ptr %t282, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t283 = load ptr, ptr %l145, !tbaa !29
  %t284 = icmp ne ptr %t283, null
  br i1 %t284, label %bb84, label %bb85
bb84:
  %t286 = load ptr, ptr %l145, !tbaa !29
  %t287 = load i64, ptr %t286, !range !{i64 0, i64 8}
  %t289 = icmp eq i64 %t287, 7
  store i1 %t289, ptr %l146, !tbaa !21
  br label %bb85
bb85:
  %t290 = load i1, ptr %l146, !tbaa !21
  br i1 %t290, label %bb86, label %bb87
bb86:
  %t291 = load ptr, ptr %l1, !tbaa !29
  %t293 = getelementptr { i64, [2 x i64] }, ptr %t291, i32 0, i32 1
  %t294 = getelementptr { ptr }, ptr %t293, i32 0, i32 0
  %t295 = load ptr, ptr %t294
  store ptr %t295, ptr %l15, !tbaa !29
  br label %bb88
bb87:
  br label %bb121
bb88:
  %t297 = load ptr, ptr %l15, !tbaa !29
  %t299 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t297)
  store i64 %t299, ptr %l152
  br label %bb89
bb89:
  %t300 = load i64, ptr %l152, !tbaa !24
  %t301 = icmp eq i64 %t300, 0
  br i1 %t301, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s18
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"std/json:writer", ptr %t303, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s18, ptr %t305, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s18)
  br label %ret
bb93:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"std/json:writer", ptr %t307, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t309, i8 123)
  br label %bb94
bb94:
  store i64 0, ptr %l16, !tbaa !24
  %t311 = load ptr, ptr %l15, !tbaa !29
  %t313 = call i64 @std_2fjson_2estd_2fjson_3aObject_2eLen(ptr %v1, ptr %t311)
  store i64 %t313, ptr %l159
  br label %bb95
bb95:
  %t314 = load i64, ptr %l159, !tbaa !24
  store i64 %t314, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t315 = load i64, ptr %l17, !tbaa !24
  %t316 = load i64, ptr %l16, !tbaa !24
  %t319 = icmp sgt i64 %t315, %t316
  br i1 %t319, label %bb96, label %bb97
bb96:
  %t321 = load i64, ptr %l18, !tbaa !24
  %t323 = icmp sgt i64 %t321, 0
  br i1 %t323, label %bb98, label %bb99
bb97:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb101
bb98:
  %t325 = load i64, ptr %l17, !tbaa !24
  %t326 = load i64, ptr %l16, !tbaa !24
  %t329 = sub i64 %t325, %t326
  %t330 = load i64, ptr %l18, !tbaa !24
  %t333 = add i64 %t329, %t330
  %t335 = sub i64 %t333, 1
  %t336 = load i64, ptr %l18, !tbaa !24
  %t339 = sdiv i64 %t335, %t336
  store i64 %t339, ptr %l166, !tbaa !24
  br label %bb100
bb99:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb100
bb100:
  %t341 = load i64, ptr %l166, !tbaa !24
  store i64 %t341, ptr %l163, !tbaa !24
  br label %bb101
bb101:
  %t342 = load i64, ptr %l163, !tbaa !24
  store i64 %t342, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s20
  %t343 = load i64, ptr %l20, !tbaa !24
  %t344 = load i64, ptr %l19, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s20)
  br label %bb118
bb104:
  br label %bb105
bb105:
  %t351 = load i64, ptr %l16, !tbaa !24
  %t352 = load i64, ptr %l20, !tbaa !24
  %t353 = load i64, ptr %l18, !tbaa !24
  %t356 = mul i64 %t352, %t353
  %t359 = add i64 %t351, %t356
  store i64 %t359, ptr %l21, !tbaa !24
  %t361 = load i64, ptr %l21, !tbaa !24
  %t363 = icmp sgt i64 %t361, 0
  br i1 %t363, label %bb106, label %bb107
bb106:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"std/json:writer", ptr %t365, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t367, i8 44)
  br label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb109
bb109:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i64, ptr %l2, !tbaa !24
  %t372 = add i64 %t370, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t369, i64 %t372)
  br label %bb110
bb110:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load ptr, ptr %l15, !tbaa !29
  %t378 = getelementptr %"std/json:Object", ptr %t376, i32 0, i32 0
  %t379 = load { i64, ptr }, ptr %t378, !tbaa !27
  store { i64, ptr } %t379, ptr %l193, !tbaa !27
  %t380 = load i64, ptr %l21, !tbaa !24
  %t382 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t383 = load ptr, ptr %t382, !tbaa !27
  %t384 = getelementptr { i64, ptr }, ptr %t383, i64 %t380
  %t385 = load { i64, ptr }, ptr %t384, !tbaa !37
  call void @std_2fjson_2estd_2fjson_3awriter_2etext(ptr %v0, ptr %v1, ptr %t375, { i64, ptr } %t385)
  br label %bb111
bb111:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"std/json:writer", ptr %t388, i32 0, i32 2
  store ptr %t390, ptr %l197, !tbaa !29
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"std/json:writer", ptr %t391, i32 0, i32 0
  %t394 = load { i64, ptr }, ptr %t393, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t398 = icmp sgt i64 %t396, 0
  br i1 %t398, label %bb112, label %bb113
bb112:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l202, !tbaa !27
  br label %bb114
bb113:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l202, !tbaa !27
  br label %bb114
bb114:
  %t400 = load ptr, ptr %l197, !tbaa !29
  %t401 = load { i64, ptr }, ptr %l202, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s20, ptr %t400, { i64, ptr } %t401)
  br label %bb115
bb115:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load ptr, ptr %l15, !tbaa !29
  %t405 = getelementptr %"std/json:Object", ptr %t403, i32 0, i32 1
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  store { i64, ptr } %t406, ptr %l205, !tbaa !27
  %t407 = load i64, ptr %l21, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l205, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr ptr, ptr %t410, i64 %t407
  %t412 = load ptr, ptr %t411, !tbaa !39
  %t413 = load i64, ptr %l2, !tbaa !24
  %t415 = add i64 %t413, 1
  call void @std_2fjson_2estd_2fjson_3awriter_2evalue(ptr %v0, ptr %v1, ptr %t402, ptr %t412, i64 %t415)
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s20)
  br label %bb117
bb117:
  %t419 = load i64, ptr %l20, !tbaa !24
  %t421 = add i64 %t419, 1
  store i64 %t421, ptr %l20, !tbaa !24
  br label %bb102
bb118:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i64, ptr %l2, !tbaa !24
  call void @std_2fjson_2estd_2fjson_3awriter_2enewline(ptr %v0, ptr %t423, i64 %t424)
  br label %bb119
bb119:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"std/json:writer", ptr %t427, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %t429, i8 125)
  br label %bb120
bb120:
  br label %bb127
bb121:
  br i1 true, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  br label %bb126
bb124:
  store %olang.scope zeroinitializer, ptr %s23
  %t431 = load ptr, ptr %l0, !tbaa !29
  %t433 = getelementptr %"std/json:writer", ptr %t431, i32 0, i32 2
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s23, ptr %t433, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s23)
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_a9bf92283d37587a_a12d0c4bd2035d0e)
  unreachable
bb127:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fjson_2ewriteNumber(ptr %v0, ptr %a0, double %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l2, !tbaa !29
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t4 = call ptr @__olang_sb_room(ptr %s1, i64 48)
  %t5 = call i64 @__olang_fmt_float(ptr %t4, i64 48, double %a1, i32 0)
  call void @__olang_sb_add(ptr %s1, i64 %t5)
  %t6 = load ptr, ptr %s1
  %t7 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t8 = load i64, ptr %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t6, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t13 = load ptr, ptr %t12
  %t14 = icmp ne ptr %t13, null
  br i1 %t14, label %sbgrew.15, label %sbdone.16
sbgrew.15:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.16
sbdone.16:
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  %t24 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s0, ptr %t24, { i64, ptr } %t23)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, %"std/json:Key" } @std_2fjson_3aKey_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i1
  %rv = alloca { i32, %"std/json:Key" }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std__23(ptr %v0, { i64, ptr } %t1)
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_ert_req_set(ptr @olang_loc_17e8b6f43f7ea001_b2ed193611229185)
  %t8 = insertvalue { i32, %"std/json:Key" } zeroinitializer, i32 65536, 0
  store { i32, %"std/json:Key" } %t8, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = insertvalue %"std/json:Key" undef, { i64, ptr } %t9, 0
  %t14 = insertvalue { i32, %"std/json:Key" } zeroinitializer, %"std/json:Key" %t12, 1
  store { i32, %"std/json:Key" } %t14, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/json:Key" }, ptr %rv
  ret { i32, %"std/json:Key" } %rr
}

define dso_local { i32, %"std/json:Object" } @std_2fjson_3aObject_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %rv = alloca { i32, %"std/json:Object" }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp ne i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t12 = insertvalue { i32, %"std/json:Object" } zeroinitializer, i32 65545, 0
  store { i32, %"std/json:Object" } %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = call { i64, ptr } @std_2fjson_2enameIndex(ptr %v0, ptr %v2, { i64, ptr } %t17)
  store { i64, ptr } %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t22 = insertvalue %"std/json:Object" undef, { i64, ptr } %t21, 0
  %t23 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = insertvalue %"std/json:Object" %t22, { i64, ptr } %t23, 1
  %t26 = insertvalue %"std/json:Object" %t24, { i64, ptr } %t20, 2
  %t28 = insertvalue { i32, %"std/json:Object" } zeroinitializer, %"std/json:Object" %t26, 1
  store { i32, %"std/json:Object" } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/json:Object" }, ptr %rv
  ret { i32, %"std/json:Object" } %rr
}

define dso_local %"std/json:Position" @std_2fjson_3aPosition_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"std/json:Position"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"std/json:Position" undef, i64 0, 0
  %t4 = insertvalue %"std/json:Position" %t2, i64 1, 1
  %t6 = insertvalue %"std/json:Position" %t4, i64 1, 2
  store %"std/json:Position" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"std/json:Position", ptr %rv
  ret %"std/json:Position" %rr
}

define dso_local %"std/json:Skip" @std_2fjson_3aSkip_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"std/json:Skip"
  br label %start
start:
  br label %bb0
bb0:
  store %"std/json:Skip" zeroinitializer, ptr %rv
  br label %ret
ret:
  %rr = load %"std/json:Skip", ptr %rv
  ret %"std/json:Skip" %rr
}

define dso_local %"std/json:reader" @std_2fjson_3areader_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l12 = alloca ptr
  %rv = alloca %"std/json:reader"
  %t3 = alloca { i64, [2 x i64] }, align 8
  %t15 = alloca i64
  %t32 = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t3
  %t4 = getelementptr { i64, [2 x i64] }, ptr %t3, i32 0, i32 0
  store i64 0, ptr %t4
  %t5 = load { i64, [2 x i64] }, ptr %t3
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store { i64, [2 x i64] } %t5, ptr %t7
  store ptr %t7, ptr %l12, !tbaa !29
  %t8 = icmp sge i64 64, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = icmp sle i64 64, 1152921504606846975
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a9d90acfb58a0efc_8cee310d77323458)
  unreachable
bb3:
  %t12 = mul i64 64, 8
  %t13 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t12)
  %t14 = load ptr, ptr %l12, !tbaa !29
  store i64 0, ptr %t15
  br label %fill.16
fill.16:
  %t19 = load i64, ptr %t15
  %t20 = icmp slt i64 %t19, 64
  br i1 %t20, label %fillb.17, label %filld.18
fillb.17:
  %t21 = getelementptr ptr, ptr %t13, i64 %t19
  store ptr %t14, ptr %t21
  %t22 = add i64 %t19, 1
  store i64 %t22, ptr %t15
  br label %fill.16
filld.18:
  %t23 = insertvalue { i64, ptr } undef, i64 64, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t13, 1
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t26 = icmp sge i64 16, 0
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a9d90acfb58a0efc_8cee310d77323458)
  unreachable
bb5:
  %t28 = icmp sle i64 16, 576460752303423487
  br i1 %t28, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_b0f269ec47121b49_ffa527191fa405c5)
  unreachable
bb7:
  %t30 = mul i64 16, 16
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  store i64 0, ptr %t32
  br label %fill.33
fill.33:
  %t36 = load i64, ptr %t32
  %t37 = icmp slt i64 %t36, 16
  br i1 %t37, label %fillb.34, label %filld.35
fillb.34:
  %t38 = getelementptr { i64, ptr }, ptr %t31, i64 %t36
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %t38
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %t32
  br label %fill.33
filld.35:
  %t40 = insertvalue { i64, ptr } undef, i64 16, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t31, 1
  store { i64, ptr } %t41, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t43 = icmp sge i64 16, 0
  br i1 %t43, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b0f269ec47121b49_ffa527191fa405c5)
  unreachable
bb9:
  %t45 = icmp sle i64 16, 1152921504606846975
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_2b7d333750119e8a_5164bda0dfbd4ba6)
  unreachable
bb11:
  %t47 = mul i64 16, 8
  %t48 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 16, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  %t52 = icmp sge i64 16, 0
  br i1 %t52, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2b7d333750119e8a_5164bda0dfbd4ba6)
  unreachable
bb13:
  %t54 = icmp sle i64 16, 1152921504606846975
  br i1 %t54, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8e53cae89060ac5f_4eb6599badda6f3b)
  unreachable
bb15:
  %t56 = mul i64 16, 8
  %t57 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 16, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = insertvalue %"std/json:reader" undef, { i64, ptr } %t61, 0
  %t63 = load i64, ptr %l2, !tbaa !24
  %t64 = insertvalue %"std/json:reader" %t62, i64 %t63, 1
  %t65 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = insertvalue %"std/json:reader" %t64, { i64, ptr } %t65, 2
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = insertvalue %"std/json:reader" %t66, i64 %t67, 3
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t70 = insertvalue %"std/json:reader" %t68, { i64, ptr } %t69, 4
  %t71 = load i64, ptr %l6, !tbaa !24
  %t72 = insertvalue %"std/json:reader" %t70, i64 %t71, 5
  %t73 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t74 = insertvalue %"std/json:reader" %t72, { i64, ptr } %t73, 6
  %t76 = insertvalue %"std/json:reader" %t74, { i64, ptr } %t59, 7
  %t78 = insertvalue %"std/json:reader" %t76, i64 0, 8
  store %"std/json:reader" %t78, ptr %rv
  br label %ret
bb16:
  call void @__olang_check_failed(ptr @olang_loc_8e53cae89060ac5f_4eb6599badda6f3b)
  unreachable
ret:
  %rr = load %"std/json:reader", ptr %rv
  ret %"std/json:reader" %rr
}

define dso_local %"std/json:writer" @std_2fjson_3awriter_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l7 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/json:writer"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i32 %a1, ptr %l3
  %t5 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v1)
  store %"std/prelude/text:StringBuilder" %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load %"std/prelude/text:StringBuilder", ptr %l7
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = insertvalue %"std/json:writer" undef, { i64, ptr } %t7, 0
  %t9 = load i32, ptr %l3, !range !{i32 0, i32 4}
  %t10 = insertvalue %"std/json:writer" %t8, i32 %t9, 1
  %t12 = insertvalue %"std/json:writer" %t10, %"std/prelude/text:StringBuilder" %t6, 2
  store %"std/json:writer" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"std/json:writer", ptr %rv
  ret %"std/json:writer" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_check_failed(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\22" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5C\5C" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cn" }>, align 8
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Ct" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\5Cr" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\5Cu00" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d16 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
declare i64 @__olang_fmt_u64(ptr, i64)
@.d18 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"[]" }>, align 8
@.d19 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"{}" }>, align 8
@.d20 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d21 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_float(ptr, i64, double, i32)
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
define internal i1 @std__23(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a0, 0
  %t5 = icmp sgt i64 %t3, 0
  %t7 = xor i1 %t5, true
  br i1 %t7, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @__olang_ert_req_set(ptr) cold
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
@olang_loc_bc241580f27121ab_ca64d2d20e518e77 = external constant [0 x i8]
@olang_loc_19fd7578c5cb7196_ea7f2a837a8496c2 = external constant [0 x i8]
declare i64 @std_2fjson_2enameHash_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fjson_2esameName_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_6a96f216a7a18db5_c7851721732fae9 = external constant [0 x i8]
@olang_loc_2a2c934c6745fec4_9721022dc2e60418 = external constant [0 x i8]
@olang_loc_247b9c864b1325ff_f9e87c5eec2e2b33 = external constant [0 x i8]
@olang_loc_7a4bfc7c7b524c63_98397af697b8e9df = external constant [0 x i8]
@olang_loc_fa9f38c9682d865a_6f1f2fc1eaeb7f26 = external constant [0 x i8]
@olang_loc_c3fd3a937aadf066_df3562c3c4e6c4da = external constant [0 x i8]
@olang_loc_9bf067a17252b335_30d904505e687d39 = external constant [0 x i8]
@olang_loc_d2781e368edd9e2f_3a33f3735a4c4ba3 = external constant [0 x i8]
@olang_loc_a7b0a92300089828_a6e8a6d400231804 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a07ba4d7ff0a56f9_d8356302010b83f5 = external constant [0 x i8]
@olang_loc_22f1698915dd4682_a0313dce564b9a3e = external constant [0 x i8]
declare { i32, i64 } @std_2fjson_2estd_2fjson_3aObject_2efind_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_e7435678738af803_3f3d624b6ec28d3f = external constant [0 x i8]
@olang_loc_cd6f075822d3ba64_2e9ce5061183e548 = external constant [0 x i8]
@olang_loc_a95109d49c9a5ab2_e7f3aa33cdaf23de = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
@olang_loc_664da5dbc2e51de6_83a7e6ee135f5f2a = external constant [0 x i8]
declare { i64, ptr } @std_2fjson_2eEncode_3cstd_2fjson_3aJson_26_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
@olang_loc_3d7deb9fd92cdf7_48602bd2c42c5c33 = external constant [0 x i8]
@olang_loc_4cf869d60c4ca172_ef56e6f5157a9496 = external constant [0 x i8]
@olang_loc_a4e4729341d0d567_917d86fd422044ab = external constant [0 x i8]
@olang_loc_78dc4052a96c39eb_b95510f79f72ba17 = external constant [0 x i8]
@olang_loc_9ab7127216e6ddd3_9523f6c3485c577 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseUint(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_1d597537a8745baf_fba5a5429ece169b = external constant [0 x i8]
declare { i32, double } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseFloat(ptr %v0, { i64, ptr } %a0)
@olang_loc_85df472c87ddc01c_576e573e0ca51428 = external constant [0 x i8]
@olang_loc_99863128c17f1e9_63398a4432912015 = external constant [0 x i8]
@olang_loc_8fccbc1a4d1c0f20_785a6b4725d4309c = external constant [0 x i8]
@olang_loc_5eafb5e9a23aa169_cec655d358f6ab8d = external constant [0 x i8]
@olang_loc_3a08abdf75e4d0df_f65d8e83429a56b3 = external constant [0 x i8]
@olang_loc_c68c402cf703814a_d8009281770a12f6 = external constant [0 x i8]
@olang_loc_b05733ff18c427e5_772a385d9f13c959 = external constant [0 x i8]
@olang_loc_619d2740d221a188_b21ca0b40d9629ac = external constant [0 x i8]
@olang_loc_a9bf92283d37587a_a12d0c4bd2035d0e = external constant [0 x i8]
@olang_loc_17e8b6f43f7ea001_b2ed193611229185 = external constant [0 x i8]
@olang_loc_a9d90acfb58a0efc_8cee310d77323458 = external constant [0 x i8]
@olang_loc_b0f269ec47121b49_ffa527191fa405c5 = external constant [0 x i8]
@olang_loc_2b7d333750119e8a_5164bda0dfbd4ba6 = external constant [0 x i8]
@olang_loc_8e53cae89060ac5f_4eb6599badda6f3b = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
