; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, [8 x i64], [8 x i64], [8 x i64] }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
define dso_local void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %l11 = alloca i32
  %l16 = alloca i32
  %l21 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_lock(ptr %t9)
  store i32 %t11, ptr %l5
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 8
  store i1 true, ptr %t14, !tbaa !21
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t15, i32 0, i32 10
  %t19 = insertvalue { i64, ptr } undef, i64 8, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  %t23 = extractvalue { i64, ptr } %t20, 1
  %t24 = extractvalue { i64, ptr } %t20, 0
  %t25 = call i32 @pthread_cond_broadcast(ptr %t23)
  store i32 %t25, ptr %l11
  br label %bb2
bb2:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t26, i32 0, i32 11
  %t30 = insertvalue { i64, ptr } undef, i64 8, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = extractvalue { i64, ptr } %t31, 0
  %t36 = call i32 @pthread_cond_broadcast(ptr %t34)
  store i32 %t36, ptr %l16
  br label %bb3
bb3:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t37, i32 0, i32 9
  %t41 = insertvalue { i64, ptr } undef, i64 8, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = extractvalue { i64, ptr } %t42, 0
  %t47 = call i32 @pthread_mutex_unlock(ptr %t45)
  store i32 %t47, ptr %l21
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fchan_2eInit_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l15 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_init(ptr %t9, i64 0)
  store i32 %t11, ptr %l5
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 10
  %t16 = insertvalue { i64, ptr } undef, i64 8, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t14, 1
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = extractvalue { i64, ptr } %t17, 0
  %t22 = call i32 @pthread_cond_init(ptr %t20, i64 0)
  store i32 %t22, ptr %l10
  br label %bb2
bb2:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t23, i32 0, i32 11
  %t27 = insertvalue { i64, ptr } undef, i64 8, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t25, 1
  %t31 = extractvalue { i64, ptr } %t28, 1
  %t32 = extractvalue { i64, ptr } %t28, 0
  %t33 = call i32 @pthread_cond_init(ptr %t31, i64 0)
  store i32 %t33, ptr %l15
  br label %bb3
bb3:
  br label %ret
ret:
  ret void
}

define dso_local { i32, i64 } @std_2fchan_2eRecv_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca i32
  %l10 = alloca i1
  %l23 = alloca i32
  %l31 = alloca i32
  %l34 = alloca i64
  %l39 = alloca i32
  %rv = alloca { i32, i64 }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_lock(ptr %t9)
  store i32 %t11, ptr %l6
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp eq i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t19, i32 0, i32 8
  %t22 = load i1, ptr %t21, !tbaa !21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t26 = load i1, ptr %l10, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t29, i32 0, i32 10
  %t33 = insertvalue { i64, ptr } undef, i64 8, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t36, i32 0, i32 9
  %t40 = insertvalue { i64, ptr } undef, i64 8, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t38, 1
  %t44 = extractvalue { i64, ptr } %t34, 1
  %t45 = extractvalue { i64, ptr } %t34, 0
  %t47 = extractvalue { i64, ptr } %t41, 1
  %t48 = extractvalue { i64, ptr } %t41, 0
  %t49 = call i32 @pthread_cond_wait(ptr %t44, ptr %t47)
  store i32 %t49, ptr %l23
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t50, i32 0, i32 4
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t57, i32 0, i32 9
  %t61 = insertvalue { i64, ptr } undef, i64 8, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t59, 1
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = extractvalue { i64, ptr } %t62, 0
  %t67 = call i32 @pthread_mutex_unlock(ptr %t65)
  store i32 %t67, ptr %l31
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t69 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t69, ptr %rv
  br label %ret
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i64 @std_2fchan_2eoldest_3cI64_3e(ptr %v0, ptr %t70)
  store i64 %t72, ptr %l34
  br label %bb16
bb16:
  %t73 = load i64, ptr %l34, !tbaa !24
  store i64 %t73, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t74, i32 0, i32 9
  %t78 = insertvalue { i64, ptr } undef, i64 8, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = extractvalue { i64, ptr } %t79, 0
  %t84 = call i32 @pthread_mutex_unlock(ptr %t82)
  store i32 %t84, ptr %l39
  br label %bb17
bb17:
  %t85 = load i64, ptr %l1, !tbaa !24
  %t87 = insertvalue { i32, i64 } zeroinitializer, i64 %t85, 1
  store { i32, i64 } %t87, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l7 = alloca i32
  %l13 = alloca i1
  %l26 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i1
  %l40 = alloca i1
  %l53 = alloca i32
  %l56 = alloca i1
  %l63 = alloca i32
  %l69 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 9
  %t5 = insertvalue { i64, ptr } undef, i64 8, 0
  %t6 = insertvalue { i64, ptr } %t5, ptr %t3, 1
  %t9 = extractvalue { i64, ptr } %t6, 1
  %t10 = extractvalue { i64, ptr } %t6, 0
  %t11 = call i32 @pthread_mutex_lock(ptr %t9)
  store i32 %t11, ptr %l7
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t12, i32 0, i32 4
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t16, i32 0, i32 0
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = icmp eq i64 %t15, %t19
  br i1 %t22, label %bb3, label %bb4
bb3:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t24, i32 0, i32 8
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l13, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb6, label %bb7
bb6:
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t34, i32 0, i32 11
  %t38 = insertvalue { i64, ptr } undef, i64 8, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t41, i32 0, i32 9
  %t45 = insertvalue { i64, ptr } undef, i64 8, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t43, 1
  %t49 = extractvalue { i64, ptr } %t39, 1
  %t50 = extractvalue { i64, ptr } %t39, 0
  %t52 = extractvalue { i64, ptr } %t46, 1
  %t53 = extractvalue { i64, ptr } %t46, 0
  %t54 = call i32 @pthread_cond_wait(ptr %t49, ptr %t52)
  store i32 %t54, ptr %l26
  br label %bb9
bb9:
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t55)
  store i32 %t57, ptr %l28
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb13, label %ok.59
ok.59:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t60 = load i32, ptr %l28, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  store i32 %t68, ptr %rv
  br label %ret
bb14:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t74 = call i64 @std_2fchan_2eplace_3cI64_3e(ptr %v0, ptr %t70, i64 %a1)
  store i64 %t74, ptr %l32
  br label %bb15
bb15:
  %t75 = load i64, ptr %l32, !tbaa !24
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t76, i32 0, i32 5
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb17, label %bb18
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t81, i32 0, i32 7
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = load i64, ptr %l2, !tbaa !24
  %t88 = icmp sle i64 %t84, %t85
  store i1 %t88, ptr %l35, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb19
bb19:
  %t90 = load i1, ptr %l35, !tbaa !21
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t91, i32 0, i32 8
  %t94 = load i1, ptr %t93, !tbaa !21
  %t96 = xor i1 %t94, true
  store i1 %t96, ptr %l40, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb22
bb22:
  %t98 = load i1, ptr %l40, !tbaa !21
  %t99 = xor i1 %t98, true
  br i1 %t99, label %bb23, label %bb24
bb23:
  br label %bb28
bb24:
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t101, i32 0, i32 11
  %t105 = insertvalue { i64, ptr } undef, i64 8, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t108, i32 0, i32 9
  %t112 = insertvalue { i64, ptr } undef, i64 8, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t110, 1
  %t116 = extractvalue { i64, ptr } %t106, 1
  %t117 = extractvalue { i64, ptr } %t106, 0
  %t119 = extractvalue { i64, ptr } %t113, 1
  %t120 = extractvalue { i64, ptr } %t113, 0
  %t121 = call i32 @pthread_cond_wait(ptr %t116, ptr %t119)
  store i32 %t121, ptr %l53
  br label %bb26
bb26:
  br label %bb27
bb27:
  br label %bb16
bb28:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t122, i32 0, i32 5
  %t125 = load i1, ptr %t124, !tbaa !21
  br i1 %t125, label %bb29, label %bb30
bb29:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t127, i32 0, i32 7
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load i64, ptr %l2, !tbaa !24
  %t134 = icmp sle i64 %t130, %t131
  store i1 %t134, ptr %l56, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t136 = load i1, ptr %l56, !tbaa !21
  br i1 %t136, label %bb32, label %bb33
bb32:
  %t137 = load ptr, ptr %l0, !tbaa !29
  call void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %t137)
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = call i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %t139)
  store i32 %t141, ptr %l63
  %t142 = icmp ne i32 %t141, 0
  br i1 %t142, label %bb36, label %ok.143
ok.143:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t144 = load i32, ptr %l63, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  store i32 %t152, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t154, i32 0, i32 9
  %t158 = insertvalue { i64, ptr } undef, i64 8, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = extractvalue { i64, ptr } %t159, 0
  %t164 = call i32 @pthread_mutex_unlock(ptr %t162)
  store i32 %t164, ptr %l69
  br label %bb39
bb39:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @std_2fchan_2eoldest_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l26 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t5, i32 0, i32 2
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i64, ptr %t11, i64 %t8
  %t13 = load i64, ptr %t12, !tbaa !34
  store i64 %t13, ptr %l1, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = srem i64 %t21, %t25
  %t31 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t15, i32 0, i32 2
  store i64 %t28, ptr %t31, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = sub i64 %t36, 1
  %t41 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t32, i32 0, i32 4
  store i64 %t38, ptr %t41, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t43, i32 0, i32 7
  %t46 = load i64, ptr %t45, !tbaa !24
  %t48 = add i64 %t46, 1
  %t51 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t42, i32 0, i32 7
  store i64 %t48, ptr %t51, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t52, i32 0, i32 11
  %t56 = insertvalue { i64, ptr } undef, i64 8, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t54, 1
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = extractvalue { i64, ptr } %t57, 0
  %t62 = call i32 @pthread_cond_broadcast(ptr %t60)
  store i32 %t62, ptr %l26
  br label %bb1
bb1:
  %t63 = load i64, ptr %l1, !tbaa !24
  store i64 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fchan_2eplace_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l37 = alloca i32
  %rv = alloca i64
  %t26 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t11, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l8, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l9, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t17 = icmp sge i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t19 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp sle i64 %t19, 1152921504606846975
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_8b1ab3db35ebb480_65ad3ecc104fb344)
  unreachable
bb5:
  %t22 = load i64, ptr %l8, !tbaa !24
  %t23 = mul i64 %t22, 8
  %t24 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t23)
  %t25 = load i64, ptr %l9, !tbaa !24
  store i64 0, ptr %t26
  br label %fill.27
fill.27:
  %t30 = load i64, ptr %t26
  %t31 = icmp slt i64 %t30, %t22
  br i1 %t31, label %fillb.28, label %filld.29
fillb.28:
  %t32 = getelementptr i64, ptr %t24, i64 %t30
  store i64 %t25, ptr %t32
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %t26
  br label %fill.27
filld.29:
  %t34 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t24, 1
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t37, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t38, !tbaa !27
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_8b1ab3db35ebb480_65ad3ecc104fb344)
  unreachable
bb7:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l14, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = load i64, ptr %l1, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i64, ptr %t51, i64 %t46
  store i64 %t47, ptr %t52, !tbaa !34
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t54, i32 0, i32 3
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = add i64 %t57, 1
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t60, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = srem i64 %t59, %t63
  %t69 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t53, i32 0, i32 3
  store i64 %t66, ptr %t69, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t71, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = add i64 %t74, 1
  %t79 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t70, i32 0, i32 4
  store i64 %t76, ptr %t79, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t81, i32 0, i32 6
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 1
  %t89 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t80, i32 0, i32 6
  store i64 %t86, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t90, i32 0, i32 10
  %t94 = insertvalue { i64, ptr } undef, i64 8, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t92, 1
  %t98 = extractvalue { i64, ptr } %t95, 1
  %t99 = extractvalue { i64, ptr } %t95, 0
  %t100 = call i32 @pthread_cond_broadcast(ptr %t98)
  store i32 %t100, ptr %l37
  br label %bb8
bb8:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t101, i32 0, i32 6
  %t104 = load i64, ptr %t103, !tbaa !24
  %t106 = sub i64 %t104, 1
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @std_2fchan_2esendOpen_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l7 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 8
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t6, i32 0, i32 9
  %t10 = insertvalue { i64, ptr } undef, i64 8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = extractvalue { i64, ptr } %t11, 0
  %t16 = call i32 @pthread_mutex_unlock(ptr %t14)
  store i32 %t16, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i32 65536, ptr %rv
  br label %ret
bb4:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i32
  %rv = alloca { i32, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, i64 } @std_2fchan_2eRecv_3cI64_3e(ptr %v0, ptr %a0)
  %t4 = extractvalue { i32, i64 } %t3, 1
  %t5 = extractvalue { i32, i64 } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store i64 %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l1, !tbaa !24
  br label %bb6
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 0, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, i64 } zeroinitializer, i32 %t22, 0
  store { i32, i64 } %t24, ptr %rv
  br label %ret
bb5:
  call void @__olang_ert_req_clear()
  %t26 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t26, ptr %rv
  br label %ret
bb6:
  %t27 = load i64, ptr %l1, !tbaa !24
  %t28 = insertvalue { i32, i64 } zeroinitializer, i64 %t27, 1
  store { i32, i64 } %t28, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local void @std_2fchan_2ewithdraw_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l11 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t1, i32 0, i32 3
  store i64 0, ptr %t3, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t4, i32 0, i32 4
  store i64 0, ptr %t6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t8, i32 0, i32 6
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = sub i64 %t11, 1
  %t16 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t7, i32 0, i32 6
  store i64 %t13, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %t17, i32 0, i32 11
  %t21 = insertvalue { i64, ptr } undef, i64 8, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t19, 1
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = extractvalue { i64, ptr } %t22, 0
  %t27 = call i32 @pthread_cond_broadcast(ptr %t25)
  store i32 %t27, ptr %l11
  br label %bb1
bb1:
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l15 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l31 = alloca %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 1, ptr %l15, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l0, !tbaa !24
  store i64 %t5, ptr %l15, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l15, !tbaa !24
  store i64 %t7, ptr %l1, !tbaa !24
  %t8 = icmp sge i64 0, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = icmp sle i64 0, 1152921504606846975
  br i1 %t10, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_bfa795281152369c_da61951da24f83c0)
  unreachable
bb6:
  %t12 = mul i64 0, 8
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 0, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  %t17 = load i64, ptr %l0, !tbaa !24
  %t19 = icmp eq i64 %t17, 0
  %t21 = load i32, ptr @G_2estd_2fchan_2eMutexWords, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l23, !tbaa !24
  %t24 = insertvalue [8 x i64] undef, i64 0, 0
  %t25 = insertvalue [8 x i64] %t24, i64 0, 1
  %t26 = insertvalue [8 x i64] %t25, i64 0, 2
  %t27 = insertvalue [8 x i64] %t26, i64 0, 3
  %t28 = insertvalue [8 x i64] %t27, i64 0, 4
  %t29 = insertvalue [8 x i64] %t28, i64 0, 5
  %t30 = insertvalue [8 x i64] %t29, i64 0, 6
  %t31 = insertvalue [8 x i64] %t30, i64 0, 7
  %t33 = load i32, ptr @G_2estd_2fchan_2eCondWords, !tbaa !23
  %t35 = sext i32 %t33 to i64
  store i64 %t35, ptr %l26, !tbaa !24
  %t36 = insertvalue [8 x i64] undef, i64 0, 0
  %t37 = insertvalue [8 x i64] %t36, i64 0, 1
  %t38 = insertvalue [8 x i64] %t37, i64 0, 2
  %t39 = insertvalue [8 x i64] %t38, i64 0, 3
  %t40 = insertvalue [8 x i64] %t39, i64 0, 4
  %t41 = insertvalue [8 x i64] %t40, i64 0, 5
  %t42 = insertvalue [8 x i64] %t41, i64 0, 6
  %t43 = insertvalue [8 x i64] %t42, i64 0, 7
  %t45 = load i32, ptr @G_2estd_2fchan_2eCondWords, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l29, !tbaa !24
  %t48 = insertvalue [8 x i64] undef, i64 0, 0
  %t49 = insertvalue [8 x i64] %t48, i64 0, 1
  %t50 = insertvalue [8 x i64] %t49, i64 0, 2
  %t51 = insertvalue [8 x i64] %t50, i64 0, 3
  %t52 = insertvalue [8 x i64] %t51, i64 0, 4
  %t53 = insertvalue [8 x i64] %t52, i64 0, 5
  %t54 = insertvalue [8 x i64] %t53, i64 0, 6
  %t55 = insertvalue [8 x i64] %t54, i64 0, 7
  %t57 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 0
  %t58 = load i64, ptr %l1, !tbaa !24
  store i64 %t58, ptr %t57, !tbaa !24
  %t59 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 1
  store { i64, ptr } %t15, ptr %t59, !tbaa !27
  %t61 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 2
  store i64 0, ptr %t61, !tbaa !24
  %t63 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 3
  store i64 0, ptr %t63, !tbaa !24
  %t65 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 4
  store i64 0, ptr %t65, !tbaa !24
  %t67 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 5
  store i1 %t19, ptr %t67, !tbaa !21
  %t69 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 6
  store i64 0, ptr %t69, !tbaa !24
  %t71 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 7
  store i64 0, ptr %t71, !tbaa !24
  %t73 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 8
  store i1 false, ptr %t73, !tbaa !21
  %t75 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 9
  store [8 x i64] %t31, ptr %t75
  %t77 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 10
  store [8 x i64] %t43, ptr %t77
  %t79 = getelementptr %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", ptr %l31, i32 0, i32 11
  store [8 x i64] %t55, ptr %t79
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l31, i64 272, i1 false)
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_bfa795281152369c_da61951da24f83c0)
  unreachable
ret:
  ret void
}

define dso_local void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l0 = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp slt i64 %t3, 2
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t11 = extractvalue { ptr, ptr } %pg1, 0
  %t12 = extractvalue { ptr, ptr } %pg1, 1
  call void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %t7, ptr %t11, ptr %t12)
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eCountOf_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = add i64 %t9, 1
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t22 = sub i64 %t16, %t19
  %t25 = icmp sle i64 %t13, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  br label %bb21
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t35 = icmp slt i64 %t29, %t32
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t37, ptr %l24, !tbaa !27
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr i8, ptr %t45, i64 %t42
  %t47 = load i8, ptr %t46, !tbaa !32
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l29, !tbaa !27
  %t49 = load i64, ptr %l4, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr i8, ptr %t52, i64 %t49
  %t54 = load i8, ptr %t53, !tbaa !32
  %t57 = icmp eq i8 %t47, %t54
  store i1 %t57, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t59 = load i1, ptr %l23, !tbaa !21
  %t60 = xor i1 %t59, true
  br i1 %t60, label %bb12, label %bb13
bb12:
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t62 = load i64, ptr %l4, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l4, !tbaa !24
  br label %bb15
bb15:
  br label %bb8
bb16:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t72 = icmp eq i64 %t66, %t69
  br i1 %t72, label %bb17, label %bb18
bb17:
  %t74 = load i64, ptr %l2, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l2, !tbaa !24
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = add i64 %t78, %t81
  store i64 %t84, ptr %l3, !tbaa !24
  br label %bb19
bb18:
  %t86 = load i64, ptr %l3, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l3, !tbaa !24
  br label %bb19
bb19:
  br label %bb20
bb20:
  br label %bb4
bb21:
  %t90 = load i64, ptr %l2, !tbaa !24
  store i64 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l24 = alloca i64
  %l36 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eCountOf_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = sub i64 %t13, %t16
  %t22 = mul i64 %t6, %t19
  %t25 = add i64 %t9, %t22
  store i64 %t25, ptr %l24, !tbaa !24
  %t26 = load i64, ptr %l24, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  br i1 %t27, label %bb2, label %bb3
bb2:
  %t29 = load i64, ptr %l24, !tbaa !24
  %t30 = mul i64 %t29, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  %t34 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 16, i64 8)
  store ptr %t34, ptr %lp4
  %t36 = load ptr, ptr %lp4
  store { i64, ptr } %t33, ptr %t36, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_9ac06bd1685c6a0e_7032635af5bb7b02)
  unreachable
bb4:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t43 = icmp sle i64 %t37, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb5, label %bb6
bb5:
  br label %bb36
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t53 = icmp slt i64 %t47, %t50
  br i1 %t53, label %bb9, label %bb10
bb9:
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t65 = icmp slt i64 %t59, %t62
  store i1 %t65, ptr %l36, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb11
bb11:
  %t67 = load i1, ptr %l36, !tbaa !21
  br i1 %t67, label %bb12, label %bb13
bb12:
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t68, ptr %l44, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i8, ptr %t76, i64 %t73
  %t78 = load i8, ptr %t77, !tbaa !32
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t79, ptr %l49, !tbaa !27
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t88 = icmp eq i8 %t78, %t85
  store i1 %t88, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t90 = load i1, ptr %l43, !tbaa !21
  %t91 = xor i1 %t90, true
  br i1 %t91, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  br label %bb8
bb19:
  %t97 = load i64, ptr %l7, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t103 = icmp eq i64 %t97, %t100
  br i1 %t103, label %bb20, label %bb21
bb20:
  %t105 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l10, !tbaa !24
  br label %bb22
bb21:
  br label %bb31
bb22:
  %t111 = load i64, ptr %l9, !tbaa !24
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t119 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t119, ptr %l67, !tbaa !27
  %t120 = load i64, ptr %l9, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = load i64, ptr %l5, !tbaa !24
  %t130 = load ptr, ptr %lp4
  %t132 = getelementptr { i64, ptr }, ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i8, ptr %t133, i64 %t127
  store i8 %t125, ptr %t134, !tbaa !32
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l5, !tbaa !24
  br label %bb26
bb26:
  %t139 = load i64, ptr %l9, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l9, !tbaa !24
  br label %bb22
bb27:
  %t143 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t147 = icmp sgt i64 %t145, 0
  br i1 %t147, label %bb28, label %bb29
bb28:
  %t149 = load i64, ptr %l6, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t155 = add i64 %t149, %t152
  store i64 %t155, ptr %l6, !tbaa !24
  br label %bb35
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t157 = load i64, ptr %l6, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp eq i64 %t157, %t160
  br i1 %t163, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t165 = load i64, ptr %l5, !tbaa !24
  %t166 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t166, ptr %l88, !tbaa !27
  %t167 = load i64, ptr %l6, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i8, ptr %t170, i64 %t167
  %t172 = load i8, ptr %t171, !tbaa !32
  %t174 = load ptr, ptr %lp4
  %t176 = getelementptr { i64, ptr }, ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i8, ptr %t177, i64 %t165
  store i8 %t172, ptr %t178, !tbaa !32
  %t179 = load i64, ptr %l5, !tbaa !24
  %t181 = add i64 %t179, 1
  store i64 %t181, ptr %l5, !tbaa !24
  %t183 = load i64, ptr %l6, !tbaa !24
  %t185 = add i64 %t183, 1
  store i64 %t185, ptr %l6, !tbaa !24
  br label %bb35
bb35:
  br label %bb4
bb36:
  %t187 = load ptr, ptr %lp4
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 576460752303423487
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_da59c7d8c597efe4_403a3926fe1e900)
  unreachable
bb5:
  %t15 = mul i64 0, 16
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_da59c7d8c597efe4_403a3926fe1e900)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %t35, i64 0
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !37
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 576460752303423487
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_da8028beccd66af1_6af34333739c302d)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 16
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load { i64, ptr }, ptr %l21, !tbaa !27
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr { i64, ptr }, ptr %t46, i64 %t52
  store { i64, ptr } %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_da8028beccd66af1_6af34333739c302d)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %t125, i64 %t122
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !37
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %t131, i64 %t114
  store { i64, ptr } %t127, ptr %t132, !tbaa !37
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aSt_H6b52d0e061b38fc17540e408f348b2aa(ptr %v0, ptr %v1, ptr %t20, i64 %t26, { i64, ptr } %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t38
  store { i64, ptr } %t39, ptr %t44, !tbaa !37
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr i64, ptr %t11, i64 %a1
  %t13 = load i64, ptr %t12, !tbaa !34
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI64_3e_2eroom_3cI64_3e(ptr %v0, ptr %t20, i64 %t26, i64 %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr i64, ptr %t43, i64 %t38
  store i64 %t39, ptr %t44, !tbaa !34
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l17 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t48 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t13 = icmp sle i64 0, 1152921504606846975
  br i1 %t13, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4d945ec18b41639d_846c036da6ee75b9)
  unreachable
bb5:
  %t15 = mul i64 0, 8
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4d945ec18b41639d_846c036da6ee75b9)
  unreachable
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t30, i32 0, i32 0
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l20, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i64, ptr %t35, i64 0
  %t37 = load i64, ptr %t36, !tbaa !34
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l17, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load i64, ptr %l17, !tbaa !24
  %t42 = icmp sle i64 %t41, 1152921504606846975
  br i1 %t42, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_10c8bc13a6db10f0_81f1e7574e9afc2c)
  unreachable
bb10:
  %t44 = load i64, ptr %l17, !tbaa !24
  %t45 = mul i64 %t44, 8
  %t46 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t45)
  %t47 = load i64, ptr %l21, !tbaa !24
  store i64 0, ptr %t48
  br label %fill.49
fill.49:
  %t52 = load i64, ptr %t48
  %t53 = icmp slt i64 %t52, %t44
  br i1 %t53, label %fillb.50, label %filld.51
fillb.50:
  %t54 = getelementptr i64, ptr %t46, i64 %t52
  store i64 %t47, ptr %t54
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %t48
  br label %fill.49
filld.51:
  %t56 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t46, 1
  store { i64, ptr } %t57, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t59, i32 0, i32 0
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t62, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  store i64 %t65, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l2, !tbaa !24
  %t71 = icmp sgt i64 %t67, %t68
  br i1 %t71, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_10c8bc13a6db10f0_81f1e7574e9afc2c)
  unreachable
bb12:
  %t73 = load i64, ptr %l4, !tbaa !24
  %t75 = icmp sgt i64 %t73, 0
  br i1 %t75, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb17
bb14:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = sub i64 %t77, %t78
  %t82 = load i64, ptr %l4, !tbaa !24
  %t85 = add i64 %t81, %t82
  %t87 = sub i64 %t85, 1
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sdiv i64 %t87, %t88
  store i64 %t91, ptr %l34, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb16
bb16:
  %t93 = load i64, ptr %l34, !tbaa !24
  store i64 %t93, ptr %l31, !tbaa !24
  br label %bb17
bb17:
  %t94 = load i64, ptr %l31, !tbaa !24
  store i64 %t94, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  %t99 = icmp slt i64 %t95, %t96
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t103 = load i64, ptr %l2, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t105 = load i64, ptr %l4, !tbaa !24
  %t108 = mul i64 %t104, %t105
  %t111 = add i64 %t103, %t108
  store i64 %t111, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t113, ptr %l52, !tbaa !27
  %t114 = load i64, ptr %l7, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t118, i32 0, i32 0
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l56, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i64, ptr %t125, i64 %t122
  %t127 = load i64, ptr %t126, !tbaa !34
  %t130 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i64, ptr %t131, i64 %t114
  store i64 %t127, ptr %t132, !tbaa !34
  br label %bb22
bb22:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t135 = add i64 %t133, 1
  store i64 %t135, ptr %l6, !tbaa !24
  br label %bb18
bb23:
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/build:Unit"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/build:Unit", ptr %t11, i64 %a1
  %t13 = load %"compiler/build:Unit", ptr %t12
  store %"compiler/build:Unit" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Unit", ptr %rv
  ret %"compiler/build:Unit" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1) #0 {
entry:
  %l1 = alloca %"compiler/build:Unit"
  %l2 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l21 = alloca ptr
  store %"compiler/build:Unit" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 1
  %t9 = load i64, ptr %t8, !tbaa !24
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t18 = icmp eq i64 %t9, %t15
  br i1 %t18, label %bb1, label %bb2
bb1:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t27 = load %"compiler/build:Unit", ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbuild_3aUnit_3e_2eroom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %t20, i64 %t26, %"compiler/build:Unit" %t27)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t31, i32 0, i32 0
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  store { i64, ptr } %t34, ptr %l17, !tbaa !27
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load %"compiler/build:Unit", ptr %l1
  %t42 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/build:Unit", ptr %t43, i64 %t38
  store %"compiler/build:Unit" %t39, ptr %t44
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l21, !tbaa !29
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 1
  %t48 = load i64, ptr %t47, !tbaa !24
  %t50 = add i64 %t48, 1
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t52, i32 0, i32 1
  store i64 %t50, ptr %t53, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l37 = alloca { i64, ptr }
  %l41 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l17, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l17, !tbaa !24
  store i64 %t35, ptr %l14, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l14, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t55, i32 0, i32 0
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t58, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %t65, i64 %t53
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !37
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %t67, { i64, ptr } %a1)
  store i1 %t71, ptr %l41
  br label %bb11
bb11:
  %t72 = load i1, ptr %l41, !tbaa !21
  br i1 %t72, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l6, !tbaa !24
  br label %bb7
bb16:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %t11, i64 %a1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !37
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45 = dso_local alias void (ptr, ptr, ptr, { i64, ptr }), ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22
@std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451 = dso_local alias { i64, ptr } (ptr, ptr, ptr), ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122
define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aSt_H6b52d0e061b38fc17540e408f348b2aa(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store { i64, ptr } %a2, ptr %l40, !tbaa !27
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 576460752303423487
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_106f465f5c4a3bb_5092cc0760828757)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 16
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load { i64, ptr }, ptr %l40, !tbaa !27
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr { i64, ptr }, ptr %t69, i64 %t75
  store { i64, ptr } %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_106f465f5c4a3bb_5092cc0760828757)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %t146, i64 %t143
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !37
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %t152, i64 %t141
  store { i64, ptr } %t148, ptr %t153, !tbaa !37
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cI64_3e_2eroom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store i64 %a2, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 1152921504606846975
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_edc1999b8064b64f_198ad4786a3ba21b)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 8
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load i64, ptr %l40, !tbaa !24
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr i64, ptr %t69, i64 %t75
  store i64 %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_edc1999b8064b64f_198ad4786a3ba21b)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i64, ptr %t146, i64 %t143
  %t148 = load i64, ptr %t147, !tbaa !34
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i64, ptr %t152, i64 %t141
  store i64 %t148, ptr %t153, !tbaa !34
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3ccompiler_2fbuild_3aUnit_3e_2eroom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/build:Unit" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l21 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca %"compiler/build:Unit"
  %l51 = alloca i64
  %l54 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l21, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l21, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l21, !tbaa !24
  store i64 %t30, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l3, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l4, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  store %"compiler/build:Unit" %a2, ptr %l40
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp sle i64 %t64, 164703072086692425
  br i1 %t65, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_49ee0ffb07b0661f_9b526ad68fdfe46b)
  unreachable
bb15:
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = mul i64 %t67, 56
  %t69 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t68)
  %t70 = load %"compiler/build:Unit", ptr %l40
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr %"compiler/build:Unit", ptr %t69, i64 %t75
  store %"compiler/build:Unit" %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  %t82 = load ptr, ptr %l38, !tbaa !29
  %t83 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t82, i32 0, i32 0
  store { i64, ptr } %t80, ptr %t83, !tbaa !27
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t84, i32 0, i32 0
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  store { i64, ptr } %t87, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  store i64 %t92, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = icmp sgt i64 %t94, %t95
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_49ee0ffb07b0661f_9b526ad68fdfe46b)
  unreachable
bb17:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  br i1 %t102, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb22
bb19:
  %t104 = load i64, ptr %l7, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = sub i64 %t104, %t105
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = add i64 %t108, %t109
  %t114 = sub i64 %t112, 1
  %t115 = load i64, ptr %l8, !tbaa !24
  %t118 = sdiv i64 %t114, %t115
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l51, !tbaa !24
  br label %bb22
bb22:
  %t121 = load i64, ptr %l51, !tbaa !24
  store i64 %t121, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t122 = load i64, ptr %l10, !tbaa !24
  %t123 = load i64, ptr %l9, !tbaa !24
  %t126 = icmp slt i64 %t122, %t123
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t131 = load i64, ptr %l10, !tbaa !24
  %t132 = load i64, ptr %l8, !tbaa !24
  %t135 = mul i64 %t131, %t132
  %t138 = add i64 %t130, %t135
  store i64 %t138, ptr %l11, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t140, ptr %l72, !tbaa !27
  %t141 = load i64, ptr %l11, !tbaa !24
  %t142 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t142, ptr %l74, !tbaa !27
  %t143 = load i64, ptr %l11, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/build:Unit", ptr %t146, i64 %t143
  %t148 = load %"compiler/build:Unit", ptr %t147
  %t151 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr %"compiler/build:Unit", ptr %t152, i64 %t141
  store %"compiler/build:Unit" %t148, ptr %t153
  br label %bb27
bb27:
  %t154 = load i64, ptr %l10, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l10, !tbaa !24
  br label %bb23
bb28:
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  br label %ret
ret:
  ret void
}

@std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cstd_2fprelude_2ftext_3aString_26__H0dbca0afa342a6533a6fc2b6f3df3a92 = dso_local alias void (ptr, ptr, ptr, i64, { i64, ptr }), ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aSt_H6b52d0e061b38fc17540e408f348b2aa
define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %r
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %t5
  %t8 = insertvalue %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" undef, ptr %t5, 0
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector = dso_local alias %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" (ptr, i64), ptr @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector
define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 576460752303423487
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_d48e46a613c6a6b0_d47489a6fe7f2fac)
  unreachable
bb3:
  %t5 = mul i64 0, 16
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t13 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" undef, { i64, ptr } %t8, 0
  %t15 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t13, i64 0, 1
  %t17 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t15, i64 %a0, 2
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_d48e46a613c6a6b0_d47489a6fe7f2fac)
  unreachable
ret:
  %rr = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cI64_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %r = tail call %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %r
}

define dso_local %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = icmp sge i64 0, 0
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = icmp sle i64 0, 164703072086692425
  br i1 %t3, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cfe35b05666e821f_c7fed8e60a4cb0b3)
  unreachable
bb3:
  %t5 = mul i64 0, 56
  %t6 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 0, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  %t13 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" undef, { i64, ptr } %t8, 0
  %t15 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t13, i64 0, 1
  %t17 = insertvalue %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t15, i64 %a0, 2
  store %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %rv
  br label %ret
bb4:
  call void @__olang_check_failed(ptr @olang_loc_cfe35b05666e821f_c7fed8e60a4cb0b3)
  unreachable
ret:
  %rr = load %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" %rr
}

@std_2fprelude_2fvec_3avecState_3cstd_2fprelude_2ftext_3aString_26_3e_2ector = dso_local alias %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" (ptr, i64), ptr @std_2fprelude_2fvec_3avecState_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector
declare i32 @pthread_mutex_lock(ptr)
declare i32 @pthread_cond_broadcast(ptr)
declare i32 @pthread_mutex_unlock(ptr)
declare i32 @pthread_mutex_init(ptr, i64)
declare i32 @pthread_cond_init(ptr, i64)
declare i32 @pthread_cond_wait(ptr, ptr)
declare void @__olang_check_failed(ptr)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @__olang_ert_req_clear()
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@olang_loc_8b1ab3db35ebb480_65ad3ecc104fb344 = external constant [0 x i8]
@olang_loc_bfa795281152369c_da61951da24f83c0 = external constant [0 x i8]
@G_2estd_2fchan_2eMutexWords = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2estd_2fchan_2eCondWords = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
declare void @std_2fprelude_2farray_2esortMergeBuffered_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
@olang_loc_9ac06bd1685c6a0e_7032635af5bb7b02 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
@olang_loc_da59c7d8c597efe4_403a3926fe1e900 = external constant [0 x i8]
@olang_loc_da8028beccd66af1_6af34333739c302d = external constant [0 x i8]
@olang_loc_4d945ec18b41639d_846c036da6ee75b9 = external constant [0 x i8]
@olang_loc_10c8bc13a6db10f0_81f1e7574e9afc2c = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_106f465f5c4a3bb_5092cc0760828757 = external constant [0 x i8]
@olang_loc_edc1999b8064b64f_198ad4786a3ba21b = external constant [0 x i8]
@olang_loc_49ee0ffb07b0661f_9b526ad68fdfe46b = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_d48e46a613c6a6b0_d47489a6fe7f2fac = external constant [0 x i8]
declare %"std/prelude/vec:vecState.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3avecState_3cU64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_cfe35b05666e821f_c7fed8e60a4cb0b3 = external constant [0 x i8]

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
