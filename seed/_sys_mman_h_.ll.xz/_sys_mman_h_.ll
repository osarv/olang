; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
@G_2e_3csys_2fmman_2eh_3e_2eMADV__COLD = constant <{ [4 x i8] }> <{ [4 x i8] c"\14\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__COLLAPSE = constant <{ [4 x i8] }> <{ [4 x i8] c"\19\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__DODUMP = constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__DOFORK = constant <{ [4 x i8] }> <{ [4 x i8] c"\0B\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTDUMP = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTFORK = constant <{ [4 x i8] }> <{ [4 x i8] c"\0A\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTNEED = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTNEED__LOCKED = constant <{ [4 x i8] }> <{ [4 x i8] c"\18\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__FREE = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__HUGEPAGE = constant <{ [4 x i8] }> <{ [4 x i8] c"\0E\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__HWPOISON = constant <{ [4 x i8] }> <{ [4 x i8] c"\64\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__KEEPONFORK = constant <{ [4 x i8] }> <{ [4 x i8] c"\13\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__MERGEABLE = constant <{ [4 x i8] }> <{ [4 x i8] c"\0C\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__NOHUGEPAGE = constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__NORMAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__PAGEOUT = constant <{ [4 x i8] }> <{ [4 x i8] c"\15\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__POPULATE__READ = constant <{ [4 x i8] }> <{ [4 x i8] c"\16\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__POPULATE__WRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\17\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__RANDOM = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__REMOVE = constant <{ [4 x i8] }> <{ [4 x i8] c"\09\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__SEQUENTIAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__UNMERGEABLE = constant <{ [4 x i8] }> <{ [4 x i8] c"\0D\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__WILLNEED = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMADV__WIPEONFORK = constant <{ [4 x i8] }> <{ [4 x i8] c"\12\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__32BIT = constant <{ [4 x i8] }> <{ [4 x i8] c"\40\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__ABOVE4G = constant <{ [4 x i8] }> <{ [4 x i8] c"\80\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__ANON = constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__ANONYMOUS = constant <{ [4 x i8] }> <{ [4 x i8] c"\20\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__DENYWRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\08\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__EXECUTABLE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\10\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__FILE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__FIXED = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__FIXED__NOREPLACE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\10\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__GROWSDOWN = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\01\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__HUGETLB = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\04\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__HUGE__MASK = constant <{ [4 x i8] }> <{ [4 x i8] c"\3F\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__HUGE__SHIFT = constant <{ [4 x i8] }> <{ [4 x i8] c"\1A\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__LOCKED = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\20\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__NONBLOCK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\01\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__NORESERVE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\40\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__POPULATE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\80\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__PRIVATE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__SHARED = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__SHARED__VALIDATE = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__STACK = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\02\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__SYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\08\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMAP__TYPE = constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMCL__CURRENT = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMCL__FUTURE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMCL__ONFAULT = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMFD__ALLOW__SEALING = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMFD__CLOEXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMFD__EXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMFD__HUGETLB = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMFD__NOEXEC__SEAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMLOCK__ONFAULT = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMREMAP__DONTUNMAP = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMREMAP__FIXED = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMREMAP__MAYMOVE = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMS__ASYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMS__INVALIDATE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eMS__SYNC = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__ACCESS = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__WRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__DONTNEED = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__NORMAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__RANDOM = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__SEQUENTIAL = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__WILLNEED = constant <{ [4 x i8] }> <{ [4 x i8] c"\03\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePROT__EXEC = constant <{ [4 x i8] }> <{ [4 x i8] c"\04\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePROT__GROWSDOWN = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\01" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePROT__GROWSUP = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\02" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePROT__NONE = constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePROT__READ = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2ePROT__WRITE = constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2e_3csys_2fmman_2eh_3e_2eSHADOW__STACK__SET__TOKEN = constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__COLD_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 20, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__COLD, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__COLLAPSE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 25, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__COLLAPSE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__DODUMP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 17, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__DODUMP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__DOFORK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 11, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__DOFORK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__DONTDUMP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTDUMP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__DONTFORK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 10, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTFORK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__DONTNEED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTNEED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__DONTNEED__LOCKED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 24, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__DONTNEED__LOCKED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__FREE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__FREE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__HUGEPAGE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 14, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__HUGEPAGE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__HWPOISON_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 100, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__HWPOISON, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__KEEPONFORK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 19, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__KEEPONFORK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__MERGEABLE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 12, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__MERGEABLE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__NOHUGEPAGE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 15, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__NOHUGEPAGE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__NORMAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__NORMAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__PAGEOUT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 21, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__PAGEOUT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__POPULATE__READ_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 22, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__POPULATE__READ, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__POPULATE__WRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 23, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__POPULATE__WRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__RANDOM_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__RANDOM, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__REMOVE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 9, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__REMOVE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__SEQUENTIAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__SEQUENTIAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__UNMERGEABLE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 13, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__UNMERGEABLE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__WILLNEED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__WILLNEED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMADV__WIPEONFORK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 18, ptr @G_2e_3csys_2fmman_2eh_3e_2eMADV__WIPEONFORK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__32BIT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 64, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__32BIT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__ABOVE4G_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 128, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__ABOVE4G, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__ANONYMOUS_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__ANONYMOUS, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__ANON_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__ANON, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__DENYWRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2048, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__DENYWRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__EXECUTABLE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4096, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__EXECUTABLE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__FILE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__FILE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__FIXED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__FIXED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__FIXED__NOREPLACE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1048576, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__FIXED__NOREPLACE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__GROWSDOWN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 256, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__GROWSDOWN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__HUGETLB_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 262144, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__HUGETLB, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__HUGE__MASK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 63, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__HUGE__MASK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__HUGE__SHIFT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 26, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__HUGE__SHIFT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__LOCKED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8192, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__LOCKED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__NONBLOCK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 65536, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__NONBLOCK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__NORESERVE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16384, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__NORESERVE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__POPULATE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 32768, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__POPULATE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__PRIVATE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__PRIVATE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__SHARED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__SHARED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__SHARED__VALIDATE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__SHARED__VALIDATE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__STACK_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 131072, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__STACK, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__SYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 524288, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__SYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMAP__TYPE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 15, ptr @G_2e_3csys_2fmman_2eh_3e_2eMAP__TYPE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMCL__CURRENT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eMCL__CURRENT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMCL__FUTURE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2eMCL__FUTURE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMCL__ONFAULT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3csys_2fmman_2eh_3e_2eMCL__ONFAULT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMFD__ALLOW__SEALING_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2eMFD__ALLOW__SEALING, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMFD__CLOEXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eMFD__CLOEXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMFD__EXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16, ptr @G_2e_3csys_2fmman_2eh_3e_2eMFD__EXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMFD__HUGETLB_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3csys_2fmman_2eh_3e_2eMFD__HUGETLB, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMFD__NOEXEC__SEAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 8, ptr @G_2e_3csys_2fmman_2eh_3e_2eMFD__NOEXEC__SEAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMLOCK__ONFAULT_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eMLOCK__ONFAULT, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMREMAP__DONTUNMAP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3csys_2fmman_2eh_3e_2eMREMAP__DONTUNMAP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMREMAP__FIXED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2eMREMAP__FIXED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMREMAP__MAYMOVE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eMREMAP__MAYMOVE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMS__ASYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eMS__ASYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMS__INVALIDATE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2eMS__INVALIDATE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eMS__SYNC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3csys_2fmman_2eh_3e_2eMS__SYNC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__ACCESS_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__ACCESS, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__WRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__WRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__DONTNEED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__DONTNEED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__NORMAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__NORMAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__RANDOM_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__RANDOM, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__SEQUENTIAL_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__SEQUENTIAL, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__WILLNEED_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 3, ptr @G_2e_3csys_2fmman_2eh_3e_2ePOSIX__MADV__WILLNEED, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePROT__EXEC_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 4, ptr @G_2e_3csys_2fmman_2eh_3e_2ePROT__EXEC, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePROT__GROWSDOWN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 16777216, ptr @G_2e_3csys_2fmman_2eh_3e_2ePROT__GROWSDOWN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePROT__GROWSUP_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 33554432, ptr @G_2e_3csys_2fmman_2eh_3e_2ePROT__GROWSUP, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePROT__NONE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr @G_2e_3csys_2fmman_2eh_3e_2ePROT__NONE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePROT__READ_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2ePROT__READ, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2ePROT__WRITE_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 2, ptr @G_2e_3csys_2fmman_2eh_3e_2ePROT__WRITE, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @_3csys_2fmman_2eh_3e_2eSHADOW__STACK__SET__TOKEN_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr @G_2e_3csys_2fmman_2eh_3e_2eSHADOW__STACK__SET__TOKEN, !tbaa !23
  br label %ret
ret:
  ret void
}

define dso_local void @olang_2einit_2e_3csys_2fmman_2eh_3e() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @_3csys_2fmman_2eh_3e_2eMAP__32BIT_2einit()
  br label %bb1
bb1:
  call void @_3csys_2fmman_2eh_3e_2eMAP__ABOVE4G_2einit()
  br label %bb2
bb2:
  call void @_3csys_2fmman_2eh_3e_2eSHADOW__STACK__SET__TOKEN_2einit()
  br label %bb3
bb3:
  call void @_3csys_2fmman_2eh_3e_2eMAP__GROWSDOWN_2einit()
  br label %bb4
bb4:
  call void @_3csys_2fmman_2eh_3e_2eMAP__DENYWRITE_2einit()
  br label %bb5
bb5:
  call void @_3csys_2fmman_2eh_3e_2eMAP__EXECUTABLE_2einit()
  br label %bb6
bb6:
  call void @_3csys_2fmman_2eh_3e_2eMAP__LOCKED_2einit()
  br label %bb7
bb7:
  call void @_3csys_2fmman_2eh_3e_2eMAP__NORESERVE_2einit()
  br label %bb8
bb8:
  call void @_3csys_2fmman_2eh_3e_2eMAP__POPULATE_2einit()
  br label %bb9
bb9:
  call void @_3csys_2fmman_2eh_3e_2eMAP__NONBLOCK_2einit()
  br label %bb10
bb10:
  call void @_3csys_2fmman_2eh_3e_2eMAP__STACK_2einit()
  br label %bb11
bb11:
  call void @_3csys_2fmman_2eh_3e_2eMAP__HUGETLB_2einit()
  br label %bb12
bb12:
  call void @_3csys_2fmman_2eh_3e_2eMAP__SYNC_2einit()
  br label %bb13
bb13:
  call void @_3csys_2fmman_2eh_3e_2eMAP__FIXED__NOREPLACE_2einit()
  br label %bb14
bb14:
  call void @_3csys_2fmman_2eh_3e_2ePROT__READ_2einit()
  br label %bb15
bb15:
  call void @_3csys_2fmman_2eh_3e_2ePROT__WRITE_2einit()
  br label %bb16
bb16:
  call void @_3csys_2fmman_2eh_3e_2ePROT__EXEC_2einit()
  br label %bb17
bb17:
  call void @_3csys_2fmman_2eh_3e_2ePROT__NONE_2einit()
  br label %bb18
bb18:
  call void @_3csys_2fmman_2eh_3e_2ePROT__GROWSDOWN_2einit()
  br label %bb19
bb19:
  call void @_3csys_2fmman_2eh_3e_2ePROT__GROWSUP_2einit()
  br label %bb20
bb20:
  call void @_3csys_2fmman_2eh_3e_2eMAP__SHARED_2einit()
  br label %bb21
bb21:
  call void @_3csys_2fmman_2eh_3e_2eMAP__PRIVATE_2einit()
  br label %bb22
bb22:
  call void @_3csys_2fmman_2eh_3e_2eMAP__SHARED__VALIDATE_2einit()
  br label %bb23
bb23:
  call void @_3csys_2fmman_2eh_3e_2eMAP__TYPE_2einit()
  br label %bb24
bb24:
  call void @_3csys_2fmman_2eh_3e_2eMAP__FIXED_2einit()
  br label %bb25
bb25:
  call void @_3csys_2fmman_2eh_3e_2eMAP__FILE_2einit()
  br label %bb26
bb26:
  call void @_3csys_2fmman_2eh_3e_2eMAP__ANONYMOUS_2einit()
  br label %bb27
bb27:
  call void @_3csys_2fmman_2eh_3e_2eMAP__ANON_2einit()
  br label %bb28
bb28:
  call void @_3csys_2fmman_2eh_3e_2eMAP__HUGE__SHIFT_2einit()
  br label %bb29
bb29:
  call void @_3csys_2fmman_2eh_3e_2eMAP__HUGE__MASK_2einit()
  br label %bb30
bb30:
  call void @_3csys_2fmman_2eh_3e_2eMS__ASYNC_2einit()
  br label %bb31
bb31:
  call void @_3csys_2fmman_2eh_3e_2eMS__SYNC_2einit()
  br label %bb32
bb32:
  call void @_3csys_2fmman_2eh_3e_2eMS__INVALIDATE_2einit()
  br label %bb33
bb33:
  call void @_3csys_2fmman_2eh_3e_2eMADV__NORMAL_2einit()
  br label %bb34
bb34:
  call void @_3csys_2fmman_2eh_3e_2eMADV__RANDOM_2einit()
  br label %bb35
bb35:
  call void @_3csys_2fmman_2eh_3e_2eMADV__SEQUENTIAL_2einit()
  br label %bb36
bb36:
  call void @_3csys_2fmman_2eh_3e_2eMADV__WILLNEED_2einit()
  br label %bb37
bb37:
  call void @_3csys_2fmman_2eh_3e_2eMADV__DONTNEED_2einit()
  br label %bb38
bb38:
  call void @_3csys_2fmman_2eh_3e_2eMADV__FREE_2einit()
  br label %bb39
bb39:
  call void @_3csys_2fmman_2eh_3e_2eMADV__REMOVE_2einit()
  br label %bb40
bb40:
  call void @_3csys_2fmman_2eh_3e_2eMADV__DONTFORK_2einit()
  br label %bb41
bb41:
  call void @_3csys_2fmman_2eh_3e_2eMADV__DOFORK_2einit()
  br label %bb42
bb42:
  call void @_3csys_2fmman_2eh_3e_2eMADV__MERGEABLE_2einit()
  br label %bb43
bb43:
  call void @_3csys_2fmman_2eh_3e_2eMADV__UNMERGEABLE_2einit()
  br label %bb44
bb44:
  call void @_3csys_2fmman_2eh_3e_2eMADV__HUGEPAGE_2einit()
  br label %bb45
bb45:
  call void @_3csys_2fmman_2eh_3e_2eMADV__NOHUGEPAGE_2einit()
  br label %bb46
bb46:
  call void @_3csys_2fmman_2eh_3e_2eMADV__DONTDUMP_2einit()
  br label %bb47
bb47:
  call void @_3csys_2fmman_2eh_3e_2eMADV__DODUMP_2einit()
  br label %bb48
bb48:
  call void @_3csys_2fmman_2eh_3e_2eMADV__WIPEONFORK_2einit()
  br label %bb49
bb49:
  call void @_3csys_2fmman_2eh_3e_2eMADV__KEEPONFORK_2einit()
  br label %bb50
bb50:
  call void @_3csys_2fmman_2eh_3e_2eMADV__COLD_2einit()
  br label %bb51
bb51:
  call void @_3csys_2fmman_2eh_3e_2eMADV__PAGEOUT_2einit()
  br label %bb52
bb52:
  call void @_3csys_2fmman_2eh_3e_2eMADV__POPULATE__READ_2einit()
  br label %bb53
bb53:
  call void @_3csys_2fmman_2eh_3e_2eMADV__POPULATE__WRITE_2einit()
  br label %bb54
bb54:
  call void @_3csys_2fmman_2eh_3e_2eMADV__DONTNEED__LOCKED_2einit()
  br label %bb55
bb55:
  call void @_3csys_2fmman_2eh_3e_2eMADV__COLLAPSE_2einit()
  br label %bb56
bb56:
  call void @_3csys_2fmman_2eh_3e_2eMADV__HWPOISON_2einit()
  br label %bb57
bb57:
  call void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__NORMAL_2einit()
  br label %bb58
bb58:
  call void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__RANDOM_2einit()
  br label %bb59
bb59:
  call void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__SEQUENTIAL_2einit()
  br label %bb60
bb60:
  call void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__WILLNEED_2einit()
  br label %bb61
bb61:
  call void @_3csys_2fmman_2eh_3e_2ePOSIX__MADV__DONTNEED_2einit()
  br label %bb62
bb62:
  call void @_3csys_2fmman_2eh_3e_2eMCL__CURRENT_2einit()
  br label %bb63
bb63:
  call void @_3csys_2fmman_2eh_3e_2eMCL__FUTURE_2einit()
  br label %bb64
bb64:
  call void @_3csys_2fmman_2eh_3e_2eMCL__ONFAULT_2einit()
  br label %bb65
bb65:
  call void @_3csys_2fmman_2eh_3e_2eMREMAP__MAYMOVE_2einit()
  br label %bb66
bb66:
  call void @_3csys_2fmman_2eh_3e_2eMREMAP__FIXED_2einit()
  br label %bb67
bb67:
  call void @_3csys_2fmman_2eh_3e_2eMREMAP__DONTUNMAP_2einit()
  br label %bb68
bb68:
  call void @_3csys_2fmman_2eh_3e_2eMFD__CLOEXEC_2einit()
  br label %bb69
bb69:
  call void @_3csys_2fmman_2eh_3e_2eMFD__ALLOW__SEALING_2einit()
  br label %bb70
bb70:
  call void @_3csys_2fmman_2eh_3e_2eMFD__HUGETLB_2einit()
  br label %bb71
bb71:
  call void @_3csys_2fmman_2eh_3e_2eMFD__NOEXEC__SEAL_2einit()
  br label %bb72
bb72:
  call void @_3csys_2fmman_2eh_3e_2eMFD__EXEC_2einit()
  br label %bb73
bb73:
  call void @_3csys_2fmman_2eh_3e_2eMLOCK__ONFAULT_2einit()
  br label %bb74
bb74:
  call void @_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__ACCESS_2einit()
  br label %bb75
bb75:
  call void @_3csys_2fmman_2eh_3e_2ePKEY__DISABLE__WRITE_2einit()
  br label %bb76
bb76:
  br label %ret
ret:
  ret void
}


!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
