; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/emit:Emitter" = type { ptr, ptr, ptr, ptr, i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/cabi:Regs" = type { i64, i64 }
%"compiler/cabi:Way" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/emit:fnEm" = type { ptr, ptr, { i64, [2 x i64] }, %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", %"std/prelude/text:StringBuilder", i64, i64, i64, i32, i1, i1, i1, i1, i1, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/text:StringBuilder", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, { i64, ptr }, i1 }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range", i64, i64, %"compiler/mir:Range" }
%"compiler/mir:TaskClause" = type { %"compiler/mir:Range", i1, { i64, [4 x i64] } }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/mir:BasicBlock" = type { %"compiler/mir:StmtList", { i64, [8 x i64] } }
%"compiler/mir:StmtList" = type { { i64, ptr }, i64 }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/mir:Case" = type { i64, i32 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/emit:cDecls" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i32
  %l109 = alloca i64
  %l111 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/lower:Lowerer", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t12, i64 %t13)
  store ptr %t16, ptr %l22
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l22, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l4
  %t23 = load { i64, [2 x i64] }, ptr %l4
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l5, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/emit:Emitter", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %s1, ptr %t35, i64 %t36)
  store { i64, ptr } %t39, ptr %l32
  br label %bb5
bb5:
  %t40 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 1
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t43 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t42)
  call void @olang_textcopy(ptr %t43, ptr %t41, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb60
bb6:
  %t47 = load { i64, [2 x i64] }, ptr %l4
  %t49 = extractvalue { i64, [2 x i64] } %t47, 0
  %t50 = icmp eq i64 %t49, 1
  br i1 %t50, label %bb7, label %bb8
bb7:
  %t52 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t53 = getelementptr { i32, i32 }, ptr %t52, i32 0, i32 0
  %t54 = load i32, ptr %t53
  store i32 %t54, ptr %l6, !tbaa !23
  %t56 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t57 = getelementptr { i32, i32 }, ptr %t56, i32 0, i32 1
  %t58 = load i32, ptr %t57
  store i32 %t58, ptr %l7, !tbaa !23
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t61 = load i32, ptr %l6, !tbaa !23
  %t63 = inttoptr i64 0 to ptr
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s3, ptr %t63, ptr %t60, i32 %t61)
  store { i64, ptr } %t66, ptr %l41
  br label %bb10
bb10:
  %t67 = load i32, ptr %l7, !tbaa !23
  %t69 = icmp eq i32 %t67, 0
  br i1 %t69, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l44, !tbaa !27
  br label %bb14
bb12:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t72 = load i32, ptr %l7, !tbaa !23
  %t74 = inttoptr i64 0 to ptr
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %s3, ptr %t74, ptr %t71, i32 %t72)
  store { i64, ptr } %t77, ptr %l48
  br label %bb13
bb13:
  %t78 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t80 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = add i64 %t79, %t82
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t78, i64 %t79)
  %t88 = getelementptr i8, ptr %t87, i64 %t79
  call void @olang_textcopy(ptr %t88, ptr %t81, i64 %t82)
  %t89 = getelementptr i8, ptr %t88, i64 %t82
  call void @olang_textcopy(ptr %t89, ptr %t84, i64 %t85)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t87, 1
  store { i64, ptr } %t91, ptr %l44, !tbaa !27
  br label %bb14
bb14:
  %t94 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t99 = add i64 %t96, %t98
  %t100 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t95, i64 %t96)
  %t105 = getelementptr i8, ptr %t104, i64 %t96
  call void @olang_textcopy(ptr %t105, ptr %t97, i64 %t98)
  %t106 = getelementptr i8, ptr %t105, i64 %t98
  call void @olang_textcopy(ptr %t106, ptr %t101, i64 %t102)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t104, 1
  %t111 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s3, ptr %v1, { i64, ptr } %t108)
  store { i64, ptr } %t111, ptr %l53
  br label %bb15
bb15:
  %t112 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t112, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb60
bb16:
  %t113 = load { i64, [2 x i64] }, ptr %l4
  %t115 = extractvalue { i64, [2 x i64] } %t113, 0
  %t116 = icmp eq i64 %t115, 3
  br i1 %t116, label %bb17, label %bb18
bb17:
  %t118 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t119 = getelementptr { i32 }, ptr %t118, i32 0, i32 0
  %t120 = load i32, ptr %t119
  store i32 %t120, ptr %l8, !tbaa !23
  br label %bb19
bb18:
  br label %bb22
bb19:
  store %olang.scope zeroinitializer, ptr %s6
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t123 = load i32, ptr %l8, !tbaa !23
  %t125 = inttoptr i64 0 to ptr
  %t128 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s6, ptr %t125, ptr %t122, i32 %t123)
  store { i64, ptr } %t128, ptr %l60
  br label %bb20
bb20:
  %t129 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 1
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t132 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t130, i64 %t131)
  %t136 = getelementptr i8, ptr %t135, i64 %t131
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t141 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s6, ptr %v1, { i64, ptr } %t138)
  store { i64, ptr } %t141, ptr %l63
  br label %bb21
bb21:
  %t142 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t142, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb60
bb22:
  %t143 = load { i64, [2 x i64] }, ptr %l4
  %t145 = extractvalue { i64, [2 x i64] } %t143, 0
  %t146 = icmp eq i64 %t145, 4
  br i1 %t146, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t148 = load i64, ptr %l1, !tbaa !24
  %t149 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t152 = call i64 @__olang_fmt_i64(ptr null, i64 %t148)
  %t153 = add i64 %t150, %t152
  %t154 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t149, i64 %t150)
  %t155 = getelementptr i8, ptr %t154, i64 %t150
  %t156 = call i64 @__olang_fmt_i64(ptr %t155, i64 %t148)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t154, 1
  store { i64, ptr } %t158, ptr %l25, !tbaa !27
  br label %bb60
bb26:
  %t160 = load { i64, [2 x i64] }, ptr %l4
  %t162 = extractvalue { i64, [2 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 5
  br i1 %t163, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l1, !tbaa !24
  %t169 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %t165, i64 %t166)
  store { i64, ptr } %t169, ptr %l72
  br label %bb30
bb30:
  %t170 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t170, ptr %l25, !tbaa !27
  br label %bb60
bb31:
  %t171 = load { i64, [2 x i64] }, ptr %l4
  %t173 = extractvalue { i64, [2 x i64] } %t171, 0
  %t174 = icmp eq i64 %t173, 6
  br i1 %t174, label %bb32, label %bb33
bb32:
  %t176 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t177 = getelementptr { i64, i32 }, ptr %t176, i32 0, i32 0
  %t178 = load i64, ptr %t177
  store i64 %t178, ptr %l9, !tbaa !24
  %t180 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t181 = getelementptr { i64, i32 }, ptr %t180, i32 0, i32 1
  %t182 = load i32, ptr %t181
  store i32 %t182, ptr %l10, !tbaa !23
  br label %bb34
bb33:
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s11
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/emit:Emitter", ptr %t184, i32 0, i32 0
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Program", ptr %t187, i32 0, i32 0
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t192 = getelementptr %"compiler/load:Loader", ptr %t190, i32 0, i32 10
  %t193 = load i64, ptr %l9, !tbaa !24
  %t196 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t192, i64 %t193)
  store ptr %t196, ptr %l82
  br label %bb35
bb35:
  %t197 = load ptr, ptr %l82, !tbaa !29
  %t199 = getelementptr %"compiler/load:Module", ptr %t197, i32 0, i32 2
  %t200 = load { i64, ptr }, ptr %t199, !tbaa !27
  store { i64, ptr } %t200, ptr %l84, !tbaa !27
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load i32, ptr %l10, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s11, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l87
  br label %bb36
bb36:
  %t206 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t212 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t207, i64 %t208)
  %t220 = getelementptr i8, ptr %t219, i64 %t208
  call void @olang_textcopy(ptr %t220, ptr %t209, i64 %t210)
  %t221 = getelementptr i8, ptr %t220, i64 %t210
  call void @olang_textcopy(ptr %t221, ptr %t213, i64 %t214)
  %t222 = getelementptr i8, ptr %t221, i64 %t214
  call void @olang_textcopy(ptr %t222, ptr %t216, i64 %t217)
  %t223 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t219, 1
  %t227 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s11, ptr %v1, { i64, ptr } %t224)
  store { i64, ptr } %t227, ptr %l90
  br label %bb37
bb37:
  %t228 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t228, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb60
bb38:
  %t229 = load { i64, [2 x i64] }, ptr %l4
  %t231 = extractvalue { i64, [2 x i64] } %t229, 0
  %t232 = icmp eq i64 %t231, 2
  br i1 %t232, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  %t234 = load i64, ptr %l1, !tbaa !24
  %t235 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t238 = call i64 @__olang_fmt_i64(ptr null, i64 %t234)
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t235, i64 %t236)
  %t241 = getelementptr i8, ptr %t240, i64 %t236
  %t242 = call i64 @__olang_fmt_i64(ptr %t241, i64 %t234)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t240, 1
  store { i64, ptr } %t244, ptr %l25, !tbaa !27
  br label %bb60
bb42:
  %t246 = load { i64, [2 x i64] }, ptr %l4
  %t248 = extractvalue { i64, [2 x i64] } %t246, 0
  %t249 = icmp eq i64 %t248, 7
  br i1 %t249, label %bb43, label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t251 = load i64, ptr %l1, !tbaa !24
  %t252 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t253 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t255 = call i64 @__olang_fmt_i64(ptr null, i64 %t251)
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = getelementptr i8, ptr %t257, i64 %t253
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t251)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  store { i64, ptr } %t261, ptr %l25, !tbaa !27
  br label %bb60
bb46:
  %t263 = load { i64, [2 x i64] }, ptr %l4
  %t265 = extractvalue { i64, [2 x i64] } %t263, 0
  %t266 = icmp eq i64 %t265, 8
  br i1 %t266, label %bb47, label %bb48
bb47:
  %t268 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t269 = getelementptr { i32, i32, i64 }, ptr %t268, i32 0, i32 0
  %t270 = load i32, ptr %t269
  store i32 %t270, ptr %l11, !tbaa !23
  %t272 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t273 = getelementptr { i32, i32, i64 }, ptr %t272, i32 0, i32 1
  %t274 = load i32, ptr %t273, !range !{i32 0, i32 1}
  store i32 %t274, ptr %l12
  %t276 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t277 = getelementptr { i32, i32, i64 }, ptr %t276, i32 0, i32 2
  %t278 = load i64, ptr %t277
  store i64 %t278, ptr %l13, !tbaa !24
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s17
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l11, !tbaa !23
  %t283 = sext i32 %t281 to i64
  %t286 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s17, ptr %t280, i64 %t283)
  store { i64, ptr } %t286, ptr %l107
  br label %bb50
bb50:
  %t287 = load i32, ptr %l12, !range !{i32 0, i32 1}
  store i32 %t287, ptr %l108
  %t288 = load i64, ptr %l13, !tbaa !24
  store i64 %t288, ptr %l109, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t289 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 1
  %t291 = extractvalue { i64, ptr } %t289, 0
  call void @__olang_sb_put(ptr %s18, ptr %t290, i64 %t291)
  %t292 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t292, i64 %t293)
  call void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %s18, ptr %l108, i64 0)
  br label %bb51
bb51:
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t295, i64 %t296)
  %t297 = load i64, ptr %l109, !tbaa !24
  %t298 = call ptr @__olang_sb_room(ptr %s18, i64 24)
  %t299 = call i64 @__olang_fmt_i64(ptr %t298, i64 %t297)
  call void @__olang_sb_add(ptr %s18, i64 %t299)
  %t300 = load ptr, ptr %s18
  %t301 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t302 = load i64, ptr %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t300, i64 %t302)
  %t304 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l111, !tbaa !27
  %t306 = getelementptr %olang.builder, ptr %s18, i32 0, i32 3
  %t307 = load ptr, ptr %t306
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %sbgrew.309, label %sbdone.310
sbgrew.309:
  call void @__olang_sb_done(ptr %s18)
  br label %sbdone.310
sbdone.310:
  %t311 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t313 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s17, ptr %v1, { i64, ptr } %t311)
  store { i64, ptr } %t313, ptr %l113
  br label %bb52
bb52:
  %t314 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t314, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s17)
  br label %bb60
bb53:
  %t315 = load { i64, [2 x i64] }, ptr %l4
  %t317 = extractvalue { i64, [2 x i64] } %t315, 0
  %t318 = icmp eq i64 %t317, 9
  br i1 %t318, label %bb54, label %bb55
bb54:
  %t320 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t321 = getelementptr { i64, i64 }, ptr %t320, i32 0, i32 0
  %t322 = load i64, ptr %t321
  store i64 %t322, ptr %l14, !tbaa !24
  %t324 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t325 = getelementptr { i64, i64 }, ptr %t324, i32 0, i32 1
  %t326 = load i64, ptr %t325
  store i64 %t326, ptr %l15, !tbaa !24
  br label %bb56
bb55:
  br label %bb59
bb56:
  store %olang.scope zeroinitializer, ptr %s19
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i64, ptr %l14, !tbaa !24
  %t332 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %s19, ptr %t328, i64 %t329)
  store { i64, ptr } %t332, ptr %l120
  br label %bb57
bb57:
  %t333 = load i64, ptr %l15, !tbaa !24
  %t334 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t336 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = add i64 %t335, %t338
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t342 = add i64 %t339, %t341
  %t344 = call i64 @__olang_fmt_i64(ptr null, i64 %t333)
  %t345 = add i64 %t342, %t344
  %t346 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t345)
  call void @olang_textcopy(ptr %t346, ptr %t334, i64 %t335)
  %t347 = getelementptr i8, ptr %t346, i64 %t335
  call void @olang_textcopy(ptr %t347, ptr %t337, i64 %t338)
  %t348 = getelementptr i8, ptr %t347, i64 %t338
  call void @olang_textcopy(ptr %t348, ptr %t340, i64 %t341)
  %t349 = getelementptr i8, ptr %t348, i64 %t341
  %t350 = call i64 @__olang_fmt_i64(ptr %t349, i64 %t333)
  %t351 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t346, 1
  %t355 = call { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %s19, ptr %v1, { i64, ptr } %t352)
  store { i64, ptr } %t355, ptr %l124
  br label %bb58
bb58:
  %t356 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t356, ptr %l25, !tbaa !27
  call void @__olang_scope_close(ptr %s19)
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_de1fe604fb5e87cf_ff4728625cff78d3)
  unreachable
bb60:
  %t357 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t357, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i1
  %l6 = alloca %"compiler/cabi:Regs"
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca %"compiler/cabi:Regs"
  %l18 = alloca i32
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca %"compiler/cabi:Way"
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l48 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t6, ptr %l14
  br label %bb1
bb1:
  %t7 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t7, ptr %l4
  store i1 true, ptr %l5, !tbaa !21
  %t8 = call %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %s0, i64 6, i64 8)
  store %"compiler/cabi:Regs" %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load %"compiler/cabi:Regs", ptr %l15
  store %"compiler/cabi:Regs" %t9, ptr %l6
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l18
  br label %bb3
bb3:
  %t15 = load i32, ptr %l18, !tbaa !23
  store i32 %t15, ptr %l7, !tbaa !23
  %t16 = load i32, ptr %l7, !tbaa !23
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t20 = icmp ne i32 %t16, %t17
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i32, ptr %l7, !tbaa !23
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t26 = icmp ne i32 %t22, %t23
  store i1 %t26, ptr %l22, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:Emitter", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t33 = load i32, ptr %l7, !tbaa !23
  %t36 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l30
  br label %bb9
bb8:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l30, !tbaa !21
  store i1 %t37, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l26, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/emit:Emitter", ptr %t39, i32 0, i32 3
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l33, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %v0, ptr %s0, ptr %t43)
  store { i64, ptr } %t45, ptr %l35
  br label %bb13
bb12:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb15
bb13:
  %t46 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t47 = load i32, ptr %l7, !tbaa !23
  %t49 = inttoptr i64 0 to ptr
  %t50 = load ptr, ptr %l33, !tbaa !29
  %t53 = call %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %s0, ptr %s0, ptr %t49, ptr %t50, { i64, ptr } %t46, i32 %t47)
  store %"compiler/cabi:Way" %t53, ptr %l39
  br label %bb14
bb14:
  %t54 = getelementptr %"compiler/cabi:Way", ptr %l39, i32 0, i32 0
  %t55 = load i32, ptr %t54, !range !{i32 0, i32 5}
  %t57 = trunc i64 4 to i32
  %t58 = icmp eq i32 %t55, %t57
  store i1 %t58, ptr %l31, !tbaa !21
  br label %bb15
bb15:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %l4, ptr %l42, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l7, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s1, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l45
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t67 = load i32, ptr %l7, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t66, i32 %t67)
  store i64 %t70, ptr %l48
  br label %bb19
bb19:
  %t71 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t73 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = load i64, ptr %l48, !tbaa !24
  %t81 = call i64 @__olang_fmt_i64(ptr null, i64 %t80)
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t71, i64 %t72)
  %t84 = getelementptr i8, ptr %t83, i64 %t72
  call void @olang_textcopy(ptr %t84, ptr %t74, i64 %t75)
  %t85 = getelementptr i8, ptr %t84, i64 %t75
  call void @olang_textcopy(ptr %t85, ptr %t77, i64 %t78)
  %t86 = getelementptr i8, ptr %t85, i64 %t78
  %t87 = call i64 @__olang_fmt_i64(ptr %t86, i64 %t80)
  %t88 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t83, 1
  %t91 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %t91, { i64, ptr } %t89)
  br label %bb20
bb20:
  store i1 false, ptr %l5, !tbaa !21
  %t93 = getelementptr %"compiler/cabi:Regs", ptr %l6, i32 0, i32 0
  %t94 = load i64, ptr %t93, !tbaa !24
  %t97 = sub i64 %t94, 1
  %t99 = getelementptr %"compiler/cabi:Regs", ptr %l6, i32 0, i32 0
  store i64 %t97, ptr %t99, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb21:
  %t100 = load ptr, ptr %l3, !tbaa !29
  store ptr %t100, ptr %l54, !tbaa !29
  %t101 = load ptr, ptr %l3, !tbaa !29
  %t102 = load i32, ptr %l1, !tbaa !23
  %t105 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t105, ptr %l57
  br label %bb22
bb22:
  %t106 = load ptr, ptr %l54, !tbaa !29
  %t107 = load i32, ptr %l57, !tbaa !23
  %t108 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t106, i32 %t107)
  store { i64, ptr } %t108, ptr %l58
  br label %bb23
bb23:
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t109, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t110, 0
  store i64 %t112, ptr %l10, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t114 = load i64, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb26:
  br label %bb27
bb27:
  %t122 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t122, ptr %l65, !tbaa !27
  %t123 = load i64, ptr %l9, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t123
  %t128 = load i32, ptr %t127, !tbaa !33
  store i32 %t128, ptr %l11, !tbaa !23
  %t130 = load i1, ptr %l5, !tbaa !21
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %l4, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  store i1 false, ptr %l5, !tbaa !21
  store ptr %l4, ptr %l71, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l11, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %s0, ptr %s4, ptr %t135, i32 %t136, ptr %l6, i1 %a2)
  store { i64, ptr } %t142, ptr %l76
  br label %bb32
bb32:
  %t143 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t144 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t144, { i64, ptr } %t143)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  %t146 = load i64, ptr %l9, !tbaa !24
  %t149 = add i64 %t146, 1
  store i64 %t149, ptr %l9, !tbaa !24
  br label %bb24
bb35:
  %t152 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l4)
  store { i64, ptr } %t152, ptr %l82
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t153, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecarriesText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l26 = alloca i64
  %l29 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca i32
  %l58 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i64
  %l78 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l92 = alloca i64
  %l96 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a3)
  store { i64, ptr } %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l9, !tbaa !24
  %t19 = load i64, ptr %l8, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l10, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l9, !tbaa !24
  %t29 = load i64, ptr %l8, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l10, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l10, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l29, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l29, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l26, !tbaa !24
  store i64 %t45, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load i64, ptr %l12, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l12, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l13, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/emit:Emitter", ptr %t64, i32 0, i32 0
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t69, ptr %l50, !tbaa !27
  %t70 = load i64, ptr %l13, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t68, i32 %t75)
  store i32 %t78, ptr %l53
  br label %bb12
bb12:
  %t79 = load ptr, ptr %l48, !tbaa !29
  %t80 = load i32, ptr %l53, !tbaa !23
  %t81 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t81, ptr %l54
  br label %bb13
bb13:
  %t82 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = load i32, ptr %l54, !tbaa !23
  %t85 = icmp eq i32 %t83, %t82
  br i1 %t85, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb15:
  br label %bb16
bb16:
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t89 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t87, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t89, ptr %l58
  br label %bb17
bb17:
  %t90 = load i1, ptr %l58, !tbaa !21
  br i1 %t90, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t97 = extractvalue { i64, ptr } %t92, 1
  %t98 = extractvalue { i64, ptr } %t92, 0
  %t99 = add i64 %t95, %t98
  %t100 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t101 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t102 = add i64 %t99, %t101
  %t104 = extractvalue { i64, ptr } %a2, 1
  %t105 = extractvalue { i64, ptr } %a2, 0
  %t106 = add i64 %t102, %t105
  %t107 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t108 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t109 = add i64 %t106, %t108
  %t110 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t94, i64 %t95)
  %t111 = getelementptr i8, ptr %t110, i64 %t95
  call void @olang_textcopy(ptr %t111, ptr %t97, i64 %t98)
  %t112 = getelementptr i8, ptr %t111, i64 %t98
  call void @olang_textcopy(ptr %t112, ptr %t100, i64 %t101)
  %t113 = getelementptr i8, ptr %t112, i64 %t101
  call void @olang_textcopy(ptr %t113, ptr %t104, i64 %t105)
  %t114 = getelementptr i8, ptr %t113, i64 %t105
  call void @olang_textcopy(ptr %t114, ptr %t107, i64 %t108)
  %t115 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t110, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t91, { i64, ptr } %t116)
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t121 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t122 = load i64, ptr %l13, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = add i64 %t124, 1
  %t127 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t130 = extractvalue { i64, ptr } %t121, 1
  %t131 = extractvalue { i64, ptr } %t121, 0
  %t132 = add i64 %t128, %t131
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t137 = call i64 @__olang_fmt_i64(ptr null, i64 %t122)
  %t138 = add i64 %t135, %t137
  %t139 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t143 = extractvalue { i64, ptr } %t123, 1
  %t144 = extractvalue { i64, ptr } %t123, 0
  %t145 = add i64 %t141, %t144
  %t146 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t150 = call i64 @__olang_fmt_i64(ptr null, i64 %t126)
  %t151 = add i64 %t148, %t150
  %t152 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t155 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t154)
  call void @olang_textcopy(ptr %t155, ptr %t127, i64 %t128)
  %t156 = getelementptr i8, ptr %t155, i64 %t128
  call void @olang_textcopy(ptr %t156, ptr %t130, i64 %t131)
  %t157 = getelementptr i8, ptr %t156, i64 %t131
  call void @olang_textcopy(ptr %t157, ptr %t133, i64 %t134)
  %t158 = getelementptr i8, ptr %t157, i64 %t134
  %t159 = call i64 @__olang_fmt_i64(ptr %t158, i64 %t122)
  %t160 = getelementptr i8, ptr %t158, i64 %t137
  call void @olang_textcopy(ptr %t160, ptr %t139, i64 %t140)
  %t161 = getelementptr i8, ptr %t160, i64 %t140
  call void @olang_textcopy(ptr %t161, ptr %t143, i64 %t144)
  %t162 = getelementptr i8, ptr %t161, i64 %t144
  call void @olang_textcopy(ptr %t162, ptr %t146, i64 %t147)
  %t163 = getelementptr i8, ptr %t162, i64 %t147
  %t164 = call i64 @__olang_fmt_i64(ptr %t163, i64 %t126)
  %t165 = getelementptr i8, ptr %t163, i64 %t150
  call void @olang_textcopy(ptr %t165, ptr %t152, i64 %t153)
  %t166 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t155, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t120, { i64, ptr } %t167)
  br label %bb22
bb22:
  %t171 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t173 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s2, { i64, ptr } %t171, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t173, ptr %l73
  br label %bb23
bb23:
  %t174 = load i1, ptr %l73, !tbaa !21
  br i1 %t174, label %bb24, label %bb25
bb24:
  %t175 = call ptr @__olang_scope_hold(ptr %v4)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l74, !tbaa !24
  %t177 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ecarriesText_2elocal_2e7
  br i1 %t177, label %bb26, label %bb27
bb25:
  store %olang.scope zeroinitializer, ptr %s9
  %t179 = load ptr, ptr %l1, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t181 = load i64, ptr %l13, !tbaa !24
  %t182 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t184 = load i64, ptr %l13, !tbaa !24
  %t185 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t188 = extractvalue { i64, ptr } %t180, 1
  %t189 = extractvalue { i64, ptr } %t180, 0
  %t190 = add i64 %t186, %t189
  %t191 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t193 = add i64 %t190, %t192
  %t195 = call i64 @__olang_fmt_i64(ptr null, i64 %t181)
  %t196 = add i64 %t193, %t195
  %t197 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t201 = extractvalue { i64, ptr } %t182, 1
  %t202 = extractvalue { i64, ptr } %t182, 0
  %t203 = add i64 %t199, %t202
  %t204 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t206 = add i64 %t203, %t205
  %t208 = extractvalue { i64, ptr } %t183, 1
  %t209 = extractvalue { i64, ptr } %t183, 0
  %t210 = add i64 %t206, %t209
  %t211 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t212 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t213 = add i64 %t210, %t212
  %t215 = call i64 @__olang_fmt_i64(ptr null, i64 %t184)
  %t216 = add i64 %t213, %t215
  %t217 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t219 = add i64 %t216, %t218
  %t220 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t219)
  call void @olang_textcopy(ptr %t220, ptr %t185, i64 %t186)
  %t221 = getelementptr i8, ptr %t220, i64 %t186
  call void @olang_textcopy(ptr %t221, ptr %t188, i64 %t189)
  %t222 = getelementptr i8, ptr %t221, i64 %t189
  call void @olang_textcopy(ptr %t222, ptr %t191, i64 %t192)
  %t223 = getelementptr i8, ptr %t222, i64 %t192
  %t224 = call i64 @__olang_fmt_i64(ptr %t223, i64 %t181)
  %t225 = getelementptr i8, ptr %t223, i64 %t195
  call void @olang_textcopy(ptr %t225, ptr %t197, i64 %t198)
  %t226 = getelementptr i8, ptr %t225, i64 %t198
  call void @olang_textcopy(ptr %t226, ptr %t201, i64 %t202)
  %t227 = getelementptr i8, ptr %t226, i64 %t202
  call void @olang_textcopy(ptr %t227, ptr %t204, i64 %t205)
  %t228 = getelementptr i8, ptr %t227, i64 %t205
  call void @olang_textcopy(ptr %t228, ptr %t208, i64 %t209)
  %t229 = getelementptr i8, ptr %t228, i64 %t209
  call void @olang_textcopy(ptr %t229, ptr %t211, i64 %t212)
  %t230 = getelementptr i8, ptr %t229, i64 %t212
  %t231 = call i64 @__olang_fmt_i64(ptr %t230, i64 %t184)
  %t232 = getelementptr i8, ptr %t230, i64 %t215
  call void @olang_textcopy(ptr %t232, ptr %t217, i64 %t218)
  %t233 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t220, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s9, ptr %t179, { i64, ptr } %t234)
  br label %bb34
bb26:
  %t238 = call ptr @__olang_region_make(ptr %v4)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l74, !tbaa !24
  br label %bb27
bb27:
  %t240 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t241 = load i64, ptr %l13, !tbaa !24
  %t242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t245 = extractvalue { i64, ptr } %t240, 1
  %t246 = extractvalue { i64, ptr } %t240, 0
  %t247 = add i64 %t243, %t246
  %t248 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t252 = call i64 @__olang_fmt_i64(ptr null, i64 %t241)
  %t253 = add i64 %t250, %t252
  %t254 = load i64, ptr %l74
  %t255 = inttoptr i64 %t254 to ptr
  %t256 = call ptr @__olang_held_alloc(ptr %t255, i64 %t253)
  call void @olang_textcopy(ptr %t256, ptr %t242, i64 %t243)
  %t257 = getelementptr i8, ptr %t256, i64 %t243
  call void @olang_textcopy(ptr %t257, ptr %t245, i64 %t246)
  %t258 = getelementptr i8, ptr %t257, i64 %t246
  call void @olang_textcopy(ptr %t258, ptr %t248, i64 %t249)
  %t259 = getelementptr i8, ptr %t258, i64 %t249
  %t260 = call i64 @__olang_fmt_i64(ptr %t259, i64 %t241)
  %t261 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t256, 1
  store { i64, ptr } %t262, ptr %l78, !tbaa !27
  %t263 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ecarriesText_2elocal_2e7
  br i1 %t263, label %bb28, label %bb29
bb28:
  %t265 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 0
  %t268 = icmp eq i64 %t266, 0
  br i1 %t268, label %bb30, label %bb31
bb29:
  %t270 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t270, ptr %l82, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t271, ptr %l7, !tbaa !27
  %t272 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ecarriesText_2elocal_2e7
  br i1 %t272, label %bb32, label %bb33
bb30:
  store { i64, ptr } zeroinitializer, ptr %l78, !tbaa !27
  br label %bb31
bb31:
  %t274 = load i64, ptr %l74
  %t275 = inttoptr i64 %t274 to ptr
  %t276 = load { i64, ptr }, ptr %l78
  %t277 = extractvalue { i64, ptr } %t276, 1
  %t278 = call ptr @__olang_region_or(ptr %t277, ptr null)
  %t279 = icmp ne ptr %t278, null
  %t280 = select i1 %t279, ptr %t278, ptr null
  call void @__olang_region_settle_in(ptr %t275, ptr %t280)
  br label %bb29
bb32:
  %t281 = load { i64, ptr }, ptr %l82
  %t282 = extractvalue { i64, ptr } %t281, 1
  call void @__olang_region_release(ptr %t282)
  store { i64, ptr } zeroinitializer, ptr %l82
  br label %bb33
bb33:
  br label %bb43
bb34:
  %t283 = call ptr @__olang_scope_hold(ptr %v4)
  %t284 = ptrtoint ptr %t283 to i64
  store i64 %t284, ptr %l92, !tbaa !24
  %t285 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ecarriesText_2elocal_2e7
  br i1 %t285, label %bb35, label %bb36
bb35:
  %t287 = call ptr @__olang_region_make(ptr %v4)
  %t288 = ptrtoint ptr %t287 to i64
  store i64 %t288, ptr %l92, !tbaa !24
  br label %bb36
bb36:
  %t289 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t290 = load i64, ptr %l13, !tbaa !24
  %t291 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t294 = extractvalue { i64, ptr } %t289, 1
  %t295 = extractvalue { i64, ptr } %t289, 0
  %t296 = add i64 %t292, %t295
  %t297 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t299 = add i64 %t296, %t298
  %t301 = call i64 @__olang_fmt_i64(ptr null, i64 %t290)
  %t302 = add i64 %t299, %t301
  %t303 = load i64, ptr %l92
  %t304 = inttoptr i64 %t303 to ptr
  %t305 = call ptr @__olang_held_alloc(ptr %t304, i64 %t302)
  call void @olang_textcopy(ptr %t305, ptr %t291, i64 %t292)
  %t306 = getelementptr i8, ptr %t305, i64 %t292
  call void @olang_textcopy(ptr %t306, ptr %t294, i64 %t295)
  %t307 = getelementptr i8, ptr %t306, i64 %t295
  call void @olang_textcopy(ptr %t307, ptr %t297, i64 %t298)
  %t308 = getelementptr i8, ptr %t307, i64 %t298
  %t309 = call i64 @__olang_fmt_i64(ptr %t308, i64 %t290)
  %t310 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t305, 1
  store { i64, ptr } %t311, ptr %l96, !tbaa !27
  %t312 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ecarriesText_2elocal_2e7
  br i1 %t312, label %bb37, label %bb38
bb37:
  %t314 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t315 = extractvalue { i64, ptr } %t314, 0
  %t317 = icmp eq i64 %t315, 0
  br i1 %t317, label %bb39, label %bb40
bb38:
  %t319 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t319, ptr %l100, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l96, !tbaa !27
  store { i64, ptr } %t320, ptr %l7, !tbaa !27
  %t321 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ecarriesText_2elocal_2e7
  br i1 %t321, label %bb41, label %bb42
bb39:
  store { i64, ptr } zeroinitializer, ptr %l96, !tbaa !27
  br label %bb40
bb40:
  %t323 = load i64, ptr %l92
  %t324 = inttoptr i64 %t323 to ptr
  %t325 = load { i64, ptr }, ptr %l96
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = call ptr @__olang_region_or(ptr %t326, ptr null)
  %t328 = icmp ne ptr %t327, null
  %t329 = select i1 %t328, ptr %t327, ptr null
  call void @__olang_region_settle_in(ptr %t324, ptr %t329)
  br label %bb38
bb41:
  %t330 = load { i64, ptr }, ptr %l100
  %t331 = extractvalue { i64, ptr } %t330, 1
  call void @__olang_region_release(ptr %t331)
  store { i64, ptr } zeroinitializer, ptr %l100
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb44
bb44:
  %t332 = load i64, ptr %l12, !tbaa !24
  %t335 = add i64 %t332, 1
  store i64 %t335, ptr %l12, !tbaa !24
  br label %bb8
bb45:
  %t337 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t337, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgErrVal(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i32
  %l39 = alloca i64
  %l45 = alloca %"std/prelude/text:StringBuilder"
  %l47 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca i64
  %l86 = alloca { i64, ptr }
  %l89 = alloca i32
  %l91 = alloca ptr
  %l94 = alloca i32
  %l95 = alloca { i64, ptr }
  %l101 = alloca i64
  %l104 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca i64
  %l128 = alloca i64
  %l133 = alloca i64
  %l136 = alloca { i64, ptr }
  %l138 = alloca ptr
  %l141 = alloca i32
  %l143 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l146 = alloca i64
  %l148 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca ptr
  %l169 = alloca i64
  %l171 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l175 = alloca i64
  %l178 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca ptr
  %l183 = alloca i32
  %l184 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 84
  %t4 = load i32, ptr %l1, !tbaa !23
  %t6 = sext i32 %t4 to i64
  %t9 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i1 %t9, ptr %l28
  br label %bb1
bb1:
  %t10 = load i1, ptr %l28, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/emit:Emitter", ptr %t11, i32 0, i32 84
  %t14 = load i32, ptr %l1, !tbaa !23
  %t16 = sext i32 %t14 to i64
  %t19 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t13, i64 %t16)
  %t20 = extractvalue { i32, i64 } %t19, 1
  %t21 = extractvalue { i32, i64 } %t19, 0
  store i32 %t21, ptr %l35
  %t22 = icmp ne i32 %t21, 0
  br i1 %t22, label %bb5, label %ok.23, !prof !99
ok.23:
  store i64 %t20, ptr %l34
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t24 = load i64, ptr %l34, !tbaa !24
  store i64 %t24, ptr %l29, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i64, ptr %l29, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/emit:Emitter", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  store ptr %t29, ptr %l2, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l39
  br label %bb9
bb9:
  %t34 = load i64, ptr %l39, !tbaa !24
  store i64 %t34, ptr %l3, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/emit:Emitter", ptr %t35, i32 0, i32 84
  %t38 = load i32, ptr %l1, !tbaa !23
  %t40 = sext i32 %t38 to i64
  %t41 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t37, i64 %t40, i64 %t41)
  br label %bb10
bb10:
  %t45 = call %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t45, ptr %l45
  br label %bb11
bb11:
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l45
  store %"std/prelude/text:StringBuilder" %t46, ptr %l4
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t47)
  store i64 %t49, ptr %l47
  br label %bb12
bb12:
  %t50 = load i64, ptr %l47, !tbaa !24
  store i64 %t50, ptr %l5, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t51, i64 %t52, { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb13
bb13:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t59 = call i64 @__olang_fmt_i64(ptr null, i64 %t55)
  %t60 = add i64 %t57, %t59
  %t61 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t60)
  call void @olang_textcopy(ptr %t61, ptr %t56, i64 %t57)
  %t62 = getelementptr i8, ptr %t61, i64 %t57
  %t63 = call i64 @__olang_fmt_i64(ptr %t62, i64 %t55)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t61, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t65)
  br label %bb14
bb14:
  %t69 = load ptr, ptr %l2, !tbaa !29
  store ptr %t69, ptr %l54, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i32, ptr %l1, !tbaa !23
  %t74 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t74, ptr %l57
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l54, !tbaa !29
  %t76 = load i32, ptr %l57, !tbaa !23
  %t77 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t75, i32 %t76)
  store { i64, ptr } %t77, ptr %l58
  br label %bb16
bb16:
  %t78 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t78, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = icmp sgt i64 %t83, %t84
  br i1 %t87, label %bb17, label %bb18
bb17:
  %t89 = load i64, ptr %l9, !tbaa !24
  %t91 = icmp sgt i64 %t89, 0
  br i1 %t91, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb22
bb19:
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = sub i64 %t93, %t94
  %t98 = load i64, ptr %l9, !tbaa !24
  %t101 = add i64 %t97, %t98
  %t103 = sub i64 %t101, 1
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = sdiv i64 %t103, %t104
  store i64 %t107, ptr %l67, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb21
bb21:
  %t109 = load i64, ptr %l67, !tbaa !24
  store i64 %t109, ptr %l64, !tbaa !24
  br label %bb22
bb22:
  %t110 = load i64, ptr %l64, !tbaa !24
  store i64 %t110, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t111 = load i64, ptr %l11, !tbaa !24
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb25:
  br label %bb26
bb26:
  %t119 = load i64, ptr %l7, !tbaa !24
  %t120 = load i64, ptr %l11, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = mul i64 %t120, %t121
  %t127 = add i64 %t119, %t124
  store i64 %t127, ptr %l12, !tbaa !24
  %t129 = load ptr, ptr %l2, !tbaa !29
  %t130 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t130, ptr %l86, !tbaa !27
  %t131 = load i64, ptr %l12, !tbaa !24
  %t133 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !27
  %t135 = getelementptr i32, ptr %t134, i64 %t131
  %t136 = load i32, ptr %t135, !tbaa !33
  %t139 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t129, i32 %t136)
  store i32 %t139, ptr %l89
  br label %bb27
bb27:
  %t140 = load i32, ptr %l89, !tbaa !23
  store i32 %t140, ptr %l13, !tbaa !23
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/emit:Emitter", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  store ptr %t144, ptr %l91, !tbaa !29
  %t145 = load ptr, ptr %l2, !tbaa !29
  %t146 = load i32, ptr %l13, !tbaa !23
  %t149 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t145, i32 %t146)
  store i32 %t149, ptr %l94
  br label %bb28
bb28:
  %t150 = load ptr, ptr %l91, !tbaa !29
  %t151 = load i32, ptr %l94, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s4, ptr %t150, i32 %t151)
  store { i64, ptr } %t152, ptr %l95
  br label %bb29
bb29:
  %t153 = load { i64, ptr }, ptr %l95, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t156 = extractvalue { i64, ptr } %t153, 0
  store i64 %t156, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t158 = load i64, ptr %l16, !tbaa !24
  %t159 = load i64, ptr %l15, !tbaa !24
  %t162 = icmp sgt i64 %t158, %t159
  br i1 %t162, label %bb30, label %bb31
bb30:
  %t164 = load i64, ptr %l17, !tbaa !24
  %t166 = icmp sgt i64 %t164, 0
  br i1 %t166, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb35
bb32:
  %t168 = load i64, ptr %l16, !tbaa !24
  %t169 = load i64, ptr %l15, !tbaa !24
  %t172 = sub i64 %t168, %t169
  %t173 = load i64, ptr %l17, !tbaa !24
  %t176 = add i64 %t172, %t173
  %t178 = sub i64 %t176, 1
  %t179 = load i64, ptr %l17, !tbaa !24
  %t182 = sdiv i64 %t178, %t179
  store i64 %t182, ptr %l104, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb34
bb34:
  %t184 = load i64, ptr %l104, !tbaa !24
  store i64 %t184, ptr %l101, !tbaa !24
  br label %bb35
bb35:
  %t185 = load i64, ptr %l101, !tbaa !24
  store i64 %t185, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t186 = load i64, ptr %l19, !tbaa !24
  %t187 = load i64, ptr %l18, !tbaa !24
  %t190 = icmp slt i64 %t186, %t187
  %t192 = xor i1 %t190, true
  br i1 %t192, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb38:
  br label %bb39
bb39:
  %t194 = load i64, ptr %l15, !tbaa !24
  %t195 = load i64, ptr %l19, !tbaa !24
  %t196 = load i64, ptr %l17, !tbaa !24
  %t199 = mul i64 %t195, %t196
  %t202 = add i64 %t194, %t199
  store i64 %t202, ptr %l20, !tbaa !24
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t205, ptr %l123, !tbaa !27
  %t206 = load i64, ptr %l12, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i32, ptr %t209, i64 %t206
  %t211 = load i32, ptr %t210, !tbaa !33
  %t214 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t204, i32 %t211)
  store i64 %t214, ptr %l126
  br label %bb40
bb40:
  %t215 = load i64, ptr %l20, !tbaa !24
  store i64 %t215, ptr %l128, !tbaa !65
  %t217 = load i64, ptr %l126, !tbaa !65
  %t218 = load i64, ptr %l128, !tbaa !65
  %t219 = load i64, ptr %l128, !tbaa !65
  %t220 = lshr i64 %t217, %t219
  %t222 = and i64 %t220, 1
  %t224 = icmp eq i64 %t222, 0
  br i1 %t224, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s6)
  br label %bb51
bb42:
  br label %bb43
bb43:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t226)
  store i64 %t228, ptr %l133
  br label %bb44
bb44:
  %t229 = load i64, ptr %l133, !tbaa !24
  store i64 %t229, ptr %l21, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i32, ptr %l13, !tbaa !23
  %t234 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrQualifier(ptr %v0, ptr %s6, ptr %t230, i32 %t231)
  store { i64, ptr } %t234, ptr %l136
  br label %bb45
bb45:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/emit:Emitter", ptr %t235, i32 0, i32 0
  %t238 = load ptr, ptr %t237, !tbaa !29
  store ptr %t238, ptr %l138, !tbaa !29
  %t239 = load ptr, ptr %l2, !tbaa !29
  %t240 = load i32, ptr %l13, !tbaa !23
  %t243 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t239, i32 %t240)
  store i32 %t243, ptr %l141
  br label %bb46
bb46:
  %t244 = load i64, ptr %l20, !tbaa !24
  %t245 = load ptr, ptr %l138, !tbaa !29
  %t246 = load i32, ptr %l141, !tbaa !23
  %t248 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s6, ptr %t245, i32 %t246, i64 %t244)
  store { i64, ptr } %t248, ptr %l143
  br label %bb47
bb47:
  %t249 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 1
  %t251 = extractvalue { i64, ptr } %t249, 0
  %t252 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 1
  %t254 = extractvalue { i64, ptr } %t252, 0
  %t255 = add i64 %t251, %t254
  %t256 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t250, i64 %t251)
  %t257 = getelementptr i8, ptr %t256, i64 %t251
  call void @olang_textcopy(ptr %t257, ptr %t253, i64 %t254)
  %t258 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l145, !tbaa !29
  %t262 = load i64, ptr %l21, !tbaa !24
  store i64 %t262, ptr %l146, !tbaa !24
  %t265 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s6, ptr %s6, { i64, ptr } %t259)
  store { i64, ptr } %t265, ptr %l148
  br label %bb48
bb48:
  %t266 = load i64, ptr %l12, !tbaa !24
  %t268 = add i64 %t266, 1
  %t270 = shl i64 %t268, 16
  %t271 = load i64, ptr %l20, !tbaa !24
  %t274 = or i64 %t270, %t271
  %t275 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t276 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t277 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = add i64 %t276, %t279
  %t281 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t283 = add i64 %t280, %t282
  %t285 = call i64 @__olang_fmt_i64(ptr null, i64 %t274)
  %t286 = add i64 %t283, %t285
  %t287 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t275, i64 %t276)
  %t291 = getelementptr i8, ptr %t290, i64 %t276
  call void @olang_textcopy(ptr %t291, ptr %t278, i64 %t279)
  %t292 = getelementptr i8, ptr %t291, i64 %t279
  call void @olang_textcopy(ptr %t292, ptr %t281, i64 %t282)
  %t293 = getelementptr i8, ptr %t292, i64 %t282
  %t294 = call i64 @__olang_fmt_i64(ptr %t293, i64 %t274)
  %t295 = getelementptr i8, ptr %t293, i64 %t285
  call void @olang_textcopy(ptr %t295, ptr %t287, i64 %t288)
  %t296 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t290, 1
  %t299 = load ptr, ptr %l145, !tbaa !29
  %t300 = load i64, ptr %l146, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s6, ptr %t299, i64 %t300, { i64, ptr } %t297)
  br label %bb49
bb49:
  %t302 = load i64, ptr %l21, !tbaa !24
  %t303 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t306 = call i64 @__olang_fmt_i64(ptr null, i64 %t302)
  %t307 = add i64 %t304, %t306
  %t308 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t307)
  call void @olang_textcopy(ptr %t308, ptr %t303, i64 %t304)
  %t309 = getelementptr i8, ptr %t308, i64 %t304
  %t310 = call i64 @__olang_fmt_i64(ptr %t309, i64 %t302)
  %t311 = insertvalue { i64, ptr } undef, i64 %t307, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t308, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l4, { i64, ptr } %t312)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s6)
  br label %bb51
bb51:
  %t316 = load i64, ptr %l19, !tbaa !24
  %t319 = add i64 %t316, 1
  store i64 %t319, ptr %l19, !tbaa !24
  br label %bb36
bb52:
  call void @__olang_scope_close(ptr %s4)
  br label %bb53
bb53:
  %t321 = load i64, ptr %l11, !tbaa !24
  %t324 = add i64 %t321, 1
  store i64 %t324, ptr %l11, !tbaa !24
  br label %bb23
bb54:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t326)
  store i64 %t328, ptr %l167
  br label %bb55
bb55:
  %t329 = load i64, ptr %l167, !tbaa !24
  store i64 %t329, ptr %l23, !tbaa !24
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l168, !tbaa !29
  %t331 = load i64, ptr %l23, !tbaa !24
  store i64 %t331, ptr %l169, !tbaa !24
  %t333 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t333, ptr %l171
  br label %bb56
bb56:
  %t334 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t335 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t336 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 1
  %t338 = extractvalue { i64, ptr } %t336, 0
  %t339 = add i64 %t335, %t338
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t341 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t342 = add i64 %t339, %t341
  %t343 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t342)
  call void @olang_textcopy(ptr %t343, ptr %t334, i64 %t335)
  %t344 = getelementptr i8, ptr %t343, i64 %t335
  call void @olang_textcopy(ptr %t344, ptr %t337, i64 %t338)
  %t345 = getelementptr i8, ptr %t344, i64 %t338
  call void @olang_textcopy(ptr %t345, ptr %t340, i64 %t341)
  %t346 = insertvalue { i64, ptr } undef, i64 %t342, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t343, 1
  %t349 = load ptr, ptr %l168, !tbaa !29
  %t350 = load i64, ptr %l169, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t349, i64 %t350, { i64, ptr } %t347)
  br label %bb57
bb57:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l174, !tbaa !29
  %t353 = load i64, ptr %l3, !tbaa !24
  store i64 %t353, ptr %l175, !tbaa !24
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l1, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %s0, ptr %t354, i32 %t355)
  store { i64, ptr } %t358, ptr %l178
  br label %bb58
bb58:
  %t359 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t361 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s0, { i64, ptr } %t359)
  store { i64, ptr } %t361, ptr %l180
  br label %bb59
bb59:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l181, !tbaa !29
  %t363 = load ptr, ptr %l2, !tbaa !29
  %t365 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t363, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i32 %t365, ptr %l183
  br label %bb60
bb60:
  %t366 = load ptr, ptr %l181, !tbaa !29
  %t367 = load i32, ptr %l183, !tbaa !23
  %t368 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBasic(ptr %v0, ptr %t366, i32 %t367)
  store i64 %t368, ptr %l184
  br label %bb61
bb61:
  %t369 = load i64, ptr %l23, !tbaa !24
  %t370 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t372 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t373 = extractvalue { i64, ptr } %t372, 1
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = add i64 %t371, %t374
  %t376 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t378 = add i64 %t375, %t377
  %t379 = load i64, ptr %l184, !tbaa !24
  %t380 = call i64 @__olang_fmt_i64(ptr null, i64 %t379)
  %t381 = add i64 %t378, %t380
  %t382 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t386 = call i64 @__olang_fmt_i64(ptr null, i64 %t369)
  %t387 = add i64 %t384, %t386
  %t388 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t389 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t390 = add i64 %t387, %t389
  %t391 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t390)
  call void @olang_textcopy(ptr %t391, ptr %t370, i64 %t371)
  %t392 = getelementptr i8, ptr %t391, i64 %t371
  call void @olang_textcopy(ptr %t392, ptr %t373, i64 %t374)
  %t393 = getelementptr i8, ptr %t392, i64 %t374
  call void @olang_textcopy(ptr %t393, ptr %t376, i64 %t377)
  %t394 = getelementptr i8, ptr %t393, i64 %t377
  %t395 = call i64 @__olang_fmt_i64(ptr %t394, i64 %t379)
  %t396 = getelementptr i8, ptr %t394, i64 %t380
  call void @olang_textcopy(ptr %t396, ptr %t382, i64 %t383)
  %t397 = getelementptr i8, ptr %t396, i64 %t383
  %t398 = call i64 @__olang_fmt_i64(ptr %t397, i64 %t369)
  %t399 = getelementptr i8, ptr %t397, i64 %t386
  call void @olang_textcopy(ptr %t399, ptr %t388, i64 %t389)
  %t400 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t391, 1
  %t403 = load ptr, ptr %l174, !tbaa !29
  %t404 = load i64, ptr %l175, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s0, ptr %t403, i64 %t404, { i64, ptr } %t401)
  br label %bb62
bb62:
  %t406 = load i64, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t406, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFunctions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:LineIter"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l22 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca { i64, ptr }
  %l26 = alloca %"std/prelude/text:LineIter"
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i1
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i32
  %l48 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i32
  %l54 = alloca i1
  %l58 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l71 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l84 = alloca i64
  %l86 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca i64
  %l94 = alloca i64
  %l96 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca i64
  %l117 = alloca i64
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l135 = alloca i1
  %l138 = alloca { i64, ptr }
  %l139 = alloca i1
  %l140 = alloca i1
  %l143 = alloca { i64, ptr }
  %l144 = alloca i1
  %l156 = alloca i64
  %l160 = alloca ptr
  %l162 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t5 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } %t4)
  store i1 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i1, ptr %l17, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = extractvalue { i64, ptr } %t9, 0
  %t13 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t12)
  call void @olang_textcopy(ptr %t13, ptr %t11, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t17, ptr %l21
  br label %bb5
bb5:
  %t18 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t18, ptr %l2
  %t19 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t19, ptr %l22
  br label %bb6
bb6:
  %t20 = load %"std/prelude/text:StringBuilder", ptr %l22
  store %"std/prelude/text:StringBuilder" %t20, ptr %l3
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t21, ptr %l4, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v1, ptr %v1, { i64, ptr } %t23)
  store %"std/prelude/text:LineIter" %t25, ptr %l26
  br label %bb7
bb7:
  %t26 = load %"std/prelude/text:LineIter", ptr %l26
  store %"std/prelude/text:LineIter" %t26, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t28 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v1, ptr %v1, ptr %l5)
  %t29 = extractvalue { i32, { i64, ptr } } %t28, 1
  %t30 = extractvalue { i32, { i64, ptr } } %t28, 0
  store i32 %t30, ptr %l30
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb10, label %ok.32, !prof !99
ok.32:
  store { i64, ptr } %t29, ptr %l29
  br label %bb9
bb9:
  %t33 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  br label %bb12
bb10:
  %t34 = load i32, ptr %l30, !tbaa !23
  %t35 = ashr i32 %t34, 16
  %t37 = icmp eq i32 %t35, 1
  store i1 %t37, ptr %l32, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb99
bb12:
  %t38 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t38, ptr %l6, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s4, { i64, ptr } %t39, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d53, i32 0, i32 1) })
  store i1 %t41, ptr %l34
  br label %bb13
bb13:
  %t42 = load i1, ptr %l34, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s4, { i64, ptr } %t43, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t45, ptr %l37
  br label %bb16
bb15:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb17
bb16:
  %t46 = load i1, ptr %l37, !tbaa !21
  store i1 %t46, ptr %l35, !tbaa !21
  br label %bb17
bb17:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb18, label %bb19
bb18:
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l41, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t52 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t48, { i64, ptr } %t51)
  store i1 %t52, ptr %l42
  br label %bb20
bb19:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb21
bb20:
  %t53 = load i1, ptr %l42, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t56 = load i1, ptr %l38, !tbaa !21
  br i1 %t56, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t57 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t59 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s5, { i64, ptr } %t57, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) })
  %t60 = extractvalue { i32, i64 } %t59, 1
  %t61 = extractvalue { i32, i64 } %t59, 0
  store i32 %t61, ptr %l47
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb25, label %ok.63, !prof !99
ok.63:
  store i64 %t60, ptr %l46
  br label %bb24
bb23:
  br label %bb77
bb24:
  %t64 = load i64, ptr %l46, !tbaa !24
  store i64 %t64, ptr %l44, !tbaa !24
  br label %bb27
bb25:
  br label %bb26
bb26:
  store i64 -1, ptr %l44, !tbaa !24
  br label %bb27
bb27:
  %t65 = load i64, ptr %l44, !tbaa !24
  store i64 %t65, ptr %l7, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t68 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s5, { i64, ptr } %t66, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d57, i32 0, i32 1) })
  %t69 = extractvalue { i32, i64 } %t68, 1
  %t70 = extractvalue { i32, i64 } %t68, 0
  store i32 %t70, ptr %l51
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb29, label %ok.72, !prof !99
ok.72:
  store i64 %t69, ptr %l50
  br label %bb28
bb28:
  %t73 = load i64, ptr %l50, !tbaa !24
  store i64 %t73, ptr %l48, !tbaa !24
  br label %bb31
bb29:
  br label %bb30
bb30:
  store i64 -1, ptr %l48, !tbaa !24
  br label %bb31
bb31:
  %t74 = load i64, ptr %l48, !tbaa !24
  store i64 %t74, ptr %l8, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = icmp sge i64 %t75, 0
  br i1 %t77, label %bb32, label %bb33
bb32:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l7, !tbaa !24
  %t83 = icmp sgt i64 %t79, %t80
  store i1 %t83, ptr %l54, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb34
bb34:
  %t85 = load i1, ptr %l54, !tbaa !21
  br i1 %t85, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t86, ptr %l58, !tbaa !27
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l60, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  store i64 %t90, ptr %l61, !tbaa !24
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 0
  store i64 %t92, ptr %l62, !tbaa !24
  %t93 = load i64, ptr %l60, !tbaa !24
  %t94 = icmp sge i64 %t93, 0
  br i1 %t94, label %bb37, label %bb38
bb36:
  br label %bb76
bb37:
  %t96 = load i64, ptr %l60, !tbaa !24
  %t97 = load i64, ptr %l61, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d)
  unreachable
bb39:
  %t100 = load i64, ptr %l61, !tbaa !24
  %t101 = load i64, ptr %l62, !tbaa !24
  %t102 = icmp sle i64 %t100, %t101
  br i1 %t102, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d)
  unreachable
bb41:
  %t104 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = load i64, ptr %l60, !tbaa !24
  %t107 = load i64, ptr %l61, !tbaa !24
  %t108 = getelementptr i8, ptr %t105, i64 %t106
  %t109 = sub i64 %t107, %t106
  %t110 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  store { i64, ptr } %t111, ptr %l9, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s6, { i64, ptr } %t113, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t115, ptr %l68
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d)
  unreachable
bb43:
  %t116 = load i1, ptr %l68, !tbaa !21
  br i1 %t116, label %bb44, label %bb45
bb44:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb52
bb45:
  %t117 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s6, { i64, ptr } %t117, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t119, ptr %l71
  br label %bb46
bb46:
  %t120 = load i1, ptr %l71, !tbaa !21
  br i1 %t120, label %bb47, label %bb48
bb47:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb51
bb48:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l73, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t124 = call { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v1, ptr %s6, { i64, ptr } %t122)
  store { i64, ptr } %t124, ptr %l75
  br label %bb49
bb49:
  %t125 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t125, 0
  store i64 %t126, ptr %l76, !tbaa !24
  %t127 = load i64, ptr %l76, !tbaa !24
  %t128 = mul i64 %t127, 1
  %t129 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t128)
  %t130 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr %t129, 1
  store { i64, ptr } %t131, ptr %l77, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l76, !tbaa !24
  %t137 = mul i64 %t136, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t133, ptr %t135, i64 %t137, i1 false)
  %t138 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  %t145 = load ptr, ptr %l73, !tbaa !29
  %t147 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %s6, ptr %s6, ptr %t145, { i64, ptr } %t144)
  store { i64, ptr } %t147, ptr %l79
  br label %bb50
bb50:
  %t148 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t148, ptr %l72, !tbaa !27
  br label %bb51
bb51:
  %t150 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t150, ptr %l69, !tbaa !27
  br label %bb52
bb52:
  %t151 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t151, ptr %l10, !tbaa !27
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgGenFile(ptr %v0, ptr %t152)
  store i64 %t154, ptr %l82
  br label %bb53
bb53:
  %t155 = load i64, ptr %l82, !tbaa !24
  store i64 %t155, ptr %l11, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t156)
  store i64 %t158, ptr %l84
  br label %bb54
bb54:
  %t159 = load i64, ptr %l84, !tbaa !24
  store i64 %t159, ptr %l12, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t160)
  store i64 %t162, ptr %l86
  br label %bb55
bb55:
  %t163 = load i64, ptr %l86, !tbaa !24
  store i64 %t163, ptr %l13, !tbaa !24
  store ptr %l3, ptr %l87, !tbaa !29
  %t164 = load i64, ptr %l12, !tbaa !24
  store i64 %t164, ptr %l88, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t167 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s6, ptr %s6, { i64, ptr } %t165)
  store { i64, ptr } %t167, ptr %l90
  br label %bb56
bb56:
  %t168 = load i64, ptr %l11, !tbaa !24
  store i64 %t168, ptr %l91, !tbaa !24
  %t169 = load i64, ptr %l11, !tbaa !24
  store i64 %t169, ptr %l92, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l94
  br label %bb57
bb57:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %t173)
  store i64 %t175, ptr %l96
  br label %bb58
bb58:
  %t176 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t178 = load i64, ptr %l88, !tbaa !24
  %t179 = call i64 @__olang_fmt_i64(ptr null, i64 %t178)
  %t180 = add i64 %t177, %t179
  %t181 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t184 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = add i64 %t183, %t186
  %t188 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t191 = load i64, ptr %l91, !tbaa !24
  %t192 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t193 = add i64 %t190, %t192
  %t194 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t196 = add i64 %t193, %t195
  %t197 = load i64, ptr %l92, !tbaa !24
  %t198 = call i64 @__olang_fmt_i64(ptr null, i64 %t197)
  %t199 = add i64 %t196, %t198
  %t200 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = load i64, ptr %l94, !tbaa !24
  %t204 = call i64 @__olang_fmt_i64(ptr null, i64 %t203)
  %t205 = add i64 %t202, %t204
  %t206 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = load i64, ptr %l96, !tbaa !24
  %t210 = call i64 @__olang_fmt_i64(ptr null, i64 %t209)
  %t211 = add i64 %t208, %t210
  %t212 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t214 = add i64 %t211, %t213
  %t215 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t214)
  call void @olang_textcopy(ptr %t215, ptr %t176, i64 %t177)
  %t216 = getelementptr i8, ptr %t215, i64 %t177
  %t217 = call i64 @__olang_fmt_i64(ptr %t216, i64 %t178)
  %t218 = getelementptr i8, ptr %t216, i64 %t179
  call void @olang_textcopy(ptr %t218, ptr %t181, i64 %t182)
  %t219 = getelementptr i8, ptr %t218, i64 %t182
  call void @olang_textcopy(ptr %t219, ptr %t185, i64 %t186)
  %t220 = getelementptr i8, ptr %t219, i64 %t186
  call void @olang_textcopy(ptr %t220, ptr %t188, i64 %t189)
  %t221 = getelementptr i8, ptr %t220, i64 %t189
  %t222 = call i64 @__olang_fmt_i64(ptr %t221, i64 %t191)
  %t223 = getelementptr i8, ptr %t221, i64 %t192
  call void @olang_textcopy(ptr %t223, ptr %t194, i64 %t195)
  %t224 = getelementptr i8, ptr %t223, i64 %t195
  %t225 = call i64 @__olang_fmt_i64(ptr %t224, i64 %t197)
  %t226 = getelementptr i8, ptr %t224, i64 %t198
  call void @olang_textcopy(ptr %t226, ptr %t200, i64 %t201)
  %t227 = getelementptr i8, ptr %t226, i64 %t201
  %t228 = call i64 @__olang_fmt_i64(ptr %t227, i64 %t203)
  %t229 = getelementptr i8, ptr %t227, i64 %t204
  call void @olang_textcopy(ptr %t229, ptr %t206, i64 %t207)
  %t230 = getelementptr i8, ptr %t229, i64 %t207
  %t231 = call i64 @__olang_fmt_i64(ptr %t230, i64 %t209)
  %t232 = getelementptr i8, ptr %t230, i64 %t210
  call void @olang_textcopy(ptr %t232, ptr %t212, i64 %t213)
  %t233 = insertvalue { i64, ptr } undef, i64 %t214, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t215, 1
  %t236 = load ptr, ptr %l87, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t236, { i64, ptr } %t234)
  br label %bb59
bb59:
  %t238 = load i64, ptr %l13, !tbaa !24
  %t239 = load i64, ptr %l12, !tbaa !24
  %t240 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t243 = call i64 @__olang_fmt_i64(ptr null, i64 %t238)
  %t244 = add i64 %t241, %t243
  %t245 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t246 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t247 = add i64 %t244, %t246
  %t249 = call i64 @__olang_fmt_i64(ptr null, i64 %t239)
  %t250 = add i64 %t247, %t249
  %t251 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t252 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t253 = add i64 %t250, %t252
  %t254 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t240, i64 %t241)
  %t255 = getelementptr i8, ptr %t254, i64 %t241
  %t256 = call i64 @__olang_fmt_i64(ptr %t255, i64 %t238)
  %t257 = getelementptr i8, ptr %t255, i64 %t243
  call void @olang_textcopy(ptr %t257, ptr %t245, i64 %t246)
  %t258 = getelementptr i8, ptr %t257, i64 %t246
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t239)
  %t260 = getelementptr i8, ptr %t258, i64 %t249
  call void @olang_textcopy(ptr %t260, ptr %t251, i64 %t252)
  %t261 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t254, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %l3, { i64, ptr } %t262)
  br label %bb60
bb60:
  store ptr %l2, ptr %l104, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t266, ptr %l105, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t271 = sub i64 %t269, 2
  store i64 %t271, ptr %l108, !tbaa !24
  %t272 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l109, !tbaa !24
  %t274 = icmp sge i64 0, 0
  br i1 %t274, label %bb61, label %bb62
bb61:
  %t276 = load i64, ptr %l108, !tbaa !24
  %t277 = icmp sle i64 0, %t276
  br i1 %t277, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70)
  unreachable
bb63:
  %t279 = load i64, ptr %l108, !tbaa !24
  %t280 = load i64, ptr %l109, !tbaa !24
  %t281 = icmp sle i64 %t279, %t280
  br i1 %t281, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70)
  unreachable
bb65:
  %t283 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = load i64, ptr %l108, !tbaa !24
  %t286 = getelementptr i8, ptr %t284, i64 0
  %t287 = sub i64 %t285, 0
  %t288 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t286, 1
  %t290 = load i64, ptr %l12, !tbaa !24
  %t292 = extractvalue { i64, ptr } %t289, 1
  %t293 = extractvalue { i64, ptr } %t289, 0
  %t294 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t298 = call i64 @__olang_fmt_i64(ptr null, i64 %t290)
  %t299 = add i64 %t296, %t298
  %t300 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t302)
  call void @olang_textcopy(ptr %t303, ptr %t292, i64 %t293)
  %t304 = getelementptr i8, ptr %t303, i64 %t293
  call void @olang_textcopy(ptr %t304, ptr %t294, i64 %t295)
  %t305 = getelementptr i8, ptr %t304, i64 %t295
  %t306 = call i64 @__olang_fmt_i64(ptr %t305, i64 %t290)
  %t307 = getelementptr i8, ptr %t305, i64 %t298
  call void @olang_textcopy(ptr %t307, ptr %t300, i64 %t301)
  %t308 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t309 = insertvalue { i64, ptr } %t308, ptr %t303, 1
  %t311 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t311, { i64, ptr } %t309)
  br label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70)
  unreachable
bb67:
  %t313 = call ptr @__olang_scope_hold(ptr %s0)
  %t314 = ptrtoint ptr %t313 to i64
  store i64 %t314, ptr %l117, !tbaa !24
  %t315 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2edbgFunctions_2elocal_2e4
  br i1 %t315, label %bb68, label %bb69
bb68:
  %t317 = call ptr @__olang_region_make(ptr %s0)
  %t318 = ptrtoint ptr %t317 to i64
  store i64 %t318, ptr %l117, !tbaa !24
  br label %bb69
bb69:
  %t319 = load i64, ptr %l13, !tbaa !24
  %t320 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t321 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t323 = call i64 @__olang_fmt_i64(ptr null, i64 %t319)
  %t324 = add i64 %t321, %t323
  %t325 = load i64, ptr %l117
  %t326 = inttoptr i64 %t325 to ptr
  %t327 = call ptr @__olang_held_alloc(ptr %t326, i64 %t324)
  call void @olang_textcopy(ptr %t327, ptr %t320, i64 %t321)
  %t328 = getelementptr i8, ptr %t327, i64 %t321
  %t329 = call i64 @__olang_fmt_i64(ptr %t328, i64 %t319)
  %t330 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t327, 1
  store { i64, ptr } %t331, ptr %l120, !tbaa !27
  %t332 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2edbgFunctions_2elocal_2e4
  br i1 %t332, label %bb70, label %bb71
bb70:
  %t334 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t337 = icmp eq i64 %t335, 0
  br i1 %t337, label %bb72, label %bb73
bb71:
  %t339 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t339, ptr %l124, !tbaa !27
  %t340 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t340, ptr %l4, !tbaa !27
  %t341 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2edbgFunctions_2elocal_2e4
  br i1 %t341, label %bb74, label %bb75
bb72:
  store { i64, ptr } zeroinitializer, ptr %l120, !tbaa !27
  br label %bb73
bb73:
  %t343 = load i64, ptr %l117
  %t344 = inttoptr i64 %t343 to ptr
  %t345 = load { i64, ptr }, ptr %l120
  %t346 = extractvalue { i64, ptr } %t345, 1
  %t347 = call ptr @__olang_region_or(ptr %t346, ptr null)
  %t348 = icmp ne ptr %t347, null
  %t349 = select i1 %t348, ptr %t347, ptr null
  call void @__olang_region_settle_in(ptr %t344, ptr %t349)
  br label %bb71
bb74:
  %t350 = load { i64, ptr }, ptr %l124
  %t351 = extractvalue { i64, ptr } %t350, 1
  call void @__olang_region_release(ptr %t351)
  store { i64, ptr } zeroinitializer, ptr %l124
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb98
bb76:
  call void @__olang_scope_close(ptr %s5)
  br label %bb77
bb77:
  %t352 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t354 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t352, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t354, ptr %l127
  br label %bb78
bb78:
  %t355 = load i1, ptr %l127, !tbaa !21
  br i1 %t355, label %bb79, label %bb80
bb79:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l128, !tbaa !27
  %t356 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t357 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t357, ptr %l130, !tbaa !27
  store { i64, ptr } %t356, ptr %l4, !tbaa !27
  %t359 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2edbgFunctions_2elocal_2e4
  br i1 %t359, label %bb81, label %bb82
bb80:
  br label %bb83
bb81:
  %t361 = load { i64, ptr }, ptr %l130
  %t362 = extractvalue { i64, ptr } %t361, 1
  call void @__olang_region_release(ptr %t362)
  store { i64, ptr } zeroinitializer, ptr %l130
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t363 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t365 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s4, { i64, ptr } %t363, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t365, ptr %l133
  br label %bb84
bb84:
  %t366 = load i1, ptr %l133, !tbaa !21
  %t367 = xor i1 %t366, true
  br i1 %t367, label %bb85, label %bb86
bb85:
  %t369 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %l138, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t373 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t369, { i64, ptr } %t372)
  store i1 %t373, ptr %l139
  br label %bb87
bb86:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb88
bb87:
  %t374 = load i1, ptr %l139, !tbaa !21
  store i1 %t374, ptr %l135, !tbaa !21
  br label %bb88
bb88:
  %t375 = load i1, ptr %l135, !tbaa !21
  br i1 %t375, label %bb89, label %bb90
bb89:
  %t376 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l143, !tbaa !27
  %t379 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t380 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s4, { i64, ptr } %t376, { i64, ptr } %t379)
  store i1 %t380, ptr %l144
  br label %bb91
bb90:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb92
bb91:
  %t381 = load i1, ptr %l144, !tbaa !21
  %t382 = xor i1 %t381, true
  store i1 %t382, ptr %l140, !tbaa !21
  br label %bb92
bb92:
  %t384 = load i1, ptr %l140, !tbaa !21
  br i1 %t384, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s12
  %t385 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t386 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t385, 1
  %t389 = extractvalue { i64, ptr } %t385, 0
  %t391 = extractvalue { i64, ptr } %t386, 1
  %t392 = extractvalue { i64, ptr } %t386, 0
  %t393 = add i64 %t389, %t392
  %t394 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t396 = add i64 %t393, %t395
  %t397 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t396)
  call void @olang_textcopy(ptr %t397, ptr %t388, i64 %t389)
  %t398 = getelementptr i8, ptr %t397, i64 %t389
  call void @olang_textcopy(ptr %t398, ptr %t391, i64 %t392)
  %t399 = getelementptr i8, ptr %t398, i64 %t392
  call void @olang_textcopy(ptr %t399, ptr %t394, i64 %t395)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t397, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s12, ptr %l2, { i64, ptr } %t401)
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  br label %bb98
bb96:
  %t405 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 1
  %t408 = extractvalue { i64, ptr } %t405, 0
  %t409 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t410 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t411 = add i64 %t408, %t410
  %t412 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t411)
  call void @olang_textcopy(ptr %t412, ptr %t407, i64 %t408)
  %t413 = getelementptr i8, ptr %t412, i64 %t408
  call void @olang_textcopy(ptr %t413, ptr %t409, i64 %t410)
  %t414 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t412, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } %t415)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s4)
  br label %bb98
bb98:
  br label %bb8
bb99:
  %t420 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l3)
  store i64 %t420, ptr %l156
  br label %bb100
bb100:
  %t421 = load i64, ptr %l156, !tbaa !24
  %t422 = icmp eq i64 %t421, 0
  br i1 %t422, label %bb101, label %bb102
bb101:
  %t424 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t424, 1
  %t427 = extractvalue { i64, ptr } %t424, 0
  %t428 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t427)
  call void @olang_textcopy(ptr %t428, ptr %t426, i64 %t427)
  %t429 = insertvalue { i64, ptr } undef, i64 %t427, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t430, ptr %rv
  br label %ret
bb102:
  br label %bb103
bb103:
  store ptr %l2, ptr %l160, !tbaa !29
  %t433 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t433, ptr %l162
  br label %bb104
bb104:
  %t434 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t435 = load ptr, ptr %l160, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t435, { i64, ptr } %t434)
  br label %bb105
bb105:
  %t438 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t438, ptr %l165
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s0)
  %t439 = load { i64, ptr }, ptr %l165, !tbaa !27
  store { i64, ptr } %t439, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgGenFile(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 80
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = getelementptr %"compiler/emit:Emitter", ptr %t13, i32 0, i32 80
  store i64 %t12, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/emit:Emitter", ptr %t16, i32 0, i32 80
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %s1, ptr %t15, i64 %t19, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:Emitter", ptr %t22, i32 0, i32 80
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eentry(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l34 = alloca %"std/prelude/text:StringBuilder"
  %l45 = alloca ptr
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i64
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca i64
  %l60 = alloca i64
  %l65 = alloca i64
  %l69 = alloca i1
  %l71 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l92 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l107 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l114 = alloca i64
  %l116 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l143 = alloca i64
  %l146 = alloca i64
  %l165 = alloca { i64, ptr }
  %l168 = alloca i32
  %l170 = alloca ptr
  %l173 = alloca i32
  %l174 = alloca { i64, ptr }
  %l180 = alloca i64
  %l183 = alloca i64
  %l211 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l216 = alloca i32
  %l218 = alloca { i64, ptr }
  %l225 = alloca ptr
  %l226 = alloca i64
  %l227 = alloca i64
  %l230 = alloca { i64, ptr }
  %l234 = alloca i64
  %l237 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l254 = alloca i1
  %l259 = alloca ptr
  %l263 = alloca i64
  %l265 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %t112 = alloca { i64, [2 x i64] }, align 8
  %t147 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t6, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d83, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t8, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d85, i32 0, i32 1) }, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb2
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t10, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb3
bb3:
  %t12 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t12, ptr %l34
  br label %bb4
bb4:
  %t13 = load %"std/prelude/text:StringBuilder", ptr %l34
  store %"std/prelude/text:StringBuilder" %t13, ptr %l4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb5
bb5:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %s0, ptr %t17, ptr %l4)
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/emit:Emitter", ptr %t20, i32 0, i32 7
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s1, ptr %t25, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s1, ptr %s1, ptr %t27, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d92, i32 0, i32 1) }, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb12
bb12:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s1, ptr %l4, { i64, ptr } { i64 97, ptr getelementptr inbounds (<{ i64, [97 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l45, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l47
  %t33 = call ptr @__olang_scope_hold(ptr %s2)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l48, !tbaa !24
  %t35 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t35, label %bb15, label %bb16
bb15:
  %t37 = call ptr @__olang_region_make_part(ptr %s2)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l48, !tbaa !24
  br label %bb16
bb16:
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l50, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l51, !tbaa !24
  %t43 = load i64, ptr %l51, !tbaa !24
  %t44 = mul i64 %t43, 8
  %t45 = load i64, ptr %l48
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_held_alloc(ptr %t46, i64 %t44)
  %t48 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l52, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l51, !tbaa !24
  %t55 = mul i64 %t54, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t57 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  store { i64, ptr } %t56, ptr %t57, !tbaa !27
  %t58 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  %t64 = icmp eq i64 %t62, 0
  br i1 %t64, label %bb19, label %bb20
bb18:
  %t66 = load ptr, ptr %l45, !tbaa !29
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %s2, ptr %s2, ptr %t66, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l56
  br label %bb21
bb19:
  %t69 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t69, !tbaa !27
  br label %bb20
bb20:
  %t70 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47, i32 0, i32 0
  %t71 = load i64, ptr %l48
  %t72 = inttoptr i64 %t71 to ptr
  %t73 = load { i64, ptr }, ptr %t70
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = call ptr @__olang_region_or(ptr %t74, ptr null)
  %t76 = icmp ne ptr %t75, null
  %t77 = select i1 %t76, ptr %t75, ptr null
  call void @__olang_region_settle_in(ptr %t72, ptr %t77)
  br label %bb18
bb21:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t79
  store ptr %t79, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb22:
  %t81 = load i64, ptr %l6, !tbaa !24
  store i64 %t81, ptr %l58, !tbaa !24
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s2, ptr %t82)
  store i64 %t84, ptr %l60
  br label %bb23
bb23:
  %t85 = load i64, ptr %l58, !tbaa !24
  %t86 = load i64, ptr %l60, !tbaa !24
  %t87 = icmp slt i64 %t85, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb24, label %bb25
bb24:
  br label %bb35
bb25:
  br label %bb26
bb26:
  %t91 = load ptr, ptr %l5, !tbaa !29
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s2, ptr %t91, i64 %t92)
  store i64 %t95, ptr %l65
  br label %bb27
bb27:
  %t96 = load i64, ptr %l65, !tbaa !24
  store i64 %t96, ptr %l7, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/emit:Emitter", ptr %t97, i32 0, i32 61
  %t100 = load i64, ptr %l7, !tbaa !24
  %t103 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %t99, i64 %t100)
  store i1 %t103, ptr %l69
  br label %bb28
bb28:
  %t104 = load i1, ptr %l69, !tbaa !21
  %t105 = xor i1 %t104, true
  br i1 %t105, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l4, ptr %l71, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l7, !tbaa !24
  %t110 = trunc i64 %t108 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [2 x i64] }, ptr %t112, i32 0, i32 0
  store i64 0, ptr %t113
  %t115 = insertvalue { i32 } undef, i32 %t110, 0
  %t116 = getelementptr { i64, [2 x i64] }, ptr %t112, i32 0, i32 1
  store { i32 } %t115, ptr %t116
  %t117 = load { i64, [2 x i64] }, ptr %t112
  %t120 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s4, ptr %t107, { i64, [2 x i64] } %t117)
  store { i64, ptr } %t120, ptr %l77
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t121 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t122 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t123 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = add i64 %t122, %t125
  %t127 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t121, i64 %t122)
  %t131 = getelementptr i8, ptr %t130, i64 %t122
  call void @olang_textcopy(ptr %t131, ptr %t124, i64 %t125)
  %t132 = getelementptr i8, ptr %t131, i64 %t125
  call void @olang_textcopy(ptr %t132, ptr %t127, i64 %t128)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t130, 1
  %t136 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %t136, { i64, ptr } %t134)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t138 = load i64, ptr %l6, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l6, !tbaa !24
  br label %bb22
bb35:
  call void @__olang_scope_close(ptr %s2)
  %t143 = load i64, ptr %l2, !tbaa !24
  %t145 = trunc i64 %t143 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t147
  %t148 = getelementptr { i64, [2 x i64] }, ptr %t147, i32 0, i32 0
  store i64 0, ptr %t148
  %t150 = insertvalue { i32 } undef, i32 %t145, 0
  %t151 = getelementptr { i64, [2 x i64] }, ptr %t147, i32 0, i32 1
  store { i32 } %t150, ptr %t151
  %t152 = load { i64, [2 x i64] }, ptr %t147
  store { i64, [2 x i64] } %t152, ptr %l8
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/emit:Emitter", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/lower:Lowerer", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = load i64, ptr %l2, !tbaa !24
  %t165 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t160, i64 %t162)
  store ptr %t165, ptr %l92
  br label %bb36
bb36:
  %t166 = load ptr, ptr %l92, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Body", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %t168, !tbaa !23
  %t171 = load ptr, ptr %l3, !tbaa !29
  store ptr %t171, ptr %l95, !tbaa !29
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t176 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t172, i32 %t169)
  store i32 %t176, ptr %l98
  br label %bb37
bb37:
  %t177 = load ptr, ptr %l95, !tbaa !29
  %t178 = load i32, ptr %l98, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t177, i32 %t178)
  store { i64, ptr } %t179, ptr %l99
  br label %bb38
bb38:
  %t180 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t180, ptr %l10, !tbaa !27
  %t181 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %s0, ptr %t181, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d97, i32 0, i32 1) })
  br label %bb39
bb39:
  %t183 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t187 = icmp eq i64 %t185, 0
  br i1 %t187, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l104, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t190 = load { i64, [2 x i64] }, ptr %l8
  %t193 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s7, ptr %t189, { i64, [2 x i64] } %t190)
  store { i64, ptr } %t193, ptr %l107
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t194 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t195 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t196 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = add i64 %t195, %t198
  %t200 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t202 = add i64 %t199, %t201
  %t203 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t202)
  call void @olang_textcopy(ptr %t203, ptr %t194, i64 %t195)
  %t204 = getelementptr i8, ptr %t203, i64 %t195
  call void @olang_textcopy(ptr %t204, ptr %t197, i64 %t198)
  %t205 = getelementptr i8, ptr %t204, i64 %t198
  call void @olang_textcopy(ptr %t205, ptr %t200, i64 %t201)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t203, 1
  %t209 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t209, { i64, ptr } %t207)
  br label %bb43
bb43:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l110, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/emit:Emitter", ptr %t212, i32 0, i32 0
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/load:Loader", ptr %t218, i32 0, i32 12
  %t221 = load i64, ptr %t220, !tbaa !24
  store i64 %t221, ptr %l114, !tbaa !24
  %t223 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s7, ptr %l4)
  store { i64, ptr } %t223, ptr %l116
  br label %bb44
bb44:
  %t224 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t225 = load ptr, ptr %l110, !tbaa !29
  %t226 = load i64, ptr %l114, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t225, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, i64 %t226, { i64, ptr } %t224, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  store ptr %l4, ptr %l118, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load { i64, [2 x i64] }, ptr %l8
  %t232 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %s0, ptr %t228, { i64, [2 x i64] } %t229)
  store { i64, ptr } %t232, ptr %l121
  br label %bb47
bb47:
  %t233 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t234 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t235 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 1
  %t237 = extractvalue { i64, ptr } %t235, 0
  %t238 = add i64 %t234, %t237
  %t239 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t240 = extractvalue { i64, ptr } { i64 70, ptr getelementptr inbounds (<{ i64, [70 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t241 = add i64 %t238, %t240
  %t242 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t241)
  call void @olang_textcopy(ptr %t242, ptr %t233, i64 %t234)
  %t243 = getelementptr i8, ptr %t242, i64 %t234
  call void @olang_textcopy(ptr %t243, ptr %t236, i64 %t237)
  %t244 = getelementptr i8, ptr %t243, i64 %t237
  call void @olang_textcopy(ptr %t244, ptr %t239, i64 %t240)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t242, 1
  %t248 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t248, { i64, ptr } %t246)
  br label %bb48
bb48:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 44, ptr getelementptr inbounds (<{ i64, [44 x i8] }>, ptr @.d104, i32 0, i32 1) })
  br label %bb49
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb50
bb50:
  %t252 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s0, ptr %s0, ptr %t252, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d106, i32 0, i32 1) }, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) })
  br label %bb51
bb51:
  store ptr %l4, ptr %l127, !tbaa !29
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estderrLoad(ptr %v0, ptr %s0, ptr %s0, ptr %t254, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d108, i32 0, i32 1) })
  store { i64, ptr } %t256, ptr %l129
  br label %bb52
bb52:
  %t257 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t258 = load ptr, ptr %l127, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t258, { i64, ptr } %t257)
  br label %bb53
bb53:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l131, !tbaa !27
  %t260 = load { i64, ptr }, ptr %l131, !tbaa !27
  store { i64, ptr } %t260, ptr %l11, !tbaa !27
  store ptr %l4, ptr %l133, !tbaa !29
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s0, ptr %s0, ptr %t262, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store { i64, ptr } %t264, ptr %l135
  br label %bb54
bb54:
  %t265 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t267 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t274 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t273)
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = getelementptr i8, ptr %t275, i64 %t269
  call void @olang_textcopy(ptr %t276, ptr %t271, i64 %t272)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t274, 1
  %t280 = load ptr, ptr %l133, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t280, { i64, ptr } %t278)
  br label %bb55
bb55:
  store i64 0, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  store i64 %t284, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t286 = load i64, ptr %l14, !tbaa !24
  %t287 = load i64, ptr %l13, !tbaa !24
  %t290 = icmp sgt i64 %t286, %t287
  br i1 %t290, label %bb56, label %bb57
bb56:
  %t292 = load i64, ptr %l15, !tbaa !24
  %t294 = icmp sgt i64 %t292, 0
  br i1 %t294, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb61
bb58:
  %t296 = load i64, ptr %l14, !tbaa !24
  %t297 = load i64, ptr %l13, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t301 = load i64, ptr %l15, !tbaa !24
  %t304 = add i64 %t300, %t301
  %t306 = sub i64 %t304, 1
  %t307 = load i64, ptr %l15, !tbaa !24
  %t310 = sdiv i64 %t306, %t307
  store i64 %t310, ptr %l146, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb60
bb60:
  %t312 = load i64, ptr %l146, !tbaa !24
  store i64 %t312, ptr %l143, !tbaa !24
  br label %bb61
bb61:
  %t313 = load i64, ptr %l143, !tbaa !24
  store i64 %t313, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s12
  %t314 = load i64, ptr %l17, !tbaa !24
  %t315 = load i64, ptr %l16, !tbaa !24
  %t318 = icmp slt i64 %t314, %t315
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb63, label %bb64
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb96
bb64:
  br label %bb65
bb65:
  %t322 = load i64, ptr %l13, !tbaa !24
  %t323 = load i64, ptr %l17, !tbaa !24
  %t324 = load i64, ptr %l15, !tbaa !24
  %t327 = mul i64 %t323, %t324
  %t330 = add i64 %t322, %t327
  store i64 %t330, ptr %l18, !tbaa !24
  %t332 = load ptr, ptr %l3, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t333, ptr %l165, !tbaa !27
  %t334 = load i64, ptr %l18, !tbaa !24
  %t336 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i32, ptr %t337, i64 %t334
  %t339 = load i32, ptr %t338, !tbaa !33
  %t342 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t332, i32 %t339)
  store i32 %t342, ptr %l168
  br label %bb66
bb66:
  %t343 = load i32, ptr %l168, !tbaa !23
  store i32 %t343, ptr %l19, !tbaa !23
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/emit:Emitter", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  store ptr %t347, ptr %l170, !tbaa !29
  %t348 = load ptr, ptr %l3, !tbaa !29
  %t349 = load i32, ptr %l19, !tbaa !23
  %t352 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t348, i32 %t349)
  store i32 %t352, ptr %l173
  br label %bb67
bb67:
  %t353 = load ptr, ptr %l170, !tbaa !29
  %t354 = load i32, ptr %l173, !tbaa !23
  %t355 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %s12, ptr %t353, i32 %t354)
  store { i64, ptr } %t355, ptr %l174
  br label %bb68
bb68:
  %t356 = load { i64, ptr }, ptr %l174, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t359 = extractvalue { i64, ptr } %t356, 0
  store i64 %t359, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t361 = load i64, ptr %l22, !tbaa !24
  %t362 = load i64, ptr %l21, !tbaa !24
  %t365 = icmp sgt i64 %t361, %t362
  br i1 %t365, label %bb69, label %bb70
bb69:
  %t367 = load i64, ptr %l23, !tbaa !24
  %t369 = icmp sgt i64 %t367, 0
  br i1 %t369, label %bb71, label %bb72
bb70:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb74
bb71:
  %t371 = load i64, ptr %l22, !tbaa !24
  %t372 = load i64, ptr %l21, !tbaa !24
  %t375 = sub i64 %t371, %t372
  %t376 = load i64, ptr %l23, !tbaa !24
  %t379 = add i64 %t375, %t376
  %t381 = sub i64 %t379, 1
  %t382 = load i64, ptr %l23, !tbaa !24
  %t385 = sdiv i64 %t381, %t382
  store i64 %t385, ptr %l183, !tbaa !24
  br label %bb73
bb72:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb73
bb73:
  %t387 = load i64, ptr %l183, !tbaa !24
  store i64 %t387, ptr %l180, !tbaa !24
  br label %bb74
bb74:
  %t388 = load i64, ptr %l180, !tbaa !24
  store i64 %t388, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t389 = load i64, ptr %l25, !tbaa !24
  %t390 = load i64, ptr %l24, !tbaa !24
  %t393 = icmp slt i64 %t389, %t390
  %t395 = xor i1 %t393, true
  br i1 %t395, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb77:
  br label %bb78
bb78:
  %t397 = load i64, ptr %l21, !tbaa !24
  %t398 = load i64, ptr %l25, !tbaa !24
  %t399 = load i64, ptr %l23, !tbaa !24
  %t402 = mul i64 %t398, %t399
  %t405 = add i64 %t397, %t402
  store i64 %t405, ptr %l26, !tbaa !24
  %t407 = load i64, ptr %l12, !tbaa !24
  %t410 = add i64 %t407, 1
  store i64 %t410, ptr %l12, !tbaa !24
  %t412 = load i64, ptr %l18, !tbaa !24
  %t414 = add i64 %t412, 1
  %t416 = shl i64 %t414, 16
  %t417 = load i64, ptr %l26, !tbaa !24
  %t420 = or i64 %t416, %t417
  store i64 %t420, ptr %l27, !tbaa !24
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load i32, ptr %l19, !tbaa !23
  %t426 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrQualifier(ptr %v0, ptr %s14, ptr %t422, i32 %t423)
  store { i64, ptr } %t426, ptr %l211
  br label %bb79
bb79:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/emit:Emitter", ptr %t427, i32 0, i32 0
  %t430 = load ptr, ptr %t429, !tbaa !29
  store ptr %t430, ptr %l213, !tbaa !29
  %t431 = load ptr, ptr %l3, !tbaa !29
  %t432 = load i32, ptr %l19, !tbaa !23
  %t435 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t431, i32 %t432)
  store i32 %t435, ptr %l216
  br label %bb80
bb80:
  %t436 = load i64, ptr %l26, !tbaa !24
  %t437 = load ptr, ptr %l213, !tbaa !29
  %t438 = load i32, ptr %l216, !tbaa !23
  %t440 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %s14, ptr %t437, i32 %t438, i64 %t436)
  store { i64, ptr } %t440, ptr %l218
  br label %bb81
bb81:
  %t441 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t442 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t443 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t444 = extractvalue { i64, ptr } %t443, 1
  %t445 = extractvalue { i64, ptr } %t443, 0
  %t446 = add i64 %t442, %t445
  %t447 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t454 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t453)
  call void @olang_textcopy(ptr %t454, ptr %t441, i64 %t442)
  %t455 = getelementptr i8, ptr %t454, i64 %t442
  call void @olang_textcopy(ptr %t455, ptr %t444, i64 %t445)
  %t456 = getelementptr i8, ptr %t455, i64 %t445
  call void @olang_textcopy(ptr %t456, ptr %t448, i64 %t449)
  %t457 = getelementptr i8, ptr %t456, i64 %t449
  call void @olang_textcopy(ptr %t457, ptr %t451, i64 %t452)
  %t458 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t454, 1
  store { i64, ptr } %t459, ptr %l28, !tbaa !27
  %t461 = load i64, ptr %l12, !tbaa !24
  %t462 = load i64, ptr %l27, !tbaa !24
  %t463 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t466 = call i64 @__olang_fmt_i64(ptr null, i64 %t461)
  %t467 = add i64 %t464, %t466
  %t468 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t470 = add i64 %t467, %t469
  %t472 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t473 = add i64 %t470, %t472
  %t474 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 1
  %t475 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d117, i32 0, i32 1) }, 0
  %t476 = add i64 %t473, %t475
  %t477 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t476)
  call void @olang_textcopy(ptr %t477, ptr %t463, i64 %t464)
  %t478 = getelementptr i8, ptr %t477, i64 %t464
  %t479 = call i64 @__olang_fmt_i64(ptr %t478, i64 %t461)
  %t480 = getelementptr i8, ptr %t478, i64 %t466
  call void @olang_textcopy(ptr %t480, ptr %t468, i64 %t469)
  %t481 = getelementptr i8, ptr %t480, i64 %t469
  %t482 = call i64 @__olang_fmt_i64(ptr %t481, i64 %t462)
  %t483 = getelementptr i8, ptr %t481, i64 %t472
  call void @olang_textcopy(ptr %t483, ptr %t474, i64 %t475)
  %t484 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t477, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %l4, { i64, ptr } %t485)
  br label %bb82
bb82:
  store ptr %l4, ptr %l225, !tbaa !29
  %t489 = load i64, ptr %l12, !tbaa !24
  store i64 %t489, ptr %l226, !tbaa !24
  %t490 = load i64, ptr %l12, !tbaa !24
  store i64 %t490, ptr %l227, !tbaa !24
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t495 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %s14, ptr %s14, ptr %t491, { i64, ptr } %t492)
  store { i64, ptr } %t495, ptr %l230
  br label %bb83
bb83:
  %t496 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t497 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t498 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t499 = load i64, ptr %l226, !tbaa !24
  %t500 = call i64 @__olang_fmt_i64(ptr null, i64 %t499)
  %t501 = add i64 %t498, %t500
  %t502 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = load i64, ptr %l227, !tbaa !24
  %t506 = call i64 @__olang_fmt_i64(ptr null, i64 %t505)
  %t507 = add i64 %t504, %t506
  %t508 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t509 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t510 = add i64 %t507, %t509
  %t511 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t512 = extractvalue { i64, ptr } %t511, 1
  %t513 = extractvalue { i64, ptr } %t511, 0
  %t514 = add i64 %t510, %t513
  %t515 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t516 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t517 = add i64 %t514, %t516
  %t519 = extractvalue { i64, ptr } %t496, 1
  %t520 = extractvalue { i64, ptr } %t496, 0
  %t521 = add i64 %t517, %t520
  %t522 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t524 = add i64 %t521, %t523
  %t525 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t524)
  call void @olang_textcopy(ptr %t525, ptr %t497, i64 %t498)
  %t526 = getelementptr i8, ptr %t525, i64 %t498
  %t527 = call i64 @__olang_fmt_i64(ptr %t526, i64 %t499)
  %t528 = getelementptr i8, ptr %t526, i64 %t500
  call void @olang_textcopy(ptr %t528, ptr %t502, i64 %t503)
  %t529 = getelementptr i8, ptr %t528, i64 %t503
  %t530 = call i64 @__olang_fmt_i64(ptr %t529, i64 %t505)
  %t531 = getelementptr i8, ptr %t529, i64 %t506
  call void @olang_textcopy(ptr %t531, ptr %t508, i64 %t509)
  %t532 = getelementptr i8, ptr %t531, i64 %t509
  call void @olang_textcopy(ptr %t532, ptr %t512, i64 %t513)
  %t533 = getelementptr i8, ptr %t532, i64 %t513
  call void @olang_textcopy(ptr %t533, ptr %t515, i64 %t516)
  %t534 = getelementptr i8, ptr %t533, i64 %t516
  call void @olang_textcopy(ptr %t534, ptr %t519, i64 %t520)
  %t535 = getelementptr i8, ptr %t534, i64 %t520
  call void @olang_textcopy(ptr %t535, ptr %t522, i64 %t523)
  %t536 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t525, 1
  %t539 = load ptr, ptr %l225, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s14, ptr %t539, { i64, ptr } %t537)
  br label %bb84
bb84:
  %t541 = call ptr @__olang_scope_hold(ptr %s0)
  %t542 = ptrtoint ptr %t541 to i64
  store i64 %t542, ptr %l234, !tbaa !24
  %t543 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eentry_2elocal_2e11
  br i1 %t543, label %bb85, label %bb86
bb85:
  %t545 = call ptr @__olang_region_make(ptr %s0)
  %t546 = ptrtoint ptr %t545 to i64
  store i64 %t546, ptr %l234, !tbaa !24
  br label %bb86
bb86:
  %t547 = load i64, ptr %l12, !tbaa !24
  %t548 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d122, i32 0, i32 1) }, 1
  %t549 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d122, i32 0, i32 1) }, 0
  %t551 = call i64 @__olang_fmt_i64(ptr null, i64 %t547)
  %t552 = add i64 %t549, %t551
  %t553 = load i64, ptr %l234
  %t554 = inttoptr i64 %t553 to ptr
  %t555 = call ptr @__olang_held_alloc(ptr %t554, i64 %t552)
  call void @olang_textcopy(ptr %t555, ptr %t548, i64 %t549)
  %t556 = getelementptr i8, ptr %t555, i64 %t549
  %t557 = call i64 @__olang_fmt_i64(ptr %t556, i64 %t547)
  %t558 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t559 = insertvalue { i64, ptr } %t558, ptr %t555, 1
  store { i64, ptr } %t559, ptr %l237, !tbaa !27
  %t560 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eentry_2elocal_2e11
  br i1 %t560, label %bb87, label %bb88
bb87:
  %t562 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t563 = extractvalue { i64, ptr } %t562, 0
  %t565 = icmp eq i64 %t563, 0
  br i1 %t565, label %bb89, label %bb90
bb88:
  %t567 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t567, ptr %l241, !tbaa !27
  %t568 = load { i64, ptr }, ptr %l237, !tbaa !27
  store { i64, ptr } %t568, ptr %l11, !tbaa !27
  %t569 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eentry_2elocal_2e11
  br i1 %t569, label %bb91, label %bb92
bb89:
  store { i64, ptr } zeroinitializer, ptr %l237, !tbaa !27
  br label %bb90
bb90:
  %t571 = load i64, ptr %l234
  %t572 = inttoptr i64 %t571 to ptr
  %t573 = load { i64, ptr }, ptr %l237
  %t574 = extractvalue { i64, ptr } %t573, 1
  %t575 = call ptr @__olang_region_or(ptr %t574, ptr null)
  %t576 = icmp ne ptr %t575, null
  %t577 = select i1 %t576, ptr %t575, ptr null
  call void @__olang_region_settle_in(ptr %t572, ptr %t577)
  br label %bb88
bb91:
  %t578 = load { i64, ptr }, ptr %l241
  %t579 = extractvalue { i64, ptr } %t578, 1
  call void @__olang_region_release(ptr %t579)
  store { i64, ptr } zeroinitializer, ptr %l241
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s14)
  br label %bb93
bb93:
  %t580 = load i64, ptr %l25, !tbaa !24
  %t583 = add i64 %t580, 1
  store i64 %t583, ptr %l25, !tbaa !24
  br label %bb75
bb94:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb95:
  %t585 = load i64, ptr %l17, !tbaa !24
  %t588 = add i64 %t585, 1
  store i64 %t588, ptr %l17, !tbaa !24
  br label %bb62
bb96:
  %t590 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t591 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t592 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t594 = extractvalue { i64, ptr } %t590, 1
  %t595 = extractvalue { i64, ptr } %t590, 0
  %t596 = add i64 %t592, %t595
  %t597 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t598 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t599 = add i64 %t596, %t598
  %t600 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t599)
  call void @olang_textcopy(ptr %t600, ptr %t591, i64 %t592)
  %t601 = getelementptr i8, ptr %t600, i64 %t592
  call void @olang_textcopy(ptr %t601, ptr %t594, i64 %t595)
  %t602 = getelementptr i8, ptr %t601, i64 %t595
  call void @olang_textcopy(ptr %t602, ptr %t597, i64 %t598)
  %t603 = insertvalue { i64, ptr } undef, i64 %t599, 0
  %t604 = insertvalue { i64, ptr } %t603, ptr %t600, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t604)
  br label %bb97
bb97:
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %t608)
  store i1 %t610, ptr %l254
  br label %bb98
bb98:
  %t611 = load i1, ptr %l254, !tbaa !21
  br i1 %t611, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s22
  %t612 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s22, ptr %s22, ptr %t612, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d125, i32 0, i32 1) }, { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d126, i32 0, i32 1) })
  br label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s23
  %t614 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s23, ptr %s23, ptr %t614, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d127, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d128, i32 0, i32 1) })
  br label %bb103
bb101:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s22, ptr %l4, { i64, ptr } { i64 86, ptr getelementptr inbounds (<{ i64, [86 x i8] }>, ptr @.d129, i32 0, i32 1) })
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s22)
  br label %bb105
bb103:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %l4, { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d130, i32 0, i32 1) })
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s23)
  br label %bb105
bb105:
  %t618 = load ptr, ptr %l0, !tbaa !29
  store ptr %t618, ptr %l259, !tbaa !29
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t621 = getelementptr %"compiler/emit:Emitter", ptr %t619, i32 0, i32 0
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t624 = getelementptr %"compiler/generic:Program", ptr %t622, i32 0, i32 0
  %t625 = load ptr, ptr %t624, !tbaa !29
  %t627 = getelementptr %"compiler/load:Loader", ptr %t625, i32 0, i32 12
  %t628 = load i64, ptr %t627, !tbaa !24
  store i64 %t628, ptr %l263, !tbaa !24
  %t630 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t630, ptr %l265
  br label %bb106
bb106:
  %t631 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t632 = load ptr, ptr %l259, !tbaa !29
  %t633 = load i64, ptr %l263, !tbaa !24
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t632, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d131, i32 0, i32 1) }, i64 %t633, { i64, ptr } %t631, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eextern(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %lp3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l19 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l35 = alloca i1
  %l37 = alloca %"std/prelude/text:StringBuilder"
  %l38 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i32
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l73 = alloca i1
  %l74 = alloca i1
  %l77 = alloca { i64, ptr }
  %l79 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExternSymbol(ptr %v0, ptr %v1, ptr %t4, i64 %t5)
  store { i64, ptr } %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t9, ptr %lp3
  %t10 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t11 = load ptr, ptr %lp3
  store { i64, ptr } %t10, ptr %t11, !tbaa !27
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %lp3
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !27
  %t15 = load i32, ptr %l2, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v1, ptr %t12, { i64, ptr } %t14, i32 %t15)
  store { i64, ptr } %t19, ptr %l13
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t21, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) })
  store i1 %t23, ptr %l15
  br label %bb3
bb3:
  %t24 = load i1, ptr %l15, !tbaa !21
  %t25 = xor i1 %t24, true
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t27, { i64, ptr } %t28)
  store i1 %t31, ptr %l19
  br label %bb6
bb5:
  br label %bb13
bb6:
  %t32 = load i1, ptr %l19, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l22, !tbaa !27
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %s2, ptr %t37, i32 %t38)
  store { i64, ptr } %t41, ptr %l25
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t42 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l2, !tbaa !23
  %t47 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s2, ptr %t43, i32 %t44)
  store { i64, ptr } %t47, ptr %l29
  br label %bb10
bb10:
  %t48 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t52 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t53 = add i64 %t50, %t52
  %t54 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = add i64 %t53, %t56
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t60 = add i64 %t57, %t59
  %t61 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t49, i64 %t50)
  %t69 = getelementptr i8, ptr %t68, i64 %t50
  call void @olang_textcopy(ptr %t69, ptr %t51, i64 %t52)
  %t70 = getelementptr i8, ptr %t69, i64 %t52
  call void @olang_textcopy(ptr %t70, ptr %t55, i64 %t56)
  %t71 = getelementptr i8, ptr %t70, i64 %t56
  call void @olang_textcopy(ptr %t71, ptr %t58, i64 %t59)
  %t72 = getelementptr i8, ptr %t71, i64 %t59
  call void @olang_textcopy(ptr %t72, ptr %t62, i64 %t63)
  %t73 = getelementptr i8, ptr %t72, i64 %t63
  call void @olang_textcopy(ptr %t73, ptr %t65, i64 %t66)
  %t74 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t68, 1
  %t77 = load ptr, ptr %l21, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s2, ptr %t77, { i64, ptr } %t78, { i64, ptr } %t75)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  %t80 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb13:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %lp3
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t87 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %t82, { i64, ptr } %t84)
  store i1 %t87, ptr %l35
  br label %bb14
bb14:
  %t88 = load i1, ptr %l35, !tbaa !21
  br i1 %t88, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %lp3
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t90, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t92 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t92, ptr %l37
  br label %bb18
bb18:
  %t93 = load %"std/prelude/text:StringBuilder", ptr %l37
  store %"std/prelude/text:StringBuilder" %t93, ptr %l5
  store ptr %l5, ptr %l38, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %s0, ptr %t94, i32 %t95)
  store { i64, ptr } %t98, ptr %l41
  br label %bb19
bb19:
  %t99 = load ptr, ptr %lp3
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t108 = extractvalue { i64, ptr } %t100, 1
  %t109 = extractvalue { i64, ptr } %t100, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t102, i64 %t103)
  %t115 = getelementptr i8, ptr %t114, i64 %t103
  call void @olang_textcopy(ptr %t115, ptr %t104, i64 %t105)
  %t116 = getelementptr i8, ptr %t115, i64 %t105
  call void @olang_textcopy(ptr %t116, ptr %t108, i64 %t109)
  %t117 = getelementptr i8, ptr %t116, i64 %t109
  call void @olang_textcopy(ptr %t117, ptr %t111, i64 %t112)
  %t118 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t114, 1
  %t121 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t121, { i64, ptr } %t119)
  br label %bb20
bb20:
  store ptr %l5, ptr %l45, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l46, !tbaa !29
  %t124 = load i32, ptr %l2, !tbaa !23
  store i32 %t124, ptr %l47, !tbaa !23
  %t125 = load ptr, ptr %lp3
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t126, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i1 %t128, ptr %l49
  br label %bb21
bb21:
  %t129 = load ptr, ptr %l46, !tbaa !29
  %t130 = load i32, ptr %l47, !tbaa !23
  %t131 = load i1, ptr %l49, !tbaa !21
  %t132 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamList(ptr %v0, ptr %s0, ptr %t129, i32 %t130, i1 %t131)
  store { i64, ptr } %t132, ptr %l50
  br label %bb22
bb22:
  %t133 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t134 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t134, { i64, ptr } %t133)
  br label %bb23
bb23:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/emit:Emitter", ptr %t136, i32 0, i32 0
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  %t143 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t139, i64 %t140)
  store ptr %t143, ptr %l55
  br label %bb24
bb24:
  %t144 = load ptr, ptr %l55, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Func", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/ast:Sig", ptr %t147, i32 0, i32 6
  %t150 = load i1, ptr %t149, !tbaa !21
  br i1 %t150, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  store ptr %l5, ptr %l59, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/emit:Emitter", ptr %t152, i32 0, i32 3
  %t155 = load ptr, ptr %t154, !tbaa !29
  store ptr %t155, ptr %l61, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/emit:Emitter", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i32, ptr %l2, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l65
  br label %bb27
bb26:
  br label %bb33
bb27:
  %t164 = load ptr, ptr %l61, !tbaa !29
  %t165 = load i32, ptr %l65, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s6, ptr %t164, i32 %t165)
  store { i64, ptr } %t166, ptr %l66
  br label %bb28
bb28:
  %t167 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t170 = icmp sgt i64 %t168, 0
  br i1 %t170, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d139, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d140, i32 0, i32 1) }, ptr %l69, !tbaa !27
  br label %bb31
bb31:
  %t172 = load ptr, ptr %l59, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l69, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t172, { i64, ptr } %t173)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l5, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d141, i32 0, i32 1) })
  br label %bb34
bb34:
  %t175 = load ptr, ptr %lp3
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t177 = load ptr, ptr @__olang_prog_scope
  %t180 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %t177, ptr %v1, ptr @G_2ecompiler_2femit_2emathInexact, { i64, ptr } %t176)
  store i1 %t180, ptr %l73
  br label %bb35
bb35:
  %t181 = load i1, ptr %l73, !tbaa !21
  br i1 %t181, label %bb36, label %bb37
bb36:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l2, !tbaa !23
  %t186 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %s0, ptr %t182, i32 %t183)
  store { i64, ptr } %t186, ptr %l77
  br label %bb38
bb37:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb40
bb38:
  %t187 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t189 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t187, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) })
  store i1 %t189, ptr %l79
  br label %bb39
bb39:
  %t190 = load i1, ptr %l79, !tbaa !21
  %t191 = xor i1 %t190, true
  store i1 %t191, ptr %l74, !tbaa !21
  br label %bb40
bb40:
  %t193 = load i1, ptr %l74, !tbaa !21
  br i1 %t193, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %l5, { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d143, i32 0, i32 1) })
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l82, !tbaa !29
  %t196 = load ptr, ptr %lp3
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l83, !tbaa !27
  %t199 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t199, ptr %l85
  br label %bb45
bb45:
  %t200 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t201 = load ptr, ptr %l82, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l83, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %s0, ptr %t201, { i64, ptr } %t202, { i64, ptr } %t200)
  br label %bb46
bb46:
  %t204 = load ptr, ptr %lp3
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t205, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2efieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l67 = alloca i32
  %l73 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca ptr
  %l81 = alloca i1
  %l88 = alloca ptr
  %l89 = alloca i1
  %l105 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca i1
  %l113 = alloca i1
  %l135 = alloca { i64, ptr }
  %l141 = alloca i64
  %l142 = alloca i64
  %l146 = alloca { i64, ptr }
  %s13 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t11 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l26, !tbaa !24
  %t2 = load i64, ptr %l26, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l26, !tbaa !24
  %t6 = icmp sle i64 %t5, 576460752303423487
  br i1 %t6, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_672626b841abebed_e9d6bd273cfd5371)
  unreachable
bb3:
  %t8 = load i64, ptr %l26, !tbaa !24
  %t9 = mul i64 %t8, 16
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  store i64 0, ptr %t11
  br label %fill.12
fill.12:
  %t15 = load i64, ptr %t11
  %t16 = icmp slt i64 %t15, %t8
  br i1 %t16, label %fillb.13, label %filld.14
fillb.13:
  %t17 = getelementptr { i64, ptr }, ptr %t10, i64 %t15
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %t17
  %t18 = add i64 %t15, 1
  store i64 %t18, ptr %t11
  br label %fill.12
filld.14:
  %t19 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t10, 1
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = icmp sgt i64 %t24, %t25
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_672626b841abebed_e9d6bd273cfd5371)
  unreachable
bb5:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp sgt i64 %t30, 0
  br i1 %t32, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb10
bb7:
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = sub i64 %t34, %t35
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = add i64 %t38, %t39
  %t44 = sub i64 %t42, 1
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = sdiv i64 %t44, %t45
  store i64 %t48, ptr %l37, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb9
bb9:
  %t50 = load i64, ptr %l37, !tbaa !24
  store i64 %t50, ptr %l34, !tbaa !24
  br label %bb10
bb10:
  %t51 = load i64, ptr %l34, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t52 = load i64, ptr %l8, !tbaa !24
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = icmp slt i64 %t52, %t53
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb12, label %bb13
bb12:
  br label %bb18
bb13:
  br label %bb14
bb14:
  %t60 = load i64, ptr %l4, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = mul i64 %t61, %t62
  %t68 = add i64 %t60, %t65
  store i64 %t68, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  store i64 %t70, ptr %l55, !tbaa !24
  %t71 = call ptr @__olang_scope_hold(ptr %v1)
  %t72 = ptrtoint ptr %t71 to i64
  store i64 %t72, ptr %l56, !tbaa !24
  %t73 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t73, label %bb15, label %bb16
bb15:
  %t75 = call ptr @__olang_region_make(ptr %v1)
  %t76 = ptrtoint ptr %t75 to i64
  store i64 %t76, ptr %l56, !tbaa !24
  br label %bb16
bb16:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = call i64 @__olang_fmt_i64(ptr null, i64 %t77)
  %t80 = load i64, ptr %l56
  %t81 = inttoptr i64 %t80 to ptr
  %t82 = call ptr @__olang_held_alloc(ptr %t81, i64 %t79)
  %t83 = call i64 @__olang_fmt_i64(ptr %t82, i64 %t77)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t88 = load i64, ptr %l55, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %t90, i64 %t88
  store { i64, ptr } %t85, ptr %t91, !tbaa !37
  br label %bb17
bb17:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t95 = add i64 %t92, 1
  store i64 %t95, ptr %l8, !tbaa !24
  br label %bb11
bb18:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/emit:Emitter", ptr %t97, i32 0, i32 3
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t101 = load i32, ptr %l1, !tbaa !23
  %t104 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t100, i32 %t101)
  store i32 %t104, ptr %l67
  br label %bb19
bb19:
  %t105 = load i32, ptr %l67, !range !{i32 0, i32 33}
  %t107 = trunc i64 18 to i32
  %t108 = icmp eq i32 %t105, %t107
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb20, label %bb21
bb20:
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t112, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/emit:Emitter", ptr %t114, i32 0, i32 0
  %t117 = load ptr, ptr %t116, !tbaa !29
  store ptr %t117, ptr %l73, !tbaa !29
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/emit:Emitter", ptr %t118, i32 0, i32 3
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i32, ptr %l1, !tbaa !23
  %t125 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t121, i32 %t122)
  store i32 %t125, ptr %l77
  br label %bb23
bb23:
  %t126 = load ptr, ptr %l73, !tbaa !29
  %t127 = load i32, ptr %l77, !tbaa !23
  %t128 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t126, i32 %t127)
  store ptr %t128, ptr %l78
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l78, !tbaa !29
  store ptr %t129, ptr %l10, !tbaa !29
  %t130 = load ptr, ptr %l10, !tbaa !29
  %t132 = icmp eq ptr %t130, null
  br i1 %t132, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l81, !tbaa !21
  br label %bb27
bb26:
  %t134 = load ptr, ptr %l10, !tbaa !29
  %t136 = getelementptr %"compiler/ast:TypeDecl", ptr %t134, i32 0, i32 3
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  store i1 %t139, ptr %l81, !tbaa !21
  br label %bb27
bb27:
  %t141 = load i1, ptr %l81, !tbaa !21
  br i1 %t141, label %bb28, label %bb29
bb28:
  %t142 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t142, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:TypeDecl", ptr %t144, i32 0, i32 3
  %t147 = load ptr, ptr %t146, !tbaa !29
  store ptr %t147, ptr %l11, !tbaa !29
  %t149 = load ptr, ptr %l11, !tbaa !29
  store ptr %t149, ptr %l88, !tbaa !29
  store i1 false, ptr %l89, !tbaa !21
  %t150 = load ptr, ptr %l88, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb31, label %bb32
bb31:
  %t153 = load ptr, ptr %l88, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 5}
  %t156 = icmp eq i64 %t154, 0
  store i1 %t156, ptr %l89, !tbaa !21
  br label %bb32
bb32:
  %t157 = load i1, ptr %l89, !tbaa !21
  %t158 = xor i1 %t157, true
  br i1 %t158, label %bb33, label %bb34
bb33:
  %t160 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t160, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  %t162 = load ptr, ptr %l11, !tbaa !29
  %t164 = getelementptr { i64, [6 x i64] }, ptr %t162, i32 0, i32 1
  %t165 = getelementptr { ptr }, ptr %t164, i32 0, i32 0
  %t166 = load ptr, ptr %t165
  store i64 0, ptr %l13, !tbaa !24
  %t171 = getelementptr %"compiler/ast:StructBody", ptr %t166, i32 0, i32 2
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t174 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  store i64 %t176, ptr %l16, !tbaa !24
  br label %bb36
bb36:
  %t178 = load i64, ptr %l15, !tbaa !24
  %t179 = load i64, ptr %l16, !tbaa !24
  %t182 = icmp slt i64 %t178, %t179
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb37, label %bb38
bb37:
  br label %bb61
bb38:
  br label %bb39
bb39:
  %t186 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t186, ptr %l105, !tbaa !27
  %t187 = load i64, ptr %l15, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr ptr, ptr %t190, i64 %t187
  %t192 = load ptr, ptr %t191, !tbaa !39
  store ptr %t192, ptr %l17, !tbaa !29
  %t194 = load ptr, ptr %l17, !tbaa !29
  store ptr %t194, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t195 = load ptr, ptr %l108, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb40, label %bb41
bb40:
  %t198 = load ptr, ptr %l108, !tbaa !29
  %t199 = load i64, ptr %t198, !range !{i64 0, i64 22}
  %t201 = icmp eq i64 %t199, 1
  store i1 %t201, ptr %l109, !tbaa !21
  br label %bb41
bb41:
  %t202 = load i1, ptr %l109, !tbaa !21
  %t203 = xor i1 %t202, true
  br i1 %t203, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l113, !tbaa !21
  br label %bb44
bb43:
  %t205 = load ptr, ptr %l17, !tbaa !29
  %t207 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", ptr }, ptr %t207, i32 0, i32 0
  %t209 = load %"compiler/source:Span", ptr %t208
  store %"compiler/source:Span" %t209, ptr %l18
  %t211 = load ptr, ptr %l17, !tbaa !29
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  %t214 = getelementptr { %"compiler/source:Span", ptr }, ptr %t213, i32 0, i32 1
  %t215 = load ptr, ptr %t214
  %t220 = getelementptr %"compiler/ast:VarDecl", ptr %t215, i32 0, i32 5
  %t221 = load i1, ptr %t220, !tbaa !21
  %t223 = xor i1 %t221, true
  store i1 %t223, ptr %l113, !tbaa !21
  br label %bb44
bb44:
  %t225 = load i1, ptr %l113, !tbaa !21
  br i1 %t225, label %bb45, label %bb46
bb45:
  br label %bb60
bb46:
  br label %bb47
bb47:
  %t226 = load ptr, ptr %l17, !tbaa !29
  %t228 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr }, ptr %t228, i32 0, i32 0
  %t230 = load %"compiler/source:Span", ptr %t229
  store %"compiler/source:Span" %t230, ptr %l20
  %t232 = load ptr, ptr %l17, !tbaa !29
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t232, i32 0, i32 1
  %t235 = getelementptr { %"compiler/source:Span", ptr }, ptr %t234, i32 0, i32 1
  %t236 = load ptr, ptr %t235
  %t241 = getelementptr %"compiler/ast:VarDecl", ptr %t236, i32 0, i32 0
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l24, !tbaa !24
  br label %bb48
bb48:
  %t248 = load i64, ptr %l23, !tbaa !24
  %t249 = load i64, ptr %l24, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb49, label %bb50
bb49:
  br label %bb59
bb50:
  br label %bb51
bb51:
  %t256 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t256, ptr %l135, !tbaa !27
  %t257 = load i64, ptr %l23, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr i32, ptr %t260, i64 %t257
  %t262 = load i32, ptr %t261, !tbaa !33
  store i32 %t262, ptr %l25, !tbaa !23
  %t264 = load i64, ptr %l13, !tbaa !24
  %t265 = load i64, ptr %l2, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  br i1 %t268, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s13
  %t270 = load i64, ptr %l13, !tbaa !24
  store i64 %t270, ptr %l141, !tbaa !24
  %t271 = call ptr @__olang_scope_hold(ptr %v1)
  %t272 = ptrtoint ptr %t271 to i64
  store i64 %t272, ptr %l142, !tbaa !24
  %t273 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t273, label %bb54, label %bb55
bb53:
  br label %bb57
bb54:
  %t275 = call ptr @__olang_region_make(ptr %v1)
  %t276 = ptrtoint ptr %t275 to i64
  store i64 %t276, ptr %l142, !tbaa !24
  br label %bb55
bb55:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i32, ptr %l25, !tbaa !23
  %t281 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %s13, ptr %t277, i32 %t278)
  store { i64, ptr } %t281, ptr %l146
  br label %bb56
bb56:
  %t282 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = load i64, ptr %l142
  %t286 = inttoptr i64 %t285 to ptr
  %t287 = call ptr @__olang_held_alloc(ptr %t286, i64 %t284)
  call void @olang_textcopy(ptr %t287, ptr %t283, i64 %t284)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  %t292 = load i64, ptr %l141, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr { i64, ptr }, ptr %t294, i64 %t292
  store { i64, ptr } %t289, ptr %t295, !tbaa !37
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb57:
  %t296 = load i64, ptr %l13, !tbaa !24
  %t299 = add i64 %t296, 1
  store i64 %t299, ptr %l13, !tbaa !24
  br label %bb58
bb58:
  %t301 = load i64, ptr %l23, !tbaa !24
  %t304 = add i64 %t301, 1
  store i64 %t304, ptr %l23, !tbaa !24
  br label %bb48
bb59:
  br label %bb60
bb60:
  %t306 = load i64, ptr %l15, !tbaa !24
  %t309 = add i64 %t306, 1
  store i64 %t309, ptr %l15, !tbaa !24
  br label %bb36
bb61:
  %t311 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t311, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBuf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBufName(ptr %v0, ptr %v1, ptr %t1, i64 %a1, i32 %a2)
  store { i64, ptr } %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = extractvalue { i64, ptr } %t12, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = getelementptr i8, ptr %t23, i64 %t17
  call void @olang_textcopy(ptr %t24, ptr %t19, i64 %t20)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t22, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } %t10, i64 %t11, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb2
bb2:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBufOn(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t19 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHasLeaves(ptr %v0, ptr %v0, ptr %t12, ptr %t14, i32 %a1)
  store i1 %t19, ptr %l12
  br label %bb2
bb2:
  %t20 = load i1, ptr %l12, !tbaa !21
  store i1 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOk(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOkName(ptr %v0, ptr %v1, ptr %t1, i64 %a1, i32 %a2)
  store { i64, ptr } %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t11 = load i64, ptr @G_2ecompiler_2femit_2eHomeShared, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t13 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = extractvalue { i64, ptr } %t12, 0
  %t18 = add i64 %t14, %t17
  %t19 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d148, i32 0, i32 1) }, 1
  %t20 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d148, i32 0, i32 1) }, 0
  %t21 = add i64 %t18, %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @olang_textcopy(ptr %t22, ptr %t13, i64 %t14)
  %t23 = getelementptr i8, ptr %t22, i64 %t14
  call void @olang_textcopy(ptr %t23, ptr %t16, i64 %t17)
  %t24 = getelementptr i8, ptr %t23, i64 %t17
  call void @olang_textcopy(ptr %t24, ptr %t19, i64 %t20)
  %t25 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t22, 1
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } %t10, i64 %t11, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  br label %bb2
bb2:
  %t32 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenRef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t4)
  store ptr %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t15 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eGenRef(ptr %v0, ptr %v0, ptr %t12, ptr %t10, i32 %a1)
  store i1 %t15, ptr %l8
  br label %bb2
bb2:
  %t16 = load i1, ptr %l8, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i32
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l42 = alloca i1
  %l49 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l66 = alloca ptr
  %l70 = alloca i64
  %l72 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 -1, ptr %l2, !tbaa !24
  store i1 false, ptr %l3, !tbaa !21
  %t1 = load { i64, [2 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i32 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t10 = load i32, ptr %l4, !tbaa !23
  %t12 = sext i32 %t10 to i64
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb13
bb4:
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { i32 }, ptr %t19, i32 0, i32 0
  %t21 = load i32, ptr %t20
  store i32 %t21, ptr %l5, !tbaa !23
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t23 = load i32, ptr %l5, !tbaa !23
  %t25 = sext i32 %t23 to i64
  store i64 %t25, ptr %l2, !tbaa !24
  store i1 true, ptr %l3, !tbaa !21
  br label %bb13
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf)
  unreachable
bb13:
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp slt i64 %t27, 0
  br i1 %t29, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb17
bb15:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  %t35 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i1, ptr %l25, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, [2 x i64] }, ptr %l1
  %t44 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %t40, { i64, [2 x i64] } %t41)
  store { i64, ptr } %t44, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
bb21:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/emit:Emitter", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/lower:Lowerer", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = load i64, ptr %l2, !tbaa !24
  %t57 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t52, i64 %t54)
  store ptr %t57, ptr %l35
  br label %bb22
bb22:
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 4
  %t61 = getelementptr %"compiler/source:Span", ptr %t60, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t64 = sext i32 %t62 to i64
  store i64 %t64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l2, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb23
bb23:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %t68, i64 %t69)
  store i1 %t72, ptr %l42
  br label %bb24
bb24:
  %t73 = load i1, ptr %l42, !tbaa !21
  %t74 = xor i1 %t73, true
  br i1 %t74, label %bb25, label %bb26
bb25:
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/emit:Emitter", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/lower:Lowerer", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t82, i64 %t84)
  store ptr %t87, ptr %l49
  br label %bb28
bb28:
  %t88 = load ptr, ptr %l49, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 1
  %t91 = load { i64, [2 x i64] }, ptr %t90
  store { i64, [2 x i64] } %t91, ptr %l8
  %t93 = load { i64, [2 x i64] }, ptr %l8
  %t95 = extractvalue { i64, [2 x i64] } %t93, 0
  %t96 = icmp eq i64 %t95, 4
  br i1 %t96, label %bb29, label %bb30
bb29:
  %t98 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t99 = getelementptr { i32 }, ptr %t98, i32 0, i32 0
  %t100 = load i32, ptr %t99
  store i32 %t100, ptr %l9, !tbaa !23
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t102 = load i32, ptr %l9, !tbaa !23
  %t104 = sext i32 %t102 to i64
  store i64 %t104, ptr %l7, !tbaa !24
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb39
bb36:
  call void @__olang_check_failed(ptr @olang_loc_dd4469a9ae312a3a_602f574df5758ebe)
  unreachable
bb37:
  br label %bb38
bb38:
  br label %bb23
bb39:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l7, !tbaa !24
  %t110 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ebodySym(ptr %v0, ptr %s0, ptr %t106, i64 %t107)
  store { i64, ptr } %t110, ptr %l59
  br label %bb40
bb40:
  %t111 = load i64, ptr %l6, !tbaa !24
  store i64 %t111, ptr %l60, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/emit:Emitter", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/lower:Lowerer", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t118, i64 %t120)
  store ptr %t123, ptr %l66
  br label %bb41
bb41:
  %t124 = load ptr, ptr %l66, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 4
  %t127 = getelementptr %"compiler/source:Span", ptr %t126, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t131 = load i64, ptr %l60, !tbaa !24
  %t133 = sub i64 %t131, %t130
  store i64 %t133, ptr %l70, !tbaa !24
  %t134 = load i1, ptr %l3, !tbaa !21
  br i1 %t134, label %bb42, label %bb43
bb42:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb44
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l72, !tbaa !27
  br label %bb44
bb44:
  %t136 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = load i64, ptr %l70, !tbaa !24
  %t143 = call i64 @__olang_fmt_i64(ptr null, i64 %t142)
  %t144 = add i64 %t141, %t143
  %t145 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = add i64 %t144, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t137, i64 %t138)
  %t150 = getelementptr i8, ptr %t149, i64 %t138
  call void @olang_textcopy(ptr %t150, ptr %t139, i64 %t140)
  %t151 = getelementptr i8, ptr %t150, i64 %t140
  %t152 = call i64 @__olang_fmt_i64(ptr %t151, i64 %t142)
  %t153 = getelementptr i8, ptr %t151, i64 %t143
  call void @olang_textcopy(ptr %t153, ptr %t146, i64 %t147)
  %t154 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t149, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t155, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathParams(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca i32
  %l33 = alloca i1
  %l36 = alloca i32
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load %"std/prelude/text:StringBuilder", ptr %l11
  store %"std/prelude/text:StringBuilder" %t7, ptr %l3
  %t8 = load ptr, ptr %l2, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l15
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l16
  br label %bb3
bb3:
  %t17 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb6:
  br label %bb7
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  store i64 %t30, ptr %l7, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t32, ptr %l24, !tbaa !27
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr i32, ptr %t36, i64 %t33
  %t38 = load i32, ptr %t37, !tbaa !33
  store i32 %t38, ptr %l8, !tbaa !23
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i32, ptr %l8, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l29
  br label %bb8
bb8:
  %t45 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t47 = trunc i64 13 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb9, label %bb10
bb9:
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t53 = load i32, ptr %l8, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l36
  br label %bb11
bb10:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb12
bb11:
  %t57 = load i32, ptr %l36, !range !{i32 0, i32 33}
  %t59 = trunc i64 14 to i32
  %t60 = icmp eq i32 %t57, %t59
  %t62 = xor i1 %t60, true
  store i1 %t62, ptr %l33, !tbaa !21
  br label %bb12
bb12:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t65, ptr %l41, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t66, 0
  store i64 %t67, ptr %l42, !tbaa !24
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l43, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l42, !tbaa !24
  %t78 = mul i64 %t77, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t74, ptr %t76, i64 %t78, i1 false)
  %t79 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t79, ptr %l41, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = icmp sgt i64 %t81, 0
  br i1 %t83, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d153, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb19:
  store ptr %l3, ptr %l47, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l8, !tbaa !23
  %t90 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %s2, ptr %t86, i32 %t87)
  store { i64, ptr } %t90, ptr %l50
  br label %bb20
bb20:
  %t91 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t92 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t92, { i64, ptr } %t91)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = add i64 %t94, 1
  store i64 %t97, ptr %l5, !tbaa !24
  br label %bb4
bb23:
  %t100 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l3)
  store { i64, ptr } %t100, ptr %l56
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t101 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t101, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l8 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = bitcast double 0x3ff0000000000000 to i64
  %t6 = shl i64 %a1, 52
  %t9 = add i64 %t2, %t6
  %t12 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 14, i64 %t9)
  store { i64, ptr } %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2erecodeText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l18 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l31 = alloca i64
  %l34 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l70 = alloca i64
  %l73 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t4, i32 %a3)
  store { i64, ptr } %t10, ptr %l18
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t16 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t18 = extractvalue { i64, ptr } %t13, 1
  %t19 = extractvalue { i64, ptr } %t13, 0
  %t20 = add i64 %t16, %t19
  %t21 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t22 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t23 = add i64 %t20, %t22
  %t25 = extractvalue { i64, ptr } %t14, 1
  %t26 = extractvalue { i64, ptr } %t14, 0
  %t27 = add i64 %t23, %t26
  %t28 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t15, i64 %t16)
  %t32 = getelementptr i8, ptr %t31, i64 %t16
  call void @olang_textcopy(ptr %t32, ptr %t18, i64 %t19)
  %t33 = getelementptr i8, ptr %t32, i64 %t19
  call void @olang_textcopy(ptr %t33, ptr %t21, i64 %t22)
  %t34 = getelementptr i8, ptr %t33, i64 %t22
  call void @olang_textcopy(ptr %t34, ptr %t25, i64 %t26)
  %t35 = getelementptr i8, ptr %t34, i64 %t26
  call void @olang_textcopy(ptr %t35, ptr %t28, i64 %t29)
  %t36 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t31, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t12, { i64, ptr } %t37)
  br label %bb2
bb2:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d157, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb3, label %bb4
bb3:
  %t53 = load i64, ptr %l10, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb8
bb5:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = sub i64 %t57, %t58
  %t62 = load i64, ptr %l10, !tbaa !24
  %t65 = add i64 %t61, %t62
  %t67 = sub i64 %t65, 1
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = sdiv i64 %t67, %t68
  store i64 %t71, ptr %l34, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb7
bb7:
  %t73 = load i64, ptr %l34, !tbaa !24
  store i64 %t73, ptr %l31, !tbaa !24
  br label %bb8
bb8:
  %t74 = load i64, ptr %l31, !tbaa !24
  store i64 %t74, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load i64, ptr %l12, !tbaa !24
  %t76 = load i64, ptr %l11, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t84 = load i64, ptr %l12, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = mul i64 %t84, %t85
  %t91 = add i64 %t83, %t88
  store i64 %t91, ptr %l13, !tbaa !24
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load i64, ptr %l13, !tbaa !24
  %t95 = load i64, ptr %l13, !tbaa !24
  %t97 = add i64 %t95, 1
  %t98 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t101 = call i64 @__olang_fmt_i64(ptr null, i64 %t94)
  %t102 = add i64 %t99, %t101
  %t103 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t104 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t105 = add i64 %t102, %t104
  %t107 = call i64 @__olang_fmt_i64(ptr null, i64 %t97)
  %t108 = add i64 %t105, %t107
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t112 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t111)
  call void @olang_textcopy(ptr %t112, ptr %t98, i64 %t99)
  %t113 = getelementptr i8, ptr %t112, i64 %t99
  %t114 = call i64 @__olang_fmt_i64(ptr %t113, i64 %t94)
  %t115 = getelementptr i8, ptr %t113, i64 %t101
  call void @olang_textcopy(ptr %t115, ptr %t103, i64 %t104)
  %t116 = getelementptr i8, ptr %t115, i64 %t104
  %t117 = call i64 @__olang_fmt_i64(ptr %t116, i64 %t97)
  %t118 = getelementptr i8, ptr %t116, i64 %t107
  call void @olang_textcopy(ptr %t118, ptr %t109, i64 %t110)
  %t119 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t112, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t93, { i64, ptr } %t120)
  br label %bb13
bb13:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l58, !tbaa !29
  %t125 = load i64, ptr %l13, !tbaa !24
  store i64 %t125, ptr %l59, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  store i64 %t126, ptr %l60, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t129, ptr %l63, !tbaa !27
  %t130 = load i64, ptr %l13, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i32, ptr %t133, i64 %t130
  %t135 = load i32, ptr %t134, !tbaa !33
  %t139 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %t127, i32 %a4, i32 %t135)
  store i64 %t139, ptr %l66
  br label %bb14
bb14:
  %t140 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t141 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t143 = load i64, ptr %l59, !tbaa !24
  %t144 = call i64 @__olang_fmt_i64(ptr null, i64 %t143)
  %t145 = add i64 %t142, %t144
  %t146 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t147 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t148 = add i64 %t145, %t147
  %t149 = load i64, ptr %l60, !tbaa !24
  %t150 = call i64 @__olang_fmt_i64(ptr null, i64 %t149)
  %t151 = add i64 %t148, %t150
  %t152 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t153 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t154 = add i64 %t151, %t153
  %t155 = load i64, ptr %l66, !tbaa !24
  %t156 = call i64 @__olang_fmt_i64(ptr null, i64 %t155)
  %t157 = add i64 %t154, %t156
  %t158 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t159 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t160 = add i64 %t157, %t159
  %t162 = extractvalue { i64, ptr } %t140, 1
  %t163 = extractvalue { i64, ptr } %t140, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t141, i64 %t142)
  %t169 = getelementptr i8, ptr %t168, i64 %t142
  %t170 = call i64 @__olang_fmt_i64(ptr %t169, i64 %t143)
  %t171 = getelementptr i8, ptr %t169, i64 %t144
  call void @olang_textcopy(ptr %t171, ptr %t146, i64 %t147)
  %t172 = getelementptr i8, ptr %t171, i64 %t147
  %t173 = call i64 @__olang_fmt_i64(ptr %t172, i64 %t149)
  %t174 = getelementptr i8, ptr %t172, i64 %t150
  call void @olang_textcopy(ptr %t174, ptr %t152, i64 %t153)
  %t175 = getelementptr i8, ptr %t174, i64 %t153
  %t176 = call i64 @__olang_fmt_i64(ptr %t175, i64 %t155)
  %t177 = getelementptr i8, ptr %t175, i64 %t156
  call void @olang_textcopy(ptr %t177, ptr %t158, i64 %t159)
  %t178 = getelementptr i8, ptr %t177, i64 %t159
  call void @olang_textcopy(ptr %t178, ptr %t162, i64 %t163)
  %t179 = getelementptr i8, ptr %t178, i64 %t163
  call void @olang_textcopy(ptr %t179, ptr %t165, i64 %t166)
  %t180 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t168, 1
  %t183 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t183, { i64, ptr } %t181)
  br label %bb15
bb15:
  %t185 = call ptr @__olang_scope_hold(ptr %s0)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l70, !tbaa !24
  %t187 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2erecodeText_2elocal_2e7
  br i1 %t187, label %bb16, label %bb17
bb16:
  %t189 = call ptr @__olang_region_make(ptr %s0)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l70, !tbaa !24
  br label %bb17
bb17:
  %t191 = load i64, ptr %l13, !tbaa !24
  %t192 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t193 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t195 = call i64 @__olang_fmt_i64(ptr null, i64 %t191)
  %t196 = add i64 %t193, %t195
  %t197 = load i64, ptr %l70
  %t198 = inttoptr i64 %t197 to ptr
  %t199 = call ptr @__olang_held_alloc(ptr %t198, i64 %t196)
  call void @olang_textcopy(ptr %t199, ptr %t192, i64 %t193)
  %t200 = getelementptr i8, ptr %t199, i64 %t193
  %t201 = call i64 @__olang_fmt_i64(ptr %t200, i64 %t191)
  %t202 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t199, 1
  store { i64, ptr } %t203, ptr %l73, !tbaa !27
  %t204 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2erecodeText_2elocal_2e7
  br i1 %t204, label %bb18, label %bb19
bb18:
  %t206 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t209 = icmp eq i64 %t207, 0
  br i1 %t209, label %bb20, label %bb21
bb19:
  %t211 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t211, ptr %l77, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t212, ptr %l7, !tbaa !27
  %t213 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2erecodeText_2elocal_2e7
  br i1 %t213, label %bb22, label %bb23
bb20:
  store { i64, ptr } zeroinitializer, ptr %l73, !tbaa !27
  br label %bb21
bb21:
  %t215 = load i64, ptr %l70
  %t216 = inttoptr i64 %t215 to ptr
  %t217 = load { i64, ptr }, ptr %l73
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = call ptr @__olang_region_or(ptr %t218, ptr null)
  %t220 = icmp ne ptr %t219, null
  %t221 = select i1 %t220, ptr %t219, ptr null
  call void @__olang_region_settle_in(ptr %t216, ptr %t221)
  br label %bb19
bb22:
  %t222 = load { i64, ptr }, ptr %l77
  %t223 = extractvalue { i64, ptr } %t222, 1
  call void @__olang_region_release(ptr %t223)
  store { i64, ptr } zeroinitializer, ptr %l77
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t224 = load i64, ptr %l12, !tbaa !24
  %t227 = add i64 %t224, 1
  store i64 %t227, ptr %l12, !tbaa !24
  br label %bb9
bb25:
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t230 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t231 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t234 = extractvalue { i64, ptr } %t230, 1
  %t235 = extractvalue { i64, ptr } %t230, 0
  %t236 = add i64 %t232, %t235
  %t237 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d167, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t231, i64 %t232)
  %t241 = getelementptr i8, ptr %t240, i64 %t232
  call void @olang_textcopy(ptr %t241, ptr %t234, i64 %t235)
  %t242 = getelementptr i8, ptr %t241, i64 %t235
  call void @olang_textcopy(ptr %t242, ptr %t237, i64 %t238)
  %t243 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t244 = insertvalue { i64, ptr } %t243, ptr %t240, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t229, { i64, ptr } %t244)
  br label %bb26
bb26:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d168, i32 0, i32 1) }, ptr %l86, !tbaa !27
  %t248 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t248, ptr %l87, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 0
  store i64 %t250, ptr %l88, !tbaa !24
  %t251 = load i64, ptr %l88, !tbaa !24
  %t252 = mul i64 %t251, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t252)
  %t254 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  store { i64, ptr } %t255, ptr %l89, !tbaa !27
  %t256 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = load i64, ptr %l88, !tbaa !24
  %t261 = mul i64 %t260, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t257, ptr %t259, i64 %t261, i1 false)
  %t262 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t262, ptr %l87, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t263 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t263, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2estderrLoad(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 31
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d169, i32 0, i32 1) })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %s1, ptr %s1, ptr %t8, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d170, i32 0, i32 1) }, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d171, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t11 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t14 = extractvalue { i64, ptr } %t10, 1
  %t15 = extractvalue { i64, ptr } %t10, 0
  %t16 = add i64 %t12, %t15
  %t17 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d173, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d173, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t11, i64 %t12)
  %t21 = getelementptr i8, ptr %t20, i64 %t12
  call void @olang_textcopy(ptr %t21, ptr %t14, i64 %t15)
  %t22 = getelementptr i8, ptr %t21, i64 %t15
  call void @olang_textcopy(ptr %t22, ptr %t17, i64 %t18)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t20, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t24, ptr %rv
  br label %ret
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %s0, ptr %s0, ptr %t26, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d174, i32 0, i32 1) }, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb6
bb6:
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t29 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %t28, 1
  %t33 = extractvalue { i64, ptr } %t28, 0
  %t34 = add i64 %t30, %t33
  %t35 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t37 = add i64 %t34, %t36
  %t38 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t37)
  call void @olang_textcopy(ptr %t38, ptr %t29, i64 %t30)
  %t39 = getelementptr i8, ptr %t38, i64 %t30
  call void @olang_textcopy(ptr %t39, ptr %t32, i64 %t33)
  %t40 = getelementptr i8, ptr %t39, i64 %t33
  call void @olang_textcopy(ptr %t40, ptr %t35, i64 %t36)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t38, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t42, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eweakField(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca ptr
  %l10 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:Emitter", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v0, ptr %t4)
  store ptr %t6, ptr %l5
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/emit:Emitter", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t17 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v0, ptr %t13, ptr %t10, i32 %a1, i64 %a2)
  store i1 %t17, ptr %l10
  br label %bb2
bb2:
  %t18 = load i1, ptr %l10, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eaddr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l18 = alloca { i64, [1 x i64] }
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca { { i64, ptr }, i32 }
  %l26 = alloca i64
  %l27 = alloca { { i64, ptr }, i32 }
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l35 = alloca { i64, ptr }
  %l42 = alloca i64
  %l46 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l54 = alloca i32
  %l60 = alloca i64
  %l63 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l82 = alloca i32
  %l85 = alloca i32
  %l105 = alloca ptr
  %l112 = alloca { i64, [1 x i64] }
  %l113 = alloca ptr
  %l116 = alloca i32
  %l120 = alloca ptr
  %l123 = alloca i32
  %l128 = alloca { i64, ptr }
  %l129 = alloca i64
  %l131 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l153 = alloca i32
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l158 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l176 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l179 = alloca i32
  %l180 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l186 = alloca { i64, ptr }
  %l188 = alloca { { i64, ptr }, i32 }
  %l189 = alloca i64
  %l191 = alloca { i64, ptr }
  %l192 = alloca i64
  %l193 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l203 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca { i64, ptr }
  %l206 = alloca i32
  %l209 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l217 = alloca { { i64, ptr }, i32 }
  %l218 = alloca i64
  %l220 = alloca { i64, ptr }
  %l221 = alloca i64
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l232 = alloca i32
  %l234 = alloca { i64, ptr }
  %l236 = alloca ptr
  %l240 = alloca { i64, ptr }
  %l245 = alloca i1
  %l246 = alloca i64
  %l251 = alloca { i64, ptr }
  %l255 = alloca { i64, ptr }
  %l260 = alloca i64
  %l262 = alloca ptr
  %l265 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l275 = alloca ptr
  %l278 = alloca i32
  %l283 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l292 = alloca { i64, ptr }
  %l294 = alloca ptr
  %l298 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t10 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t10, ptr %lp3
  %t12 = load ptr, ptr %lp3
  store { i64, ptr } %t9, ptr %t12, !tbaa !27
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t13, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  %t15 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t16 = load { i64, [2 x i64] }, ptr %t15
  store { i64, [2 x i64] } %t16, ptr %l7
  %t18 = load { i64, [2 x i64] }, ptr %l7
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 1
  br i1 %t21, label %bb1, label %bb2
bb1:
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t24 = getelementptr { i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t27 = call ptr @__olang_scope_hold(ptr %v1)
  %t28 = ptrtoint ptr %t27 to i64
  store i64 %t28, ptr %l42, !tbaa !24
  %t29 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = call ptr @__olang_region_make(ptr %v1)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l42, !tbaa !24
  br label %bb5
bb5:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l8, !tbaa !23
  %t35 = load i64, ptr %l42
  %t36 = inttoptr i64 %t35 to ptr
  %t39 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %t36, ptr %v2, ptr %v3, ptr %t33, i32 %t34)
  store { i64, ptr } %t39, ptr %l46
  br label %bb6
bb6:
  %t40 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t42 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  %t47 = load ptr, ptr %lp3
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l50, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t50 = load ptr, ptr %lp3
  store { i64, ptr } %t49, ptr %t50, !tbaa !27
  %t51 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t51, label %bb11, label %bb12
bb9:
  store { i64, ptr } zeroinitializer, ptr %l46, !tbaa !27
  br label %bb10
bb10:
  %t53 = load i64, ptr %l42
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = load { i64, ptr }, ptr %l46
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = call ptr @__olang_region_or(ptr %t56, ptr null)
  %t58 = icmp ne ptr %t57, null
  %t59 = select i1 %t58, ptr %t57, ptr null
  call void @__olang_region_settle_in(ptr %t54, ptr %t59)
  br label %bb8
bb11:
  %t60 = load { i64, ptr }, ptr %l50
  %t61 = extractvalue { i64, ptr } %t60, 1
  call void @__olang_region_release(ptr %t61)
  store { i64, ptr } zeroinitializer, ptr %l50
  br label %bb12
bb12:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load i32, ptr %l8, !tbaa !23
  %t66 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %v2, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l54
  br label %bb13
bb13:
  %t67 = load i32, ptr %l54, !tbaa !23
  store i32 %t67, ptr %l4, !tbaa !23
  br label %bb33
bb14:
  %t68 = load { i64, [2 x i64] }, ptr %l7
  %t70 = extractvalue { i64, [2 x i64] } %t68, 0
  %t71 = icmp eq i64 %t70, 2
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t74 = getelementptr { i64, i32, i32 }, ptr %t73, i32 0, i32 0
  %t75 = load i64, ptr %t74
  store i64 %t75, ptr %l9, !tbaa !24
  %t77 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t78 = getelementptr { i64, i32, i32 }, ptr %t77, i32 0, i32 1
  %t79 = load i32, ptr %t78
  store i32 %t79, ptr %l10, !tbaa !23
  %t81 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t82 = getelementptr { i64, i32, i32 }, ptr %t81, i32 0, i32 2
  %t83 = load i32, ptr %t82
  store i32 %t83, ptr %l11, !tbaa !23
  br label %bb17
bb16:
  br label %bb27
bb17:
  %t85 = call ptr @__olang_scope_hold(ptr %v1)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l60, !tbaa !24
  %t87 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = call ptr @__olang_region_make(ptr %v1)
  %t90 = ptrtoint ptr %t89 to i64
  store i64 %t90, ptr %l60, !tbaa !24
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/emit:fnEm", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l63, !tbaa !29
  %t95 = load i64, ptr %l9, !tbaa !24
  %t96 = load i32, ptr %l10, !tbaa !23
  %t97 = load i32, ptr %l11, !tbaa !23
  %t98 = load ptr, ptr %l63, !tbaa !29
  %t99 = call ptr @__olang_scope_or(ptr %v3, ptr %t98)
  %t100 = call ptr @__olang_scope_hold(ptr %t99)
  %t101 = ptrtoint ptr %t100 to i64
  %t103 = inttoptr i64 %t101 to ptr
  %t104 = load i64, ptr %l60
  %t105 = inttoptr i64 %t104 to ptr
  %t106 = load ptr, ptr %l63, !tbaa !29
  %t110 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %t103, ptr %t105, ptr %t106, i64 %t95, i32 %t96, i32 %t97)
  store { i64, ptr } %t110, ptr %l68
  br label %bb20
bb20:
  %t111 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t111, label %bb21, label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb23, label %bb24
bb22:
  %t118 = load ptr, ptr %lp3
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l72, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t121 = load ptr, ptr %lp3
  store { i64, ptr } %t120, ptr %t121, !tbaa !27
  %t122 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t122, label %bb25, label %bb26
bb23:
  store { i64, ptr } zeroinitializer, ptr %l68, !tbaa !27
  br label %bb24
bb24:
  %t124 = load i64, ptr %l60
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = load { i64, ptr }, ptr %l68
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = call ptr @__olang_region_or(ptr %t127, ptr null)
  %t129 = icmp ne ptr %t128, null
  %t130 = select i1 %t129, ptr %t128, ptr null
  call void @__olang_region_settle_in(ptr %t125, ptr %t130)
  br label %bb22
bb25:
  %t131 = load { i64, ptr }, ptr %l72
  %t132 = extractvalue { i64, ptr } %t131, 1
  call void @__olang_region_release(ptr %t132)
  store { i64, ptr } zeroinitializer, ptr %l72
  br label %bb26
bb26:
  %t133 = load i32, ptr %l11, !tbaa !23
  store i32 %t133, ptr %l4, !tbaa !23
  br label %bb33
bb27:
  %t135 = load { i64, [2 x i64] }, ptr %l7
  %t137 = extractvalue { i64, [2 x i64] } %t135, 0
  %t138 = icmp eq i64 %t137, 0
  br i1 %t138, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb32
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t140 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s3, ptr %v3, ptr %t140, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d179, i32 0, i32 1) })
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b)
  unreachable
bb33:
  store i32 0, ptr %l12, !tbaa !23
  %t142 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t143 = getelementptr %"compiler/mir:Range", ptr %t142, i32 0, i32 1
  %t144 = load i32, ptr %t143, !tbaa !23
  store i32 %t144, ptr %l13, !tbaa !23
  store i32 1, ptr %l14, !tbaa !23
  %t146 = load i32, ptr %l13, !tbaa !23
  %t147 = load i32, ptr %l12, !tbaa !23
  %t150 = icmp sgt i32 %t146, %t147
  br i1 %t150, label %bb34, label %bb35
bb34:
  %t152 = load i32, ptr %l14, !tbaa !23
  %t154 = icmp sgt i32 %t152, 0
  br i1 %t154, label %bb36, label %bb37
bb35:
  store i32 0, ptr %l82, !tbaa !23
  br label %bb39
bb36:
  %t156 = load i32, ptr %l13, !tbaa !23
  %t157 = load i32, ptr %l12, !tbaa !23
  %t160 = sub i32 %t156, %t157
  %t161 = load i32, ptr %l14, !tbaa !23
  %t164 = add i32 %t160, %t161
  %t166 = sub i32 %t164, 1
  %t167 = load i32, ptr %l14, !tbaa !23
  %t170 = sdiv i32 %t166, %t167
  store i32 %t170, ptr %l85, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l85, !tbaa !23
  br label %bb38
bb38:
  %t172 = load i32, ptr %l85, !tbaa !23
  store i32 %t172, ptr %l82, !tbaa !23
  br label %bb39
bb39:
  %t173 = load i32, ptr %l82, !tbaa !23
  store i32 %t173, ptr %l15, !tbaa !23
  store i32 0, ptr %l16, !tbaa !23
  br label %bb40
bb40:
  %t174 = load i32, ptr %l16, !tbaa !23
  %t175 = load i32, ptr %l15, !tbaa !23
  %t178 = icmp slt i32 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb41, label %bb42
bb41:
  br label %bb140
bb42:
  br label %bb43
bb43:
  %t182 = load i32, ptr %l12, !tbaa !23
  %t183 = load i32, ptr %l16, !tbaa !23
  %t184 = load i32, ptr %l14, !tbaa !23
  %t187 = mul i32 %t183, %t184
  %t190 = add i32 %t182, %t187
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/emit:fnEm", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/mir:Fn", ptr %t195, i32 0, i32 10
  store ptr %t197, ptr %l105, !tbaa !29
  %t198 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 1
  %t199 = getelementptr %"compiler/mir:Range", ptr %t198, i32 0, i32 0
  %t200 = load i32, ptr %t199, !tbaa !23
  %t202 = sext i32 %t200 to i64
  %t205 = sext i32 %t190 to i64
  %t208 = add i64 %t202, %t205
  %t209 = load ptr, ptr %l105, !tbaa !29
  %t210 = call ptr @__olang_scope_or(ptr %v2, ptr %t209)
  %t211 = call ptr @__olang_scope_hold(ptr %t210)
  %t212 = ptrtoint ptr %t211 to i64
  %t214 = inttoptr i64 %t212 to ptr
  %t215 = load ptr, ptr %l105, !tbaa !29
  %t217 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %t214, ptr %t215, i64 %t208)
  store { i64, [1 x i64] } %t217, ptr %l112
  br label %bb44
bb44:
  %t218 = load { i64, [1 x i64] }, ptr %l112
  store { i64, [1 x i64] } %t218, ptr %l18
  %t219 = load ptr, ptr %l2, !tbaa !29
  store ptr %t219, ptr %l113, !tbaa !29
  %t220 = load i32, ptr %l4, !tbaa !23
  %t221 = load ptr, ptr %l113, !tbaa !29
  %t222 = call ptr @__olang_scope_or(ptr %v3, ptr %t221)
  %t223 = call ptr @__olang_scope_hold(ptr %t222)
  %t224 = ptrtoint ptr %t223 to i64
  %t226 = inttoptr i64 %t224 to ptr
  %t227 = load ptr, ptr %l113, !tbaa !29
  %t229 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t226, ptr %t227, i32 %t220)
  store i32 %t229, ptr %l116
  br label %bb45
bb45:
  %t230 = load i32, ptr %l116, !tbaa !23
  store i32 %t230, ptr %l19, !tbaa !23
  %t231 = load { i64, [1 x i64] }, ptr %l18
  %t233 = extractvalue { i64, [1 x i64] } %t231, 0
  %t234 = icmp eq i64 %t233, 0
  br i1 %t234, label %bb46, label %bb47
bb46:
  %t236 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t237 = getelementptr { i64 }, ptr %t236, i32 0, i32 0
  %t238 = load i64, ptr %t237
  store i64 %t238, ptr %l20, !tbaa !24
  br label %bb48
bb47:
  br label %bb61
bb48:
  store %olang.scope zeroinitializer, ptr %s6
  %t240 = load ptr, ptr %l2, !tbaa !29
  store ptr %t240, ptr %l120, !tbaa !29
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load i32, ptr %l19, !tbaa !23
  %t245 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %v3, ptr %t241, i32 %t242)
  store i32 %t245, ptr %l123
  br label %bb49
bb49:
  %t246 = load ptr, ptr %l120, !tbaa !29
  %t247 = call ptr @__olang_scope_or(ptr %v3, ptr %t246)
  %t248 = call ptr @__olang_scope_hold(ptr %t247)
  %t249 = ptrtoint ptr %t248 to i64
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/emit:fnEm", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = call ptr @__olang_scope_or(ptr %v3, ptr %t253)
  %t256 = call ptr @__olang_scope_hold(ptr %t255)
  %t257 = ptrtoint ptr %t256 to i64
  %t259 = inttoptr i64 %t249 to ptr
  %t261 = inttoptr i64 %t257 to ptr
  %t262 = load ptr, ptr %l120, !tbaa !29
  %t263 = load i32, ptr %l123, !tbaa !23
  %t264 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t259, ptr %t261, ptr %t262, i32 %t263)
  store { i64, ptr } %t264, ptr %l128
  br label %bb50
bb50:
  %t265 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t265, ptr %l21, !tbaa !27
  %t266 = call ptr @__olang_scope_hold(ptr %v1)
  %t267 = ptrtoint ptr %t266 to i64
  store i64 %t267, ptr %l129, !tbaa !24
  %t268 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t268, label %bb51, label %bb52
bb51:
  %t270 = call ptr @__olang_region_make(ptr %v1)
  %t271 = ptrtoint ptr %t270 to i64
  store i64 %t271, ptr %l129, !tbaa !24
  br label %bb52
bb52:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l131, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load i32, ptr %l19, !tbaa !23
  %t277 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s6, ptr %v3, ptr %t273, i32 %t274)
  store { i64, ptr } %t277, ptr %l134
  br label %bb53
bb53:
  %t278 = load ptr, ptr %lp3
  %t279 = load { i64, ptr }, ptr %t278, !tbaa !27
  %t280 = load i64, ptr %l20, !tbaa !24
  %t281 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d180, i32 0, i32 1) }, 1
  %t282 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d180, i32 0, i32 1) }, 0
  %t283 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t283, 1
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t286 = add i64 %t282, %t285
  %t287 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t288 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t289 = add i64 %t286, %t288
  %t291 = extractvalue { i64, ptr } %t279, 1
  %t292 = extractvalue { i64, ptr } %t279, 0
  %t293 = add i64 %t289, %t292
  %t294 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t295 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t296 = add i64 %t293, %t295
  %t298 = call i64 @__olang_fmt_i64(ptr null, i64 %t280)
  %t299 = add i64 %t296, %t298
  %t300 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t299)
  call void @olang_textcopy(ptr %t300, ptr %t281, i64 %t282)
  %t301 = getelementptr i8, ptr %t300, i64 %t282
  call void @olang_textcopy(ptr %t301, ptr %t284, i64 %t285)
  %t302 = getelementptr i8, ptr %t301, i64 %t285
  call void @olang_textcopy(ptr %t302, ptr %t287, i64 %t288)
  %t303 = getelementptr i8, ptr %t302, i64 %t288
  call void @olang_textcopy(ptr %t303, ptr %t291, i64 %t292)
  %t304 = getelementptr i8, ptr %t303, i64 %t292
  call void @olang_textcopy(ptr %t304, ptr %t294, i64 %t295)
  %t305 = getelementptr i8, ptr %t304, i64 %t295
  %t306 = call i64 @__olang_fmt_i64(ptr %t305, i64 %t280)
  %t307 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t300, 1
  %t310 = load i64, ptr %l129
  %t311 = inttoptr i64 %t310 to ptr
  %t312 = load ptr, ptr %l131, !tbaa !29
  %t314 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s6, ptr %t311, ptr %v3, ptr %t312, { i64, ptr } %t308)
  store { i64, ptr } %t314, ptr %l139
  br label %bb54
bb54:
  %t315 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t315, label %bb55, label %bb56
bb55:
  %t317 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t317, 0
  %t320 = icmp eq i64 %t318, 0
  br i1 %t320, label %bb57, label %bb58
bb56:
  %t322 = load ptr, ptr %lp3
  %t323 = load { i64, ptr }, ptr %t322, !tbaa !27
  store { i64, ptr } %t323, ptr %l143, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t325 = load ptr, ptr %lp3
  store { i64, ptr } %t324, ptr %t325, !tbaa !27
  %t326 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t326, label %bb59, label %bb60
bb57:
  store { i64, ptr } zeroinitializer, ptr %l139, !tbaa !27
  br label %bb58
bb58:
  %t328 = load i64, ptr %l129
  %t329 = inttoptr i64 %t328 to ptr
  %t330 = load { i64, ptr }, ptr %l139
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = call ptr @__olang_region_or(ptr %t331, ptr null)
  %t333 = icmp ne ptr %t332, null
  %t334 = select i1 %t333, ptr %t332, ptr null
  call void @__olang_region_settle_in(ptr %t329, ptr %t334)
  br label %bb56
bb59:
  %t335 = load { i64, ptr }, ptr %l143
  %t336 = extractvalue { i64, ptr } %t335, 1
  call void @__olang_region_release(ptr %t336)
  store { i64, ptr } zeroinitializer, ptr %l143
  br label %bb60
bb60:
  %t337 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t337, ptr %l145, !tbaa !27
  %t338 = load i64, ptr %l20, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr i32, ptr %t341, i64 %t338
  %t343 = load i32, ptr %t342, !tbaa !33
  store i32 %t343, ptr %l4, !tbaa !23
  store i1 false, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb138
bb61:
  %t345 = load { i64, [1 x i64] }, ptr %l18
  %t347 = extractvalue { i64, [1 x i64] } %t345, 0
  %t348 = icmp eq i64 %t347, 1
  br i1 %t348, label %bb62, label %bb63
bb62:
  %t350 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t351 = getelementptr { i32 }, ptr %t350, i32 0, i32 0
  %t352 = load i32, ptr %t351
  store i32 %t352, ptr %l22, !tbaa !23
  br label %bb64
bb63:
  br label %bb83
bb64:
  store %olang.scope zeroinitializer, ptr %s8
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load i32, ptr %l22, !tbaa !23
  %t358 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %v2, ptr %t354, i32 %t355)
  store i32 %t358, ptr %l153
  br label %bb65
bb65:
  %t359 = load i32, ptr %l153, !tbaa !23
  store i32 %t359, ptr %l23, !tbaa !23
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l154, !tbaa !29
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l155, !tbaa !29
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i32, ptr %l23, !tbaa !23
  %t366 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s8, ptr %v3, ptr %t362, i32 %t363)
  store { i64, ptr } %t366, ptr %l158
  br label %bb66
bb66:
  %t367 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t367, ptr %l159, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load i32, ptr %l22, !tbaa !23
  %t372 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s8, ptr %v2, ptr %v3, ptr %t368, i32 %t369)
  store { i64, ptr } %t372, ptr %l162
  br label %bb67
bb67:
  %t373 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t373, ptr %l163, !tbaa !27
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/emit:fnEm", ptr %t374, i32 0, i32 0
  %t377 = load ptr, ptr %t376, !tbaa !29
  store ptr %t377, ptr %l165, !tbaa !29
  %t378 = load i32, ptr %l23, !tbaa !23
  %t379 = load ptr, ptr %l165, !tbaa !29
  %t380 = call ptr @__olang_scope_or(ptr %v3, ptr %t379)
  %t381 = call ptr @__olang_scope_hold(ptr %t380)
  %t382 = ptrtoint ptr %t381 to i64
  %t384 = inttoptr i64 %t382 to ptr
  %t385 = load ptr, ptr %l165, !tbaa !29
  %t387 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %t384, ptr %s8, ptr %t385, i32 %t378, i1 false)
  store { i64, ptr } %t387, ptr %l168
  br label %bb68
bb68:
  %t388 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t389 = load ptr, ptr %l155, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t391 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t393 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %s8, ptr %v3, ptr %t389, { i64, ptr } %t390, { i64, ptr } %t391, { i64, ptr } %t388)
  store { i64, ptr } %t393, ptr %l170
  br label %bb69
bb69:
  %t394 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t395 = load i32, ptr %l23, !tbaa !23
  %t396 = load ptr, ptr %l154, !tbaa !29
  %t399 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %s8, ptr %s8, ptr %v3, ptr %t396, { i64, ptr } %t394, i32 %t395)
  store { i64, ptr } %t399, ptr %l173
  br label %bb70
bb70:
  %t400 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t400, ptr %l24, !tbaa !27
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load i32, ptr %l4, !tbaa !23
  %t405 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %v3, ptr %t401, i32 %t402)
  store i1 %t405, ptr %l176
  br label %bb71
bb71:
  %t406 = load i1, ptr %l176, !tbaa !21
  br i1 %t406, label %bb72, label %bb73
bb72:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb74
bb73:
  br label %bb74
bb74:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l177, !tbaa !29
  %t408 = load ptr, ptr %lp3
  %t409 = load { i64, ptr }, ptr %t408, !tbaa !27
  store { i64, ptr } %t409, ptr %l178, !tbaa !27
  %t410 = load i32, ptr %l4, !tbaa !23
  store i32 %t410, ptr %l179, !tbaa !23
  %t411 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t411, ptr %l180, !tbaa !27
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t414 = getelementptr %"compiler/emit:fnEm", ptr %t412, i32 0, i32 0
  %t415 = load ptr, ptr %t414, !tbaa !29
  store ptr %t415, ptr %l182, !tbaa !29
  %t416 = load i1, ptr %l5, !tbaa !21
  %t417 = load i1, ptr %l6, !tbaa !21
  %t418 = load ptr, ptr %l182, !tbaa !29
  %t419 = call ptr @__olang_scope_or(ptr %v3, ptr %t418)
  %t420 = call ptr @__olang_scope_hold(ptr %t419)
  %t421 = ptrtoint ptr %t420 to i64
  %t423 = inttoptr i64 %t421 to ptr
  %t424 = load ptr, ptr %l182, !tbaa !29
  %t427 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %t423, ptr %s8, ptr %t424, i1 %t416, i1 %t417)
  store { i64, ptr } %t427, ptr %l186
  br label %bb75
bb75:
  %t428 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t429 = load ptr, ptr %l177, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t431 = load i32, ptr %l179, !tbaa !23
  %t432 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t434 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s8, ptr %s8, ptr %v1, ptr %v3, ptr %t429, { i64, ptr } %t430, i32 %t431, { i64, ptr } %t432, { i64, ptr } %t428)
  store { { i64, ptr }, i32 } %t434, ptr %l188
  br label %bb76
bb76:
  %t435 = load { { i64, ptr }, i32 }, ptr %l188
  store { { i64, ptr }, i32 } %t435, ptr %l25
  %t436 = call ptr @__olang_scope_hold(ptr %v1)
  %t437 = ptrtoint ptr %t436 to i64
  store i64 %t437, ptr %l189, !tbaa !24
  %t438 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t438, label %bb77, label %bb78
bb77:
  %t440 = call ptr @__olang_region_make(ptr %v1)
  %t441 = ptrtoint ptr %t440 to i64
  store i64 %t441, ptr %l189, !tbaa !24
  br label %bb78
bb78:
  %t442 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 0
  %t443 = load { i64, ptr }, ptr %t442, !tbaa !27
  store { i64, ptr } %t443, ptr %l191, !tbaa !27
  %t444 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  store i64 %t445, ptr %l192, !tbaa !24
  %t446 = load i64, ptr %l192, !tbaa !24
  %t447 = mul i64 %t446, 1
  %t448 = load i64, ptr %l189
  %t449 = inttoptr i64 %t448 to ptr
  %t450 = call ptr @__olang_held_alloc(ptr %t449, i64 %t447)
  %t451 = insertvalue { i64, ptr } undef, i64 %t446, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t450, 1
  store { i64, ptr } %t452, ptr %l193, !tbaa !27
  %t453 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !27
  %t457 = load i64, ptr %l192, !tbaa !24
  %t458 = mul i64 %t457, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t454, ptr %t456, i64 %t458, i1 false)
  %t459 = load ptr, ptr %lp3
  %t460 = load { i64, ptr }, ptr %t459, !tbaa !27
  store { i64, ptr } %t460, ptr %l194, !tbaa !27
  %t461 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t462 = load ptr, ptr %lp3
  store { i64, ptr } %t461, ptr %t462, !tbaa !27
  %t463 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t463, label %bb79, label %bb80
bb79:
  %t465 = load { i64, ptr }, ptr %l194
  %t466 = extractvalue { i64, ptr } %t465, 1
  call void @__olang_region_release(ptr %t466)
  store { i64, ptr } zeroinitializer, ptr %l194
  br label %bb80
bb80:
  %t467 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t467, label %bb81, label %bb82
bb81:
  %t469 = load ptr, ptr %lp3
  %t470 = load i64, ptr %l189
  %t471 = inttoptr i64 %t470 to ptr
  %t472 = load { i64, ptr }, ptr %t469
  %t473 = extractvalue { i64, ptr } %t472, 1
  %t474 = call ptr @__olang_region_or(ptr %t473, ptr null)
  %t475 = icmp ne ptr %t474, null
  %t476 = select i1 %t475, ptr %t474, ptr null
  call void @__olang_region_settle_in(ptr %t471, ptr %t476)
  br label %bb82
bb82:
  %t477 = getelementptr { { i64, ptr }, i32 }, ptr %l25, i32 0, i32 1
  %t478 = load i32, ptr %t477, !tbaa !23
  store i32 %t478, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb138
bb83:
  %t480 = load { i64, [1 x i64] }, ptr %l18
  %t482 = extractvalue { i64, [1 x i64] } %t480, 0
  %t483 = icmp eq i64 %t482, 2
  br i1 %t483, label %bb84, label %bb85
bb84:
  %t485 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t486 = getelementptr { i64 }, ptr %t485, i32 0, i32 0
  %t487 = load i64, ptr %t486
  store i64 %t487, ptr %l26, !tbaa !24
  br label %bb86
bb85:
  br label %bb99
bb86:
  store %olang.scope zeroinitializer, ptr %s10
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i32, ptr %l4, !tbaa !23
  %t493 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %v3, ptr %t489, i32 %t490)
  store i1 %t493, ptr %l203
  br label %bb87
bb87:
  %t494 = load i1, ptr %l203, !tbaa !21
  br i1 %t494, label %bb88, label %bb89
bb88:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb90
bb89:
  br label %bb90
bb90:
  %t495 = load ptr, ptr %l0, !tbaa !29
  store ptr %t495, ptr %l204, !tbaa !29
  %t496 = load ptr, ptr %lp3
  %t497 = load { i64, ptr }, ptr %t496, !tbaa !27
  store { i64, ptr } %t497, ptr %l205, !tbaa !27
  %t498 = load i32, ptr %l4, !tbaa !23
  store i32 %t498, ptr %l206, !tbaa !23
  %t499 = load i64, ptr %l26, !tbaa !24
  %t501 = call i64 @__olang_fmt_i64(ptr null, i64 %t499)
  %t502 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t501)
  %t503 = call i64 @__olang_fmt_i64(ptr %t502, i64 %t499)
  %t504 = insertvalue { i64, ptr } undef, i64 %t501, 0
  %t505 = insertvalue { i64, ptr } %t504, ptr %t502, 1
  store { i64, ptr } %t505, ptr %l209, !tbaa !27
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/emit:fnEm", ptr %t507, i32 0, i32 0
  %t510 = load ptr, ptr %t509, !tbaa !29
  store ptr %t510, ptr %l211, !tbaa !29
  %t511 = load i1, ptr %l5, !tbaa !21
  %t512 = load i1, ptr %l6, !tbaa !21
  %t513 = load ptr, ptr %l211, !tbaa !29
  %t514 = call ptr @__olang_scope_or(ptr %v3, ptr %t513)
  %t515 = call ptr @__olang_scope_hold(ptr %t514)
  %t516 = ptrtoint ptr %t515 to i64
  %t518 = inttoptr i64 %t516 to ptr
  %t519 = load ptr, ptr %l211, !tbaa !29
  %t522 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %t518, ptr %s10, ptr %t519, i1 %t511, i1 %t512)
  store { i64, ptr } %t522, ptr %l215
  br label %bb91
bb91:
  %t523 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t524 = load ptr, ptr %l204, !tbaa !29
  %t525 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t526 = load i32, ptr %l206, !tbaa !23
  %t527 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t529 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s10, ptr %s10, ptr %v1, ptr %v3, ptr %t524, { i64, ptr } %t525, i32 %t526, { i64, ptr } %t527, { i64, ptr } %t523)
  store { { i64, ptr }, i32 } %t529, ptr %l217
  br label %bb92
bb92:
  %t530 = load { { i64, ptr }, i32 }, ptr %l217
  store { { i64, ptr }, i32 } %t530, ptr %l27
  %t531 = call ptr @__olang_scope_hold(ptr %v1)
  %t532 = ptrtoint ptr %t531 to i64
  store i64 %t532, ptr %l218, !tbaa !24
  %t533 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t533, label %bb93, label %bb94
bb93:
  %t535 = call ptr @__olang_region_make(ptr %v1)
  %t536 = ptrtoint ptr %t535 to i64
  store i64 %t536, ptr %l218, !tbaa !24
  br label %bb94
bb94:
  %t537 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 0
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !27
  store { i64, ptr } %t538, ptr %l220, !tbaa !27
  %t539 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 0
  store i64 %t540, ptr %l221, !tbaa !24
  %t541 = load i64, ptr %l221, !tbaa !24
  %t542 = mul i64 %t541, 1
  %t543 = load i64, ptr %l218
  %t544 = inttoptr i64 %t543 to ptr
  %t545 = call ptr @__olang_held_alloc(ptr %t544, i64 %t542)
  %t546 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t547 = insertvalue { i64, ptr } %t546, ptr %t545, 1
  store { i64, ptr } %t547, ptr %l222, !tbaa !27
  %t548 = getelementptr { i64, ptr }, ptr %l222, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = load i64, ptr %l221, !tbaa !24
  %t553 = mul i64 %t552, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t549, ptr %t551, i64 %t553, i1 false)
  %t554 = load ptr, ptr %lp3
  %t555 = load { i64, ptr }, ptr %t554, !tbaa !27
  store { i64, ptr } %t555, ptr %l223, !tbaa !27
  %t556 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t557 = load ptr, ptr %lp3
  store { i64, ptr } %t556, ptr %t557, !tbaa !27
  %t558 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t558, label %bb95, label %bb96
bb95:
  %t560 = load { i64, ptr }, ptr %l223
  %t561 = extractvalue { i64, ptr } %t560, 1
  call void @__olang_region_release(ptr %t561)
  store { i64, ptr } zeroinitializer, ptr %l223
  br label %bb96
bb96:
  %t562 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t562, label %bb97, label %bb98
bb97:
  %t564 = load ptr, ptr %lp3
  %t565 = load i64, ptr %l218
  %t566 = inttoptr i64 %t565 to ptr
  %t567 = load { i64, ptr }, ptr %t564
  %t568 = extractvalue { i64, ptr } %t567, 1
  %t569 = call ptr @__olang_region_or(ptr %t568, ptr null)
  %t570 = icmp ne ptr %t569, null
  %t571 = select i1 %t570, ptr %t569, ptr null
  call void @__olang_region_settle_in(ptr %t566, ptr %t571)
  br label %bb98
bb98:
  %t572 = getelementptr { { i64, ptr }, i32 }, ptr %l27, i32 0, i32 1
  %t573 = load i32, ptr %t572, !tbaa !23
  store i32 %t573, ptr %l4, !tbaa !23
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb138
bb99:
  %t575 = load { i64, [1 x i64] }, ptr %l18
  %t577 = extractvalue { i64, [1 x i64] } %t575, 0
  %t578 = icmp eq i64 %t577, 3
  br i1 %t578, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb121
bb102:
  store %olang.scope zeroinitializer, ptr %s13
  %t580 = load ptr, ptr %l2, !tbaa !29
  store ptr %t580, ptr %l229, !tbaa !29
  %t581 = load i32, ptr %l19, !tbaa !23
  %t582 = load ptr, ptr %l229, !tbaa !29
  %t583 = call ptr @__olang_scope_or(ptr %v3, ptr %t582)
  %t584 = call ptr @__olang_scope_hold(ptr %t583)
  %t585 = ptrtoint ptr %t584 to i64
  %t587 = inttoptr i64 %t585 to ptr
  %t588 = load ptr, ptr %l229, !tbaa !29
  %t590 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t587, ptr %t588, i32 %t581)
  store i32 %t590, ptr %l232
  br label %bb103
bb103:
  %t591 = load i32, ptr %l232, !tbaa !23
  store i32 %t591, ptr %l28, !tbaa !23
  %t592 = load i1, ptr %l6, !tbaa !21
  br i1 %t592, label %bb104, label %bb105
bb104:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d183, i32 0, i32 1) }, ptr %l234, !tbaa !27
  br label %bb107
bb105:
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/emit:fnEm", ptr %t594, i32 0, i32 0
  %t597 = load ptr, ptr %t596, !tbaa !29
  store ptr %t597, ptr %l236, !tbaa !29
  %t598 = load i32, ptr %l19, !tbaa !23
  %t599 = load i1, ptr %l5, !tbaa !21
  %t600 = load ptr, ptr %l236, !tbaa !29
  %t601 = call ptr @__olang_scope_or(ptr %v3, ptr %t600)
  %t602 = call ptr @__olang_scope_hold(ptr %t601)
  %t603 = ptrtoint ptr %t602 to i64
  %t605 = inttoptr i64 %t603 to ptr
  %t606 = load ptr, ptr %l236, !tbaa !29
  %t609 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %t605, ptr %s13, ptr %t606, i32 %t598, i1 %t599)
  store { i64, ptr } %t609, ptr %l240
  br label %bb106
bb106:
  %t610 = load { i64, ptr }, ptr %l240, !tbaa !27
  store { i64, ptr } %t610, ptr %l234, !tbaa !27
  br label %bb107
bb107:
  %t612 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t612, ptr %l29, !tbaa !27
  %t613 = load i32, ptr %l28, !tbaa !23
  store i32 %t613, ptr %l4, !tbaa !23
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l28, !tbaa !23
  %t619 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %v3, ptr %t615, i32 %t616)
  store i1 %t619, ptr %l245
  br label %bb108
bb108:
  %t620 = load i1, ptr %l245, !tbaa !21
  br i1 %t620, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s13)
  br label %bb139
bb110:
  br label %bb111
bb111:
  %t621 = call ptr @__olang_scope_hold(ptr %v1)
  %t622 = ptrtoint ptr %t621 to i64
  store i64 %t622, ptr %l246, !tbaa !24
  %t623 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t623, label %bb112, label %bb113
bb112:
  %t625 = call ptr @__olang_region_make(ptr %v1)
  %t626 = ptrtoint ptr %t625 to i64
  store i64 %t626, ptr %l246, !tbaa !24
  br label %bb113
bb113:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load ptr, ptr %lp3
  %t629 = load { i64, ptr }, ptr %t628, !tbaa !27
  %t630 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t631 = load i64, ptr %l246
  %t632 = inttoptr i64 %t631 to ptr
  %t636 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s13, ptr %v1, ptr %s13, ptr %t632, ptr %v3, ptr %t627, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d184, i32 0, i32 1) }, { i64, ptr } %t629, { i64, ptr } %t630)
  store { i64, ptr } %t636, ptr %l251
  br label %bb114
bb114:
  %t637 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t637, label %bb115, label %bb116
bb115:
  %t639 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t640 = extractvalue { i64, ptr } %t639, 0
  %t642 = icmp eq i64 %t640, 0
  br i1 %t642, label %bb117, label %bb118
bb116:
  %t644 = load ptr, ptr %lp3
  %t645 = load { i64, ptr }, ptr %t644, !tbaa !27
  store { i64, ptr } %t645, ptr %l255, !tbaa !27
  %t646 = load { i64, ptr }, ptr %l251, !tbaa !27
  %t647 = load ptr, ptr %lp3
  store { i64, ptr } %t646, ptr %t647, !tbaa !27
  %t648 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t648, label %bb119, label %bb120
bb117:
  store { i64, ptr } zeroinitializer, ptr %l251, !tbaa !27
  br label %bb118
bb118:
  %t650 = load i64, ptr %l246
  %t651 = inttoptr i64 %t650 to ptr
  %t652 = load { i64, ptr }, ptr %l251
  %t653 = extractvalue { i64, ptr } %t652, 1
  %t654 = call ptr @__olang_region_or(ptr %t653, ptr null)
  %t655 = icmp ne ptr %t654, null
  %t656 = select i1 %t655, ptr %t654, ptr null
  call void @__olang_region_settle_in(ptr %t651, ptr %t656)
  br label %bb116
bb119:
  %t657 = load { i64, ptr }, ptr %l255
  %t658 = extractvalue { i64, ptr } %t657, 1
  call void @__olang_region_release(ptr %t658)
  store { i64, ptr } zeroinitializer, ptr %l255
  br label %bb120
bb120:
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb138
bb121:
  %t659 = load { i64, [1 x i64] }, ptr %l18
  %t661 = extractvalue { i64, [1 x i64] } %t659, 0
  %t662 = icmp eq i64 %t661, 4
  br i1 %t662, label %bb122, label %bb123
bb122:
  %t664 = getelementptr { i64, [1 x i64] }, ptr %l18, i32 0, i32 1
  %t665 = getelementptr { i64 }, ptr %t664, i32 0, i32 0
  %t666 = load i64, ptr %t665
  store i64 %t666, ptr %l30, !tbaa !24
  br label %bb124
bb123:
  br label %bb137
bb124:
  store %olang.scope zeroinitializer, ptr %s15
  %t668 = call ptr @__olang_scope_hold(ptr %v1)
  %t669 = ptrtoint ptr %t668 to i64
  store i64 %t669, ptr %l260, !tbaa !24
  %t670 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t670, label %bb125, label %bb126
bb125:
  %t672 = call ptr @__olang_region_make(ptr %v1)
  %t673 = ptrtoint ptr %t672 to i64
  store i64 %t673, ptr %l260, !tbaa !24
  br label %bb126
bb126:
  %t674 = load ptr, ptr %l0, !tbaa !29
  store ptr %t674, ptr %l262, !tbaa !29
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load i32, ptr %l19, !tbaa !23
  %t679 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s15, ptr %v3, ptr %t675, i32 %t676)
  store { i64, ptr } %t679, ptr %l265
  br label %bb127
bb127:
  %t680 = load ptr, ptr %lp3
  %t681 = load { i64, ptr }, ptr %t680, !tbaa !27
  %t682 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t683 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t684 = load { i64, ptr }, ptr %l265, !tbaa !27
  %t685 = extractvalue { i64, ptr } %t684, 1
  %t686 = extractvalue { i64, ptr } %t684, 0
  %t687 = add i64 %t683, %t686
  %t688 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t692 = extractvalue { i64, ptr } %t681, 1
  %t693 = extractvalue { i64, ptr } %t681, 0
  %t694 = add i64 %t690, %t693
  %t695 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t696 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t697 = add i64 %t694, %t696
  %t698 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t697)
  call void @olang_textcopy(ptr %t698, ptr %t682, i64 %t683)
  %t699 = getelementptr i8, ptr %t698, i64 %t683
  call void @olang_textcopy(ptr %t699, ptr %t685, i64 %t686)
  %t700 = getelementptr i8, ptr %t699, i64 %t686
  call void @olang_textcopy(ptr %t700, ptr %t688, i64 %t689)
  %t701 = getelementptr i8, ptr %t700, i64 %t689
  call void @olang_textcopy(ptr %t701, ptr %t692, i64 %t693)
  %t702 = getelementptr i8, ptr %t701, i64 %t693
  call void @olang_textcopy(ptr %t702, ptr %t695, i64 %t696)
  %t703 = insertvalue { i64, ptr } undef, i64 %t697, 0
  %t704 = insertvalue { i64, ptr } %t703, ptr %t698, 1
  %t706 = load i64, ptr %l260
  %t707 = inttoptr i64 %t706 to ptr
  %t708 = load ptr, ptr %l262, !tbaa !29
  %t710 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s15, ptr %t707, ptr %v3, ptr %t708, { i64, ptr } %t704)
  store { i64, ptr } %t710, ptr %l269
  br label %bb128
bb128:
  %t711 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t711, label %bb129, label %bb130
bb129:
  %t713 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t714 = extractvalue { i64, ptr } %t713, 0
  %t716 = icmp eq i64 %t714, 0
  br i1 %t716, label %bb131, label %bb132
bb130:
  %t718 = load ptr, ptr %lp3
  %t719 = load { i64, ptr }, ptr %t718, !tbaa !27
  store { i64, ptr } %t719, ptr %l273, !tbaa !27
  %t720 = load { i64, ptr }, ptr %l269, !tbaa !27
  %t721 = load ptr, ptr %lp3
  store { i64, ptr } %t720, ptr %t721, !tbaa !27
  %t722 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3
  br i1 %t722, label %bb133, label %bb134
bb131:
  store { i64, ptr } zeroinitializer, ptr %l269, !tbaa !27
  br label %bb132
bb132:
  %t724 = load i64, ptr %l260
  %t725 = inttoptr i64 %t724 to ptr
  %t726 = load { i64, ptr }, ptr %l269
  %t727 = extractvalue { i64, ptr } %t726, 1
  %t728 = call ptr @__olang_region_or(ptr %t727, ptr null)
  %t729 = icmp ne ptr %t728, null
  %t730 = select i1 %t729, ptr %t728, ptr null
  call void @__olang_region_settle_in(ptr %t725, ptr %t730)
  br label %bb130
bb133:
  %t731 = load { i64, ptr }, ptr %l273
  %t732 = extractvalue { i64, ptr } %t731, 1
  call void @__olang_region_release(ptr %t732)
  store { i64, ptr } zeroinitializer, ptr %l273
  br label %bb134
bb134:
  %t733 = load ptr, ptr %l2, !tbaa !29
  store ptr %t733, ptr %l275, !tbaa !29
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t735 = load i32, ptr %l19, !tbaa !23
  %t738 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %v3, ptr %t734, i32 %t735)
  store i32 %t738, ptr %l278
  br label %bb135
bb135:
  %t739 = load ptr, ptr %l275, !tbaa !29
  %t740 = call ptr @__olang_scope_or(ptr %v3, ptr %t739)
  %t741 = call ptr @__olang_scope_hold(ptr %t740)
  %t742 = ptrtoint ptr %t741 to i64
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t745 = getelementptr %"compiler/emit:fnEm", ptr %t743, i32 0, i32 0
  %t746 = load ptr, ptr %t745, !tbaa !29
  %t748 = call ptr @__olang_scope_or(ptr %v3, ptr %t746)
  %t749 = call ptr @__olang_scope_hold(ptr %t748)
  %t750 = ptrtoint ptr %t749 to i64
  %t752 = inttoptr i64 %t742 to ptr
  %t754 = inttoptr i64 %t750 to ptr
  %t755 = load ptr, ptr %l275, !tbaa !29
  %t756 = load i32, ptr %l278, !tbaa !23
  %t757 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t752, ptr %t754, ptr %t755, i32 %t756)
  store { i64, ptr } %t757, ptr %l283
  br label %bb136
bb136:
  %t758 = load { i64, ptr }, ptr %l283, !tbaa !27
  store { i64, ptr } %t758, ptr %l284, !tbaa !27
  %t760 = load i64, ptr %l30, !tbaa !24
  %t762 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !27
  %t764 = getelementptr i32, ptr %t763, i64 %t760
  %t765 = load i32, ptr %t764, !tbaa !33
  store i32 %t765, ptr %l4, !tbaa !23
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s15)
  br label %bb138
bb137:
  call void @__olang_check_failed(ptr @olang_loc_f0091f918c975106_bc2d594a86836fba)
  unreachable
bb138:
  br label %bb139
bb139:
  %t767 = load i32, ptr %l16, !tbaa !23
  %t770 = add i32 %t767, 1
  store i32 %t770, ptr %l16, !tbaa !23
  br label %bb40
bb140:
  %t772 = load ptr, ptr %l0, !tbaa !29
  store ptr %t772, ptr %l290, !tbaa !29
  %t773 = load i1, ptr %l6, !tbaa !21
  br i1 %t773, label %bb141, label %bb142
bb141:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d188, i32 0, i32 1) }, ptr %l292, !tbaa !27
  br label %bb144
bb142:
  %t775 = load ptr, ptr %l0, !tbaa !29
  %t777 = getelementptr %"compiler/emit:fnEm", ptr %t775, i32 0, i32 0
  %t778 = load ptr, ptr %t777, !tbaa !29
  store ptr %t778, ptr %l294, !tbaa !29
  %t779 = load i32, ptr %l4, !tbaa !23
  %t780 = load i1, ptr %l5, !tbaa !21
  %t781 = load ptr, ptr %l294, !tbaa !29
  %t782 = call ptr @__olang_scope_or(ptr %v3, ptr %t781)
  %t783 = call ptr @__olang_scope_hold(ptr %t782)
  %t784 = ptrtoint ptr %t783 to i64
  %t786 = inttoptr i64 %t784 to ptr
  %t787 = load ptr, ptr %l294, !tbaa !29
  %t790 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %t786, ptr %v0, ptr %t787, i32 %t779, i1 %t780)
  store { i64, ptr } %t790, ptr %l298
  br label %bb143
bb143:
  %t791 = load { i64, ptr }, ptr %l298, !tbaa !27
  store { i64, ptr } %t791, ptr %l292, !tbaa !27
  br label %bb144
bb144:
  %t793 = load ptr, ptr %l290, !tbaa !29
  %t794 = getelementptr %"compiler/emit:fnEm", ptr %t793, i32 0, i32 15
  %t795 = load { i64, ptr }, ptr %t794, !tbaa !27
  store { i64, ptr } %t795, ptr %l300, !tbaa !27
  %t796 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t797 = load ptr, ptr %l290, !tbaa !29
  %t798 = getelementptr %"compiler/emit:fnEm", ptr %t797, i32 0, i32 15
  store { i64, ptr } %t796, ptr %t798, !tbaa !27
  %t799 = load i1, ptr @olang_2esole_2ecompiler_2femit_3afnEm_2e15
  br i1 %t799, label %bb145, label %bb146
bb145:
  %t801 = load { i64, ptr }, ptr %l300
  %t802 = extractvalue { i64, ptr } %t801, 1
  call void @__olang_region_release(ptr %t802)
  store { i64, ptr } zeroinitializer, ptr %l300
  br label %bb146
bb146:
  %t803 = load ptr, ptr %lp3
  %t804 = load { i64, ptr }, ptr %t803, !tbaa !27
  %t805 = load i32, ptr %l4, !tbaa !23
  %t807 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t804, 0
  %t809 = insertvalue { { i64, ptr }, i32 } %t807, i32 %t805, 1
  store { { i64, ptr }, i32 } %t809, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2earrayStorage(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i1
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l50 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %v4, ptr %t1, i32 %a3)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  br i1 %a5, label %bb2, label %bb3
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  %t11 = xor i1 %t9, true
  store i1 %t11, ptr %l14, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l14, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d189, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb7
bb6:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d190, i32 0, i32 1) }, ptr %l17, !tbaa !27
  br label %bb7
bb7:
  %t14 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t14, ptr %l7, !tbaa !27
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 8
  br i1 %t17, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load i1, ptr %l4, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb9:
  br label %bb15
bb10:
  store { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d191, i32 0, i32 1) }, ptr %l21, !tbaa !27
  br label %bb12
bb11:
  %t21 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = extractvalue { i64, ptr } %t21, 0
  %t25 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t26 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t27 = add i64 %t24, %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t27)
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = getelementptr i8, ptr %t28, i64 %t24
  call void @olang_textcopy(ptr %t29, ptr %t25, i64 %t26)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t28, 1
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  br label %bb12
bb12:
  %t34 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t34, ptr %l8, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/emit:fnEm", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %l26, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = load ptr, ptr %l26, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v4, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l26, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t45, ptr %s1, ptr %t46, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t56 = extractvalue { i64, ptr } %t49, 1
  %t57 = extractvalue { i64, ptr } %t49, 0
  %t58 = add i64 %t54, %t57
  %t59 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t63 = extractvalue { i64, ptr } %t50, 1
  %t64 = extractvalue { i64, ptr } %t50, 0
  %t65 = add i64 %t61, %t64
  %t66 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t68 = add i64 %t65, %t67
  %t70 = extractvalue { i64, ptr } %t51, 1
  %t71 = extractvalue { i64, ptr } %t51, 0
  %t72 = add i64 %t68, %t71
  %t73 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t75 = add i64 %t72, %t74
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t52)
  %t78 = add i64 %t75, %t77
  %t79 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t53, i64 %t54)
  %t83 = getelementptr i8, ptr %t82, i64 %t54
  call void @olang_textcopy(ptr %t83, ptr %t56, i64 %t57)
  %t84 = getelementptr i8, ptr %t83, i64 %t57
  call void @olang_textcopy(ptr %t84, ptr %t59, i64 %t60)
  %t85 = getelementptr i8, ptr %t84, i64 %t60
  call void @olang_textcopy(ptr %t85, ptr %t63, i64 %t64)
  %t86 = getelementptr i8, ptr %t85, i64 %t64
  call void @olang_textcopy(ptr %t86, ptr %t66, i64 %t67)
  %t87 = getelementptr i8, ptr %t86, i64 %t67
  call void @olang_textcopy(ptr %t87, ptr %t70, i64 %t71)
  %t88 = getelementptr i8, ptr %t87, i64 %t71
  call void @olang_textcopy(ptr %t88, ptr %t73, i64 %t74)
  %t89 = getelementptr i8, ptr %t88, i64 %t74
  %t90 = call i64 @__olang_fmt_i64(ptr %t89, i64 %t52)
  %t91 = getelementptr i8, ptr %t89, i64 %t77
  call void @olang_textcopy(ptr %t91, ptr %t79, i64 %t80)
  %t92 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t82, 1
  %t97 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %v3, ptr %v4, ptr %t48, { i64, ptr } %t93)
  store { i64, ptr } %t97, ptr %l36
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t98, ptr %rv
  br label %ret
bb15:
  %t99 = load i1, ptr %l4, !tbaa !21
  br i1 %t99, label %bb16, label %bb17
bb16:
  store { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l38, !tbaa !27
  br label %bb18
bb17:
  %t101 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t101, ptr %l38, !tbaa !27
  br label %bb18
bb18:
  %t103 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t103, ptr %l9, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/emit:fnEm", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l41, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t109 = load ptr, ptr %l41, !tbaa !29
  %t110 = call ptr @__olang_scope_or(ptr %v4, ptr %t109)
  %t111 = call ptr @__olang_scope_hold(ptr %t110)
  %t112 = ptrtoint ptr %t111 to i64
  %t114 = inttoptr i64 %t112 to ptr
  %t115 = load ptr, ptr @__olang_prog_scope
  %t116 = load ptr, ptr %l41, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t114, ptr %t115, ptr %t116, { i64, ptr } %t108)
  br label %bb19
bb19:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t120 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t122 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t125 = extractvalue { i64, ptr } %t119, 1
  %t126 = extractvalue { i64, ptr } %t119, 0
  %t127 = add i64 %t123, %t126
  %t128 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t129 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t130 = add i64 %t127, %t129
  %t132 = extractvalue { i64, ptr } %t120, 1
  %t133 = extractvalue { i64, ptr } %t120, 0
  %t134 = add i64 %t130, %t133
  %t135 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = extractvalue { i64, ptr } %t121, 1
  %t140 = extractvalue { i64, ptr } %t121, 0
  %t141 = add i64 %t137, %t140
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d201, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t145 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t144)
  call void @olang_textcopy(ptr %t145, ptr %t122, i64 %t123)
  %t146 = getelementptr i8, ptr %t145, i64 %t123
  call void @olang_textcopy(ptr %t146, ptr %t125, i64 %t126)
  %t147 = getelementptr i8, ptr %t146, i64 %t126
  call void @olang_textcopy(ptr %t147, ptr %t128, i64 %t129)
  %t148 = getelementptr i8, ptr %t147, i64 %t129
  call void @olang_textcopy(ptr %t148, ptr %t132, i64 %t133)
  %t149 = getelementptr i8, ptr %t148, i64 %t133
  call void @olang_textcopy(ptr %t149, ptr %t135, i64 %t136)
  %t150 = getelementptr i8, ptr %t149, i64 %t136
  call void @olang_textcopy(ptr %t150, ptr %t139, i64 %t140)
  %t151 = getelementptr i8, ptr %t150, i64 %t140
  call void @olang_textcopy(ptr %t151, ptr %t142, i64 %t143)
  %t152 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t145, 1
  %t157 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t118, { i64, ptr } %t153)
  store { i64, ptr } %t157, ptr %l50
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t158 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t158, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2easPacked(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v3, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t11, ptr %l11, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 0
  store i64 %t13, ptr %l12, !tbaa !24
  %t14 = load i64, ptr %l12, !tbaa !24
  %t15 = mul i64 %t14, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = mul i64 %t23, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t20, ptr %t22, i64 %t24, i1 false)
  %t25 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t25, ptr %l11, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t26 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t26, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t32 = call i64 @__olang_fmt_i64(ptr null, i64 %t28)
  %t33 = add i64 %t30, %t32
  %t34 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t36)
  call void @olang_textcopy(ptr %t37, ptr %t29, i64 %t30)
  %t38 = getelementptr i8, ptr %t37, i64 %t30
  %t39 = call i64 @__olang_fmt_i64(ptr %t38, i64 %t28)
  %t40 = getelementptr i8, ptr %t38, i64 %t32
  call void @olang_textcopy(ptr %t40, ptr %t34, i64 %t35)
  %t41 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t37, 1
  %t46 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s0, ptr %s0, ptr %t27, { i64, ptr } %t42, i64 1)
  store { i64, ptr } %t46, ptr %l18
  br label %bb5
bb5:
  %t47 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t47, ptr %l4, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l3, !tbaa !24
  %t51 = mul i64 8, %t49
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t55 = call i64 @__olang_fmt_i64(ptr null, i64 %t51)
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t52, i64 %t53)
  %t58 = getelementptr i8, ptr %t57, i64 %t53
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t51)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t64 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %v1, ptr %s0, ptr %s0, ptr %v3, ptr %t48, { i64, ptr } %t61, { i64, ptr } %a1, { i64, ptr } %t64, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb6
bb6:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i64, ptr %l3, !tbaa !24
  %t71 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d207, i32 0, i32 1) }, 0
  %t74 = call i64 @__olang_fmt_i64(ptr null, i64 %t70)
  %t75 = add i64 %t72, %t74
  %t76 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 1
  %t77 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d208, i32 0, i32 1) }, 0
  %t78 = add i64 %t75, %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t71, i64 %t72)
  %t80 = getelementptr i8, ptr %t79, i64 %t72
  %t81 = call i64 @__olang_fmt_i64(ptr %t80, i64 %t70)
  %t82 = getelementptr i8, ptr %t80, i64 %t74
  call void @olang_textcopy(ptr %t82, ptr %t76, i64 %t77)
  %t83 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t79, 1
  %t86 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %v2, ptr %v3, ptr %t69, { i64, ptr } %t84, { i64, ptr } %t86, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store { i64, ptr } %t90, ptr %l31
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t91, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2ebufferCopy(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l27 = alloca i1
  %l33 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca ptr
  %l50 = alloca i32
  %l55 = alloca ptr
  %l58 = alloca i32
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca i32
  %l72 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l78 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l101 = alloca i1
  %l105 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca i32
  %l118 = alloca { i64, ptr }
  %l123 = alloca i64
  %l127 = alloca i64
  %l130 = alloca i64
  %l152 = alloca ptr
  %l159 = alloca { i64, ptr }
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca { i64, ptr }
  %l168 = alloca i32
  %l169 = alloca ptr
  %l172 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 0
  %t7 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t7, ptr %l2
  %t9 = load { i64, [2 x i64] }, ptr %l2
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 3
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb6
bb2:
  %t16 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t17 = getelementptr { i32, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load i32, ptr %t17, !range !{i32 0, i32 10}
  store i32 %t18, ptr %l3
  %t20 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t21 = getelementptr { i32, i32 }, ptr %t20, i32 0, i32 1
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l3, !range !{i32 0, i32 10}
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb3, label %bb4
bb3:
  %t31 = load i32, ptr %l3, !range !{i32 0, i32 10}
  %t33 = trunc i64 5 to i32
  %t34 = icmp eq i32 %t31, %t33
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l33, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t38 = load i1, ptr %l33, !tbaa !21
  store i1 %t38, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t39 = load i1, ptr %l27, !tbaa !21
  br i1 %t39, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t41 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t42 = getelementptr { i32, i32 }, ptr %t41, i32 0, i32 0
  %t43 = load i32, ptr %t42, !range !{i32 0, i32 10}
  store i32 %t43, ptr %l5
  %t45 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t46 = getelementptr { i32, i32 }, ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/emit:fnEm", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/emit:Emitter", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  store ptr %t55, ptr %l7, !tbaa !29
  %t57 = load ptr, ptr %l7, !tbaa !29
  store ptr %t57, ptr %l43, !tbaa !29
  %t59 = load ptr, ptr %l43, !tbaa !29
  %t60 = call ptr @__olang_scope_or(ptr %v1, ptr %t59)
  %t61 = call ptr @__olang_scope_hold(ptr %t60)
  %t62 = ptrtoint ptr %t61 to i64
  %t64 = inttoptr i64 %t62 to ptr
  %t65 = load ptr, ptr %l43, !tbaa !29
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t64, ptr %t65, i32 %t47)
  store i32 %t67, ptr %l46
  br label %bb10
bb10:
  %t68 = load i32, ptr %l46, !tbaa !23
  store i32 %t68, ptr %l8, !tbaa !23
  %t69 = load ptr, ptr %l7, !tbaa !29
  store ptr %t69, ptr %l47, !tbaa !29
  %t70 = load i32, ptr %l8, !tbaa !23
  %t71 = load ptr, ptr %l47, !tbaa !29
  %t72 = call ptr @__olang_scope_or(ptr %v1, ptr %t71)
  %t73 = call ptr @__olang_scope_hold(ptr %t72)
  %t74 = ptrtoint ptr %t73 to i64
  %t76 = inttoptr i64 %t74 to ptr
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t79 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t76, ptr %t77, i32 %t70)
  store i32 %t79, ptr %l50
  br label %bb11
bb11:
  %t80 = load i32, ptr %l50, !range !{i32 0, i32 33}
  %t82 = trunc i64 18 to i32
  %t83 = icmp eq i32 %t80, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t88 = load ptr, ptr %l7, !tbaa !29
  store ptr %t88, ptr %l55, !tbaa !29
  %t89 = load i32, ptr %l8, !tbaa !23
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = call ptr @__olang_scope_or(ptr %v1, ptr %t90)
  %t92 = call ptr @__olang_scope_hold(ptr %t91)
  %t93 = ptrtoint ptr %t92 to i64
  %t95 = inttoptr i64 %t93 to ptr
  %t96 = load ptr, ptr %l55, !tbaa !29
  %t98 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t95, ptr %t96, i32 %t89)
  store i32 %t98, ptr %l58
  br label %bb15
bb15:
  %t99 = load i32, ptr %l58, !tbaa !23
  store i32 %t99, ptr %l9, !tbaa !23
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/emit:fnEm", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/emit:Emitter", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 3
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t113 = load ptr, ptr %l7, !tbaa !29
  store ptr %t113, ptr %l64, !tbaa !29
  %t114 = load i32, ptr %l9, !tbaa !23
  %t115 = load ptr, ptr %l64, !tbaa !29
  %t116 = call ptr @__olang_scope_or(ptr %v1, ptr %t115)
  %t117 = call ptr @__olang_scope_hold(ptr %t116)
  %t118 = ptrtoint ptr %t117 to i64
  %t120 = inttoptr i64 %t118 to ptr
  %t121 = load ptr, ptr %l64, !tbaa !29
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %t120, ptr %t121, i32 %t114)
  store i32 %t123, ptr %l67
  br label %bb16
bb16:
  %t124 = load ptr, ptr %l63, !tbaa !29
  %t125 = call ptr @__olang_scope_or(ptr %v1, ptr %t124)
  %t126 = call ptr @__olang_scope_hold(ptr %t125)
  %t127 = ptrtoint ptr %t126 to i64
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/emit:fnEm", ptr %t128, i32 0, i32 0
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = call ptr @__olang_scope_or(ptr %v1, ptr %t131)
  %t134 = call ptr @__olang_scope_hold(ptr %t133)
  %t135 = ptrtoint ptr %t134 to i64
  %t137 = inttoptr i64 %t127 to ptr
  %t139 = inttoptr i64 %t135 to ptr
  %t140 = load ptr, ptr %l63, !tbaa !29
  %t141 = load i32, ptr %l67, !tbaa !23
  %t142 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t137, ptr %t139, ptr %t140, i32 %t141)
  store { i64, ptr } %t142, ptr %l72
  br label %bb17
bb17:
  %t143 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t143, ptr %l10, !tbaa !27
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t146 = getelementptr %"compiler/types:Table", ptr %t144, i32 0, i32 14
  store ptr %t146, ptr %l74, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  store ptr %t147, ptr %l75, !tbaa !29
  %t148 = load i32, ptr %l9, !tbaa !23
  %t149 = load ptr, ptr %l75, !tbaa !29
  %t150 = call ptr @__olang_scope_or(ptr %v1, ptr %t149)
  %t151 = call ptr @__olang_scope_hold(ptr %t150)
  %t152 = ptrtoint ptr %t151 to i64
  %t154 = inttoptr i64 %t152 to ptr
  %t155 = load ptr, ptr %l75, !tbaa !29
  %t157 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %t154, ptr %t155, i32 %t148)
  store i64 %t157, ptr %l78
  br label %bb18
bb18:
  %t158 = load ptr, ptr %l74, !tbaa !29
  %t159 = call ptr @__olang_scope_or(ptr %v1, ptr %t158)
  %t160 = call ptr @__olang_scope_hold(ptr %t159)
  %t161 = ptrtoint ptr %t160 to i64
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/emit:fnEm", ptr %t162, i32 0, i32 0
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = call ptr @__olang_scope_or(ptr %v1, ptr %t165)
  %t168 = call ptr @__olang_scope_hold(ptr %t167)
  %t169 = ptrtoint ptr %t168 to i64
  %t171 = inttoptr i64 %t161 to ptr
  %t173 = inttoptr i64 %t169 to ptr
  %t174 = load ptr, ptr %l74, !tbaa !29
  %t175 = load i64, ptr %l78, !tbaa !24
  %t176 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %t171, ptr %t173, ptr %t174, i64 %t175)
  store { i64, ptr } %t176, ptr %l83
  br label %bb19
bb19:
  %t177 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t177, ptr %l11, !tbaa !27
  %t178 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t178, ptr %l84, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = call ptr @__olang_scope_or(ptr %v1, ptr %t180)
  %t182 = call ptr @__olang_scope_hold(ptr %t181)
  %t183 = ptrtoint ptr %t182 to i64
  %t185 = inttoptr i64 %t183 to ptr
  %t186 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t187 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t185, ptr %s0, { i64, ptr } %t186, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d210, i32 0, i32 1) })
  store i1 %t187, ptr %l86
  br label %bb20
bb20:
  %t188 = load i1, ptr %l86, !tbaa !21
  br i1 %t188, label %bb21, label %bb22
bb21:
  %t189 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t189, ptr %l88, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 1
  %t192 = call ptr @__olang_scope_or(ptr %v1, ptr %t191)
  %t193 = call ptr @__olang_scope_hold(ptr %t192)
  %t194 = ptrtoint ptr %t193 to i64
  %t196 = inttoptr i64 %t194 to ptr
  %t197 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t196, ptr %s0, { i64, ptr } %t197, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d211, i32 0, i32 1) })
  store i1 %t198, ptr %l90
  br label %bb23
bb22:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb24
bb23:
  %t199 = load i1, ptr %l90, !tbaa !21
  store i1 %t199, ptr %l87, !tbaa !21
  br label %bb24
bb24:
  %t200 = load i1, ptr %l87, !tbaa !21
  br i1 %t200, label %bb25, label %bb26
bb25:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d212, i32 0, i32 1) }, ptr %l91, !tbaa !27
  br label %bb35
bb26:
  %t201 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t201, ptr %l92, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = call ptr @__olang_scope_or(ptr %v1, ptr %t203)
  %t205 = call ptr @__olang_scope_hold(ptr %t204)
  %t206 = ptrtoint ptr %t205 to i64
  %t208 = inttoptr i64 %t206 to ptr
  %t209 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t210 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t208, ptr %s0, { i64, ptr } %t209, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d213, i32 0, i32 1) })
  store i1 %t210, ptr %l94
  br label %bb27
bb27:
  %t211 = load i1, ptr %l94, !tbaa !21
  br i1 %t211, label %bb28, label %bb29
bb28:
  %t212 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t212, ptr %l96, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = call ptr @__olang_scope_or(ptr %v1, ptr %t214)
  %t216 = call ptr @__olang_scope_hold(ptr %t215)
  %t217 = ptrtoint ptr %t216 to i64
  %t219 = inttoptr i64 %t217 to ptr
  %t220 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t219, ptr %s0, { i64, ptr } %t220, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d214, i32 0, i32 1) })
  store i1 %t221, ptr %l98
  br label %bb30
bb29:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb31
bb30:
  %t222 = load i1, ptr %l98, !tbaa !21
  store i1 %t222, ptr %l95, !tbaa !21
  br label %bb31
bb31:
  %t223 = load i1, ptr %l95, !tbaa !21
  br i1 %t223, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l99, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d216, i32 0, i32 1) }, ptr %l99, !tbaa !27
  br label %bb34
bb34:
  %t224 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t224, ptr %l91, !tbaa !27
  br label %bb35
bb35:
  %t225 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t225, ptr %l12, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t227 = load ptr, ptr @__olang_prog_scope
  %t229 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t227, ptr %s0, { i64, ptr } %t226, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d217, i32 0, i32 1) })
  store i1 %t229, ptr %l101
  br label %bb36
bb36:
  %t230 = load i1, ptr %l101, !tbaa !21
  br i1 %t230, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/emit:fnEm", ptr %t232, i32 0, i32 0
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/emit:Emitter", ptr %t235, i32 0, i32 0
  %t238 = load ptr, ptr %t237, !tbaa !29
  store ptr %t238, ptr %l105, !tbaa !29
  %t239 = load i32, ptr %l8, !tbaa !23
  %t240 = load ptr, ptr %l105, !tbaa !29
  %t241 = call ptr @__olang_scope_or(ptr %v1, ptr %t240)
  %t242 = call ptr @__olang_scope_hold(ptr %t241)
  %t243 = ptrtoint ptr %t242 to i64
  %t245 = inttoptr i64 %t243 to ptr
  %t246 = load ptr, ptr %l105, !tbaa !29
  %t248 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %t245, ptr %s0, ptr %t246, i32 %t239)
  store { i64, ptr } %t248, ptr %l108
  br label %bb40
bb40:
  %t249 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t249, ptr %l13, !tbaa !27
  %t250 = load ptr, ptr %l7, !tbaa !29
  store ptr %t250, ptr %l109, !tbaa !29
  %t251 = load ptr, ptr %l7, !tbaa !29
  store ptr %t251, ptr %l110, !tbaa !29
  %t252 = load i32, ptr %l8, !tbaa !23
  %t253 = load ptr, ptr %l110, !tbaa !29
  %t254 = call ptr @__olang_scope_or(ptr %v1, ptr %t253)
  %t255 = call ptr @__olang_scope_hold(ptr %t254)
  %t256 = ptrtoint ptr %t255 to i64
  %t258 = inttoptr i64 %t256 to ptr
  %t259 = load ptr, ptr %l110, !tbaa !29
  %t261 = call i32 @compiler_2fmir_2eFieldsOf(ptr %t258, ptr %t259, i32 %t252)
  store i32 %t261, ptr %l113
  br label %bb41
bb41:
  %t262 = load ptr, ptr %l109, !tbaa !29
  %t263 = call ptr @__olang_scope_or(ptr %v1, ptr %t262)
  %t264 = call ptr @__olang_scope_hold(ptr %t263)
  %t265 = ptrtoint ptr %t264 to i64
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/emit:fnEm", ptr %t266, i32 0, i32 0
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t271 = call ptr @__olang_scope_or(ptr %v1, ptr %t269)
  %t272 = call ptr @__olang_scope_hold(ptr %t271)
  %t273 = ptrtoint ptr %t272 to i64
  %t275 = inttoptr i64 %t265 to ptr
  %t277 = inttoptr i64 %t273 to ptr
  %t278 = load ptr, ptr %l109, !tbaa !29
  %t279 = load i32, ptr %l113, !tbaa !23
  %t280 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t275, ptr %t277, ptr %t278, i32 %t279)
  store { i64, ptr } %t280, ptr %l118
  br label %bb42
bb42:
  %t281 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t281, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  %t290 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t284, i64 %t287)
  store i64 %t290, ptr %l123
  br label %bb43
bb43:
  %t291 = load i64, ptr %l123, !tbaa !24
  store i64 %t291, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t292 = load i64, ptr %l16, !tbaa !24
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = icmp sgt i64 %t292, %t293
  br i1 %t296, label %bb44, label %bb45
bb44:
  %t298 = load i64, ptr %l17, !tbaa !24
  %t300 = icmp sgt i64 %t298, 0
  br i1 %t300, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l127, !tbaa !24
  br label %bb49
bb46:
  %t302 = load i64, ptr %l16, !tbaa !24
  %t303 = load i64, ptr %l15, !tbaa !24
  %t306 = sub i64 %t302, %t303
  %t307 = load i64, ptr %l17, !tbaa !24
  %t310 = add i64 %t306, %t307
  %t312 = sub i64 %t310, 1
  %t313 = load i64, ptr %l17, !tbaa !24
  %t316 = sdiv i64 %t312, %t313
  store i64 %t316, ptr %l130, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l130, !tbaa !24
  br label %bb48
bb48:
  %t318 = load i64, ptr %l130, !tbaa !24
  store i64 %t318, ptr %l127, !tbaa !24
  br label %bb49
bb49:
  %t319 = load i64, ptr %l127, !tbaa !24
  store i64 %t319, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb50
bb50:
  %t320 = load i64, ptr %l19, !tbaa !24
  %t321 = load i64, ptr %l18, !tbaa !24
  %t324 = icmp slt i64 %t320, %t321
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb51, label %bb52
bb51:
  br label %bb62
bb52:
  br label %bb53
bb53:
  %t328 = load i64, ptr %l15, !tbaa !24
  %t329 = load i64, ptr %l19, !tbaa !24
  %t330 = load i64, ptr %l17, !tbaa !24
  %t333 = mul i64 %t329, %t330
  %t336 = add i64 %t328, %t333
  store i64 %t336, ptr %l20, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/emit:fnEm", ptr %t338, i32 0, i32 0
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = getelementptr %"compiler/emit:Emitter", ptr %t341, i32 0, i32 0
  %t344 = load ptr, ptr %t343, !tbaa !29
  %t346 = getelementptr %"compiler/generic:Program", ptr %t344, i32 0, i32 0
  %t347 = load ptr, ptr %t346, !tbaa !29
  %t349 = getelementptr %"compiler/load:Loader", ptr %t347, i32 0, i32 3
  %t350 = load ptr, ptr %t349, !tbaa !29
  store ptr %t350, ptr %l152, !tbaa !29
  %t351 = load i64, ptr %l20, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr i32, ptr %t354, i64 %t351
  %t356 = load i32, ptr %t355, !tbaa !33
  %t357 = load ptr, ptr %l152, !tbaa !29
  %t358 = call ptr @__olang_scope_or(ptr %v1, ptr %t357)
  %t359 = call ptr @__olang_scope_hold(ptr %t358)
  %t360 = ptrtoint ptr %t359 to i64
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/emit:fnEm", ptr %t361, i32 0, i32 0
  %t364 = load ptr, ptr %t363, !tbaa !29
  %t366 = call ptr @__olang_scope_or(ptr %v1, ptr %t364)
  %t367 = call ptr @__olang_scope_hold(ptr %t366)
  %t368 = ptrtoint ptr %t367 to i64
  %t370 = inttoptr i64 %t360 to ptr
  %t372 = inttoptr i64 %t368 to ptr
  %t373 = load ptr, ptr %l152, !tbaa !29
  %t375 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t370, ptr %t372, ptr %t373, i32 %t356)
  store { i64, ptr } %t375, ptr %l159
  br label %bb54
bb54:
  %t376 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t378 = extractvalue { i64, ptr } %t377, 1
  %t379 = call ptr @__olang_scope_or(ptr %v1, ptr %t378)
  %t380 = call ptr @__olang_scope_hold(ptr %t379)
  %t381 = ptrtoint ptr %t380 to i64
  %t383 = inttoptr i64 %t381 to ptr
  %t384 = load ptr, ptr @__olang_prog_scope
  %t385 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t387 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t383, ptr %t384, { i64, ptr } %t385, { i64, ptr } %t376)
  store i1 %t387, ptr %l162
  br label %bb55
bb55:
  %t388 = load i1, ptr %l162, !tbaa !21
  br i1 %t388, label %bb56, label %bb57
bb56:
  %t389 = load ptr, ptr %l7, !tbaa !29
  store ptr %t389, ptr %l163, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t390, ptr %l164, !tbaa !27
  %t391 = load i64, ptr %l20, !tbaa !24
  %t393 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t394 = load ptr, ptr %t393, !tbaa !27
  %t395 = getelementptr i32, ptr %t394, i64 %t391
  %t396 = load i32, ptr %t395, !tbaa !33
  %t397 = load ptr, ptr %l163, !tbaa !29
  %t398 = call ptr @__olang_scope_or(ptr %v1, ptr %t397)
  %t399 = call ptr @__olang_scope_hold(ptr %t398)
  %t400 = ptrtoint ptr %t399 to i64
  %t402 = inttoptr i64 %t400 to ptr
  %t403 = load ptr, ptr %l163, !tbaa !29
  %t405 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t402, ptr %t403, i32 %t396)
  store i32 %t405, ptr %l168
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t406 = load ptr, ptr %l7, !tbaa !29
  store ptr %t406, ptr %l169, !tbaa !29
  %t408 = load ptr, ptr %l169, !tbaa !29
  %t409 = call ptr @__olang_scope_or(ptr %v1, ptr %t408)
  %t410 = call ptr @__olang_scope_hold(ptr %t409)
  %t411 = ptrtoint ptr %t410 to i64
  %t413 = inttoptr i64 %t411 to ptr
  %t414 = load ptr, ptr %l169, !tbaa !29
  %t416 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t413, ptr %t414, i32 %a1)
  store i32 %t416, ptr %l172
  br label %bb59
bb59:
  %t417 = load i32, ptr %l168, !tbaa !23
  %t418 = load i32, ptr %l172, !tbaa !23
  %t419 = icmp eq i32 %t417, %t418
  call void @__olang_scope_close(ptr %s0)
  store i1 %t419, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t421 = load i64, ptr %l19, !tbaa !24
  %t424 = add i64 %t421, 1
  store i64 %t424, ptr %l19, !tbaa !24
  br label %bb50
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eclauses(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i64 %a5, i64 %a6, { i64, ptr } %a7, i64 %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/mir:Task"
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca %"compiler/mir:TaskClause"
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca %"compiler/typed:Item"
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/text:StringBuilder"
  %l33 = alloca i32
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l51 = alloca i32
  %l57 = alloca i32
  %l60 = alloca i32
  %l80 = alloca ptr
  %l87 = alloca %"compiler/mir:TaskClause"
  %l88 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l100 = alloca i32
  %l103 = alloca i32
  %l123 = alloca ptr
  %l130 = alloca %"compiler/typed:Item"
  %l131 = alloca ptr
  %l135 = alloca i64
  %l164 = alloca i64
  %l167 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l191 = alloca { i64, ptr }
  %l193 = alloca i1
  %l195 = alloca ptr
  %l214 = alloca i32
  %l215 = alloca ptr
  %l230 = alloca %"std/prelude/text:StringBuilder"
  %l235 = alloca ptr
  %l238 = alloca i32
  %l242 = alloca i1
  %l246 = alloca i1
  %l247 = alloca ptr
  %l250 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i32
  %l254 = alloca ptr
  %l257 = alloca { i64, ptr }
  %l264 = alloca ptr
  %l269 = alloca i64
  %l273 = alloca i64
  %l276 = alloca i64
  %l294 = alloca ptr
  %l330 = alloca ptr
  %l334 = alloca { i64, ptr }
  %l335 = alloca { i64, ptr }
  %l338 = alloca i1
  %l339 = alloca ptr
  %l340 = alloca i32
  %l342 = alloca { i64, ptr }
  %l345 = alloca ptr
  %l346 = alloca i32
  %l347 = alloca { i64, ptr }
  %l348 = alloca i32
  %l350 = alloca { i64, ptr }
  %l353 = alloca i64
  %l356 = alloca { i64, ptr }
  %l360 = alloca { i64, ptr }
  %l363 = alloca ptr
  %l364 = alloca i32
  %l365 = alloca ptr
  %l368 = alloca { i64, ptr }
  %l372 = alloca i64
  %l375 = alloca { i64, ptr }
  %l379 = alloca { i64, ptr }
  %l382 = alloca i1
  %l384 = alloca i1
  %l389 = alloca ptr
  %l390 = alloca i32
  %l391 = alloca i64
  %l392 = alloca ptr
  %l395 = alloca { i64, ptr }
  %l411 = alloca %"compiler/mir:Task"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %t825 = alloca { i64, [4 x i64] }, align 8
  %t828 = alloca { i64, [7 x i64] }, align 8
  %t1450 = alloca %"compiler/mir:Task", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %a3, i64 144, i1 false)
  store i64 %a6, ptr %l6
  store i64 %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l9, !tbaa !29
  %t6 = load ptr, ptr %l9, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 3
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l10, !tbaa !29
  %t11 = load ptr, ptr %l10, !tbaa !29
  store ptr %t11, ptr %l48, !tbaa !29
  %t13 = load ptr, ptr %l48, !tbaa !29
  %t14 = call ptr @__olang_scope_or(ptr %v4, ptr %t13)
  %t15 = call ptr @__olang_scope_hold(ptr %t14)
  %t16 = ptrtoint ptr %t15 to i64
  %t18 = inttoptr i64 %t16 to ptr
  %t19 = load ptr, ptr %l48, !tbaa !29
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %t18, ptr %t19, i32 %a4)
  store i32 %t21, ptr %l51
  br label %bb1
bb1:
  %t22 = load i32, ptr %l51, !tbaa !23
  store i32 %t22, ptr %l11, !tbaa !23
  store i64 %a5, ptr %l12, !tbaa !24
  store i32 0, ptr %l13, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t26 = getelementptr %"compiler/mir:Range", ptr %t25, i32 0, i32 1
  %t27 = load i32, ptr %t26, !tbaa !23
  store i32 %t27, ptr %l14, !tbaa !23
  store i32 1, ptr %l15, !tbaa !23
  %t29 = load i32, ptr %l14, !tbaa !23
  %t30 = load i32, ptr %l13, !tbaa !23
  %t33 = icmp sgt i32 %t29, %t30
  br i1 %t33, label %bb2, label %bb3
bb2:
  %t35 = load i32, ptr %l15, !tbaa !23
  %t37 = icmp sgt i32 %t35, 0
  br i1 %t37, label %bb4, label %bb5
bb3:
  store i32 0, ptr %l57, !tbaa !23
  br label %bb7
bb4:
  %t39 = load i32, ptr %l14, !tbaa !23
  %t40 = load i32, ptr %l13, !tbaa !23
  %t43 = sub i32 %t39, %t40
  %t44 = load i32, ptr %l15, !tbaa !23
  %t47 = add i32 %t43, %t44
  %t49 = sub i32 %t47, 1
  %t50 = load i32, ptr %l15, !tbaa !23
  %t53 = sdiv i32 %t49, %t50
  store i32 %t53, ptr %l60, !tbaa !23
  br label %bb6
bb5:
  store i32 0, ptr %l60, !tbaa !23
  br label %bb6
bb6:
  %t55 = load i32, ptr %l60, !tbaa !23
  store i32 %t55, ptr %l57, !tbaa !23
  br label %bb7
bb7:
  %t56 = load i32, ptr %l57, !tbaa !23
  store i32 %t56, ptr %l16, !tbaa !23
  store i32 0, ptr %l17, !tbaa !23
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = load i32, ptr %l17, !tbaa !23
  %t58 = load i32, ptr %l16, !tbaa !23
  %t61 = icmp slt i32 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb146
bb10:
  br label %bb11
bb11:
  %t65 = load i32, ptr %l13, !tbaa !23
  %t66 = load i32, ptr %l17, !tbaa !23
  %t67 = load i32, ptr %l15, !tbaa !23
  %t70 = mul i32 %t66, %t67
  %t73 = add i32 %t65, %t70
  store i32 %t73, ptr %l18, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/mir:Fn", ptr %t78, i32 0, i32 17
  store ptr %t80, ptr %l80, !tbaa !29
  %t81 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 4
  %t82 = getelementptr %"compiler/mir:Range", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t85 = sext i32 %t83 to i64
  %t86 = load i32, ptr %l18, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t91 = add i64 %t85, %t88
  %t92 = load ptr, ptr %l80, !tbaa !29
  %t93 = call ptr @__olang_scope_or(ptr %v5, ptr %t92)
  %t94 = call ptr @__olang_scope_hold(ptr %t93)
  %t95 = ptrtoint ptr %t94 to i64
  %t97 = inttoptr i64 %t95 to ptr
  %t98 = load ptr, ptr %l80, !tbaa !29
  %t100 = call %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %t97, ptr %t98, i64 %t91)
  store %"compiler/mir:TaskClause" %t100, ptr %l87
  br label %bb12
bb12:
  %t101 = load %"compiler/mir:TaskClause", ptr %l87
  store %"compiler/mir:TaskClause" %t101, ptr %l19
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d218, i32 0, i32 1) }, ptr %l88, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t102, ptr %l20, !tbaa !27
  %t104 = getelementptr %"compiler/mir:TaskClause", ptr %l19, i32 0, i32 1
  %t105 = load i1, ptr %t104, !tbaa !21
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d219, i32 0, i32 1) }, ptr %l92, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t110, ptr %l94, !tbaa !27
  store { i64, ptr } %t109, ptr %l20, !tbaa !27
  %t112 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e20
  br i1 %t112, label %bb15, label %bb16
bb14:
  br label %bb45
bb15:
  %t114 = load { i64, ptr }, ptr %l94
  %t115 = extractvalue { i64, ptr } %t114, 1
  call void @__olang_region_release(ptr %t115)
  store { i64, ptr } zeroinitializer, ptr %l94
  br label %bb16
bb16:
  store i32 0, ptr %l21, !tbaa !23
  %t116 = getelementptr %"compiler/mir:TaskClause", ptr %l19, i32 0, i32 0
  %t117 = getelementptr %"compiler/mir:Range", ptr %t116, i32 0, i32 1
  %t118 = load i32, ptr %t117, !tbaa !23
  store i32 %t118, ptr %l22, !tbaa !23
  store i32 1, ptr %l23, !tbaa !23
  %t120 = load i32, ptr %l22, !tbaa !23
  %t121 = load i32, ptr %l21, !tbaa !23
  %t124 = icmp sgt i32 %t120, %t121
  br i1 %t124, label %bb17, label %bb18
bb17:
  %t126 = load i32, ptr %l23, !tbaa !23
  %t128 = icmp sgt i32 %t126, 0
  br i1 %t128, label %bb19, label %bb20
bb18:
  store i32 0, ptr %l100, !tbaa !23
  br label %bb22
bb19:
  %t130 = load i32, ptr %l22, !tbaa !23
  %t131 = load i32, ptr %l21, !tbaa !23
  %t134 = sub i32 %t130, %t131
  %t135 = load i32, ptr %l23, !tbaa !23
  %t138 = add i32 %t134, %t135
  %t140 = sub i32 %t138, 1
  %t141 = load i32, ptr %l23, !tbaa !23
  %t144 = sdiv i32 %t140, %t141
  store i32 %t144, ptr %l103, !tbaa !23
  br label %bb21
bb20:
  store i32 0, ptr %l103, !tbaa !23
  br label %bb21
bb21:
  %t146 = load i32, ptr %l103, !tbaa !23
  store i32 %t146, ptr %l100, !tbaa !23
  br label %bb22
bb22:
  %t147 = load i32, ptr %l100, !tbaa !23
  store i32 %t147, ptr %l24, !tbaa !23
  store i32 0, ptr %l25, !tbaa !23
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load i32, ptr %l25, !tbaa !23
  %t149 = load i32, ptr %l24, !tbaa !23
  %t152 = icmp slt i32 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb44
bb25:
  br label %bb26
bb26:
  %t156 = load i32, ptr %l21, !tbaa !23
  %t157 = load i32, ptr %l25, !tbaa !23
  %t158 = load i32, ptr %l23, !tbaa !23
  %t161 = mul i32 %t157, %t158
  %t164 = add i32 %t156, %t161
  store i32 %t164, ptr %l26, !tbaa !23
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = getelementptr %"compiler/emit:fnEm", ptr %t166, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = getelementptr %"compiler/mir:Fn", ptr %t169, i32 0, i32 18
  store ptr %t171, ptr %l123, !tbaa !29
  %t172 = getelementptr %"compiler/mir:TaskClause", ptr %l19, i32 0, i32 0
  %t173 = getelementptr %"compiler/mir:Range", ptr %t172, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  %t176 = sext i32 %t174 to i64
  %t177 = load i32, ptr %l26, !tbaa !23
  %t179 = sext i32 %t177 to i64
  %t182 = add i64 %t176, %t179
  %t183 = load ptr, ptr %l123, !tbaa !29
  %t184 = call ptr @__olang_scope_or(ptr %v5, ptr %t183)
  %t185 = call ptr @__olang_scope_hold(ptr %t184)
  %t186 = ptrtoint ptr %t185 to i64
  %t188 = inttoptr i64 %t186 to ptr
  %t189 = load ptr, ptr %l123, !tbaa !29
  %t191 = call %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %t188, ptr %t189, i64 %t182)
  store %"compiler/typed:Item" %t191, ptr %l130
  br label %bb27
bb27:
  %t192 = load %"compiler/typed:Item", ptr %l130
  store %"compiler/typed:Item" %t192, ptr %l27
  %t193 = load ptr, ptr %l9, !tbaa !29
  store ptr %t193, ptr %l131, !tbaa !29
  %t194 = load i32, ptr %l11, !tbaa !23
  %t195 = getelementptr %"compiler/typed:Item", ptr %l27, i32 0, i32 0
  %t196 = load i32, ptr %t195, !tbaa !23
  %t197 = load ptr, ptr %l131, !tbaa !29
  %t198 = call ptr @__olang_scope_or(ptr %v4, ptr %t197)
  %t199 = call ptr @__olang_scope_hold(ptr %t198)
  %t200 = ptrtoint ptr %t199 to i64
  %t202 = inttoptr i64 %t200 to ptr
  %t203 = load ptr, ptr %l131, !tbaa !29
  %t206 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %t202, ptr %t203, i32 %t194, i32 %t196)
  store i64 %t206, ptr %l135
  br label %bb28
bb28:
  %t207 = load i64, ptr %l135, !tbaa !24
  store i64 %t207, ptr %l28, !tbaa !24
  %t208 = load i32, ptr %l18, !tbaa !23
  %t209 = load i32, ptr %l26, !tbaa !23
  %t210 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t213 = sext i32 %t208 to i64
  %t214 = call i64 @__olang_fmt_i64(ptr null, i64 %t213)
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t220 = sext i32 %t209 to i64
  %t221 = call i64 @__olang_fmt_i64(ptr null, i64 %t220)
  %t222 = add i64 %t218, %t221
  %t223 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t222)
  call void @olang_textcopy(ptr %t223, ptr %t210, i64 %t211)
  %t224 = getelementptr i8, ptr %t223, i64 %t211
  %t225 = call i64 @__olang_fmt_i64(ptr %t224, i64 %t213)
  %t226 = getelementptr i8, ptr %t224, i64 %t214
  call void @olang_textcopy(ptr %t226, ptr %t216, i64 %t217)
  %t227 = getelementptr i8, ptr %t226, i64 %t217
  %t228 = call i64 @__olang_fmt_i64(ptr %t227, i64 %t220)
  %t229 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t223, 1
  store { i64, ptr } %t230, ptr %l29, !tbaa !27
  %t232 = getelementptr %"compiler/typed:Item", ptr %l27, i32 0, i32 1
  %t233 = load i64, ptr %t232, !tbaa !24
  %t235 = icmp slt i64 %t233, 0
  br i1 %t235, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s7
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t242 = load i64, ptr %l28, !tbaa !24
  %t243 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t244 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t246 = extractvalue { i64, ptr } %t238, 1
  %t247 = extractvalue { i64, ptr } %t238, 0
  %t248 = add i64 %t244, %t247
  %t249 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t251 = add i64 %t248, %t250
  %t253 = extractvalue { i64, ptr } %t239, 1
  %t254 = extractvalue { i64, ptr } %t239, 0
  %t255 = add i64 %t251, %t254
  %t256 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t258 = add i64 %t255, %t257
  %t260 = extractvalue { i64, ptr } %t240, 1
  %t261 = extractvalue { i64, ptr } %t240, 0
  %t262 = add i64 %t258, %t261
  %t263 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d225, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d225, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t267 = extractvalue { i64, ptr } %t241, 1
  %t268 = extractvalue { i64, ptr } %t241, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t274 = call i64 @__olang_fmt_i64(ptr null, i64 %t242)
  %t275 = add i64 %t272, %t274
  %t276 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t278 = add i64 %t275, %t277
  %t279 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t278)
  call void @olang_textcopy(ptr %t279, ptr %t243, i64 %t244)
  %t280 = getelementptr i8, ptr %t279, i64 %t244
  call void @olang_textcopy(ptr %t280, ptr %t246, i64 %t247)
  %t281 = getelementptr i8, ptr %t280, i64 %t247
  call void @olang_textcopy(ptr %t281, ptr %t249, i64 %t250)
  %t282 = getelementptr i8, ptr %t281, i64 %t250
  call void @olang_textcopy(ptr %t282, ptr %t253, i64 %t254)
  %t283 = getelementptr i8, ptr %t282, i64 %t254
  call void @olang_textcopy(ptr %t283, ptr %t256, i64 %t257)
  %t284 = getelementptr i8, ptr %t283, i64 %t257
  call void @olang_textcopy(ptr %t284, ptr %t260, i64 %t261)
  %t285 = getelementptr i8, ptr %t284, i64 %t261
  call void @olang_textcopy(ptr %t285, ptr %t263, i64 %t264)
  %t286 = getelementptr i8, ptr %t285, i64 %t264
  call void @olang_textcopy(ptr %t286, ptr %t267, i64 %t268)
  %t287 = getelementptr i8, ptr %t286, i64 %t268
  call void @olang_textcopy(ptr %t287, ptr %t270, i64 %t271)
  %t288 = getelementptr i8, ptr %t287, i64 %t271
  %t289 = call i64 @__olang_fmt_i64(ptr %t288, i64 %t242)
  %t290 = getelementptr i8, ptr %t288, i64 %t274
  call void @olang_textcopy(ptr %t290, ptr %t276, i64 %t277)
  %t291 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t279, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t237, { i64, ptr } %t292)
  br label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t296 = load ptr, ptr %l1, !tbaa !29
  %t297 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t299 = load i64, ptr %l28, !tbaa !24
  %t301 = shl i64 %t299, 16
  %t302 = getelementptr %"compiler/typed:Item", ptr %l27, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  %t306 = or i64 %t301, %t303
  %t307 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t308 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t310 = extractvalue { i64, ptr } %t297, 1
  %t311 = extractvalue { i64, ptr } %t297, 0
  %t312 = add i64 %t308, %t311
  %t313 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t315 = add i64 %t312, %t314
  %t317 = extractvalue { i64, ptr } %t298, 1
  %t318 = extractvalue { i64, ptr } %t298, 0
  %t319 = add i64 %t315, %t318
  %t320 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t321 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t322 = add i64 %t319, %t321
  %t324 = call i64 @__olang_fmt_i64(ptr null, i64 %t306)
  %t325 = add i64 %t322, %t324
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d231, i32 0, i32 1) }, 1
  %t327 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d231, i32 0, i32 1) }, 0
  %t328 = add i64 %t325, %t327
  %t329 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t307, i64 %t308)
  %t330 = getelementptr i8, ptr %t329, i64 %t308
  call void @olang_textcopy(ptr %t330, ptr %t310, i64 %t311)
  %t331 = getelementptr i8, ptr %t330, i64 %t311
  call void @olang_textcopy(ptr %t331, ptr %t313, i64 %t314)
  %t332 = getelementptr i8, ptr %t331, i64 %t314
  call void @olang_textcopy(ptr %t332, ptr %t317, i64 %t318)
  %t333 = getelementptr i8, ptr %t332, i64 %t318
  call void @olang_textcopy(ptr %t333, ptr %t320, i64 %t321)
  %t334 = getelementptr i8, ptr %t333, i64 %t321
  %t335 = call i64 @__olang_fmt_i64(ptr %t334, i64 %t306)
  %t336 = getelementptr i8, ptr %t334, i64 %t324
  call void @olang_textcopy(ptr %t336, ptr %t326, i64 %t327)
  %t337 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t329, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s9, ptr %t296, { i64, ptr } %t338)
  br label %bb32
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  %t342 = load ptr, ptr %l1, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t346 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t349 = extractvalue { i64, ptr } %t343, 1
  %t350 = extractvalue { i64, ptr } %t343, 0
  %t351 = add i64 %t347, %t350
  %t352 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t353 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t354 = add i64 %t351, %t353
  %t356 = extractvalue { i64, ptr } %t344, 1
  %t357 = extractvalue { i64, ptr } %t344, 0
  %t358 = add i64 %t354, %t357
  %t359 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 1
  %t360 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d234, i32 0, i32 1) }, 0
  %t361 = add i64 %t358, %t360
  %t363 = extractvalue { i64, ptr } %t345, 1
  %t364 = extractvalue { i64, ptr } %t345, 0
  %t365 = add i64 %t361, %t364
  %t366 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t367 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t368 = add i64 %t365, %t367
  %t369 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t346, i64 %t347)
  %t370 = getelementptr i8, ptr %t369, i64 %t347
  call void @olang_textcopy(ptr %t370, ptr %t349, i64 %t350)
  %t371 = getelementptr i8, ptr %t370, i64 %t350
  call void @olang_textcopy(ptr %t371, ptr %t352, i64 %t353)
  %t372 = getelementptr i8, ptr %t371, i64 %t353
  call void @olang_textcopy(ptr %t372, ptr %t356, i64 %t357)
  %t373 = getelementptr i8, ptr %t372, i64 %t357
  call void @olang_textcopy(ptr %t373, ptr %t359, i64 %t360)
  %t374 = getelementptr i8, ptr %t373, i64 %t360
  call void @olang_textcopy(ptr %t374, ptr %t363, i64 %t364)
  %t375 = getelementptr i8, ptr %t374, i64 %t364
  call void @olang_textcopy(ptr %t375, ptr %t366, i64 %t367)
  %t376 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t377 = insertvalue { i64, ptr } %t376, ptr %t369, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t342, { i64, ptr } %t377)
  br label %bb34
bb34:
  %t381 = call ptr @__olang_scope_hold(ptr %s2)
  %t382 = ptrtoint ptr %t381 to i64
  store i64 %t382, ptr %l164, !tbaa !24
  %t383 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e20
  br i1 %t383, label %bb35, label %bb36
bb35:
  %t385 = call ptr @__olang_region_make(ptr %s2)
  %t386 = ptrtoint ptr %t385 to i64
  store i64 %t386, ptr %l164, !tbaa !24
  br label %bb36
bb36:
  %t387 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 1
  %t390 = extractvalue { i64, ptr } %t387, 0
  %t391 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t393 = add i64 %t390, %t392
  %t394 = load i64, ptr %l164
  %t395 = inttoptr i64 %t394 to ptr
  %t396 = call ptr @__olang_held_alloc(ptr %t395, i64 %t393)
  call void @olang_textcopy(ptr %t396, ptr %t389, i64 %t390)
  %t397 = getelementptr i8, ptr %t396, i64 %t390
  call void @olang_textcopy(ptr %t397, ptr %t391, i64 %t392)
  %t398 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t396, 1
  store { i64, ptr } %t399, ptr %l167, !tbaa !27
  %t400 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e20
  br i1 %t400, label %bb37, label %bb38
bb37:
  %t402 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t403 = extractvalue { i64, ptr } %t402, 0
  %t405 = icmp eq i64 %t403, 0
  br i1 %t405, label %bb39, label %bb40
bb38:
  %t407 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t407, ptr %l171, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t408, ptr %l20, !tbaa !27
  %t409 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e20
  br i1 %t409, label %bb41, label %bb42
bb39:
  store { i64, ptr } zeroinitializer, ptr %l167, !tbaa !27
  br label %bb40
bb40:
  %t411 = load i64, ptr %l164
  %t412 = inttoptr i64 %t411 to ptr
  %t413 = load { i64, ptr }, ptr %l167
  %t414 = extractvalue { i64, ptr } %t413, 1
  %t415 = call ptr @__olang_region_or(ptr %t414, ptr null)
  %t416 = icmp ne ptr %t415, null
  %t417 = select i1 %t416, ptr %t415, ptr null
  call void @__olang_region_settle_in(ptr %t412, ptr %t417)
  br label %bb38
bb41:
  %t418 = load { i64, ptr }, ptr %l171
  %t419 = extractvalue { i64, ptr } %t418, 1
  call void @__olang_region_release(ptr %t419)
  store { i64, ptr } zeroinitializer, ptr %l171
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb43:
  %t420 = load i32, ptr %l25, !tbaa !23
  %t423 = add i32 %t420, 1
  store i32 %t423, ptr %l25, !tbaa !23
  br label %bb23
bb44:
  br label %bb45
bb45:
  %t425 = load ptr, ptr %l1, !tbaa !29
  %t426 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t427 = load i32, ptr %l18, !tbaa !23
  %t428 = load i32, ptr %l18, !tbaa !23
  %t429 = load i32, ptr %l18, !tbaa !23
  %t430 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d237, i32 0, i32 1) }, 1
  %t431 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d237, i32 0, i32 1) }, 0
  %t433 = extractvalue { i64, ptr } %t426, 1
  %t434 = extractvalue { i64, ptr } %t426, 0
  %t435 = add i64 %t431, %t434
  %t436 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d238, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d238, i32 0, i32 1) }, 0
  %t438 = add i64 %t435, %t437
  %t440 = sext i32 %t427 to i64
  %t441 = call i64 @__olang_fmt_i64(ptr null, i64 %t440)
  %t442 = add i64 %t438, %t441
  %t443 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t447 = sext i32 %t428 to i64
  %t448 = call i64 @__olang_fmt_i64(ptr null, i64 %t447)
  %t449 = add i64 %t445, %t448
  %t450 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t454 = sext i32 %t429 to i64
  %t455 = call i64 @__olang_fmt_i64(ptr null, i64 %t454)
  %t456 = add i64 %t452, %t455
  %t457 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t458 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t459 = add i64 %t456, %t458
  %t460 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t459)
  call void @olang_textcopy(ptr %t460, ptr %t430, i64 %t431)
  %t461 = getelementptr i8, ptr %t460, i64 %t431
  call void @olang_textcopy(ptr %t461, ptr %t433, i64 %t434)
  %t462 = getelementptr i8, ptr %t461, i64 %t434
  call void @olang_textcopy(ptr %t462, ptr %t436, i64 %t437)
  %t463 = getelementptr i8, ptr %t462, i64 %t437
  %t464 = call i64 @__olang_fmt_i64(ptr %t463, i64 %t440)
  %t465 = getelementptr i8, ptr %t463, i64 %t441
  call void @olang_textcopy(ptr %t465, ptr %t443, i64 %t444)
  %t466 = getelementptr i8, ptr %t465, i64 %t444
  %t467 = call i64 @__olang_fmt_i64(ptr %t466, i64 %t447)
  %t468 = getelementptr i8, ptr %t466, i64 %t448
  call void @olang_textcopy(ptr %t468, ptr %t450, i64 %t451)
  %t469 = getelementptr i8, ptr %t468, i64 %t451
  %t470 = call i64 @__olang_fmt_i64(ptr %t469, i64 %t454)
  %t471 = getelementptr i8, ptr %t469, i64 %t455
  call void @olang_textcopy(ptr %t471, ptr %t457, i64 %t458)
  %t472 = insertvalue { i64, ptr } undef, i64 %t459, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t460, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t425, { i64, ptr } %t473)
  br label %bb46
bb46:
  %t477 = load ptr, ptr %l9, !tbaa !29
  store ptr %t477, ptr %l183, !tbaa !29
  %t478 = load ptr, ptr %l1, !tbaa !29
  %t479 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t480 = load i32, ptr %l11, !tbaa !23
  %t481 = load i32, ptr %l18, !tbaa !23
  %t482 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 1
  %t483 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d242, i32 0, i32 1) }, 0
  %t485 = sext i32 %t481 to i64
  %t486 = call i64 @__olang_fmt_i64(ptr null, i64 %t485)
  %t487 = add i64 %t483, %t486
  %t488 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t487)
  call void @olang_textcopy(ptr %t488, ptr %t482, i64 %t483)
  %t489 = getelementptr i8, ptr %t488, i64 %t483
  %t490 = call i64 @__olang_fmt_i64(ptr %t489, i64 %t485)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t488, 1
  %t494 = load ptr, ptr %l183, !tbaa !29
  %t495 = call ptr @__olang_scope_or(ptr %v4, ptr %t494)
  %t496 = call ptr @__olang_scope_hold(ptr %t495)
  %t497 = ptrtoint ptr %t496 to i64
  %t499 = inttoptr i64 %t497 to ptr
  %t500 = load ptr, ptr %l183, !tbaa !29
  %t505 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecarriesText(ptr %t499, ptr %v1, ptr %v2, ptr %s2, ptr %s2, ptr %t500, ptr %t478, { i64, ptr } %t479, i32 %t480, { i64, ptr } %t492)
  store { i64, ptr } %t505, ptr %l191
  br label %bb47
bb47:
  %t506 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t506, ptr %l30, !tbaa !27
  %t507 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t509 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t507, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d243, i32 0, i32 1) })
  store i1 %t509, ptr %l193
  br label %bb48
bb48:
  %t510 = load i1, ptr %l193, !tbaa !21
  %t511 = xor i1 %t510, true
  br i1 %t511, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s16
  %t513 = load ptr, ptr %l9, !tbaa !29
  store ptr %t513, ptr %l195, !tbaa !29
  %t514 = load ptr, ptr %l195, !tbaa !29
  %t515 = call ptr @__olang_scope_or(ptr %v4, ptr %t514)
  %t516 = call ptr @__olang_scope_hold(ptr %t515)
  %t517 = ptrtoint ptr %t516 to i64
  %t519 = inttoptr i64 %t517 to ptr
  %t520 = load ptr, ptr %l195, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t519, ptr %s16, ptr %t520, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d244, i32 0, i32 1) })
  br label %bb51
bb50:
  br label %bb54
bb51:
  %t521 = load ptr, ptr %l1, !tbaa !29
  %t522 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t523 = load i32, ptr %l18, !tbaa !23
  %t524 = load i32, ptr %l18, !tbaa !23
  %t525 = load i32, ptr %l18, !tbaa !23
  %t526 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d245, i32 0, i32 1) }, 1
  %t527 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d245, i32 0, i32 1) }, 0
  %t529 = extractvalue { i64, ptr } %t522, 1
  %t530 = extractvalue { i64, ptr } %t522, 0
  %t531 = add i64 %t527, %t530
  %t532 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t533 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t534 = add i64 %t531, %t533
  %t536 = sext i32 %t523 to i64
  %t537 = call i64 @__olang_fmt_i64(ptr null, i64 %t536)
  %t538 = add i64 %t534, %t537
  %t539 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t540 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t541 = add i64 %t538, %t540
  %t543 = sext i32 %t524 to i64
  %t544 = call i64 @__olang_fmt_i64(ptr null, i64 %t543)
  %t545 = add i64 %t541, %t544
  %t546 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d248, i32 0, i32 1) }, 1
  %t547 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d248, i32 0, i32 1) }, 0
  %t548 = add i64 %t545, %t547
  %t550 = sext i32 %t525 to i64
  %t551 = call i64 @__olang_fmt_i64(ptr null, i64 %t550)
  %t552 = add i64 %t548, %t551
  %t553 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d249, i32 0, i32 1) }, 1
  %t554 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d249, i32 0, i32 1) }, 0
  %t555 = add i64 %t552, %t554
  %t556 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t555)
  call void @olang_textcopy(ptr %t556, ptr %t526, i64 %t527)
  %t557 = getelementptr i8, ptr %t556, i64 %t527
  call void @olang_textcopy(ptr %t557, ptr %t529, i64 %t530)
  %t558 = getelementptr i8, ptr %t557, i64 %t530
  call void @olang_textcopy(ptr %t558, ptr %t532, i64 %t533)
  %t559 = getelementptr i8, ptr %t558, i64 %t533
  %t560 = call i64 @__olang_fmt_i64(ptr %t559, i64 %t536)
  %t561 = getelementptr i8, ptr %t559, i64 %t537
  call void @olang_textcopy(ptr %t561, ptr %t539, i64 %t540)
  %t562 = getelementptr i8, ptr %t561, i64 %t540
  %t563 = call i64 @__olang_fmt_i64(ptr %t562, i64 %t543)
  %t564 = getelementptr i8, ptr %t562, i64 %t544
  call void @olang_textcopy(ptr %t564, ptr %t546, i64 %t547)
  %t565 = getelementptr i8, ptr %t564, i64 %t547
  %t566 = call i64 @__olang_fmt_i64(ptr %t565, i64 %t550)
  %t567 = getelementptr i8, ptr %t565, i64 %t551
  call void @olang_textcopy(ptr %t567, ptr %t553, i64 %t554)
  %t568 = insertvalue { i64, ptr } undef, i64 %t555, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t556, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t521, { i64, ptr } %t569)
  br label %bb52
bb52:
  %t573 = load ptr, ptr %l1, !tbaa !29
  %t574 = load i32, ptr %l18, !tbaa !23
  %t575 = load i32, ptr %l18, !tbaa !23
  %t576 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d250, i32 0, i32 1) }, 1
  %t577 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d250, i32 0, i32 1) }, 0
  %t579 = sext i32 %t574 to i64
  %t580 = call i64 @__olang_fmt_i64(ptr null, i64 %t579)
  %t581 = add i64 %t577, %t580
  %t582 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t583 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t584 = add i64 %t581, %t583
  %t586 = sext i32 %t575 to i64
  %t587 = call i64 @__olang_fmt_i64(ptr null, i64 %t586)
  %t588 = add i64 %t584, %t587
  %t589 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t590 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t591 = add i64 %t588, %t590
  %t592 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t591)
  call void @olang_textcopy(ptr %t592, ptr %t576, i64 %t577)
  %t593 = getelementptr i8, ptr %t592, i64 %t577
  %t594 = call i64 @__olang_fmt_i64(ptr %t593, i64 %t579)
  %t595 = getelementptr i8, ptr %t593, i64 %t580
  call void @olang_textcopy(ptr %t595, ptr %t582, i64 %t583)
  %t596 = getelementptr i8, ptr %t595, i64 %t583
  %t597 = call i64 @__olang_fmt_i64(ptr %t596, i64 %t586)
  %t598 = getelementptr i8, ptr %t596, i64 %t587
  call void @olang_textcopy(ptr %t598, ptr %t589, i64 %t590)
  %t599 = insertvalue { i64, ptr } undef, i64 %t591, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t592, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s16, ptr %t573, { i64, ptr } %t600)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s16)
  br label %bb54
bb54:
  %t604 = getelementptr %"compiler/mir:TaskClause", ptr %l19, i32 0, i32 2
  %t605 = load { i64, [4 x i64] }, ptr %t604
  %t607 = extractvalue { i64, [4 x i64] } %t605, 0
  %t608 = icmp eq i64 %t607, 0
  %t610 = xor i1 %t608, true
  br i1 %t610, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s19
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/mir:TaskClause", ptr %l19, i32 0, i32 2
  %t614 = load { i64, [4 x i64] }, ptr %t613
  %t617 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v5, ptr %v4, ptr %t612, { i64, [4 x i64] } %t614)
  store i32 %t617, ptr %l214
  br label %bb57
bb56:
  br label %bb143
bb57:
  %t618 = load i32, ptr %l214, !tbaa !23
  store i32 %t618, ptr %l31, !tbaa !23
  %t619 = load ptr, ptr %l9, !tbaa !29
  store ptr %t619, ptr %l215, !tbaa !29
  %t620 = load i32, ptr %l31, !tbaa !23
  %t621 = load ptr, ptr %l215, !tbaa !29
  %t622 = call ptr @__olang_scope_or(ptr %v4, ptr %t621)
  %t623 = call ptr @__olang_scope_hold(ptr %t622)
  %t624 = ptrtoint ptr %t623 to i64
  %t626 = inttoptr i64 %t624 to ptr
  %t627 = load ptr, ptr %l215, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %t626, ptr %t627, i32 %t620)
  br label %bb58
bb58:
  %t629 = load ptr, ptr %l1, !tbaa !29
  %t630 = load i32, ptr %l18, !tbaa !23
  %t631 = load i64, ptr %l12, !tbaa !24
  %t632 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t633 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t635 = sext i32 %t630 to i64
  %t636 = call i64 @__olang_fmt_i64(ptr null, i64 %t635)
  %t637 = add i64 %t633, %t636
  %t638 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t639 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t640 = add i64 %t637, %t639
  %t642 = call i64 @__olang_fmt_i64(ptr null, i64 %t631)
  %t643 = add i64 %t640, %t642
  %t644 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t645 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t646 = add i64 %t643, %t645
  %t647 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t646)
  call void @olang_textcopy(ptr %t647, ptr %t632, i64 %t633)
  %t648 = getelementptr i8, ptr %t647, i64 %t633
  %t649 = call i64 @__olang_fmt_i64(ptr %t648, i64 %t635)
  %t650 = getelementptr i8, ptr %t648, i64 %t636
  call void @olang_textcopy(ptr %t650, ptr %t638, i64 %t639)
  %t651 = getelementptr i8, ptr %t650, i64 %t639
  %t652 = call i64 @__olang_fmt_i64(ptr %t651, i64 %t631)
  %t653 = getelementptr i8, ptr %t651, i64 %t642
  call void @olang_textcopy(ptr %t653, ptr %t644, i64 %t645)
  %t654 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t647, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t629, { i64, ptr } %t655)
  br label %bb59
bb59:
  %t659 = load ptr, ptr %l1, !tbaa !29
  %t660 = load i32, ptr %l18, !tbaa !23
  %t661 = load i32, ptr %l18, !tbaa !23
  %t662 = load i32, ptr %l18, !tbaa !23
  %t663 = load i32, ptr %l18, !tbaa !23
  %t664 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t667 = sext i32 %t660 to i64
  %t668 = call i64 @__olang_fmt_i64(ptr null, i64 %t667)
  %t669 = add i64 %t665, %t668
  %t670 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t671 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t672 = add i64 %t669, %t671
  %t674 = sext i32 %t661 to i64
  %t675 = call i64 @__olang_fmt_i64(ptr null, i64 %t674)
  %t676 = add i64 %t672, %t675
  %t677 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t678 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t679 = add i64 %t676, %t678
  %t681 = sext i32 %t662 to i64
  %t682 = call i64 @__olang_fmt_i64(ptr null, i64 %t681)
  %t683 = add i64 %t679, %t682
  %t684 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d257, i32 0, i32 1) }, 1
  %t685 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d257, i32 0, i32 1) }, 0
  %t686 = add i64 %t683, %t685
  %t688 = sext i32 %t663 to i64
  %t689 = call i64 @__olang_fmt_i64(ptr null, i64 %t688)
  %t690 = add i64 %t686, %t689
  %t691 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t692 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t693 = add i64 %t690, %t692
  %t694 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t693)
  call void @olang_textcopy(ptr %t694, ptr %t664, i64 %t665)
  %t695 = getelementptr i8, ptr %t694, i64 %t665
  %t696 = call i64 @__olang_fmt_i64(ptr %t695, i64 %t667)
  %t697 = getelementptr i8, ptr %t695, i64 %t668
  call void @olang_textcopy(ptr %t697, ptr %t670, i64 %t671)
  %t698 = getelementptr i8, ptr %t697, i64 %t671
  %t699 = call i64 @__olang_fmt_i64(ptr %t698, i64 %t674)
  %t700 = getelementptr i8, ptr %t698, i64 %t675
  call void @olang_textcopy(ptr %t700, ptr %t677, i64 %t678)
  %t701 = getelementptr i8, ptr %t700, i64 %t678
  %t702 = call i64 @__olang_fmt_i64(ptr %t701, i64 %t681)
  %t703 = getelementptr i8, ptr %t701, i64 %t682
  call void @olang_textcopy(ptr %t703, ptr %t684, i64 %t685)
  %t704 = getelementptr i8, ptr %t703, i64 %t685
  %t705 = call i64 @__olang_fmt_i64(ptr %t704, i64 %t688)
  %t706 = getelementptr i8, ptr %t704, i64 %t689
  call void @olang_textcopy(ptr %t706, ptr %t691, i64 %t692)
  %t707 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t708 = insertvalue { i64, ptr } %t707, ptr %t694, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t659, { i64, ptr } %t708)
  br label %bb60
bb60:
  %t712 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s19)
  store %"std/prelude/text:StringBuilder" %t712, ptr %l230
  br label %bb61
bb61:
  %t713 = load %"std/prelude/text:StringBuilder", ptr %l230
  store %"std/prelude/text:StringBuilder" %t713, ptr %l32
  %t714 = load i32, ptr %l18, !tbaa !23
  %t715 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d260, i32 0, i32 1) }, 1
  %t716 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d260, i32 0, i32 1) }, 0
  %t718 = sext i32 %t714 to i64
  %t719 = call i64 @__olang_fmt_i64(ptr null, i64 %t718)
  %t720 = add i64 %t716, %t719
  %t721 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t720)
  call void @olang_textcopy(ptr %t721, ptr %t715, i64 %t716)
  %t722 = getelementptr i8, ptr %t721, i64 %t716
  %t723 = call i64 @__olang_fmt_i64(ptr %t722, i64 %t718)
  %t724 = insertvalue { i64, ptr } undef, i64 %t720, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t721, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s19, ptr %l32, { i64, ptr } %t725)
  br label %bb62
bb62:
  %t729 = load ptr, ptr %l10, !tbaa !29
  store ptr %t729, ptr %l235, !tbaa !29
  %t730 = load i32, ptr %l31, !tbaa !23
  %t731 = load ptr, ptr %l235, !tbaa !29
  %t732 = call ptr @__olang_scope_or(ptr %v4, ptr %t731)
  %t733 = call ptr @__olang_scope_hold(ptr %t732)
  %t734 = ptrtoint ptr %t733 to i64
  %t736 = inttoptr i64 %t734 to ptr
  %t737 = load ptr, ptr %l235, !tbaa !29
  %t739 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %t736, ptr %t737, i32 %t730)
  store i32 %t739, ptr %l238
  br label %bb63
bb63:
  %t740 = load i32, ptr %l238, !tbaa !23
  store i32 %t740, ptr %l33, !tbaa !23
  %t741 = load i32, ptr %l33, !tbaa !23
  %t742 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t745 = icmp ne i32 %t741, %t742
  br i1 %t745, label %bb64, label %bb65
bb64:
  %t747 = load i32, ptr %l33, !tbaa !23
  %t748 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t751 = icmp ne i32 %t747, %t748
  store i1 %t751, ptr %l242, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l242, !tbaa !21
  br label %bb66
bb66:
  %t753 = load i1, ptr %l242, !tbaa !21
  br i1 %t753, label %bb67, label %bb68
bb67:
  %t754 = load ptr, ptr %l10, !tbaa !29
  store ptr %t754, ptr %l247, !tbaa !29
  %t755 = load i32, ptr %l33, !tbaa !23
  %t756 = load ptr, ptr %l247, !tbaa !29
  %t757 = call ptr @__olang_scope_or(ptr %v4, ptr %t756)
  %t758 = call ptr @__olang_scope_hold(ptr %t757)
  %t759 = ptrtoint ptr %t758 to i64
  %t761 = inttoptr i64 %t759 to ptr
  %t762 = load ptr, ptr %l247, !tbaa !29
  %t764 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %t761, ptr %t762, i32 %t755)
  store i1 %t764, ptr %l250
  br label %bb69
bb68:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb70
bb69:
  %t765 = load i1, ptr %l250, !tbaa !21
  store i1 %t765, ptr %l246, !tbaa !21
  br label %bb70
bb70:
  %t766 = load i1, ptr %l246, !tbaa !21
  store i1 %t766, ptr %l34, !tbaa !21
  %t767 = load i1, ptr %l34, !tbaa !21
  br i1 %t767, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s23
  %t769 = load ptr, ptr %l1, !tbaa !29
  store ptr %t769, ptr %l252, !tbaa !29
  %t770 = load i32, ptr %l18, !tbaa !23
  store i32 %t770, ptr %l253, !tbaa !23
  %t771 = load ptr, ptr %l9, !tbaa !29
  store ptr %t771, ptr %l254, !tbaa !29
  %t772 = load i32, ptr %l33, !tbaa !23
  %t773 = load ptr, ptr %l254, !tbaa !29
  %t774 = call ptr @__olang_scope_or(ptr %v4, ptr %t773)
  %t775 = call ptr @__olang_scope_hold(ptr %t774)
  %t776 = ptrtoint ptr %t775 to i64
  %t778 = inttoptr i64 %t776 to ptr
  %t779 = load ptr, ptr %l254, !tbaa !29
  %t781 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %t778, ptr %s23, ptr %t779, i32 %t772)
  store { i64, ptr } %t781, ptr %l257
  br label %bb73
bb72:
  br label %bb76
bb73:
  %t782 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t784 = load i32, ptr %l253, !tbaa !23
  %t785 = sext i32 %t784 to i64
  %t786 = call i64 @__olang_fmt_i64(ptr null, i64 %t785)
  %t787 = add i64 %t783, %t786
  %t788 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t790 = add i64 %t787, %t789
  %t791 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t792 = extractvalue { i64, ptr } %t791, 1
  %t793 = extractvalue { i64, ptr } %t791, 0
  %t794 = add i64 %t790, %t793
  %t795 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t796 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t797 = add i64 %t794, %t796
  %t798 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t797)
  call void @olang_textcopy(ptr %t798, ptr %t782, i64 %t783)
  %t799 = getelementptr i8, ptr %t798, i64 %t783
  %t800 = call i64 @__olang_fmt_i64(ptr %t799, i64 %t785)
  %t801 = getelementptr i8, ptr %t799, i64 %t786
  call void @olang_textcopy(ptr %t801, ptr %t788, i64 %t789)
  %t802 = getelementptr i8, ptr %t801, i64 %t789
  call void @olang_textcopy(ptr %t802, ptr %t792, i64 %t793)
  %t803 = getelementptr i8, ptr %t802, i64 %t793
  call void @olang_textcopy(ptr %t803, ptr %t795, i64 %t796)
  %t804 = insertvalue { i64, ptr } undef, i64 %t797, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t798, 1
  %t807 = load ptr, ptr %l252, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s23, ptr %t807, { i64, ptr } %t805)
  br label %bb74
bb74:
  %t809 = load i32, ptr %l18, !tbaa !23
  %t810 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t811 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t813 = sext i32 %t809 to i64
  %t814 = call i64 @__olang_fmt_i64(ptr null, i64 %t813)
  %t815 = add i64 %t811, %t814
  %t816 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t815)
  call void @olang_textcopy(ptr %t816, ptr %t810, i64 %t811)
  %t817 = getelementptr i8, ptr %t816, i64 %t811
  %t818 = call i64 @__olang_fmt_i64(ptr %t817, i64 %t813)
  %t819 = insertvalue { i64, ptr } undef, i64 %t815, 0
  %t820 = insertvalue { i64, ptr } %t819, ptr %t816, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s23, ptr %l32, { i64, ptr } %t820)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s23)
  br label %bb76
bb76:
  store i64 0, ptr %l35, !tbaa !24
  %t824 = load ptr, ptr %l10, !tbaa !29
  store ptr %t824, ptr %l264, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t825
  %t826 = getelementptr { i64, [4 x i64] }, ptr %t825, i32 0, i32 0
  store i64 0, ptr %t826
  %t827 = load { i64, [4 x i64] }, ptr %t825
  store { i64, [7 x i64] } zeroinitializer, ptr %t828
  %t829 = getelementptr { i64, [7 x i64] }, ptr %t828, i32 0, i32 0
  store i64 2, ptr %t829
  %t831 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t827, 0
  %t832 = getelementptr { i64, [7 x i64] }, ptr %t828, i32 0, i32 1
  store { { i64, [4 x i64] } } %t831, ptr %t832
  %t833 = load { i64, [7 x i64] }, ptr %t828
  %t834 = load i32, ptr %l31, !tbaa !23
  %t835 = load ptr, ptr %l264, !tbaa !29
  %t836 = call ptr @__olang_scope_or(ptr %v4, ptr %t835)
  %t837 = call ptr @__olang_scope_hold(ptr %t836)
  %t838 = ptrtoint ptr %t837 to i64
  %t840 = inttoptr i64 %t838 to ptr
  %t841 = load ptr, ptr %l264, !tbaa !29
  %t844 = call i64 @compiler_2fmir_2ePassedCount(ptr %t840, ptr %t841, { i64, [7 x i64] } %t833, i32 %t834)
  store i64 %t844, ptr %l269
  br label %bb77
bb77:
  %t845 = load i64, ptr %l269, !tbaa !24
  store i64 %t845, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t846 = load i64, ptr %l36, !tbaa !24
  %t847 = load i64, ptr %l35, !tbaa !24
  %t850 = icmp sgt i64 %t846, %t847
  br i1 %t850, label %bb78, label %bb79
bb78:
  %t852 = load i64, ptr %l37, !tbaa !24
  %t854 = icmp sgt i64 %t852, 0
  br i1 %t854, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l273, !tbaa !24
  br label %bb83
bb80:
  %t856 = load i64, ptr %l36, !tbaa !24
  %t857 = load i64, ptr %l35, !tbaa !24
  %t860 = sub i64 %t856, %t857
  %t861 = load i64, ptr %l37, !tbaa !24
  %t864 = add i64 %t860, %t861
  %t866 = sub i64 %t864, 1
  %t867 = load i64, ptr %l37, !tbaa !24
  %t870 = sdiv i64 %t866, %t867
  store i64 %t870, ptr %l276, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l276, !tbaa !24
  br label %bb82
bb82:
  %t872 = load i64, ptr %l276, !tbaa !24
  store i64 %t872, ptr %l273, !tbaa !24
  br label %bb83
bb83:
  %t873 = load i64, ptr %l273, !tbaa !24
  store i64 %t873, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb84
bb84:
  store %olang.scope zeroinitializer, ptr %s27
  %t874 = load i64, ptr %l39, !tbaa !24
  %t875 = load i64, ptr %l38, !tbaa !24
  %t878 = icmp slt i64 %t874, %t875
  %t880 = xor i1 %t878, true
  br i1 %t880, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s27)
  br label %bb98
bb86:
  br label %bb87
bb87:
  %t882 = load i64, ptr %l35, !tbaa !24
  %t883 = load i64, ptr %l39, !tbaa !24
  %t884 = load i64, ptr %l37, !tbaa !24
  %t887 = mul i64 %t883, %t884
  %t890 = add i64 %t882, %t887
  store i64 %t890, ptr %l40, !tbaa !24
  %t892 = load ptr, ptr %l9, !tbaa !29
  store ptr %t892, ptr %l294, !tbaa !29
  %t893 = load ptr, ptr %l294, !tbaa !29
  %t894 = call ptr @__olang_scope_or(ptr %v4, ptr %t893)
  %t895 = call ptr @__olang_scope_hold(ptr %t894)
  %t896 = ptrtoint ptr %t895 to i64
  %t898 = inttoptr i64 %t896 to ptr
  %t899 = load ptr, ptr %l294, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %t898, ptr %s27, ptr %s27, ptr %t899, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d265, i32 0, i32 1) }, { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d266, i32 0, i32 1) })
  br label %bb88
bb88:
  %t900 = load i32, ptr %l18, !tbaa !23
  %t901 = load i64, ptr %l40, !tbaa !24
  %t902 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d267, i32 0, i32 1) }, 1
  %t903 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d267, i32 0, i32 1) }, 0
  %t905 = sext i32 %t900 to i64
  %t906 = call i64 @__olang_fmt_i64(ptr null, i64 %t905)
  %t907 = add i64 %t903, %t906
  %t908 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t909 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t910 = add i64 %t907, %t909
  %t912 = call i64 @__olang_fmt_i64(ptr null, i64 %t901)
  %t913 = add i64 %t910, %t912
  %t914 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t913)
  call void @olang_textcopy(ptr %t914, ptr %t902, i64 %t903)
  %t915 = getelementptr i8, ptr %t914, i64 %t903
  %t916 = call i64 @__olang_fmt_i64(ptr %t915, i64 %t905)
  %t917 = getelementptr i8, ptr %t915, i64 %t906
  call void @olang_textcopy(ptr %t917, ptr %t908, i64 %t909)
  %t918 = getelementptr i8, ptr %t917, i64 %t909
  %t919 = call i64 @__olang_fmt_i64(ptr %t918, i64 %t901)
  %t920 = insertvalue { i64, ptr } undef, i64 %t913, 0
  %t921 = insertvalue { i64, ptr } %t920, ptr %t914, 1
  store { i64, ptr } %t921, ptr %l41, !tbaa !27
  %t923 = load ptr, ptr %l1, !tbaa !29
  %t924 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t925 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t926 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t928 = extractvalue { i64, ptr } %t924, 1
  %t929 = extractvalue { i64, ptr } %t924, 0
  %t930 = add i64 %t926, %t929
  %t931 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t932 = extractvalue { i64, ptr } { i64 38, ptr getelementptr inbounds (<{ i64, [38 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t933 = add i64 %t930, %t932
  %t934 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t933)
  call void @olang_textcopy(ptr %t934, ptr %t925, i64 %t926)
  %t935 = getelementptr i8, ptr %t934, i64 %t926
  call void @olang_textcopy(ptr %t935, ptr %t928, i64 %t929)
  %t936 = getelementptr i8, ptr %t935, i64 %t929
  call void @olang_textcopy(ptr %t936, ptr %t931, i64 %t932)
  %t937 = insertvalue { i64, ptr } undef, i64 %t933, 0
  %t938 = insertvalue { i64, ptr } %t937, ptr %t934, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t923, { i64, ptr } %t938)
  br label %bb89
bb89:
  %t942 = load i64, ptr %l8, !tbaa !24
  %t944 = icmp slt i64 %t942, 0
  br i1 %t944, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s30
  %t946 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t947 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d271, i32 0, i32 1) }, 1
  %t948 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d271, i32 0, i32 1) }, 0
  %t950 = extractvalue { i64, ptr } %t946, 1
  %t951 = extractvalue { i64, ptr } %t946, 0
  %t952 = add i64 %t948, %t951
  %t953 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d272, i32 0, i32 1) }, 1
  %t954 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d272, i32 0, i32 1) }, 0
  %t955 = add i64 %t952, %t954
  %t956 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t955)
  call void @olang_textcopy(ptr %t956, ptr %t947, i64 %t948)
  %t957 = getelementptr i8, ptr %t956, i64 %t948
  call void @olang_textcopy(ptr %t957, ptr %t950, i64 %t951)
  %t958 = getelementptr i8, ptr %t957, i64 %t951
  call void @olang_textcopy(ptr %t958, ptr %t953, i64 %t954)
  %t959 = insertvalue { i64, ptr } undef, i64 %t955, 0
  %t960 = insertvalue { i64, ptr } %t959, ptr %t956, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s30, ptr %l32, { i64, ptr } %t960)
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s30)
  call void @__olang_scope_close(ptr %s27)
  br label %bb97
bb93:
  %t964 = load ptr, ptr %l1, !tbaa !29
  %t965 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t966 = load i64, ptr %l8, !tbaa !24
  %t967 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t968 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t969 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t970 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t972 = extractvalue { i64, ptr } %t965, 1
  %t973 = extractvalue { i64, ptr } %t965, 0
  %t974 = add i64 %t970, %t973
  %t975 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d274, i32 0, i32 1) }, 1
  %t976 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d274, i32 0, i32 1) }, 0
  %t977 = add i64 %t974, %t976
  %t979 = call i64 @__olang_fmt_i64(ptr null, i64 %t966)
  %t980 = add i64 %t977, %t979
  %t981 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t982 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t983 = add i64 %t980, %t982
  %t985 = extractvalue { i64, ptr } %t967, 1
  %t986 = extractvalue { i64, ptr } %t967, 0
  %t987 = add i64 %t983, %t986
  %t988 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d276, i32 0, i32 1) }, 1
  %t989 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d276, i32 0, i32 1) }, 0
  %t990 = add i64 %t987, %t989
  %t992 = extractvalue { i64, ptr } %t968, 1
  %t993 = extractvalue { i64, ptr } %t968, 0
  %t994 = add i64 %t990, %t993
  %t995 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d277, i32 0, i32 1) }, 1
  %t996 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d277, i32 0, i32 1) }, 0
  %t997 = add i64 %t994, %t996
  %t998 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t997)
  call void @olang_textcopy(ptr %t998, ptr %t969, i64 %t970)
  %t999 = getelementptr i8, ptr %t998, i64 %t970
  call void @olang_textcopy(ptr %t999, ptr %t972, i64 %t973)
  %t1000 = getelementptr i8, ptr %t999, i64 %t973
  call void @olang_textcopy(ptr %t1000, ptr %t975, i64 %t976)
  %t1001 = getelementptr i8, ptr %t1000, i64 %t976
  %t1002 = call i64 @__olang_fmt_i64(ptr %t1001, i64 %t966)
  %t1003 = getelementptr i8, ptr %t1001, i64 %t979
  call void @olang_textcopy(ptr %t1003, ptr %t981, i64 %t982)
  %t1004 = getelementptr i8, ptr %t1003, i64 %t982
  call void @olang_textcopy(ptr %t1004, ptr %t985, i64 %t986)
  %t1005 = getelementptr i8, ptr %t1004, i64 %t986
  call void @olang_textcopy(ptr %t1005, ptr %t988, i64 %t989)
  %t1006 = getelementptr i8, ptr %t1005, i64 %t989
  call void @olang_textcopy(ptr %t1006, ptr %t992, i64 %t993)
  %t1007 = getelementptr i8, ptr %t1006, i64 %t993
  call void @olang_textcopy(ptr %t1007, ptr %t995, i64 %t996)
  %t1008 = insertvalue { i64, ptr } undef, i64 %t997, 0
  %t1009 = insertvalue { i64, ptr } %t1008, ptr %t998, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t964, { i64, ptr } %t1009)
  br label %bb94
bb94:
  %t1013 = load ptr, ptr %l1, !tbaa !29
  %t1014 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1015 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1016 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1017 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1018 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d278, i32 0, i32 1) }, 1
  %t1019 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d278, i32 0, i32 1) }, 0
  %t1021 = extractvalue { i64, ptr } %t1014, 1
  %t1022 = extractvalue { i64, ptr } %t1014, 0
  %t1023 = add i64 %t1019, %t1022
  %t1024 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d279, i32 0, i32 1) }, 1
  %t1025 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d279, i32 0, i32 1) }, 0
  %t1026 = add i64 %t1023, %t1025
  %t1028 = extractvalue { i64, ptr } %t1015, 1
  %t1029 = extractvalue { i64, ptr } %t1015, 0
  %t1030 = add i64 %t1026, %t1029
  %t1031 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d280, i32 0, i32 1) }, 1
  %t1032 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d280, i32 0, i32 1) }, 0
  %t1033 = add i64 %t1030, %t1032
  %t1035 = extractvalue { i64, ptr } %t1016, 1
  %t1036 = extractvalue { i64, ptr } %t1016, 0
  %t1037 = add i64 %t1033, %t1036
  %t1038 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t1039 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t1040 = add i64 %t1037, %t1039
  %t1042 = extractvalue { i64, ptr } %t1017, 1
  %t1043 = extractvalue { i64, ptr } %t1017, 0
  %t1044 = add i64 %t1040, %t1043
  %t1045 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t1046 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t1047 = add i64 %t1044, %t1046
  %t1048 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t1047)
  call void @olang_textcopy(ptr %t1048, ptr %t1018, i64 %t1019)
  %t1049 = getelementptr i8, ptr %t1048, i64 %t1019
  call void @olang_textcopy(ptr %t1049, ptr %t1021, i64 %t1022)
  %t1050 = getelementptr i8, ptr %t1049, i64 %t1022
  call void @olang_textcopy(ptr %t1050, ptr %t1024, i64 %t1025)
  %t1051 = getelementptr i8, ptr %t1050, i64 %t1025
  call void @olang_textcopy(ptr %t1051, ptr %t1028, i64 %t1029)
  %t1052 = getelementptr i8, ptr %t1051, i64 %t1029
  call void @olang_textcopy(ptr %t1052, ptr %t1031, i64 %t1032)
  %t1053 = getelementptr i8, ptr %t1052, i64 %t1032
  call void @olang_textcopy(ptr %t1053, ptr %t1035, i64 %t1036)
  %t1054 = getelementptr i8, ptr %t1053, i64 %t1036
  call void @olang_textcopy(ptr %t1054, ptr %t1038, i64 %t1039)
  %t1055 = getelementptr i8, ptr %t1054, i64 %t1039
  call void @olang_textcopy(ptr %t1055, ptr %t1042, i64 %t1043)
  %t1056 = getelementptr i8, ptr %t1055, i64 %t1043
  call void @olang_textcopy(ptr %t1056, ptr %t1045, i64 %t1046)
  %t1057 = insertvalue { i64, ptr } undef, i64 %t1047, 0
  %t1058 = insertvalue { i64, ptr } %t1057, ptr %t1048, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s27, ptr %t1013, { i64, ptr } %t1058)
  br label %bb95
bb95:
  %t1062 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1063 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d283, i32 0, i32 1) }, 1
  %t1064 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d283, i32 0, i32 1) }, 0
  %t1066 = extractvalue { i64, ptr } %t1062, 1
  %t1067 = extractvalue { i64, ptr } %t1062, 0
  %t1068 = add i64 %t1064, %t1067
  %t1069 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t1068)
  call void @olang_textcopy(ptr %t1069, ptr %t1063, i64 %t1064)
  %t1070 = getelementptr i8, ptr %t1069, i64 %t1064
  call void @olang_textcopy(ptr %t1070, ptr %t1066, i64 %t1067)
  %t1071 = insertvalue { i64, ptr } undef, i64 %t1068, 0
  %t1072 = insertvalue { i64, ptr } %t1071, ptr %t1069, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s19, ptr %s27, ptr %l32, { i64, ptr } %t1072)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s27)
  br label %bb97
bb97:
  %t1076 = load i64, ptr %l39, !tbaa !24
  %t1079 = add i64 %t1076, 1
  store i64 %t1079, ptr %l39, !tbaa !24
  br label %bb84
bb98:
  %t1081 = load ptr, ptr %l10, !tbaa !29
  store ptr %t1081, ptr %l330, !tbaa !29
  %t1082 = load i32, ptr %l31, !tbaa !23
  %t1083 = load ptr, ptr %l330, !tbaa !29
  %t1084 = call ptr @__olang_scope_or(ptr %v4, ptr %t1083)
  %t1085 = call ptr @__olang_scope_hold(ptr %t1084)
  %t1086 = ptrtoint ptr %t1085 to i64
  %t1088 = inttoptr i64 %t1086 to ptr
  %t1090 = inttoptr i64 0 to ptr
  %t1091 = load ptr, ptr %l330, !tbaa !29
  %t1093 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %t1088, ptr %s19, ptr %t1090, ptr %t1091, i32 %t1082)
  store { i64, ptr } %t1093, ptr %l334
  br label %bb99
bb99:
  %t1094 = load { i64, ptr }, ptr %l334, !tbaa !27
  store { i64, ptr } %t1094, ptr %l42, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d284, i32 0, i32 1) }, ptr %l335, !tbaa !27
  %t1095 = load { i64, ptr }, ptr %l335, !tbaa !27
  store { i64, ptr } %t1095, ptr %l43, !tbaa !27
  %t1097 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t1099 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t1097, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d285, i32 0, i32 1) })
  store i1 %t1099, ptr %l338
  br label %bb100
bb100:
  %t1100 = load i1, ptr %l338, !tbaa !21
  br i1 %t1100, label %bb101, label %bb102
bb101:
  store %olang.scope zeroinitializer, ptr %s36
  %t1101 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1101, ptr %l339, !tbaa !29
  %t1102 = load i32, ptr %l18, !tbaa !23
  store i32 %t1102, ptr %l340, !tbaa !23
  %t1104 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s19, ptr %s36, ptr %l32)
  store { i64, ptr } %t1104, ptr %l342
  br label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s38
  %t1105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1105, ptr %l345, !tbaa !29
  %t1106 = load i32, ptr %l18, !tbaa !23
  store i32 %t1106, ptr %l346, !tbaa !23
  %t1107 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t1107, ptr %l347, !tbaa !27
  %t1108 = load i32, ptr %l18, !tbaa !23
  store i32 %t1108, ptr %l348, !tbaa !23
  %t1110 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s19, ptr %s38, ptr %l32)
  store { i64, ptr } %t1110, ptr %l350
  br label %bb105
bb103:
  %t1111 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d286, i32 0, i32 1) }, 1
  %t1112 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d286, i32 0, i32 1) }, 0
  %t1113 = load i32, ptr %l340, !tbaa !23
  %t1114 = sext i32 %t1113 to i64
  %t1115 = call i64 @__olang_fmt_i64(ptr null, i64 %t1114)
  %t1116 = add i64 %t1112, %t1115
  %t1117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 1
  %t1118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d287, i32 0, i32 1) }, 0
  %t1119 = add i64 %t1116, %t1118
  %t1120 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t1121 = extractvalue { i64, ptr } %t1120, 1
  %t1122 = extractvalue { i64, ptr } %t1120, 0
  %t1123 = add i64 %t1119, %t1122
  %t1124 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d288, i32 0, i32 1) }, 1
  %t1125 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d288, i32 0, i32 1) }, 0
  %t1126 = add i64 %t1123, %t1125
  %t1127 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1126)
  call void @olang_textcopy(ptr %t1127, ptr %t1111, i64 %t1112)
  %t1128 = getelementptr i8, ptr %t1127, i64 %t1112
  %t1129 = call i64 @__olang_fmt_i64(ptr %t1128, i64 %t1114)
  %t1130 = getelementptr i8, ptr %t1128, i64 %t1115
  call void @olang_textcopy(ptr %t1130, ptr %t1117, i64 %t1118)
  %t1131 = getelementptr i8, ptr %t1130, i64 %t1118
  call void @olang_textcopy(ptr %t1131, ptr %t1121, i64 %t1122)
  %t1132 = getelementptr i8, ptr %t1131, i64 %t1122
  call void @olang_textcopy(ptr %t1132, ptr %t1124, i64 %t1125)
  %t1133 = insertvalue { i64, ptr } undef, i64 %t1126, 0
  %t1134 = insertvalue { i64, ptr } %t1133, ptr %t1127, 1
  %t1136 = load ptr, ptr %l339, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s36, ptr %t1136, { i64, ptr } %t1134)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s36)
  br label %bb115
bb105:
  %t1138 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d289, i32 0, i32 1) }, 1
  %t1139 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d289, i32 0, i32 1) }, 0
  %t1140 = load i32, ptr %l346, !tbaa !23
  %t1141 = sext i32 %t1140 to i64
  %t1142 = call i64 @__olang_fmt_i64(ptr null, i64 %t1141)
  %t1143 = add i64 %t1139, %t1142
  %t1144 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t1145 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t1146 = add i64 %t1143, %t1145
  %t1147 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t1148 = extractvalue { i64, ptr } %t1147, 1
  %t1149 = extractvalue { i64, ptr } %t1147, 0
  %t1150 = add i64 %t1146, %t1149
  %t1151 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t1152 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t1153 = add i64 %t1150, %t1152
  %t1154 = load i32, ptr %l348, !tbaa !23
  %t1155 = sext i32 %t1154 to i64
  %t1156 = call i64 @__olang_fmt_i64(ptr null, i64 %t1155)
  %t1157 = add i64 %t1153, %t1156
  %t1158 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 1
  %t1159 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d292, i32 0, i32 1) }, 0
  %t1160 = add i64 %t1157, %t1159
  %t1161 = load { i64, ptr }, ptr %l350, !tbaa !27
  %t1162 = extractvalue { i64, ptr } %t1161, 1
  %t1163 = extractvalue { i64, ptr } %t1161, 0
  %t1164 = add i64 %t1160, %t1163
  %t1165 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t1166 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t1167 = add i64 %t1164, %t1166
  %t1168 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t1167)
  call void @olang_textcopy(ptr %t1168, ptr %t1138, i64 %t1139)
  %t1169 = getelementptr i8, ptr %t1168, i64 %t1139
  %t1170 = call i64 @__olang_fmt_i64(ptr %t1169, i64 %t1141)
  %t1171 = getelementptr i8, ptr %t1169, i64 %t1142
  call void @olang_textcopy(ptr %t1171, ptr %t1144, i64 %t1145)
  %t1172 = getelementptr i8, ptr %t1171, i64 %t1145
  call void @olang_textcopy(ptr %t1172, ptr %t1148, i64 %t1149)
  %t1173 = getelementptr i8, ptr %t1172, i64 %t1149
  call void @olang_textcopy(ptr %t1173, ptr %t1151, i64 %t1152)
  %t1174 = getelementptr i8, ptr %t1173, i64 %t1152
  %t1175 = call i64 @__olang_fmt_i64(ptr %t1174, i64 %t1155)
  %t1176 = getelementptr i8, ptr %t1174, i64 %t1156
  call void @olang_textcopy(ptr %t1176, ptr %t1158, i64 %t1159)
  %t1177 = getelementptr i8, ptr %t1176, i64 %t1159
  call void @olang_textcopy(ptr %t1177, ptr %t1162, i64 %t1163)
  %t1178 = getelementptr i8, ptr %t1177, i64 %t1163
  call void @olang_textcopy(ptr %t1178, ptr %t1165, i64 %t1166)
  %t1179 = insertvalue { i64, ptr } undef, i64 %t1167, 0
  %t1180 = insertvalue { i64, ptr } %t1179, ptr %t1168, 1
  %t1182 = load ptr, ptr %l345, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s38, ptr %t1182, { i64, ptr } %t1180)
  br label %bb106
bb106:
  %t1184 = call ptr @__olang_scope_hold(ptr %s19)
  %t1185 = ptrtoint ptr %t1184 to i64
  store i64 %t1185, ptr %l353, !tbaa !24
  %t1186 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e43
  br i1 %t1186, label %bb107, label %bb108
bb107:
  %t1188 = call ptr @__olang_region_make(ptr %s19)
  %t1189 = ptrtoint ptr %t1188 to i64
  store i64 %t1189, ptr %l353, !tbaa !24
  br label %bb108
bb108:
  %t1190 = load i32, ptr %l18, !tbaa !23
  %t1191 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t1192 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t1194 = sext i32 %t1190 to i64
  %t1195 = call i64 @__olang_fmt_i64(ptr null, i64 %t1194)
  %t1196 = add i64 %t1192, %t1195
  %t1197 = load i64, ptr %l353
  %t1198 = inttoptr i64 %t1197 to ptr
  %t1199 = call ptr @__olang_held_alloc(ptr %t1198, i64 %t1196)
  call void @olang_textcopy(ptr %t1199, ptr %t1191, i64 %t1192)
  %t1200 = getelementptr i8, ptr %t1199, i64 %t1192
  %t1201 = call i64 @__olang_fmt_i64(ptr %t1200, i64 %t1194)
  %t1202 = insertvalue { i64, ptr } undef, i64 %t1196, 0
  %t1203 = insertvalue { i64, ptr } %t1202, ptr %t1199, 1
  store { i64, ptr } %t1203, ptr %l356, !tbaa !27
  %t1204 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e43
  br i1 %t1204, label %bb109, label %bb110
bb109:
  %t1206 = load { i64, ptr }, ptr %l356, !tbaa !27
  %t1207 = extractvalue { i64, ptr } %t1206, 0
  %t1209 = icmp eq i64 %t1207, 0
  br i1 %t1209, label %bb111, label %bb112
bb110:
  %t1211 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t1211, ptr %l360, !tbaa !27
  %t1212 = load { i64, ptr }, ptr %l356, !tbaa !27
  store { i64, ptr } %t1212, ptr %l43, !tbaa !27
  %t1213 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e43
  br i1 %t1213, label %bb113, label %bb114
bb111:
  store { i64, ptr } zeroinitializer, ptr %l356, !tbaa !27
  br label %bb112
bb112:
  %t1215 = load i64, ptr %l353
  %t1216 = inttoptr i64 %t1215 to ptr
  %t1217 = load { i64, ptr }, ptr %l356
  %t1218 = extractvalue { i64, ptr } %t1217, 1
  %t1219 = call ptr @__olang_region_or(ptr %t1218, ptr null)
  %t1220 = icmp ne ptr %t1219, null
  %t1221 = select i1 %t1220, ptr %t1219, ptr null
  call void @__olang_region_settle_in(ptr %t1216, ptr %t1221)
  br label %bb110
bb113:
  %t1222 = load { i64, ptr }, ptr %l360
  %t1223 = extractvalue { i64, ptr } %t1222, 1
  call void @__olang_region_release(ptr %t1223)
  store { i64, ptr } zeroinitializer, ptr %l360
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s38)
  br label %bb115
bb115:
  %t1224 = load i1, ptr %l34, !tbaa !21
  br i1 %t1224, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s41
  %t1226 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1226, ptr %l363, !tbaa !29
  %t1227 = load i32, ptr %l18, !tbaa !23
  store i32 %t1227, ptr %l364, !tbaa !23
  %t1228 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1228, ptr %l365, !tbaa !29
  %t1229 = load i32, ptr %l33, !tbaa !23
  %t1230 = load ptr, ptr %l365, !tbaa !29
  %t1231 = call ptr @__olang_scope_or(ptr %v4, ptr %t1230)
  %t1232 = call ptr @__olang_scope_hold(ptr %t1231)
  %t1233 = ptrtoint ptr %t1232 to i64
  %t1235 = inttoptr i64 %t1233 to ptr
  %t1236 = load ptr, ptr %l365, !tbaa !29
  %t1238 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %t1235, ptr %s41, ptr %t1236, i32 %t1229)
  store { i64, ptr } %t1238, ptr %l368
  br label %bb118
bb117:
  br label %bb128
bb118:
  %t1239 = load i32, ptr %l18, !tbaa !23
  %t1240 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t1241 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t1242 = load i32, ptr %l364, !tbaa !23
  %t1243 = sext i32 %t1242 to i64
  %t1244 = call i64 @__olang_fmt_i64(ptr null, i64 %t1243)
  %t1245 = add i64 %t1241, %t1244
  %t1246 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d296, i32 0, i32 1) }, 1
  %t1247 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d296, i32 0, i32 1) }, 0
  %t1248 = add i64 %t1245, %t1247
  %t1249 = load { i64, ptr }, ptr %l368, !tbaa !27
  %t1250 = extractvalue { i64, ptr } %t1249, 1
  %t1251 = extractvalue { i64, ptr } %t1249, 0
  %t1252 = add i64 %t1248, %t1251
  %t1253 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d297, i32 0, i32 1) }, 1
  %t1254 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d297, i32 0, i32 1) }, 0
  %t1255 = add i64 %t1252, %t1254
  %t1257 = sext i32 %t1239 to i64
  %t1258 = call i64 @__olang_fmt_i64(ptr null, i64 %t1257)
  %t1259 = add i64 %t1255, %t1258
  %t1260 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t1261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t1262 = add i64 %t1259, %t1261
  %t1263 = call ptr @__olang_scope_alloc(ptr %s41, i64 %t1262)
  call void @olang_textcopy(ptr %t1263, ptr %t1240, i64 %t1241)
  %t1264 = getelementptr i8, ptr %t1263, i64 %t1241
  %t1265 = call i64 @__olang_fmt_i64(ptr %t1264, i64 %t1243)
  %t1266 = getelementptr i8, ptr %t1264, i64 %t1244
  call void @olang_textcopy(ptr %t1266, ptr %t1246, i64 %t1247)
  %t1267 = getelementptr i8, ptr %t1266, i64 %t1247
  call void @olang_textcopy(ptr %t1267, ptr %t1250, i64 %t1251)
  %t1268 = getelementptr i8, ptr %t1267, i64 %t1251
  call void @olang_textcopy(ptr %t1268, ptr %t1253, i64 %t1254)
  %t1269 = getelementptr i8, ptr %t1268, i64 %t1254
  %t1270 = call i64 @__olang_fmt_i64(ptr %t1269, i64 %t1257)
  %t1271 = getelementptr i8, ptr %t1269, i64 %t1258
  call void @olang_textcopy(ptr %t1271, ptr %t1260, i64 %t1261)
  %t1272 = insertvalue { i64, ptr } undef, i64 %t1262, 0
  %t1273 = insertvalue { i64, ptr } %t1272, ptr %t1263, 1
  %t1275 = load ptr, ptr %l363, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s41, ptr %t1275, { i64, ptr } %t1273)
  br label %bb119
bb119:
  %t1277 = call ptr @__olang_scope_hold(ptr %s19)
  %t1278 = ptrtoint ptr %t1277 to i64
  store i64 %t1278, ptr %l372, !tbaa !24
  %t1279 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e43
  br i1 %t1279, label %bb120, label %bb121
bb120:
  %t1281 = call ptr @__olang_region_make(ptr %s19)
  %t1282 = ptrtoint ptr %t1281 to i64
  store i64 %t1282, ptr %l372, !tbaa !24
  br label %bb121
bb121:
  %t1283 = load i32, ptr %l18, !tbaa !23
  %t1284 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t1285 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t1287 = sext i32 %t1283 to i64
  %t1288 = call i64 @__olang_fmt_i64(ptr null, i64 %t1287)
  %t1289 = add i64 %t1285, %t1288
  %t1290 = load i64, ptr %l372
  %t1291 = inttoptr i64 %t1290 to ptr
  %t1292 = call ptr @__olang_held_alloc(ptr %t1291, i64 %t1289)
  call void @olang_textcopy(ptr %t1292, ptr %t1284, i64 %t1285)
  %t1293 = getelementptr i8, ptr %t1292, i64 %t1285
  %t1294 = call i64 @__olang_fmt_i64(ptr %t1293, i64 %t1287)
  %t1295 = insertvalue { i64, ptr } undef, i64 %t1289, 0
  %t1296 = insertvalue { i64, ptr } %t1295, ptr %t1292, 1
  store { i64, ptr } %t1296, ptr %l375, !tbaa !27
  %t1297 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e43
  br i1 %t1297, label %bb122, label %bb123
bb122:
  %t1299 = load { i64, ptr }, ptr %l375, !tbaa !27
  %t1300 = extractvalue { i64, ptr } %t1299, 0
  %t1302 = icmp eq i64 %t1300, 0
  br i1 %t1302, label %bb124, label %bb125
bb123:
  %t1304 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t1304, ptr %l379, !tbaa !27
  %t1305 = load { i64, ptr }, ptr %l375, !tbaa !27
  store { i64, ptr } %t1305, ptr %l43, !tbaa !27
  %t1306 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e43
  br i1 %t1306, label %bb126, label %bb127
bb124:
  store { i64, ptr } zeroinitializer, ptr %l375, !tbaa !27
  br label %bb125
bb125:
  %t1308 = load i64, ptr %l372
  %t1309 = inttoptr i64 %t1308 to ptr
  %t1310 = load { i64, ptr }, ptr %l375
  %t1311 = extractvalue { i64, ptr } %t1310, 1
  %t1312 = call ptr @__olang_region_or(ptr %t1311, ptr null)
  %t1313 = icmp ne ptr %t1312, null
  %t1314 = select i1 %t1313, ptr %t1312, ptr null
  call void @__olang_region_settle_in(ptr %t1309, ptr %t1314)
  br label %bb123
bb126:
  %t1315 = load { i64, ptr }, ptr %l379
  %t1316 = extractvalue { i64, ptr } %t1315, 1
  call void @__olang_region_release(ptr %t1316)
  store { i64, ptr } zeroinitializer, ptr %l379
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s41)
  br label %bb128
bb128:
  %t1317 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t1319 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s19, ptr %s19, { i64, ptr } %t1317, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d300, i32 0, i32 1) })
  store i1 %t1319, ptr %l382
  br label %bb129
bb129:
  %t1320 = load i1, ptr %l382, !tbaa !21
  %t1321 = xor i1 %t1320, true
  br i1 %t1321, label %bb130, label %bb131
bb130:
  %t1323 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1324 = getelementptr %"compiler/mir:Range", ptr %t1323, i32 0, i32 1
  %t1325 = load i32, ptr %t1324, !tbaa !23
  %t1327 = icmp sgt i32 %t1325, 0
  store i1 %t1327, ptr %l384, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l384, !tbaa !21
  br label %bb132
bb132:
  %t1329 = load i1, ptr %l384, !tbaa !21
  br i1 %t1329, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s44
  %t1330 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1331 = getelementptr %"compiler/mir:Range", ptr %t1330, i32 0, i32 1
  %t1332 = load i32, ptr %t1331, !tbaa !23
  %t1334 = icmp eq i32 %t1332, 1
  br i1 %t1334, label %bb135, label %bb136
bb134:
  br label %bb142
bb135:
  store %olang.scope zeroinitializer, ptr %s45
  %t1336 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1336, ptr %l389, !tbaa !29
  %t1337 = load i32, ptr %l18, !tbaa !23
  store i32 %t1337, ptr %l390, !tbaa !23
  %t1338 = load i64, ptr %l6, !tbaa !24
  store i64 %t1338, ptr %l391, !tbaa !24
  %t1339 = load ptr, ptr %l9, !tbaa !29
  store ptr %t1339, ptr %l392, !tbaa !29
  %t1340 = load i32, ptr %l33, !tbaa !23
  %t1341 = load ptr, ptr %l392, !tbaa !29
  %t1342 = call ptr @__olang_scope_or(ptr %v4, ptr %t1341)
  %t1343 = call ptr @__olang_scope_hold(ptr %t1342)
  %t1344 = ptrtoint ptr %t1343 to i64
  %t1346 = inttoptr i64 %t1344 to ptr
  %t1347 = load ptr, ptr %l392, !tbaa !29
  %t1349 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %t1346, ptr %s45, ptr %t1347, i32 %t1340)
  store { i64, ptr } %t1349, ptr %l395
  br label %bb137
bb136:
  store %olang.scope zeroinitializer, ptr %s47
  %t1350 = load ptr, ptr %l0, !tbaa !29
  %t1351 = load ptr, ptr %l1, !tbaa !29
  %t1352 = load i32, ptr %l18, !tbaa !23
  %t1354 = sext i32 %t1352 to i64
  %t1355 = call i64 @__olang_fmt_i64(ptr null, i64 %t1354)
  %t1356 = call ptr @__olang_scope_alloc(ptr %s47, i64 %t1355)
  %t1357 = call i64 @__olang_fmt_i64(ptr %t1356, i64 %t1354)
  %t1358 = insertvalue { i64, ptr } undef, i64 %t1355, 0
  %t1359 = insertvalue { i64, ptr } %t1358, ptr %t1356, 1
  %t1361 = load i32, ptr %l33, !tbaa !23
  %t1362 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t1363 = load i64, ptr %l6, !tbaa !24
  %t1364 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 3
  %t1365 = getelementptr %"compiler/mir:Range", ptr %t1364, i32 0, i32 1
  %t1366 = load i32, ptr %t1365, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estoreParts(ptr %v0, ptr %v1, ptr %s47, ptr %s19, ptr %v4, ptr %t1350, ptr %t1351, { i64, ptr } %t1359, i32 %t1361, { i64, ptr } %t1362, i64 %t1363, i32 %t1366)
  br label %bb139
bb137:
  %t1374 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t1375 = load i32, ptr %l18, !tbaa !23
  %t1376 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d301, i32 0, i32 1) }, 1
  %t1377 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d301, i32 0, i32 1) }, 0
  %t1378 = load i32, ptr %l390, !tbaa !23
  %t1379 = sext i32 %t1378 to i64
  %t1380 = call i64 @__olang_fmt_i64(ptr null, i64 %t1379)
  %t1381 = add i64 %t1377, %t1380
  %t1382 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t1383 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t1384 = add i64 %t1381, %t1383
  %t1385 = load i64, ptr %l391, !tbaa !24
  %t1386 = call i64 @__olang_fmt_i64(ptr null, i64 %t1385)
  %t1387 = add i64 %t1384, %t1386
  %t1388 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t1389 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t1390 = add i64 %t1387, %t1389
  %t1391 = load { i64, ptr }, ptr %l395, !tbaa !27
  %t1392 = extractvalue { i64, ptr } %t1391, 1
  %t1393 = extractvalue { i64, ptr } %t1391, 0
  %t1394 = add i64 %t1390, %t1393
  %t1395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t1396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t1397 = add i64 %t1394, %t1396
  %t1399 = extractvalue { i64, ptr } %t1374, 1
  %t1400 = extractvalue { i64, ptr } %t1374, 0
  %t1401 = add i64 %t1397, %t1400
  %t1402 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d305, i32 0, i32 1) }, 1
  %t1403 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d305, i32 0, i32 1) }, 0
  %t1404 = add i64 %t1401, %t1403
  %t1406 = sext i32 %t1375 to i64
  %t1407 = call i64 @__olang_fmt_i64(ptr null, i64 %t1406)
  %t1408 = add i64 %t1404, %t1407
  %t1409 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d306, i32 0, i32 1) }, 1
  %t1410 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d306, i32 0, i32 1) }, 0
  %t1411 = add i64 %t1408, %t1410
  %t1412 = call ptr @__olang_scope_alloc(ptr %s45, i64 %t1411)
  call void @olang_textcopy(ptr %t1412, ptr %t1376, i64 %t1377)
  %t1413 = getelementptr i8, ptr %t1412, i64 %t1377
  %t1414 = call i64 @__olang_fmt_i64(ptr %t1413, i64 %t1379)
  %t1415 = getelementptr i8, ptr %t1413, i64 %t1380
  call void @olang_textcopy(ptr %t1415, ptr %t1382, i64 %t1383)
  %t1416 = getelementptr i8, ptr %t1415, i64 %t1383
  %t1417 = call i64 @__olang_fmt_i64(ptr %t1416, i64 %t1385)
  %t1418 = getelementptr i8, ptr %t1416, i64 %t1386
  call void @olang_textcopy(ptr %t1418, ptr %t1388, i64 %t1389)
  %t1419 = getelementptr i8, ptr %t1418, i64 %t1389
  call void @olang_textcopy(ptr %t1419, ptr %t1392, i64 %t1393)
  %t1420 = getelementptr i8, ptr %t1419, i64 %t1393
  call void @olang_textcopy(ptr %t1420, ptr %t1395, i64 %t1396)
  %t1421 = getelementptr i8, ptr %t1420, i64 %t1396
  call void @olang_textcopy(ptr %t1421, ptr %t1399, i64 %t1400)
  %t1422 = getelementptr i8, ptr %t1421, i64 %t1400
  call void @olang_textcopy(ptr %t1422, ptr %t1402, i64 %t1403)
  %t1423 = getelementptr i8, ptr %t1422, i64 %t1403
  %t1424 = call i64 @__olang_fmt_i64(ptr %t1423, i64 %t1406)
  %t1425 = getelementptr i8, ptr %t1423, i64 %t1407
  call void @olang_textcopy(ptr %t1425, ptr %t1409, i64 %t1410)
  %t1426 = insertvalue { i64, ptr } undef, i64 %t1411, 0
  %t1427 = insertvalue { i64, ptr } %t1426, ptr %t1412, 1
  %t1429 = load ptr, ptr %l389, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s45, ptr %t1429, { i64, ptr } %t1427)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s45)
  br label %bb140
bb139:
  call void @__olang_scope_close(ptr %s47)
  br label %bb140
bb140:
  %t1431 = load ptr, ptr %l0, !tbaa !29
  %t1432 = load ptr, ptr %l1, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l411, ptr %l3, i64 144, i1 false)
  %t1433 = load i64, ptr %l6, !tbaa !24
  %t1435 = load i32, ptr %l18, !tbaa !23
  %t1436 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d307, i32 0, i32 1) }, 1
  %t1437 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d307, i32 0, i32 1) }, 0
  %t1439 = sext i32 %t1435 to i64
  %t1440 = call i64 @__olang_fmt_i64(ptr null, i64 %t1439)
  %t1441 = add i64 %t1437, %t1440
  %t1442 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1441)
  call void @olang_textcopy(ptr %t1442, ptr %t1436, i64 %t1437)
  %t1443 = getelementptr i8, ptr %t1442, i64 %t1437
  %t1444 = call i64 @__olang_fmt_i64(ptr %t1443, i64 %t1439)
  %t1445 = insertvalue { i64, ptr } undef, i64 %t1441, 0
  %t1446 = insertvalue { i64, ptr } %t1445, ptr %t1442, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1450, ptr %l411, i64 144, i1 false)
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v3, ptr %s44, ptr %v5, ptr %v4, ptr %t1431, ptr %t1432, ptr %t1450, i64 %t1433, { i64, ptr } %a7, { i64, ptr } %t1446)
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s44)
  br label %bb142
bb142:
  %t1454 = load i64, ptr %l12, !tbaa !24
  %t1457 = add i64 %t1454, 1
  store i64 %t1457, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb143
bb143:
  %t1459 = load ptr, ptr %l1, !tbaa !29
  %t1460 = load i32, ptr %l18, !tbaa !23
  %t1461 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d308, i32 0, i32 1) }, 1
  %t1462 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d308, i32 0, i32 1) }, 0
  %t1464 = sext i32 %t1460 to i64
  %t1465 = call i64 @__olang_fmt_i64(ptr null, i64 %t1464)
  %t1466 = add i64 %t1462, %t1465
  %t1467 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d309, i32 0, i32 1) }, 1
  %t1468 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d309, i32 0, i32 1) }, 0
  %t1469 = add i64 %t1466, %t1468
  %t1470 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t1469)
  call void @olang_textcopy(ptr %t1470, ptr %t1461, i64 %t1462)
  %t1471 = getelementptr i8, ptr %t1470, i64 %t1462
  %t1472 = call i64 @__olang_fmt_i64(ptr %t1471, i64 %t1464)
  %t1473 = getelementptr i8, ptr %t1471, i64 %t1465
  call void @olang_textcopy(ptr %t1473, ptr %t1467, i64 %t1468)
  %t1474 = insertvalue { i64, ptr } undef, i64 %t1469, 0
  %t1475 = insertvalue { i64, ptr } %t1474, ptr %t1470, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t1459, { i64, ptr } %t1475)
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s2)
  br label %bb145
bb145:
  %t1479 = load i32, ptr %l17, !tbaa !23
  %t1482 = add i32 %t1479, 1
  store i32 %t1482, ptr %l17, !tbaa !23
  br label %bb8
bb146:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2edeclareVars(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca ptr
  %l36 = alloca i64
  %l40 = alloca i64
  %l43 = alloca i64
  %l62 = alloca ptr
  %l65 = alloca %"compiler/mir:Local"
  %l74 = alloca i1
  %l80 = alloca ptr
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l93 = alloca i1
  %l96 = alloca i64
  %l98 = alloca ptr
  %l101 = alloca i64
  %l104 = alloca ptr
  %l106 = alloca i64
  %l109 = alloca i64
  %l111 = alloca ptr
  %l117 = alloca i64
  %l119 = alloca ptr
  %l126 = alloca i64
  %l129 = alloca { i64, ptr }
  %l135 = alloca i64
  %l138 = alloca i64
  %l142 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l156 = alloca ptr
  %l158 = alloca i64
  %l161 = alloca { i64, ptr }
  %l165 = alloca i64
  %l167 = alloca { i64, ptr }
  %l173 = alloca i1
  %l175 = alloca i64
  %l178 = alloca { i64, ptr }
  %l182 = alloca i64
  %l184 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l191 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l194 = alloca { i64, ptr }
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %l202 = alloca ptr
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l205 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l208 = alloca ptr
  %l215 = alloca i64
  %l217 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/emit:fnEm", ptr %t6, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  store ptr %t11, ptr %l28, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = getelementptr %"compiler/mir:Fn", ptr %t12, i32 0, i32 2
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load ptr, ptr %l28, !tbaa !29
  %t17 = call ptr @__olang_scope_or(ptr %v2, ptr %t16)
  %t18 = call ptr @__olang_scope_hold(ptr %t17)
  %t19 = ptrtoint ptr %t18 to i64
  %t21 = inttoptr i64 %t19 to ptr
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t24 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %t21, ptr %t22, i64 %t15)
  store i64 %t24, ptr %l32
  br label %bb1
bb1:
  %t25 = load i64, ptr %l32, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = getelementptr %"compiler/mir:Fn", ptr %t26, i32 0, i32 7
  store ptr %t28, ptr %l34, !tbaa !29
  %t29 = load ptr, ptr %l34, !tbaa !29
  %t30 = call ptr @__olang_scope_or(ptr %v3, ptr %t29)
  %t31 = call ptr @__olang_scope_hold(ptr %t30)
  %t32 = ptrtoint ptr %t31 to i64
  %t34 = inttoptr i64 %t32 to ptr
  %t35 = load ptr, ptr %l34, !tbaa !29
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %t34, ptr %t35)
  store i64 %t36, ptr %l36
  br label %bb2
bb2:
  %t37 = load i64, ptr %l36, !tbaa !24
  store i64 %t37, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t38, %t39
  br i1 %t42, label %bb3, label %bb4
bb3:
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp sgt i64 %t44, 0
  br i1 %t46, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l40, !tbaa !24
  br label %bb8
bb5:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = sub i64 %t48, %t49
  %t53 = load i64, ptr %l8, !tbaa !24
  %t56 = add i64 %t52, %t53
  %t58 = sub i64 %t56, 1
  %t59 = load i64, ptr %l8, !tbaa !24
  %t62 = sdiv i64 %t58, %t59
  store i64 %t62, ptr %l43, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb7
bb7:
  %t64 = load i64, ptr %l43, !tbaa !24
  store i64 %t64, ptr %l40, !tbaa !24
  br label %bb8
bb8:
  %t65 = load i64, ptr %l40, !tbaa !24
  store i64 %t65, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load i64, ptr %l10, !tbaa !24
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = icmp slt i64 %t66, %t67
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb97
bb11:
  br label %bb12
bb12:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = mul i64 %t75, %t76
  %t82 = add i64 %t74, %t79
  store i64 %t82, ptr %l11, !tbaa !24
  %t84 = load ptr, ptr %l3, !tbaa !29
  %t86 = getelementptr %"compiler/mir:Fn", ptr %t84, i32 0, i32 7
  store ptr %t86, ptr %l62, !tbaa !29
  %t87 = load i64, ptr %l11, !tbaa !24
  %t88 = load ptr, ptr %l62, !tbaa !29
  %t89 = call ptr @__olang_scope_or(ptr %v3, ptr %t88)
  %t90 = call ptr @__olang_scope_hold(ptr %t89)
  %t91 = ptrtoint ptr %t90 to i64
  %t93 = inttoptr i64 %t91 to ptr
  %t94 = load ptr, ptr %l62, !tbaa !29
  %t96 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t93, ptr %t94, i64 %t87)
  store %"compiler/mir:Local" %t96, ptr %l65
  br label %bb13
bb13:
  %t97 = load %"compiler/mir:Local", ptr %l65
  store %"compiler/mir:Local" %t97, ptr %l12
  %t98 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t99 = load i32, ptr %t98, !range !{i32 0, i32 4}
  %t101 = trunc i64 0 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb14, label %bb15
bb14:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l5, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t109 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t110 = load i32, ptr %t109, !range !{i32 0, i32 4}
  %t112 = trunc i64 0 to i32
  %t113 = icmp eq i32 %t110, %t112
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb17, label %bb18
bb17:
  %t117 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t118 = load i32, ptr %t117, !range !{i32 0, i32 4}
  %t120 = trunc i64 2 to i32
  %t121 = icmp eq i32 %t118, %t120
  %t123 = xor i1 %t121, true
  store i1 %t123, ptr %l74, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb19
bb19:
  %t125 = load i1, ptr %l74, !tbaa !21
  br i1 %t125, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb21:
  br label %bb22
bb22:
  %t126 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 0
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = icmp eq i32 %t127, 0
  br i1 %t129, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb24:
  br label %bb25
bb25:
  %t131 = load ptr, ptr %l2, !tbaa !29
  store ptr %t131, ptr %l80, !tbaa !29
  %t132 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 0
  %t133 = load i32, ptr %t132, !tbaa !23
  %t134 = load ptr, ptr %l80, !tbaa !29
  %t135 = call ptr @__olang_scope_or(ptr %v2, ptr %t134)
  %t136 = call ptr @__olang_scope_hold(ptr %t135)
  %t137 = ptrtoint ptr %t136 to i64
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/emit:fnEm", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = call ptr @__olang_scope_or(ptr %v2, ptr %t141)
  %t144 = call ptr @__olang_scope_hold(ptr %t143)
  %t145 = ptrtoint ptr %t144 to i64
  %t147 = inttoptr i64 %t137 to ptr
  %t149 = inttoptr i64 %t145 to ptr
  %t150 = load ptr, ptr %l80, !tbaa !29
  %t152 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %t147, ptr %t149, ptr %t150, i32 %t133)
  store { i64, ptr } %t152, ptr %l86
  br label %bb26
bb26:
  %t153 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t153, ptr %l13, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t154, ptr %l87, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_scope_or(ptr %v2, ptr %t156)
  %t158 = call ptr @__olang_scope_hold(ptr %t157)
  %t159 = ptrtoint ptr %t158 to i64
  %t161 = inttoptr i64 %t159 to ptr
  %t162 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t163 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t161, ptr %s2, { i64, ptr } %t162, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d310, i32 0, i32 1) })
  store i1 %t163, ptr %l89
  br label %bb27
bb27:
  %t164 = load i1, ptr %l89, !tbaa !21
  br i1 %t164, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb31
bb29:
  %t165 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t165, ptr %l91, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_scope_or(ptr %v2, ptr %t167)
  %t169 = call ptr @__olang_scope_hold(ptr %t168)
  %t170 = ptrtoint ptr %t169 to i64
  %t172 = inttoptr i64 %t170 to ptr
  %t173 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %t172, ptr %s2, { i64, ptr } %t173, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d311, i32 0, i32 1) })
  store i1 %t174, ptr %l93
  br label %bb30
bb30:
  %t175 = load i1, ptr %l93, !tbaa !21
  store i1 %t175, ptr %l90, !tbaa !21
  br label %bb31
bb31:
  %t176 = load i1, ptr %l90, !tbaa !21
  br i1 %t176, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb33:
  br label %bb34
bb34:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t179 = load i32, ptr %t178, !tbaa !23
  %t182 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v2, ptr %t177, i32 %t179)
  store i64 %t182, ptr %l96
  br label %bb35
bb35:
  %t183 = load i64, ptr %l96, !tbaa !24
  %t184 = icmp sgt i64 %t183, 65536
  br i1 %t184, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb37:
  br label %bb38
bb38:
  %t186 = load ptr, ptr %l2, !tbaa !29
  store ptr %t186, ptr %l98, !tbaa !29
  %t187 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t188 = load i32, ptr %t187, !tbaa !23
  %t189 = load ptr, ptr %l98, !tbaa !29
  %t190 = call ptr @__olang_scope_or(ptr %v2, ptr %t189)
  %t191 = call ptr @__olang_scope_hold(ptr %t190)
  %t192 = ptrtoint ptr %t191 to i64
  %t194 = inttoptr i64 %t192 to ptr
  %t195 = load ptr, ptr %l98, !tbaa !29
  %t197 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %t194, ptr %t195, i32 %t188)
  store i64 %t197, ptr %l101
  br label %bb39
bb39:
  %t198 = load i64, ptr %l101, !tbaa !24
  store i64 %t198, ptr %l14, !tbaa !24
  %t199 = load i64, ptr %l14, !tbaa !24
  %t201 = icmp slt i64 %t199, 0
  br i1 %t201, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb41:
  br label %bb42
bb42:
  %t203 = load ptr, ptr %l2, !tbaa !29
  store ptr %t203, ptr %l104, !tbaa !29
  %t204 = load ptr, ptr %l104, !tbaa !29
  %t205 = call ptr @__olang_scope_or(ptr %v2, ptr %t204)
  %t206 = call ptr @__olang_scope_hold(ptr %t205)
  %t207 = ptrtoint ptr %t206 to i64
  %t209 = inttoptr i64 %t207 to ptr
  %t210 = load ptr, ptr %l104, !tbaa !29
  %t211 = call i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %t209, ptr %t210)
  store i64 %t211, ptr %l106
  br label %bb43
bb43:
  %t212 = load i64, ptr %l106, !tbaa !24
  store i64 %t212, ptr %l15, !tbaa !24
  %t213 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 1
  %t214 = getelementptr %"compiler/source:Span", ptr %t213, i32 0, i32 0
  %t215 = load i32, ptr %t214, !tbaa !23
  %t217 = icmp ne i32 %t215, 0
  br i1 %t217, label %bb44, label %bb45
bb44:
  %t219 = load ptr, ptr %l2, !tbaa !29
  %t221 = getelementptr %"compiler/emit:Emitter", ptr %t219, i32 0, i32 2
  %t222 = load ptr, ptr %t221, !tbaa !29
  store ptr %t222, ptr %l111, !tbaa !29
  %t223 = load ptr, ptr %l3, !tbaa !29
  %t225 = getelementptr %"compiler/mir:Fn", ptr %t223, i32 0, i32 2
  %t226 = load i64, ptr %t225, !tbaa !24
  %t227 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 1
  %t228 = getelementptr %"compiler/source:Span", ptr %t227, i32 0, i32 0
  %t229 = load i32, ptr %t228, !tbaa !23
  %t231 = sext i32 %t229 to i64
  %t232 = load ptr, ptr %l111, !tbaa !29
  %t233 = call ptr @__olang_scope_or(ptr %v2, ptr %t232)
  %t234 = call ptr @__olang_scope_hold(ptr %t233)
  %t235 = ptrtoint ptr %t234 to i64
  %t237 = inttoptr i64 %t235 to ptr
  %t238 = load ptr, ptr %l111, !tbaa !29
  %t241 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %t237, ptr %t238, i64 %t226, i64 %t231)
  store i64 %t241, ptr %l117
  br label %bb46
bb45:
  %t242 = load ptr, ptr %l2, !tbaa !29
  %t244 = getelementptr %"compiler/emit:Emitter", ptr %t242, i32 0, i32 2
  %t245 = load ptr, ptr %t244, !tbaa !29
  store ptr %t245, ptr %l119, !tbaa !29
  %t246 = load ptr, ptr %l3, !tbaa !29
  %t248 = getelementptr %"compiler/mir:Fn", ptr %t246, i32 0, i32 2
  %t249 = load i64, ptr %t248, !tbaa !24
  %t250 = load ptr, ptr %l3, !tbaa !29
  %t252 = getelementptr %"compiler/mir:Fn", ptr %t250, i32 0, i32 3
  %t253 = getelementptr %"compiler/source:Span", ptr %t252, i32 0, i32 0
  %t254 = load i32, ptr %t253, !tbaa !23
  %t256 = sext i32 %t254 to i64
  %t257 = load ptr, ptr %l119, !tbaa !29
  %t258 = call ptr @__olang_scope_or(ptr %v2, ptr %t257)
  %t259 = call ptr @__olang_scope_hold(ptr %t258)
  %t260 = ptrtoint ptr %t259 to i64
  %t262 = inttoptr i64 %t260 to ptr
  %t263 = load ptr, ptr %l119, !tbaa !29
  %t266 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %t262, ptr %t263, i64 %t249, i64 %t256)
  store i64 %t266, ptr %l126
  br label %bb47
bb46:
  %t267 = load i64, ptr %l117, !tbaa !24
  store i64 %t267, ptr %l109, !tbaa !24
  br label %bb48
bb47:
  %t268 = load i64, ptr %l126, !tbaa !24
  store i64 %t268, ptr %l109, !tbaa !24
  br label %bb48
bb48:
  %t269 = load i64, ptr %l109, !tbaa !24
  store i64 %t269, ptr %l16, !tbaa !24
  %t270 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t271 = load i32, ptr %t270, !range !{i32 0, i32 4}
  %t273 = trunc i64 0 to i32
  %t274 = icmp eq i32 %t271, %t273
  br i1 %t274, label %bb49, label %bb50
bb49:
  %t276 = load i64, ptr %l5, !tbaa !24
  %t277 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d312, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d312, i32 0, i32 1) }, 0
  %t280 = call i64 @__olang_fmt_i64(ptr null, i64 %t276)
  %t281 = add i64 %t278, %t280
  %t282 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t277, i64 %t278)
  %t283 = getelementptr i8, ptr %t282, i64 %t278
  %t284 = call i64 @__olang_fmt_i64(ptr %t283, i64 %t276)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t282, 1
  store { i64, ptr } %t286, ptr %l129, !tbaa !27
  br label %bb51
bb50:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d313, i32 0, i32 1) }, ptr %l129, !tbaa !27
  br label %bb51
bb51:
  %t289 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t289, ptr %l17, !tbaa !27
  %t290 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 3
  %t291 = load i32, ptr %t290, !range !{i32 0, i32 4}
  %t293 = trunc i64 0 to i32
  %t294 = icmp eq i32 %t291, %t293
  br i1 %t294, label %bb52, label %bb53
bb52:
  store i64 -1, ptr %l135, !tbaa !24
  br label %bb55
bb53:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 1
  %t298 = getelementptr %"compiler/source:Span", ptr %t297, i32 0, i32 0
  %t299 = load i32, ptr %t298, !tbaa !23
  %t302 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2escopeAt(ptr %v0, ptr %v3, ptr %t296, i32 %t299)
  store i64 %t302, ptr %l138
  br label %bb54
bb54:
  %t303 = load i64, ptr %l138, !tbaa !24
  store i64 %t303, ptr %l135, !tbaa !24
  br label %bb55
bb55:
  %t304 = load i64, ptr %l135, !tbaa !24
  store i64 %t304, ptr %l18, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i64, ptr %l18, !tbaa !24
  %t307 = load i64, ptr %l4, !tbaa !24
  %t311 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgBlockOf(ptr %v0, ptr %v3, ptr %v2, ptr %t305, i64 %t306, i64 %t307)
  store i64 %t311, ptr %l142
  br label %bb56
bb56:
  %t312 = load i64, ptr %l142, !tbaa !24
  store i64 %t312, ptr %l19, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = getelementptr %"compiler/emit:fnEm", ptr %t313, i32 0, i32 22
  store ptr %t315, ptr %l144, !tbaa !29
  %t316 = load i64, ptr %l15, !tbaa !24
  store i64 %t316, ptr %l145, !tbaa !24
  %t317 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t317, ptr %l146, !tbaa !27
  %t318 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = call ptr @__olang_scope_or(ptr %v2, ptr %t319)
  %t321 = call ptr @__olang_scope_hold(ptr %t320)
  %t322 = ptrtoint ptr %t321 to i64
  %t324 = inttoptr i64 %t322 to ptr
  %t325 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t326 = call { i64, ptr } @compiler_2femit_2eescape(ptr %t324, ptr %s2, { i64, ptr } %t325)
  store { i64, ptr } %t326, ptr %l148
  br label %bb57
bb57:
  %t327 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t328 = load i64, ptr %l19, !tbaa !24
  %t329 = load i64, ptr %l4, !tbaa !24
  %t330 = load i64, ptr %l16, !tbaa !24
  %t331 = load i64, ptr %l14, !tbaa !24
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d314, i32 0, i32 1) }, 0
  %t334 = load i64, ptr %l145, !tbaa !24
  %t335 = call i64 @__olang_fmt_i64(ptr null, i64 %t334)
  %t336 = add i64 %t333, %t335
  %t337 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d315, i32 0, i32 1) }, 1
  %t338 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d315, i32 0, i32 1) }, 0
  %t339 = add i64 %t336, %t338
  %t340 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 1
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = add i64 %t339, %t342
  %t344 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d316, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t348 = extractvalue { i64, ptr } %t327, 1
  %t349 = extractvalue { i64, ptr } %t327, 0
  %t350 = add i64 %t346, %t349
  %t351 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d317, i32 0, i32 1) }, 1
  %t352 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d317, i32 0, i32 1) }, 0
  %t353 = add i64 %t350, %t352
  %t355 = call i64 @__olang_fmt_i64(ptr null, i64 %t328)
  %t356 = add i64 %t353, %t355
  %t357 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d318, i32 0, i32 1) }, 1
  %t358 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d318, i32 0, i32 1) }, 0
  %t359 = add i64 %t356, %t358
  %t361 = call i64 @__olang_fmt_i64(ptr null, i64 %t329)
  %t362 = add i64 %t359, %t361
  %t363 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d319, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d319, i32 0, i32 1) }, 0
  %t365 = add i64 %t362, %t364
  %t367 = call i64 @__olang_fmt_i64(ptr null, i64 %t330)
  %t368 = add i64 %t365, %t367
  %t369 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d320, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d320, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t373 = call i64 @__olang_fmt_i64(ptr null, i64 %t331)
  %t374 = add i64 %t371, %t373
  %t375 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d321, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d321, i32 0, i32 1) }, 0
  %t377 = add i64 %t374, %t376
  %t378 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t377)
  call void @olang_textcopy(ptr %t378, ptr %t332, i64 %t333)
  %t379 = getelementptr i8, ptr %t378, i64 %t333
  %t380 = call i64 @__olang_fmt_i64(ptr %t379, i64 %t334)
  %t381 = getelementptr i8, ptr %t379, i64 %t335
  call void @olang_textcopy(ptr %t381, ptr %t337, i64 %t338)
  %t382 = getelementptr i8, ptr %t381, i64 %t338
  call void @olang_textcopy(ptr %t382, ptr %t341, i64 %t342)
  %t383 = getelementptr i8, ptr %t382, i64 %t342
  call void @olang_textcopy(ptr %t383, ptr %t344, i64 %t345)
  %t384 = getelementptr i8, ptr %t383, i64 %t345
  call void @olang_textcopy(ptr %t384, ptr %t348, i64 %t349)
  %t385 = getelementptr i8, ptr %t384, i64 %t349
  call void @olang_textcopy(ptr %t385, ptr %t351, i64 %t352)
  %t386 = getelementptr i8, ptr %t385, i64 %t352
  %t387 = call i64 @__olang_fmt_i64(ptr %t386, i64 %t328)
  %t388 = getelementptr i8, ptr %t386, i64 %t355
  call void @olang_textcopy(ptr %t388, ptr %t357, i64 %t358)
  %t389 = getelementptr i8, ptr %t388, i64 %t358
  %t390 = call i64 @__olang_fmt_i64(ptr %t389, i64 %t329)
  %t391 = getelementptr i8, ptr %t389, i64 %t361
  call void @olang_textcopy(ptr %t391, ptr %t363, i64 %t364)
  %t392 = getelementptr i8, ptr %t391, i64 %t364
  %t393 = call i64 @__olang_fmt_i64(ptr %t392, i64 %t330)
  %t394 = getelementptr i8, ptr %t392, i64 %t367
  call void @olang_textcopy(ptr %t394, ptr %t369, i64 %t370)
  %t395 = getelementptr i8, ptr %t394, i64 %t370
  %t396 = call i64 @__olang_fmt_i64(ptr %t395, i64 %t331)
  %t397 = getelementptr i8, ptr %t395, i64 %t373
  call void @olang_textcopy(ptr %t397, ptr %t375, i64 %t376)
  %t398 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t378, 1
  %t401 = load ptr, ptr %l144, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %s2, ptr %t401, { i64, ptr } %t399)
  br label %bb58
bb58:
  %t403 = load ptr, ptr %l2, !tbaa !29
  store ptr %t403, ptr %l156, !tbaa !29
  %t404 = load ptr, ptr %l156, !tbaa !29
  %t405 = call ptr @__olang_scope_or(ptr %v2, ptr %t404)
  %t406 = call ptr @__olang_scope_hold(ptr %t405)
  %t407 = ptrtoint ptr %t406 to i64
  %t409 = inttoptr i64 %t407 to ptr
  %t410 = load ptr, ptr %l156, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t409, ptr %s2, ptr %s2, ptr %t410, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d322, i32 0, i32 1) }, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d323, i32 0, i32 1) })
  br label %bb59
bb59:
  %t411 = call ptr @__olang_scope_hold(ptr %s2)
  %t412 = ptrtoint ptr %t411 to i64
  store i64 %t412, ptr %l158, !tbaa !24
  %t413 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e20
  br i1 %t413, label %bb60, label %bb61
bb60:
  %t415 = call ptr @__olang_region_make(ptr %s2)
  %t416 = ptrtoint ptr %t415 to i64
  store i64 %t416, ptr %l158, !tbaa !24
  br label %bb61
bb61:
  %t417 = load i64, ptr %l11, !tbaa !24
  %t418 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d324, i32 0, i32 1) }, 1
  %t419 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d324, i32 0, i32 1) }, 0
  %t421 = call i64 @__olang_fmt_i64(ptr null, i64 %t417)
  %t422 = add i64 %t419, %t421
  %t423 = load i64, ptr %l158
  %t424 = inttoptr i64 %t423 to ptr
  %t425 = call ptr @__olang_held_alloc(ptr %t424, i64 %t422)
  call void @olang_textcopy(ptr %t425, ptr %t418, i64 %t419)
  %t426 = getelementptr i8, ptr %t425, i64 %t419
  %t427 = call i64 @__olang_fmt_i64(ptr %t426, i64 %t417)
  %t428 = insertvalue { i64, ptr } undef, i64 %t422, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t425, 1
  store { i64, ptr } %t429, ptr %l161, !tbaa !27
  %t430 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e20
  br i1 %t430, label %bb62, label %bb63
bb62:
  %t432 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t432, 0
  %t435 = icmp eq i64 %t433, 0
  br i1 %t435, label %bb64, label %bb65
bb63:
  %t437 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t437, ptr %l20, !tbaa !27
  %t438 = call ptr @__olang_scope_hold(ptr %s2)
  %t439 = ptrtoint ptr %t438 to i64
  store i64 %t439, ptr %l165, !tbaa !24
  %t440 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e21
  br i1 %t440, label %bb66, label %bb67
bb64:
  store { i64, ptr } zeroinitializer, ptr %l161, !tbaa !27
  br label %bb65
bb65:
  %t442 = load i64, ptr %l158
  %t443 = inttoptr i64 %t442 to ptr
  %t444 = load { i64, ptr }, ptr %l161
  %t445 = extractvalue { i64, ptr } %t444, 1
  %t446 = call ptr @__olang_region_or(ptr %t445, ptr null)
  %t447 = icmp ne ptr %t446, null
  %t448 = select i1 %t447, ptr %t446, ptr null
  call void @__olang_region_settle_in(ptr %t443, ptr %t448)
  br label %bb63
bb66:
  %t449 = call ptr @__olang_region_make(ptr %s2)
  %t450 = ptrtoint ptr %t449 to i64
  store i64 %t450, ptr %l165, !tbaa !24
  br label %bb67
bb67:
  %t451 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d325, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d325, i32 0, i32 1) }, 0
  %t453 = load i64, ptr %l165
  %t454 = inttoptr i64 %t453 to ptr
  %t455 = call ptr @__olang_held_alloc(ptr %t454, i64 %t452)
  call void @olang_textcopy(ptr %t455, ptr %t451, i64 %t452)
  %t456 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t457 = insertvalue { i64, ptr } %t456, ptr %t455, 1
  store { i64, ptr } %t457, ptr %l167, !tbaa !27
  %t458 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e21
  br i1 %t458, label %bb68, label %bb69
bb68:
  %t460 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t460, 0
  %t463 = icmp eq i64 %t461, 0
  br i1 %t463, label %bb70, label %bb71
bb69:
  %t465 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t465, ptr %l21, !tbaa !27
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 4
  %t468 = load { i64, [1 x i64] }, ptr %t467
  %t471 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %t466, { i64, [1 x i64] } %t468)
  store i1 %t471, ptr %l173
  br label %bb72
bb70:
  store { i64, ptr } zeroinitializer, ptr %l167, !tbaa !27
  br label %bb71
bb71:
  %t472 = load i64, ptr %l165
  %t473 = inttoptr i64 %t472 to ptr
  %t474 = load { i64, ptr }, ptr %l167
  %t475 = extractvalue { i64, ptr } %t474, 1
  %t476 = call ptr @__olang_region_or(ptr %t475, ptr null)
  %t477 = icmp ne ptr %t476, null
  %t478 = select i1 %t477, ptr %t476, ptr null
  call void @__olang_region_settle_in(ptr %t473, ptr %t478)
  br label %bb69
bb72:
  %t479 = load i1, ptr %l173, !tbaa !21
  %t480 = xor i1 %t479, true
  br i1 %t480, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s13
  %t482 = call ptr @__olang_scope_hold(ptr %s2)
  %t483 = ptrtoint ptr %t482 to i64
  store i64 %t483, ptr %l175, !tbaa !24
  %t484 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e20
  br i1 %t484, label %bb75, label %bb76
bb74:
  br label %bb92
bb75:
  %t486 = call ptr @__olang_region_make(ptr %s2)
  %t487 = ptrtoint ptr %t486 to i64
  store i64 %t487, ptr %l175, !tbaa !24
  br label %bb76
bb76:
  %t488 = load i64, ptr %l11, !tbaa !24
  %t489 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d326, i32 0, i32 1) }, 1
  %t490 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d326, i32 0, i32 1) }, 0
  %t492 = call i64 @__olang_fmt_i64(ptr null, i64 %t488)
  %t493 = add i64 %t490, %t492
  %t494 = load i64, ptr %l175
  %t495 = inttoptr i64 %t494 to ptr
  %t496 = call ptr @__olang_held_alloc(ptr %t495, i64 %t493)
  call void @olang_textcopy(ptr %t496, ptr %t489, i64 %t490)
  %t497 = getelementptr i8, ptr %t496, i64 %t490
  %t498 = call i64 @__olang_fmt_i64(ptr %t497, i64 %t488)
  %t499 = insertvalue { i64, ptr } undef, i64 %t493, 0
  %t500 = insertvalue { i64, ptr } %t499, ptr %t496, 1
  store { i64, ptr } %t500, ptr %l178, !tbaa !27
  %t501 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e20
  br i1 %t501, label %bb77, label %bb78
bb77:
  %t503 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t503, 0
  %t506 = icmp eq i64 %t504, 0
  br i1 %t506, label %bb79, label %bb80
bb78:
  %t508 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t508, ptr %l22, !tbaa !27
  %t509 = call ptr @__olang_scope_hold(ptr %s2)
  %t510 = ptrtoint ptr %t509 to i64
  store i64 %t510, ptr %l182, !tbaa !24
  %t511 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e21
  br i1 %t511, label %bb81, label %bb82
bb79:
  store { i64, ptr } zeroinitializer, ptr %l178, !tbaa !27
  br label %bb80
bb80:
  %t513 = load i64, ptr %l175
  %t514 = inttoptr i64 %t513 to ptr
  %t515 = load { i64, ptr }, ptr %l178
  %t516 = extractvalue { i64, ptr } %t515, 1
  %t517 = call ptr @__olang_region_or(ptr %t516, ptr null)
  %t518 = icmp ne ptr %t517, null
  %t519 = select i1 %t518, ptr %t517, ptr null
  call void @__olang_region_settle_in(ptr %t514, ptr %t519)
  br label %bb78
bb81:
  %t520 = call ptr @__olang_region_make(ptr %s2)
  %t521 = ptrtoint ptr %t520 to i64
  store i64 %t521, ptr %l182, !tbaa !24
  br label %bb82
bb82:
  %t522 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d327, i32 0, i32 1) }, 1
  %t523 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d327, i32 0, i32 1) }, 0
  %t524 = load i64, ptr %l182
  %t525 = inttoptr i64 %t524 to ptr
  %t526 = call ptr @__olang_held_alloc(ptr %t525, i64 %t523)
  call void @olang_textcopy(ptr %t526, ptr %t522, i64 %t523)
  %t527 = insertvalue { i64, ptr } undef, i64 %t523, 0
  %t528 = insertvalue { i64, ptr } %t527, ptr %t526, 1
  store { i64, ptr } %t528, ptr %l184, !tbaa !27
  %t529 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e21
  br i1 %t529, label %bb83, label %bb84
bb83:
  %t531 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t531, 0
  %t534 = icmp eq i64 %t532, 0
  br i1 %t534, label %bb85, label %bb86
bb84:
  %t536 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t536, ptr %l23, !tbaa !27
  %t537 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t537, ptr %l188, !tbaa !27
  %t538 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t538, ptr %l189, !tbaa !27
  %t539 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 0
  store i64 %t540, ptr %l190, !tbaa !24
  %t541 = load i64, ptr %l190, !tbaa !24
  %t542 = mul i64 %t541, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t542)
  %t544 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  store { i64, ptr } %t545, ptr %l191, !tbaa !27
  %t546 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = load i64, ptr %l190, !tbaa !24
  %t551 = mul i64 %t550, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t547, ptr %t549, i64 %t551, i1 false)
  %t552 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t552, ptr %l20, !tbaa !27
  %t553 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e20
  br i1 %t553, label %bb87, label %bb88
bb85:
  store { i64, ptr } zeroinitializer, ptr %l184, !tbaa !27
  br label %bb86
bb86:
  %t555 = load i64, ptr %l182
  %t556 = inttoptr i64 %t555 to ptr
  %t557 = load { i64, ptr }, ptr %l184
  %t558 = extractvalue { i64, ptr } %t557, 1
  %t559 = call ptr @__olang_region_or(ptr %t558, ptr null)
  %t560 = icmp ne ptr %t559, null
  %t561 = select i1 %t560, ptr %t559, ptr null
  call void @__olang_region_settle_in(ptr %t556, ptr %t561)
  br label %bb84
bb87:
  %t562 = load { i64, ptr }, ptr %l189
  %t563 = extractvalue { i64, ptr } %t562, 1
  call void @__olang_region_release(ptr %t563)
  store { i64, ptr } zeroinitializer, ptr %l189
  br label %bb88
bb88:
  %t564 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t564, ptr %l193, !tbaa !27
  %t565 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t565, ptr %l194, !tbaa !27
  %t566 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t566, 0
  store i64 %t567, ptr %l195, !tbaa !24
  %t568 = load i64, ptr %l195, !tbaa !24
  %t569 = mul i64 %t568, 1
  %t570 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t569)
  %t571 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t572 = insertvalue { i64, ptr } %t571, ptr %t570, 1
  store { i64, ptr } %t572, ptr %l196, !tbaa !27
  %t573 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t574 = load ptr, ptr %t573, !tbaa !27
  %t575 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !27
  %t577 = load i64, ptr %l195, !tbaa !24
  %t578 = mul i64 %t577, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t574, ptr %t576, i64 %t578, i1 false)
  %t579 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t579, ptr %l21, !tbaa !27
  %t580 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e21
  br i1 %t580, label %bb89, label %bb90
bb89:
  %t582 = load { i64, ptr }, ptr %l194
  %t583 = extractvalue { i64, ptr } %t582, 1
  call void @__olang_region_release(ptr %t583)
  store { i64, ptr } zeroinitializer, ptr %l194
  br label %bb90
bb90:
  %t584 = load ptr, ptr %l1, !tbaa !29
  %t585 = load i64, ptr %l11, !tbaa !24
  %t586 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d328, i32 0, i32 1) }, 1
  %t587 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d328, i32 0, i32 1) }, 0
  %t589 = call i64 @__olang_fmt_i64(ptr null, i64 %t585)
  %t590 = add i64 %t587, %t589
  %t591 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d329, i32 0, i32 1) }, 1
  %t592 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d329, i32 0, i32 1) }, 0
  %t593 = add i64 %t590, %t592
  %t594 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t593)
  call void @olang_textcopy(ptr %t594, ptr %t586, i64 %t587)
  %t595 = getelementptr i8, ptr %t594, i64 %t587
  %t596 = call i64 @__olang_fmt_i64(ptr %t595, i64 %t585)
  %t597 = getelementptr i8, ptr %t595, i64 %t589
  call void @olang_textcopy(ptr %t597, ptr %t591, i64 %t592)
  %t598 = insertvalue { i64, ptr } undef, i64 %t593, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t594, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t584, { i64, ptr } %t599)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s13)
  br label %bb92
bb92:
  %t603 = load ptr, ptr %l1, !tbaa !29
  store ptr %t603, ptr %l202, !tbaa !29
  %t604 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t604, ptr %l203, !tbaa !27
  %t605 = load i64, ptr %l15, !tbaa !24
  store i64 %t605, ptr %l204, !tbaa !24
  %t606 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t606, ptr %l205, !tbaa !27
  %t607 = load ptr, ptr %l0, !tbaa !29
  store ptr %t607, ptr %l206, !tbaa !29
  %t608 = load ptr, ptr %l2, !tbaa !29
  %t610 = getelementptr %"compiler/emit:Emitter", ptr %t608, i32 0, i32 2
  %t611 = load ptr, ptr %t610, !tbaa !29
  store ptr %t611, ptr %l208, !tbaa !29
  %t612 = load ptr, ptr %l3, !tbaa !29
  %t614 = getelementptr %"compiler/mir:Fn", ptr %t612, i32 0, i32 2
  %t615 = load i64, ptr %t614, !tbaa !24
  %t616 = load ptr, ptr %l3, !tbaa !29
  %t618 = getelementptr %"compiler/mir:Fn", ptr %t616, i32 0, i32 3
  %t619 = getelementptr %"compiler/source:Span", ptr %t618, i32 0, i32 0
  %t620 = load i32, ptr %t619, !tbaa !23
  %t622 = sext i32 %t620 to i64
  %t623 = load ptr, ptr %l208, !tbaa !29
  %t624 = call ptr @__olang_scope_or(ptr %v2, ptr %t623)
  %t625 = call ptr @__olang_scope_hold(ptr %t624)
  %t626 = ptrtoint ptr %t625 to i64
  %t628 = inttoptr i64 %t626 to ptr
  %t629 = load ptr, ptr %l208, !tbaa !29
  %t632 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %t628, ptr %t629, i64 %t615, i64 %t622)
  store i64 %t632, ptr %l215
  br label %bb93
bb93:
  %t633 = load i64, ptr %l18, !tbaa !24
  %t634 = load ptr, ptr %l206, !tbaa !29
  %t635 = load i64, ptr %l215, !tbaa !24
  %t637 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %s2, ptr %v2, ptr %t634, i64 %t635, i64 %t633)
  store { i64, ptr } %t637, ptr %l217
  br label %bb94
bb94:
  %t638 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d330, i32 0, i32 1) }, 1
  %t639 = extractvalue { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d330, i32 0, i32 1) }, 0
  %t640 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t641 = extractvalue { i64, ptr } %t640, 1
  %t642 = extractvalue { i64, ptr } %t640, 0
  %t643 = add i64 %t639, %t642
  %t644 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d331, i32 0, i32 1) }, 1
  %t645 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d331, i32 0, i32 1) }, 0
  %t646 = add i64 %t643, %t645
  %t647 = load i64, ptr %l204, !tbaa !24
  %t648 = call i64 @__olang_fmt_i64(ptr null, i64 %t647)
  %t649 = add i64 %t646, %t648
  %t650 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d332, i32 0, i32 1) }, 1
  %t651 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d332, i32 0, i32 1) }, 0
  %t652 = add i64 %t649, %t651
  %t653 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t653, 1
  %t655 = extractvalue { i64, ptr } %t653, 0
  %t656 = add i64 %t652, %t655
  %t657 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 1
  %t658 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d333, i32 0, i32 1) }, 0
  %t659 = add i64 %t656, %t658
  %t660 = load { i64, ptr }, ptr %l217, !tbaa !27
  %t661 = extractvalue { i64, ptr } %t660, 1
  %t662 = extractvalue { i64, ptr } %t660, 0
  %t663 = add i64 %t659, %t662
  %t664 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 1
  %t665 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d334, i32 0, i32 1) }, 0
  %t666 = add i64 %t663, %t665
  %t667 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t666)
  call void @olang_textcopy(ptr %t667, ptr %t638, i64 %t639)
  %t668 = getelementptr i8, ptr %t667, i64 %t639
  call void @olang_textcopy(ptr %t668, ptr %t641, i64 %t642)
  %t669 = getelementptr i8, ptr %t668, i64 %t642
  call void @olang_textcopy(ptr %t669, ptr %t644, i64 %t645)
  %t670 = getelementptr i8, ptr %t669, i64 %t645
  %t671 = call i64 @__olang_fmt_i64(ptr %t670, i64 %t647)
  %t672 = getelementptr i8, ptr %t670, i64 %t648
  call void @olang_textcopy(ptr %t672, ptr %t650, i64 %t651)
  %t673 = getelementptr i8, ptr %t672, i64 %t651
  call void @olang_textcopy(ptr %t673, ptr %t654, i64 %t655)
  %t674 = getelementptr i8, ptr %t673, i64 %t655
  call void @olang_textcopy(ptr %t674, ptr %t657, i64 %t658)
  %t675 = getelementptr i8, ptr %t674, i64 %t658
  call void @olang_textcopy(ptr %t675, ptr %t661, i64 %t662)
  %t676 = getelementptr i8, ptr %t675, i64 %t662
  call void @olang_textcopy(ptr %t676, ptr %t664, i64 %t665)
  %t677 = insertvalue { i64, ptr } undef, i64 %t666, 0
  %t678 = insertvalue { i64, ptr } %t677, ptr %t667, 1
  %t680 = load ptr, ptr %l202, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t680, { i64, ptr } %t678)
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s2)
  br label %bb96
bb96:
  %t682 = load i64, ptr %l10, !tbaa !24
  %t685 = add i64 %t682, 1
  store i64 %t685, ptr %l10, !tbaa !24
  br label %bb9
bb97:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efloatOverflows(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l49 = alloca i1
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l62 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l105 = alloca i64
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l112 = alloca i64
  %l120 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l129 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = call ptr @__olang_scope_hold(ptr %s0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l13, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e6
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = call ptr @__olang_region_make(ptr %s0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l13, !tbaa !24
  br label %bb2
bb2:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = extractvalue { i64, ptr } %t15, 0
  %t19 = load i64, ptr %l13
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call ptr @__olang_held_alloc(ptr %t20, i64 %t18)
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l16, !tbaa !27
  %t24 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e6
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  %t29 = icmp eq i64 %t27, 0
  br i1 %t29, label %bb5, label %bb6
bb4:
  %t31 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load ptr, ptr %l5, !tbaa !29
  store ptr %t32, ptr %l20, !tbaa !29
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = call ptr @__olang_scope_or(ptr %v4, ptr %t34)
  %t36 = call ptr @__olang_scope_hold(ptr %t35)
  %t37 = ptrtoint ptr %t36 to i64
  %t39 = inttoptr i64 %t37 to ptr
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t42 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %t39, ptr %t40, i32 %a3)
  store i64 %t42, ptr %l23
  br label %bb7
bb5:
  store { i64, ptr } zeroinitializer, ptr %l16, !tbaa !27
  br label %bb6
bb6:
  %t43 = load i64, ptr %l13
  %t44 = inttoptr i64 %t43 to ptr
  %t45 = load { i64, ptr }, ptr %l16
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = call ptr @__olang_region_or(ptr %t46, ptr null)
  %t48 = icmp ne ptr %t47, null
  %t49 = select i1 %t48, ptr %t47, ptr null
  call void @__olang_region_settle_in(ptr %t44, ptr %t49)
  br label %bb4
bb7:
  %t50 = load i64, ptr %l23, !tbaa !24
  %t51 = icmp ne i64 %t50, 64
  br i1 %t51, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t53 = call ptr @__olang_scope_hold(ptr %s0)
  %t54 = ptrtoint ptr %t53 to i64
  store i64 %t54, ptr %l25, !tbaa !24
  %t55 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e6
  br i1 %t55, label %bb10, label %bb11
bb9:
  br label %bb19
bb10:
  %t57 = call ptr @__olang_region_make(ptr %s0)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l25, !tbaa !24
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d335, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d335, i32 0, i32 1) }, 0
  %t65 = extractvalue { i64, ptr } %a2, 1
  %t66 = extractvalue { i64, ptr } %a2, 0
  %t67 = add i64 %t63, %t66
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d336, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d336, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t72 = extractvalue { i64, ptr } %t61, 1
  %t73 = extractvalue { i64, ptr } %t61, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d337, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d337, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t62, i64 %t63)
  %t79 = getelementptr i8, ptr %t78, i64 %t63
  call void @olang_textcopy(ptr %t79, ptr %t65, i64 %t66)
  %t80 = getelementptr i8, ptr %t79, i64 %t66
  call void @olang_textcopy(ptr %t80, ptr %t68, i64 %t69)
  %t81 = getelementptr i8, ptr %t80, i64 %t69
  call void @olang_textcopy(ptr %t81, ptr %t72, i64 %t73)
  %t82 = getelementptr i8, ptr %t81, i64 %t73
  call void @olang_textcopy(ptr %t82, ptr %t75, i64 %t76)
  %t83 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t78, 1
  %t86 = load i64, ptr %l25
  %t87 = inttoptr i64 %t86 to ptr
  %t90 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s2, ptr %t87, ptr %v4, ptr %t59, { i64, ptr } %t84)
  store { i64, ptr } %t90, ptr %l32
  br label %bb12
bb12:
  %t91 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e6
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t96 = icmp eq i64 %t94, 0
  br i1 %t96, label %bb15, label %bb16
bb14:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l36, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t99, ptr %l6, !tbaa !27
  %t100 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e6
  br i1 %t100, label %bb17, label %bb18
bb15:
  store { i64, ptr } zeroinitializer, ptr %l32, !tbaa !27
  br label %bb16
bb16:
  %t102 = load i64, ptr %l25
  %t103 = inttoptr i64 %t102 to ptr
  %t104 = load { i64, ptr }, ptr %l32
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = call ptr @__olang_region_or(ptr %t105, ptr null)
  %t107 = icmp ne ptr %t106, null
  %t108 = select i1 %t107, ptr %t106, ptr null
  call void @__olang_region_settle_in(ptr %t103, ptr %t108)
  br label %bb14
bb17:
  %t109 = load { i64, ptr }, ptr %l36
  %t110 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release(ptr %t110)
  store { i64, ptr } zeroinitializer, ptr %l36
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t111 = load ptr, ptr %l5, !tbaa !29
  store ptr %t111, ptr %l38, !tbaa !29
  %t112 = load i32, ptr %l4, !tbaa !23
  %t113 = load ptr, ptr %l38, !tbaa !29
  %t114 = call ptr @__olang_scope_or(ptr %v4, ptr %t113)
  %t115 = call ptr @__olang_scope_hold(ptr %t114)
  %t116 = ptrtoint ptr %t115 to i64
  %t118 = inttoptr i64 %t116 to ptr
  %t119 = load ptr, ptr %l38, !tbaa !29
  %t121 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %t118, ptr %t119, i32 %t112)
  store i64 %t121, ptr %l41
  br label %bb20
bb20:
  %t122 = load i64, ptr %l41, !tbaa !24
  store i64 %t122, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d338, i32 0, i32 1) }, ptr %l42, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t123, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d339, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t125, ptr %l9, !tbaa !27
  %t127 = load ptr, ptr %l5, !tbaa !29
  store ptr %t127, ptr %l46, !tbaa !29
  %t128 = load i32, ptr %l4, !tbaa !23
  %t129 = load ptr, ptr %l46, !tbaa !29
  %t130 = call ptr @__olang_scope_or(ptr %v4, ptr %t129)
  %t131 = call ptr @__olang_scope_hold(ptr %t130)
  %t132 = ptrtoint ptr %t131 to i64
  %t134 = inttoptr i64 %t132 to ptr
  %t135 = load ptr, ptr %l46, !tbaa !29
  %t137 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %t134, ptr %t135, i32 %t128)
  store i1 %t137, ptr %l49
  br label %bb21
bb21:
  %t138 = load i1, ptr %l49, !tbaa !21
  br i1 %t138, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t139 = call ptr @__olang_scope_hold(ptr %s0)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l50, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t141, label %bb24, label %bb25
bb23:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load i64, ptr %l7, !tbaa !24
  %t145 = icmp sgt i64 %t143, 53
  br i1 %t145, label %bb43, label %bb44
bb24:
  %t147 = call ptr @__olang_region_make(ptr %s0)
  %t148 = ptrtoint ptr %t147 to i64
  store i64 %t148, ptr %l50, !tbaa !24
  br label %bb25
bb25:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t151 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d340, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d340, i32 0, i32 1) }, 0
  %t154 = extractvalue { i64, ptr } %t150, 1
  %t155 = extractvalue { i64, ptr } %t150, 0
  %t156 = add i64 %t152, %t155
  %t157 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d341, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d341, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t159)
  call void @olang_textcopy(ptr %t160, ptr %t151, i64 %t152)
  %t161 = getelementptr i8, ptr %t160, i64 %t152
  call void @olang_textcopy(ptr %t161, ptr %t154, i64 %t155)
  %t162 = getelementptr i8, ptr %t161, i64 %t155
  call void @olang_textcopy(ptr %t162, ptr %t157, i64 %t158)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t160, 1
  %t166 = load i64, ptr %l50
  %t167 = inttoptr i64 %t166 to ptr
  %t170 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %t167, ptr %v4, ptr %t149, { i64, ptr } %t164)
  store { i64, ptr } %t170, ptr %l56
  br label %bb26
bb26:
  %t171 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t171, label %bb27, label %bb28
bb27:
  %t173 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 0
  %t176 = icmp eq i64 %t174, 0
  br i1 %t176, label %bb29, label %bb30
bb28:
  %t178 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t178, ptr %l60, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t179, ptr %l8, !tbaa !27
  %t180 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t180, label %bb31, label %bb32
bb29:
  store { i64, ptr } zeroinitializer, ptr %l56, !tbaa !27
  br label %bb30
bb30:
  %t182 = load i64, ptr %l50
  %t183 = inttoptr i64 %t182 to ptr
  %t184 = load { i64, ptr }, ptr %l56
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = call ptr @__olang_region_or(ptr %t185, ptr null)
  %t187 = icmp ne ptr %t186, null
  %t188 = select i1 %t187, ptr %t186, ptr null
  call void @__olang_region_settle_in(ptr %t183, ptr %t188)
  br label %bb28
bb31:
  %t189 = load { i64, ptr }, ptr %l60
  %t190 = extractvalue { i64, ptr } %t189, 1
  call void @__olang_region_release(ptr %t190)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %bb32
bb32:
  %t191 = call ptr @__olang_scope_hold(ptr %s0)
  %t192 = ptrtoint ptr %t191 to i64
  store i64 %t192, ptr %l62, !tbaa !24
  %t193 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e9
  br i1 %t193, label %bb33, label %bb34
bb33:
  %t195 = call ptr @__olang_region_make(ptr %s0)
  %t196 = ptrtoint ptr %t195 to i64
  store i64 %t196, ptr %l62, !tbaa !24
  br label %bb34
bb34:
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l64, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t198, ptr %l65, !tbaa !27
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/emit:fnEm", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  store ptr %t202, ptr %l67, !tbaa !29
  %t203 = load i64, ptr %l7, !tbaa !24
  %t204 = load ptr, ptr %l67, !tbaa !29
  %t205 = call ptr @__olang_scope_or(ptr %v4, ptr %t204)
  %t206 = call ptr @__olang_scope_hold(ptr %t205)
  %t207 = ptrtoint ptr %t206 to i64
  %t209 = inttoptr i64 %t207 to ptr
  %t210 = load ptr, ptr %l67, !tbaa !29
  %t212 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %t209, ptr %s4, ptr %t210, i64 %t203)
  store { i64, ptr } %t212, ptr %l70
  br label %bb35
bb35:
  %t213 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d342, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d342, i32 0, i32 1) }, 0
  %t215 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 1
  %t217 = extractvalue { i64, ptr } %t215, 0
  %t218 = add i64 %t214, %t217
  %t219 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d343, i32 0, i32 1) }, 1
  %t220 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d343, i32 0, i32 1) }, 0
  %t221 = add i64 %t218, %t220
  %t222 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = add i64 %t221, %t224
  %t226 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t225)
  call void @olang_textcopy(ptr %t226, ptr %t213, i64 %t214)
  %t227 = getelementptr i8, ptr %t226, i64 %t214
  call void @olang_textcopy(ptr %t227, ptr %t216, i64 %t217)
  %t228 = getelementptr i8, ptr %t227, i64 %t217
  call void @olang_textcopy(ptr %t228, ptr %t219, i64 %t220)
  %t229 = getelementptr i8, ptr %t228, i64 %t220
  call void @olang_textcopy(ptr %t229, ptr %t223, i64 %t224)
  %t230 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t226, 1
  %t233 = load i64, ptr %l62
  %t234 = inttoptr i64 %t233 to ptr
  %t235 = load ptr, ptr %l64, !tbaa !29
  %t237 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s4, ptr %t234, ptr %v4, ptr %t235, { i64, ptr } %t231)
  store { i64, ptr } %t237, ptr %l73
  br label %bb36
bb36:
  %t238 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e9
  br i1 %t238, label %bb37, label %bb38
bb37:
  %t240 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  %t243 = icmp eq i64 %t241, 0
  br i1 %t243, label %bb39, label %bb40
bb38:
  %t245 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t245, ptr %l77, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t246, ptr %l9, !tbaa !27
  %t247 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e9
  br i1 %t247, label %bb41, label %bb42
bb39:
  store { i64, ptr } zeroinitializer, ptr %l73, !tbaa !27
  br label %bb40
bb40:
  %t249 = load i64, ptr %l62
  %t250 = inttoptr i64 %t249 to ptr
  %t251 = load { i64, ptr }, ptr %l73
  %t252 = extractvalue { i64, ptr } %t251, 1
  %t253 = call ptr @__olang_region_or(ptr %t252, ptr null)
  %t254 = icmp ne ptr %t253, null
  %t255 = select i1 %t254, ptr %t253, ptr null
  call void @__olang_region_settle_in(ptr %t250, ptr %t255)
  br label %bb38
bb41:
  %t256 = load { i64, ptr }, ptr %l77
  %t257 = extractvalue { i64, ptr } %t256, 1
  call void @__olang_region_release(ptr %t257)
  store { i64, ptr } zeroinitializer, ptr %l77
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb76
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t258 = call ptr @__olang_scope_hold(ptr %s0)
  %t259 = ptrtoint ptr %t258 to i64
  store i64 %t259, ptr %l81, !tbaa !24
  %t260 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t260, label %bb45, label %bb46
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t262 = call ptr @__olang_scope_hold(ptr %s0)
  %t263 = ptrtoint ptr %t262 to i64
  store i64 %t263, ptr %l105, !tbaa !24
  %t264 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t264, label %bb55, label %bb56
bb45:
  %t266 = call ptr @__olang_region_make(ptr %s0)
  %t267 = ptrtoint ptr %t266 to i64
  store i64 %t267, ptr %l81, !tbaa !24
  br label %bb46
bb46:
  %t268 = load ptr, ptr %l0, !tbaa !29
  store ptr %t268, ptr %l83, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t269, ptr %l84, !tbaa !27
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/emit:fnEm", ptr %t270, i32 0, i32 0
  %t273 = load ptr, ptr %t272, !tbaa !29
  store ptr %t273, ptr %l86, !tbaa !29
  %t274 = bitcast double 0x3ff0000000000000 to i64
  %t276 = load i64, ptr %l7, !tbaa !24
  %t278 = sub i64 %t276, 1
  %t280 = shl i64 %t278, 52
  %t283 = add i64 %t274, %t280
  %t284 = shl i64 1, 63
  %t287 = or i64 %t283, %t284
  %t288 = load ptr, ptr %l86, !tbaa !29
  %t289 = call ptr @__olang_scope_or(ptr %v4, ptr %t288)
  %t290 = call ptr @__olang_scope_hold(ptr %t289)
  %t291 = ptrtoint ptr %t290 to i64
  %t293 = inttoptr i64 %t291 to ptr
  %t294 = load ptr, ptr %l86, !tbaa !29
  %t296 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %t293, ptr %s8, ptr %t294, i32 14, i64 %t287)
  store { i64, ptr } %t296, ptr %l96
  br label %bb47
bb47:
  %t297 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d344, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d344, i32 0, i32 1) }, 0
  %t299 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = add i64 %t298, %t301
  %t303 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d345, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d345, i32 0, i32 1) }, 0
  %t305 = add i64 %t302, %t304
  %t306 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = add i64 %t305, %t308
  %t310 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t309)
  call void @olang_textcopy(ptr %t310, ptr %t297, i64 %t298)
  %t311 = getelementptr i8, ptr %t310, i64 %t298
  call void @olang_textcopy(ptr %t311, ptr %t300, i64 %t301)
  %t312 = getelementptr i8, ptr %t311, i64 %t301
  call void @olang_textcopy(ptr %t312, ptr %t303, i64 %t304)
  %t313 = getelementptr i8, ptr %t312, i64 %t304
  call void @olang_textcopy(ptr %t313, ptr %t307, i64 %t308)
  %t314 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t310, 1
  %t317 = load i64, ptr %l81
  %t318 = inttoptr i64 %t317 to ptr
  %t319 = load ptr, ptr %l83, !tbaa !29
  %t321 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s8, ptr %t318, ptr %v4, ptr %t319, { i64, ptr } %t315)
  store { i64, ptr } %t321, ptr %l99
  br label %bb48
bb48:
  %t322 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t322, label %bb49, label %bb50
bb49:
  %t324 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t325 = extractvalue { i64, ptr } %t324, 0
  %t327 = icmp eq i64 %t325, 0
  br i1 %t327, label %bb51, label %bb52
bb50:
  %t329 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t329, ptr %l103, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t330, ptr %l8, !tbaa !27
  %t331 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t331, label %bb53, label %bb54
bb51:
  store { i64, ptr } zeroinitializer, ptr %l99, !tbaa !27
  br label %bb52
bb52:
  %t333 = load i64, ptr %l81
  %t334 = inttoptr i64 %t333 to ptr
  %t335 = load { i64, ptr }, ptr %l99
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = call ptr @__olang_region_or(ptr %t336, ptr null)
  %t338 = icmp ne ptr %t337, null
  %t339 = select i1 %t338, ptr %t337, ptr null
  call void @__olang_region_settle_in(ptr %t334, ptr %t339)
  br label %bb50
bb53:
  %t340 = load { i64, ptr }, ptr %l103
  %t341 = extractvalue { i64, ptr } %t340, 1
  call void @__olang_region_release(ptr %t341)
  store { i64, ptr } zeroinitializer, ptr %l103
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb65
bb55:
  %t342 = call ptr @__olang_region_make(ptr %s0)
  %t343 = ptrtoint ptr %t342 to i64
  store i64 %t343, ptr %l105, !tbaa !24
  br label %bb56
bb56:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l107, !tbaa !29
  %t345 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t345, ptr %l108, !tbaa !27
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/emit:fnEm", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  store ptr %t349, ptr %l110, !tbaa !29
  %t350 = load i64, ptr %l7, !tbaa !24
  %t352 = sub i64 %t350, 1
  store i64 %t352, ptr %l112, !tbaa !24
  %t353 = load i64, ptr %l112, !tbaa !24
  %t354 = load i64, ptr %l112, !tbaa !24
  %t355 = shl i64 1, %t354
  %t357 = sitofp i64 %t355 to double
  %t359 = fsub double 0x0000000000000000, %t357
  %t361 = fsub double %t359, 0x3ff0000000000000
  %t363 = bitcast double %t361 to i64
  %t365 = load ptr, ptr %l110, !tbaa !29
  %t366 = call ptr @__olang_scope_or(ptr %v4, ptr %t365)
  %t367 = call ptr @__olang_scope_hold(ptr %t366)
  %t368 = ptrtoint ptr %t367 to i64
  %t370 = inttoptr i64 %t368 to ptr
  %t371 = load ptr, ptr %l110, !tbaa !29
  %t373 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %t370, ptr %s10, ptr %t371, i32 14, i64 %t363)
  store { i64, ptr } %t373, ptr %l120
  br label %bb57
bb57:
  %t374 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d346, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d346, i32 0, i32 1) }, 0
  %t376 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t377 = extractvalue { i64, ptr } %t376, 1
  %t378 = extractvalue { i64, ptr } %t376, 0
  %t379 = add i64 %t375, %t378
  %t380 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d347, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d347, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t383 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  %t386 = add i64 %t382, %t385
  %t387 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t386)
  call void @olang_textcopy(ptr %t387, ptr %t374, i64 %t375)
  %t388 = getelementptr i8, ptr %t387, i64 %t375
  call void @olang_textcopy(ptr %t388, ptr %t377, i64 %t378)
  %t389 = getelementptr i8, ptr %t388, i64 %t378
  call void @olang_textcopy(ptr %t389, ptr %t380, i64 %t381)
  %t390 = getelementptr i8, ptr %t389, i64 %t381
  call void @olang_textcopy(ptr %t390, ptr %t384, i64 %t385)
  %t391 = insertvalue { i64, ptr } undef, i64 %t386, 0
  %t392 = insertvalue { i64, ptr } %t391, ptr %t387, 1
  %t394 = load i64, ptr %l105
  %t395 = inttoptr i64 %t394 to ptr
  %t396 = load ptr, ptr %l107, !tbaa !29
  %t398 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s10, ptr %t395, ptr %v4, ptr %t396, { i64, ptr } %t392)
  store { i64, ptr } %t398, ptr %l123
  br label %bb58
bb58:
  %t399 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t399, label %bb59, label %bb60
bb59:
  %t401 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 0
  %t404 = icmp eq i64 %t402, 0
  br i1 %t404, label %bb61, label %bb62
bb60:
  %t406 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t406, ptr %l127, !tbaa !27
  %t407 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t407, ptr %l8, !tbaa !27
  %t408 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8
  br i1 %t408, label %bb63, label %bb64
bb61:
  store { i64, ptr } zeroinitializer, ptr %l123, !tbaa !27
  br label %bb62
bb62:
  %t410 = load i64, ptr %l105
  %t411 = inttoptr i64 %t410 to ptr
  %t412 = load { i64, ptr }, ptr %l123
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = call ptr @__olang_region_or(ptr %t413, ptr null)
  %t415 = icmp ne ptr %t414, null
  %t416 = select i1 %t415, ptr %t414, ptr null
  call void @__olang_region_settle_in(ptr %t411, ptr %t416)
  br label %bb60
bb63:
  %t417 = load { i64, ptr }, ptr %l127
  %t418 = extractvalue { i64, ptr } %t417, 1
  call void @__olang_region_release(ptr %t418)
  store { i64, ptr } zeroinitializer, ptr %l127
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s10)
  br label %bb65
bb65:
  %t419 = call ptr @__olang_scope_hold(ptr %s0)
  %t420 = ptrtoint ptr %t419 to i64
  store i64 %t420, ptr %l129, !tbaa !24
  %t421 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e9
  br i1 %t421, label %bb66, label %bb67
bb66:
  %t423 = call ptr @__olang_region_make(ptr %s0)
  %t424 = ptrtoint ptr %t423 to i64
  store i64 %t424, ptr %l129, !tbaa !24
  br label %bb67
bb67:
  %t425 = load ptr, ptr %l0, !tbaa !29
  store ptr %t425, ptr %l131, !tbaa !29
  %t426 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t426, ptr %l132, !tbaa !27
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/emit:fnEm", ptr %t427, i32 0, i32 0
  %t430 = load ptr, ptr %t429, !tbaa !29
  store ptr %t430, ptr %l134, !tbaa !29
  %t431 = load i64, ptr %l7, !tbaa !24
  %t433 = sub i64 %t431, 1
  %t434 = load ptr, ptr %l134, !tbaa !29
  %t435 = call ptr @__olang_scope_or(ptr %v4, ptr %t434)
  %t436 = call ptr @__olang_scope_hold(ptr %t435)
  %t437 = ptrtoint ptr %t436 to i64
  %t439 = inttoptr i64 %t437 to ptr
  %t440 = load ptr, ptr %l134, !tbaa !29
  %t442 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2epow2(ptr %t439, ptr %s7, ptr %t440, i64 %t433)
  store { i64, ptr } %t442, ptr %l138
  br label %bb68
bb68:
  %t443 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d348, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d348, i32 0, i32 1) }, 0
  %t445 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 1
  %t447 = extractvalue { i64, ptr } %t445, 0
  %t448 = add i64 %t444, %t447
  %t449 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d349, i32 0, i32 1) }, 0
  %t451 = add i64 %t448, %t450
  %t452 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t452, 1
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = add i64 %t451, %t454
  %t456 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t455)
  call void @olang_textcopy(ptr %t456, ptr %t443, i64 %t444)
  %t457 = getelementptr i8, ptr %t456, i64 %t444
  call void @olang_textcopy(ptr %t457, ptr %t446, i64 %t447)
  %t458 = getelementptr i8, ptr %t457, i64 %t447
  call void @olang_textcopy(ptr %t458, ptr %t449, i64 %t450)
  %t459 = getelementptr i8, ptr %t458, i64 %t450
  call void @olang_textcopy(ptr %t459, ptr %t453, i64 %t454)
  %t460 = insertvalue { i64, ptr } undef, i64 %t455, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t456, 1
  %t463 = load i64, ptr %l129
  %t464 = inttoptr i64 %t463 to ptr
  %t465 = load ptr, ptr %l131, !tbaa !29
  %t467 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s7, ptr %t464, ptr %v4, ptr %t465, { i64, ptr } %t461)
  store { i64, ptr } %t467, ptr %l141
  br label %bb69
bb69:
  %t468 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e9
  br i1 %t468, label %bb70, label %bb71
bb70:
  %t470 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t470, 0
  %t473 = icmp eq i64 %t471, 0
  br i1 %t473, label %bb72, label %bb73
bb71:
  %t475 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t475, ptr %l145, !tbaa !27
  %t476 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t476, ptr %l9, !tbaa !27
  %t477 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e9
  br i1 %t477, label %bb74, label %bb75
bb72:
  store { i64, ptr } zeroinitializer, ptr %l141, !tbaa !27
  br label %bb73
bb73:
  %t479 = load i64, ptr %l129
  %t480 = inttoptr i64 %t479 to ptr
  %t481 = load { i64, ptr }, ptr %l141
  %t482 = extractvalue { i64, ptr } %t481, 1
  %t483 = call ptr @__olang_region_or(ptr %t482, ptr null)
  %t484 = icmp ne ptr %t483, null
  %t485 = select i1 %t484, ptr %t483, ptr null
  call void @__olang_region_settle_in(ptr %t480, ptr %t485)
  br label %bb71
bb74:
  %t486 = load { i64, ptr }, ptr %l145
  %t487 = extractvalue { i64, ptr } %t486, 1
  call void @__olang_region_release(ptr %t487)
  store { i64, ptr } zeroinitializer, ptr %l145
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb76:
  %t488 = load ptr, ptr %l0, !tbaa !29
  store ptr %t488, ptr %l147, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t491 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t492 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d350, i32 0, i32 1) }, 1
  %t493 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d350, i32 0, i32 1) }, 0
  %t495 = extractvalue { i64, ptr } %t490, 1
  %t496 = extractvalue { i64, ptr } %t490, 0
  %t497 = add i64 %t493, %t496
  %t498 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d351, i32 0, i32 1) }, 1
  %t499 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d351, i32 0, i32 1) }, 0
  %t500 = add i64 %t497, %t499
  %t502 = extractvalue { i64, ptr } %t491, 1
  %t503 = extractvalue { i64, ptr } %t491, 0
  %t504 = add i64 %t500, %t503
  %t505 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t492, i64 %t493)
  %t506 = getelementptr i8, ptr %t505, i64 %t493
  call void @olang_textcopy(ptr %t506, ptr %t495, i64 %t496)
  %t507 = getelementptr i8, ptr %t506, i64 %t496
  call void @olang_textcopy(ptr %t507, ptr %t498, i64 %t499)
  %t508 = getelementptr i8, ptr %t507, i64 %t499
  call void @olang_textcopy(ptr %t508, ptr %t502, i64 %t503)
  %t509 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t505, 1
  %t514 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t489, { i64, ptr } %t510)
  store { i64, ptr } %t514, ptr %l153
  br label %bb77
bb77:
  %t515 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d352, i32 0, i32 1) }, 1
  %t516 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d352, i32 0, i32 1) }, 0
  %t517 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t518 = extractvalue { i64, ptr } %t517, 1
  %t519 = extractvalue { i64, ptr } %t517, 0
  %t520 = add i64 %t516, %t519
  %t521 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d353, i32 0, i32 1) }, 1
  %t522 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d353, i32 0, i32 1) }, 0
  %t523 = add i64 %t520, %t522
  %t524 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t523)
  call void @olang_textcopy(ptr %t524, ptr %t515, i64 %t516)
  %t525 = getelementptr i8, ptr %t524, i64 %t516
  call void @olang_textcopy(ptr %t525, ptr %t518, i64 %t519)
  %t526 = getelementptr i8, ptr %t525, i64 %t519
  call void @olang_textcopy(ptr %t526, ptr %t521, i64 %t522)
  %t527 = insertvalue { i64, ptr } undef, i64 %t523, 0
  %t528 = insertvalue { i64, ptr } %t527, ptr %t524, 1
  %t530 = load ptr, ptr %l147, !tbaa !29
  %t532 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t530, { i64, ptr } %t528)
  store { i64, ptr } %t532, ptr %l156
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s0)
  %t533 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t533, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2efreshDrops(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, [2 x i64] }
  %l18 = alloca ptr
  %l20 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca i64
  %l55 = alloca i32
  %l57 = alloca ptr
  %l61 = alloca %"compiler/mir:Local"
  %l63 = alloca ptr
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca ptr
  %l71 = alloca i1
  %l73 = alloca { i64, [2 x i64] }
  %l74 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i64
  %l79 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca i32
  %l85 = alloca { i64, [2 x i64] }
  %l86 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l92 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l101 = alloca ptr
  %l104 = alloca i1
  %l108 = alloca ptr
  %l113 = alloca ptr
  %l116 = alloca ptr
  %l118 = alloca ptr
  %l121 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l1, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/mir:Fn", ptr %t14, i32 0, i32 5
  store ptr %t16, ptr %l18, !tbaa !29
  %t17 = load ptr, ptr %l18, !tbaa !29
  %t18 = call ptr @__olang_scope_or(ptr %v1, ptr %t17)
  %t19 = call ptr @__olang_scope_hold(ptr %t18)
  %t20 = ptrtoint ptr %t19 to i64
  %t22 = inttoptr i64 %t20 to ptr
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t22, ptr %t23)
  store i64 %t24, ptr %l20
  br label %bb1
bb1:
  %t25 = load i64, ptr %l20, !tbaa !24
  store i64 %t25, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp sgt i64 %t26, %t27
  br i1 %t30, label %bb2, label %bb3
bb2:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb7
bb4:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = sub i64 %t36, %t37
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = add i64 %t40, %t41
  %t46 = sub i64 %t44, 1
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = sdiv i64 %t46, %t47
  store i64 %t50, ptr %l27, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb6
bb6:
  %t52 = load i64, ptr %l27, !tbaa !24
  store i64 %t52, ptr %l24, !tbaa !24
  br label %bb7
bb7:
  %t53 = load i64, ptr %l24, !tbaa !24
  store i64 %t53, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb43
bb10:
  br label %bb11
bb11:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t63 = load i64, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l5, !tbaa !24
  %t67 = mul i64 %t63, %t64
  %t70 = add i64 %t62, %t67
  store i64 %t70, ptr %l8, !tbaa !24
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t74 = getelementptr %"compiler/mir:Fn", ptr %t72, i32 0, i32 5
  store ptr %t74, ptr %l46, !tbaa !29
  %t75 = load ptr, ptr %l2, !tbaa !29
  %t77 = getelementptr %"compiler/mir:Fn", ptr %t75, i32 0, i32 5
  store ptr %t77, ptr %l48, !tbaa !29
  %t78 = load ptr, ptr %l48, !tbaa !29
  %t79 = call ptr @__olang_scope_or(ptr %v1, ptr %t78)
  %t80 = call ptr @__olang_scope_hold(ptr %t79)
  %t81 = ptrtoint ptr %t80 to i64
  %t83 = inttoptr i64 %t81 to ptr
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %t83, ptr %t84)
  store i64 %t85, ptr %l50
  br label %bb12
bb12:
  %t86 = load i64, ptr %l50, !tbaa !24
  %t87 = sub i64 %t86, 1
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load ptr, ptr %l46, !tbaa !29
  %t93 = call ptr @__olang_scope_or(ptr %v1, ptr %t92)
  %t94 = call ptr @__olang_scope_hold(ptr %t93)
  %t95 = ptrtoint ptr %t94 to i64
  %t97 = inttoptr i64 %t95 to ptr
  %t98 = load ptr, ptr %l46, !tbaa !29
  %t100 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %t97, ptr %t98, i64 %t91)
  store i32 %t100, ptr %l55
  br label %bb13
bb13:
  %t101 = load i32, ptr %l55, !tbaa !23
  store i32 %t101, ptr %l9, !tbaa !23
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/mir:Fn", ptr %t102, i32 0, i32 7
  store ptr %t104, ptr %l57, !tbaa !29
  %t105 = load i32, ptr %l9, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t108 = load ptr, ptr %l57, !tbaa !29
  %t109 = call ptr @__olang_scope_or(ptr %v1, ptr %t108)
  %t110 = call ptr @__olang_scope_hold(ptr %t109)
  %t111 = ptrtoint ptr %t110 to i64
  %t113 = inttoptr i64 %t111 to ptr
  %t114 = load ptr, ptr %l57, !tbaa !29
  %t116 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %t113, ptr %t114, i64 %t107)
  store %"compiler/mir:Local" %t116, ptr %l61
  br label %bb14
bb14:
  %t117 = getelementptr %"compiler/mir:Local", ptr %l61, i32 0, i32 2
  %t118 = load i32, ptr %t117, !tbaa !23
  store i32 %t118, ptr %l10, !tbaa !23
  %t120 = load ptr, ptr %l1, !tbaa !29
  store ptr %t120, ptr %l63, !tbaa !29
  %t121 = load i32, ptr %l10, !tbaa !23
  %t122 = load ptr, ptr %l63, !tbaa !29
  %t123 = call ptr @__olang_scope_or(ptr %v2, ptr %t122)
  %t124 = call ptr @__olang_scope_hold(ptr %t123)
  %t125 = ptrtoint ptr %t124 to i64
  %t127 = inttoptr i64 %t125 to ptr
  %t128 = load ptr, ptr %l63, !tbaa !29
  %t130 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %t127, ptr %t128, i32 %t121)
  store i1 %t130, ptr %l66
  br label %bb15
bb15:
  %t131 = load i1, ptr %l66, !tbaa !21
  br i1 %t131, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb19
bb17:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l68, !tbaa !29
  %t133 = load i32, ptr %l10, !tbaa !23
  %t134 = load ptr, ptr %l68, !tbaa !29
  %t135 = call ptr @__olang_scope_or(ptr %v2, ptr %t134)
  %t136 = call ptr @__olang_scope_hold(ptr %t135)
  %t137 = ptrtoint ptr %t136 to i64
  %t139 = inttoptr i64 %t137 to ptr
  %t140 = load ptr, ptr %l68, !tbaa !29
  %t142 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %t139, ptr %t140, i32 %t133)
  store i1 %t142, ptr %l71
  br label %bb18
bb18:
  %t143 = load i1, ptr %l71, !tbaa !21
  %t144 = xor i1 %t143, true
  store i1 %t144, ptr %l67, !tbaa !21
  br label %bb19
bb19:
  %t146 = load i1, ptr %l67, !tbaa !21
  br i1 %t146, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb21:
  br label %bb22
bb22:
  %t147 = load ptr, ptr %l1, !tbaa !29
  store ptr %t147, ptr %l74, !tbaa !29
  %t148 = load i32, ptr %l10, !tbaa !23
  store i32 %t148, ptr %l75, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/emit:fnEm", ptr %t149, i32 0, i32 0
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/emit:Emitter", ptr %t152, i32 0, i32 46
  store ptr %t154, ptr %l79, !tbaa !29
  %t155 = load i32, ptr %l10, !tbaa !23
  %t156 = load ptr, ptr %l79, !tbaa !29
  %t157 = call ptr @__olang_scope_or(ptr %v2, ptr %t156)
  %t158 = call ptr @__olang_scope_hold(ptr %t157)
  %t159 = ptrtoint ptr %t158 to i64
  %t161 = inttoptr i64 %t159 to ptr
  %t162 = load ptr, ptr %l79, !tbaa !29
  %t164 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %t161, ptr %t162, i32 %t155)
  %t165 = extractvalue { i32, i64 } %t164, 1
  %t166 = extractvalue { i32, i64 } %t164, 0
  store i32 %t166, ptr %l83
  %t167 = icmp ne i32 %t166, 0
  br i1 %t167, label %bb24, label %ok.168, !prof !99
ok.168:
  store i64 %t165, ptr %l82
  br label %bb23
bb23:
  %t169 = load i64, ptr %l82, !tbaa !24
  store i64 %t169, ptr %l76, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  store i64 -1, ptr %l76, !tbaa !24
  br label %bb26
bb26:
  %t170 = load ptr, ptr %l74, !tbaa !29
  %t171 = call ptr @__olang_scope_or(ptr %v2, ptr %t170)
  %t172 = call ptr @__olang_scope_hold(ptr %t171)
  %t173 = ptrtoint ptr %t172 to i64
  %t175 = inttoptr i64 %t173 to ptr
  %t176 = load ptr, ptr %l74, !tbaa !29
  %t177 = load i32, ptr %l75, !tbaa !23
  %t178 = load i64, ptr %l76, !tbaa !24
  %t179 = call { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %t175, ptr %t176, i32 %t177, i64 %t178)
  %t180 = extractvalue { i32, { i64, [2 x i64] } } %t179, 1
  %t181 = extractvalue { i32, { i64, [2 x i64] } } %t179, 0
  store i32 %t181, ptr %l86
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb28, label %ok.183, !prof !99
ok.183:
  store { i64, [2 x i64] } %t180, ptr %l85
  br label %bb27
bb27:
  %t184 = load { i64, [2 x i64] }, ptr %l85
  store { i64, [2 x i64] } %t184, ptr %l73
  br label %bb32
bb28:
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l87, !tbaa !29
  %t186 = load ptr, ptr %l1, !tbaa !29
  store ptr %t186, ptr %l88, !tbaa !29
  %t187 = load i32, ptr %l10, !tbaa !23
  %t188 = load ptr, ptr %l88, !tbaa !29
  %t189 = call ptr @__olang_scope_or(ptr %v2, ptr %t188)
  %t190 = call ptr @__olang_scope_hold(ptr %t189)
  %t191 = ptrtoint ptr %t190 to i64
  %t193 = inttoptr i64 %t191 to ptr
  %t195 = inttoptr i64 0 to ptr
  %t196 = load ptr, ptr %l88, !tbaa !29
  %t198 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %t193, ptr %s4, ptr %t195, ptr %t196, i32 %t187)
  store { i64, ptr } %t198, ptr %l92
  br label %bb30
bb30:
  %t199 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d354, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d354, i32 0, i32 1) }, 0
  %t201 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t201, 1
  %t203 = extractvalue { i64, ptr } %t201, 0
  %t204 = add i64 %t200, %t203
  %t205 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t204)
  call void @olang_textcopy(ptr %t205, ptr %t199, i64 %t200)
  %t206 = getelementptr i8, ptr %t205, i64 %t200
  call void @olang_textcopy(ptr %t206, ptr %t202, i64 %t203)
  %t207 = insertvalue { i64, ptr } undef, i64 %t204, 0
  %t208 = insertvalue { i64, ptr } %t207, ptr %t205, 1
  %t210 = load ptr, ptr %l87, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s4, ptr %v2, ptr %t210, { i64, ptr } %t208)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb32:
  %t212 = load { i64, [2 x i64] }, ptr %l73
  store { i64, [2 x i64] } %t212, ptr %l11
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/emit:fnEm", ptr %t213, i32 0, i32 0
  %t216 = load ptr, ptr %t215, !tbaa !29
  store ptr %t216, ptr %l96, !tbaa !29
  %t217 = load { i64, [2 x i64] }, ptr %l11
  %t218 = load ptr, ptr %l96, !tbaa !29
  %t219 = call ptr @__olang_scope_or(ptr %v2, ptr %t218)
  %t220 = call ptr @__olang_scope_hold(ptr %t219)
  %t221 = ptrtoint ptr %t220 to i64
  %t223 = inttoptr i64 %t221 to ptr
  %t224 = load ptr, ptr %l96, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %t223, ptr %t224, { i64, [2 x i64] } %t217)
  br label %bb33
bb33:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/emit:fnEm", ptr %t226, i32 0, i32 0
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = getelementptr %"compiler/emit:Emitter", ptr %t229, i32 0, i32 44
  store ptr %t231, ptr %l101, !tbaa !29
  %t232 = load { i64, [2 x i64] }, ptr %l11
  %t233 = load ptr, ptr %l101, !tbaa !29
  %t234 = call ptr @__olang_scope_or(ptr %v2, ptr %t233)
  %t235 = call ptr @__olang_scope_hold(ptr %t234)
  %t236 = ptrtoint ptr %t235 to i64
  %t238 = inttoptr i64 %t236 to ptr
  %t239 = load ptr, ptr %l101, !tbaa !29
  %t241 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %t238, ptr %t239, { i64, [2 x i64] } %t232)
  store i1 %t241, ptr %l104
  br label %bb34
bb34:
  %t242 = load i1, ptr %l104, !tbaa !21
  %t243 = xor i1 %t242, true
  br i1 %t243, label %bb35, label %bb36
bb35:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/emit:fnEm", ptr %t245, i32 0, i32 0
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/emit:Emitter", ptr %t248, i32 0, i32 44
  store ptr %t250, ptr %l108, !tbaa !29
  %t251 = load { i64, [2 x i64] }, ptr %l11
  %t252 = load ptr, ptr %l108, !tbaa !29
  %t253 = call ptr @__olang_scope_or(ptr %v2, ptr %t252)
  %t254 = call ptr @__olang_scope_hold(ptr %t253)
  %t255 = ptrtoint ptr %t254 to i64
  %t257 = inttoptr i64 %t255 to ptr
  %t258 = load ptr, ptr %l108, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %t257, ptr %t258, { i64, [2 x i64] } %t251, i1 true)
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/emit:fnEm", ptr %t260, i32 0, i32 0
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/emit:Emitter", ptr %t263, i32 0, i32 43
  store ptr %t265, ptr %l113, !tbaa !29
  %t266 = load { i64, [2 x i64] }, ptr %l11
  %t267 = load ptr, ptr %l113, !tbaa !29
  %t268 = call ptr @__olang_scope_or(ptr %v2, ptr %t267)
  %t269 = call ptr @__olang_scope_hold(ptr %t268)
  %t270 = ptrtoint ptr %t269 to i64
  %t272 = inttoptr i64 %t270 to ptr
  %t273 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %t272, ptr %t273, { i64, [2 x i64] } %t266)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l116, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/emit:fnEm", ptr %t276, i32 0, i32 0
  %t279 = load ptr, ptr %t278, !tbaa !29
  store ptr %t279, ptr %l118, !tbaa !29
  %t280 = load { i64, [2 x i64] }, ptr %l11
  %t281 = load ptr, ptr %l118, !tbaa !29
  %t282 = call ptr @__olang_scope_or(ptr %v2, ptr %t281)
  %t283 = call ptr @__olang_scope_hold(ptr %t282)
  %t284 = ptrtoint ptr %t283 to i64
  %t286 = inttoptr i64 %t284 to ptr
  %t287 = load ptr, ptr %l118, !tbaa !29
  %t289 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %t286, ptr %s2, ptr %t287, { i64, [2 x i64] } %t280)
  store { i64, ptr } %t289, ptr %l121
  br label %bb40
bb40:
  %t290 = load i32, ptr %l9, !tbaa !23
  %t291 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d355, i32 0, i32 1) }, 1
  %t292 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d355, i32 0, i32 1) }, 0
  %t293 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 1
  %t295 = extractvalue { i64, ptr } %t293, 0
  %t296 = add i64 %t292, %t295
  %t297 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d356, i32 0, i32 1) }, 1
  %t298 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d356, i32 0, i32 1) }, 0
  %t299 = add i64 %t296, %t298
  %t301 = sext i32 %t290 to i64
  %t302 = call i64 @__olang_fmt_i64(ptr null, i64 %t301)
  %t303 = add i64 %t299, %t302
  %t304 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d357, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d357, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t291, i64 %t292)
  %t308 = getelementptr i8, ptr %t307, i64 %t292
  call void @olang_textcopy(ptr %t308, ptr %t294, i64 %t295)
  %t309 = getelementptr i8, ptr %t308, i64 %t295
  call void @olang_textcopy(ptr %t309, ptr %t297, i64 %t298)
  %t310 = getelementptr i8, ptr %t309, i64 %t298
  %t311 = call i64 @__olang_fmt_i64(ptr %t310, i64 %t301)
  %t312 = getelementptr i8, ptr %t310, i64 %t302
  call void @olang_textcopy(ptr %t312, ptr %t304, i64 %t305)
  %t313 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t307, 1
  %t316 = load ptr, ptr %l116, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %v2, ptr %t316, { i64, ptr } %t314)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s2)
  br label %bb42
bb42:
  %t318 = load i64, ptr %l7, !tbaa !24
  %t321 = add i64 %t318, 1
  store i64 %t321, ptr %l7, !tbaa !24
  br label %bb8
bb43:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l19 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca ptr
  %l27 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i32
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l75 = alloca i32
  %l78 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l85 = alloca i32
  %l86 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca i32
  %l108 = alloca { i64, ptr }
  %l114 = alloca i64
  %l117 = alloca i64
  %l136 = alloca ptr
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l159 = alloca ptr
  %l162 = alloca i1
  %l163 = alloca i1
  %l165 = alloca ptr
  %l168 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  %t11 = load ptr, ptr %l19, !tbaa !29
  %t12 = call ptr @__olang_scope_or(ptr %v3, ptr %t11)
  %t13 = call ptr @__olang_scope_hold(ptr %t12)
  %t14 = ptrtoint ptr %t13 to i64
  %t16 = inttoptr i64 %t14 to ptr
  %t17 = load ptr, ptr %l19, !tbaa !29
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t16, ptr %t17, i32 %a2)
  store i32 %t19, ptr %l22
  br label %bb1
bb1:
  %t20 = load i32, ptr %l22, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/emit:fnEm", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  store ptr %t24, ptr %l24, !tbaa !29
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = load ptr, ptr %l24, !tbaa !29
  %t27 = call ptr @__olang_scope_or(ptr %v3, ptr %t26)
  %t28 = call ptr @__olang_scope_hold(ptr %t27)
  %t29 = ptrtoint ptr %t28 to i64
  %t31 = inttoptr i64 %t29 to ptr
  %t32 = load ptr, ptr %l24, !tbaa !29
  %t34 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eholdsGen(ptr %t31, ptr %t32, i32 %t25)
  store i1 %t34, ptr %l27
  br label %bb2
bb2:
  %t35 = load i1, ptr %l27, !tbaa !21
  %t36 = xor i1 %t35, true
  br i1 %t36, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  %t39 = load i32, ptr %l6, !tbaa !23
  %t40 = load ptr, ptr %l29, !tbaa !29
  %t41 = call ptr @__olang_scope_or(ptr %v3, ptr %t40)
  %t42 = call ptr @__olang_scope_hold(ptr %t41)
  %t43 = ptrtoint ptr %t42 to i64
  %t45 = inttoptr i64 %t43 to ptr
  %t46 = load ptr, ptr %l29, !tbaa !29
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t45, ptr %t46, i32 %t39)
  store i32 %t48, ptr %l32
  br label %bb6
bb6:
  %t49 = load i32, ptr %l32, !range !{i32 0, i32 33}
  store i32 %t49, ptr %l7
  %t50 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t52 = trunc i64 20 to i32
  %t53 = icmp eq i32 %t50, %t52
  br i1 %t53, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/emit:fnEm", ptr %t55, i32 0, i32 31
  %t58 = load i1, ptr %t57, !tbaa !21
  br i1 %t58, label %bb9, label %bb10
bb8:
  br label %bb21
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/emit:fnEm", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  store ptr %t63, ptr %l38, !tbaa !29
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = call ptr @__olang_scope_or(ptr %v3, ptr %t64)
  %t66 = call ptr @__olang_scope_hold(ptr %t65)
  %t67 = ptrtoint ptr %t66 to i64
  %t69 = inttoptr i64 %t67 to ptr
  %t70 = load ptr, ptr %l38, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t69, ptr %s3, ptr %t70, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d358, i32 0, i32 1) })
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/emit:fnEm", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l41, !tbaa !29
  %t75 = load ptr, ptr %l5, !tbaa !29
  store ptr %t75, ptr %l42, !tbaa !29
  %t76 = load ptr, ptr %l5, !tbaa !29
  store ptr %t76, ptr %l43, !tbaa !29
  %t77 = load i32, ptr %l6, !tbaa !23
  %t78 = load ptr, ptr %l43, !tbaa !29
  %t79 = call ptr @__olang_scope_or(ptr %v3, ptr %t78)
  %t80 = call ptr @__olang_scope_hold(ptr %t79)
  %t81 = ptrtoint ptr %t80 to i64
  %t83 = inttoptr i64 %t81 to ptr
  %t84 = load ptr, ptr %l43, !tbaa !29
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t83, ptr %t84, i32 %t77)
  store i32 %t86, ptr %l46
  br label %bb12
bb12:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = call ptr @__olang_scope_or(ptr %v3, ptr %t87)
  %t89 = call ptr @__olang_scope_hold(ptr %t88)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t90 to ptr
  %t93 = load ptr, ptr %l42, !tbaa !29
  %t94 = load i32, ptr %l46, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t92, ptr %t93, i32 %t94)
  store i32 %t95, ptr %l48
  br label %bb13
bb13:
  %t96 = load ptr, ptr %l41, !tbaa !29
  %t97 = call ptr @__olang_scope_or(ptr %v3, ptr %t96)
  %t98 = call ptr @__olang_scope_hold(ptr %t97)
  %t99 = ptrtoint ptr %t98 to i64
  %t101 = inttoptr i64 %t99 to ptr
  %t102 = load ptr, ptr %l41, !tbaa !29
  %t103 = load i32, ptr %l48, !tbaa !23
  %t104 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %t101, ptr %s3, ptr %t102, i32 %t103)
  store { i64, ptr } %t104, ptr %l50
  br label %bb14
bb14:
  %t105 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t105, ptr %l8, !tbaa !27
  %t106 = load ptr, ptr %l0, !tbaa !29
  store ptr %t106, ptr %l51, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t111 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s3, ptr %v1, ptr %s3, ptr %s3, ptr %v3, ptr %t107, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d359, i32 0, i32 1) }, { i64, ptr } %t108, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store { i64, ptr } %t111, ptr %l54
  br label %bb15
bb15:
  %t112 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t113 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d360, i32 0, i32 1) }, 1
  %t114 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d360, i32 0, i32 1) }, 0
  %t115 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = add i64 %t114, %t117
  %t119 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d361, i32 0, i32 1) }, 1
  %t120 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d361, i32 0, i32 1) }, 0
  %t121 = add i64 %t118, %t120
  %t123 = extractvalue { i64, ptr } %t112, 1
  %t124 = extractvalue { i64, ptr } %t112, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d362, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d362, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t113, i64 %t114)
  %t130 = getelementptr i8, ptr %t129, i64 %t114
  call void @olang_textcopy(ptr %t130, ptr %t116, i64 %t117)
  %t131 = getelementptr i8, ptr %t130, i64 %t117
  call void @olang_textcopy(ptr %t131, ptr %t119, i64 %t120)
  %t132 = getelementptr i8, ptr %t131, i64 %t120
  call void @olang_textcopy(ptr %t132, ptr %t123, i64 %t124)
  %t133 = getelementptr i8, ptr %t132, i64 %t124
  call void @olang_textcopy(ptr %t133, ptr %t126, i64 %t127)
  %t134 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t129, 1
  %t137 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %v3, ptr %t137, { i64, ptr } %t135)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb17:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/emit:fnEm", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  store ptr %t142, ptr %l59, !tbaa !29
  %t143 = load ptr, ptr %l59, !tbaa !29
  %t144 = call ptr @__olang_scope_or(ptr %v3, ptr %t143)
  %t145 = call ptr @__olang_scope_hold(ptr %t144)
  %t146 = ptrtoint ptr %t145 to i64
  %t148 = inttoptr i64 %t146 to ptr
  %t149 = load ptr, ptr %l59, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t148, ptr %s2, ptr %t149, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d363, i32 0, i32 1) })
  br label %bb18
bb18:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l61, !tbaa !29
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t155 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s2, ptr %v1, ptr %s2, ptr %s2, ptr %v3, ptr %t151, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d364, i32 0, i32 1) }, { i64, ptr } %t152, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store { i64, ptr } %t155, ptr %l64
  br label %bb19
bb19:
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d365, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d365, i32 0, i32 1) }, 0
  %t159 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d366, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d366, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t167 = extractvalue { i64, ptr } %t156, 1
  %t168 = extractvalue { i64, ptr } %t156, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d367, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d367, i32 0, i32 1) }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t157, i64 %t158)
  %t174 = getelementptr i8, ptr %t173, i64 %t158
  call void @olang_textcopy(ptr %t174, ptr %t160, i64 %t161)
  %t175 = getelementptr i8, ptr %t174, i64 %t161
  call void @olang_textcopy(ptr %t175, ptr %t163, i64 %t164)
  %t176 = getelementptr i8, ptr %t175, i64 %t164
  call void @olang_textcopy(ptr %t176, ptr %t167, i64 %t168)
  %t177 = getelementptr i8, ptr %t176, i64 %t168
  call void @olang_textcopy(ptr %t177, ptr %t170, i64 %t171)
  %t178 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t173, 1
  %t181 = load ptr, ptr %l61, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %v3, ptr %t181, { i64, ptr } %t179)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb21:
  %t183 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t185 = trunc i64 19 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb22, label %bb23
bb22:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l6, !tbaa !23
  %t192 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %v3, ptr %t188, i32 %t189)
  store i1 %t192, ptr %l72
  br label %bb24
bb23:
  br label %bb36
bb24:
  %t193 = load i1, ptr %l72, !tbaa !21
  br i1 %t193, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l73, !tbaa !29
  %t195 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t195, ptr %l74, !tbaa !27
  %t196 = load i32, ptr %l6, !tbaa !23
  store i32 %t196, ptr %l75, !tbaa !23
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l6, !tbaa !23
  %t201 = call i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %v3, ptr %t197, i32 %t198)
  store i64 %t201, ptr %l78
  br label %bb27
bb26:
  br i1 %a4, label %bb29, label %bb30
bb27:
  %t204 = load i64, ptr %l78, !tbaa !24
  %t205 = call i64 @__olang_fmt_i64(ptr null, i64 %t204)
  %t206 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t205)
  %t207 = call i64 @__olang_fmt_i64(ptr %t206, i64 %t204)
  %t208 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  %t211 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t212 = load ptr, ptr %l73, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t214 = load i32, ptr %l75, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersEach(ptr %v0, ptr %v1, ptr %s7, ptr %v2, ptr %v3, ptr %t212, { i64, ptr } %t213, i32 %t214, { i64, ptr } %t209, { i64, ptr } %t211)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb29:
  store %olang.scope zeroinitializer, ptr %s10
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l83, !tbaa !29
  %t218 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t218, ptr %l84, !tbaa !27
  %t219 = load i32, ptr %l6, !tbaa !23
  store i32 %t219, ptr %l85, !tbaa !23
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l86, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t222 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t223 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d368, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d368, i32 0, i32 1) }, 0
  %t226 = extractvalue { i64, ptr } %t222, 1
  %t227 = extractvalue { i64, ptr } %t222, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d369, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d369, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t223, i64 %t224)
  %t233 = getelementptr i8, ptr %t232, i64 %t224
  call void @olang_textcopy(ptr %t233, ptr %t226, i64 %t227)
  %t234 = getelementptr i8, ptr %t233, i64 %t227
  call void @olang_textcopy(ptr %t234, ptr %t229, i64 %t230)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t232, 1
  %t240 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s10, ptr %s10, ptr %v3, ptr %t221, { i64, ptr } %t236)
  store { i64, ptr } %t240, ptr %l91
  br label %bb31
bb30:
  br label %bb34
bb31:
  %t241 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t242 = load ptr, ptr %l86, !tbaa !29
  %t244 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s10, ptr %s10, ptr %s10, ptr %s10, ptr %v3, ptr %t242, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d370, i32 0, i32 1) }, { i64, ptr } %t241, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store { i64, ptr } %t244, ptr %l93
  br label %bb32
bb32:
  %t245 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t247 = load ptr, ptr %l83, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t249 = load i32, ptr %l85, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersEach(ptr %v0, ptr %v1, ptr %s10, ptr %v2, ptr %v3, ptr %t247, { i64, ptr } %t248, i32 %t249, { i64, ptr } %t245, { i64, ptr } %t246)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %ret
bb36:
  %t252 = load ptr, ptr %l5, !tbaa !29
  store ptr %t252, ptr %l96, !tbaa !29
  %t253 = load i32, ptr %l6, !tbaa !23
  %t254 = load ptr, ptr %l96, !tbaa !29
  %t255 = call ptr @__olang_scope_or(ptr %v3, ptr %t254)
  %t256 = call ptr @__olang_scope_hold(ptr %t255)
  %t257 = ptrtoint ptr %t256 to i64
  %t259 = inttoptr i64 %t257 to ptr
  %t260 = load ptr, ptr %l96, !tbaa !29
  %t262 = call i1 @compiler_2fmir_2eHasFields(ptr %t259, ptr %t260, i32 %t253)
  store i1 %t262, ptr %l99
  br label %bb37
bb37:
  %t263 = load i1, ptr %l99, !tbaa !21
  br i1 %t263, label %bb38, label %bb39
bb38:
  %t264 = load ptr, ptr %l5, !tbaa !29
  store ptr %t264, ptr %l100, !tbaa !29
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t266 = load i32, ptr %l6, !tbaa !23
  %t269 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %v3, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l103
  br label %bb40
bb39:
  br label %bb61
bb40:
  %t270 = load ptr, ptr %l100, !tbaa !29
  %t271 = call ptr @__olang_scope_or(ptr %v3, ptr %t270)
  %t272 = call ptr @__olang_scope_hold(ptr %t271)
  %t273 = ptrtoint ptr %t272 to i64
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/emit:fnEm", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = call ptr @__olang_scope_or(ptr %v3, ptr %t277)
  %t280 = call ptr @__olang_scope_hold(ptr %t279)
  %t281 = ptrtoint ptr %t280 to i64
  %t283 = inttoptr i64 %t273 to ptr
  %t285 = inttoptr i64 %t281 to ptr
  %t286 = load ptr, ptr %l100, !tbaa !29
  %t287 = load i32, ptr %l103, !tbaa !23
  %t288 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t283, ptr %t285, ptr %t286, i32 %t287)
  store { i64, ptr } %t288, ptr %l108
  br label %bb41
bb41:
  %t289 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t289, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t290 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t290, 0
  store i64 %t292, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t294 = load i64, ptr %l11, !tbaa !24
  %t295 = load i64, ptr %l10, !tbaa !24
  %t298 = icmp sgt i64 %t294, %t295
  br i1 %t298, label %bb42, label %bb43
bb42:
  %t300 = load i64, ptr %l12, !tbaa !24
  %t302 = icmp sgt i64 %t300, 0
  br i1 %t302, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb47
bb44:
  %t304 = load i64, ptr %l11, !tbaa !24
  %t305 = load i64, ptr %l10, !tbaa !24
  %t308 = sub i64 %t304, %t305
  %t309 = load i64, ptr %l12, !tbaa !24
  %t312 = add i64 %t308, %t309
  %t314 = sub i64 %t312, 1
  %t315 = load i64, ptr %l12, !tbaa !24
  %t318 = sdiv i64 %t314, %t315
  store i64 %t318, ptr %l117, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb46
bb46:
  %t320 = load i64, ptr %l117, !tbaa !24
  store i64 %t320, ptr %l114, !tbaa !24
  br label %bb47
bb47:
  %t321 = load i64, ptr %l114, !tbaa !24
  store i64 %t321, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s14
  %t322 = load i64, ptr %l14, !tbaa !24
  %t323 = load i64, ptr %l13, !tbaa !24
  %t326 = icmp slt i64 %t322, %t323
  %t328 = xor i1 %t326, true
  br i1 %t328, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s14)
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t330 = load i64, ptr %l10, !tbaa !24
  %t331 = load i64, ptr %l14, !tbaa !24
  %t332 = load i64, ptr %l12, !tbaa !24
  %t335 = mul i64 %t331, %t332
  %t338 = add i64 %t330, %t335
  store i64 %t338, ptr %l15, !tbaa !24
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/emit:fnEm", ptr %t340, i32 0, i32 0
  %t343 = load ptr, ptr %t342, !tbaa !29
  store ptr %t343, ptr %l136, !tbaa !29
  %t344 = load i32, ptr %l6, !tbaa !23
  %t345 = load i64, ptr %l15, !tbaa !24
  %t346 = load ptr, ptr %l136, !tbaa !29
  %t347 = call ptr @__olang_scope_or(ptr %v3, ptr %t346)
  %t348 = call ptr @__olang_scope_hold(ptr %t347)
  %t349 = ptrtoint ptr %t348 to i64
  %t351 = inttoptr i64 %t349 to ptr
  %t352 = load ptr, ptr %l136, !tbaa !29
  %t355 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eweakField(ptr %t351, ptr %t352, i32 %t344, i64 %t345)
  store i1 %t355, ptr %l140
  br label %bb52
bb52:
  %t356 = load i1, ptr %l140, !tbaa !21
  br i1 %t356, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s14)
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l141, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  store ptr %t358, ptr %l142, !tbaa !29
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i32, ptr %l6, !tbaa !23
  %t363 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s14, ptr %v3, ptr %t359, i32 %t360)
  store { i64, ptr } %t363, ptr %l145
  br label %bb56
bb56:
  %t364 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t365 = load i64, ptr %l15, !tbaa !24
  %t366 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d371, i32 0, i32 1) }, 1
  %t367 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d371, i32 0, i32 1) }, 0
  %t368 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t369 = extractvalue { i64, ptr } %t368, 1
  %t370 = extractvalue { i64, ptr } %t368, 0
  %t371 = add i64 %t367, %t370
  %t372 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d372, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d372, i32 0, i32 1) }, 0
  %t374 = add i64 %t371, %t373
  %t376 = extractvalue { i64, ptr } %t364, 1
  %t377 = extractvalue { i64, ptr } %t364, 0
  %t378 = add i64 %t374, %t377
  %t379 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d373, i32 0, i32 1) }, 1
  %t380 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d373, i32 0, i32 1) }, 0
  %t381 = add i64 %t378, %t380
  %t383 = call i64 @__olang_fmt_i64(ptr null, i64 %t365)
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t366, i64 %t367)
  %t386 = getelementptr i8, ptr %t385, i64 %t367
  call void @olang_textcopy(ptr %t386, ptr %t369, i64 %t370)
  %t387 = getelementptr i8, ptr %t386, i64 %t370
  call void @olang_textcopy(ptr %t387, ptr %t372, i64 %t373)
  %t388 = getelementptr i8, ptr %t387, i64 %t373
  call void @olang_textcopy(ptr %t388, ptr %t376, i64 %t377)
  %t389 = getelementptr i8, ptr %t388, i64 %t377
  call void @olang_textcopy(ptr %t389, ptr %t379, i64 %t380)
  %t390 = getelementptr i8, ptr %t389, i64 %t380
  %t391 = call i64 @__olang_fmt_i64(ptr %t390, i64 %t365)
  %t392 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t385, 1
  %t395 = load ptr, ptr %l142, !tbaa !29
  %t397 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s14, ptr %s14, ptr %v3, ptr %t395, { i64, ptr } %t393)
  store { i64, ptr } %t397, ptr %l150
  br label %bb57
bb57:
  %t398 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t399 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t399, ptr %l152, !tbaa !27
  %t400 = load i64, ptr %l15, !tbaa !24
  %t402 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr i32, ptr %t403, i64 %t400
  %t405 = load i32, ptr %t404, !tbaa !33
  %t406 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t407 = load ptr, ptr %l141, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %s14, ptr %v2, ptr %v3, ptr %t407, { i64, ptr } %t398, i32 %t405, { i64, ptr } %t406, i1 false)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s14)
  br label %bb59
bb59:
  %t411 = load i64, ptr %l14, !tbaa !24
  %t414 = add i64 %t411, 1
  store i64 %t414, ptr %l14, !tbaa !24
  br label %bb48
bb60:
  br label %ret
bb61:
  %t416 = load ptr, ptr %l5, !tbaa !29
  store ptr %t416, ptr %l159, !tbaa !29
  %t417 = load i32, ptr %l6, !tbaa !23
  %t418 = load ptr, ptr %l159, !tbaa !29
  %t419 = call ptr @__olang_scope_or(ptr %v3, ptr %t418)
  %t420 = call ptr @__olang_scope_hold(ptr %t419)
  %t421 = ptrtoint ptr %t420 to i64
  %t423 = inttoptr i64 %t421 to ptr
  %t424 = load ptr, ptr %l159, !tbaa !29
  %t426 = call i1 @compiler_2fmir_2eHasCases(ptr %t423, ptr %t424, i32 %t417)
  store i1 %t426, ptr %l162
  br label %bb62
bb62:
  %t427 = load i1, ptr %l162, !tbaa !21
  br i1 %t427, label %bb63, label %bb64
bb63:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/emit:fnEm", ptr %t428, i32 0, i32 0
  %t431 = load ptr, ptr %t430, !tbaa !29
  store ptr %t431, ptr %l165, !tbaa !29
  %t432 = load i32, ptr %l6, !tbaa !23
  %t433 = load ptr, ptr %l165, !tbaa !29
  %t434 = call ptr @__olang_scope_or(ptr %v3, ptr %t433)
  %t435 = call ptr @__olang_scope_hold(ptr %t434)
  %t436 = ptrtoint ptr %t435 to i64
  %t438 = inttoptr i64 %t436 to ptr
  %t439 = load ptr, ptr %l165, !tbaa !29
  %t441 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %t438, ptr %t439, i32 %t432)
  store i1 %t441, ptr %l168
  br label %bb65
bb64:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb66
bb65:
  %t442 = load i1, ptr %l168, !tbaa !21
  store i1 %t442, ptr %l163, !tbaa !21
  br label %bb66
bb66:
  %t443 = load i1, ptr %l163, !tbaa !21
  br i1 %t443, label %bb67, label %bb68
bb67:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t446 = load i32, ptr %l6, !tbaa !23
  %t447 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersCases(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t444, { i64, ptr } %t445, i32 %t446, { i64, ptr } %t447)
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersEach(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { { i64, ptr }, i32 }
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l65 = alloca { { i64, ptr }, i32 }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t1, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d374, i32 0, i32 1) })
  store { i64, ptr } %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d375, i32 0, i32 1) })
  store { i64, ptr } %t7, ptr %l18
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t9, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d376, i32 0, i32 1) })
  store { i64, ptr } %t11, ptr %l20
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t12, ptr %l7, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t13, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d377, i32 0, i32 1) })
  store { i64, ptr } %t15, ptr %l22
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t16, ptr %l8, !tbaa !27
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t17, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d378, i32 0, i32 1) })
  store { i64, ptr } %t19, ptr %l24
  br label %bb5
bb5:
  %t20 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t20, ptr %l9, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d379, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d379, i32 0, i32 1) }, 0
  %t26 = extractvalue { i64, ptr } %t22, 1
  %t27 = extractvalue { i64, ptr } %t22, 0
  %t28 = add i64 %t24, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t23, i64 %t24)
  %t30 = getelementptr i8, ptr %t29, i64 %t24
  call void @olang_textcopy(ptr %t30, ptr %t26, i64 %t27)
  %t31 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t21, { i64, ptr } %t32)
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t36, { i64, ptr } %t37)
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t42 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d380, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d380, i32 0, i32 1) }, 0
  %t45 = extractvalue { i64, ptr } %t41, 1
  %t46 = extractvalue { i64, ptr } %t41, 0
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  call void @olang_textcopy(ptr %t49, ptr %t45, i64 %t46)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t40, { i64, ptr } %t51)
  br label %bb8
bb8:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t55, { i64, ptr } %t56)
  br label %bb9
bb9:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s0, ptr %t59)
  store { i64, ptr } %t61, ptr %l38
  br label %bb10
bb10:
  %t62 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t62, ptr %l10, !tbaa !27
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %s0, ptr %t63)
  store { i64, ptr } %t65, ptr %l40
  br label %bb11
bb11:
  %t66 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t66, ptr %l11, !tbaa !27
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t68, 1
  %t74 = extractvalue { i64, ptr } %t68, 0
  %t75 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d381, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d381, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t79 = extractvalue { i64, ptr } %t69, 1
  %t80 = extractvalue { i64, ptr } %t69, 0
  %t81 = add i64 %t77, %t80
  %t82 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d382, i32 0, i32 1) }, 1
  %t83 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d382, i32 0, i32 1) }, 0
  %t84 = add i64 %t81, %t83
  %t86 = extractvalue { i64, ptr } %t70, 1
  %t87 = extractvalue { i64, ptr } %t70, 0
  %t88 = add i64 %t84, %t87
  %t89 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d383, i32 0, i32 1) }, 1
  %t90 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d383, i32 0, i32 1) }, 0
  %t91 = add i64 %t88, %t90
  %t93 = extractvalue { i64, ptr } %t71, 1
  %t94 = extractvalue { i64, ptr } %t71, 0
  %t95 = add i64 %t91, %t94
  %t96 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d384, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d384, i32 0, i32 1) }, 0
  %t98 = add i64 %t95, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t73, i64 %t74)
  %t100 = getelementptr i8, ptr %t99, i64 %t74
  call void @olang_textcopy(ptr %t100, ptr %t75, i64 %t76)
  %t101 = getelementptr i8, ptr %t100, i64 %t76
  call void @olang_textcopy(ptr %t101, ptr %t79, i64 %t80)
  %t102 = getelementptr i8, ptr %t101, i64 %t80
  call void @olang_textcopy(ptr %t102, ptr %t82, i64 %t83)
  %t103 = getelementptr i8, ptr %t102, i64 %t83
  call void @olang_textcopy(ptr %t103, ptr %t86, i64 %t87)
  %t104 = getelementptr i8, ptr %t103, i64 %t87
  call void @olang_textcopy(ptr %t104, ptr %t89, i64 %t90)
  %t105 = getelementptr i8, ptr %t104, i64 %t90
  call void @olang_textcopy(ptr %t105, ptr %t93, i64 %t94)
  %t106 = getelementptr i8, ptr %t105, i64 %t94
  call void @olang_textcopy(ptr %t106, ptr %t96, i64 %t97)
  %t107 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t99, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t67, { i64, ptr } %t108)
  br label %bb12
bb12:
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l48, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t116 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d385, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d385, i32 0, i32 1) }, 0
  %t119 = extractvalue { i64, ptr } %t114, 1
  %t120 = extractvalue { i64, ptr } %t114, 0
  %t121 = add i64 %t117, %t120
  %t122 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d386, i32 0, i32 1) }, 1
  %t123 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d386, i32 0, i32 1) }, 0
  %t124 = add i64 %t121, %t123
  %t126 = extractvalue { i64, ptr } %a3, 1
  %t127 = extractvalue { i64, ptr } %a3, 0
  %t128 = add i64 %t124, %t127
  %t129 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t128)
  call void @olang_textcopy(ptr %t129, ptr %t116, i64 %t117)
  %t130 = getelementptr i8, ptr %t129, i64 %t117
  call void @olang_textcopy(ptr %t130, ptr %t119, i64 %t120)
  %t131 = getelementptr i8, ptr %t130, i64 %t120
  call void @olang_textcopy(ptr %t131, ptr %t122, i64 %t123)
  %t132 = getelementptr i8, ptr %t131, i64 %t123
  call void @olang_textcopy(ptr %t132, ptr %t126, i64 %t127)
  %t133 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t129, 1
  %t138 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t113, { i64, ptr } %t134)
  store { i64, ptr } %t138, ptr %l54
  br label %bb13
bb13:
  %t139 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t141 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d387, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d387, i32 0, i32 1) }, 0
  %t143 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t151 = extractvalue { i64, ptr } %t139, 1
  %t152 = extractvalue { i64, ptr } %t139, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d388, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d388, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t158 = extractvalue { i64, ptr } %t140, 1
  %t159 = extractvalue { i64, ptr } %t140, 0
  %t160 = add i64 %t156, %t159
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t141, i64 %t142)
  %t162 = getelementptr i8, ptr %t161, i64 %t142
  call void @olang_textcopy(ptr %t162, ptr %t144, i64 %t145)
  %t163 = getelementptr i8, ptr %t162, i64 %t145
  call void @olang_textcopy(ptr %t163, ptr %t147, i64 %t148)
  %t164 = getelementptr i8, ptr %t163, i64 %t148
  call void @olang_textcopy(ptr %t164, ptr %t151, i64 %t152)
  %t165 = getelementptr i8, ptr %t164, i64 %t152
  call void @olang_textcopy(ptr %t165, ptr %t154, i64 %t155)
  %t166 = getelementptr i8, ptr %t165, i64 %t155
  call void @olang_textcopy(ptr %t166, ptr %t158, i64 %t159)
  %t167 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t161, 1
  %t170 = load ptr, ptr %l48, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t170, { i64, ptr } %t168)
  br label %bb14
bb14:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l7, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t172, { i64, ptr } %t173)
  br label %bb15
bb15:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t184 = call { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %v4, ptr %t176, { i64, ptr } %a1, i32 %a2, { i64, ptr } %t179, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d389, i32 0, i32 1) })
  store { { i64, ptr }, i32 } %t184, ptr %l65
  br label %bb16
bb16:
  %t185 = load { { i64, ptr }, i32 }, ptr %l65
  store { { i64, ptr }, i32 } %t185, ptr %l12
  %t186 = getelementptr { { i64, ptr }, i32 }, ptr %l12, i32 0, i32 0
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t189 = getelementptr { { i64, ptr }, i32 }, ptr %l12, i32 0, i32 1
  %t190 = load i32, ptr %t189, !tbaa !23
  %t192 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersAt(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t192, { i64, ptr } %t187, i32 %t190, { i64, ptr } %a4, i1 false)
  br label %bb17
bb17:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t202 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d390, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d390, i32 0, i32 1) }, 0
  %t205 = extractvalue { i64, ptr } %t201, 1
  %t206 = extractvalue { i64, ptr } %t201, 0
  %t207 = add i64 %t203, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t202, i64 %t203)
  %t209 = getelementptr i8, ptr %t208, i64 %t203
  call void @olang_textcopy(ptr %t209, ptr %t205, i64 %t206)
  %t210 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t208, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t200, { i64, ptr } %t211)
  br label %bb18
bb18:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t215, { i64, ptr } %t216)
  br label %bb19
bb19:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t220, 1
  %t224 = extractvalue { i64, ptr } %t220, 0
  %t225 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d391, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d391, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t229 = extractvalue { i64, ptr } %t221, 1
  %t230 = extractvalue { i64, ptr } %t221, 0
  %t231 = add i64 %t227, %t230
  %t232 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d392, i32 0, i32 1) }, 1
  %t233 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d392, i32 0, i32 1) }, 0
  %t234 = add i64 %t231, %t233
  %t235 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t234)
  call void @olang_textcopy(ptr %t235, ptr %t223, i64 %t224)
  %t236 = getelementptr i8, ptr %t235, i64 %t224
  call void @olang_textcopy(ptr %t236, ptr %t225, i64 %t226)
  %t237 = getelementptr i8, ptr %t236, i64 %t226
  call void @olang_textcopy(ptr %t237, ptr %t229, i64 %t230)
  %t238 = getelementptr i8, ptr %t237, i64 %t230
  call void @olang_textcopy(ptr %t238, ptr %t232, i64 %t233)
  %t239 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t235, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t219, { i64, ptr } %t240)
  br label %bb20
bb20:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t246 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d393, i32 0, i32 1) }, 1
  %t247 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d393, i32 0, i32 1) }, 0
  %t249 = extractvalue { i64, ptr } %t245, 1
  %t250 = extractvalue { i64, ptr } %t245, 0
  %t251 = add i64 %t247, %t250
  %t252 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t251)
  call void @olang_textcopy(ptr %t252, ptr %t246, i64 %t247)
  %t253 = getelementptr i8, ptr %t252, i64 %t247
  call void @olang_textcopy(ptr %t253, ptr %t249, i64 %t250)
  %t254 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v4, ptr %t244, { i64, ptr } %t255)
  br label %bb21
bb21:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t259, { i64, ptr } %t260)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i32
  %l47 = alloca i1
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l83 = alloca i1
  %l85 = alloca i64
  %l87 = alloca { i64, ptr }
  %l90 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca i64
  %l103 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca i64
  %l112 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca { i64, ptr }
  %l133 = alloca i64
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  br i1 %a3, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"compiler/emit:Emitter", ptr %t8, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/emit:fnEm", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/mir:Fn", ptr %t15, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t20 = load i32, ptr %t19, !tbaa !23
  %t22 = sext i32 %t20 to i64
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = call ptr @__olang_scope_or(ptr %v3, ptr %t23)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l16, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %t28, ptr %s0, ptr %t29, i64 %t18, i64 %t22)
  store { i64, ptr } %t32, ptr %l23
  br label %bb3
bb2:
  %t33 = load ptr, ptr %l4, !tbaa !29
  store ptr %t33, ptr %l24, !tbaa !29
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:fnEm", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/mir:Fn", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load %"compiler/source:Span", ptr %l1
  %t42 = load ptr, ptr %l24, !tbaa !29
  %t43 = call ptr @__olang_scope_or(ptr %v3, ptr %t42)
  %t44 = call ptr @__olang_scope_hold(ptr %t43)
  %t45 = ptrtoint ptr %t44 to i64
  %t47 = inttoptr i64 %t45 to ptr
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %t47, ptr %s0, ptr %t48, i64 %t40, %"compiler/source:Span" %t41)
  store { i64, ptr } %t51, ptr %l30
  br label %bb4
bb3:
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %l14, !tbaa !27
  br label %bb5
bb4:
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %l14, !tbaa !27
  br label %bb5
bb5:
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t59 = extractvalue { i64, ptr } %t54, 1
  %t60 = extractvalue { i64, ptr } %t54, 0
  %t61 = add i64 %t57, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t56, i64 %t57)
  %t63 = getelementptr i8, ptr %t62, i64 %t57
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  store { i64, ptr } %t65, ptr %l5, !tbaa !27
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/emit:Emitter", ptr %t67, i32 0, i32 98
  %t70 = load i1, ptr %t69, !tbaa !21
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb6, label %bb7
bb6:
  %t74 = load ptr, ptr %l4, !tbaa !29
  store ptr %t74, ptr %l36, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t76 = load ptr, ptr %l36, !tbaa !29
  %t77 = call ptr @__olang_scope_or(ptr %v3, ptr %t76)
  %t78 = call ptr @__olang_scope_hold(ptr %t77)
  %t79 = ptrtoint ptr %t78 to i64
  %t81 = inttoptr i64 %t79 to ptr
  %t82 = load ptr, ptr %l36, !tbaa !29
  %t84 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %t81, ptr %s0, ptr %v2, ptr %t82, { i64, ptr } %t75)
  store { i64, ptr } %t84, ptr %l39
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
bb9:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/emit:fnEm", ptr %t86, i32 0, i32 17
  %t89 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t92 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %s0, ptr %v0, ptr %t88, { i64, ptr } %t89)
  %t93 = extractvalue { i32, { i64, ptr } } %t92, 1
  %t94 = extractvalue { i32, { i64, ptr } } %t92, 0
  store i32 %t94, ptr %l45
  %t95 = icmp ne i32 %t94, 0
  br i1 %t95, label %bb11, label %ok.96, !prof !99
ok.96:
  store { i64, ptr } %t93, ptr %l44
  br label %bb10
bb10:
  %t97 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t97, ptr %l40, !tbaa !27
  br label %bb13
bb11:
  br label %bb12
bb12:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d394, i32 0, i32 1) }, ptr %l40, !tbaa !27
  br label %bb13
bb13:
  %t98 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t98, ptr %l6, !tbaa !27
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t101 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t99, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d395, i32 0, i32 1) })
  store i1 %t101, ptr %l47
  br label %bb14
bb14:
  %t102 = load i1, ptr %l47, !tbaa !21
  %t103 = xor i1 %t102, true
  br i1 %t103, label %bb15, label %bb16
bb15:
  %t105 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t113 = load ptr, ptr %l4, !tbaa !29
  store ptr %t113, ptr %l51, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/emit:fnEm", ptr %t114, i32 0, i32 2
  %t117 = load { i64, [2 x i64] }, ptr %t116
  %t118 = load ptr, ptr %l51, !tbaa !29
  %t119 = call ptr @__olang_scope_or(ptr %v3, ptr %t118)
  %t120 = call ptr @__olang_scope_hold(ptr %t119)
  %t121 = ptrtoint ptr %t120 to i64
  %t123 = inttoptr i64 %t121 to ptr
  %t124 = load ptr, ptr %l51, !tbaa !29
  %t126 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2elocBase(ptr %t123, ptr %s0, ptr %t124, { i64, [2 x i64] } %t117)
  store { i64, ptr } %t126, ptr %l55
  br label %bb18
bb18:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/emit:fnEm", ptr %t127, i32 0, i32 16
  %t130 = load i64, ptr %t129, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t139 = call i64 @__olang_fmt_i64(ptr null, i64 %t130)
  %t140 = add i64 %t137, %t139
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 1
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d396, i32 0, i32 1) }, 0
  %t143 = add i64 %t140, %t142
  %t145 = extractvalue { i64, ptr } %t131, 1
  %t146 = extractvalue { i64, ptr } %t131, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t133, i64 %t134)
  %t149 = getelementptr i8, ptr %t148, i64 %t134
  call void @olang_textcopy(ptr %t149, ptr %t135, i64 %t136)
  %t150 = getelementptr i8, ptr %t149, i64 %t136
  %t151 = call i64 @__olang_fmt_i64(ptr %t150, i64 %t130)
  %t152 = getelementptr i8, ptr %t150, i64 %t139
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  call void @olang_textcopy(ptr %t153, ptr %t145, i64 %t146)
  %t154 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t148, 1
  store { i64, ptr } %t155, ptr %l7, !tbaa !27
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l60, !tbaa !29
  %t158 = load ptr, ptr %l60, !tbaa !29
  %t159 = getelementptr %"compiler/emit:fnEm", ptr %t158, i32 0, i32 16
  %t160 = load i64, ptr %t159, !tbaa !24
  %t163 = add i64 %t160, 1
  %t165 = load ptr, ptr %l60, !tbaa !29
  %t166 = getelementptr %"compiler/emit:fnEm", ptr %t165, i32 0, i32 16
  store i64 %t163, ptr %t166, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d397, i32 0, i32 1) }, 0
  %t171 = extractvalue { i64, ptr } %t167, 1
  %t172 = extractvalue { i64, ptr } %t167, 0
  %t173 = add i64 %t169, %t172
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t168, i64 %t169)
  %t175 = getelementptr i8, ptr %t174, i64 %t169
  call void @olang_textcopy(ptr %t175, ptr %t171, i64 %t172)
  %t176 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t174, 1
  store { i64, ptr } %t177, ptr %l8, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t181 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t179)
  store i64 %t181, ptr %l67
  br label %bb19
bb19:
  %t182 = load i64, ptr %l67, !tbaa !24
  store i64 %t182, ptr %l68, !tbaa !65
  %t183 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t184 = extractvalue { i32, i64 } %t183, 1
  %t185 = extractvalue { i32, i64 } %t183, 0
  store i32 %t185, ptr %l70
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb21, label %ok.187, !prof !99
ok.187:
  store i64 %t184, ptr %l69
  br label %bb20
bb20:
  %t188 = load i64, ptr %l68, !tbaa !65
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t188, i64 %t189)
  store { i64, ptr } %t190, ptr %l71
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_6a1c0f36bb2af484_15693b919ea68168)
  unreachable
bb22:
  %t191 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t193 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %s0, { i64, ptr } %t191)
  store i64 %t193, ptr %l73
  br label %bb23
bb23:
  %t194 = load i64, ptr %l73, !tbaa !24
  store i64 %t194, ptr %l74, !tbaa !65
  %t195 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s0, i64 16)
  %t196 = extractvalue { i32, i64 } %t195, 1
  %t197 = extractvalue { i32, i64 } %t195, 0
  store i32 %t197, ptr %l76
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb25, label %ok.199, !prof !99
ok.199:
  store i64 %t196, ptr %l75
  br label %bb24
bb24:
  %t200 = load i64, ptr %l74, !tbaa !65
  %t201 = load i64, ptr %l75, !tbaa !24
  %t202 = call { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %s0, i64 %t200, i64 %t201)
  store { i64, ptr } %t202, ptr %l77
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_6a1c0f36bb2af484_15693b919ea68168)
  unreachable
bb26:
  %t203 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d398, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d398, i32 0, i32 1) }, 0
  %t205 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = add i64 %t204, %t207
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d399, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d399, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t212 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = add i64 %t211, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t203, i64 %t204)
  %t217 = getelementptr i8, ptr %t216, i64 %t204
  call void @olang_textcopy(ptr %t217, ptr %t206, i64 %t207)
  %t218 = getelementptr i8, ptr %t217, i64 %t207
  call void @olang_textcopy(ptr %t218, ptr %t209, i64 %t210)
  %t219 = getelementptr i8, ptr %t218, i64 %t210
  call void @olang_textcopy(ptr %t219, ptr %t213, i64 %t214)
  %t220 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t216, 1
  store { i64, ptr } %t221, ptr %l9, !tbaa !27
  %t223 = load ptr, ptr %l4, !tbaa !29
  %t225 = getelementptr %"compiler/emit:Emitter", ptr %t223, i32 0, i32 26
  store ptr %t225, ptr %l80, !tbaa !29
  %t226 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t227 = load ptr, ptr %l80, !tbaa !29
  %t228 = call ptr @__olang_scope_or(ptr %v3, ptr %t227)
  %t229 = call ptr @__olang_scope_hold(ptr %t228)
  %t230 = ptrtoint ptr %t229 to i64
  %t232 = inttoptr i64 %t230 to ptr
  %t233 = load ptr, ptr %l80, !tbaa !29
  %t235 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %t232, ptr %s0, ptr %t233, { i64, ptr } %t226)
  store i1 %t235, ptr %l83
  br label %bb27
bb27:
  %t236 = load i1, ptr %l83, !tbaa !21
  %t237 = xor i1 %t236, true
  br i1 %t237, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t239 = call ptr @__olang_scope_hold(ptr %s8)
  %t240 = ptrtoint ptr %t239 to i64
  store i64 %t240, ptr %l85, !tbaa !24
  %t241 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2elocated_2elocal_2e10
  br i1 %t241, label %bb30, label %bb31
bb29:
  br label %bb56
bb30:
  %t243 = call ptr @__olang_region_make(ptr %s8)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l85, !tbaa !24
  br label %bb31
bb31:
  %t245 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t245, ptr %l87, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  %t250 = add i64 %t248, 1
  store i64 %t250, ptr %l90, !tbaa !24
  %t251 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t253 = call { i64, ptr } @compiler_2femit_2eescape(ptr %s0, ptr %s8, { i64, ptr } %t251)
  store { i64, ptr } %t253, ptr %l92
  br label %bb32
bb32:
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d400, i32 0, i32 1) }, 0
  %t256 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = add i64 %t255, %t258
  %t260 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d401, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d401, i32 0, i32 1) }, 0
  %t262 = add i64 %t259, %t261
  %t263 = load i64, ptr %l90, !tbaa !24
  %t264 = call i64 @__olang_fmt_i64(ptr null, i64 %t263)
  %t265 = add i64 %t262, %t264
  %t266 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d402, i32 0, i32 1) }, 1
  %t267 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d402, i32 0, i32 1) }, 0
  %t268 = add i64 %t265, %t267
  %t269 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 1
  %t271 = extractvalue { i64, ptr } %t269, 0
  %t272 = add i64 %t268, %t271
  %t273 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d403, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d403, i32 0, i32 1) }, 0
  %t275 = add i64 %t272, %t274
  %t276 = load i64, ptr %l85
  %t277 = inttoptr i64 %t276 to ptr
  %t278 = call ptr @__olang_held_alloc(ptr %t277, i64 %t275)
  call void @olang_textcopy(ptr %t278, ptr %t254, i64 %t255)
  %t279 = getelementptr i8, ptr %t278, i64 %t255
  call void @olang_textcopy(ptr %t279, ptr %t257, i64 %t258)
  %t280 = getelementptr i8, ptr %t279, i64 %t258
  call void @olang_textcopy(ptr %t280, ptr %t260, i64 %t261)
  %t281 = getelementptr i8, ptr %t280, i64 %t261
  %t282 = call i64 @__olang_fmt_i64(ptr %t281, i64 %t263)
  %t283 = getelementptr i8, ptr %t281, i64 %t264
  call void @olang_textcopy(ptr %t283, ptr %t266, i64 %t267)
  %t284 = getelementptr i8, ptr %t283, i64 %t267
  call void @olang_textcopy(ptr %t284, ptr %t270, i64 %t271)
  %t285 = getelementptr i8, ptr %t284, i64 %t271
  call void @olang_textcopy(ptr %t285, ptr %t273, i64 %t274)
  %t286 = insertvalue { i64, ptr } undef, i64 %t275, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t278, 1
  store { i64, ptr } %t287, ptr %l93, !tbaa !27
  %t288 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2elocated_2elocal_2e10
  br i1 %t288, label %bb33, label %bb34
bb33:
  %t290 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t293 = icmp eq i64 %t291, 0
  br i1 %t293, label %bb35, label %bb36
bb34:
  %t295 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t295, ptr %l10, !tbaa !27
  %t296 = load ptr, ptr %l4, !tbaa !29
  %t298 = getelementptr %"compiler/emit:Emitter", ptr %t296, i32 0, i32 31
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  store { i64, ptr } %t299, ptr %l98, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 1
  %t302 = call ptr @__olang_scope_or(ptr %v3, ptr %t301)
  %t303 = call ptr @__olang_scope_hold(ptr %t302)
  %t304 = ptrtoint ptr %t303 to i64
  %t306 = inttoptr i64 %t304 to ptr
  %t307 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t308 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t306, ptr %s8, { i64, ptr } %t307, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d404, i32 0, i32 1) })
  store i1 %t308, ptr %l100
  br label %bb37
bb35:
  store { i64, ptr } zeroinitializer, ptr %l93, !tbaa !27
  br label %bb36
bb36:
  %t309 = load i64, ptr %l85
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = load { i64, ptr }, ptr %l93
  %t312 = extractvalue { i64, ptr } %t311, 1
  %t313 = call ptr @__olang_region_or(ptr %t312, ptr null)
  %t314 = icmp ne ptr %t313, null
  %t315 = select i1 %t314, ptr %t313, ptr null
  call void @__olang_region_settle_in(ptr %t310, ptr %t315)
  br label %bb34
bb37:
  %t316 = load i1, ptr %l100, !tbaa !21
  br i1 %t316, label %bb38, label %bb39
bb38:
  %t317 = call ptr @__olang_scope_hold(ptr %s8)
  %t318 = ptrtoint ptr %t317 to i64
  store i64 %t318, ptr %l101, !tbaa !24
  %t319 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2elocated_2elocal_2e10
  br i1 %t319, label %bb40, label %bb41
bb39:
  br label %bb54
bb40:
  %t321 = call ptr @__olang_region_make(ptr %s8)
  %t322 = ptrtoint ptr %t321 to i64
  store i64 %t322, ptr %l101, !tbaa !24
  br label %bb41
bb41:
  %t323 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t323, ptr %l103, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t328 = sub i64 %t326, 1
  store i64 %t328, ptr %l106, !tbaa !24
  %t329 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  store i64 %t330, ptr %l107, !tbaa !24
  %t331 = icmp sge i64 0, 0
  br i1 %t331, label %bb42, label %bb43
bb42:
  %t333 = load i64, ptr %l106, !tbaa !24
  %t334 = icmp sle i64 0, %t333
  br i1 %t334, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7bda3904fb775f6e_cd0d5260ae61bcf2)
  unreachable
bb44:
  %t336 = load i64, ptr %l106, !tbaa !24
  %t337 = load i64, ptr %l107, !tbaa !24
  %t338 = icmp sle i64 %t336, %t337
  br i1 %t338, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_7bda3904fb775f6e_cd0d5260ae61bcf2)
  unreachable
bb46:
  %t340 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = load i64, ptr %l106, !tbaa !24
  %t343 = getelementptr i8, ptr %t341, i64 0
  %t344 = sub i64 %t342, 0
  %t345 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t343, 1
  %t347 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d405, i32 0, i32 1) }, 0
  %t349 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 1
  %t351 = extractvalue { i64, ptr } %t349, 0
  %t352 = add i64 %t348, %t351
  %t353 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d406, i32 0, i32 1) }, 1
  %t354 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d406, i32 0, i32 1) }, 0
  %t355 = add i64 %t352, %t354
  %t357 = extractvalue { i64, ptr } %t346, 1
  %t358 = extractvalue { i64, ptr } %t346, 0
  %t359 = add i64 %t355, %t358
  %t360 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d407, i32 0, i32 1) }, 1
  %t361 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d407, i32 0, i32 1) }, 0
  %t362 = add i64 %t359, %t361
  %t363 = load i64, ptr %l101
  %t364 = inttoptr i64 %t363 to ptr
  %t365 = call ptr @__olang_held_alloc(ptr %t364, i64 %t362)
  call void @olang_textcopy(ptr %t365, ptr %t347, i64 %t348)
  %t366 = getelementptr i8, ptr %t365, i64 %t348
  call void @olang_textcopy(ptr %t366, ptr %t350, i64 %t351)
  %t367 = getelementptr i8, ptr %t366, i64 %t351
  call void @olang_textcopy(ptr %t367, ptr %t353, i64 %t354)
  %t368 = getelementptr i8, ptr %t367, i64 %t354
  call void @olang_textcopy(ptr %t368, ptr %t357, i64 %t358)
  %t369 = getelementptr i8, ptr %t368, i64 %t358
  call void @olang_textcopy(ptr %t369, ptr %t360, i64 %t361)
  %t370 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t365, 1
  store { i64, ptr } %t371, ptr %l112, !tbaa !27
  %t372 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2elocated_2elocal_2e10
  br i1 %t372, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7bda3904fb775f6e_cd0d5260ae61bcf2)
  unreachable
bb48:
  %t374 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 0
  %t377 = icmp eq i64 %t375, 0
  br i1 %t377, label %bb50, label %bb51
bb49:
  %t379 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t379, ptr %l116, !tbaa !27
  %t380 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t380, ptr %l10, !tbaa !27
  %t381 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2elocated_2elocal_2e10
  br i1 %t381, label %bb52, label %bb53
bb50:
  store { i64, ptr } zeroinitializer, ptr %l112, !tbaa !27
  br label %bb51
bb51:
  %t383 = load i64, ptr %l101
  %t384 = inttoptr i64 %t383 to ptr
  %t385 = load { i64, ptr }, ptr %l112
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = call ptr @__olang_region_or(ptr %t386, ptr null)
  %t388 = icmp ne ptr %t387, null
  %t389 = select i1 %t388, ptr %t387, ptr null
  call void @__olang_region_settle_in(ptr %t384, ptr %t389)
  br label %bb49
bb52:
  %t390 = load { i64, ptr }, ptr %l116
  %t391 = extractvalue { i64, ptr } %t390, 1
  call void @__olang_region_release(ptr %t391)
  store { i64, ptr } zeroinitializer, ptr %l116
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t392 = load ptr, ptr %l4, !tbaa !29
  store ptr %t392, ptr %l118, !tbaa !29
  %t393 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t394 = load i64, ptr @G_2ecompiler_2femit_2eHomeLoc, !tbaa !24
  %t395 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t396 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t397 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d408, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d408, i32 0, i32 1) }, 0
  %t400 = extractvalue { i64, ptr } %t396, 1
  %t401 = extractvalue { i64, ptr } %t396, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d409, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d409, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t406 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t405)
  call void @olang_textcopy(ptr %t406, ptr %t397, i64 %t398)
  %t407 = getelementptr i8, ptr %t406, i64 %t398
  call void @olang_textcopy(ptr %t407, ptr %t400, i64 %t401)
  %t408 = getelementptr i8, ptr %t407, i64 %t401
  call void @olang_textcopy(ptr %t408, ptr %t403, i64 %t404)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t406, 1
  %t412 = load ptr, ptr %l118, !tbaa !29
  %t413 = call ptr @__olang_scope_or(ptr %v3, ptr %t412)
  %t414 = call ptr @__olang_scope_hold(ptr %t413)
  %t415 = ptrtoint ptr %t414 to i64
  %t417 = inttoptr i64 %t415 to ptr
  %t418 = load ptr, ptr %l118, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %t417, ptr %s0, ptr %s8, ptr %s8, ptr %t418, { i64, ptr } %t393, i64 %t394, { i64, ptr } %t395, { i64, ptr } %t410)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/emit:fnEm", ptr %t423, i32 0, i32 17
  store ptr %t425, ptr %l127, !tbaa !29
  %t426 = call ptr @__olang_scope_hold(ptr %v0)
  %t427 = ptrtoint ptr %t426 to i64
  store i64 %t427, ptr %l128, !tbaa !24
  %t428 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670
  br i1 %t428, label %bb57, label %bb58
bb57:
  %t430 = call ptr @__olang_region_make(ptr %v0)
  %t431 = ptrtoint ptr %t430 to i64
  store i64 %t431, ptr %l128, !tbaa !24
  br label %bb58
bb58:
  %t432 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 1
  %t435 = extractvalue { i64, ptr } %t432, 0
  %t436 = load i64, ptr %l128
  %t437 = inttoptr i64 %t436 to ptr
  %t438 = call ptr @__olang_held_alloc(ptr %t437, i64 %t435)
  call void @olang_textcopy(ptr %t438, ptr %t434, i64 %t435)
  %t439 = insertvalue { i64, ptr } undef, i64 %t435, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  store { i64, ptr } %t440, ptr %l132, !tbaa !27
  %t442 = call ptr @__olang_scope_hold(ptr %v0)
  %t443 = ptrtoint ptr %t442 to i64
  store i64 %t443, ptr %l133, !tbaa !24
  %t444 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03
  br i1 %t444, label %bb59, label %bb60
bb59:
  %t446 = call ptr @__olang_region_make(ptr %v0)
  %t447 = ptrtoint ptr %t446 to i64
  store i64 %t447, ptr %l133, !tbaa !24
  br label %bb60
bb60:
  %t448 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t449 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d410, i32 0, i32 1) }, 1
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d410, i32 0, i32 1) }, 0
  %t452 = extractvalue { i64, ptr } %t448, 1
  %t453 = extractvalue { i64, ptr } %t448, 0
  %t454 = add i64 %t450, %t453
  %t455 = load i64, ptr %l133
  %t456 = inttoptr i64 %t455 to ptr
  %t457 = call ptr @__olang_held_alloc(ptr %t456, i64 %t454)
  call void @olang_textcopy(ptr %t457, ptr %t449, i64 %t450)
  %t458 = getelementptr i8, ptr %t457, i64 %t450
  call void @olang_textcopy(ptr %t458, ptr %t452, i64 %t453)
  %t459 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t457, 1
  %t462 = load ptr, ptr %l127, !tbaa !29
  %t463 = load { i64, ptr }, ptr %l132, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v0, ptr %v0, ptr %t462, { i64, ptr } %t463, { i64, ptr } %t460)
  br label %bb61
bb61:
  %t465 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t466 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d411, i32 0, i32 1) }, 1
  %t467 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d411, i32 0, i32 1) }, 0
  %t469 = extractvalue { i64, ptr } %t465, 1
  %t470 = extractvalue { i64, ptr } %t465, 0
  %t471 = add i64 %t467, %t470
  %t472 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t471)
  call void @olang_textcopy(ptr %t472, ptr %t466, i64 %t467)
  %t473 = getelementptr i8, ptr %t472, i64 %t467
  call void @olang_textcopy(ptr %t473, ptr %t469, i64 %t470)
  %t474 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t472, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t475, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, [15 x i64] }
  %l6 = alloca { i64, [15 x i64] }
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca i32
  %l9 = alloca %"compiler/mir:Lvalue"
  %l13 = alloca { i64, [15 x i64] }
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca i1
  %l30 = alloca i1
  %l31 = alloca %"compiler/mir:Lvalue"
  %l32 = alloca ptr
  %l36 = alloca %"compiler/mir:Lvalue"
  %l38 = alloca i1
  %l39 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca ptr
  %l46 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %rv = alloca i1
  %t26 = alloca { i64, [4 x i64] }, align 8
  %t29 = alloca { i64, [15 x i64] }, align 8
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l14, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 20}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l15, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [21 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t20, i32 0, i32 2
  %t22 = load { i64, [15 x i64] }, ptr %t21
  store { i64, [15 x i64] } %t22, ptr %l5
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t24 = load { i64, [15 x i64] }, ptr %l5
  store { i64, [15 x i64] } %t24, ptr %l13
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store { i64, [4 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 0
  store i64 0, ptr %t27
  %t28 = load { i64, [4 x i64] }, ptr %t26
  store { i64, [15 x i64] } zeroinitializer, ptr %t29
  %t30 = getelementptr { i64, [15 x i64] }, ptr %t29, i32 0, i32 0
  store i64 0, ptr %t30
  %t32 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %t28, 0
  %t33 = getelementptr { i64, [15 x i64] }, ptr %t29, i32 0, i32 1
  store { { i64, [4 x i64] } } %t32, ptr %t33
  %t34 = load { i64, [15 x i64] }, ptr %t29
  store { i64, [15 x i64] } %t34, ptr %l13
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_d93074814994636b_bdb833f18b1c6fff)
  unreachable
bb11:
  %t36 = load { i64, [15 x i64] }, ptr %l13
  store { i64, [15 x i64] } %t36, ptr %l6
  %t37 = load { i64, [15 x i64] }, ptr %l6
  %t39 = extractvalue { i64, [15 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 7
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t42 = getelementptr { i64, [15 x i64] }, ptr %l6, i32 0, i32 1
  %t43 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t42, i32 0, i32 1
  %t44 = load { i64, [4 x i64] }, ptr %t43
  store { i64, [4 x i64] } %t44, ptr %l7
  %t46 = getelementptr { i64, [15 x i64] }, ptr %l6, i32 0, i32 1
  %t47 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t46, i32 0, i32 2
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l8, !tbaa !23
  br label %bb14
bb13:
  br label %bb26
bb14:
  %t50 = load { i64, [4 x i64] }, ptr %l7
  %t52 = extractvalue { i64, [4 x i64] } %t50, 0
  %t53 = icmp eq i64 %t52, 1
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = getelementptr { i64, [4 x i64] }, ptr %l7, i32 0, i32 1
  %t56 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t55, i32 0, i32 0
  %t57 = load %"compiler/mir:Lvalue", ptr %t56
  store %"compiler/mir:Lvalue" %t57, ptr %l31
  store ptr %l31, ptr %l32, !tbaa !29
  %t60 = trunc i64 %a2 to i32
  %t63 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %t60)
  store %"compiler/mir:Lvalue" %t63, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t64 = load ptr, ptr %l32, !tbaa !29
  %t66 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aLvalue(ptr %t64, ptr %l36)
  store i1 %t66, ptr %l38
  br label %bb18
bb18:
  %t67 = load i1, ptr %l38, !tbaa !21
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t68 = load i1, ptr %l30, !tbaa !21
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t69 = getelementptr { i64, [4 x i64] }, ptr %l7, i32 0, i32 1
  %t70 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t69, i32 0, i32 0
  %t71 = load %"compiler/mir:Lvalue", ptr %t70
  store %"compiler/mir:Lvalue" %t71, ptr %l9
  %t73 = load ptr, ptr %l4, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  %t74 = load ptr, ptr %l4, !tbaa !29
  store ptr %t74, ptr %l42, !tbaa !29
  %t75 = load ptr, ptr %l4, !tbaa !29
  store ptr %t75, ptr %l43, !tbaa !29
  %t76 = load i32, ptr %l8, !tbaa !23
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t78 = call ptr @__olang_scope_or(ptr %v2, ptr %t77)
  %t79 = call ptr @__olang_scope_hold(ptr %t78)
  %t80 = ptrtoint ptr %t79 to i64
  %t82 = inttoptr i64 %t80 to ptr
  %t83 = load ptr, ptr %l43, !tbaa !29
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t82, ptr %t83, i32 %t76)
  store i32 %t85, ptr %l46
  br label %bb22
bb21:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb25
bb22:
  %t86 = load ptr, ptr %l42, !tbaa !29
  %t87 = call ptr @__olang_scope_or(ptr %v2, ptr %t86)
  %t88 = call ptr @__olang_scope_hold(ptr %t87)
  %t89 = ptrtoint ptr %t88 to i64
  %t91 = inttoptr i64 %t89 to ptr
  %t92 = load ptr, ptr %l42, !tbaa !29
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %t91, ptr %t92, i32 %t93)
  store i32 %t94, ptr %l48
  br label %bb23
bb23:
  %t95 = load ptr, ptr %l41, !tbaa !29
  %t96 = call ptr @__olang_scope_or(ptr %v2, ptr %t95)
  %t97 = call ptr @__olang_scope_hold(ptr %t96)
  %t98 = ptrtoint ptr %t97 to i64
  %t100 = inttoptr i64 %t98 to ptr
  %t101 = load ptr, ptr %l41, !tbaa !29
  %t102 = load i32, ptr %l48, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t100, ptr %t101, i32 %t102)
  store i32 %t103, ptr %l50
  br label %bb24
bb24:
  %t105 = load i32, ptr %l50, !tbaa !23
  %t107 = icmp eq i32 %t105, %a3
  store i1 %t107, ptr %l39, !tbaa !21
  br label %bb25
bb25:
  %t109 = load i1, ptr %l39, !tbaa !21
  store i1 %t109, ptr %l23, !tbaa !21
  br label %bb31
bb26:
  br i1 true, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_73776ce6ec0034aa_c594c414c7ca39fe)
  unreachable
bb31:
  %t110 = load i1, ptr %l23, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOnce(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/mir:BasicBlock"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, [21 x i64] }
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca i64
  %l25 = alloca ptr
  %l27 = alloca i64
  %l30 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca %"compiler/mir:BasicBlock"
  %l38 = alloca %"compiler/mir:BasicBlock"
  %l40 = alloca i64
  %l42 = alloca i64
  %l47 = alloca { i64, [21 x i64] }
  %l51 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca i64
  %l64 = alloca i32
  %l79 = alloca i1
  %l86 = alloca ptr
  %l92 = alloca i64
  %l94 = alloca i64
  %l99 = alloca i32
  %l114 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l20
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/emit:fnEm", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Fn", ptr %t8, i32 0, i32 9
  store ptr %t10, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l24, !tbaa !24
  %t13 = load ptr, ptr %l7, !tbaa !29
  store ptr %t13, ptr %l25, !tbaa !29
  %t14 = load ptr, ptr %l25, !tbaa !29
  %t15 = call ptr @__olang_scope_or(ptr %v1, ptr %t14)
  %t16 = call ptr @__olang_scope_hold(ptr %t15)
  %t17 = ptrtoint ptr %t16 to i64
  %t19 = inttoptr i64 %t17 to ptr
  %t20 = load ptr, ptr %l25, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t19, ptr %t20)
  store i64 %t21, ptr %l27
  br label %bb4
bb4:
  %t22 = load i64, ptr %l24, !tbaa !24
  %t23 = load i64, ptr %l27, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb51
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l7, !tbaa !29
  store ptr %t28, ptr %l30, !tbaa !29
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load ptr, ptr %l30, !tbaa !29
  %t31 = call ptr @__olang_scope_or(ptr %v1, ptr %t30)
  %t32 = call ptr @__olang_scope_hold(ptr %t31)
  %t33 = ptrtoint ptr %t32 to i64
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/emit:fnEm", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = call ptr @__olang_scope_or(ptr %v1, ptr %t37)
  %t40 = call ptr @__olang_scope_hold(ptr %t39)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l35, !tbaa !24
  %t43 = inttoptr i64 %t33 to ptr
  %t44 = load i64, ptr %l35
  %t45 = inttoptr i64 %t44 to ptr
  %t46 = load ptr, ptr %l30, !tbaa !29
  %t48 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t43, ptr %t45, ptr %t46, i64 %t29)
  store %"compiler/mir:BasicBlock" %t48, ptr %l36
  br label %bb8
bb8:
  %t49 = load i64, ptr %l35
  %t50 = inttoptr i64 %t49 to ptr
  %t52 = call %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %t50, ptr %l36)
  store %"compiler/mir:BasicBlock" %t52, ptr %l38
  br label %bb9
bb9:
  %t53 = load %"compiler/mir:BasicBlock", ptr %l38
  store %"compiler/mir:BasicBlock" %t53, ptr %l9
  %t54 = getelementptr %"compiler/mir:BasicBlock", ptr %l9, i32 0, i32 0
  store ptr %t54, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t56 = load i64, ptr %l11, !tbaa !24
  store i64 %t56, ptr %l40, !tbaa !24
  %t57 = load ptr, ptr %l10, !tbaa !29
  %t59 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %s2, ptr %t57)
  store i64 %t59, ptr %l42
  br label %bb11
bb11:
  %t60 = load i64, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l42, !tbaa !24
  %t62 = icmp slt i64 %t60, %t61
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb13:
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l10, !tbaa !29
  %t67 = load i64, ptr %l11, !tbaa !24
  %t70 = call { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %s2, ptr %t66, i64 %t67)
  store { i64, [21 x i64] } %t70, ptr %l47
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l47, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l3)
  br label %bb16
bb16:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l4)
  br label %bb17
bb17:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/emit:fnEm", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l51, !tbaa !29
  %t77 = load ptr, ptr %l51, !tbaa !29
  %t78 = call ptr @__olang_scope_or(ptr %v1, ptr %t77)
  %t79 = call ptr @__olang_scope_hold(ptr %t78)
  %t80 = ptrtoint ptr %t79 to i64
  %t82 = inttoptr i64 %t80 to ptr
  %t83 = load ptr, ptr %l51, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eMentions(ptr %t82, ptr %s4, ptr %s0, ptr %s0, ptr %t83, ptr %l12, ptr %l3, ptr %l4)
  br label %bb18
bb18:
  store ptr %l3, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb19
bb19:
  %t88 = load i64, ptr %l14, !tbaa !24
  store i64 %t88, ptr %l57, !tbaa !24
  %t89 = load ptr, ptr %l13, !tbaa !29
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t89)
  store i64 %t91, ptr %l59
  br label %bb20
bb20:
  %t92 = load i64, ptr %l57, !tbaa !24
  %t93 = load i64, ptr %l59, !tbaa !24
  %t94 = icmp slt i64 %t92, %t93
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb21, label %bb22
bb21:
  br label %bb29
bb22:
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l13, !tbaa !29
  %t99 = load i64, ptr %l14, !tbaa !24
  %t102 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t98, i64 %t99)
  store i32 %t102, ptr %l64
  br label %bb24
bb24:
  %t103 = load i32, ptr %l64, !tbaa !23
  %t106 = sext i32 %t103 to i64
  %t107 = load i64, ptr %l1, !tbaa !24
  %t110 = icmp eq i64 %t106, %t107
  br i1 %t110, label %bb25, label %bb26
bb25:
  %t112 = load i64, ptr %l5, !tbaa !24
  %t115 = add i64 %t112, 1
  store i64 %t115, ptr %l5, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = add i64 %t117, 1
  store i64 %t120, ptr %l14, !tbaa !24
  br label %bb19
bb29:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  %t129 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2enewOf(ptr %v0, ptr %s4, ptr %v2, ptr %t122, ptr %l12, i64 %t123, i32 %a2)
  store i1 %t129, ptr %l79
  br label %bb30
bb30:
  %t130 = load i1, ptr %l79, !tbaa !21
  br i1 %t130, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb34
bb34:
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l11, !tbaa !24
  br label %bb10
bb35:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l3)
  br label %bb36
bb36:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %l4)
  br label %bb37
bb37:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/emit:fnEm", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  store ptr %t141, ptr %l86, !tbaa !29
  %t142 = getelementptr %"compiler/mir:BasicBlock", ptr %l9, i32 0, i32 1
  %t143 = load { i64, [8 x i64] }, ptr %t142
  %t144 = load ptr, ptr %l86, !tbaa !29
  %t145 = call ptr @__olang_scope_or(ptr %v1, ptr %t144)
  %t146 = call ptr @__olang_scope_hold(ptr %t145)
  %t147 = ptrtoint ptr %t146 to i64
  %t149 = inttoptr i64 %t147 to ptr
  %t150 = load ptr, ptr %l86, !tbaa !29
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermMentions(ptr %t149, ptr %s0, ptr %s0, ptr %t150, { i64, [8 x i64] } %t143, ptr %l3, ptr %l4)
  br label %bb38
bb38:
  store ptr %l3, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t155 = load i64, ptr %l17, !tbaa !24
  store i64 %t155, ptr %l92, !tbaa !24
  %t156 = load ptr, ptr %l16, !tbaa !29
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t156)
  store i64 %t158, ptr %l94
  br label %bb40
bb40:
  %t159 = load i64, ptr %l92, !tbaa !24
  %t160 = load i64, ptr %l94, !tbaa !24
  %t161 = icmp slt i64 %t159, %t160
  %t163 = xor i1 %t161, true
  br i1 %t163, label %bb41, label %bb42
bb41:
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t165 = load ptr, ptr %l16, !tbaa !29
  %t166 = load i64, ptr %l17, !tbaa !24
  %t169 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %s0, ptr %t165, i64 %t166)
  store i32 %t169, ptr %l99
  br label %bb44
bb44:
  %t170 = load i32, ptr %l99, !tbaa !23
  %t173 = sext i32 %t170 to i64
  %t174 = load i64, ptr %l1, !tbaa !24
  %t177 = icmp eq i64 %t173, %t174
  br i1 %t177, label %bb45, label %bb46
bb45:
  %t179 = load i64, ptr %l5, !tbaa !24
  %t182 = add i64 %t179, 1
  store i64 %t182, ptr %l5, !tbaa !24
  br label %bb47
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t184 = load i64, ptr %l17, !tbaa !24
  %t187 = add i64 %t184, 1
  store i64 %t187, ptr %l17, !tbaa !24
  br label %bb39
bb49:
  call void @__olang_scope_close(ptr %s2)
  br label %bb50
bb50:
  %t189 = load i64, ptr %l8, !tbaa !24
  %t192 = add i64 %t189, 1
  store i64 %t192, ptr %l8, !tbaa !24
  br label %bb3
bb51:
  %t194 = load i1, ptr %l6, !tbaa !21
  br i1 %t194, label %bb52, label %bb53
bb52:
  %t196 = load i64, ptr %l5, !tbaa !24
  %t198 = icmp eq i64 %t196, 1
  store i1 %t198, ptr %l114, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t200 = load i1, ptr %l114, !tbaa !21
  store i1 %t200, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2ereclaim(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca { i64, [4 x i64] }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, [4 x i64] }
  %l50 = alloca i64
  %l59 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l64 = alloca ptr
  %l65 = alloca { i64, [4 x i64] }
  %l68 = alloca i32
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l100 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l115 = alloca ptr
  %l116 = alloca ptr
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l131 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca i64
  %l144 = alloca i64
  %l164 = alloca ptr
  %l170 = alloca { i64, [4 x i64] }
  %l171 = alloca ptr
  %l174 = alloca i32
  %l176 = alloca i32
  %l178 = alloca ptr
  %l181 = alloca i1
  %l186 = alloca { i64, ptr }
  %l188 = alloca i1
  %l195 = alloca i64
  %l196 = alloca { i64, ptr }
  %l200 = alloca i64
  %l206 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l216 = alloca i64
  %l219 = alloca i64
  %l239 = alloca { i64, [4 x i64] }
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca { i64, [4 x i64] }
  %l245 = alloca i32
  %l246 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l259 = alloca { i64, ptr }
  %l261 = alloca { i64, ptr }
  %l265 = alloca i1
  %l267 = alloca ptr
  %l270 = alloca i1
  %l272 = alloca i64
  %l275 = alloca i64
  %l281 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l291 = alloca i64
  %l294 = alloca i64
  %l314 = alloca { i64, [4 x i64] }
  %l315 = alloca ptr
  %l316 = alloca ptr
  %l317 = alloca { i64, [4 x i64] }
  %l320 = alloca i32
  %l321 = alloca { i64, ptr }
  %l324 = alloca { i64, ptr }
  %l325 = alloca ptr
  %l326 = alloca { i64, ptr }
  %l333 = alloca { i64, ptr }
  %l339 = alloca i64
  %l341 = alloca ptr
  %l342 = alloca ptr
  %l344 = alloca ptr
  %l348 = alloca { i64, ptr }
  %l351 = alloca { i64, ptr }
  %l355 = alloca { i64, ptr }
  %l359 = alloca { i64, ptr }
  %l362 = alloca ptr
  %l364 = alloca ptr
  %l365 = alloca { i64, ptr }
  %l367 = alloca ptr
  %l370 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/mir:Fn", ptr %t4, i32 0, i32 0
  %t7 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t7, ptr %l4
  %t9 = load { i64, [2 x i64] }, ptr %l4
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t15 = getelementptr { i32 }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t18 = load i32, ptr %l5, !tbaa !23
  %t20 = sext i32 %t18 to i64
  store i64 %t20, ptr %l50, !tbaa !24
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i64 -1, ptr %l50, !tbaa !24
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_768769e499c57657_c453ba5dc43e6f8b)
  unreachable
bb9:
  %t22 = load i64, ptr %l50, !tbaa !24
  store i64 %t22, ptr %l6, !tbaa !24
  %t23 = load i64, ptr %l6, !tbaa !24
  %t25 = icmp slt i64 %t23, 0
  br i1 %t25, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/emit:fnEm", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l59, !tbaa !29
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l59, !tbaa !29
  %t34 = call ptr @__olang_scope_or(ptr %v1, ptr %t33)
  %t35 = call ptr @__olang_scope_hold(ptr %t34)
  %t36 = ptrtoint ptr %t35 to i64
  %t38 = inttoptr i64 %t36 to ptr
  %t39 = load ptr, ptr %l59, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOk(ptr %t38, ptr %s0, ptr %t39, i64 %t31, i32 %t32)
  store { i64, ptr } %t42, ptr %l63
  br label %bb13
bb13:
  %t43 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l64, !tbaa !29
  %t45 = load { i64, [4 x i64] }, ptr %l1
  store { i64, [4 x i64] } %t45, ptr %l65
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load { i64, [4 x i64] }, ptr %l1
  %t50 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v1, ptr %t46, { i64, [4 x i64] } %t47)
  store i32 %t50, ptr %l68
  br label %bb14
bb14:
  %t51 = load ptr, ptr %l64, !tbaa !29
  %t52 = load { i64, [4 x i64] }, ptr %l65
  %t53 = load i32, ptr %l68, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t51, { i64, [4 x i64] } %t52, i32 %t53)
  store { i64, ptr } %t54, ptr %l69
  br label %bb15
bb15:
  %t55 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t55, ptr %l8, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t56, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d412, i32 0, i32 1) })
  store { i64, ptr } %t58, ptr %l71
  br label %bb16
bb16:
  %t59 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t59, ptr %l9, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t60, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d413, i32 0, i32 1) })
  store { i64, ptr } %t62, ptr %l73
  br label %bb17
bb17:
  %t63 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t63, ptr %l10, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t64, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d414, i32 0, i32 1) })
  store { i64, ptr } %t66, ptr %l75
  br label %bb18
bb18:
  %t67 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t67, ptr %l11, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t68, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d415, i32 0, i32 1) })
  store { i64, ptr } %t70, ptr %l77
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t71, ptr %l12, !tbaa !27
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t74 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d416, i32 0, i32 1) }, 1
  %t75 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d416, i32 0, i32 1) }, 0
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = add i64 %t75, %t78
  %t80 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d417, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d417, i32 0, i32 1) }, 0
  %t82 = add i64 %t79, %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t74, i64 %t75)
  %t84 = getelementptr i8, ptr %t83, i64 %t75
  call void @olang_textcopy(ptr %t84, ptr %t77, i64 %t78)
  %t85 = getelementptr i8, ptr %t84, i64 %t78
  call void @olang_textcopy(ptr %t85, ptr %t80, i64 %t81)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t83, 1
  %t91 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t72, { i64, ptr } %t87)
  store { i64, ptr } %t91, ptr %l82
  br label %bb20
bb20:
  %t92 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t92, ptr %l13, !tbaa !27
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l83, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l84, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t97 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d418, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d418, i32 0, i32 1) }, 0
  %t100 = extractvalue { i64, ptr } %t96, 1
  %t101 = extractvalue { i64, ptr } %t96, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t97, i64 %t98)
  %t104 = getelementptr i8, ptr %t103, i64 %t98
  call void @olang_textcopy(ptr %t104, ptr %t100, i64 %t101)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  %t110 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %v1, ptr %t95, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d419, i32 0, i32 1) }, { i64, ptr } %t106, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store { i64, ptr } %t110, ptr %l89
  br label %bb21
bb21:
  %t111 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t112 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d420, i32 0, i32 1) }, 1
  %t113 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d420, i32 0, i32 1) }, 0
  %t114 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t114, 1
  %t116 = extractvalue { i64, ptr } %t114, 0
  %t117 = add i64 %t113, %t116
  %t118 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d421, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d421, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t111, 1
  %t123 = extractvalue { i64, ptr } %t111, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t112, i64 %t113)
  %t126 = getelementptr i8, ptr %t125, i64 %t113
  call void @olang_textcopy(ptr %t126, ptr %t115, i64 %t116)
  %t127 = getelementptr i8, ptr %t126, i64 %t116
  call void @olang_textcopy(ptr %t127, ptr %t118, i64 %t119)
  %t128 = getelementptr i8, ptr %t127, i64 %t119
  call void @olang_textcopy(ptr %t128, ptr %t122, i64 %t123)
  %t129 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t125, 1
  %t132 = load ptr, ptr %l84, !tbaa !29
  %t134 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t132, { i64, ptr } %t130)
  store { i64, ptr } %t134, ptr %l93
  br label %bb22
bb22:
  %t135 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t137 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d422, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d422, i32 0, i32 1) }, 0
  %t139 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t145 = add i64 %t142, %t144
  %t147 = extractvalue { i64, ptr } %t135, 1
  %t148 = extractvalue { i64, ptr } %t135, 0
  %t149 = add i64 %t145, %t148
  %t150 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d423, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t154 = extractvalue { i64, ptr } %t136, 1
  %t155 = extractvalue { i64, ptr } %t136, 0
  %t156 = add i64 %t152, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t137, i64 %t138)
  %t158 = getelementptr i8, ptr %t157, i64 %t138
  call void @olang_textcopy(ptr %t158, ptr %t140, i64 %t141)
  %t159 = getelementptr i8, ptr %t158, i64 %t141
  call void @olang_textcopy(ptr %t159, ptr %t143, i64 %t144)
  %t160 = getelementptr i8, ptr %t159, i64 %t144
  call void @olang_textcopy(ptr %t160, ptr %t147, i64 %t148)
  %t161 = getelementptr i8, ptr %t160, i64 %t148
  call void @olang_textcopy(ptr %t161, ptr %t150, i64 %t151)
  %t162 = getelementptr i8, ptr %t161, i64 %t151
  call void @olang_textcopy(ptr %t162, ptr %t154, i64 %t155)
  %t163 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t157, 1
  %t166 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t166, { i64, ptr } %t164)
  br label %bb23
bb23:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t168, { i64, ptr } %t169)
  br label %bb24
bb24:
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l100, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t175 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d424, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d424, i32 0, i32 1) }, 0
  %t178 = extractvalue { i64, ptr } %t174, 1
  %t179 = extractvalue { i64, ptr } %t174, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d425, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d425, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t184 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t183)
  call void @olang_textcopy(ptr %t184, ptr %t175, i64 %t176)
  %t185 = getelementptr i8, ptr %t184, i64 %t176
  call void @olang_textcopy(ptr %t185, ptr %t178, i64 %t179)
  %t186 = getelementptr i8, ptr %t185, i64 %t179
  call void @olang_textcopy(ptr %t186, ptr %t181, i64 %t182)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t184, 1
  %t192 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t173, { i64, ptr } %t188)
  store { i64, ptr } %t192, ptr %l105
  br label %bb25
bb25:
  %t193 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d426, i32 0, i32 1) }, 1
  %t194 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d426, i32 0, i32 1) }, 0
  %t195 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = add i64 %t194, %t197
  %t199 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d427, i32 0, i32 1) }, 1
  %t200 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d427, i32 0, i32 1) }, 0
  %t201 = add i64 %t198, %t200
  %t202 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t201)
  call void @olang_textcopy(ptr %t202, ptr %t193, i64 %t194)
  %t203 = getelementptr i8, ptr %t202, i64 %t194
  call void @olang_textcopy(ptr %t203, ptr %t196, i64 %t197)
  %t204 = getelementptr i8, ptr %t203, i64 %t197
  call void @olang_textcopy(ptr %t204, ptr %t199, i64 %t200)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t202, 1
  %t208 = load ptr, ptr %l100, !tbaa !29
  %t210 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t208, { i64, ptr } %t206)
  store { i64, ptr } %t210, ptr %l108
  br label %bb26
bb26:
  %t211 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t211, ptr %l14, !tbaa !27
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t214 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d428, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d428, i32 0, i32 1) }, 0
  %t217 = extractvalue { i64, ptr } %t213, 1
  %t218 = extractvalue { i64, ptr } %t213, 0
  %t219 = add i64 %t215, %t218
  %t220 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t219)
  call void @olang_textcopy(ptr %t220, ptr %t214, i64 %t215)
  %t221 = getelementptr i8, ptr %t220, i64 %t215
  call void @olang_textcopy(ptr %t221, ptr %t217, i64 %t218)
  %t222 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t220, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t212, { i64, ptr } %t223)
  br label %bb27
bb27:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t227, { i64, ptr } %t228)
  br label %bb28
bb28:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l115, !tbaa !29
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l116, !tbaa !29
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t235 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d429, i32 0, i32 1) }, 1
  %t236 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d429, i32 0, i32 1) }, 0
  %t238 = extractvalue { i64, ptr } %t234, 1
  %t239 = extractvalue { i64, ptr } %t234, 0
  %t240 = add i64 %t236, %t239
  %t241 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d430, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d430, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t244 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t243)
  call void @olang_textcopy(ptr %t244, ptr %t235, i64 %t236)
  %t245 = getelementptr i8, ptr %t244, i64 %t236
  call void @olang_textcopy(ptr %t245, ptr %t238, i64 %t239)
  %t246 = getelementptr i8, ptr %t245, i64 %t239
  call void @olang_textcopy(ptr %t246, ptr %t241, i64 %t242)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t244, 1
  %t252 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t233, { i64, ptr } %t248)
  store { i64, ptr } %t252, ptr %l121
  br label %bb29
bb29:
  %t253 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d431, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d431, i32 0, i32 1) }, 0
  %t255 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 1
  %t257 = extractvalue { i64, ptr } %t255, 0
  %t258 = add i64 %t254, %t257
  %t259 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d432, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d432, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t253, i64 %t254)
  %t263 = getelementptr i8, ptr %t262, i64 %t254
  call void @olang_textcopy(ptr %t263, ptr %t256, i64 %t257)
  %t264 = getelementptr i8, ptr %t263, i64 %t257
  call void @olang_textcopy(ptr %t264, ptr %t259, i64 %t260)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t262, 1
  %t268 = load ptr, ptr %l116, !tbaa !29
  %t270 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t268, { i64, ptr } %t266)
  store { i64, ptr } %t270, ptr %l124
  br label %bb30
bb30:
  %t271 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t273 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d433, i32 0, i32 1) }, 1
  %t274 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d433, i32 0, i32 1) }, 0
  %t275 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  %t278 = add i64 %t274, %t277
  %t279 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t280 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t281 = add i64 %t278, %t280
  %t283 = extractvalue { i64, ptr } %t271, 1
  %t284 = extractvalue { i64, ptr } %t271, 0
  %t285 = add i64 %t281, %t284
  %t286 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 1
  %t287 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d434, i32 0, i32 1) }, 0
  %t288 = add i64 %t285, %t287
  %t290 = extractvalue { i64, ptr } %t272, 1
  %t291 = extractvalue { i64, ptr } %t272, 0
  %t292 = add i64 %t288, %t291
  %t293 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t292)
  call void @olang_textcopy(ptr %t293, ptr %t273, i64 %t274)
  %t294 = getelementptr i8, ptr %t293, i64 %t274
  call void @olang_textcopy(ptr %t294, ptr %t276, i64 %t277)
  %t295 = getelementptr i8, ptr %t294, i64 %t277
  call void @olang_textcopy(ptr %t295, ptr %t279, i64 %t280)
  %t296 = getelementptr i8, ptr %t295, i64 %t280
  call void @olang_textcopy(ptr %t296, ptr %t283, i64 %t284)
  %t297 = getelementptr i8, ptr %t296, i64 %t284
  call void @olang_textcopy(ptr %t297, ptr %t286, i64 %t287)
  %t298 = getelementptr i8, ptr %t297, i64 %t287
  call void @olang_textcopy(ptr %t298, ptr %t290, i64 %t291)
  %t299 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t293, 1
  %t302 = load ptr, ptr %l115, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t302, { i64, ptr } %t300)
  br label %bb31
bb31:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t304, { i64, ptr } %t305)
  br label %bb32
bb32:
  %t308 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %l131
  br label %bb33
bb33:
  %t309 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l131
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t309, ptr %l15
  %t310 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t310, ptr %l132
  br label %bb34
bb34:
  %t311 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t311, ptr %l16
  store i1 false, ptr %l17, !tbaa !21
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/emit:fnEm", ptr %t312, i32 0, i32 0
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/emit:Emitter", ptr %t315, i32 0, i32 3
  %t318 = load ptr, ptr %t317, !tbaa !29
  store ptr %t318, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  %t320 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t321 = load i32, ptr %t320, !tbaa !23
  %t323 = sext i32 %t321 to i64
  store i64 %t323, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t325 = load i64, ptr %l20, !tbaa !24
  %t326 = load i64, ptr %l19, !tbaa !24
  %t329 = icmp sgt i64 %t325, %t326
  br i1 %t329, label %bb35, label %bb36
bb35:
  %t331 = load i64, ptr %l21, !tbaa !24
  %t333 = icmp sgt i64 %t331, 0
  br i1 %t333, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l141, !tbaa !24
  br label %bb40
bb37:
  %t335 = load i64, ptr %l20, !tbaa !24
  %t336 = load i64, ptr %l19, !tbaa !24
  %t339 = sub i64 %t335, %t336
  %t340 = load i64, ptr %l21, !tbaa !24
  %t343 = add i64 %t339, %t340
  %t345 = sub i64 %t343, 1
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = sdiv i64 %t345, %t346
  store i64 %t349, ptr %l144, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb39
bb39:
  %t351 = load i64, ptr %l144, !tbaa !24
  store i64 %t351, ptr %l141, !tbaa !24
  br label %bb40
bb40:
  %t352 = load i64, ptr %l141, !tbaa !24
  store i64 %t352, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb41
bb41:
  %t353 = load i64, ptr %l23, !tbaa !24
  %t354 = load i64, ptr %l22, !tbaa !24
  %t357 = icmp slt i64 %t353, %t354
  %t359 = xor i1 %t357, true
  br i1 %t359, label %bb42, label %bb43
bb42:
  br label %bb60
bb43:
  br label %bb44
bb44:
  %t361 = load i64, ptr %l19, !tbaa !24
  %t362 = load i64, ptr %l23, !tbaa !24
  %t363 = load i64, ptr %l21, !tbaa !24
  %t366 = mul i64 %t362, %t363
  %t369 = add i64 %t361, %t366
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/emit:fnEm", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = getelementptr %"compiler/mir:Fn", ptr %t374, i32 0, i32 11
  store ptr %t376, ptr %l164, !tbaa !29
  %t377 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t378 = load i32, ptr %t377, !tbaa !23
  %t380 = sext i32 %t378 to i64
  %t384 = add i64 %t380, %t369
  %t385 = load ptr, ptr %l164, !tbaa !29
  %t386 = call ptr @__olang_scope_or(ptr %v2, ptr %t385)
  %t387 = call ptr @__olang_scope_hold(ptr %t386)
  %t388 = ptrtoint ptr %t387 to i64
  %t390 = inttoptr i64 %t388 to ptr
  %t391 = load ptr, ptr %l164, !tbaa !29
  %t393 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t390, ptr %t391, i64 %t384)
  store { i64, [4 x i64] } %t393, ptr %l170
  br label %bb45
bb45:
  %t394 = load { i64, [4 x i64] }, ptr %l170
  store { i64, [4 x i64] } %t394, ptr %l25
  %t395 = load ptr, ptr %l18, !tbaa !29
  store ptr %t395, ptr %l171, !tbaa !29
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t397 = load { i64, [4 x i64] }, ptr %l25
  %t400 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v1, ptr %t396, { i64, [4 x i64] } %t397)
  store i32 %t400, ptr %l174
  br label %bb46
bb46:
  %t401 = load ptr, ptr %l171, !tbaa !29
  %t402 = call ptr @__olang_scope_or(ptr %v1, ptr %t401)
  %t403 = call ptr @__olang_scope_hold(ptr %t402)
  %t404 = ptrtoint ptr %t403 to i64
  %t406 = inttoptr i64 %t404 to ptr
  %t407 = load ptr, ptr %l171, !tbaa !29
  %t408 = load i32, ptr %l174, !tbaa !23
  %t409 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t406, ptr %t407, i32 %t408)
  store i32 %t409, ptr %l176
  br label %bb47
bb47:
  %t410 = load i32, ptr %l176, !tbaa !23
  store i32 %t410, ptr %l26, !tbaa !23
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/emit:fnEm", ptr %t411, i32 0, i32 0
  %t414 = load ptr, ptr %t413, !tbaa !29
  store ptr %t414, ptr %l178, !tbaa !29
  %t415 = load i32, ptr %l26, !tbaa !23
  %t416 = load ptr, ptr %l178, !tbaa !29
  %t417 = call ptr @__olang_scope_or(ptr %v1, ptr %t416)
  %t418 = call ptr @__olang_scope_hold(ptr %t417)
  %t419 = ptrtoint ptr %t418 to i64
  %t421 = inttoptr i64 %t419 to ptr
  %t422 = load ptr, ptr %l178, !tbaa !29
  %t424 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenRef(ptr %t421, ptr %t422, i32 %t415)
  store i1 %t424, ptr %l181
  br label %bb48
bb48:
  %t425 = load i1, ptr %l181, !tbaa !21
  br i1 %t425, label %bb49, label %bb50
bb49:
  %t426 = load { i64, [4 x i64] }, ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l15, { i64, [4 x i64] } %t426)
  br label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s17
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load i32, ptr %l26, !tbaa !23
  %t433 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s17, ptr %v1, ptr %t429, i32 %t430)
  store { i64, ptr } %t433, ptr %l186
  br label %bb52
bb51:
  br label %bb58
bb52:
  %t434 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t436 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s17, ptr %s17, { i64, ptr } %t434, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d435, i32 0, i32 1) })
  store i1 %t436, ptr %l188
  br label %bb53
bb53:
  %t437 = load i1, ptr %l188, !tbaa !21
  br i1 %t437, label %bb54, label %bb55
bb54:
  %t438 = load { i64, [4 x i64] }, ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l16, { i64, [4 x i64] } %t438)
  br label %bb56
bb55:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s17)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t441 = load i64, ptr %l23, !tbaa !24
  %t444 = add i64 %t441, 1
  store i64 %t444, ptr %l23, !tbaa !24
  br label %bb41
bb60:
  %t447 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l15)
  store i64 %t447, ptr %l195
  br label %bb61
bb61:
  %t448 = load i64, ptr %l195, !tbaa !24
  store i64 %t448, ptr %l27, !tbaa !24
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d436, i32 0, i32 1) }, ptr %l196, !tbaa !27
  %t449 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t449, ptr %l28, !tbaa !27
  %t451 = load i64, ptr %l27, !tbaa !24
  %t453 = icmp sgt i64 %t451, 0
  br i1 %t453, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s21
  %t455 = call ptr @__olang_scope_hold(ptr %s0)
  %t456 = ptrtoint ptr %t455 to i64
  store i64 %t456, ptr %l200, !tbaa !24
  %t457 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e28
  br i1 %t457, label %bb64, label %bb65
bb63:
  br label %bb90
bb64:
  %t459 = call ptr @__olang_region_make(ptr %s0)
  %t460 = ptrtoint ptr %t459 to i64
  store i64 %t460, ptr %l200, !tbaa !24
  br label %bb65
bb65:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load i64, ptr %l27, !tbaa !24
  %t463 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d437, i32 0, i32 1) }, 1
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d437, i32 0, i32 1) }, 0
  %t466 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t467 = add i64 %t464, %t466
  %t468 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d438, i32 0, i32 1) }, 1
  %t469 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d438, i32 0, i32 1) }, 0
  %t470 = add i64 %t467, %t469
  %t471 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t470)
  call void @olang_textcopy(ptr %t471, ptr %t463, i64 %t464)
  %t472 = getelementptr i8, ptr %t471, i64 %t464
  %t473 = call i64 @__olang_fmt_i64(ptr %t472, i64 %t462)
  %t474 = getelementptr i8, ptr %t472, i64 %t466
  call void @olang_textcopy(ptr %t474, ptr %t468, i64 %t469)
  %t475 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t471, 1
  %t478 = load i64, ptr %l200
  %t479 = inttoptr i64 %t478 to ptr
  %t482 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s21, ptr %t479, ptr %t461, { i64, ptr } %t476, i64 0)
  store { i64, ptr } %t482, ptr %l206
  br label %bb66
bb66:
  %t483 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e28
  br i1 %t483, label %bb67, label %bb68
bb67:
  %t485 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 0
  %t488 = icmp eq i64 %t486, 0
  br i1 %t488, label %bb69, label %bb70
bb68:
  %t490 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t490, ptr %l210, !tbaa !27
  %t491 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t491, ptr %l28, !tbaa !27
  %t492 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e28
  br i1 %t492, label %bb71, label %bb72
bb69:
  store { i64, ptr } zeroinitializer, ptr %l206, !tbaa !27
  br label %bb70
bb70:
  %t494 = load i64, ptr %l200
  %t495 = inttoptr i64 %t494 to ptr
  %t496 = load { i64, ptr }, ptr %l206
  %t497 = extractvalue { i64, ptr } %t496, 1
  %t498 = call ptr @__olang_region_or(ptr %t497, ptr null)
  %t499 = icmp ne ptr %t498, null
  %t500 = select i1 %t499, ptr %t498, ptr null
  call void @__olang_region_settle_in(ptr %t495, ptr %t500)
  br label %bb68
bb71:
  %t501 = load { i64, ptr }, ptr %l210
  %t502 = extractvalue { i64, ptr } %t501, 1
  call void @__olang_region_release(ptr %t502)
  store { i64, ptr } zeroinitializer, ptr %l210
  br label %bb72
bb72:
  store i64 0, ptr %l29, !tbaa !24
  %t503 = load i64, ptr %l27, !tbaa !24
  store i64 %t503, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t505 = load i64, ptr %l30, !tbaa !24
  %t506 = load i64, ptr %l29, !tbaa !24
  %t509 = icmp sgt i64 %t505, %t506
  br i1 %t509, label %bb73, label %bb74
bb73:
  %t511 = load i64, ptr %l31, !tbaa !24
  %t513 = icmp sgt i64 %t511, 0
  br i1 %t513, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb78
bb75:
  %t515 = load i64, ptr %l30, !tbaa !24
  %t516 = load i64, ptr %l29, !tbaa !24
  %t519 = sub i64 %t515, %t516
  %t520 = load i64, ptr %l31, !tbaa !24
  %t523 = add i64 %t519, %t520
  %t525 = sub i64 %t523, 1
  %t526 = load i64, ptr %l31, !tbaa !24
  %t529 = sdiv i64 %t525, %t526
  store i64 %t529, ptr %l219, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l219, !tbaa !24
  br label %bb77
bb77:
  %t531 = load i64, ptr %l219, !tbaa !24
  store i64 %t531, ptr %l216, !tbaa !24
  br label %bb78
bb78:
  %t532 = load i64, ptr %l216, !tbaa !24
  store i64 %t532, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s24
  %t533 = load i64, ptr %l33, !tbaa !24
  %t534 = load i64, ptr %l32, !tbaa !24
  %t537 = icmp slt i64 %t533, %t534
  %t539 = xor i1 %t537, true
  br i1 %t539, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s24)
  br label %bb89
bb81:
  br label %bb82
bb82:
  %t541 = load i64, ptr %l29, !tbaa !24
  %t542 = load i64, ptr %l33, !tbaa !24
  %t543 = load i64, ptr %l31, !tbaa !24
  %t546 = mul i64 %t542, %t543
  %t549 = add i64 %t541, %t546
  store i64 %t549, ptr %l34, !tbaa !24
  %t551 = load i64, ptr %l34, !tbaa !24
  %t554 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l15, i64 %t551)
  store { i64, [4 x i64] } %t554, ptr %l239
  br label %bb83
bb83:
  %t555 = load { i64, [4 x i64] }, ptr %l239
  store { i64, [4 x i64] } %t555, ptr %l35
  %t556 = load ptr, ptr %l0, !tbaa !29
  store ptr %t556, ptr %l240, !tbaa !29
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l241, !tbaa !29
  %t558 = load { i64, [4 x i64] }, ptr %l35
  store { i64, [4 x i64] } %t558, ptr %l242
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load { i64, [4 x i64] }, ptr %l35
  %t563 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v1, ptr %t559, { i64, [4 x i64] } %t560)
  store i32 %t563, ptr %l245
  br label %bb84
bb84:
  %t564 = load ptr, ptr %l241, !tbaa !29
  %t565 = load { i64, [4 x i64] }, ptr %l242
  %t566 = load i32, ptr %l245, !tbaa !23
  %t567 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s24, ptr %v2, ptr %v1, ptr %t564, { i64, [4 x i64] } %t565, i32 %t566)
  store { i64, ptr } %t567, ptr %l246
  br label %bb85
bb85:
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load i64, ptr %l27, !tbaa !24
  %t570 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t571 = load i64, ptr %l34, !tbaa !24
  %t572 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d439, i32 0, i32 1) }, 1
  %t573 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d439, i32 0, i32 1) }, 0
  %t575 = call i64 @__olang_fmt_i64(ptr null, i64 %t569)
  %t576 = add i64 %t573, %t575
  %t577 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d440, i32 0, i32 1) }, 1
  %t578 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d440, i32 0, i32 1) }, 0
  %t579 = add i64 %t576, %t578
  %t581 = extractvalue { i64, ptr } %t570, 1
  %t582 = extractvalue { i64, ptr } %t570, 0
  %t583 = add i64 %t579, %t582
  %t584 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d441, i32 0, i32 1) }, 1
  %t585 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d441, i32 0, i32 1) }, 0
  %t586 = add i64 %t583, %t585
  %t588 = call i64 @__olang_fmt_i64(ptr null, i64 %t571)
  %t589 = add i64 %t586, %t588
  %t590 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t589)
  call void @olang_textcopy(ptr %t590, ptr %t572, i64 %t573)
  %t591 = getelementptr i8, ptr %t590, i64 %t573
  %t592 = call i64 @__olang_fmt_i64(ptr %t591, i64 %t569)
  %t593 = getelementptr i8, ptr %t591, i64 %t575
  call void @olang_textcopy(ptr %t593, ptr %t577, i64 %t578)
  %t594 = getelementptr i8, ptr %t593, i64 %t578
  call void @olang_textcopy(ptr %t594, ptr %t581, i64 %t582)
  %t595 = getelementptr i8, ptr %t594, i64 %t582
  call void @olang_textcopy(ptr %t595, ptr %t584, i64 %t585)
  %t596 = getelementptr i8, ptr %t595, i64 %t585
  %t597 = call i64 @__olang_fmt_i64(ptr %t596, i64 %t571)
  %t598 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t599 = insertvalue { i64, ptr } %t598, ptr %t590, 1
  %t603 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s24, ptr %s24, ptr %v1, ptr %t568, { i64, ptr } %t599)
  store { i64, ptr } %t603, ptr %l253
  br label %bb86
bb86:
  %t604 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d442, i32 0, i32 1) }, 1
  %t605 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d442, i32 0, i32 1) }, 0
  %t606 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t607 = extractvalue { i64, ptr } %t606, 1
  %t608 = extractvalue { i64, ptr } %t606, 0
  %t609 = add i64 %t605, %t608
  %t610 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 1
  %t611 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d443, i32 0, i32 1) }, 0
  %t612 = add i64 %t609, %t611
  %t613 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = add i64 %t612, %t615
  %t617 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t616)
  call void @olang_textcopy(ptr %t617, ptr %t604, i64 %t605)
  %t618 = getelementptr i8, ptr %t617, i64 %t605
  call void @olang_textcopy(ptr %t618, ptr %t607, i64 %t608)
  %t619 = getelementptr i8, ptr %t618, i64 %t608
  call void @olang_textcopy(ptr %t619, ptr %t610, i64 %t611)
  %t620 = getelementptr i8, ptr %t619, i64 %t611
  call void @olang_textcopy(ptr %t620, ptr %t614, i64 %t615)
  %t621 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t622 = insertvalue { i64, ptr } %t621, ptr %t617, 1
  %t624 = load ptr, ptr %l240, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s24, ptr %v1, ptr %t624, { i64, ptr } %t622)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s24)
  br label %bb88
bb88:
  %t626 = load i64, ptr %l33, !tbaa !24
  %t629 = add i64 %t626, 1
  store i64 %t629, ptr %l33, !tbaa !24
  br label %bb79
bb89:
  call void @__olang_scope_close(ptr %s21)
  br label %bb90
bb90:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d444, i32 0, i32 1) }, ptr %l259, !tbaa !27
  %t631 = load { i64, ptr }, ptr %l259, !tbaa !27
  store { i64, ptr } %t631, ptr %l36, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d445, i32 0, i32 1) }, ptr %l261, !tbaa !27
  %t633 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t633, ptr %l37, !tbaa !27
  %t635 = load i1, ptr %l17, !tbaa !21
  %t637 = xor i1 %t635, true
  br i1 %t637, label %bb91, label %bb92
bb91:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t641 = getelementptr %"compiler/emit:fnEm", ptr %t639, i32 0, i32 0
  %t642 = load ptr, ptr %t641, !tbaa !29
  store ptr %t642, ptr %l267, !tbaa !29
  %t643 = load i32, ptr %l2, !tbaa !23
  %t644 = load ptr, ptr %l267, !tbaa !29
  %t645 = call ptr @__olang_scope_or(ptr %v1, ptr %t644)
  %t646 = call ptr @__olang_scope_hold(ptr %t645)
  %t647 = ptrtoint ptr %t646 to i64
  %t649 = inttoptr i64 %t647 to ptr
  %t650 = load ptr, ptr %l267, !tbaa !29
  %t652 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBufOn(ptr %t649, ptr %t650, i32 %t643)
  store i1 %t652, ptr %l270
  br label %bb93
bb92:
  store i1 false, ptr %l265, !tbaa !21
  br label %bb94
bb93:
  %t653 = load i1, ptr %l270, !tbaa !21
  store i1 %t653, ptr %l265, !tbaa !21
  br label %bb94
bb94:
  %t654 = load i1, ptr %l265, !tbaa !21
  br i1 %t654, label %bb95, label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s28
  %t656 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l16)
  store i64 %t656, ptr %l272
  br label %bb97
bb96:
  br label %bb139
bb97:
  %t657 = load i64, ptr %l272, !tbaa !24
  store i64 %t657, ptr %l38, !tbaa !24
  %t658 = load i64, ptr %l38, !tbaa !24
  %t660 = icmp sgt i64 %t658, 0
  br i1 %t660, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s29
  %t662 = call ptr @__olang_scope_hold(ptr %s0)
  %t663 = ptrtoint ptr %t662 to i64
  store i64 %t663, ptr %l275, !tbaa !24
  %t664 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e36
  br i1 %t664, label %bb100, label %bb101
bb99:
  br label %bb127
bb100:
  %t666 = call ptr @__olang_region_make(ptr %s0)
  %t667 = ptrtoint ptr %t666 to i64
  store i64 %t667, ptr %l275, !tbaa !24
  br label %bb101
bb101:
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load i64, ptr %l38, !tbaa !24
  %t670 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 1
  %t671 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d446, i32 0, i32 1) }, 0
  %t673 = call i64 @__olang_fmt_i64(ptr null, i64 %t669)
  %t674 = add i64 %t671, %t673
  %t675 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d447, i32 0, i32 1) }, 1
  %t676 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d447, i32 0, i32 1) }, 0
  %t677 = add i64 %t674, %t676
  %t678 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t677)
  call void @olang_textcopy(ptr %t678, ptr %t670, i64 %t671)
  %t679 = getelementptr i8, ptr %t678, i64 %t671
  %t680 = call i64 @__olang_fmt_i64(ptr %t679, i64 %t669)
  %t681 = getelementptr i8, ptr %t679, i64 %t673
  call void @olang_textcopy(ptr %t681, ptr %t675, i64 %t676)
  %t682 = insertvalue { i64, ptr } undef, i64 %t677, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t678, 1
  %t685 = load i64, ptr %l275
  %t686 = inttoptr i64 %t685 to ptr
  %t689 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %s29, ptr %t686, ptr %t668, { i64, ptr } %t683, i64 0)
  store { i64, ptr } %t689, ptr %l281
  br label %bb102
bb102:
  %t690 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e36
  br i1 %t690, label %bb103, label %bb104
bb103:
  %t692 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t693 = extractvalue { i64, ptr } %t692, 0
  %t695 = icmp eq i64 %t693, 0
  br i1 %t695, label %bb105, label %bb106
bb104:
  %t697 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t697, ptr %l285, !tbaa !27
  %t698 = load { i64, ptr }, ptr %l281, !tbaa !27
  store { i64, ptr } %t698, ptr %l36, !tbaa !27
  %t699 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e36
  br i1 %t699, label %bb107, label %bb108
bb105:
  store { i64, ptr } zeroinitializer, ptr %l281, !tbaa !27
  br label %bb106
bb106:
  %t701 = load i64, ptr %l275
  %t702 = inttoptr i64 %t701 to ptr
  %t703 = load { i64, ptr }, ptr %l281
  %t704 = extractvalue { i64, ptr } %t703, 1
  %t705 = call ptr @__olang_region_or(ptr %t704, ptr null)
  %t706 = icmp ne ptr %t705, null
  %t707 = select i1 %t706, ptr %t705, ptr null
  call void @__olang_region_settle_in(ptr %t702, ptr %t707)
  br label %bb104
bb107:
  %t708 = load { i64, ptr }, ptr %l285
  %t709 = extractvalue { i64, ptr } %t708, 1
  call void @__olang_region_release(ptr %t709)
  store { i64, ptr } zeroinitializer, ptr %l285
  br label %bb108
bb108:
  store i64 0, ptr %l39, !tbaa !24
  %t710 = load i64, ptr %l38, !tbaa !24
  store i64 %t710, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t712 = load i64, ptr %l40, !tbaa !24
  %t713 = load i64, ptr %l39, !tbaa !24
  %t716 = icmp sgt i64 %t712, %t713
  br i1 %t716, label %bb109, label %bb110
bb109:
  %t718 = load i64, ptr %l41, !tbaa !24
  %t720 = icmp sgt i64 %t718, 0
  br i1 %t720, label %bb111, label %bb112
bb110:
  store i64 0, ptr %l291, !tbaa !24
  br label %bb114
bb111:
  %t722 = load i64, ptr %l40, !tbaa !24
  %t723 = load i64, ptr %l39, !tbaa !24
  %t726 = sub i64 %t722, %t723
  %t727 = load i64, ptr %l41, !tbaa !24
  %t730 = add i64 %t726, %t727
  %t732 = sub i64 %t730, 1
  %t733 = load i64, ptr %l41, !tbaa !24
  %t736 = sdiv i64 %t732, %t733
  store i64 %t736, ptr %l294, !tbaa !24
  br label %bb113
bb112:
  store i64 0, ptr %l294, !tbaa !24
  br label %bb113
bb113:
  %t738 = load i64, ptr %l294, !tbaa !24
  store i64 %t738, ptr %l291, !tbaa !24
  br label %bb114
bb114:
  %t739 = load i64, ptr %l291, !tbaa !24
  store i64 %t739, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s32
  %t740 = load i64, ptr %l43, !tbaa !24
  %t741 = load i64, ptr %l42, !tbaa !24
  %t744 = icmp slt i64 %t740, %t741
  %t746 = xor i1 %t744, true
  br i1 %t746, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s32)
  br label %bb126
bb117:
  br label %bb118
bb118:
  %t748 = load i64, ptr %l39, !tbaa !24
  %t749 = load i64, ptr %l43, !tbaa !24
  %t750 = load i64, ptr %l41, !tbaa !24
  %t753 = mul i64 %t749, %t750
  %t756 = add i64 %t748, %t753
  store i64 %t756, ptr %l44, !tbaa !24
  %t758 = load i64, ptr %l44, !tbaa !24
  %t761 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %s0, ptr %l16, i64 %t758)
  store { i64, [4 x i64] } %t761, ptr %l314
  br label %bb119
bb119:
  %t762 = load { i64, [4 x i64] }, ptr %l314
  store { i64, [4 x i64] } %t762, ptr %l45
  %t763 = load ptr, ptr %l0, !tbaa !29
  store ptr %t763, ptr %l315, !tbaa !29
  %t764 = load ptr, ptr %l0, !tbaa !29
  store ptr %t764, ptr %l316, !tbaa !29
  %t765 = load { i64, [4 x i64] }, ptr %l45
  store { i64, [4 x i64] } %t765, ptr %l317
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load { i64, [4 x i64] }, ptr %l45
  %t770 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v1, ptr %t766, { i64, [4 x i64] } %t767)
  store i32 %t770, ptr %l320
  br label %bb120
bb120:
  %t771 = load ptr, ptr %l316, !tbaa !29
  %t772 = load { i64, [4 x i64] }, ptr %l317
  %t773 = load i32, ptr %l320, !tbaa !23
  %t774 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s32, ptr %v2, ptr %v1, ptr %t771, { i64, [4 x i64] } %t772, i32 %t773)
  store { i64, ptr } %t774, ptr %l321
  br label %bb121
bb121:
  %t775 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d448, i32 0, i32 1) }, 1
  %t776 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d448, i32 0, i32 1) }, 0
  %t777 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t778 = extractvalue { i64, ptr } %t777, 1
  %t779 = extractvalue { i64, ptr } %t777, 0
  %t780 = add i64 %t776, %t779
  %t781 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d449, i32 0, i32 1) }, 1
  %t782 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d449, i32 0, i32 1) }, 0
  %t783 = add i64 %t780, %t782
  %t784 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t783)
  call void @olang_textcopy(ptr %t784, ptr %t775, i64 %t776)
  %t785 = getelementptr i8, ptr %t784, i64 %t776
  call void @olang_textcopy(ptr %t785, ptr %t778, i64 %t779)
  %t786 = getelementptr i8, ptr %t785, i64 %t779
  call void @olang_textcopy(ptr %t786, ptr %t781, i64 %t782)
  %t787 = insertvalue { i64, ptr } undef, i64 %t783, 0
  %t788 = insertvalue { i64, ptr } %t787, ptr %t784, 1
  %t790 = load ptr, ptr %l315, !tbaa !29
  %t792 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %v1, ptr %t790, { i64, ptr } %t788)
  store { i64, ptr } %t792, ptr %l324
  br label %bb122
bb122:
  %t793 = load { i64, ptr }, ptr %l324, !tbaa !27
  %t794 = load ptr, ptr %l0, !tbaa !29
  store ptr %t794, ptr %l325, !tbaa !29
  store { i64, ptr } %t793, ptr %l326, !tbaa !27
  %t796 = load ptr, ptr %l0, !tbaa !29
  %t797 = load i64, ptr %l38, !tbaa !24
  %t798 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t799 = load i64, ptr %l44, !tbaa !24
  %t800 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d450, i32 0, i32 1) }, 1
  %t801 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d450, i32 0, i32 1) }, 0
  %t803 = call i64 @__olang_fmt_i64(ptr null, i64 %t797)
  %t804 = add i64 %t801, %t803
  %t805 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d451, i32 0, i32 1) }, 1
  %t806 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d451, i32 0, i32 1) }, 0
  %t807 = add i64 %t804, %t806
  %t809 = extractvalue { i64, ptr } %t798, 1
  %t810 = extractvalue { i64, ptr } %t798, 0
  %t811 = add i64 %t807, %t810
  %t812 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d452, i32 0, i32 1) }, 1
  %t813 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d452, i32 0, i32 1) }, 0
  %t814 = add i64 %t811, %t813
  %t816 = call i64 @__olang_fmt_i64(ptr null, i64 %t799)
  %t817 = add i64 %t814, %t816
  %t818 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t817)
  call void @olang_textcopy(ptr %t818, ptr %t800, i64 %t801)
  %t819 = getelementptr i8, ptr %t818, i64 %t801
  %t820 = call i64 @__olang_fmt_i64(ptr %t819, i64 %t797)
  %t821 = getelementptr i8, ptr %t819, i64 %t803
  call void @olang_textcopy(ptr %t821, ptr %t805, i64 %t806)
  %t822 = getelementptr i8, ptr %t821, i64 %t806
  call void @olang_textcopy(ptr %t822, ptr %t809, i64 %t810)
  %t823 = getelementptr i8, ptr %t822, i64 %t810
  call void @olang_textcopy(ptr %t823, ptr %t812, i64 %t813)
  %t824 = getelementptr i8, ptr %t823, i64 %t813
  %t825 = call i64 @__olang_fmt_i64(ptr %t824, i64 %t799)
  %t826 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t827 = insertvalue { i64, ptr } %t826, ptr %t818, 1
  %t831 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s32, ptr %s32, ptr %v1, ptr %t796, { i64, ptr } %t827)
  store { i64, ptr } %t831, ptr %l333
  br label %bb123
bb123:
  %t832 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d453, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d453, i32 0, i32 1) }, 0
  %t834 = load { i64, ptr }, ptr %l326, !tbaa !27
  %t835 = extractvalue { i64, ptr } %t834, 1
  %t836 = extractvalue { i64, ptr } %t834, 0
  %t837 = add i64 %t833, %t836
  %t838 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d454, i32 0, i32 1) }, 1
  %t839 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d454, i32 0, i32 1) }, 0
  %t840 = add i64 %t837, %t839
  %t841 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t842 = extractvalue { i64, ptr } %t841, 1
  %t843 = extractvalue { i64, ptr } %t841, 0
  %t844 = add i64 %t840, %t843
  %t845 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t844)
  call void @olang_textcopy(ptr %t845, ptr %t832, i64 %t833)
  %t846 = getelementptr i8, ptr %t845, i64 %t833
  call void @olang_textcopy(ptr %t846, ptr %t835, i64 %t836)
  %t847 = getelementptr i8, ptr %t846, i64 %t836
  call void @olang_textcopy(ptr %t847, ptr %t838, i64 %t839)
  %t848 = getelementptr i8, ptr %t847, i64 %t839
  call void @olang_textcopy(ptr %t848, ptr %t842, i64 %t843)
  %t849 = insertvalue { i64, ptr } undef, i64 %t844, 0
  %t850 = insertvalue { i64, ptr } %t849, ptr %t845, 1
  %t852 = load ptr, ptr %l325, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s32, ptr %v1, ptr %t852, { i64, ptr } %t850)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s32)
  br label %bb125
bb125:
  %t854 = load i64, ptr %l43, !tbaa !24
  %t857 = add i64 %t854, 1
  store i64 %t857, ptr %l43, !tbaa !24
  br label %bb115
bb126:
  call void @__olang_scope_close(ptr %s29)
  br label %bb127
bb127:
  %t859 = call ptr @__olang_scope_hold(ptr %s0)
  %t860 = ptrtoint ptr %t859 to i64
  store i64 %t860, ptr %l339, !tbaa !24
  %t861 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e37
  br i1 %t861, label %bb128, label %bb129
bb128:
  %t863 = call ptr @__olang_region_make(ptr %s0)
  %t864 = ptrtoint ptr %t863 to i64
  store i64 %t864, ptr %l339, !tbaa !24
  br label %bb129
bb129:
  %t865 = load ptr, ptr %l0, !tbaa !29
  store ptr %t865, ptr %l341, !tbaa !29
  %t866 = load ptr, ptr %l0, !tbaa !29
  store ptr %t866, ptr %l342, !tbaa !29
  %t867 = load ptr, ptr %l0, !tbaa !29
  %t869 = getelementptr %"compiler/emit:fnEm", ptr %t867, i32 0, i32 0
  %t870 = load ptr, ptr %t869, !tbaa !29
  store ptr %t870, ptr %l344, !tbaa !29
  %t871 = load i64, ptr %l6, !tbaa !24
  %t872 = load i32, ptr %l2, !tbaa !23
  %t873 = load ptr, ptr %l344, !tbaa !29
  %t874 = call ptr @__olang_scope_or(ptr %v1, ptr %t873)
  %t875 = call ptr @__olang_scope_hold(ptr %t874)
  %t876 = ptrtoint ptr %t875 to i64
  %t878 = inttoptr i64 %t876 to ptr
  %t879 = load ptr, ptr %l344, !tbaa !29
  %t882 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBuf(ptr %t878, ptr %s28, ptr %t879, i64 %t871, i32 %t872)
  store { i64, ptr } %t882, ptr %l348
  br label %bb130
bb130:
  %t883 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d455, i32 0, i32 1) }, 1
  %t884 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d455, i32 0, i32 1) }, 0
  %t885 = load { i64, ptr }, ptr %l348, !tbaa !27
  %t886 = extractvalue { i64, ptr } %t885, 1
  %t887 = extractvalue { i64, ptr } %t885, 0
  %t888 = add i64 %t884, %t887
  %t889 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t888)
  call void @olang_textcopy(ptr %t889, ptr %t883, i64 %t884)
  %t890 = getelementptr i8, ptr %t889, i64 %t884
  call void @olang_textcopy(ptr %t890, ptr %t886, i64 %t887)
  %t891 = insertvalue { i64, ptr } undef, i64 %t888, 0
  %t892 = insertvalue { i64, ptr } %t891, ptr %t889, 1
  %t894 = load ptr, ptr %l342, !tbaa !29
  %t896 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s28, ptr %s28, ptr %s28, ptr %s28, ptr %v1, ptr %t894, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d456, i32 0, i32 1) }, { i64, ptr } %t892, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store { i64, ptr } %t896, ptr %l351
  br label %bb131
bb131:
  %t897 = load i64, ptr %l38, !tbaa !24
  %t898 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d457, i32 0, i32 1) }, 1
  %t899 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d457, i32 0, i32 1) }, 0
  %t900 = load { i64, ptr }, ptr %l351, !tbaa !27
  %t901 = extractvalue { i64, ptr } %t900, 1
  %t902 = extractvalue { i64, ptr } %t900, 0
  %t903 = add i64 %t899, %t902
  %t904 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d458, i32 0, i32 1) }, 1
  %t905 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d458, i32 0, i32 1) }, 0
  %t906 = add i64 %t903, %t905
  %t908 = call i64 @__olang_fmt_i64(ptr null, i64 %t897)
  %t909 = add i64 %t906, %t908
  %t910 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d459, i32 0, i32 1) }, 1
  %t911 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d459, i32 0, i32 1) }, 0
  %t912 = add i64 %t909, %t911
  %t913 = call ptr @__olang_scope_alloc(ptr %s28, i64 %t912)
  call void @olang_textcopy(ptr %t913, ptr %t898, i64 %t899)
  %t914 = getelementptr i8, ptr %t913, i64 %t899
  call void @olang_textcopy(ptr %t914, ptr %t901, i64 %t902)
  %t915 = getelementptr i8, ptr %t914, i64 %t902
  call void @olang_textcopy(ptr %t915, ptr %t904, i64 %t905)
  %t916 = getelementptr i8, ptr %t915, i64 %t905
  %t917 = call i64 @__olang_fmt_i64(ptr %t916, i64 %t897)
  %t918 = getelementptr i8, ptr %t916, i64 %t908
  call void @olang_textcopy(ptr %t918, ptr %t910, i64 %t911)
  %t919 = insertvalue { i64, ptr } undef, i64 %t912, 0
  %t920 = insertvalue { i64, ptr } %t919, ptr %t913, 1
  %t922 = load i64, ptr %l339
  %t923 = inttoptr i64 %t922 to ptr
  %t924 = load ptr, ptr %l341, !tbaa !29
  %t926 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s28, ptr %t923, ptr %v1, ptr %t924, { i64, ptr } %t920)
  store { i64, ptr } %t926, ptr %l355
  br label %bb132
bb132:
  %t927 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e37
  br i1 %t927, label %bb133, label %bb134
bb133:
  %t929 = load { i64, ptr }, ptr %l355, !tbaa !27
  %t930 = extractvalue { i64, ptr } %t929, 0
  %t932 = icmp eq i64 %t930, 0
  br i1 %t932, label %bb135, label %bb136
bb134:
  %t934 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t934, ptr %l359, !tbaa !27
  %t935 = load { i64, ptr }, ptr %l355, !tbaa !27
  store { i64, ptr } %t935, ptr %l37, !tbaa !27
  %t936 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e37
  br i1 %t936, label %bb137, label %bb138
bb135:
  store { i64, ptr } zeroinitializer, ptr %l355, !tbaa !27
  br label %bb136
bb136:
  %t938 = load i64, ptr %l339
  %t939 = inttoptr i64 %t938 to ptr
  %t940 = load { i64, ptr }, ptr %l355
  %t941 = extractvalue { i64, ptr } %t940, 1
  %t942 = call ptr @__olang_region_or(ptr %t941, ptr null)
  %t943 = icmp ne ptr %t942, null
  %t944 = select i1 %t943, ptr %t942, ptr null
  call void @__olang_region_settle_in(ptr %t939, ptr %t944)
  br label %bb134
bb137:
  %t945 = load { i64, ptr }, ptr %l359
  %t946 = extractvalue { i64, ptr } %t945, 1
  call void @__olang_region_release(ptr %t946)
  store { i64, ptr } zeroinitializer, ptr %l359
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s28)
  br label %bb139
bb139:
  %t947 = load ptr, ptr %l0, !tbaa !29
  %t949 = getelementptr %"compiler/emit:fnEm", ptr %t947, i32 0, i32 0
  %t950 = load ptr, ptr %t949, !tbaa !29
  store ptr %t950, ptr %l362, !tbaa !29
  %t951 = load ptr, ptr %l362, !tbaa !29
  %t952 = call ptr @__olang_scope_or(ptr %v1, ptr %t951)
  %t953 = call ptr @__olang_scope_hold(ptr %t952)
  %t954 = ptrtoint ptr %t953 to i64
  %t956 = inttoptr i64 %t954 to ptr
  %t957 = load ptr, ptr %l362, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %t956, ptr %s0, ptr %t957, { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d460, i32 0, i32 1) })
  br label %bb140
bb140:
  %t958 = load ptr, ptr %l0, !tbaa !29
  store ptr %t958, ptr %l364, !tbaa !29
  %t959 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t959, ptr %l365, !tbaa !27
  %t960 = load ptr, ptr %l0, !tbaa !29
  %t962 = getelementptr %"compiler/emit:fnEm", ptr %t960, i32 0, i32 0
  %t963 = load ptr, ptr %t962, !tbaa !29
  store ptr %t963, ptr %l367, !tbaa !29
  %t964 = load i32, ptr %l2, !tbaa !23
  %t965 = load ptr, ptr %l367, !tbaa !29
  %t966 = call ptr @__olang_scope_or(ptr %v1, ptr %t965)
  %t967 = call ptr @__olang_scope_hold(ptr %t966)
  %t968 = ptrtoint ptr %t967 to i64
  %t970 = inttoptr i64 %t968 to ptr
  %t971 = load ptr, ptr %l367, !tbaa !29
  %t973 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %t970, ptr %s0, ptr %t971, i32 %t964)
  store { i64, ptr } %t973, ptr %l370
  br label %bb141
bb141:
  %t974 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t975 = load i64, ptr %l27, !tbaa !24
  %t976 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t977 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t978 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d461, i32 0, i32 1) }, 1
  %t979 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d461, i32 0, i32 1) }, 0
  %t980 = load { i64, ptr }, ptr %l365, !tbaa !27
  %t981 = extractvalue { i64, ptr } %t980, 1
  %t982 = extractvalue { i64, ptr } %t980, 0
  %t983 = add i64 %t979, %t982
  %t984 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d462, i32 0, i32 1) }, 1
  %t985 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d462, i32 0, i32 1) }, 0
  %t986 = add i64 %t983, %t985
  %t987 = load { i64, ptr }, ptr %l370, !tbaa !27
  %t988 = extractvalue { i64, ptr } %t987, 1
  %t989 = extractvalue { i64, ptr } %t987, 0
  %t990 = add i64 %t986, %t989
  %t991 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t992 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t993 = add i64 %t990, %t992
  %t995 = extractvalue { i64, ptr } %t974, 1
  %t996 = extractvalue { i64, ptr } %t974, 0
  %t997 = add i64 %t993, %t996
  %t998 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t999 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t1000 = add i64 %t997, %t999
  %t1002 = call i64 @__olang_fmt_i64(ptr null, i64 %t975)
  %t1003 = add i64 %t1000, %t1002
  %t1004 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 1
  %t1005 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d463, i32 0, i32 1) }, 0
  %t1006 = add i64 %t1003, %t1005
  %t1008 = extractvalue { i64, ptr } %t976, 1
  %t1009 = extractvalue { i64, ptr } %t976, 0
  %t1010 = add i64 %t1006, %t1009
  %t1011 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 1
  %t1012 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d464, i32 0, i32 1) }, 0
  %t1013 = add i64 %t1010, %t1012
  %t1015 = extractvalue { i64, ptr } %t977, 1
  %t1016 = extractvalue { i64, ptr } %t977, 0
  %t1017 = add i64 %t1013, %t1016
  %t1018 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d465, i32 0, i32 1) }, 1
  %t1019 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d465, i32 0, i32 1) }, 0
  %t1020 = add i64 %t1017, %t1019
  %t1021 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1020)
  call void @olang_textcopy(ptr %t1021, ptr %t978, i64 %t979)
  %t1022 = getelementptr i8, ptr %t1021, i64 %t979
  call void @olang_textcopy(ptr %t1022, ptr %t981, i64 %t982)
  %t1023 = getelementptr i8, ptr %t1022, i64 %t982
  call void @olang_textcopy(ptr %t1023, ptr %t984, i64 %t985)
  %t1024 = getelementptr i8, ptr %t1023, i64 %t985
  call void @olang_textcopy(ptr %t1024, ptr %t988, i64 %t989)
  %t1025 = getelementptr i8, ptr %t1024, i64 %t989
  call void @olang_textcopy(ptr %t1025, ptr %t991, i64 %t992)
  %t1026 = getelementptr i8, ptr %t1025, i64 %t992
  call void @olang_textcopy(ptr %t1026, ptr %t995, i64 %t996)
  %t1027 = getelementptr i8, ptr %t1026, i64 %t996
  call void @olang_textcopy(ptr %t1027, ptr %t998, i64 %t999)
  %t1028 = getelementptr i8, ptr %t1027, i64 %t999
  %t1029 = call i64 @__olang_fmt_i64(ptr %t1028, i64 %t975)
  %t1030 = getelementptr i8, ptr %t1028, i64 %t1002
  call void @olang_textcopy(ptr %t1030, ptr %t1004, i64 %t1005)
  %t1031 = getelementptr i8, ptr %t1030, i64 %t1005
  call void @olang_textcopy(ptr %t1031, ptr %t1008, i64 %t1009)
  %t1032 = getelementptr i8, ptr %t1031, i64 %t1009
  call void @olang_textcopy(ptr %t1032, ptr %t1011, i64 %t1012)
  %t1033 = getelementptr i8, ptr %t1032, i64 %t1012
  call void @olang_textcopy(ptr %t1033, ptr %t1015, i64 %t1016)
  %t1034 = getelementptr i8, ptr %t1033, i64 %t1016
  call void @olang_textcopy(ptr %t1034, ptr %t1018, i64 %t1019)
  %t1035 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1036 = insertvalue { i64, ptr } %t1035, ptr %t1021, 1
  %t1038 = load ptr, ptr %l364, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t1038, { i64, ptr } %t1036)
  br label %bb142
bb142:
  %t1040 = load ptr, ptr %l0, !tbaa !29
  %t1041 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t1042 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d466, i32 0, i32 1) }, 1
  %t1043 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d466, i32 0, i32 1) }, 0
  %t1045 = extractvalue { i64, ptr } %t1041, 1
  %t1046 = extractvalue { i64, ptr } %t1041, 0
  %t1047 = add i64 %t1043, %t1046
  %t1048 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1047)
  call void @olang_textcopy(ptr %t1048, ptr %t1042, i64 %t1043)
  %t1049 = getelementptr i8, ptr %t1048, i64 %t1043
  call void @olang_textcopy(ptr %t1049, ptr %t1045, i64 %t1046)
  %t1050 = insertvalue { i64, ptr } undef, i64 %t1047, 0
  %t1051 = insertvalue { i64, ptr } %t1050, ptr %t1048, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t1040, { i64, ptr } %t1051)
  br label %bb143
bb143:
  %t1055 = load ptr, ptr %l0, !tbaa !29
  %t1056 = load { i64, ptr }, ptr %l12, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t1055, { i64, ptr } %t1056)
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2erehold(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l39 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca %"compiler/mir:ScopeInfo"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t11)
  store i64 %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load i64, ptr %l14, !tbaa !24
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb10
bb7:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l21, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb9
bb9:
  %t41 = load i64, ptr %l21, !tbaa !24
  store i64 %t41, ptr %l18, !tbaa !24
  br label %bb10
bb10:
  %t42 = load i64, ptr %l18, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l39, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t62)
  store i64 %t64, ptr %l41
  br label %bb15
bb15:
  %t65 = load i64, ptr %l41, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l39, !tbaa !29
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t71, i64 %t70)
  store i64 %t73, ptr %l45
  br label %bb16
bb16:
  %t74 = load i64, ptr %l45, !tbaa !24
  store i64 %t74, ptr %l8, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l46, !tbaa !29
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = trunc i64 %t76 to i32
  store i32 %t78, ptr %l49, !tbaa !23
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/emit:fnEm", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/mir:Fn", ptr %t83, i32 0, i32 8
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = call ptr @__olang_scope_or(ptr %v2, ptr %t87)
  %t89 = call ptr @__olang_scope_hold(ptr %t88)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t90 to ptr
  %t93 = load ptr, ptr %l52, !tbaa !29
  %t95 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t92, ptr %t93, i64 %t86)
  store %"compiler/mir:ScopeInfo" %t95, ptr %l55
  br label %bb17
bb17:
  %t96 = getelementptr %"compiler/mir:ScopeInfo", ptr %l55, i32 0, i32 0
  %t97 = load i32, ptr %t96, !range !{i32 0, i32 7}
  %t99 = trunc i64 3 to i32
  %t100 = icmp eq i32 %t97, %t99
  %t101 = load ptr, ptr %l46, !tbaa !29
  %t102 = load i32, ptr %l49, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %v3, ptr %t101, i32 %t102, i1 %t100)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t107 = add i64 %t104, 1
  store i64 %t107, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2esuspend(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2, %"compiler/mir:Range" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Range"
  %l6 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l16 = alloca { i64, [1 x i64] }
  %l17 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca i32
  %l77 = alloca i32
  %l97 = alloca ptr
  %l104 = alloca { i64, [1 x i64] }
  %l113 = alloca i1
  %l115 = alloca i1
  %l119 = alloca i1
  %l121 = alloca i1
  %l124 = alloca ptr
  %l127 = alloca %"compiler/mir:ScopeInfo"
  %l140 = alloca i64
  %l142 = alloca i64
  %l147 = alloca i64
  %l156 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l171 = alloca ptr
  %l173 = alloca { i64, ptr }
  %l180 = alloca ptr
  %l182 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [4 x i64] } %a1, ptr %l1
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l28, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/emit:fnEm", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Fn", ptr %t13, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t17 = load ptr, ptr %l28, !tbaa !29
  %t18 = call ptr @__olang_scope_or(ptr %v1, ptr %t17)
  %t19 = call ptr @__olang_scope_hold(ptr %t18)
  %t20 = ptrtoint ptr %t19 to i64
  %t22 = inttoptr i64 %t20 to ptr
  %t24 = inttoptr i64 0 to ptr
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %t22, ptr %s0, ptr %t24, ptr %t25, i32 %t16)
  store { i64, ptr } %t27, ptr %l34
  br label %bb1
bb1:
  %t28 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t28, ptr %l6, !tbaa !27
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/emit:fnEm", ptr %t29, i32 0, i32 11
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l37, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/emit:fnEm", ptr %t36, i32 0, i32 30
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d467, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d467, i32 0, i32 1) }, 0
  %t43 = extractvalue { i64, ptr } %t39, 1
  %t44 = extractvalue { i64, ptr } %t39, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d468, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d468, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t49 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t40, i64 %t41)
  %t50 = getelementptr i8, ptr %t49, i64 %t41
  call void @olang_textcopy(ptr %t50, ptr %t43, i64 %t44)
  %t51 = getelementptr i8, ptr %t50, i64 %t44
  call void @olang_textcopy(ptr %t51, ptr %t46, i64 %t47)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t49, 1
  %t57 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s1, ptr %s1, ptr %v1, ptr %t35, { i64, ptr } %t53)
  store { i64, ptr } %t57, ptr %l43
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l52, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l53, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/emit:fnEm", ptr %t61, i32 0, i32 9
  %t64 = load i32, ptr %t63, !tbaa !23
  %t67 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s3, ptr %v1, ptr %t60, i32 %t64)
  store { i64, ptr } %t67, ptr %l57
  br label %bb8
bb4:
  %t68 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t69 = load ptr, ptr %l37, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %v1, ptr %t69, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d469, i32 0, i32 1) }, { i64, ptr } %t68, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) })
  store { i64, ptr } %t71, ptr %l45
  br label %bb5
bb5:
  %t72 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/emit:fnEm", ptr %t75, i32 0, i32 9
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = load { i64, [4 x i64] }, ptr %l1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s1, ptr %s1, ptr %v1, ptr %v2, ptr %t73, { i64, ptr } %t72, i32 %t78, { i64, [4 x i64] } %t79, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d470, i32 0, i32 1) })
  br label %bb6
bb6:
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %v1, ptr %t84, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d471, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d472, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d473, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb8:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load { i64, [4 x i64] }, ptr %l1
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/emit:fnEm", ptr %t88, i32 0, i32 9
  %t91 = load i32, ptr %t90, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s3, ptr %v2, ptr %v1, ptr %t86, { i64, [4 x i64] } %t87, i32 %t91)
  store { i64, ptr } %t95, ptr %l62
  br label %bb9
bb9:
  %t96 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d474, i32 0, i32 1) }, 1
  %t97 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d474, i32 0, i32 1) }, 0
  %t98 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d475, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d475, i32 0, i32 1) }, 0
  %t104 = add i64 %t101, %t103
  %t105 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = add i64 %t104, %t107
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d476, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d476, i32 0, i32 1) }, 0
  %t111 = add i64 %t108, %t110
  %t112 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d477, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d477, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t96, i64 %t97)
  %t120 = getelementptr i8, ptr %t119, i64 %t97
  call void @olang_textcopy(ptr %t120, ptr %t99, i64 %t100)
  %t121 = getelementptr i8, ptr %t120, i64 %t100
  call void @olang_textcopy(ptr %t121, ptr %t102, i64 %t103)
  %t122 = getelementptr i8, ptr %t121, i64 %t103
  call void @olang_textcopy(ptr %t122, ptr %t106, i64 %t107)
  %t123 = getelementptr i8, ptr %t122, i64 %t107
  call void @olang_textcopy(ptr %t123, ptr %t109, i64 %t110)
  %t124 = getelementptr i8, ptr %t123, i64 %t110
  call void @olang_textcopy(ptr %t124, ptr %t113, i64 %t114)
  %t125 = getelementptr i8, ptr %t124, i64 %t114
  call void @olang_textcopy(ptr %t125, ptr %t116, i64 %t117)
  %t126 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t119, 1
  %t129 = load ptr, ptr %l52, !tbaa !29
  %t131 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s3, ptr %s3, ptr %v1, ptr %t129, { i64, ptr } %t127)
  store { i64, ptr } %t131, ptr %l65
  br label %bb10
bb10:
  %t132 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s0, ptr %s3, ptr %s3, ptr %s3, ptr %v1, ptr %t133, { i64, ptr } %t134, { i64, ptr } %t132, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d478, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t139 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l69
  br label %bb13
bb13:
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %l9
  store i32 0, ptr %l10, !tbaa !23
  %t141 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t142 = load i32, ptr %t141, !tbaa !23
  store i32 %t142, ptr %l11, !tbaa !23
  store i32 1, ptr %l12, !tbaa !23
  %t144 = load i32, ptr %l11, !tbaa !23
  %t145 = load i32, ptr %l10, !tbaa !23
  %t148 = icmp sgt i32 %t144, %t145
  br i1 %t148, label %bb14, label %bb15
bb14:
  %t150 = load i32, ptr %l12, !tbaa !23
  %t152 = icmp sgt i32 %t150, 0
  br i1 %t152, label %bb16, label %bb17
bb15:
  store i32 0, ptr %l74, !tbaa !23
  br label %bb19
bb16:
  %t154 = load i32, ptr %l11, !tbaa !23
  %t155 = load i32, ptr %l10, !tbaa !23
  %t158 = sub i32 %t154, %t155
  %t159 = load i32, ptr %l12, !tbaa !23
  %t162 = add i32 %t158, %t159
  %t164 = sub i32 %t162, 1
  %t165 = load i32, ptr %l12, !tbaa !23
  %t168 = sdiv i32 %t164, %t165
  store i32 %t168, ptr %l77, !tbaa !23
  br label %bb18
bb17:
  store i32 0, ptr %l77, !tbaa !23
  br label %bb18
bb18:
  %t170 = load i32, ptr %l77, !tbaa !23
  store i32 %t170, ptr %l74, !tbaa !23
  br label %bb19
bb19:
  %t171 = load i32, ptr %l74, !tbaa !23
  store i32 %t171, ptr %l13, !tbaa !23
  store i32 0, ptr %l14, !tbaa !23
  br label %bb20
bb20:
  %t172 = load i32, ptr %l14, !tbaa !23
  %t173 = load i32, ptr %l13, !tbaa !23
  %t176 = icmp slt i32 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb21, label %bb22
bb21:
  br label %bb48
bb22:
  br label %bb23
bb23:
  %t180 = load i32, ptr %l10, !tbaa !23
  %t181 = load i32, ptr %l14, !tbaa !23
  %t182 = load i32, ptr %l12, !tbaa !23
  %t185 = mul i32 %t181, %t182
  %t188 = add i32 %t180, %t185
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/emit:fnEm", ptr %t190, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = getelementptr %"compiler/mir:Fn", ptr %t193, i32 0, i32 12
  store ptr %t195, ptr %l97, !tbaa !29
  %t196 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t197 = load i32, ptr %t196, !tbaa !23
  %t199 = sext i32 %t197 to i64
  %t202 = sext i32 %t188 to i64
  %t205 = add i64 %t199, %t202
  %t206 = load ptr, ptr %l97, !tbaa !29
  %t207 = call ptr @__olang_scope_or(ptr %v2, ptr %t206)
  %t208 = call ptr @__olang_scope_hold(ptr %t207)
  %t209 = ptrtoint ptr %t208 to i64
  %t211 = inttoptr i64 %t209 to ptr
  %t212 = load ptr, ptr %l97, !tbaa !29
  %t214 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %t211, ptr %t212, i64 %t205)
  store { i64, [1 x i64] } %t214, ptr %l104
  br label %bb24
bb24:
  %t215 = load { i64, [1 x i64] }, ptr %l104
  store { i64, [1 x i64] } %t215, ptr %l16
  %t216 = load { i64, [1 x i64] }, ptr %l16
  %t218 = extractvalue { i64, [1 x i64] } %t216, 0
  %t219 = icmp eq i64 %t218, 0
  br i1 %t219, label %bb25, label %bb26
bb25:
  %t221 = getelementptr { i64, [1 x i64] }, ptr %l16, i32 0, i32 1
  %t222 = getelementptr { i32 }, ptr %t221, i32 0, i32 0
  %t223 = load i32, ptr %t222
  store i32 %t223, ptr %l17, !tbaa !23
  br label %bb27
bb26:
  br label %bb41
bb27:
  %t225 = load i32, ptr %l17, !tbaa !23
  %t227 = sext i32 %t225 to i64
  store i64 %t227, ptr %l18, !tbaa !24
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = getelementptr %"compiler/emit:fnEm", ptr %t229, i32 0, i32 26
  %t232 = load i64, ptr %l18, !tbaa !24
  %t235 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t231, i64 %t232)
  store i1 %t235, ptr %l113
  br label %bb28
bb28:
  %t236 = load i1, ptr %l113, !tbaa !21
  %t237 = xor i1 %t236, true
  br i1 %t237, label %bb29, label %bb30
bb29:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/emit:fnEm", ptr %t239, i32 0, i32 25
  %t242 = load i64, ptr %l18, !tbaa !24
  %t245 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t241, i64 %t242)
  store i1 %t245, ptr %l119
  br label %bb31
bb30:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb32
bb31:
  %t246 = load i1, ptr %l119, !tbaa !21
  %t247 = xor i1 %t246, true
  store i1 %t247, ptr %l115, !tbaa !21
  br label %bb32
bb32:
  %t249 = load i1, ptr %l115, !tbaa !21
  br i1 %t249, label %bb33, label %bb34
bb33:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/emit:fnEm", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/mir:Fn", ptr %t253, i32 0, i32 8
  store ptr %t255, ptr %l124, !tbaa !29
  %t256 = load i64, ptr %l18, !tbaa !24
  %t257 = load ptr, ptr %l124, !tbaa !29
  %t258 = call ptr @__olang_scope_or(ptr %v2, ptr %t257)
  %t259 = call ptr @__olang_scope_hold(ptr %t258)
  %t260 = ptrtoint ptr %t259 to i64
  %t262 = inttoptr i64 %t260 to ptr
  %t263 = load ptr, ptr %l124, !tbaa !29
  %t265 = call %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %t262, ptr %t263, i64 %t256)
  store %"compiler/mir:ScopeInfo" %t265, ptr %l127
  br label %bb35
bb34:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb36
bb35:
  %t266 = getelementptr %"compiler/mir:ScopeInfo", ptr %l127, i32 0, i32 0
  %t267 = load i32, ptr %t266, !range !{i32 0, i32 7}
  %t269 = trunc i64 6 to i32
  %t270 = icmp eq i32 %t267, %t269
  %t272 = xor i1 %t270, true
  store i1 %t272, ptr %l121, !tbaa !21
  br label %bb36
bb36:
  %t274 = load i1, ptr %l121, !tbaa !21
  br i1 %t274, label %bb37, label %bb38
bb37:
  %t275 = load i64, ptr %l18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l9, i64 %t275)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_97d51a883f8cc986_4828fb3e43690a82)
  unreachable
bb46:
  br label %bb47
bb47:
  %t278 = load i32, ptr %l14, !tbaa !23
  %t281 = add i32 %t278, 1
  store i32 %t281, ptr %l14, !tbaa !23
  br label %bb20
bb48:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/emit:fnEm", ptr %t283, i32 0, i32 0
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t288 = getelementptr %"compiler/emit:Emitter", ptr %t286, i32 0, i32 4
  %t289 = load i1, ptr %t288, !tbaa !21
  br i1 %t289, label %bb49, label %bb50
bb49:
  store ptr %l9, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb51
bb50:
  br label %bb60
bb51:
  %t292 = load i64, ptr %l20, !tbaa !24
  store i64 %t292, ptr %l140, !tbaa !24
  %t293 = load ptr, ptr %l19, !tbaa !29
  %t295 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t293)
  store i64 %t295, ptr %l142
  br label %bb52
bb52:
  %t296 = load i64, ptr %l140, !tbaa !24
  %t297 = load i64, ptr %l142, !tbaa !24
  %t298 = icmp slt i64 %t296, %t297
  %t300 = xor i1 %t298, true
  br i1 %t300, label %bb53, label %bb54
bb53:
  br label %bb59
bb54:
  br label %bb55
bb55:
  %t302 = load ptr, ptr %l19, !tbaa !29
  %t303 = load i64, ptr %l20, !tbaa !24
  %t306 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t302, i64 %t303)
  store i64 %t306, ptr %l147
  br label %bb56
bb56:
  %t307 = load i64, ptr %l147, !tbaa !24
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t311 = trunc i64 %t307 to i32
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %v1, ptr %t308, i32 %t311)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t315 = load i64, ptr %l20, !tbaa !24
  %t318 = add i64 %t315, 1
  store i64 %t318, ptr %l20, !tbaa !24
  br label %bb51
bb59:
  br label %bb60
bb60:
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t320, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d479, i32 0, i32 1) })
  store { i64, ptr } %t322, ptr %l156
  br label %bb61
bb61:
  %t323 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t323, ptr %l22, !tbaa !27
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t324, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d480, i32 0, i32 1) })
  store { i64, ptr } %t326, ptr %l158
  br label %bb62
bb62:
  %t327 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t327, ptr %l23, !tbaa !27
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %s0, ptr %s0, ptr %t328, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d481, i32 0, i32 1) })
  store { i64, ptr } %t330, ptr %l160
  br label %bb63
bb63:
  %t331 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t331, ptr %l24, !tbaa !27
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t336 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d482, i32 0, i32 1) }, 1
  %t337 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d482, i32 0, i32 1) }, 0
  %t339 = extractvalue { i64, ptr } %t333, 1
  %t340 = extractvalue { i64, ptr } %t333, 0
  %t341 = add i64 %t337, %t340
  %t342 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d483, i32 0, i32 1) }, 1
  %t343 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d483, i32 0, i32 1) }, 0
  %t344 = add i64 %t341, %t343
  %t346 = extractvalue { i64, ptr } %t334, 1
  %t347 = extractvalue { i64, ptr } %t334, 0
  %t348 = add i64 %t344, %t347
  %t349 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d484, i32 0, i32 1) }, 1
  %t350 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d484, i32 0, i32 1) }, 0
  %t351 = add i64 %t348, %t350
  %t353 = extractvalue { i64, ptr } %t335, 1
  %t354 = extractvalue { i64, ptr } %t335, 0
  %t355 = add i64 %t351, %t354
  %t356 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d485, i32 0, i32 1) }, 1
  %t357 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d485, i32 0, i32 1) }, 0
  %t358 = add i64 %t355, %t357
  %t359 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t358)
  call void @olang_textcopy(ptr %t359, ptr %t336, i64 %t337)
  %t360 = getelementptr i8, ptr %t359, i64 %t337
  call void @olang_textcopy(ptr %t360, ptr %t339, i64 %t340)
  %t361 = getelementptr i8, ptr %t360, i64 %t340
  call void @olang_textcopy(ptr %t361, ptr %t342, i64 %t343)
  %t362 = getelementptr i8, ptr %t361, i64 %t343
  call void @olang_textcopy(ptr %t362, ptr %t346, i64 %t347)
  %t363 = getelementptr i8, ptr %t362, i64 %t347
  call void @olang_textcopy(ptr %t363, ptr %t349, i64 %t350)
  %t364 = getelementptr i8, ptr %t363, i64 %t350
  call void @olang_textcopy(ptr %t364, ptr %t353, i64 %t354)
  %t365 = getelementptr i8, ptr %t364, i64 %t354
  call void @olang_textcopy(ptr %t365, ptr %t356, i64 %t357)
  %t366 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t359, 1
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t332, { i64, ptr } %t367)
  br label %bb64
bb64:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t372 = load { i64, ptr }, ptr %l23, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t371, { i64, ptr } %t372)
  br label %bb65
bb65:
  %t375 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2erehold(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t375, ptr %l9)
  br label %bb66
bb66:
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l171, !tbaa !29
  %t381 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %a2)
  store { i64, ptr } %t381, ptr %l173
  br label %bb67
bb67:
  %t382 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d486, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d486, i32 0, i32 1) }, 0
  %t384 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t385 = extractvalue { i64, ptr } %t384, 1
  %t386 = extractvalue { i64, ptr } %t384, 0
  %t387 = add i64 %t383, %t386
  %t388 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t382, i64 %t383)
  %t389 = getelementptr i8, ptr %t388, i64 %t383
  call void @olang_textcopy(ptr %t389, ptr %t385, i64 %t386)
  %t390 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t388, 1
  %t393 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t393, { i64, ptr } %t391)
  br label %bb68
bb68:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %s0, ptr %t395, { i64, ptr } %t396)
  br label %bb69
bb69:
  %t399 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2erehold(ptr %v0, ptr %s0, ptr %v2, ptr %v1, ptr %t399, ptr %l9)
  br label %bb70
bb70:
  %t402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t402, ptr %l180, !tbaa !29
  %t405 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s0, i32 %a4)
  store { i64, ptr } %t405, ptr %l182
  br label %bb71
bb71:
  %t406 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d487, i32 0, i32 1) }, 1
  %t407 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d487, i32 0, i32 1) }, 0
  %t408 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t408, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = add i64 %t407, %t410
  %t412 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t411)
  call void @olang_textcopy(ptr %t412, ptr %t406, i64 %t407)
  %t413 = getelementptr i8, ptr %t412, i64 %t407
  call void @olang_textcopy(ptr %t413, ptr %t409, i64 %t410)
  %t414 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t412, 1
  %t417 = load ptr, ptr %l180, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s0, ptr %v1, ptr %t417, { i64, ptr } %t415)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCopies(ptr %v0, ptr %v1, ptr %v2, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l24 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca %"compiler/mir:BasicBlock"
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l70 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l99 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca { i64, [1 x i64] }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 29
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d488, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t6, ptr %l17, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l18, !tbaa !24
  %t9 = load i64, ptr %l18, !tbaa !24
  %t10 = mul i64 %t9, 1
  %t11 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l19, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = mul i64 %t18, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t15, ptr %t17, i64 %t19, i1 false)
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l17, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t21, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i1 false, ptr %l1, !tbaa !21
  store i64 0, ptr %l2, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/emit:fnEm", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/mir:Fn", ptr %t25, i32 0, i32 9
  store ptr %t27, ptr %l22, !tbaa !29
  %t28 = load ptr, ptr %l22, !tbaa !29
  %t29 = call ptr @__olang_scope_or(ptr %v2, ptr %t28)
  %t30 = call ptr @__olang_scope_hold(ptr %t29)
  %t31 = ptrtoint ptr %t30 to i64
  %t33 = inttoptr i64 %t31 to ptr
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t33, ptr %t34)
  store i64 %t35, ptr %l24
  br label %bb4
bb4:
  %t36 = load i64, ptr %l24, !tbaa !24
  store i64 %t36, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb5, label %bb6
bb5:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb10
bb7:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l2, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l4, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l31, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb9
bb9:
  %t63 = load i64, ptr %l31, !tbaa !24
  store i64 %t63, ptr %l28, !tbaa !24
  br label %bb10
bb10:
  %t64 = load i64, ptr %l28, !tbaa !24
  store i64 %t64, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load i64, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l4, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/emit:fnEm", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/mir:Fn", ptr %t86, i32 0, i32 9
  store ptr %t88, ptr %l51, !tbaa !29
  %t90 = load ptr, ptr %l51, !tbaa !29
  %t91 = call ptr @__olang_scope_or(ptr %v2, ptr %t90)
  %t92 = call ptr @__olang_scope_hold(ptr %t91)
  %t93 = ptrtoint ptr %t92 to i64
  %t95 = inttoptr i64 %t93 to ptr
  %t96 = load ptr, ptr %l51, !tbaa !29
  %t98 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %t95, ptr %s3, ptr %t96, i64 %t81)
  store %"compiler/mir:BasicBlock" %t98, ptr %l54
  br label %bb15
bb15:
  %t99 = getelementptr %"compiler/mir:BasicBlock", ptr %l54, i32 0, i32 1
  %t100 = load { i64, [8 x i64] }, ptr %t99
  %t102 = extractvalue { i64, [8 x i64] } %t100, 0
  %t103 = icmp eq i64 %t102, 6
  br i1 %t103, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t105 = load i64, ptr %l6, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  %t110 = load i1, ptr %l1, !tbaa !21
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d489, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t114 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t114, ptr %l63, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l64, !tbaa !24
  %t117 = load i64, ptr %l64, !tbaa !24
  %t118 = mul i64 %t117, 1
  %t119 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t118)
  %t120 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t119, 1
  store { i64, ptr } %t121, ptr %l65, !tbaa !27
  %t122 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = load i64, ptr %l64, !tbaa !24
  %t127 = mul i64 %t126, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t123, ptr %t125, i64 %t127, i1 false)
  %t128 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t128, ptr %l63, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t129, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l8, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/emit:fnEm", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/mir:Fn", ptr %t133, i32 0, i32 6
  store ptr %t135, ptr %l68, !tbaa !29
  %t136 = load ptr, ptr %l68, !tbaa !29
  %t137 = call ptr @__olang_scope_or(ptr %v2, ptr %t136)
  %t138 = call ptr @__olang_scope_hold(ptr %t137)
  %t139 = ptrtoint ptr %t138 to i64
  %t141 = inttoptr i64 %t139 to ptr
  %t142 = load ptr, ptr %l68, !tbaa !29
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %t141, ptr %t142)
  store i64 %t143, ptr %l70
  br label %bb24
bb24:
  %t144 = load i64, ptr %l70, !tbaa !24
  store i64 %t144, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l8, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb25, label %bb26
bb25:
  %t151 = load i64, ptr %l10, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb30
bb27:
  %t155 = load i64, ptr %l9, !tbaa !24
  %t156 = load i64, ptr %l8, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l10, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l77, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb29
bb29:
  %t171 = load i64, ptr %l77, !tbaa !24
  store i64 %t171, ptr %l74, !tbaa !24
  br label %bb30
bb30:
  %t172 = load i64, ptr %l74, !tbaa !24
  store i64 %t172, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb31
bb31:
  %t173 = load i64, ptr %l12, !tbaa !24
  %t174 = load i64, ptr %l11, !tbaa !24
  %t177 = icmp slt i64 %t173, %t174
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb32, label %bb33
bb32:
  br label %bb43
bb33:
  br label %bb34
bb34:
  %t181 = load i64, ptr %l8, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  %t183 = load i64, ptr %l10, !tbaa !24
  %t186 = mul i64 %t182, %t183
  %t189 = add i64 %t181, %t186
  store i64 %t189, ptr %l13, !tbaa !24
  %t191 = load i64, ptr %l13, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/emit:fnEm", ptr %t192, i32 0, i32 7
  %t195 = load i64, ptr %t194, !tbaa !24
  %t198 = icmp slt i64 %t191, %t195
  br i1 %t198, label %bb35, label %bb36
bb35:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/emit:fnEm", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/mir:Fn", ptr %t203, i32 0, i32 6
  store ptr %t205, ptr %l102, !tbaa !29
  %t206 = load i64, ptr %l13, !tbaa !24
  %t207 = load ptr, ptr %l102, !tbaa !29
  %t208 = call ptr @__olang_scope_or(ptr %v2, ptr %t207)
  %t209 = call ptr @__olang_scope_hold(ptr %t208)
  %t210 = ptrtoint ptr %t209 to i64
  %t212 = inttoptr i64 %t210 to ptr
  %t213 = load ptr, ptr %l102, !tbaa !29
  %t215 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %t212, ptr %t213, i64 %t206)
  store { i64, [1 x i64] } %t215, ptr %l105
  br label %bb37
bb36:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb38
bb37:
  %t216 = load { i64, [1 x i64] }, ptr %l105
  %t218 = extractvalue { i64, [1 x i64] } %t216, 0
  %t219 = icmp eq i64 %t218, 1
  store i1 %t219, ptr %l99, !tbaa !21
  br label %bb38
bb38:
  %t221 = load i1, ptr %l99, !tbaa !21
  br i1 %t221, label %bb39, label %bb40
bb39:
  %t222 = load i64, ptr %l13, !tbaa !24
  %t223 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d490, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d490, i32 0, i32 1) }, 0
  %t226 = call i64 @__olang_fmt_i64(ptr null, i64 %t222)
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t223, i64 %t224)
  %t229 = getelementptr i8, ptr %t228, i64 %t224
  %t230 = call i64 @__olang_fmt_i64(ptr %t229, i64 %t222)
  %t231 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t232 = insertvalue { i64, ptr } %t231, ptr %t228, 1
  store { i64, ptr } %t232, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t234 = load i64, ptr %l12, !tbaa !24
  %t237 = add i64 %t234, 1
  store i64 %t237, ptr %l12, !tbaa !24
  br label %bb31
bb43:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d491, i32 0, i32 1) }, ptr %l113, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t239, ptr %l114, !tbaa !27
  %t240 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  store i64 %t241, ptr %l115, !tbaa !24
  %t242 = load i64, ptr %l115, !tbaa !24
  %t243 = mul i64 %t242, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t243)
  %t245 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  store { i64, ptr } %t246, ptr %l116, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t250 = load ptr, ptr %t249, !tbaa !27
  %t251 = load i64, ptr %l115, !tbaa !24
  %t252 = mul i64 %t251, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t248, ptr %t250, i64 %t252, i1 false)
  %t253 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t253, ptr %l114, !tbaa !27
  %t254 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t254, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskEnds(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/mir:Task"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, [4 x i64] }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, [4 x i64] }
  %l17 = alloca i32
  %l20 = alloca ptr
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca i64
  %l58 = alloca ptr
  %l64 = alloca { i64, [4 x i64] }
  %l69 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l80 = alloca { i64, [4 x i64] }
  %l84 = alloca i64
  %l88 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %a3, i64 144, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  store ptr %t6, ptr %l20, !tbaa !29
  %t7 = load ptr, ptr %l20, !tbaa !29
  %t8 = call ptr @__olang_scope_or(ptr %v3, ptr %t7)
  %t9 = call ptr @__olang_scope_hold(ptr %t8)
  %t10 = ptrtoint ptr %t9 to i64
  %t12 = inttoptr i64 %t10 to ptr
  %t13 = load ptr, ptr %l20, !tbaa !29
  %t14 = call i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %t12, ptr %t13)
  store i1 %t14, ptr %l22
  br label %bb1
bb1:
  %t15 = load i1, ptr %l22, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d492, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb4
bb3:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d493, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t16, ptr %l5, !tbaa !27
  %t17 = load ptr, ptr %l4, !tbaa !29
  store ptr %t17, ptr %l24, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t20 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d494, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d494, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %t19, 1
  %t24 = extractvalue { i64, ptr } %t19, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d495, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d495, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = load ptr, ptr %l24, !tbaa !29
  %t36 = call ptr @__olang_scope_or(ptr %v3, ptr %t35)
  %t37 = call ptr @__olang_scope_hold(ptr %t36)
  %t38 = ptrtoint ptr %t37 to i64
  %t40 = inttoptr i64 %t38 to ptr
  %t41 = load ptr, ptr @__olang_prog_scope
  %t42 = load ptr, ptr %l24, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t40, ptr %t41, ptr %s0, ptr %t42, { i64, ptr } %t18, { i64, ptr } %t33)
  br label %bb5
bb5:
  store i64 0, ptr %l6, !tbaa !24
  %t45 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t46 = getelementptr %"compiler/mir:Range", ptr %t45, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = sext i32 %t47 to i64
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 2, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb6, label %bb7
bb6:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb11
bb8:
  %t61 = load i64, ptr %l7, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l38, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb10
bb10:
  %t77 = load i64, ptr %l38, !tbaa !24
  store i64 %t77, ptr %l35, !tbaa !24
  br label %bb11
bb11:
  %t78 = load i64, ptr %l35, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb14:
  br label %bb15
bb15:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/emit:fnEm", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/mir:Fn", ptr %t100, i32 0, i32 11
  store ptr %t102, ptr %l58, !tbaa !29
  %t103 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t104 = getelementptr %"compiler/mir:Range", ptr %t103, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = sext i32 %t105 to i64
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t112 = load ptr, ptr %l58, !tbaa !29
  %t113 = call ptr @__olang_scope_or(ptr %v4, ptr %t112)
  %t114 = call ptr @__olang_scope_hold(ptr %t113)
  %t115 = ptrtoint ptr %t114 to i64
  %t117 = inttoptr i64 %t115 to ptr
  %t118 = load ptr, ptr %l58, !tbaa !29
  %t120 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t117, ptr %t118, i64 %t111)
  store { i64, [4 x i64] } %t120, ptr %l64
  br label %bb16
bb16:
  %t121 = load { i64, [4 x i64] }, ptr %l64
  store { i64, [4 x i64] } %t121, ptr %l13
  %t122 = load { i64, [4 x i64] }, ptr %l13
  %t124 = extractvalue { i64, [4 x i64] } %t122, 0
  %t125 = icmp eq i64 %t124, 2
  br i1 %t125, label %bb17, label %bb18
bb17:
  %t127 = getelementptr { i64, [4 x i64] }, ptr %l13, i32 0, i32 1
  %t128 = getelementptr { i32, i64 }, ptr %t127, i32 0, i32 1
  %t129 = load i64, ptr %t128
  store i64 %t129, ptr %l14, !tbaa !24
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t131 = load i64, ptr %l14, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_a013fd5d1a1a0ecb_8946a3e4bb7adef)
  unreachable
bb25:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d496, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t133, ptr %l15, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/emit:fnEm", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/mir:Fn", ptr %t138, i32 0, i32 11
  store ptr %t140, ptr %l73, !tbaa !29
  %t141 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 5
  %t142 = getelementptr %"compiler/mir:Range", ptr %t141, i32 0, i32 0
  %t143 = load i32, ptr %t142, !tbaa !23
  %t145 = sext i32 %t143 to i64
  %t146 = load i64, ptr %l11, !tbaa !24
  %t149 = add i64 %t145, %t146
  %t151 = add i64 %t149, 1
  %t152 = load ptr, ptr %l73, !tbaa !29
  %t153 = call ptr @__olang_scope_or(ptr %v4, ptr %t152)
  %t154 = call ptr @__olang_scope_hold(ptr %t153)
  %t155 = ptrtoint ptr %t154 to i64
  %t157 = inttoptr i64 %t155 to ptr
  %t158 = load ptr, ptr %l73, !tbaa !29
  %t160 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %t157, ptr %t158, i64 %t151)
  store { i64, [4 x i64] } %t160, ptr %l80
  br label %bb26
bb26:
  %t161 = load { i64, [4 x i64] }, ptr %l80
  store { i64, [4 x i64] } %t161, ptr %l16
  %t162 = load { i64, [4 x i64] }, ptr %l16
  %t164 = extractvalue { i64, [4 x i64] } %t162, 0
  %t165 = icmp eq i64 %t164, 3
  br i1 %t165, label %bb27, label %bb28
bb27:
  %t167 = getelementptr { i64, [4 x i64] }, ptr %l16, i32 0, i32 1
  %t168 = getelementptr { i32, i32, i64, %"compiler/source:Span" }, ptr %t167, i32 0, i32 1
  %t169 = load i32, ptr %t168
  store i32 %t169, ptr %l17, !tbaa !23
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t171 = call ptr @__olang_scope_hold(ptr %s3)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l84, !tbaa !24
  %t173 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etaskEnds_2elocal_2e15
  br i1 %t173, label %bb30, label %bb31
bb30:
  %t175 = call ptr @__olang_region_make(ptr %s3)
  %t176 = ptrtoint ptr %t175 to i64
  store i64 %t176, ptr %l84, !tbaa !24
  br label %bb31
bb31:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l17, !tbaa !23
  %t179 = load i64, ptr %l84
  %t180 = inttoptr i64 %t179 to ptr
  %t183 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %t180, ptr %v4, ptr %t177, i32 %t178)
  store { i64, ptr } %t183, ptr %l88
  br label %bb32
bb32:
  %t184 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etaskEnds_2elocal_2e15
  br i1 %t184, label %bb33, label %bb34
bb33:
  %t186 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t189 = icmp eq i64 %t187, 0
  br i1 %t189, label %bb35, label %bb36
bb34:
  %t191 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t191, ptr %l92, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t192, ptr %l15, !tbaa !27
  %t193 = load i1, ptr @olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etaskEnds_2elocal_2e15
  br i1 %t193, label %bb37, label %bb38
bb35:
  store { i64, ptr } zeroinitializer, ptr %l88, !tbaa !27
  br label %bb36
bb36:
  %t195 = load i64, ptr %l84
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = load { i64, ptr }, ptr %l88
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = call ptr @__olang_region_or(ptr %t198, ptr null)
  %t200 = icmp ne ptr %t199, null
  %t201 = select i1 %t200, ptr %t199, ptr null
  call void @__olang_region_settle_in(ptr %t196, ptr %t201)
  br label %bb34
bb37:
  %t202 = load { i64, ptr }, ptr %l92
  %t203 = extractvalue { i64, ptr } %t202, 1
  call void @__olang_region_release(ptr %t203)
  store { i64, ptr } zeroinitializer, ptr %l92
  br label %bb38
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_625291c18633ca8a_b2d4e63a7cb7312e)
  unreachable
bb44:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = load i64, ptr %l12, !tbaa !24
  %t208 = load i64, ptr %l11, !tbaa !24
  %t209 = load i64, ptr %l11, !tbaa !24
  %t210 = load i64, ptr %l11, !tbaa !24
  %t211 = load i64, ptr %l11, !tbaa !24
  %t212 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d497, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d497, i32 0, i32 1) }, 0
  %t215 = call i64 @__olang_fmt_i64(ptr null, i64 %t205)
  %t216 = add i64 %t213, %t215
  %t217 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d498, i32 0, i32 1) }, 1
  %t218 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d498, i32 0, i32 1) }, 0
  %t219 = add i64 %t216, %t218
  %t221 = extractvalue { i64, ptr } %a2, 1
  %t222 = extractvalue { i64, ptr } %a2, 0
  %t223 = add i64 %t219, %t222
  %t224 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d499, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d499, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t228 = call i64 @__olang_fmt_i64(ptr null, i64 %t207)
  %t229 = add i64 %t226, %t228
  %t230 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d500, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d500, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t234 = call i64 @__olang_fmt_i64(ptr null, i64 %t208)
  %t235 = add i64 %t232, %t234
  %t236 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d501, i32 0, i32 1) }, 1
  %t237 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d501, i32 0, i32 1) }, 0
  %t238 = add i64 %t235, %t237
  %t240 = call i64 @__olang_fmt_i64(ptr null, i64 %t209)
  %t241 = add i64 %t238, %t240
  %t242 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d502, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d502, i32 0, i32 1) }, 0
  %t244 = add i64 %t241, %t243
  %t246 = call i64 @__olang_fmt_i64(ptr null, i64 %t210)
  %t247 = add i64 %t244, %t246
  %t248 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d503, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d503, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t252 = call i64 @__olang_fmt_i64(ptr null, i64 %t211)
  %t253 = add i64 %t250, %t252
  %t254 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d504, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t212, i64 %t213)
  %t258 = getelementptr i8, ptr %t257, i64 %t213
  %t259 = call i64 @__olang_fmt_i64(ptr %t258, i64 %t205)
  %t260 = getelementptr i8, ptr %t258, i64 %t215
  call void @olang_textcopy(ptr %t260, ptr %t217, i64 %t218)
  %t261 = getelementptr i8, ptr %t260, i64 %t218
  call void @olang_textcopy(ptr %t261, ptr %t221, i64 %t222)
  %t262 = getelementptr i8, ptr %t261, i64 %t222
  call void @olang_textcopy(ptr %t262, ptr %t224, i64 %t225)
  %t263 = getelementptr i8, ptr %t262, i64 %t225
  %t264 = call i64 @__olang_fmt_i64(ptr %t263, i64 %t207)
  %t265 = getelementptr i8, ptr %t263, i64 %t228
  call void @olang_textcopy(ptr %t265, ptr %t230, i64 %t231)
  %t266 = getelementptr i8, ptr %t265, i64 %t231
  %t267 = call i64 @__olang_fmt_i64(ptr %t266, i64 %t208)
  %t268 = getelementptr i8, ptr %t266, i64 %t234
  call void @olang_textcopy(ptr %t268, ptr %t236, i64 %t237)
  %t269 = getelementptr i8, ptr %t268, i64 %t237
  %t270 = call i64 @__olang_fmt_i64(ptr %t269, i64 %t209)
  %t271 = getelementptr i8, ptr %t269, i64 %t240
  call void @olang_textcopy(ptr %t271, ptr %t242, i64 %t243)
  %t272 = getelementptr i8, ptr %t271, i64 %t243
  %t273 = call i64 @__olang_fmt_i64(ptr %t272, i64 %t210)
  %t274 = getelementptr i8, ptr %t272, i64 %t246
  call void @olang_textcopy(ptr %t274, ptr %t248, i64 %t249)
  %t275 = getelementptr i8, ptr %t274, i64 %t249
  %t276 = call i64 @__olang_fmt_i64(ptr %t275, i64 %t211)
  %t277 = getelementptr i8, ptr %t275, i64 %t252
  call void @olang_textcopy(ptr %t277, ptr %t254, i64 %t255)
  %t278 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t257, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t204, { i64, ptr } %t279)
  br label %bb45
bb45:
  %t283 = load ptr, ptr %l1, !tbaa !29
  store ptr %t283, ptr %l104, !tbaa !29
  %t284 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t284, ptr %l105, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 6
  %t287 = load %"compiler/source:Span", ptr %t286
  %t288 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t289 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d505, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d505, i32 0, i32 1) }, 0
  %t292 = extractvalue { i64, ptr } %t288, 1
  %t293 = extractvalue { i64, ptr } %t288, 0
  %t294 = add i64 %t290, %t293
  %t295 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d506, i32 0, i32 1) }, 1
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d506, i32 0, i32 1) }, 0
  %t297 = add i64 %t294, %t296
  %t298 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t297)
  call void @olang_textcopy(ptr %t298, ptr %t289, i64 %t290)
  %t299 = getelementptr i8, ptr %t298, i64 %t290
  call void @olang_textcopy(ptr %t299, ptr %t292, i64 %t293)
  %t300 = getelementptr i8, ptr %t299, i64 %t293
  call void @olang_textcopy(ptr %t300, ptr %t295, i64 %t296)
  %t301 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t298, 1
  %t307 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s3, ptr %s3, ptr %v3, ptr %t285, %"compiler/source:Span" %t287, { i64, ptr } %t302, i1 false)
  store { i64, ptr } %t307, ptr %l111
  br label %bb46
bb46:
  %t308 = load i64, ptr %l11, !tbaa !24
  %t309 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d507, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d507, i32 0, i32 1) }, 0
  %t311 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t312 = extractvalue { i64, ptr } %t311, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = add i64 %t310, %t313
  %t315 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d508, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d508, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t318 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t318, 1
  %t320 = extractvalue { i64, ptr } %t318, 0
  %t321 = add i64 %t317, %t320
  %t322 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d509, i32 0, i32 1) }, 1
  %t323 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d509, i32 0, i32 1) }, 0
  %t324 = add i64 %t321, %t323
  %t326 = call i64 @__olang_fmt_i64(ptr null, i64 %t308)
  %t327 = add i64 %t324, %t326
  %t328 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d510, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d510, i32 0, i32 1) }, 0
  %t330 = add i64 %t327, %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t330)
  call void @olang_textcopy(ptr %t331, ptr %t309, i64 %t310)
  %t332 = getelementptr i8, ptr %t331, i64 %t310
  call void @olang_textcopy(ptr %t332, ptr %t312, i64 %t313)
  %t333 = getelementptr i8, ptr %t332, i64 %t313
  call void @olang_textcopy(ptr %t333, ptr %t315, i64 %t316)
  %t334 = getelementptr i8, ptr %t333, i64 %t316
  call void @olang_textcopy(ptr %t334, ptr %t319, i64 %t320)
  %t335 = getelementptr i8, ptr %t334, i64 %t320
  call void @olang_textcopy(ptr %t335, ptr %t322, i64 %t323)
  %t336 = getelementptr i8, ptr %t335, i64 %t323
  %t337 = call i64 @__olang_fmt_i64(ptr %t336, i64 %t308)
  %t338 = getelementptr i8, ptr %t336, i64 %t326
  call void @olang_textcopy(ptr %t338, ptr %t328, i64 %t329)
  %t339 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t331, 1
  %t342 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t342, { i64, ptr } %t340)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb48:
  %t344 = load i64, ptr %l10, !tbaa !24
  %t347 = add i64 %t344, 1
  store i64 %t347, ptr %l10, !tbaa !24
  br label %bb12
bb49:
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l118, !tbaa !29
  %t350 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t350, ptr %l119, !tbaa !27
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/mir:Task", ptr %l3, i32 0, i32 6
  %t353 = load %"compiler/source:Span", ptr %t352
  %t356 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocated(ptr %v0, ptr %s0, ptr %s0, ptr %v3, ptr %t351, %"compiler/source:Span" %t353, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d511, i32 0, i32 1) }, i1 false)
  store { i64, ptr } %t356, ptr %l122
  br label %bb50
bb50:
  %t357 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d512, i32 0, i32 1) }, 1
  %t358 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d512, i32 0, i32 1) }, 0
  %t359 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = add i64 %t358, %t361
  %t363 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d513, i32 0, i32 1) }, 1
  %t364 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d513, i32 0, i32 1) }, 0
  %t365 = add i64 %t362, %t364
  %t366 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t367 = extractvalue { i64, ptr } %t366, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = add i64 %t365, %t368
  %t370 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d514, i32 0, i32 1) }, 1
  %t371 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d514, i32 0, i32 1) }, 0
  %t372 = add i64 %t369, %t371
  %t373 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t372)
  call void @olang_textcopy(ptr %t373, ptr %t357, i64 %t358)
  %t374 = getelementptr i8, ptr %t373, i64 %t358
  call void @olang_textcopy(ptr %t374, ptr %t360, i64 %t361)
  %t375 = getelementptr i8, ptr %t374, i64 %t361
  call void @olang_textcopy(ptr %t375, ptr %t363, i64 %t364)
  %t376 = getelementptr i8, ptr %t375, i64 %t364
  call void @olang_textcopy(ptr %t376, ptr %t367, i64 %t368)
  %t377 = getelementptr i8, ptr %t376, i64 %t368
  call void @olang_textcopy(ptr %t377, ptr %t370, i64 %t371)
  %t378 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t373, 1
  %t381 = load ptr, ptr %l118, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t381, { i64, ptr } %t379)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskOld(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l2 = alloca %"compiler/mir:Task"
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l36 = alloca %"compiler/mir:Task"
  %l39 = alloca i1
  %s2 = alloca %olang.scope
  %t56 = alloca %"compiler/mir:Task", align 8
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %a2, i64 144, i1 false)
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l4, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Task", ptr %l2, i32 0, i32 3
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 1
  %t3 = load i32, ptr %t2, !tbaa !23
  store i32 %t3, ptr %l5, !tbaa !23
  store i32 1, ptr %l6, !tbaa !23
  %t5 = load i32, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l4, !tbaa !23
  %t9 = icmp sgt i32 %t5, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t13 = icmp sgt i32 %t11, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l14, !tbaa !23
  br label %bb6
bb3:
  %t15 = load i32, ptr %l5, !tbaa !23
  %t16 = load i32, ptr %l4, !tbaa !23
  %t19 = sub i32 %t15, %t16
  %t20 = load i32, ptr %l6, !tbaa !23
  %t23 = add i32 %t19, %t20
  %t25 = sub i32 %t23, 1
  %t26 = load i32, ptr %l6, !tbaa !23
  %t29 = sdiv i32 %t25, %t26
  store i32 %t29, ptr %l17, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l17, !tbaa !23
  br label %bb5
bb5:
  %t31 = load i32, ptr %l17, !tbaa !23
  store i32 %t31, ptr %l14, !tbaa !23
  br label %bb6
bb6:
  %t32 = load i32, ptr %l14, !tbaa !23
  store i32 %t32, ptr %l7, !tbaa !23
  store i32 0, ptr %l8, !tbaa !23
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load i32, ptr %l8, !tbaa !23
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = icmp slt i32 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t41 = load i32, ptr %l4, !tbaa !23
  %t42 = load i32, ptr %l8, !tbaa !23
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = mul i32 %t42, %t43
  %t49 = add i32 %t41, %t46
  store i32 %t49, ptr %l9, !tbaa !23
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %l2, i64 144, i1 false)
  %t52 = load i32, ptr %l9, !tbaa !23
  %t54 = sext i32 %t52 to i64
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %l36, i64 144, i1 false)
  %t58 = call i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %v2, ptr %v3, ptr %a0, ptr %t56, i64 %t54)
  store i1 %t58, ptr %l39
  br label %bb11
bb11:
  %t59 = load i1, ptr %l39, !tbaa !21
  %t60 = xor i1 %t59, true
  br i1 %t60, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t63 = load i32, ptr %l9, !tbaa !23
  %t65 = load i32, ptr %l9, !tbaa !23
  %t67 = sext i32 %t65 to i64
  %t70 = add i64 %a3, %t67
  %t71 = load i32, ptr %l9, !tbaa !23
  %t72 = load i32, ptr %l9, !tbaa !23
  %t73 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d515, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d515, i32 0, i32 1) }, 0
  %t76 = sext i32 %t63 to i64
  %t77 = call i64 @__olang_fmt_i64(ptr null, i64 %t76)
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d516, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d516, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t83 = call i64 @__olang_fmt_i64(ptr null, i64 %t70)
  %t84 = add i64 %t81, %t83
  %t85 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d517, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d517, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t89 = sext i32 %t71 to i64
  %t90 = call i64 @__olang_fmt_i64(ptr null, i64 %t89)
  %t91 = add i64 %t87, %t90
  %t92 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d518, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d518, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t96 = sext i32 %t72 to i64
  %t97 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d519, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d519, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t73, i64 %t74)
  %t103 = getelementptr i8, ptr %t102, i64 %t74
  %t104 = call i64 @__olang_fmt_i64(ptr %t103, i64 %t76)
  %t105 = getelementptr i8, ptr %t103, i64 %t77
  call void @olang_textcopy(ptr %t105, ptr %t79, i64 %t80)
  %t106 = getelementptr i8, ptr %t105, i64 %t80
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t70)
  %t108 = getelementptr i8, ptr %t106, i64 %t83
  call void @olang_textcopy(ptr %t108, ptr %t85, i64 %t86)
  %t109 = getelementptr i8, ptr %t108, i64 %t86
  %t110 = call i64 @__olang_fmt_i64(ptr %t109, i64 %t89)
  %t111 = getelementptr i8, ptr %t109, i64 %t90
  call void @olang_textcopy(ptr %t111, ptr %t92, i64 %t93)
  %t112 = getelementptr i8, ptr %t111, i64 %t93
  %t113 = call i64 @__olang_fmt_i64(ptr %t112, i64 %t96)
  %t114 = getelementptr i8, ptr %t112, i64 %t97
  call void @olang_textcopy(ptr %t114, ptr %t99, i64 %t100)
  %t115 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t102, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %a1, { i64, ptr } %t116)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t120 = load i32, ptr %l8, !tbaa !23
  %t123 = add i32 %t120, 1
  store i32 %t123, ptr %l8, !tbaa !23
  br label %bb7
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2femit_2ecompiler_2femit_3afnEm_2eterm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, [4 x i64] }
  %l8 = alloca %"compiler/mir:Range"
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l20 = alloca %"compiler/mir:Case"
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca { i64, [4 x i64] }
  %l24 = alloca { i64, ptr }
  %l26 = alloca { i64, [4 x i64] }
  %l27 = alloca i32
  %l28 = alloca %"compiler/mir:Range"
  %l29 = alloca i32
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, [4 x i64] }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca { i64, [4 x i64] }
  %l51 = alloca ptr
  %l53 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l88 = alloca i32
  %l91 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca %"std/prelude/text:StringBuilder"
  %l97 = alloca ptr
  %l98 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l108 = alloca i32
  %l111 = alloca i32
  %l131 = alloca ptr
  %l138 = alloca %"compiler/mir:Case"
  %l139 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l146 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l157 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l168 = alloca ptr
  %l172 = alloca %"compiler/mir:Call"
  %l179 = alloca ptr
  %l182 = alloca ptr
  %l186 = alloca %"compiler/mir:Call"
  %l190 = alloca ptr
  %l196 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l214 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l226 = alloca { i64, ptr }
  %l231 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l268 = alloca { i64, ptr }
  %l272 = alloca { i64, ptr }
  %l274 = alloca i1
  %l277 = alloca ptr
  %l278 = alloca { i64, ptr }
  %l284 = alloca { i64, ptr }
  %l296 = alloca i1
  %l301 = alloca ptr
  %l303 = alloca ptr
  %l304 = alloca i32
  %l306 = alloca { i64, ptr }
  %l309 = alloca { i64, ptr }
  %l313 = alloca ptr
  %l315 = alloca { i64, ptr }
  %l322 = alloca { i64, ptr }
  %l326 = alloca ptr
  %l327 = alloca { i64, ptr }
  %l330 = alloca { i64, ptr }
  %l336 = alloca { i64, ptr }
  %l337 = alloca ptr
  %l338 = alloca { i64, ptr }
  %l340 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s41 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/emit:fnEm", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/emit:Emitter", ptr %t4, i32 0, i32 3
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/emit:fnEm", ptr %t9, i32 0, i32 18
  %t12 = load i64, ptr %t11, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l51, !tbaa !29
  %t17 = load { i64, [8 x i64] }, ptr %l1
  %t19 = call %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [8 x i64] } %t17)
  store %"compiler/source:Span" %t19, ptr %l53
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l51, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l53
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %v1, ptr %v2, ptr %t20, %"compiler/source:Span" %t21)
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, [8 x i64] }, ptr %l1
  %t24 = extractvalue { i64, [8 x i64] } %t22, 0
  %t25 = icmp eq i64 %t24, 0
  br i1 %t25, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s2, ptr %v1, ptr %t27, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d520, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb159
bb10:
  %t29 = load { i64, [8 x i64] }, ptr %l1
  %t31 = extractvalue { i64, [8 x i64] } %t29, 0
  %t32 = icmp eq i64 %t31, 1
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t35 = getelementptr { i32 }, ptr %t34, i32 0, i32 0
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb16
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l60, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t41 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s3, i32 %t39)
  store { i64, ptr } %t41, ptr %l62
  br label %bb14
bb14:
  %t42 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d521, i32 0, i32 1) }, 1
  %t43 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d521, i32 0, i32 1) }, 0
  %t44 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = add i64 %t43, %t46
  %t48 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t42, i64 %t43)
  %t49 = getelementptr i8, ptr %t48, i64 %t43
  call void @olang_textcopy(ptr %t49, ptr %t45, i64 %t46)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  %t53 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s3, ptr %v1, ptr %t53, { i64, ptr } %t51)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb159
bb16:
  %t55 = load { i64, [8 x i64] }, ptr %l1
  %t57 = extractvalue { i64, [8 x i64] } %t55, 0
  %t58 = icmp eq i64 %t57, 2
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t61 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t60, i32 0, i32 0
  %t62 = load { i64, [4 x i64] }, ptr %t61
  store { i64, [4 x i64] } %t62, ptr %l4
  %t64 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t65 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t64, i32 0, i32 1
  %t66 = load i32, ptr %t65
  store i32 %t66, ptr %l5, !tbaa !23
  %t68 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t69 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t68, i32 0, i32 2
  %t70 = load i32, ptr %t69
  store i32 %t70, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l70, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, [4 x i64] }, ptr %l4
  %t75 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s5, ptr %v2, ptr %v1, ptr %t73, { i64, [4 x i64] } %t74, i32 %t75)
  store { i64, ptr } %t79, ptr %l74
  br label %bb20
bb20:
  %t80 = load i32, ptr %l5, !tbaa !23
  %t82 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t80)
  store { i64, ptr } %t82, ptr %l76
  br label %bb21
bb21:
  %t83 = load i32, ptr %l6, !tbaa !23
  %t85 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s5, i32 %t83)
  store { i64, ptr } %t85, ptr %l78
  br label %bb22
bb22:
  %t86 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d522, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d522, i32 0, i32 1) }, 0
  %t88 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t93 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  %t94 = add i64 %t91, %t93
  %t95 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = add i64 %t94, %t97
  %t99 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 1
  %t100 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d523, i32 0, i32 1) }, 0
  %t101 = add i64 %t98, %t100
  %t102 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = add i64 %t101, %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t105)
  call void @olang_textcopy(ptr %t106, ptr %t86, i64 %t87)
  %t107 = getelementptr i8, ptr %t106, i64 %t87
  call void @olang_textcopy(ptr %t107, ptr %t89, i64 %t90)
  %t108 = getelementptr i8, ptr %t107, i64 %t90
  call void @olang_textcopy(ptr %t108, ptr %t92, i64 %t93)
  %t109 = getelementptr i8, ptr %t108, i64 %t93
  call void @olang_textcopy(ptr %t109, ptr %t96, i64 %t97)
  %t110 = getelementptr i8, ptr %t109, i64 %t97
  call void @olang_textcopy(ptr %t110, ptr %t99, i64 %t100)
  %t111 = getelementptr i8, ptr %t110, i64 %t100
  call void @olang_textcopy(ptr %t111, ptr %t103, i64 %t104)
  %t112 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t106, 1
  %t115 = load ptr, ptr %l70, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s5, ptr %v1, ptr %t115, { i64, ptr } %t113)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb159
bb24:
  %t117 = load { i64, [8 x i64] }, ptr %l1
  %t119 = extractvalue { i64, [8 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 3
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t122 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t123 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t122, i32 0, i32 0
  %t124 = load { i64, [4 x i64] }, ptr %t123
  store { i64, [4 x i64] } %t124, ptr %l7
  %t126 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t127 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t126, i32 0, i32 1
  %t128 = load %"compiler/mir:Range", ptr %t127
  store %"compiler/mir:Range" %t128, ptr %l8
  %t130 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t131 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t130, i32 0, i32 2
  %t132 = load i32, ptr %t131
  store i32 %t132, ptr %l9, !tbaa !23
  br label %bb27
bb26:
  br label %bb53
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load { i64, [4 x i64] }, ptr %l7
  %t138 = call i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v2, ptr %v1, ptr %t134, { i64, [4 x i64] } %t135)
  store i32 %t138, ptr %l88
  br label %bb28
bb28:
  %t139 = load i32, ptr %l88, !tbaa !23
  store i32 %t139, ptr %l10, !tbaa !23
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l10, !tbaa !23
  %t144 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s7, ptr %v1, ptr %t140, i32 %t141)
  store { i64, ptr } %t144, ptr %l91
  br label %bb29
bb29:
  %t145 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t145, ptr %l11, !tbaa !27
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load { i64, [4 x i64] }, ptr %l7
  %t148 = load i32, ptr %l10, !tbaa !23
  %t152 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s7, ptr %v2, ptr %v1, ptr %t146, { i64, [4 x i64] } %t147, i32 %t148)
  store { i64, ptr } %t152, ptr %l95
  br label %bb30
bb30:
  %t153 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t153, ptr %l12, !tbaa !27
  %t154 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s7)
  store %"std/prelude/text:StringBuilder" %t154, ptr %l96
  br label %bb31
bb31:
  %t155 = load %"std/prelude/text:StringBuilder", ptr %l96
  store %"std/prelude/text:StringBuilder" %t155, ptr %l13
  store ptr %l13, ptr %l97, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t156, ptr %l98, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t157, ptr %l99, !tbaa !27
  %t158 = load i32, ptr %l9, !tbaa !23
  %t160 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s7, i32 %t158)
  store { i64, ptr } %t160, ptr %l101
  br label %bb32
bb32:
  %t161 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d524, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d524, i32 0, i32 1) }, 0
  %t163 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = add i64 %t162, %t165
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d525, i32 0, i32 1) }, 1
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d525, i32 0, i32 1) }, 0
  %t169 = add i64 %t166, %t168
  %t170 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = add i64 %t169, %t172
  %t174 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d526, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d526, i32 0, i32 1) }, 0
  %t176 = add i64 %t173, %t175
  %t177 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = add i64 %t176, %t179
  %t181 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d527, i32 0, i32 1) }, 1
  %t182 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d527, i32 0, i32 1) }, 0
  %t183 = add i64 %t180, %t182
  %t184 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t183)
  call void @olang_textcopy(ptr %t184, ptr %t161, i64 %t162)
  %t185 = getelementptr i8, ptr %t184, i64 %t162
  call void @olang_textcopy(ptr %t185, ptr %t164, i64 %t165)
  %t186 = getelementptr i8, ptr %t185, i64 %t165
  call void @olang_textcopy(ptr %t186, ptr %t167, i64 %t168)
  %t187 = getelementptr i8, ptr %t186, i64 %t168
  call void @olang_textcopy(ptr %t187, ptr %t171, i64 %t172)
  %t188 = getelementptr i8, ptr %t187, i64 %t172
  call void @olang_textcopy(ptr %t188, ptr %t174, i64 %t175)
  %t189 = getelementptr i8, ptr %t188, i64 %t175
  call void @olang_textcopy(ptr %t189, ptr %t178, i64 %t179)
  %t190 = getelementptr i8, ptr %t189, i64 %t179
  call void @olang_textcopy(ptr %t190, ptr %t181, i64 %t182)
  %t191 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t184, 1
  %t194 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %t194, { i64, ptr } %t192)
  br label %bb33
bb33:
  store i32 0, ptr %l14, !tbaa !23
  %t196 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 1
  %t197 = load i32, ptr %t196, !tbaa !23
  store i32 %t197, ptr %l15, !tbaa !23
  store i32 1, ptr %l16, !tbaa !23
  %t199 = load i32, ptr %l15, !tbaa !23
  %t200 = load i32, ptr %l14, !tbaa !23
  %t203 = icmp sgt i32 %t199, %t200
  br i1 %t203, label %bb34, label %bb35
bb34:
  %t205 = load i32, ptr %l16, !tbaa !23
  %t207 = icmp sgt i32 %t205, 0
  br i1 %t207, label %bb36, label %bb37
bb35:
  store i32 0, ptr %l108, !tbaa !23
  br label %bb39
bb36:
  %t209 = load i32, ptr %l15, !tbaa !23
  %t210 = load i32, ptr %l14, !tbaa !23
  %t213 = sub i32 %t209, %t210
  %t214 = load i32, ptr %l16, !tbaa !23
  %t217 = add i32 %t213, %t214
  %t219 = sub i32 %t217, 1
  %t220 = load i32, ptr %l16, !tbaa !23
  %t223 = sdiv i32 %t219, %t220
  store i32 %t223, ptr %l111, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l111, !tbaa !23
  br label %bb38
bb38:
  %t225 = load i32, ptr %l111, !tbaa !23
  store i32 %t225, ptr %l108, !tbaa !23
  br label %bb39
bb39:
  %t226 = load i32, ptr %l108, !tbaa !23
  store i32 %t226, ptr %l17, !tbaa !23
  store i32 0, ptr %l18, !tbaa !23
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s10
  %t227 = load i32, ptr %l18, !tbaa !23
  %t228 = load i32, ptr %l17, !tbaa !23
  %t231 = icmp slt i32 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb42:
  br label %bb43
bb43:
  %t235 = load i32, ptr %l14, !tbaa !23
  %t236 = load i32, ptr %l18, !tbaa !23
  %t237 = load i32, ptr %l16, !tbaa !23
  %t240 = mul i32 %t236, %t237
  %t243 = add i32 %t235, %t240
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/emit:fnEm", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/mir:Fn", ptr %t248, i32 0, i32 15
  store ptr %t250, ptr %l131, !tbaa !29
  %t251 = getelementptr %"compiler/mir:Range", ptr %l8, i32 0, i32 0
  %t252 = load i32, ptr %t251, !tbaa !23
  %t254 = sext i32 %t252 to i64
  %t257 = sext i32 %t243 to i64
  %t260 = add i64 %t254, %t257
  %t261 = load ptr, ptr %l131, !tbaa !29
  %t262 = call ptr @__olang_scope_or(ptr %v2, ptr %t261)
  %t263 = call ptr @__olang_scope_hold(ptr %t262)
  %t264 = ptrtoint ptr %t263 to i64
  %t266 = inttoptr i64 %t264 to ptr
  %t267 = load ptr, ptr %l131, !tbaa !29
  %t269 = call %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %t266, ptr %t267, i64 %t260)
  store %"compiler/mir:Case" %t269, ptr %l138
  br label %bb44
bb44:
  %t270 = load %"compiler/mir:Case", ptr %l138
  store %"compiler/mir:Case" %t270, ptr %l20
  store ptr %l13, ptr %l139, !tbaa !29
  %t271 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t271, ptr %l140, !tbaa !27
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/emit:fnEm", ptr %t272, i32 0, i32 0
  %t275 = load ptr, ptr %t274, !tbaa !29
  store ptr %t275, ptr %l142, !tbaa !29
  %t276 = load i32, ptr %l10, !tbaa !23
  %t277 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 0
  %t278 = load i64, ptr %t277, !tbaa !24
  %t279 = load ptr, ptr %l142, !tbaa !29
  %t280 = call ptr @__olang_scope_or(ptr %v1, ptr %t279)
  %t281 = call ptr @__olang_scope_hold(ptr %t280)
  %t282 = ptrtoint ptr %t281 to i64
  %t284 = inttoptr i64 %t282 to ptr
  %t285 = load ptr, ptr %l142, !tbaa !29
  %t288 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %t284, ptr %s10, ptr %t285, i32 %t276, i64 %t278)
  store { i64, ptr } %t288, ptr %l146
  br label %bb45
bb45:
  %t289 = getelementptr %"compiler/mir:Case", ptr %l20, i32 0, i32 1
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s10, i32 %t290)
  store { i64, ptr } %t292, ptr %l148
  br label %bb46
bb46:
  %t293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t295 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  %t298 = add i64 %t294, %t297
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 1
  %t300 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d528, i32 0, i32 1) }, 0
  %t301 = add i64 %t298, %t300
  %t302 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 1
  %t304 = extractvalue { i64, ptr } %t302, 0
  %t305 = add i64 %t301, %t304
  %t306 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d529, i32 0, i32 1) }, 1
  %t307 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d529, i32 0, i32 1) }, 0
  %t308 = add i64 %t305, %t307
  %t309 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 1
  %t311 = extractvalue { i64, ptr } %t309, 0
  %t312 = add i64 %t308, %t311
  %t313 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t312)
  call void @olang_textcopy(ptr %t313, ptr %t293, i64 %t294)
  %t314 = getelementptr i8, ptr %t313, i64 %t294
  call void @olang_textcopy(ptr %t314, ptr %t296, i64 %t297)
  %t315 = getelementptr i8, ptr %t314, i64 %t297
  call void @olang_textcopy(ptr %t315, ptr %t299, i64 %t300)
  %t316 = getelementptr i8, ptr %t315, i64 %t300
  call void @olang_textcopy(ptr %t316, ptr %t303, i64 %t304)
  %t317 = getelementptr i8, ptr %t316, i64 %t304
  call void @olang_textcopy(ptr %t317, ptr %t306, i64 %t307)
  %t318 = getelementptr i8, ptr %t317, i64 %t307
  call void @olang_textcopy(ptr %t318, ptr %t310, i64 %t311)
  %t319 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t313, 1
  %t322 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s10, ptr %t322, { i64, ptr } %t320)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb48:
  %t324 = load i32, ptr %l18, !tbaa !23
  %t327 = add i32 %t324, 1
  store i32 %t327, ptr %l18, !tbaa !23
  br label %bb40
bb49:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s7, ptr %s7, ptr %l13, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d530, i32 0, i32 1) })
  br label %bb50
bb50:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l155, !tbaa !29
  %t332 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s7, ptr %s7, ptr %l13)
  store { i64, ptr } %t332, ptr %l157
  br label %bb51
bb51:
  %t333 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t334 = load ptr, ptr %l155, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s7, ptr %v1, ptr %t334, { i64, ptr } %t333)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s7)
  br label %bb159
bb53:
  %t336 = load { i64, [8 x i64] }, ptr %l1
  %t338 = extractvalue { i64, [8 x i64] } %t336, 0
  %t339 = icmp eq i64 %t338, 4
  br i1 %t339, label %bb54, label %bb55
bb54:
  %t341 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", i32 }, ptr %t341, i32 0, i32 1
  %t343 = load i32, ptr %t342
  store i32 %t343, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i32, ptr %l21, !tbaa !23
  %t348 = sext i32 %t346 to i64
  %t351 = getelementptr %"compiler/emit:fnEm", ptr %t345, i32 0, i32 39
  store i64 %t348, ptr %t351, !tbaa !24
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l165, !tbaa !29
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t355 = getelementptr %"compiler/emit:fnEm", ptr %t353, i32 0, i32 1
  %t356 = load ptr, ptr %t355, !tbaa !29
  %t358 = getelementptr %"compiler/mir:Fn", ptr %t356, i32 0, i32 14
  store ptr %t358, ptr %l168, !tbaa !29
  %t359 = load i32, ptr %l21, !tbaa !23
  %t361 = sext i32 %t359 to i64
  %t362 = load ptr, ptr %l168, !tbaa !29
  %t363 = call ptr @__olang_scope_or(ptr %v2, ptr %t362)
  %t364 = call ptr @__olang_scope_hold(ptr %t363)
  %t365 = ptrtoint ptr %t364 to i64
  %t367 = inttoptr i64 %t365 to ptr
  %t368 = load ptr, ptr %l168, !tbaa !29
  %t370 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t367, ptr %t368, i64 %t361)
  store %"compiler/mir:Call" %t370, ptr %l172
  br label %bb57
bb57:
  %t371 = load ptr, ptr %l165, !tbaa !29
  %t372 = load %"compiler/mir:Call", ptr %l172
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %t371, %"compiler/mir:Call" %t372)
  br label %bb58
bb58:
  br label %bb159
bb59:
  %t373 = load { i64, [8 x i64] }, ptr %l1
  %t375 = extractvalue { i64, [8 x i64] } %t373, 0
  %t376 = icmp eq i64 %t375, 6
  br i1 %t376, label %bb60, label %bb61
bb60:
  %t378 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t379 = getelementptr { %"compiler/source:Span", i32 }, ptr %t378, i32 0, i32 1
  %t380 = load i32, ptr %t379
  store i32 %t380, ptr %l22, !tbaa !23
  br label %bb62
bb61:
  br label %bb65
bb62:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load i32, ptr %l22, !tbaa !23
  %t385 = sext i32 %t383 to i64
  %t388 = getelementptr %"compiler/emit:fnEm", ptr %t382, i32 0, i32 39
  store i64 %t385, ptr %t388, !tbaa !24
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l179, !tbaa !29
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/emit:fnEm", ptr %t390, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/mir:Fn", ptr %t393, i32 0, i32 14
  store ptr %t395, ptr %l182, !tbaa !29
  %t396 = load i32, ptr %l22, !tbaa !23
  %t398 = sext i32 %t396 to i64
  %t399 = load ptr, ptr %l182, !tbaa !29
  %t400 = call ptr @__olang_scope_or(ptr %v2, ptr %t399)
  %t401 = call ptr @__olang_scope_hold(ptr %t400)
  %t402 = ptrtoint ptr %t401 to i64
  %t404 = inttoptr i64 %t402 to ptr
  %t405 = load ptr, ptr %l182, !tbaa !29
  %t407 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %t404, ptr %t405, i64 %t398)
  store %"compiler/mir:Call" %t407, ptr %l186
  br label %bb63
bb63:
  %t408 = load ptr, ptr %l179, !tbaa !29
  %t409 = load %"compiler/mir:Call", ptr %l186
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCall(ptr %v0, ptr %v1, ptr %v2, ptr %t408, %"compiler/mir:Call" %t409)
  br label %bb64
bb64:
  br label %bb159
bb65:
  %t410 = load { i64, [8 x i64] }, ptr %l1
  %t412 = extractvalue { i64, [8 x i64] } %t410, 0
  %t413 = icmp eq i64 %t412, 5
  br i1 %t413, label %bb66, label %bb67
bb66:
  %t415 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t416 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t415, i32 0, i32 1
  %t417 = load { i64, [4 x i64] }, ptr %t416
  store { i64, [4 x i64] } %t417, ptr %l23
  br label %bb68
bb67:
  br label %bb96
bb68:
  store %olang.scope zeroinitializer, ptr %s15
  %t419 = load ptr, ptr %l2, !tbaa !29
  store ptr %t419, ptr %l190, !tbaa !29
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/emit:fnEm", ptr %t420, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !29
  %t425 = getelementptr %"compiler/mir:Fn", ptr %t423, i32 0, i32 1
  %t426 = load i32, ptr %t425, !tbaa !23
  %t427 = load ptr, ptr %l190, !tbaa !29
  %t428 = call ptr @__olang_scope_or(ptr %v1, ptr %t427)
  %t429 = call ptr @__olang_scope_hold(ptr %t428)
  %t430 = ptrtoint ptr %t429 to i64
  %t432 = inttoptr i64 %t430 to ptr
  %t434 = inttoptr i64 0 to ptr
  %t435 = load ptr, ptr %l190, !tbaa !29
  %t437 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %t432, ptr %s15, ptr %t434, ptr %t435, i32 %t426)
  store { i64, ptr } %t437, ptr %l196
  br label %bb69
bb69:
  %t438 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t438, ptr %l24, !tbaa !27
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/emit:fnEm", ptr %t439, i32 0, i32 11
  %t442 = load i1, ptr %t441, !tbaa !21
  br i1 %t442, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/emit:fnEm", ptr %t445, i32 0, i32 9
  %t448 = load i32, ptr %t447, !tbaa !23
  %t449 = load { i64, [4 x i64] }, ptr %l23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %s16, ptr %s16, ptr %v1, ptr %v2, ptr %t444, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d531, i32 0, i32 1) }, i32 %t448, { i64, [4 x i64] } %t449, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d470, i32 0, i32 1) })
  br label %bb72
bb71:
  %t453 = load ptr, ptr %l0, !tbaa !29
  %t455 = getelementptr %"compiler/emit:fnEm", ptr %t453, i32 0, i32 10
  %t456 = load i1, ptr %t455, !tbaa !21
  br i1 %t456, label %bb77, label %bb78
bb72:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/emit:fnEm", ptr %t458, i32 0, i32 10
  %t461 = load i1, ptr %t460, !tbaa !21
  br i1 %t461, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s17
  %t463 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s17, ptr %s17, ptr %s17, ptr %s17, ptr %v1, ptr %t463, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d532, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d533, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d534, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s17)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s16)
  br label %bb94
bb77:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/emit:fnEm", ptr %t465, i32 0, i32 9
  %t468 = load i32, ptr %t467, !tbaa !23
  %t469 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t472 = icmp eq i32 %t468, %t469
  br i1 %t472, label %bb79, label %bb80
bb78:
  store %olang.scope zeroinitializer, ptr %s23
  %t474 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t476 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s15, ptr %s23, { i64, ptr } %t474, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d535, i32 0, i32 1) })
  store i1 %t476, ptr %l231
  br label %bb87
bb79:
  store %olang.scope zeroinitializer, ptr %s20
  %t477 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s20, ptr %s20, ptr %s20, ptr %s20, ptr %v1, ptr %t477, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d536, i32 0, i32 1) }, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d537, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d538, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s21
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l213, !tbaa !29
  %t480 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t480, ptr %l214, !tbaa !27
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/emit:fnEm", ptr %t482, i32 0, i32 9
  %t485 = load i32, ptr %t484, !tbaa !23
  %t488 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %s21, ptr %v1, ptr %t481, i32 %t485)
  store { i64, ptr } %t488, ptr %l218
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s20)
  br label %bb86
bb82:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load { i64, [4 x i64] }, ptr %l23
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/emit:fnEm", ptr %t491, i32 0, i32 9
  %t494 = load i32, ptr %t493, !tbaa !23
  %t498 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s21, ptr %v2, ptr %v1, ptr %t489, { i64, [4 x i64] } %t490, i32 %t494)
  store { i64, ptr } %t498, ptr %l223
  br label %bb83
bb83:
  %t499 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d539, i32 0, i32 1) }, 1
  %t500 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d539, i32 0, i32 1) }, 0
  %t501 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = add i64 %t500, %t503
  %t505 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d540, i32 0, i32 1) }, 1
  %t506 = extractvalue { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d540, i32 0, i32 1) }, 0
  %t507 = add i64 %t504, %t506
  %t508 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t509 = extractvalue { i64, ptr } %t508, 1
  %t510 = extractvalue { i64, ptr } %t508, 0
  %t511 = add i64 %t507, %t510
  %t512 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d541, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d541, i32 0, i32 1) }, 0
  %t514 = add i64 %t511, %t513
  %t515 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t516 = extractvalue { i64, ptr } %t515, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  %t518 = add i64 %t514, %t517
  %t519 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d542, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d542, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t522 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t521)
  call void @olang_textcopy(ptr %t522, ptr %t499, i64 %t500)
  %t523 = getelementptr i8, ptr %t522, i64 %t500
  call void @olang_textcopy(ptr %t523, ptr %t502, i64 %t503)
  %t524 = getelementptr i8, ptr %t523, i64 %t503
  call void @olang_textcopy(ptr %t524, ptr %t505, i64 %t506)
  %t525 = getelementptr i8, ptr %t524, i64 %t506
  call void @olang_textcopy(ptr %t525, ptr %t509, i64 %t510)
  %t526 = getelementptr i8, ptr %t525, i64 %t510
  call void @olang_textcopy(ptr %t526, ptr %t512, i64 %t513)
  %t527 = getelementptr i8, ptr %t526, i64 %t513
  call void @olang_textcopy(ptr %t527, ptr %t516, i64 %t517)
  %t528 = getelementptr i8, ptr %t527, i64 %t517
  call void @olang_textcopy(ptr %t528, ptr %t519, i64 %t520)
  %t529 = insertvalue { i64, ptr } undef, i64 %t521, 0
  %t530 = insertvalue { i64, ptr } %t529, ptr %t522, 1
  %t532 = load ptr, ptr %l213, !tbaa !29
  %t534 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s21, ptr %s21, ptr %v1, ptr %t532, { i64, ptr } %t530)
  store { i64, ptr } %t534, ptr %l226
  br label %bb84
bb84:
  %t535 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s15, ptr %s21, ptr %s21, ptr %s21, ptr %v1, ptr %t536, { i64, ptr } %t537, { i64, ptr } %t535, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d543, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s21)
  br label %bb86
bb86:
  br label %bb93
bb87:
  %t542 = load i1, ptr %l231, !tbaa !21
  %t543 = xor i1 %t542, true
  br i1 %t543, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s24
  %t545 = load ptr, ptr %l0, !tbaa !29
  store ptr %t545, ptr %l233, !tbaa !29
  %t546 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t546, ptr %l234, !tbaa !27
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load { i64, [4 x i64] }, ptr %l23
  %t549 = load ptr, ptr %l0, !tbaa !29
  %t551 = getelementptr %"compiler/emit:fnEm", ptr %t549, i32 0, i32 9
  %t552 = load i32, ptr %t551, !tbaa !23
  %t556 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s24, ptr %v2, ptr %v1, ptr %t547, { i64, [4 x i64] } %t548, i32 %t552)
  store { i64, ptr } %t556, ptr %l239
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t557 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t558 = load ptr, ptr %l233, !tbaa !29
  %t559 = load { i64, ptr }, ptr %l234, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s15, ptr %s24, ptr %s24, ptr %s24, ptr %v1, ptr %t558, { i64, ptr } %t559, { i64, ptr } %t557, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d544, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s24)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s23)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t561 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s15, ptr %v1, ptr %t561, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d545, i32 0, i32 1) })
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb159
bb96:
  %t563 = load { i64, [8 x i64] }, ptr %l1
  %t565 = extractvalue { i64, [8 x i64] } %t563, 0
  %t566 = icmp eq i64 %t565, 11
  br i1 %t566, label %bb97, label %bb98
bb97:
  %t568 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t569 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t568, i32 0, i32 1
  %t570 = load { i64, [4 x i64] }, ptr %t569
  store { i64, [4 x i64] } %t570, ptr %l26
  %t572 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t573 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t572, i32 0, i32 2
  %t574 = load i32, ptr %t573
  store i32 %t574, ptr %l27, !tbaa !23
  %t576 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t577 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t576, i32 0, i32 3
  %t578 = load %"compiler/mir:Range", ptr %t577
  store %"compiler/mir:Range" %t578, ptr %l28
  %t580 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t581 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range", i32 }, ptr %t580, i32 0, i32 4
  %t582 = load i32, ptr %t581
  store i32 %t582, ptr %l29, !tbaa !23
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load { i64, [4 x i64] }, ptr %l26
  %t586 = load i32, ptr %l27, !tbaa !23
  %t587 = load %"compiler/mir:Range", ptr %l28
  %t588 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2esuspend(ptr %v0, ptr %v1, ptr %v2, ptr %t584, { i64, [4 x i64] } %t585, i32 %t586, %"compiler/mir:Range" %t587, i32 %t588)
  br label %bb100
bb100:
  br label %bb159
bb101:
  %t594 = load { i64, [8 x i64] }, ptr %l1
  %t596 = extractvalue { i64, [8 x i64] } %t594, 0
  %t597 = icmp eq i64 %t596, 12
  br i1 %t597, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb106
bb104:
  store %olang.scope zeroinitializer, ptr %s26
  %t599 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s26, ptr %v1, ptr %t599, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d546, i32 0, i32 1) })
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s26)
  br label %bb159
bb106:
  %t601 = load { i64, [8 x i64] }, ptr %l1
  %t603 = extractvalue { i64, [8 x i64] } %t601, 0
  %t604 = icmp eq i64 %t603, 7
  br i1 %t604, label %bb107, label %bb108
bb107:
  %t606 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t607 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t606, i32 0, i32 0
  %t608 = load %"compiler/source:Span", ptr %t607
  store %"compiler/source:Span" %t608, ptr %l30
  %t610 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t611 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t610, i32 0, i32 1
  %t612 = load { i64, [4 x i64] }, ptr %t611
  store { i64, [4 x i64] } %t612, ptr %l31
  br label %bb109
bb108:
  br label %bb121
bb109:
  store %olang.scope zeroinitializer, ptr %s27
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t615 = load %"compiler/source:Span", ptr %l30
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %v1, ptr %v2, ptr %t614, %"compiler/source:Span" %t615)
  br label %bb110
bb110:
  %t618 = load ptr, ptr %l2, !tbaa !29
  store ptr %t618, ptr %l262, !tbaa !29
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t621 = getelementptr %"compiler/emit:fnEm", ptr %t619, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t624 = getelementptr %"compiler/mir:Fn", ptr %t622, i32 0, i32 1
  %t625 = load i32, ptr %t624, !tbaa !23
  %t626 = load ptr, ptr %l262, !tbaa !29
  %t627 = call ptr @__olang_scope_or(ptr %v1, ptr %t626)
  %t628 = call ptr @__olang_scope_hold(ptr %t627)
  %t629 = ptrtoint ptr %t628 to i64
  %t631 = inttoptr i64 %t629 to ptr
  %t633 = inttoptr i64 0 to ptr
  %t634 = load ptr, ptr %l262, !tbaa !29
  %t636 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %t631, ptr %s27, ptr %t633, ptr %t634, i32 %t625)
  store { i64, ptr } %t636, ptr %l268
  br label %bb111
bb111:
  %t637 = load { i64, ptr }, ptr %l268, !tbaa !27
  store { i64, ptr } %t637, ptr %l32, !tbaa !27
  %t638 = load ptr, ptr %l0, !tbaa !29
  %t639 = load { i64, [4 x i64] }, ptr %l31
  %t640 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t644 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %s27, ptr %v2, ptr %v1, ptr %t638, { i64, [4 x i64] } %t639, i32 %t640)
  store { i64, ptr } %t644, ptr %l272
  br label %bb112
bb112:
  %t645 = load { i64, ptr }, ptr %l272, !tbaa !27
  store { i64, ptr } %t645, ptr %l33, !tbaa !27
  %t646 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t648 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s27, ptr %s27, { i64, ptr } %t646, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d547, i32 0, i32 1) })
  store i1 %t648, ptr %l274
  br label %bb113
bb113:
  %t649 = load i1, ptr %l274, !tbaa !21
  br i1 %t649, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s28
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t651 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s28, ptr %s27, ptr %s28, ptr %s28, ptr %v1, ptr %t650, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d548, i32 0, i32 1) }, { i64, ptr } %t651, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d549, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s29
  %t654 = load ptr, ptr %l0, !tbaa !29
  store ptr %t654, ptr %l277, !tbaa !29
  %t655 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t655, ptr %l278, !tbaa !27
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t658 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t659 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d550, i32 0, i32 1) }, 1
  %t660 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d550, i32 0, i32 1) }, 0
  %t662 = extractvalue { i64, ptr } %t657, 1
  %t663 = extractvalue { i64, ptr } %t657, 0
  %t664 = add i64 %t660, %t663
  %t665 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d551, i32 0, i32 1) }, 1
  %t666 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d551, i32 0, i32 1) }, 0
  %t667 = add i64 %t664, %t666
  %t669 = extractvalue { i64, ptr } %t658, 1
  %t670 = extractvalue { i64, ptr } %t658, 0
  %t671 = add i64 %t667, %t670
  %t672 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d552, i32 0, i32 1) }, 1
  %t673 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d552, i32 0, i32 1) }, 0
  %t674 = add i64 %t671, %t673
  %t675 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t674)
  call void @olang_textcopy(ptr %t675, ptr %t659, i64 %t660)
  %t676 = getelementptr i8, ptr %t675, i64 %t660
  call void @olang_textcopy(ptr %t676, ptr %t662, i64 %t663)
  %t677 = getelementptr i8, ptr %t676, i64 %t663
  call void @olang_textcopy(ptr %t677, ptr %t665, i64 %t666)
  %t678 = getelementptr i8, ptr %t677, i64 %t666
  call void @olang_textcopy(ptr %t678, ptr %t669, i64 %t670)
  %t679 = getelementptr i8, ptr %t678, i64 %t670
  call void @olang_textcopy(ptr %t679, ptr %t672, i64 %t673)
  %t680 = insertvalue { i64, ptr } undef, i64 %t674, 0
  %t681 = insertvalue { i64, ptr } %t680, ptr %t675, 1
  %t685 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s29, ptr %s29, ptr %v1, ptr %t656, { i64, ptr } %t681)
  store { i64, ptr } %t685, ptr %l284
  br label %bb117
bb116:
  call void @__olang_scope_close(ptr %s28)
  br label %bb119
bb117:
  %t686 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t687 = load ptr, ptr %l277, !tbaa !29
  %t688 = load { i64, ptr }, ptr %l278, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s27, ptr %s29, ptr %s29, ptr %s29, ptr %v1, ptr %t687, { i64, ptr } %t688, { i64, ptr } %t686, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d553, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s29)
  br label %bb119
bb119:
  %t690 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s27, ptr %v1, ptr %t690, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d554, i32 0, i32 1) })
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s27)
  br label %bb159
bb121:
  %t692 = load { i64, [8 x i64] }, ptr %l1
  %t694 = extractvalue { i64, [8 x i64] } %t692, 0
  %t695 = icmp eq i64 %t694, 8
  br i1 %t695, label %bb122, label %bb123
bb122:
  %t697 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t698 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t697, i32 0, i32 1
  %t699 = load i32, ptr %t698
  store i32 %t699, ptr %l34, !tbaa !23
  %t701 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t702 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t701, i32 0, i32 2
  %t703 = load i32, ptr %t702
  store i32 %t703, ptr %l35, !tbaa !23
  %t705 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t706 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t705, i32 0, i32 3
  %t707 = load i32, ptr %t706
  store i32 %t707, ptr %l36, !tbaa !23
  %t709 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t710 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t709, i32 0, i32 4
  %t711 = load i32, ptr %t710
  store i32 %t711, ptr %l37, !tbaa !23
  br label %bb124
bb123:
  br label %bb148
bb124:
  store %olang.scope zeroinitializer, ptr %s31
  %t713 = load i32, ptr %l37, !tbaa !23
  %t714 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t717 = icmp ne i32 %t713, %t714
  br i1 %t717, label %bb125, label %bb126
bb125:
  %t719 = load i32, ptr %l37, !tbaa !23
  %t720 = load i32, ptr %l35, !tbaa !23
  %t723 = icmp ne i32 %t719, %t720
  store i1 %t723, ptr %l296, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb127
bb127:
  %t725 = load i1, ptr %l296, !tbaa !21
  store i1 %t725, ptr %l38, !tbaa !21
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t728 = getelementptr %"compiler/emit:fnEm", ptr %t726, i32 0, i32 0
  %t729 = load ptr, ptr %t728, !tbaa !29
  store ptr %t729, ptr %l301, !tbaa !29
  %t730 = load ptr, ptr %l301, !tbaa !29
  %t731 = call ptr @__olang_scope_or(ptr %v1, ptr %t730)
  %t732 = call ptr @__olang_scope_hold(ptr %t731)
  %t733 = ptrtoint ptr %t732 to i64
  %t735 = inttoptr i64 %t733 to ptr
  %t736 = load ptr, ptr %l301, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %t735, ptr %s31, ptr %s31, ptr %t736, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d555, i32 0, i32 1) }, { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d556, i32 0, i32 1) })
  br label %bb128
bb128:
  %t737 = load ptr, ptr %l0, !tbaa !29
  store ptr %t737, ptr %l303, !tbaa !29
  %t738 = load i32, ptr %l34, !tbaa !23
  store i32 %t738, ptr %l304, !tbaa !23
  %t739 = load i1, ptr %l38, !tbaa !21
  br i1 %t739, label %bb129, label %bb130
bb129:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d557, i32 0, i32 1) }, ptr %l306, !tbaa !27
  br label %bb131
bb130:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d558, i32 0, i32 1) }, ptr %l306, !tbaa !27
  br label %bb131
bb131:
  %t741 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d559, i32 0, i32 1) }, 1
  %t742 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d559, i32 0, i32 1) }, 0
  %t743 = load i32, ptr %l304, !tbaa !23
  %t744 = sext i32 %t743 to i64
  %t745 = call i64 @__olang_fmt_i64(ptr null, i64 %t744)
  %t746 = add i64 %t742, %t745
  %t747 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d560, i32 0, i32 1) }, 1
  %t748 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d560, i32 0, i32 1) }, 0
  %t749 = add i64 %t746, %t748
  %t750 = load { i64, ptr }, ptr %l306, !tbaa !27
  %t751 = extractvalue { i64, ptr } %t750, 1
  %t752 = extractvalue { i64, ptr } %t750, 0
  %t753 = add i64 %t749, %t752
  %t754 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d561, i32 0, i32 1) }, 1
  %t755 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d561, i32 0, i32 1) }, 0
  %t756 = add i64 %t753, %t755
  %t757 = call ptr @__olang_scope_alloc(ptr %s31, i64 %t756)
  call void @olang_textcopy(ptr %t757, ptr %t741, i64 %t742)
  %t758 = getelementptr i8, ptr %t757, i64 %t742
  %t759 = call i64 @__olang_fmt_i64(ptr %t758, i64 %t744)
  %t760 = getelementptr i8, ptr %t758, i64 %t745
  call void @olang_textcopy(ptr %t760, ptr %t747, i64 %t748)
  %t761 = getelementptr i8, ptr %t760, i64 %t748
  call void @olang_textcopy(ptr %t761, ptr %t751, i64 %t752)
  %t762 = getelementptr i8, ptr %t761, i64 %t752
  call void @olang_textcopy(ptr %t762, ptr %t754, i64 %t755)
  %t763 = insertvalue { i64, ptr } undef, i64 %t756, 0
  %t764 = insertvalue { i64, ptr } %t763, ptr %t757, 1
  %t766 = load ptr, ptr %l303, !tbaa !29
  %t768 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s31, ptr %s31, ptr %v1, ptr %t766, { i64, ptr } %t764)
  store { i64, ptr } %t768, ptr %l309
  br label %bb132
bb132:
  %t769 = load { i64, ptr }, ptr %l309, !tbaa !27
  store { i64, ptr } %t769, ptr %l39, !tbaa !27
  %t770 = load i32, ptr %l37, !tbaa !23
  %t771 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t774 = icmp eq i32 %t770, %t771
  br i1 %t774, label %bb133, label %bb134
bb133:
  store %olang.scope zeroinitializer, ptr %s33
  %t776 = load ptr, ptr %l0, !tbaa !29
  store ptr %t776, ptr %l313, !tbaa !29
  %t777 = load i32, ptr %l35, !tbaa !23
  %t779 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s33, i32 %t777)
  store { i64, ptr } %t779, ptr %l315
  br label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s35
  %t780 = load ptr, ptr %l0, !tbaa !29
  %t781 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t782 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d562, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d562, i32 0, i32 1) }, 0
  %t785 = extractvalue { i64, ptr } %t781, 1
  %t786 = extractvalue { i64, ptr } %t781, 0
  %t787 = add i64 %t783, %t786
  %t788 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d563, i32 0, i32 1) }, 1
  %t789 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d563, i32 0, i32 1) }, 0
  %t790 = add i64 %t787, %t789
  %t791 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t790)
  call void @olang_textcopy(ptr %t791, ptr %t782, i64 %t783)
  %t792 = getelementptr i8, ptr %t791, i64 %t783
  call void @olang_textcopy(ptr %t792, ptr %t785, i64 %t786)
  %t793 = getelementptr i8, ptr %t792, i64 %t786
  call void @olang_textcopy(ptr %t793, ptr %t788, i64 %t789)
  %t794 = insertvalue { i64, ptr } undef, i64 %t790, 0
  %t795 = insertvalue { i64, ptr } %t794, ptr %t791, 1
  %t799 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s35, ptr %s35, ptr %v1, ptr %t780, { i64, ptr } %t795)
  store { i64, ptr } %t799, ptr %l322
  br label %bb137
bb135:
  %t800 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d564, i32 0, i32 1) }, 1
  %t801 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d564, i32 0, i32 1) }, 0
  %t802 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t802, 1
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t805 = add i64 %t801, %t804
  %t806 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t805)
  call void @olang_textcopy(ptr %t806, ptr %t800, i64 %t801)
  %t807 = getelementptr i8, ptr %t806, i64 %t801
  call void @olang_textcopy(ptr %t807, ptr %t803, i64 %t804)
  %t808 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t809 = insertvalue { i64, ptr } %t808, ptr %t806, 1
  %t811 = load ptr, ptr %l313, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s33, ptr %v1, ptr %t811, { i64, ptr } %t809)
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s33)
  br label %bb147
bb137:
  %t813 = load { i64, ptr }, ptr %l322, !tbaa !27
  store { i64, ptr } %t813, ptr %l40, !tbaa !27
  %t814 = load i32, ptr %l36, !tbaa !23
  %t815 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t818 = icmp ne i32 %t814, %t815
  br i1 %t818, label %bb138, label %bb139
bb138:
  store %olang.scope zeroinitializer, ptr %s37
  %t820 = load ptr, ptr %l0, !tbaa !29
  store ptr %t820, ptr %l326, !tbaa !29
  %t821 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t821, ptr %l327, !tbaa !27
  %t822 = load ptr, ptr %l0, !tbaa !29
  %t823 = load i32, ptr %l36, !tbaa !23
  %t826 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %s37, ptr %v2, ptr %v1, ptr %t822, i32 %t823)
  store { i64, ptr } %t826, ptr %l330
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t827 = load { i64, ptr }, ptr %l330, !tbaa !27
  %t828 = load ptr, ptr %l326, !tbaa !29
  %t829 = load { i64, ptr }, ptr %l327, !tbaa !27
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %s37, ptr %s35, ptr %s37, ptr %s37, ptr %v1, ptr %t828, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d565, i32 0, i32 1) }, { i64, ptr } %t829, { i64, ptr } %t827, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) })
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s37)
  br label %bb142
bb142:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t832 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t833 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d566, i32 0, i32 1) }, 1
  %t834 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d566, i32 0, i32 1) }, 0
  %t836 = extractvalue { i64, ptr } %t832, 1
  %t837 = extractvalue { i64, ptr } %t832, 0
  %t838 = add i64 %t834, %t837
  %t839 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d567, i32 0, i32 1) }, 1
  %t840 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d567, i32 0, i32 1) }, 0
  %t841 = add i64 %t838, %t840
  %t842 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t841)
  call void @olang_textcopy(ptr %t842, ptr %t833, i64 %t834)
  %t843 = getelementptr i8, ptr %t842, i64 %t834
  call void @olang_textcopy(ptr %t843, ptr %t836, i64 %t837)
  %t844 = getelementptr i8, ptr %t843, i64 %t837
  call void @olang_textcopy(ptr %t844, ptr %t839, i64 %t840)
  %t845 = insertvalue { i64, ptr } undef, i64 %t841, 0
  %t846 = insertvalue { i64, ptr } %t845, ptr %t842, 1
  %t850 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s35, ptr %s35, ptr %v1, ptr %t831, { i64, ptr } %t846)
  store { i64, ptr } %t850, ptr %l336
  br label %bb143
bb143:
  %t851 = load { i64, ptr }, ptr %l336, !tbaa !27
  %t852 = load ptr, ptr %l0, !tbaa !29
  store ptr %t852, ptr %l337, !tbaa !29
  store { i64, ptr } %t851, ptr %l338, !tbaa !27
  %t854 = load i32, ptr %l37, !tbaa !23
  %t856 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s35, i32 %t854)
  store { i64, ptr } %t856, ptr %l340
  br label %bb144
bb144:
  %t857 = load i32, ptr %l35, !tbaa !23
  %t859 = call { i64, ptr } @compiler_2femit_2eblockName(ptr %s35, i32 %t857)
  store { i64, ptr } %t859, ptr %l342
  br label %bb145
bb145:
  %t860 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d568, i32 0, i32 1) }, 1
  %t861 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d568, i32 0, i32 1) }, 0
  %t862 = load { i64, ptr }, ptr %l338, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t862, 1
  %t864 = extractvalue { i64, ptr } %t862, 0
  %t865 = add i64 %t861, %t864
  %t866 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 1
  %t867 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 0
  %t868 = add i64 %t865, %t867
  %t869 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t870 = extractvalue { i64, ptr } %t869, 1
  %t871 = extractvalue { i64, ptr } %t869, 0
  %t872 = add i64 %t868, %t871
  %t873 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 1
  %t874 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d569, i32 0, i32 1) }, 0
  %t875 = add i64 %t872, %t874
  %t876 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t877 = extractvalue { i64, ptr } %t876, 1
  %t878 = extractvalue { i64, ptr } %t876, 0
  %t879 = add i64 %t875, %t878
  %t880 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t879)
  call void @olang_textcopy(ptr %t880, ptr %t860, i64 %t861)
  %t881 = getelementptr i8, ptr %t880, i64 %t861
  call void @olang_textcopy(ptr %t881, ptr %t863, i64 %t864)
  %t882 = getelementptr i8, ptr %t881, i64 %t864
  call void @olang_textcopy(ptr %t882, ptr %t866, i64 %t867)
  %t883 = getelementptr i8, ptr %t882, i64 %t867
  call void @olang_textcopy(ptr %t883, ptr %t870, i64 %t871)
  %t884 = getelementptr i8, ptr %t883, i64 %t871
  call void @olang_textcopy(ptr %t884, ptr %t873, i64 %t874)
  %t885 = getelementptr i8, ptr %t884, i64 %t874
  call void @olang_textcopy(ptr %t885, ptr %t877, i64 %t878)
  %t886 = insertvalue { i64, ptr } undef, i64 %t879, 0
  %t887 = insertvalue { i64, ptr } %t886, ptr %t880, 1
  %t889 = load ptr, ptr %l337, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %s35, ptr %v1, ptr %t889, { i64, ptr } %t887)
  br label %bb146
bb146:
  call void @__olang_scope_close(ptr %s35)
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s31)
  br label %bb159
bb148:
  %t891 = load { i64, [8 x i64] }, ptr %l1
  %t893 = extractvalue { i64, [8 x i64] } %t891, 0
  %t894 = icmp eq i64 %t893, 9
  br i1 %t894, label %bb149, label %bb150
bb149:
  %t896 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t897 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t896, i32 0, i32 0
  %t898 = load %"compiler/source:Span", ptr %t897
  store %"compiler/source:Span" %t898, ptr %l42
  %t900 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t901 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t900, i32 0, i32 1
  %t902 = load i32, ptr %t901, !range !{i32 0, i32 20}
  store i32 %t902, ptr %l43
  %t904 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t905 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t904, i32 0, i32 2
  %t906 = load { i64, [4 x i64] }, ptr %t905
  store { i64, [4 x i64] } %t906, ptr %l44
  br label %bb151
bb150:
  br label %bb153
bb151:
  %t908 = load ptr, ptr %l0, !tbaa !29
  %t909 = load %"compiler/source:Span", ptr %l42
  %t910 = load i32, ptr %l43, !range !{i32 0, i32 20}
  %t911 = load { i64, [4 x i64] }, ptr %l44
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %v1, ptr %v2, ptr %t908, %"compiler/source:Span" %t909, i32 %t910, { i64, [4 x i64] } %t911)
  br label %bb152
bb152:
  br label %bb159
bb153:
  %t916 = load { i64, [8 x i64] }, ptr %l1
  %t918 = extractvalue { i64, [8 x i64] } %t916, 0
  %t919 = icmp eq i64 %t918, 10
  br i1 %t919, label %bb154, label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb158
bb156:
  store %olang.scope zeroinitializer, ptr %s41
  %t921 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %s41, ptr %v1, ptr %t921, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d570, i32 0, i32 1) })
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s41)
  br label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_7633dd9d24c54174_280dfd74a77e9550)
  unreachable
bb159:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ewidenBF16(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca i1
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/emit:fnEm", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/emit:Emitter", ptr %t6, i32 0, i32 73
  %t9 = load i1, ptr %t8, !tbaa !21
  %t13 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %s0, ptr %v4, ptr %t1, { i64, ptr } %a1, i1 %t9)
  store { i64, ptr } %t13, ptr %l12
  br label %bb1
bb1:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d571, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d571, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t14, 1
  %t21 = extractvalue { i64, ptr } %t14, 0
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d572, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d572, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t17, i64 %t18)
  %t27 = getelementptr i8, ptr %t26, i64 %t18
  call void @olang_textcopy(ptr %t27, ptr %t20, i64 %t21)
  %t28 = getelementptr i8, ptr %t27, i64 %t21
  call void @olang_textcopy(ptr %t28, ptr %t23, i64 %t24)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t26, 1
  %t34 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t15, { i64, ptr } %t30)
  store { i64, ptr } %t34, ptr %l17
  br label %bb2
bb2:
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d573, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d573, i32 0, i32 1) }, 0
  %t41 = extractvalue { i64, ptr } %t35, 1
  %t42 = extractvalue { i64, ptr } %t35, 0
  %t43 = add i64 %t39, %t42
  %t44 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d574, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d574, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t38, i64 %t39)
  %t48 = getelementptr i8, ptr %t47, i64 %t39
  call void @olang_textcopy(ptr %t48, ptr %t41, i64 %t42)
  %t49 = getelementptr i8, ptr %t48, i64 %t42
  call void @olang_textcopy(ptr %t49, ptr %t44, i64 %t45)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t47, 1
  %t55 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %s0, ptr %v4, ptr %t36, { i64, ptr } %t51)
  store { i64, ptr } %t55, ptr %l22
  br label %bb3
bb3:
  %t56 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d575, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d575, i32 0, i32 1) }, 0
  %t62 = extractvalue { i64, ptr } %t56, 1
  %t63 = extractvalue { i64, ptr } %t56, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d576, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d576, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  %t76 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t57, { i64, ptr } %t72)
  store { i64, ptr } %t76, ptr %l27
  br label %bb4
bb4:
  %t77 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t77, ptr %l6, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t78, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d577, i32 0, i32 1) })
  store i1 %t80, ptr %l29
  br label %bb5
bb5:
  %t81 = load i1, ptr %l29, !tbaa !21
  br i1 %t81, label %bb6, label %bb7
bb6:
  %t82 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t82, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d578, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d578, i32 0, i32 1) }, 0
  %t90 = extractvalue { i64, ptr } %t85, 1
  %t91 = extractvalue { i64, ptr } %t85, 0
  %t92 = add i64 %t88, %t91
  %t93 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d579, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d579, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t97 = extractvalue { i64, ptr } %t86, 1
  %t98 = extractvalue { i64, ptr } %t86, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t87, i64 %t88)
  %t101 = getelementptr i8, ptr %t100, i64 %t88
  call void @olang_textcopy(ptr %t101, ptr %t90, i64 %t91)
  %t102 = getelementptr i8, ptr %t101, i64 %t91
  call void @olang_textcopy(ptr %t102, ptr %t93, i64 %t94)
  %t103 = getelementptr i8, ptr %t102, i64 %t94
  call void @olang_textcopy(ptr %t103, ptr %t97, i64 %t98)
  %t104 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t100, 1
  %t109 = call { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %s0, ptr %v3, ptr %v4, ptr %t84, { i64, ptr } %t105)
  store { i64, ptr } %t109, ptr %l36
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t110, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2femit_2etermSpan({ i64, [8 x i64] } %a0) #0 {
entry:
  %l0 = alloca { i64, [8 x i64] }
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l24 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store { i64, [8 x i64] } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [8 x i64] }, ptr %l0
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 4
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t7 = getelementptr { %"compiler/source:Span", i32 }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/source:Span", ptr %t7
  store %"compiler/source:Span" %t8, ptr %l1
  br label %bb7
bb2:
  %t10 = load { i64, [8 x i64] }, ptr %l0
  %t12 = extractvalue { i64, [8 x i64] } %t10, 0
  %t13 = icmp eq i64 %t12, 5
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t16 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t15, i32 0, i32 0
  %t17 = load %"compiler/source:Span", ptr %t16
  store %"compiler/source:Span" %t17, ptr %l1
  br label %bb7
bb4:
  %t19 = load { i64, [8 x i64] }, ptr %l0
  %t21 = extractvalue { i64, [8 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 7
  br i1 %t22, label %bb5, label %bb6
bb5:
  %t24 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l1
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l3
  br label %bb22
bb8:
  %t30 = load { i64, [8 x i64] }, ptr %l0
  %t32 = extractvalue { i64, [8 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 8
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32, i32, i32, i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l2
  br label %bb15
bb10:
  %t39 = load { i64, [8 x i64] }, ptr %l0
  %t41 = extractvalue { i64, [8 x i64] } %t39, 0
  %t42 = icmp eq i64 %t41, 9
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t44 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", i32, { i64, [4 x i64] } }, ptr %t44, i32 0, i32 0
  %t46 = load %"compiler/source:Span", ptr %t45
  store %"compiler/source:Span" %t46, ptr %l2
  br label %bb15
bb12:
  %t48 = load { i64, [8 x i64] }, ptr %l0
  %t50 = extractvalue { i64, [8 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 6
  br i1 %t51, label %bb13, label %bb14
bb13:
  %t53 = getelementptr { i64, [8 x i64] }, ptr %l0, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32 }, ptr %t53, i32 0, i32 0
  %t55 = load %"compiler/source:Span", ptr %t54
  store %"compiler/source:Span" %t55, ptr %l2
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t57 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t57, ptr %l3
  br label %bb22
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t59 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t59, ptr %l24
  br label %bb20
bb20:
  %t60 = load %"compiler/source:Span", ptr %l24
  store %"compiler/source:Span" %t60, ptr %l3
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a69d5bfe0a165b0_62b4fff2e0b246dc)
  unreachable
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t61 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t61, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2femit_3acDecls_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l16 = alloca i64
  %l18 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l20 = alloca %"compiler/emit:cDecls"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v0)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l4, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v0)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l6
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e0
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l4
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l0
  %t22 = call ptr @__olang_scope_hold(ptr %v0)
  %t23 = ptrtoint ptr %t22 to i64
  store i64 %t23, ptr %l8, !tbaa !24
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e1
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = call ptr @__olang_region_make(ptr %v0)
  %t27 = ptrtoint ptr %t26 to i64
  store i64 %t27, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t28 = load i64, ptr %l8
  %t29 = inttoptr i64 %t28 to ptr
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t29, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l10
  br label %bb8
bb8:
  %t31 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e1
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t33 = load i64, ptr %l8
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10, i32 0, i32 0
  %t36 = load { i64, ptr }, ptr %t35
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = call ptr @__olang_region_or(ptr %t37, ptr null)
  %t39 = call ptr @__olang_region_home(ptr %t38)
  %t40 = icmp ne ptr %t39, null
  %t41 = select i1 %t40, ptr %t39, ptr null
  call void @__olang_region_settle_in(ptr %t34, ptr %t41)
  br label %bb10
bb10:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l1
  %t43 = call ptr @__olang_scope_hold(ptr %v0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l12, !tbaa !24
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e2
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = call ptr @__olang_region_make(ptr %v0)
  %t48 = ptrtoint ptr %t47 to i64
  store i64 %t48, ptr %l12, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i64, ptr %l12
  %t50 = inttoptr i64 %t49 to ptr
  %t51 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %t50)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t51, ptr %l14
  br label %bb13
bb13:
  %t52 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e2
  br i1 %t52, label %bb14, label %bb15
bb14:
  %t54 = load i64, ptr %l12
  %t55 = inttoptr i64 %t54 to ptr
  %t56 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14, i32 0, i32 2
  %t57 = load { i64, ptr }, ptr %t56
  %t58 = extractvalue { i64, ptr } %t57, 1
  %t59 = call ptr @__olang_region_or(ptr %t58, ptr null)
  %t60 = call ptr @__olang_region_home(ptr %t59)
  %t61 = icmp ne ptr %t60, null
  %t62 = select i1 %t61, ptr %t60, ptr null
  %t63 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14, i32 0, i32 1
  %t64 = load { i64, ptr }, ptr %t63
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = call ptr @__olang_region_or(ptr %t65, ptr null)
  %t67 = call ptr @__olang_region_home(ptr %t66)
  %t68 = icmp ne ptr %t67, null
  %t69 = select i1 %t68, ptr %t67, ptr %t62
  %t70 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14, i32 0, i32 0
  %t71 = load { i64, ptr }, ptr %t70
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = call ptr @__olang_region_or(ptr %t72, ptr null)
  %t74 = call ptr @__olang_region_home(ptr %t73)
  %t75 = icmp ne ptr %t74, null
  %t76 = select i1 %t75, ptr %t74, ptr %t69
  call void @__olang_region_settle_in(ptr %t55, ptr %t76)
  br label %bb15
bb15:
  %t77 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t77, ptr %l2
  %t78 = call ptr @__olang_scope_hold(ptr %v0)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l16, !tbaa !24
  %t80 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e3
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = call ptr @__olang_region_make(ptr %v0)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l16, !tbaa !24
  br label %bb17
bb17:
  %t84 = load i64, ptr %l16
  %t85 = inttoptr i64 %t84 to ptr
  %t86 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %t85)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t86, ptr %l18
  br label %bb18
bb18:
  %t87 = load i1, ptr @olang_2esole_2ecompiler_2femit_3acDecls_2e3
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = load i64, ptr %l16
  %t90 = inttoptr i64 %t89 to ptr
  %t91 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 2
  %t92 = load { i64, ptr }, ptr %t91
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = call ptr @__olang_region_or(ptr %t93, ptr null)
  %t95 = call ptr @__olang_region_home(ptr %t94)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, ptr %t95, ptr null
  %t98 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98
  %t100 = extractvalue { i64, ptr } %t99, 1
  %t101 = call ptr @__olang_region_or(ptr %t100, ptr null)
  %t102 = call ptr @__olang_region_home(ptr %t101)
  %t103 = icmp ne ptr %t102, null
  %t104 = select i1 %t103, ptr %t102, ptr %t97
  %t105 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18, i32 0, i32 0
  %t106 = load { i64, ptr }, ptr %t105
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = call ptr @__olang_region_or(ptr %t107, ptr null)
  %t109 = call ptr @__olang_region_home(ptr %t108)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr %t104
  call void @__olang_region_settle_in(ptr %t90, ptr %t111)
  br label %bb20
bb20:
  %t112 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l18
  %t113 = getelementptr %"compiler/emit:cDecls", ptr %l20, i32 0, i32 0
  %t114 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %t113
  %t115 = getelementptr %"compiler/emit:cDecls", ptr %l20, i32 0, i32 1
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %t115
  %t117 = getelementptr %"compiler/emit:cDecls", ptr %l20, i32 0, i32 2
  %t118 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t118, ptr %t117
  %t119 = getelementptr %"compiler/emit:cDecls", ptr %l20, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t112, ptr %t119
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l20, i64 208, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d3 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".ctor" }>, align 8
@.d4 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".dtor" }>, align 8
@.d5 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_lambda_" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".init" }>, align 8
@.d8 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_case_" }>, align 8
@.d9 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang_cond_" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
@.d10 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c".contract." }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2ecompiler_2ftyped_3aContractKind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 1}
  %t3 = sext i32 %t2 to i64
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  br label %ret
bb2:
  %t5 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d580, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d580, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
ret:
  ret void
}

@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d12 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"olang.slot." }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d14 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"ptr sret(" }>, align 8
@.d15 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c") align " }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d20 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"h = lshr i32 " }>, align 8
@.d21 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", 16\0A" }>, align 8
@.d22 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d24 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = icmp eq i32 %" }>, align 8
@.d25 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"h, " }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2ecarriesText_2elocal_2e7 = weak hidden constant i1 false
@.d28 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"  %" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
@.d30 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" = or i1 " }>, align 8
@.d31 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", %" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare ptr @__olang_region_make(ptr) noinline
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"e" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release(ptr) noinline
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"%" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
define linkonce_odr %"std/prelude/text:StringBuilder" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2ftext_3aStringBuilder(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %rv = alloca %"std/prelude/text:StringBuilder"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l0
  store %"std/prelude/text:StringBuilder" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/text:StringBuilder", ptr %rv
  ret %"std/prelude/text:StringBuilder" %rr
}

@.d38 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"!DIEnumerator(name: \22null\22, value: 0)" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d40 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"!DIEnumerator(name: \22" }>, align 8
@.d41 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\22, value: " }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", !" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"!{" }>, align 8
@.d45 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d46 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d47 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"!DICompositeType(tag: DW_TAG_enumeration_type, name: \22" }>, align 8
@.d48 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"\22, size: 32, baseType: !" }>, align 8
@.d49 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", elements: !" }>, align 8
@.d50 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"define " }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" {" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"!dbg" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d57 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d59 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"startup" }>, align 8
@.d60 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang_task" }>, align 8
@.d61 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"task" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d63 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = distinct !DISubprogram(name: \22" }>, align 8
@.d64 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\22, scope: !" }>, align 8
@.d65 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", file: !" }>, align 8
@.d66 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c", line: 0, type: !" }>, align 8
@.d67 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c", scopeLine: 0, spFlags: DISPFlagDefinition, unit: !" }>, align 8
@.d68 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d70 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" = !DILocation(line: 0, scope: !" }>, align 8
@.d71 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d72 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" !dbg !" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" {\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2edbgFunctions_2elocal_2e4 = weak hidden constant i1 false
@.d74 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", !dbg !" }>, align 8
@.d75 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"}" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"call " }>, align 8
@.d79 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"!dbg" }>, align 8
@.d80 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d82 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"!DIFile(filename: \22<generated>\22, directory: \22\22)" }>, align 8
@.d83 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argc" }>, align 8
@.d84 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argc = external global i32" }>, align 8
@.d85 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_argv" }>, align 8
@.d86 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"@__olang_argv = external global ptr" }>, align 8
@.d87 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_thread_init" }>, align 8
@.d88 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"define i32 @main(i32 %argc, ptr %argv) #0 {\0Aentry:\0A" }>, align 8
@.d89 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"  store i32 %argc, ptr @__olang_argc\0A  store ptr %argv, ptr @__olang_argv\0A" }>, align 8
@.d90 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"  call void @__olang_thread_init()\0A" }>, align 8
@.d91 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prof_start" }>, align 8
@.d92 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"llvm.frameaddress.p0" }>, align 8
@.d93 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"ptr @llvm.frameaddress.p0(i32)" }>, align 8
@.d94 = private constant <{ i64, [97 x i8] }> <{ i64 0, [97 x i8] c"  %proftop = call ptr @llvm.frameaddress.p0(i32 0)\0A  call void @__olang_prof_start(ptr %proftop)\0A" }>, align 8
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d95 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d96 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()\0A" }>, align 8
@.d97 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_prog_end" }>, align 8
@.d98 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d99 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"()\0A  call void @__olang_prog_end()\0A  ret i32 0\0A}\0A\0A" }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d102 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"  %c = call i32 @" }>, align 8
@.d103 = private constant <{ i64, [70 x i8] }> <{ i64 0, [70 x i8] c"()\0A  %bad = icmp ne i32 %c, 0\0A  br i1 %bad, label %err, label %ok\0Aok:\0A" }>, align 8
@.d104 = private constant <{ i64, [44 x i8] }> <{ i64 0, [44 x i8] c"  call void @__olang_prog_end()\0A  ret i32 0\0A" }>, align 8
@.d105 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"err:\0A" }>, align 8
@.d106 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"fputs" }>, align 8
@.d107 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"i32 @fputs(ptr, ptr)" }>, align 8
@.d108 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%s" }>, align 8
@.d109 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%m0" }>, align 8
@.d110 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"unhandled error\0A" }>, align 8
@.d111 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"  %m0 = getelementptr i8, ptr " }>, align 8
@.d112 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 0\0A" }>, align 8
@.d113 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"unhandled error: " }>, align 8
@.d114 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d115 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %q" }>, align 8
@.d116 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = icmp eq i32 %c, " }>, align 8
@.d117 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d118 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"  %m" }>, align 8
@.d119 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = select i1 %q" }>, align 8
@.d120 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d121 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2eentry_2elocal_2e11 = weak hidden constant i1 false
@.d122 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%m" }>, align 8
@.d123 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"  call i32 @fputs(ptr " }>, align 8
@.d124 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", ptr %s)\0A" }>, align 8
@.d125 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_ert_print" }>, align 8
@.d126 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"void @__olang_ert_print(ptr)" }>, align 8
@.d127 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_debug_hint" }>, align 8
@.d128 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"void @__olang_debug_hint(ptr)" }>, align 8
@.d129 = private constant <{ i64, [86 x i8] }> <{ i64 0, [86 x i8] c"  call void @__olang_ert_print(ptr %s)\0A  call void @__olang_prog_end()\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d130 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"  call void @__olang_debug_hint(ptr %s)\0A  call void @__olang_prog_end()\0A  ret i32 1\0A}\0A\0A" }>, align 8
@.d131 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d136 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" @" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d138 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d139 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", ..." }>, align 8
@.d140 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@.d141 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d143 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c" nobuiltin memory(write)" }>, align 8
@.d144 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d146 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = weak hidden constant i1 false\0A" }>, align 8
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d148 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c" = weak hidden constant i1 false\0A" }>, align 8
@.d149 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"|adapter" }>, align 8
@.d150 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d152 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d153 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d154 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"  %rhi = lshr i32 " }>, align 8
@.d155 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c", 16\0A  %rw = and i32 " }>, align 8
@.d156 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", 65535\0A" }>, align 8
@.d157 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d158 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %rh" }>, align 8
@.d159 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c" = icmp eq i32 %rhi, " }>, align 8
@.d160 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d161 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %rp" }>, align 8
@.d162 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" = select i1 %rh" }>, align 8
@.d163 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i32 " }>, align 8
@.d164 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3aEmitter__2erecodeText_2elocal_2e7 = weak hidden constant i1 false
@.d165 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rp" }>, align 8
@.d166 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"  %rs = shl i32 " }>, align 8
@.d167 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c", 16\0A  %rv2 = or i32 %rs, %rw\0A" }>, align 8
@.d168 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%rv2" }>, align 8
@.d169 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d170 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__acrt_iob_func" }>, align 8
@.d171 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"ptr @__acrt_iob_func(i32)" }>, align 8
@.d172 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d173 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c" = call ptr @__acrt_iob_func(i32 2)\0A" }>, align 8
@.d174 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"stderr" }>, align 8
@.d175 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"@stderr = external global ptr" }>, align 8
@.d176 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d177 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c" = load ptr, ptr @stderr\0A" }>, align 8
@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eaddr_2elocal_2e3 = weak hidden constant i1 false
declare ptr @__olang_scope_or(ptr, ptr)
@.d179 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"a place with no base" }>, align 8
@.d180 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d181 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d182 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d183 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d184 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d185 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d186 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d187 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 1" }>, align 8
@.d188 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2femit_3afnEm_2e15 = weak hidden constant i1 false
@.d189 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_held_alloc" }>, align 8
@.d190 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_scope_alloc" }>, align 8
@.d191 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"__olang_scope_alloc_zeroed_min" }>, align 8
@.d192 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"_min" }>, align 8
@.d193 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d194 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d195 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d196 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d197 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"__olang_scope_alloc_zeroed" }>, align 8
@.d198 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"call ptr @" }>, align 8
@.d199 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d200 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d201 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d202 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"zeroinitializer" }>, align 8
@.d203 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d204 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d205 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"i" }>, align 8
@.d206 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d207 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d208 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" x i8]" }>, align 8
@.d209 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d210 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Vec" }>, align 8
@.d211 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/vec" }>, align 8
@.d212 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"data" }>, align 8
@.d213 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Map" }>, align 8
@.d214 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"std/prelude/map" }>, align 8
@.d215 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"ents" }>, align 8
@.d216 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d217 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d218 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d219 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e20 = weak hidden constant i1 false
@.d220 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%k" }>, align 8
@.d221 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d222 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d223 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"h = lshr i32 " }>, align 8
@.d224 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", 16\0A  " }>, align 8
@.d225 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d226 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"h, " }>, align 8
@.d227 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d228 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d229 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d230 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d231 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d232 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d233 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"o = or i1 " }>, align 8
@.d234 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d235 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d236 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"o" }>, align 8
@.d237 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d238 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %take" }>, align 8
@.d239 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %pass" }>, align 8
@.d240 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Atake" }>, align 8
@.d241 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d242 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"pt" }>, align 8
@.d243 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d244 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_errpay_pop" }>, align 8
@.d245 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"  br i1 " }>, align 8
@.d246 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", label %ptyes" }>, align 8
@.d247 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %ptno" }>, align 8
@.d248 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"\0Aptyes" }>, align 8
@.d249 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c":\0A  call void @__olang_errpay_pop()\0A" }>, align 8
@.d250 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"  br label %ptno" }>, align 8
@.d251 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Aptno" }>, align 8
@.d252 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d253 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hv" }>, align 8
@.d254 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c" = load { ptr, ptr }, ptr %f" }>, align 8
@.d255 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d256 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hc" }>, align 8
@.d257 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c" = extractvalue { ptr, ptr } %hv" }>, align 8
@.d258 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", 0\0A  %he" }>, align 8
@.d259 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 1\0A" }>, align 8
@.d260 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"ptr %he" }>, align 8
@.d261 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %ho" }>, align 8
@.d262 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" = alloca " }>, align 8
@.d263 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d264 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ho" }>, align 8
@.d265 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"__olang_prog_scope" }>, align 8
@.d266 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"@__olang_prog_scope = external thread_local(initialexec) global ptr" }>, align 8
@.d267 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%hs" }>, align 8
@.d268 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d269 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d270 = private constant <{ i64, [38 x i8] }> <{ i64 0, [38 x i8] c"g = load ptr, ptr @__olang_prog_scope\0A" }>, align 8
@.d271 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d272 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"g" }>, align 8
@.d273 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d274 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"d = load ptr, ptr %f" }>, align 8
@.d275 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A  " }>, align 8
@.d276 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"n = icmp eq ptr " }>, align 8
@.d277 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"d, null\0A" }>, align 8
@.d278 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d279 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" = select i1 " }>, align 8
@.d280 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"n, ptr " }>, align 8
@.d281 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"g, ptr " }>, align 8
@.d282 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"d\0A" }>, align 8
@.d283 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d284 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d285 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d286 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  call void %hc" }>, align 8
@.d287 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d288 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d289 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hr" }>, align 8
@.d290 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = call " }>, align 8
@.d291 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" %hc" }>, align 8
@.d292 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d293 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2eclauses_2elocal_2e43 = weak hidden constant i1 false
@.d294 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%hr" }>, align 8
@.d295 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hl" }>, align 8
@.d296 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" = load " }>, align 8
@.d297 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %ho" }>, align 8
@.d298 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d299 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%hl" }>, align 8
@.d300 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d301 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %hd" }>, align 8
@.d302 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d303 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"\0A  store " }>, align 8
@.d304 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d305 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", ptr %hd" }>, align 8
@.d306 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d307 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"c" }>, align 8
@.d308 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"  ret ptr null\0Apass" }>, align 8
@.d309 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d310 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d311 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@.d312 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", arg: " }>, align 8
@.d313 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d314 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"!" }>, align 8
@.d315 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c" = !DILocalVariable(name: \22" }>, align 8
@.d316 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@.d317 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c", scope: !" }>, align 8
@.d318 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", file: !" }>, align 8
@.d319 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", line: " }>, align 8
@.d320 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", type: !" }>, align 8
@.d321 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d322 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"llvm.dbg.declare" }>, align 8
@.d323 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"void @llvm.dbg.declare(metadata, metadata, metadata)" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e20 = weak hidden constant i1 false
@.d324 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%l" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2edeclareVars_2elocal_2e21 = weak hidden constant i1 false
@.d325 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"!DIExpression()" }>, align 8
@.d326 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%lp" }>, align 8
@.d327 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"!DIExpression(DW_OP_deref)" }>, align 8
@.d328 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"  store ptr null, ptr %lp" }>, align 8
@.d329 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d330 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"  call void @llvm.dbg.declare(metadata ptr " }>, align 8
@.d331 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", metadata !" }>, align 8
@.d332 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c", metadata " }>, align 8
@.d333 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d334 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e6 = weak hidden constant i1 false
@.d335 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"fpext " }>, align 8
@.d336 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d337 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" to double" }>, align 8
@.d338 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d339 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e8 = weak hidden constant i1 false
@.d340 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp ogt double " }>, align 8
@.d341 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", -1.0" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2efloatOverflows_2elocal_2e9 = weak hidden constant i1 false
@.d342 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp olt double " }>, align 8
@.d343 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d344 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp oge double " }>, align 8
@.d345 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d346 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp ogt double " }>, align 8
@.d347 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d348 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"fcmp olt double " }>, align 8
@.d349 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d350 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"and i1 " }>, align 8
@.d351 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d352 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"xor i1 " }>, align 8
@.d353 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", true" }>, align 8
@.d354 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"a destructor not found: " }>, align 8
@.d355 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"call void @" }>, align 8
@.d356 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"_rt(ptr %l" }>, align 8
@.d357 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c", ptr %home)" }>, align 8
@.d358 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_gen_let" }>, align 8
@.d359 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d360 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"call void @__olang_gen_let(ptr " }>, align 8
@.d361 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d362 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c", ptr %keep, i64 %n)" }>, align 8
@.d363 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_gen_count" }>, align 8
@.d364 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d365 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"call void @__olang_gen_count(ptr " }>, align 8
@.d366 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d367 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d368 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"getelementptr { i64, ptr }, ptr " }>, align 8
@.d369 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", i32 0, i32 0" }>, align 8
@.d370 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i64" }>, align 8
@.d371 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d372 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d373 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i32 0, i32 " }>, align 8
@.d374 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d375 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d376 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d377 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d378 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"gc" }>, align 8
@.d379 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d380 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d381 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" = phi i64 [ 0, %" }>, align 8
@.d382 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ], [ " }>, align 8
@.d383 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", %" }>, align 8
@.d384 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d385 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"icmp slt i64 " }>, align 8
@.d386 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d387 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d388 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d389 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d390 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d391 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" = add i64 " }>, align 8
@.d392 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d393 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d394 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d395 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d396 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"|" }>, align 8
@.d397 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"~" }>, align 8
@.d398 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"olang_loc_" }>, align 8
@.d399 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2elocated_2elocal_2e10 = weak hidden constant i1 false
@.d400 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d401 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" = weak_odr constant [" }>, align 8
@.d402 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" x i8] c\22" }>, align 8
@.d403 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\5C00\22\0A" }>, align 8
@.d404 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"windows" }>, align 8
@.d405 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@.d406 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" = comdat any\0A" }>, align 8
@.d407 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", comdat\0A" }>, align 8
@.d408 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d409 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c" = external constant [0 x i8]\0A" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33385783b00c3f13cf90b683d8670 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cstd_2fprelude_2ftext_3aString_26_2c_20st_Ha3f33285783aff10f13cf80b683d8c03 = weak hidden constant i1 false
@.d410 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d411 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aLvalue(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l5 = alloca i1
  %l8 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Lvalue", ptr %t1, i32 0, i32 0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/mir:Lvalue", ptr %t3, i32 0, i32 0
  %t7 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %t2, ptr %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb1
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/mir:Lvalue", ptr %t9, i32 0, i32 1
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Lvalue", ptr %t11, i32 0, i32 1
  %t15 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %t10, ptr %t12)
  store i1 %t15, ptr %l8
  br label %bb4
bb4:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb5, label %bb1
bb5:
  br label %bb6
bb6:
  %t17 = load i1, ptr %l2, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"compiler/mir:BasicBlock" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aBasicBlock(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:BasicBlock"
  %l3 = alloca %"compiler/mir:StmtList"
  %rv = alloca %"compiler/mir:BasicBlock"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:BasicBlock", ptr %a0
  store %"compiler/mir:BasicBlock" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  %t5 = call %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %t3)
  store %"compiler/mir:StmtList" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"compiler/mir:StmtList", ptr %l3
  %t7 = getelementptr %"compiler/mir:BasicBlock", ptr %l1, i32 0, i32 0
  store %"compiler/mir:StmtList" %t6, ptr %t7
  %t8 = load %"compiler/mir:BasicBlock", ptr %l1
  store %"compiler/mir:BasicBlock" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:BasicBlock", ptr %rv
  ret %"compiler/mir:BasicBlock" %rr
}

@.d412 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d413 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d414 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d415 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"rc" }>, align 8
@.d416 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne ptr " }>, align 8
@.d417 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", null" }>, align 8
@.d418 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d419 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i1" }>, align 8
@.d420 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"and i1 " }>, align 8
@.d421 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d422 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d423 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d424 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"getelementptr i8, ptr " }>, align 8
@.d425 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 -8" }>, align 8
@.d426 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"load atomic i64, ptr " }>, align 8
@.d427 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" monotonic, align 8" }>, align 8
@.d428 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d429 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"and i64 " }>, align 8
@.d430 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", 196608" }>, align 8
@.d431 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp eq i64 " }>, align 8
@.d432 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d433 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d434 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d435 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{ i64, ptr }" }>, align 8
@.d436 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e28 = weak hidden constant i1 false
@.d437 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d438 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" x ptr]" }>, align 8
@.d439 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"getelementptr [" }>, align 8
@.d440 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" x ptr], ptr " }>, align 8
@.d441 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d442 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store ptr " }>, align 8
@.d443 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d444 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d445 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-1" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e36 = weak hidden constant i1 false
@.d446 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d447 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" x ptr]" }>, align 8
@.d448 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"extractvalue { i64, ptr } " }>, align 8
@.d449 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d450 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"getelementptr [" }>, align 8
@.d451 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" x ptr], ptr " }>, align 8
@.d452 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", i64 0, i64 " }>, align 8
@.d453 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"store ptr " }>, align 8
@.d454 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2ereclaim_2elocal_2e37 = weak hidden constant i1 false
@.d455 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d456 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"i1" }>, align 8
@.d457 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"select i1 " }>, align 8
@.d458 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d459 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c", i64 -1" }>, align 8
@.d460 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_gen_reclaim" }>, align 8
@.d461 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"call void @__olang_gen_reclaim(ptr " }>, align 8
@.d462 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c", ptr @" }>, align 8
@.d463 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", ptr " }>, align 8
@.d464 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c", i64 " }>, align 8
@.d465 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d466 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d467 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"getelementptr " }>, align 8
@.d468 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c", ptr %prom, i32 0, i32 2" }>, align 8
@.d469 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"ptr" }>, align 8
@.d470 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d471 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d472 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d473 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d474 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d475 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" zeroinitializer, " }>, align 8
@.d476 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d477 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d478 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d479 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"call i8 @llvm.coro.suspend(token none, i1 false)" }>, align 8
@.d480 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"gen.res" }>, align 8
@.d481 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"gen.drop" }>, align 8
@.d482 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"switch i8 " }>, align 8
@.d483 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c", label %gen.end [ i8 0, label %" }>, align 8
@.d484 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" i8 1, label %" }>, align 8
@.d485 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d486 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d487 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d488 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d489 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d490 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"%v" }>, align 8
@.d491 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d492 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"__olang_bang_failed" }>, align 8
@.d493 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"__olang_bang_failed_plain" }>, align 8
@.d494 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"void @" }>, align 8
@.d495 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr)" }>, align 8
@.d496 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2femit__2ecompiler__2femit__3afnEm__2etaskEnds_2elocal_2e15 = weak hidden constant i1 false
@.d497 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %bq" }>, align 8
@.d498 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" = icmp eq i32 " }>, align 8
@.d499 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d500 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"\0A  br i1 %bq" }>, align 8
@.d501 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c", label %bang" }>, align 8
@.d502 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c", label %bnext" }>, align 8
@.d503 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"\0Abang" }>, align 8
@.d504 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d505 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d506 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d507 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d508 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d509 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c")\0A  unreachable\0Abnext" }>, align 8
@.d510 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c":\0A" }>, align 8
@.d511 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c": unhandled error\0A" }>, align 8
@.d512 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"  call void @" }>, align 8
@.d513 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"(ptr " }>, align 8
@.d514 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c")\0A  unreachable\0A" }>, align 8
@.d515 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"  %od" }>, align 8
@.d516 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" = load ptr, ptr %f" }>, align 8
@.d517 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"\0A  %old" }>, align 8
@.d518 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c" = load { i64, ptr }, ptr %od" }>, align 8
@.d519 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d520 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"unreachable" }>, align 8
@.d521 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d522 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d523 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d524 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"switch " }>, align 8
@.d525 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d526 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d527 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" [" }>, align 8
@.d528 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d529 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d530 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" ]" }>, align 8
@.d531 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"%out" }>, align 8
@.d532 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d533 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d534 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d535 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"void" }>, align 8
@.d536 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d537 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"0" }>, align 8
@.d538 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d539 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d540 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c" zeroinitializer, " }>, align 8
@.d541 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d542 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 1" }>, align 8
@.d543 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d544 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d545 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"br label %ret" }>, align 8
@.d546 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"br label %gen.free" }>, align 8
@.d547 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d548 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d549 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d550 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"insertvalue " }>, align 8
@.d551 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" zeroinitializer, i32 " }>, align 8
@.d552 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d553 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"%rv" }>, align 8
@.d554 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"br label %ret" }>, align 8
@.d555 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"__olang_join_tasks_keep" }>, align 8
@.d556 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"i64 @__olang_join_tasks_keep(ptr, i1)" }>, align 8
@.d557 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"true" }>, align 8
@.d558 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"false" }>, align 8
@.d559 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"call i64 @__olang_join_tasks_keep(ptr %jh" }>, align 8
@.d560 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c", i1 " }>, align 8
@.d561 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d562 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"trunc i64 " }>, align 8
@.d563 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d564 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"br label %" }>, align 8
@.d565 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"i32" }>, align 8
@.d566 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"icmp ne i32 " }>, align 8
@.d567 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", 0" }>, align 8
@.d568 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"br i1 " }>, align 8
@.d569 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c", label %" }>, align 8
@.d570 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"a cleanup (interpret's)" }>, align 8
@.d571 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"zext i16 " }>, align 8
@.d572 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" to i32" }>, align 8
@.d573 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"shl i32 " }>, align 8
@.d574 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c", 16" }>, align 8
@.d575 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"bitcast i32 " }>, align 8
@.d576 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" to float" }>, align 8
@.d577 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"float" }>, align 8
@.d578 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"fpext float " }>, align 8
@.d579 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" to " }>, align 8
@olang_2esole_2ecompiler_2femit_3acDecls_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
@olang_2esole_2ecompiler_2femit_3acDecls_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2femit_3acDecls_2e2 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2femit_3acDecls_2e3 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aStr_H4eff2894ad89de6e140d6d54faebb689(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@.d580 = private unnamed_addr constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"typed.ContractKind.Req" }>, align 8
declare ptr @__olang_sb_grow(ptr, i64) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aBase(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 3}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 3}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb6, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64, i32, i32 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64, i32, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb7, label %bb1
bb6:
  br label %bb3
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i64, i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i64, i32, i32 }, ptr %t39, i32 0, i32 1
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb8, label %bb1
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64, i32, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64, i32, i32 }, ptr %t51, i32 0, i32 2
  %t53 = load i32, ptr %t52
  %t56 = icmp eq i32 %t49, %t53
  br i1 %t56, label %bb9, label %bb1
bb9:
  br label %bb3
bb10:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2fmir_3aRange(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = getelementptr %"compiler/mir:Range", ptr %t1, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/mir:Range", ptr %t4, i32 0, i32 0
  %t6 = load i32, ptr %t5, !tbaa !23
  %t9 = icmp eq i32 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb4
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Range", ptr %t11, i32 0, i32 1
  %t13 = load i32, ptr %t12, !tbaa !23
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/mir:Range", ptr %t14, i32 0, i32 1
  %t16 = load i32, ptr %t15, !tbaa !23
  %t19 = icmp eq i32 %t13, %t16
  br i1 %t19, label %bb3, label %bb1
bb3:
  br label %bb4
bb4:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"compiler/mir:StmtList" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2fmir_3aStmtList(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:StmtList"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/mir:StmtList"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/mir:StmtList", ptr %a0
  store %"compiler/mir:StmtList" %t2, ptr %l1
  %t3 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 176
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 176
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/mir:StmtList", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/mir:StmtList", ptr %l1
  store %"compiler/mir:StmtList" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:StmtList", ptr %rv
  ret %"compiler/mir:StmtList" %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanonList(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2eSymbol(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etestSym(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etableName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_de1fe604fb5e87cf_ff4728625cff78d3 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"compiler/cabi:Regs" @compiler_2fcabi_3aRegs_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eabiArch(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/cabi:Way" @compiler_2fcabi_2eWay_2eResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecParamSpelled(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, i1 %a3)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePayloadOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgNew(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgShared(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eerrQualifier(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWordName(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2eescape(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgTypeName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgBasic(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_b200df0f2ca52fe9_68c86c80ca4bbd4d = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2eDemangle(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ereadableTypes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgSubTy(ptr %v0, ptr %a0)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgCu(ptr %v0, ptr %a0)
@olang_loc_e7f1f4c1c7eb01fc_51bf614425d25b70 = external constant [0 x i8]
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edefine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eruntime(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esanInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2edeclare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobalOrder(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2e_H901ad831a5883703dcf426ee01511832(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2esym(ptr %v0, ptr %v1, ptr %a0, { i64, [2 x i64] } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2eitem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecstr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2etraced(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExternSymbol(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2emathIntrinsic(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2ehas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eexternRet(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ecHeader(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2femit_2emathInexact = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [24 x i8] }>
@olang_loc_672626b841abebed_e9d6bd273cfd5371 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenBufName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2femit_2eHomeShared = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare ptr @compiler_2flower_2ecompiler_2flower_3aLowerer_2eGen(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eHasLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenOkName(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eGenRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_1cb2b0b1c80ab6bb_ff3b7bcb0dec81bf = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eisLambda(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_dd4469a9ae312a3a_602f574df5758ebe = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2econstText(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eposition(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2elocalType(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2eglobal(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2egap(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
@olang_loc_a45e6d34f8d75be7_fb9ba052a05cfc3b = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aProj_3e_2eAt_3ccompiler_2fmir_3aProj_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2efieldList(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ety(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2elet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2etbaa(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eload(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2erunTime(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2edescTag(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i1 %a2)
declare { { i64, ptr }, i32 } @compiler_2femit_2ecompiler_2femit_3afnEm_2eelemAt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2ecasesList(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_f0091f918c975106_bc2d594a86836fba = external constant [0 x i8]
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2ealign(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2esize(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ealloca(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare %"compiler/mir:TaskClause" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTaskClause_3e_2eAt_3ccompiler_2fmir_3aTaskClause_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Item" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eAt_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2femit_2ecompiler_2femit_3afnEm_2eotype(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [4 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2esignature(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eViaMemory(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fmir_2ePassedCount(ptr %v0, ptr %a0, { i64, [7 x i64] } %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRetLlvm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2estoreParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etaskFix(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgFile(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eLen_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3aEmitter_2edbgType(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2escopeAt(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgBlockOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2eisFrame(ptr %v0, ptr %a0, { i64, [1 x i64] } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2edbgLine(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e__H165e1ff795edcbb725e28dde18fd1dc2(ptr %v0, ptr %a0, i32 %a1)
declare { i32, { i64, [2 x i64] } } @compiler_2fmir_2eFnKey_2eDropFn(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewant(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_He6968003b8dd5762fa82ec44b4ee1fc9(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ew(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eholdsGen(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2egenDropFn(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixed(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2femit_2ecompiler_2femit_3afnEm_2efixedLen(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2femit_2ecompiler_2femit_3aEmitter_2eenumWords(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eholdersCases(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2efresh(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elabel(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2etmp(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3aEmitter_2ewhere(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_Ha4444909f5ef14f7626d25b8f59e6ba2(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eHash(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU64_2eFormat(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_6a1c0f36bb2af484_15693b919ea68168 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H9b83f66eba65594537030636cb0b52b7(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_7bda3904fb775f6e_cd0d5260ae61bcf2 = external constant [0 x i8]
@G_2ecompiler_2femit_2eHomeLoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FC\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@olang_loc_d93074814994636b_bdb833f18b1c6fff = external constant [0 x i8]
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eLvalue_2eL(i32 %a0)
@olang_loc_73776ce6ec0034aa_c594c414c7ca39fe = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eLen_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eLen(ptr %v0, ptr %a0)
declare { i64, [21 x i64] } @compiler_2fmir_2ecompiler_2fmir_3aStmtList_2eAt(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eClear_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eMentions(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eTermMentions(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [8 x i64] } %a1, ptr %a2, ptr %a3)
@olang_loc_768769e499c57657_c453ba5dc43e6f8b = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2eval(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, [4 x i64] } %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ector(ptr %v0, i64 %a0)
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2ePush_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, { i64, [4 x i64] } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eLen_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0)
declare %"compiler/mir:ScopeInfo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeInfo_3e_2eAt_3ccompiler_2fmir_3aScopeInfo_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPush(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i1 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eput(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, [4 x i64] } %a3, { i64, ptr } %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_97d51a883f8cc986_4828fb3e43690a82 = external constant [0 x i8]
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eunwindPop(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2femit_2eblockName(ptr %v0, i32 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_a013fd5d1a1a0ecb_8946a3e4bb7adef = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2econstText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
@olang_loc_625291c18633ca8a_b2d4e63a7cb7312e = external constant [0 x i8]
declare i1 @compiler_2femit_2ecompiler_2femit_3afnEm_2evalueTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2elocate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare %"compiler/mir:Case" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCase_3e_2eAt_3ccompiler_2fmir_3aCase_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etailCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/mir:Call" %a1)
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2etrace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare void @compiler_2femit_2ecompiler_2femit_3afnEm_2eexit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, [4 x i64] } %a3)
@olang_loc_7633dd9d24c54174_280dfd74a77e9550 = external constant [0 x i8]
declare { i64, ptr } @compiler_2femit_2ecompiler_2femit_3afnEm_2ebf16Bits(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
@olang_loc_a69d5bfe0a165b0_62b4fff2e0b246dc = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
