; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/free:feedCall" = type { i64, i64, i64, i64, i64, i1 }
%"compiler/free:feed" = type { i64, i64, i64, i64, { i64, [2 x i64] }, { i64, [2 x i64] }, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32 }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l4, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l3, !tbaa !29
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l15, !tbaa !24
  %t24 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %t18)
  store i64 %t24, ptr %l18
  br label %bb7
bb7:
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = load i64, ptr %l18, !tbaa !24
  %t27 = add i64 %t25, %t26
  store i64 %t27, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  %t29 = load i64, ptr %l4, !tbaa !24
  %t31 = add i64 %t29, 1
  store i64 %t31, ptr %l4, !tbaa !24
  br label %bb1
bb9:
  %t33 = load i64, ptr %l2, !tbaa !24
  store i64 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDecide(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l6 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca i64
  %l63 = alloca ptr
  %l67 = alloca i64
  %l69 = alloca i1
  %l78 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l79 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i32
  %l84 = alloca i1
  %l91 = alloca %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l97 = alloca i1
  %l98 = alloca i64
  %l99 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l105 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i1
  %l113 = alloca i64
  %l116 = alloca i64
  %l145 = alloca i64
  %l148 = alloca i64
  %l171 = alloca ptr
  %l176 = alloca ptr
  %l180 = alloca ptr
  %l190 = alloca i64
  %l196 = alloca i64
  %l199 = alloca i64
  %l220 = alloca ptr
  %l229 = alloca i64
  %l232 = alloca { i64, ptr }
  %l237 = alloca i64
  %l240 = alloca { i64, ptr }
  %l242 = alloca i64
  %l248 = alloca i64
  %l251 = alloca i64
  %l275 = alloca i64
  %l276 = alloca i64
  %l279 = alloca i64
  %l280 = alloca i64
  %l283 = alloca ptr
  %l284 = alloca i64
  %l287 = alloca i64
  %l306 = alloca i64
  %l309 = alloca i64
  %l331 = alloca i64
  %l336 = alloca i64
  %l339 = alloca i64
  %l361 = alloca i64
  %l362 = alloca ptr
  %l364 = alloca i1
  %l373 = alloca i64
  %l376 = alloca ptr
  %l380 = alloca i64
  %l383 = alloca i64
  %l386 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s32 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l54, !tbaa !29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1, ptr %l55
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %l55)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l57
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t6 = load ptr, ptr %l54, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t7
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 7
  store i64 %t9, ptr %t12, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 1
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t15)
  store i64 %t17, ptr %l62
  br label %bb2
bb2:
  %t18 = load i64, ptr %l62, !tbaa !24
  store i64 %t18, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l63, !tbaa !29
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 5
  %t27 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l67
  br label %bb3
bb3:
  %t28 = load i64, ptr %l67, !tbaa !24
  %t29 = icmp sgt i64 %t28, 0
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 8
  %t34 = load i1, ptr %t33, !tbaa !21
  %t36 = xor i1 %t34, true
  store i1 %t36, ptr %l69, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb6
bb6:
  %t38 = load i1, ptr %l69, !tbaa !21
  %t39 = load ptr, ptr %l63, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 27
  store i1 %t38, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:Free", ptr %t41, i32 0, i32 27
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 0
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 5
  %t53 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3054d603499f3fef5e3f6df62ca84cee(ptr %v0, ptr %v0, ptr %t51)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t53, ptr %l78
  br label %bb9
bb8:
  br label %bb29
bb9:
  %t54 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l78
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t54, ptr %l4
  br label %bb10
bb10:
  %t56 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20std_2fprelude_2ftext_3_H9d7da39dd81a932fb2b877accbcd070c(ptr %v0, ptr %l4)
  %t57 = extractvalue { i32, i64 } %t56, 1
  %t58 = extractvalue { i32, i64 } %t56, 0
  store i32 %t58, ptr %l82
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb12, label %ok.60, !prof !99
ok.60:
  store i64 %t57, ptr %l81
  br label %bb11
bb11:
  %t61 = load i64, ptr %l81, !tbaa !24
  store i64 %t61, ptr %l79, !tbaa !24
  br label %bb14
bb12:
  %t62 = load i32, ptr %l82, !tbaa !23
  %t63 = ashr i32 %t62, 16
  %t65 = icmp eq i32 %t63, 1
  store i1 %t65, ptr %l84, !tbaa !21
  br label %bb13
bb13:
  br label %bb17
bb14:
  %t66 = load i64, ptr %l79, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:Free", ptr %t67, i32 0, i32 28
  %t70 = getelementptr %"compiler/mir:GenInfo", ptr %t69, i32 0, i32 0
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t70, i64 %t66, i1 true)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %bb10
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 7
  %t81 = call %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hc20348a7e3f4966d079d7d53957fcef1(ptr %v0, ptr %v0, ptr %t79)
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t81, ptr %l91
  br label %bb18
bb18:
  %t82 = load %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l91
  store %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" %t82, ptr %l6
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H25a1fa74df5469e35efe3ff4130517ef(ptr %v0, ptr %s5, ptr %l6)
  %t85 = extractvalue { i32, { i64, ptr } } %t84, 1
  %t86 = extractvalue { i32, { i64, ptr } } %t84, 0
  store i32 %t86, ptr %l95
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb21, label %ok.88, !prof !99
ok.88:
  store { i64, ptr } %t85, ptr %l94
  br label %bb20
bb20:
  %t89 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 0
  store i64 %t90, ptr %l98, !tbaa !24
  %t91 = load i64, ptr %l98, !tbaa !24
  %t92 = mul i64 %t91, 1
  %t93 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l99, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l98, !tbaa !24
  %t101 = mul i64 %t100, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t97, ptr %t99, i64 %t101, i1 false)
  %t102 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t102, ptr %l92, !tbaa !27
  br label %bb23
bb21:
  %t103 = load i32, ptr %l95, !tbaa !23
  %t104 = ashr i32 %t103, 16
  %t106 = icmp eq i32 %t104, 1
  store i1 %t106, ptr %l97, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb23:
  %t107 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:Free", ptr %t108, i32 0, i32 28
  %t111 = getelementptr %"compiler/mir:GenInfo", ptr %t110, i32 0, i32 1
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %t111, { i64, ptr } %t107, i1 true)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  br label %bb19
bb26:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l103, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:Free", ptr %t116, i32 0, i32 28
  store ptr %t118, ptr %l105, !tbaa !29
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t119)
  store ptr %t121, ptr %l107
  br label %bb27
bb27:
  %t122 = load ptr, ptr %l105, !tbaa !29
  %t123 = load ptr, ptr %l107, !tbaa !29
  %t124 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eAnyLeaves(ptr %v0, ptr %v0, ptr %t122, ptr %t123)
  store i1 %t124, ptr %l108
  br label %bb28
bb28:
  %t125 = load i1, ptr %l108, !tbaa !21
  %t126 = load ptr, ptr %l103, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t126, i32 0, i32 46
  store i1 %t125, ptr %t127, !tbaa !21
  br label %bb29
bb29:
  store i64 0, ptr %l8, !tbaa !24
  %t128 = load i64, ptr %l3, !tbaa !24
  store i64 %t128, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l8, !tbaa !24
  %t134 = icmp sgt i64 %t130, %t131
  br i1 %t134, label %bb30, label %bb31
bb30:
  %t136 = load i64, ptr %l10, !tbaa !24
  %t138 = icmp sgt i64 %t136, 0
  br i1 %t138, label %bb32, label %bb33
bb31:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb35
bb32:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  %t144 = sub i64 %t140, %t141
  %t145 = load i64, ptr %l10, !tbaa !24
  %t148 = add i64 %t144, %t145
  %t150 = sub i64 %t148, 1
  %t151 = load i64, ptr %l10, !tbaa !24
  %t154 = sdiv i64 %t150, %t151
  store i64 %t154, ptr %l116, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l116, !tbaa !24
  br label %bb34
bb34:
  %t156 = load i64, ptr %l116, !tbaa !24
  store i64 %t156, ptr %l113, !tbaa !24
  br label %bb35
bb35:
  %t157 = load i64, ptr %l113, !tbaa !24
  store i64 %t157, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb36
bb36:
  %t158 = load i64, ptr %l12, !tbaa !24
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = icmp slt i64 %t158, %t159
  %t164 = xor i1 %t162, true
  br i1 %t164, label %bb37, label %bb38
bb37:
  br label %bb42
bb38:
  br label %bb39
bb39:
  %t166 = load i64, ptr %l8, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l10, !tbaa !24
  %t171 = mul i64 %t167, %t168
  %t174 = add i64 %t166, %t171
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eaddBody(ptr %v0, ptr %t176, i64 %t174, i64 %t178)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t182 = load i64, ptr %l12, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l12, !tbaa !24
  br label %bb36
bb42:
  %t186 = load i64, ptr %l2, !tbaa !24
  %t188 = icmp slt i64 %t186, 0
  br i1 %t188, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb44:
  br label %bb45
bb45:
  store i64 0, ptr %l14, !tbaa !24
  %t190 = load i64, ptr %l3, !tbaa !24
  store i64 %t190, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t193 = load i64, ptr %l14, !tbaa !24
  %t196 = icmp sgt i64 %t192, %t193
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = icmp sgt i64 %t198, 0
  br i1 %t200, label %bb48, label %bb49
bb47:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb51
bb48:
  %t202 = load i64, ptr %l15, !tbaa !24
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = sub i64 %t202, %t203
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = add i64 %t206, %t207
  %t212 = sub i64 %t210, 1
  %t213 = load i64, ptr %l16, !tbaa !24
  %t216 = sdiv i64 %t212, %t213
  store i64 %t216, ptr %l148, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb50
bb50:
  %t218 = load i64, ptr %l148, !tbaa !24
  store i64 %t218, ptr %l145, !tbaa !24
  br label %bb51
bb51:
  %t219 = load i64, ptr %l145, !tbaa !24
  store i64 %t219, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb52
bb52:
  %t220 = load i64, ptr %l18, !tbaa !24
  %t221 = load i64, ptr %l17, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  %t226 = xor i1 %t224, true
  br i1 %t226, label %bb53, label %bb54
bb53:
  br label %bb66
bb54:
  br label %bb55
bb55:
  %t228 = load i64, ptr %l14, !tbaa !24
  %t229 = load i64, ptr %l18, !tbaa !24
  %t230 = load i64, ptr %l16, !tbaa !24
  %t233 = mul i64 %t229, %t230
  %t236 = add i64 %t228, %t233
  store i64 %t236, ptr %l19, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i64, ptr %l19, !tbaa !24
  %t242 = getelementptr %"compiler/free:Free", ptr %t238, i32 0, i32 114
  store i64 %t239, ptr %t242, !tbaa !24
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/free:Free", ptr %t243, i32 0, i32 1
  %t246 = load i64, ptr %l19, !tbaa !24
  %t249 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t245, i64 %t246)
  store ptr %t249, ptr %l171
  br label %bb56
bb56:
  %t250 = load ptr, ptr %l171, !tbaa !29
  %t252 = getelementptr %"compiler/typed:Body", ptr %t250, i32 0, i32 11
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = icmp eq ptr %t253, null
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb57, label %bb58
bb57:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l176, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/free:Free", ptr %t260, i32 0, i32 1
  %t263 = load i64, ptr %l19, !tbaa !24
  %t266 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t262, i64 %t263)
  store ptr %t266, ptr %l180
  br label %bb59
bb58:
  br label %bb64
bb59:
  %t267 = load ptr, ptr %l180, !tbaa !29
  %t269 = getelementptr %"compiler/typed:Body", ptr %t267, i32 0, i32 11
  %t270 = load ptr, ptr %t269, !tbaa !29
  store ptr %t270, ptr %l20, !tbaa !29
  %t272 = load ptr, ptr %l20, !tbaa !29
  %t274 = icmp eq ptr %t272, null
  br i1 %t274, label %bb60, label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_873f02c5d3f91a6b_c0b0bcdb30583717)
  unreachable
bb61:
  br label %bb62
bb62:
  %t276 = load ptr, ptr %l20, !tbaa !29
  %t277 = load ptr, ptr %l176, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v0, ptr %t277, ptr %t276)
  br label %bb63
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t279 = load i64, ptr %l18, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l18, !tbaa !24
  br label %bb52
bb66:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/free:Free", ptr %t283, i32 0, i32 9
  %t287 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t285)
  store i64 %t287, ptr %l190
  br label %bb67
bb67:
  %t288 = load i64, ptr %l190, !tbaa !24
  %t289 = icmp eq i64 %t288, 0
  br i1 %t289, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb69:
  br label %bb70
bb70:
  store i64 0, ptr %l21, !tbaa !24
  %t291 = load i64, ptr %l3, !tbaa !24
  store i64 %t291, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t293 = load i64, ptr %l22, !tbaa !24
  %t294 = load i64, ptr %l21, !tbaa !24
  %t297 = icmp sgt i64 %t293, %t294
  br i1 %t297, label %bb71, label %bb72
bb71:
  %t299 = load i64, ptr %l23, !tbaa !24
  %t301 = icmp sgt i64 %t299, 0
  br i1 %t301, label %bb73, label %bb74
bb72:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb76
bb73:
  %t303 = load i64, ptr %l22, !tbaa !24
  %t304 = load i64, ptr %l21, !tbaa !24
  %t307 = sub i64 %t303, %t304
  %t308 = load i64, ptr %l23, !tbaa !24
  %t311 = add i64 %t307, %t308
  %t313 = sub i64 %t311, 1
  %t314 = load i64, ptr %l23, !tbaa !24
  %t317 = sdiv i64 %t313, %t314
  store i64 %t317, ptr %l199, !tbaa !24
  br label %bb75
bb74:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb75
bb75:
  %t319 = load i64, ptr %l199, !tbaa !24
  store i64 %t319, ptr %l196, !tbaa !24
  br label %bb76
bb76:
  %t320 = load i64, ptr %l196, !tbaa !24
  store i64 %t320, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb77
bb77:
  %t321 = load i64, ptr %l25, !tbaa !24
  %t322 = load i64, ptr %l24, !tbaa !24
  %t325 = icmp slt i64 %t321, %t322
  %t327 = xor i1 %t325, true
  br i1 %t327, label %bb78, label %bb79
bb78:
  br label %bb87
bb79:
  br label %bb80
bb80:
  %t329 = load i64, ptr %l21, !tbaa !24
  %t330 = load i64, ptr %l25, !tbaa !24
  %t331 = load i64, ptr %l23, !tbaa !24
  %t334 = mul i64 %t330, %t331
  %t337 = add i64 %t329, %t334
  store i64 %t337, ptr %l26, !tbaa !24
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/free:Free", ptr %t339, i32 0, i32 1
  %t342 = load i64, ptr %l26, !tbaa !24
  %t345 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t341, i64 %t342)
  store ptr %t345, ptr %l220
  br label %bb81
bb81:
  %t346 = load ptr, ptr %l220, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Body", ptr %t346, i32 0, i32 11
  %t349 = load ptr, ptr %t348, !tbaa !29
  %t351 = icmp eq ptr %t349, null
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb82, label %bb83
bb82:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i64, ptr %l26, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindFeeds(ptr %v0, ptr %t355, i64 %t356)
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t359 = load i64, ptr %l25, !tbaa !24
  %t361 = add i64 %t359, 1
  store i64 %t361, ptr %l25, !tbaa !24
  br label %bb77
bb87:
  %t363 = call i64 @std_2ftime_2eNow()
  store i64 %t363, ptr %l229
  br label %bb88
bb88:
  %t364 = load i64, ptr %l229, !tbaa !24
  store i64 %t364, ptr %l27, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/free:Free", ptr %t365, i32 0, i32 2
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t370 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %s0, ptr %t368)
  store { i64, ptr } %t370, ptr %l232
  br label %bb89
bb89:
  %t371 = load { i64, ptr }, ptr %l232, !tbaa !27
  store { i64, ptr } %t371, ptr %l28, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = load i64, ptr %l3, !tbaa !24
  %t378 = icmp ne i64 %t374, %t375
  br i1 %t378, label %bb90, label %bb91
bb90:
  %t380 = load i64, ptr %l3, !tbaa !24
  store i64 %t380, ptr %l237, !tbaa !24
  %t381 = load i64, ptr %l237, !tbaa !24
  %t382 = icmp sge i64 %t381, 0
  br i1 %t382, label %bb92, label %bb93
bb91:
  br label %bb111
bb92:
  %t384 = load i64, ptr %l237, !tbaa !24
  %t385 = icmp sle i64 %t384, 1152921504606846975
  br i1 %t385, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0)
  unreachable
bb94:
  %t387 = load i64, ptr %l237, !tbaa !24
  %t388 = mul i64 %t387, 8
  %t389 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t388)
  %t390 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  store { i64, ptr } %t391, ptr %l240, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 0
  %t394 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 0
  store i64 %t395, ptr %l242, !tbaa !24
  %t397 = load i64, ptr %l242, !tbaa !24
  %t398 = icmp eq i64 %t393, %t397
  br i1 %t398, label %bb96, label %bb97
bb95:
  call void @__olang_check_failed(ptr @olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0)
  unreachable
bb96:
  %t400 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = load i64, ptr %l242, !tbaa !24
  %t405 = mul i64 %t404, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t401, ptr %t403, i64 %t405, i1 false)
  br label %bb98
bb97:
  %t406 = load { i64, ptr }, ptr %l240, !tbaa !27
  store { i64, ptr } %t406, ptr %l28, !tbaa !27
  br label %bb98
bb98:
  store i64 0, ptr %l29, !tbaa !24
  %t407 = load i64, ptr %l3, !tbaa !24
  store i64 %t407, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t409 = load i64, ptr %l30, !tbaa !24
  %t410 = load i64, ptr %l29, !tbaa !24
  %t413 = icmp sgt i64 %t409, %t410
  br i1 %t413, label %bb99, label %bb100
bb99:
  %t415 = load i64, ptr %l31, !tbaa !24
  %t417 = icmp sgt i64 %t415, 0
  br i1 %t417, label %bb101, label %bb102
bb100:
  store i64 0, ptr %l248, !tbaa !24
  br label %bb104
bb101:
  %t419 = load i64, ptr %l30, !tbaa !24
  %t420 = load i64, ptr %l29, !tbaa !24
  %t423 = sub i64 %t419, %t420
  %t424 = load i64, ptr %l31, !tbaa !24
  %t427 = add i64 %t423, %t424
  %t429 = sub i64 %t427, 1
  %t430 = load i64, ptr %l31, !tbaa !24
  %t433 = sdiv i64 %t429, %t430
  store i64 %t433, ptr %l251, !tbaa !24
  br label %bb103
bb102:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb103
bb103:
  %t435 = load i64, ptr %l251, !tbaa !24
  store i64 %t435, ptr %l248, !tbaa !24
  br label %bb104
bb104:
  %t436 = load i64, ptr %l248, !tbaa !24
  store i64 %t436, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb105
bb105:
  %t437 = load i64, ptr %l33, !tbaa !24
  %t438 = load i64, ptr %l32, !tbaa !24
  %t441 = icmp slt i64 %t437, %t438
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb106, label %bb107
bb106:
  br label %bb110
bb107:
  br label %bb108
bb108:
  %t445 = load i64, ptr %l29, !tbaa !24
  %t446 = load i64, ptr %l33, !tbaa !24
  %t447 = load i64, ptr %l31, !tbaa !24
  %t450 = mul i64 %t446, %t447
  %t453 = add i64 %t445, %t450
  store i64 %t453, ptr %l34, !tbaa !24
  %t455 = load i64, ptr %l34, !tbaa !24
  %t456 = load i64, ptr %l34, !tbaa !24
  %t459 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !27
  %t461 = getelementptr i64, ptr %t460, i64 %t455
  store i64 %t456, ptr %t461, !tbaa !34
  br label %bb109
bb109:
  %t462 = load i64, ptr %l33, !tbaa !24
  %t464 = add i64 %t462, 1
  store i64 %t464, ptr %l33, !tbaa !24
  br label %bb105
bb110:
  br label %bb111
bb111:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t470 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustFixedPoint(ptr %v0, ptr %s0, ptr %t466, { i64, ptr } %t467)
  store i64 %t470, ptr %l275
  br label %bb112
bb112:
  %t471 = load i64, ptr %l275, !tbaa !24
  store i64 %t471, ptr %l35, !tbaa !24
  %t472 = call i64 @std_2ftime_2eNow()
  store i64 %t472, ptr %l276
  br label %bb113
bb113:
  %t473 = load i64, ptr %l276, !tbaa !24
  store i64 %t473, ptr %l36, !tbaa !24
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t475 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t478 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayFixedPoint(ptr %v0, ptr %s0, ptr %t474, { i64, ptr } %t475)
  store i64 %t478, ptr %l279
  br label %bb114
bb114:
  %t479 = load i64, ptr %l279, !tbaa !24
  store i64 %t479, ptr %l37, !tbaa !24
  %t480 = call i64 @std_2ftime_2eNow()
  store i64 %t480, ptr %l280
  br label %bb115
bb115:
  %t481 = load i64, ptr %l280, !tbaa !24
  store i64 %t481, ptr %l38, !tbaa !24
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/free:Free", ptr %t482, i32 0, i32 116
  %t485 = load i1, ptr %t484, !tbaa !21
  br i1 %t485, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s23
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l283, !tbaa !29
  %t488 = load i64, ptr %l3, !tbaa !24
  store i64 %t488, ptr %l284, !tbaa !24
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/free:Free", ptr %t489, i32 0, i32 9
  %t493 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t491)
  store i64 %t493, ptr %l287
  br label %bb118
bb117:
  br label %bb120
bb118:
  %t494 = load i64, ptr %l35, !tbaa !24
  %t495 = load i64, ptr %l36, !tbaa !24
  %t496 = load i64, ptr %l27, !tbaa !24
  %t499 = sub i64 %t495, %t496
  %t501 = sdiv i64 %t499, 1000000
  %t502 = load i64, ptr %l37, !tbaa !24
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t505 = getelementptr %"compiler/free:Free", ptr %t503, i32 0, i32 4
  %t506 = load i64, ptr %t505, !tbaa !24
  %t507 = load i64, ptr %l38, !tbaa !24
  %t508 = load i64, ptr %l36, !tbaa !24
  %t511 = sub i64 %t507, %t508
  %t513 = sdiv i64 %t511, 1000000
  %t514 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t515 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t516 = load i64, ptr %l284, !tbaa !24
  %t517 = call i64 @__olang_fmt_i64(ptr null, i64 %t516)
  %t518 = add i64 %t515, %t517
  %t519 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t522 = load i64, ptr %l287, !tbaa !24
  %t523 = call i64 @__olang_fmt_i64(ptr null, i64 %t522)
  %t524 = add i64 %t521, %t523
  %t525 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t527 = add i64 %t524, %t526
  %t529 = call i64 @__olang_fmt_i64(ptr null, i64 %t494)
  %t530 = add i64 %t527, %t529
  %t531 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t532 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t533 = add i64 %t530, %t532
  %t535 = call i64 @__olang_fmt_i64(ptr null, i64 %t501)
  %t536 = add i64 %t533, %t535
  %t537 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t539 = add i64 %t536, %t538
  %t541 = call i64 @__olang_fmt_i64(ptr null, i64 %t502)
  %t542 = add i64 %t539, %t541
  %t543 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t544 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t545 = add i64 %t542, %t544
  %t547 = call i64 @__olang_fmt_i64(ptr null, i64 %t506)
  %t548 = add i64 %t545, %t547
  %t549 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t550 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t551 = add i64 %t548, %t550
  %t553 = call i64 @__olang_fmt_i64(ptr null, i64 %t513)
  %t554 = add i64 %t551, %t553
  %t555 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t556 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t557 = add i64 %t554, %t556
  %t558 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t557)
  call void @olang_textcopy(ptr %t558, ptr %t514, i64 %t515)
  %t559 = getelementptr i8, ptr %t558, i64 %t515
  %t560 = call i64 @__olang_fmt_i64(ptr %t559, i64 %t516)
  %t561 = getelementptr i8, ptr %t559, i64 %t517
  call void @olang_textcopy(ptr %t561, ptr %t519, i64 %t520)
  %t562 = getelementptr i8, ptr %t561, i64 %t520
  %t563 = call i64 @__olang_fmt_i64(ptr %t562, i64 %t522)
  %t564 = getelementptr i8, ptr %t562, i64 %t523
  call void @olang_textcopy(ptr %t564, ptr %t525, i64 %t526)
  %t565 = getelementptr i8, ptr %t564, i64 %t526
  %t566 = call i64 @__olang_fmt_i64(ptr %t565, i64 %t494)
  %t567 = getelementptr i8, ptr %t565, i64 %t529
  call void @olang_textcopy(ptr %t567, ptr %t531, i64 %t532)
  %t568 = getelementptr i8, ptr %t567, i64 %t532
  %t569 = call i64 @__olang_fmt_i64(ptr %t568, i64 %t501)
  %t570 = getelementptr i8, ptr %t568, i64 %t535
  call void @olang_textcopy(ptr %t570, ptr %t537, i64 %t538)
  %t571 = getelementptr i8, ptr %t570, i64 %t538
  %t572 = call i64 @__olang_fmt_i64(ptr %t571, i64 %t502)
  %t573 = getelementptr i8, ptr %t571, i64 %t541
  call void @olang_textcopy(ptr %t573, ptr %t543, i64 %t544)
  %t574 = getelementptr i8, ptr %t573, i64 %t544
  %t575 = call i64 @__olang_fmt_i64(ptr %t574, i64 %t506)
  %t576 = getelementptr i8, ptr %t574, i64 %t547
  call void @olang_textcopy(ptr %t576, ptr %t549, i64 %t550)
  %t577 = getelementptr i8, ptr %t576, i64 %t550
  %t578 = call i64 @__olang_fmt_i64(ptr %t577, i64 %t513)
  %t579 = getelementptr i8, ptr %t577, i64 %t553
  call void @olang_textcopy(ptr %t579, ptr %t555, i64 %t556)
  %t580 = insertvalue { i64, ptr } undef, i64 %t557, 0
  %t581 = insertvalue { i64, ptr } %t580, ptr %t558, 1
  %t583 = extractvalue { i64, ptr } %t581, 0
  %t584 = extractvalue { i64, ptr } %t581, 1
  %t585 = mul i64 %t583, 1
  %t586 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t585)
  call void @llvm.memcpy.p0.p0.i64(ptr %t586, ptr %t584, i64 %t585, i1 false)
  %t587 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t588 = insertvalue { i64, ptr } %t587, ptr %t586, 1
  %t589 = load ptr, ptr %l283, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %s23, ptr %t589, { i64, ptr } %t588)
  br label %bb119
bb119:
  call void @__olang_scope_close(ptr %s23)
  br label %bb120
bb120:
  store i64 0, ptr %l39, !tbaa !24
  %t591 = load i64, ptr %l3, !tbaa !24
  store i64 %t591, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t593 = load i64, ptr %l40, !tbaa !24
  %t594 = load i64, ptr %l39, !tbaa !24
  %t597 = icmp sgt i64 %t593, %t594
  br i1 %t597, label %bb121, label %bb122
bb121:
  %t599 = load i64, ptr %l41, !tbaa !24
  %t601 = icmp sgt i64 %t599, 0
  br i1 %t601, label %bb123, label %bb124
bb122:
  store i64 0, ptr %l306, !tbaa !24
  br label %bb126
bb123:
  %t603 = load i64, ptr %l40, !tbaa !24
  %t604 = load i64, ptr %l39, !tbaa !24
  %t607 = sub i64 %t603, %t604
  %t608 = load i64, ptr %l41, !tbaa !24
  %t611 = add i64 %t607, %t608
  %t613 = sub i64 %t611, 1
  %t614 = load i64, ptr %l41, !tbaa !24
  %t617 = sdiv i64 %t613, %t614
  store i64 %t617, ptr %l309, !tbaa !24
  br label %bb125
bb124:
  store i64 0, ptr %l309, !tbaa !24
  br label %bb125
bb125:
  %t619 = load i64, ptr %l309, !tbaa !24
  store i64 %t619, ptr %l306, !tbaa !24
  br label %bb126
bb126:
  %t620 = load i64, ptr %l306, !tbaa !24
  store i64 %t620, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb127
bb127:
  %t621 = load i64, ptr %l43, !tbaa !24
  %t622 = load i64, ptr %l42, !tbaa !24
  %t625 = icmp slt i64 %t621, %t622
  %t627 = xor i1 %t625, true
  br i1 %t627, label %bb128, label %bb129
bb128:
  br label %bb133
bb129:
  br label %bb130
bb130:
  %t629 = load i64, ptr %l39, !tbaa !24
  %t630 = load i64, ptr %l43, !tbaa !24
  %t631 = load i64, ptr %l41, !tbaa !24
  %t634 = mul i64 %t630, %t631
  %t637 = add i64 %t629, %t634
  %t639 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehiddenLetGo(ptr %v0, ptr %t639, i64 %t637)
  br label %bb131
bb131:
  br label %bb132
bb132:
  %t643 = load i64, ptr %l43, !tbaa !24
  %t645 = add i64 %t643, 1
  store i64 %t645, ptr %l43, !tbaa !24
  br label %bb127
bb133:
  %t647 = call i64 @std_2ftime_2eNow()
  store i64 %t647, ptr %l331
  br label %bb134
bb134:
  %t648 = load i64, ptr %l331, !tbaa !24
  store i64 %t648, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  %t649 = load i64, ptr %l3, !tbaa !24
  store i64 %t649, ptr %l47, !tbaa !24
  store i64 1, ptr %l48, !tbaa !24
  %t651 = load i64, ptr %l47, !tbaa !24
  %t652 = load i64, ptr %l46, !tbaa !24
  %t655 = icmp sgt i64 %t651, %t652
  br i1 %t655, label %bb135, label %bb136
bb135:
  %t657 = load i64, ptr %l48, !tbaa !24
  %t659 = icmp sgt i64 %t657, 0
  br i1 %t659, label %bb137, label %bb138
bb136:
  store i64 0, ptr %l336, !tbaa !24
  br label %bb140
bb137:
  %t661 = load i64, ptr %l47, !tbaa !24
  %t662 = load i64, ptr %l46, !tbaa !24
  %t665 = sub i64 %t661, %t662
  %t666 = load i64, ptr %l48, !tbaa !24
  %t669 = add i64 %t665, %t666
  %t671 = sub i64 %t669, 1
  %t672 = load i64, ptr %l48, !tbaa !24
  %t675 = sdiv i64 %t671, %t672
  store i64 %t675, ptr %l339, !tbaa !24
  br label %bb139
bb138:
  store i64 0, ptr %l339, !tbaa !24
  br label %bb139
bb139:
  %t677 = load i64, ptr %l339, !tbaa !24
  store i64 %t677, ptr %l336, !tbaa !24
  br label %bb140
bb140:
  %t678 = load i64, ptr %l336, !tbaa !24
  store i64 %t678, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb141
bb141:
  %t679 = load i64, ptr %l50, !tbaa !24
  %t680 = load i64, ptr %l49, !tbaa !24
  %t683 = icmp slt i64 %t679, %t680
  %t685 = xor i1 %t683, true
  br i1 %t685, label %bb142, label %bb143
bb142:
  br label %bb147
bb143:
  br label %bb144
bb144:
  %t687 = load i64, ptr %l46, !tbaa !24
  %t688 = load i64, ptr %l50, !tbaa !24
  %t689 = load i64, ptr %l48, !tbaa !24
  %t692 = mul i64 %t688, %t689
  %t695 = add i64 %t687, %t692
  %t697 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %t697, i64 %t695, i1 true)
  br label %bb145
bb145:
  br label %bb146
bb146:
  %t701 = load i64, ptr %l50, !tbaa !24
  %t703 = add i64 %t701, 1
  store i64 %t703, ptr %l50, !tbaa !24
  br label %bb141
bb147:
  %t705 = call i64 @std_2ftime_2eNow()
  store i64 %t705, ptr %l361
  br label %bb148
bb148:
  %t706 = load i64, ptr %l361, !tbaa !24
  store i64 %t706, ptr %l52, !tbaa !24
  %t707 = load ptr, ptr %l0, !tbaa !29
  store ptr %t707, ptr %l362, !tbaa !29
  %t708 = load ptr, ptr %l0, !tbaa !29
  %t710 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachedTasks(ptr %v0, ptr %t708)
  store i1 %t710, ptr %l364
  br label %bb149
bb149:
  %t711 = load i1, ptr %l364, !tbaa !21
  %t712 = load ptr, ptr %l362, !tbaa !29
  %t713 = getelementptr %"compiler/free:Free", ptr %t712, i32 0, i32 78
  store i1 %t711, ptr %t713, !tbaa !21
  %t714 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenKeeps(ptr %v0, ptr %t714)
  br label %bb150
bb150:
  %t716 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %t716)
  br label %bb151
bb151:
  %t718 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eclassifyHolders(ptr %v0, ptr %t718)
  br label %bb152
bb152:
  %t720 = load ptr, ptr %l0, !tbaa !29
  %t722 = getelementptr %"compiler/free:Free", ptr %t720, i32 0, i32 27
  %t723 = load i1, ptr %t722, !tbaa !21
  br i1 %t723, label %bb153, label %bb154
bb153:
  %t725 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenDecide(ptr %v0, ptr %t725)
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb156
bb156:
  %t727 = load ptr, ptr %l0, !tbaa !29
  %t729 = getelementptr %"compiler/free:Free", ptr %t727, i32 0, i32 115
  store i1 true, ptr %t729, !tbaa !21
  %t730 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %t730)
  br label %bb157
bb157:
  %t732 = call i64 @std_2ftime_2eNow()
  store i64 %t732, ptr %l373
  br label %bb158
bb158:
  %t733 = load i64, ptr %l373, !tbaa !24
  store i64 %t733, ptr %l53, !tbaa !24
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = getelementptr %"compiler/free:Free", ptr %t734, i32 0, i32 116
  %t737 = load i1, ptr %t736, !tbaa !21
  br i1 %t737, label %bb159, label %bb160
bb159:
  store %olang.scope zeroinitializer, ptr %s32
  %t739 = load ptr, ptr %l0, !tbaa !29
  store ptr %t739, ptr %l376, !tbaa !29
  %t740 = load i64, ptr %l52, !tbaa !24
  %t741 = load i64, ptr %l45, !tbaa !24
  %t744 = sub i64 %t740, %t741
  %t746 = sdiv i64 %t744, 1000000
  store i64 %t746, ptr %l380, !tbaa !24
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t749 = getelementptr %"compiler/free:Free", ptr %t747, i32 0, i32 84
  %t751 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t749)
  store i64 %t751, ptr %l383
  br label %bb161
bb160:
  br label %bb164
bb161:
  %t752 = load ptr, ptr %l0, !tbaa !29
  %t754 = getelementptr %"compiler/free:Free", ptr %t752, i32 0, i32 83
  %t756 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t754)
  store i64 %t756, ptr %l386
  br label %bb162
bb162:
  %t757 = load i64, ptr %l53, !tbaa !24
  %t758 = load i64, ptr %l52, !tbaa !24
  %t761 = sub i64 %t757, %t758
  %t763 = sdiv i64 %t761, 1000000
  %t764 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t765 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t766 = load i64, ptr %l380, !tbaa !24
  %t767 = call i64 @__olang_fmt_i64(ptr null, i64 %t766)
  %t768 = add i64 %t765, %t767
  %t769 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t770 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t771 = add i64 %t768, %t770
  %t772 = load i64, ptr %l383, !tbaa !24
  %t773 = call i64 @__olang_fmt_i64(ptr null, i64 %t772)
  %t774 = add i64 %t771, %t773
  %t775 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t776 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t777 = add i64 %t774, %t776
  %t778 = load i64, ptr %l386, !tbaa !24
  %t779 = call i64 @__olang_fmt_i64(ptr null, i64 %t778)
  %t780 = add i64 %t777, %t779
  %t781 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t782 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t783 = add i64 %t780, %t782
  %t785 = call i64 @__olang_fmt_i64(ptr null, i64 %t763)
  %t786 = add i64 %t783, %t785
  %t787 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t788 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t789 = add i64 %t786, %t788
  %t790 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t789)
  call void @olang_textcopy(ptr %t790, ptr %t764, i64 %t765)
  %t791 = getelementptr i8, ptr %t790, i64 %t765
  %t792 = call i64 @__olang_fmt_i64(ptr %t791, i64 %t766)
  %t793 = getelementptr i8, ptr %t791, i64 %t767
  call void @olang_textcopy(ptr %t793, ptr %t769, i64 %t770)
  %t794 = getelementptr i8, ptr %t793, i64 %t770
  %t795 = call i64 @__olang_fmt_i64(ptr %t794, i64 %t772)
  %t796 = getelementptr i8, ptr %t794, i64 %t773
  call void @olang_textcopy(ptr %t796, ptr %t775, i64 %t776)
  %t797 = getelementptr i8, ptr %t796, i64 %t776
  %t798 = call i64 @__olang_fmt_i64(ptr %t797, i64 %t778)
  %t799 = getelementptr i8, ptr %t797, i64 %t779
  call void @olang_textcopy(ptr %t799, ptr %t781, i64 %t782)
  %t800 = getelementptr i8, ptr %t799, i64 %t782
  %t801 = call i64 @__olang_fmt_i64(ptr %t800, i64 %t763)
  %t802 = getelementptr i8, ptr %t800, i64 %t785
  call void @olang_textcopy(ptr %t802, ptr %t787, i64 %t788)
  %t803 = insertvalue { i64, ptr } undef, i64 %t789, 0
  %t804 = insertvalue { i64, ptr } %t803, ptr %t790, 1
  %t806 = extractvalue { i64, ptr } %t804, 0
  %t807 = extractvalue { i64, ptr } %t804, 1
  %t808 = mul i64 %t806, 1
  %t809 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t808)
  call void @llvm.memcpy.p0.p0.i64(ptr %t809, ptr %t807, i64 %t808, i1 false)
  %t810 = insertvalue { i64, ptr } undef, i64 %t806, 0
  %t811 = insertvalue { i64, ptr } %t810, ptr %t809, 1
  %t812 = load ptr, ptr %l376, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %s32, ptr %t812, { i64, ptr } %t811)
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s32)
  br label %bb164
bb164:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eGenOkNow(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 42
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 115
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp2
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %t15, i32 %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l10
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePlaceValue(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i32
  %l14 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 15
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 15
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t18, i64 %t19)
  store i32 %t22, ptr %l14
  br label %bb7
bb6:
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t23, ptr %l10, !tbaa !23
  br label %bb8
bb7:
  %t25 = load i32, ptr %l14, !tbaa !23
  store i32 %t25, ptr %l10, !tbaa !23
  br label %bb8
bb8:
  %t26 = load i32, ptr %l10, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load i32, ptr %l3, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i64
  %l25 = alloca i32
  %l27 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l48 = alloca i64
  %l66 = alloca i64
  %l73 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 1
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t8, i64 %a1)
  store ptr %t12, ptr %l16
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l16, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 1
  %t16 = load { i64, [2 x i64] }, ptr %t15
  store { i64, [2 x i64] } %t16, ptr %l3
  %t18 = load { i64, [2 x i64] }, ptr %l3
  %t20 = extractvalue { i64, [2 x i64] } %t18, 0
  %t21 = icmp eq i64 %t20, 0
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  store i64 %t25, ptr %l4, !tbaa !24
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t27, i64 %t28)
  store i32 %t31, ptr %l25
  br label %bb5
bb5:
  %t32 = load i32, ptr %l25, !tbaa !23
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb6, label %bb7
bb6:
  store i64 -3, ptr %l27, !tbaa !24
  br label %bb10
bb7:
  %t35 = load ptr, ptr %l2, !tbaa !29
  store ptr %t35, ptr %l28, !tbaa !29
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l31
  br label %bb8
bb8:
  %t41 = load ptr, ptr %l28, !tbaa !29
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t43, ptr %l32
  br label %bb9
bb9:
  %t44 = load i64, ptr %l32, !tbaa !24
  store i64 %t44, ptr %l27, !tbaa !24
  br label %bb10
bb10:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l19, !tbaa !24
  br label %bb51
bb11:
  %t46 = load { i64, [2 x i64] }, ptr %l3
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t52 = getelementptr { i32, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l5, !tbaa !23
  %t55 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t56 = getelementptr { i32, i32 }, ptr %t55, i32 0, i32 1
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t59 = load i32, ptr %l6, !tbaa !23
  %t61 = icmp ne i32 %t59, 0
  br i1 %t61, label %bb15, label %bb16
bb15:
  store i64 -3, ptr %l39, !tbaa !24
  br label %bb18
bb16:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %t63, i32 %t64)
  store i64 %t67, ptr %l42
  br label %bb17
bb17:
  %t68 = load i64, ptr %l42, !tbaa !24
  store i64 %t68, ptr %l39, !tbaa !24
  br label %bb18
bb18:
  %t69 = load i64, ptr %l39, !tbaa !24
  store i64 %t69, ptr %l19, !tbaa !24
  br label %bb51
bb19:
  %t70 = load { i64, [2 x i64] }, ptr %l3
  %t72 = extractvalue { i64, [2 x i64] } %t70, 0
  %t73 = icmp eq i64 %t72, 3
  br i1 %t73, label %bb20, label %bb21
bb20:
  %t75 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t76 = getelementptr { i32 }, ptr %t75, i32 0, i32 0
  %t77 = load i32, ptr %t76
  store i32 %t77, ptr %l7, !tbaa !23
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i32, ptr %l7, !tbaa !23
  %t83 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %t79, i32 %t80)
  store i64 %t83, ptr %l48
  br label %bb23
bb23:
  %t84 = load i64, ptr %l48, !tbaa !24
  store i64 %t84, ptr %l19, !tbaa !24
  br label %bb51
bb24:
  %t85 = load { i64, [2 x i64] }, ptr %l3
  %t87 = extractvalue { i64, [2 x i64] } %t85, 0
  %t88 = icmp eq i64 %t87, 6
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t91 = getelementptr { i64, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load i64, ptr %t91
  store i64 %t92, ptr %l8, !tbaa !24
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t94 = load i64, ptr %l8, !tbaa !24
  store i64 %t94, ptr %l19, !tbaa !24
  br label %bb51
bb28:
  %t96 = load { i64, [2 x i64] }, ptr %l3
  %t98 = extractvalue { i64, [2 x i64] } %t96, 0
  %t99 = icmp eq i64 %t98, 5
  br i1 %t99, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/load:Loader", ptr %t104, i32 0, i32 12
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l19, !tbaa !24
  br label %bb51
bb32:
  %t109 = load { i64, [2 x i64] }, ptr %l3
  %t111 = extractvalue { i64, [2 x i64] } %t109, 0
  %t112 = icmp eq i64 %t111, 9
  br i1 %t112, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i64 -3, ptr %l19, !tbaa !24
  br label %bb51
bb36:
  %t114 = load { i64, [2 x i64] }, ptr %l3
  %t116 = extractvalue { i64, [2 x i64] } %t114, 0
  %t117 = icmp eq i64 %t116, 4
  br i1 %t117, label %bb37, label %bb38
bb37:
  %t119 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t120 = getelementptr { i32 }, ptr %t119, i32 0, i32 0
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l9, !tbaa !23
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i32, ptr %l9, !tbaa !23
  %t126 = sext i32 %t124 to i64
  %t129 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t123, i64 %t126)
  store i64 %t129, ptr %l66
  br label %bb40
bb40:
  %t130 = load i64, ptr %l66, !tbaa !24
  store i64 %t130, ptr %l19, !tbaa !24
  br label %bb51
bb41:
  %t131 = load { i64, [2 x i64] }, ptr %l3
  %t133 = extractvalue { i64, [2 x i64] } %t131, 0
  %t134 = icmp eq i64 %t133, 8
  br i1 %t134, label %bb42, label %bb43
bb42:
  %t136 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t137 = getelementptr { i32, i32, i64 }, ptr %t136, i32 0, i32 0
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l10, !tbaa !23
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l10, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t146 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t140, i64 %t143)
  store i64 %t146, ptr %l73
  br label %bb45
bb45:
  %t147 = load i64, ptr %l73, !tbaa !24
  store i64 %t147, ptr %l19, !tbaa !24
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -4, ptr %l19, !tbaa !24
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_26303021143ae8be_4bef98a84a02e70a)
  unreachable
bb51:
  %t148 = load i64, ptr %l19, !tbaa !24
  store i64 %t148, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i1
  %l16 = alloca i64
  %l18 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l42 = alloca i1
  %l43 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l10
  br label %bb3
bb3:
  %t11 = load i64, ptr %l7, !tbaa !24
  %t12 = load i64, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 10
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l16
  br label %bb7
bb7:
  %t23 = load i64, ptr %l16, !tbaa !24
  %t24 = icmp slt i64 %t23, 0
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l12, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb16
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 13
  %t30 = load i64, ptr %l1, !tbaa !24
  %t33 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t33, ptr %l22
  br label %bb11
bb11:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb15
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 12
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t37, i64 %t38)
  store i1 %t41, ptr %l27
  br label %bb14
bb14:
  %t42 = load i1, ptr %l27, !tbaa !21
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t43 = load i1, ptr %l23, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l18, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i1, ptr %l18, !tbaa !21
  br i1 %t46, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t48)
  store ptr %t50, ptr %l31
  br label %bb20
bb20:
  %t51 = load ptr, ptr %l31, !tbaa !29
  store ptr %t51, ptr %l2, !tbaa !29
  %t52 = load ptr, ptr %l2, !tbaa !29
  store ptr %t52, ptr %l32, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 9
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t55, i64 %t56)
  store i32 %t59, ptr %l36
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l32, !tbaa !29
  %t61 = load i32, ptr %l36, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t62, ptr %l37
  br label %bb22
bb22:
  %t63 = load i32, ptr %l37, !tbaa !23
  store i32 %t63, ptr %l3, !tbaa !23
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/free:Free", ptr %t64, i32 0, i32 28
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t68 = load i32, ptr %l3, !tbaa !23
  %t72 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v0, ptr %t66, ptr %t67, i32 %t68)
  store i1 %t72, ptr %l42
  br label %bb23
bb23:
  %t73 = load i1, ptr %l42, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb27
bb25:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 28
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t78 = load i32, ptr %l3, !tbaa !23
  %t82 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2ePartOfGen(ptr %v0, ptr %v0, ptr %t76, ptr %t77, i32 %t78)
  store i1 %t82, ptr %l48
  br label %bb26
bb26:
  %t83 = load i1, ptr %l48, !tbaa !21
  store i1 %t83, ptr %l43, !tbaa !21
  br label %bb27
bb27:
  %t84 = load i1, ptr %l43, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufRows(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/text:StringBuilder"
  %l23 = alloca ptr
  %l26 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l54 = alloca i1
  %l56 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i32
  %l77 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l102 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i64
  %l130 = alloca i64
  %l134 = alloca i64
  %l137 = alloca i1
  %l138 = alloca i64
  %l141 = alloca i64
  %l143 = alloca i1
  %l147 = alloca i64
  %l150 = alloca i1
  %l152 = alloca ptr
  %l156 = alloca i64
  %l157 = alloca i1
  %l159 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l165 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l167 = alloca i1
  %l169 = alloca ptr
  %l173 = alloca i64
  %l174 = alloca ptr
  %l178 = alloca i64
  %l182 = alloca %"compiler/source:Span"
  %l185 = alloca i64
  %l186 = alloca { i64, ptr }
  %l188 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l194 = alloca i64
  %l198 = alloca %"compiler/source:Span"
  %l199 = alloca { i64, ptr }
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l207 = alloca i64
  %l211 = alloca %"compiler/source:Span"
  %l214 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l219 = alloca i64
  %l223 = alloca %"compiler/source:Span"
  %l224 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l21
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t3)
  store ptr %t5, ptr %l23
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l23, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 39
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l26
  br label %bb3
bb3:
  %t12 = load i64, ptr %l26, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l6, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l33, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l33, !tbaa !24
  store i64 %t39, ptr %l30, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l30, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l8, !tbaa !24
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 40
  %t62 = load i64, ptr %l9, !tbaa !24
  %t65 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l54
  br label %bb14
bb14:
  %t66 = load i1, ptr %l54, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb19
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 28
  store ptr %t71, ptr %l58, !tbaa !29
  %t72 = load ptr, ptr %l3, !tbaa !29
  store ptr %t72, ptr %l59, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 39
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t75, i64 %t76)
  store i32 %t79, ptr %l63
  br label %bb17
bb17:
  %t80 = load ptr, ptr %l58, !tbaa !29
  %t81 = load ptr, ptr %l59, !tbaa !29
  %t82 = load i32, ptr %l63, !tbaa !23
  %t83 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eLeaves(ptr %v0, ptr %v0, ptr %t80, ptr %t81, i32 %t82)
  store i1 %t83, ptr %l64
  br label %bb18
bb18:
  %t84 = load i1, ptr %l64, !tbaa !21
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %l56, !tbaa !21
  br label %bb19
bb19:
  %t87 = load i1, ptr %l56, !tbaa !21
  br i1 %t87, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb21:
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = getelementptr %"compiler/types:Table", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  store ptr %t91, ptr %l67, !tbaa !29
  %t92 = load ptr, ptr %l3, !tbaa !29
  store ptr %t92, ptr %l68, !tbaa !29
  %t93 = load ptr, ptr %l3, !tbaa !29
  store ptr %t93, ptr %l69, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:Free", ptr %t94, i32 0, i32 39
  %t97 = load i64, ptr %l9, !tbaa !24
  %t100 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t96, i64 %t97)
  store i32 %t100, ptr %l73
  br label %bb23
bb23:
  %t101 = load ptr, ptr %l69, !tbaa !29
  %t102 = load i32, ptr %l73, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t101, i32 %t102)
  store i32 %t103, ptr %l74
  br label %bb24
bb24:
  %t104 = load ptr, ptr %l68, !tbaa !29
  %t105 = load i32, ptr %l74, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t104, i32 %t105)
  store i32 %t106, ptr %l75
  br label %bb25
bb25:
  %t107 = load ptr, ptr %l67, !tbaa !29
  %t108 = call ptr @__olang_scope_of(ptr %t107, ptr null)
  %t109 = ptrtoint ptr %t108 to i64
  %t111 = inttoptr i64 %t109 to ptr
  %t112 = load ptr, ptr %l67, !tbaa !29
  %t113 = load i32, ptr %l75, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t111, ptr %s2, ptr %t112, i32 %t113)
  store { i64, ptr } %t114, ptr %l77
  br label %bb26
bb26:
  %t115 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t115, ptr %l10, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:Free", ptr %t116, i32 0, i32 47
  %t119 = load i1, ptr %t118, !tbaa !21
  br i1 %t119, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t121 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/free:Free", ptr %t122, i32 0, i32 48
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  %t126 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t129 = extractvalue { i64, ptr } %t121, 1
  %t130 = extractvalue { i64, ptr } %t121, 0
  %t131 = add i64 %t127, %t130
  %t132 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t133 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t134 = add i64 %t131, %t133
  %t136 = extractvalue { i64, ptr } %t125, 1
  %t137 = extractvalue { i64, ptr } %t125, 0
  %t138 = add i64 %t134, %t137
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t141 = add i64 %t138, %t140
  %t142 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t141)
  call void @olang_textcopy(ptr %t142, ptr %t126, i64 %t127)
  %t143 = getelementptr i8, ptr %t142, i64 %t127
  call void @olang_textcopy(ptr %t143, ptr %t129, i64 %t130)
  %t144 = getelementptr i8, ptr %t143, i64 %t130
  call void @olang_textcopy(ptr %t144, ptr %t132, i64 %t133)
  %t145 = getelementptr i8, ptr %t144, i64 %t133
  call void @olang_textcopy(ptr %t145, ptr %t136, i64 %t137)
  %t146 = getelementptr i8, ptr %t145, i64 %t137
  call void @olang_textcopy(ptr %t146, ptr %t139, i64 %t140)
  %t147 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t142, 1
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t151 = extractvalue { i64, ptr } %t148, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l2, { i64, ptr } %t155)
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb30:
  %t158 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t159 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t162 = extractvalue { i64, ptr } %t158, 1
  %t163 = extractvalue { i64, ptr } %t158, 0
  %t164 = add i64 %t160, %t163
  %t165 = extractvalue { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t159, i64 %t160)
  %t169 = getelementptr i8, ptr %t168, i64 %t160
  call void @olang_textcopy(ptr %t169, ptr %t162, i64 %t163)
  %t170 = getelementptr i8, ptr %t169, i64 %t163
  call void @olang_textcopy(ptr %t170, ptr %t165, i64 %t166)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t168, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = extractvalue { i64, ptr } %t172, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t179)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  %t182 = load i64, ptr %l8, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l8, !tbaa !24
  br label %bb10
bb33:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/free:Free", ptr %t186, i32 0, i32 47
  %t189 = load i1, ptr %t188, !tbaa !21
  br i1 %t189, label %bb34, label %bb35
bb34:
  %t192 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t192, ptr %l95
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t193 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t193, ptr %rv
  br label %ret
bb37:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/free:Free", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 0
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/load:Loader", ptr %t200, i32 0, i32 4
  %t203 = load ptr, ptr %t202, !tbaa !29
  store ptr %t203, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/free:Free", ptr %t205, i32 0, i32 53
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t207)
  store i64 %t209, ptr %l102
  br label %bb38
bb38:
  %t210 = load i64, ptr %l102, !tbaa !24
  store i64 %t210, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l12, !tbaa !24
  %t215 = icmp sgt i64 %t211, %t212
  br i1 %t215, label %bb39, label %bb40
bb39:
  %t217 = load i64, ptr %l14, !tbaa !24
  %t219 = icmp sgt i64 %t217, 0
  br i1 %t219, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb44
bb41:
  %t221 = load i64, ptr %l13, !tbaa !24
  %t222 = load i64, ptr %l12, !tbaa !24
  %t225 = sub i64 %t221, %t222
  %t226 = load i64, ptr %l14, !tbaa !24
  %t229 = add i64 %t225, %t226
  %t231 = sub i64 %t229, 1
  %t232 = load i64, ptr %l14, !tbaa !24
  %t235 = sdiv i64 %t231, %t232
  store i64 %t235, ptr %l109, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb43
bb43:
  %t237 = load i64, ptr %l109, !tbaa !24
  store i64 %t237, ptr %l106, !tbaa !24
  br label %bb44
bb44:
  %t238 = load i64, ptr %l106, !tbaa !24
  store i64 %t238, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s10
  %t239 = load i64, ptr %l16, !tbaa !24
  %t240 = load i64, ptr %l15, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb90
bb47:
  br label %bb48
bb48:
  %t247 = load i64, ptr %l12, !tbaa !24
  %t248 = load i64, ptr %l16, !tbaa !24
  %t249 = load i64, ptr %l14, !tbaa !24
  %t252 = mul i64 %t248, %t249
  %t255 = add i64 %t247, %t252
  store i64 %t255, ptr %l17, !tbaa !24
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/free:Free", ptr %t257, i32 0, i32 53
  %t260 = load i64, ptr %l17, !tbaa !24
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t259, i64 %t260)
  store i64 %t263, ptr %l130
  br label %bb49
bb49:
  %t264 = load i64, ptr %l130, !tbaa !24
  store i64 %t264, ptr %l18, !tbaa !24
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/free:Free", ptr %t265, i32 0, i32 30
  %t268 = load i64, ptr %l18, !tbaa !24
  %t271 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t267, i64 %t268)
  store i64 %t271, ptr %l134
  br label %bb50
bb50:
  %t272 = load i64, ptr %l134, !tbaa !24
  store i64 %t272, ptr %l19, !tbaa !24
  %t273 = load i64, ptr %l19, !tbaa !24
  %t275 = icmp slt i64 %t273, 0
  br i1 %t275, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l137, !tbaa !21
  br label %bb54
bb52:
  %t277 = load i64, ptr %l19, !tbaa !24
  store i64 %t277, ptr %l138, !tbaa !24
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/free:Free", ptr %t278, i32 0, i32 59
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t280)
  store i64 %t282, ptr %l141
  br label %bb53
bb53:
  %t283 = load i64, ptr %l138, !tbaa !24
  %t284 = load i64, ptr %l141, !tbaa !24
  %t285 = icmp sge i64 %t283, %t284
  store i1 %t285, ptr %l137, !tbaa !21
  br label %bb54
bb54:
  %t287 = load i1, ptr %l137, !tbaa !21
  br i1 %t287, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb58
bb56:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/free:Free", ptr %t288, i32 0, i32 59
  %t291 = load i64, ptr %l19, !tbaa !24
  %t294 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t290, i64 %t291)
  store i64 %t294, ptr %l147
  br label %bb57
bb57:
  %t295 = load i64, ptr %l17, !tbaa !24
  %t296 = load i64, ptr %l147, !tbaa !24
  %t298 = icmp ne i64 %t296, %t295
  store i1 %t298, ptr %l143, !tbaa !21
  br label %bb58
bb58:
  %t300 = load i1, ptr %l143, !tbaa !21
  br i1 %t300, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l150, !tbaa !21
  br label %bb63
bb60:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/free:Free", ptr %t301, i32 0, i32 23
  store ptr %t303, ptr %l152, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/free:Free", ptr %t304, i32 0, i32 29
  %t307 = load i64, ptr %l18, !tbaa !24
  %t310 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t306, i64 %t307)
  store i64 %t310, ptr %l156
  br label %bb61
bb61:
  %t311 = load ptr, ptr %l152, !tbaa !29
  %t312 = load i64, ptr %l156, !tbaa !24
  %t313 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t311, i64 %t312)
  store i1 %t313, ptr %l157
  br label %bb62
bb62:
  %t314 = load i1, ptr %l157, !tbaa !21
  %t315 = xor i1 %t314, true
  store i1 %t315, ptr %l150, !tbaa !21
  br label %bb63
bb63:
  %t317 = load i1, ptr %l150, !tbaa !21
  br i1 %t317, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb69
bb65:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l160, !tbaa !29
  %t320 = load i64, ptr %l19, !tbaa !24
  %t323 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v1, ptr %v1, ptr %a1, i64 %t320)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t323, ptr %l163
  br label %bb66
bb66:
  %t325 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v1, ptr %l163)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t325, ptr %l165
  br label %bb67
bb67:
  %t326 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l165
  %t327 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %t327
  %t328 = load ptr, ptr %l160, !tbaa !29
  %t330 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eletsLeaves(ptr %v0, ptr %v1, ptr %t328, ptr %t327)
  store i1 %t330, ptr %l167
  br label %bb68
bb68:
  %t331 = load i1, ptr %l167, !tbaa !21
  %t332 = xor i1 %t331, true
  store i1 %t332, ptr %l159, !tbaa !21
  br label %bb69
bb69:
  %t334 = load i1, ptr %l159, !tbaa !21
  br i1 %t334, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s10)
  br label %bb89
bb71:
  br label %bb72
bb72:
  %t335 = load ptr, ptr %l11, !tbaa !29
  store ptr %t335, ptr %l169, !tbaa !29
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/free:Free", ptr %t336, i32 0, i32 31
  %t339 = load i64, ptr %l18, !tbaa !24
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t338, i64 %t339)
  store i64 %t342, ptr %l173
  br label %bb73
bb73:
  %t343 = load ptr, ptr %l0, !tbaa !29
  store ptr %t343, ptr %l174, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/free:Free", ptr %t344, i32 0, i32 31
  %t347 = load i64, ptr %l18, !tbaa !24
  %t350 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t346, i64 %t347)
  store i64 %t350, ptr %l178
  br label %bb74
bb74:
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/free:Free", ptr %t351, i32 0, i32 32
  %t354 = load i64, ptr %l18, !tbaa !24
  %t357 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t353, i64 %t354)
  store %"compiler/source:Span" %t357, ptr %l182
  br label %bb75
bb75:
  %t358 = getelementptr %"compiler/source:Span", ptr %l182, i32 0, i32 0
  %t359 = load i32, ptr %t358, !tbaa !23
  %t361 = sext i32 %t359 to i64
  %t362 = load ptr, ptr %l174, !tbaa !29
  %t363 = load i64, ptr %l178, !tbaa !24
  %t365 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %t362, i64 %t363, i64 %t361)
  store i64 %t365, ptr %l185
  br label %bb76
bb76:
  %t366 = load ptr, ptr %l169, !tbaa !29
  %t367 = load i64, ptr %l173, !tbaa !24
  %t368 = load i64, ptr %l185, !tbaa !24
  %t369 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s10, ptr %t366, i64 %t367, i64 %t368)
  store { i64, ptr } %t369, ptr %l186
  br label %bb77
bb77:
  %t370 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  %t373 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t372)
  call void @olang_textcopy(ptr %t373, ptr %t371, i64 %t372)
  %t374 = insertvalue { i64, ptr } undef, i64 %t372, 0
  %t375 = insertvalue { i64, ptr } %t374, ptr %t373, 1
  store ptr %l2, ptr %l188, !tbaa !29
  store { i64, ptr } %t375, ptr %l189, !tbaa !27
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l190, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/free:Free", ptr %t379, i32 0, i32 31
  %t382 = load i64, ptr %l18, !tbaa !24
  %t385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t381, i64 %t382)
  store i64 %t385, ptr %l194
  br label %bb78
bb78:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/free:Free", ptr %t386, i32 0, i32 32
  %t389 = load i64, ptr %l18, !tbaa !24
  %t392 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t388, i64 %t389)
  store %"compiler/source:Span" %t392, ptr %l198
  br label %bb79
bb79:
  %t393 = load ptr, ptr %l190, !tbaa !29
  %t394 = load i64, ptr %l194, !tbaa !24
  %t395 = load %"compiler/source:Span", ptr %l198
  %t396 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s10, ptr %t393, i64 %t394, %"compiler/source:Span" %t395)
  store { i64, ptr } %t396, ptr %l199
  br label %bb80
bb80:
  %t397 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t401 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t402 = add i64 %t399, %t401
  %t403 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t403, 1
  %t405 = extractvalue { i64, ptr } %t403, 0
  %t406 = add i64 %t402, %t405
  %t407 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 64, ptr getelementptr inbounds (<{ i64, [64 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t409 = add i64 %t406, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t398, i64 %t399)
  %t411 = getelementptr i8, ptr %t410, i64 %t399
  call void @olang_textcopy(ptr %t411, ptr %t400, i64 %t401)
  %t412 = getelementptr i8, ptr %t411, i64 %t401
  call void @olang_textcopy(ptr %t412, ptr %t404, i64 %t405)
  %t413 = getelementptr i8, ptr %t412, i64 %t405
  call void @olang_textcopy(ptr %t413, ptr %t407, i64 %t408)
  %t414 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t410, 1
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t418 = extractvalue { i64, ptr } %t415, 1
  %t419 = mul i64 %t417, 1
  %t420 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t418, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  %t423 = load ptr, ptr %l188, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t423, { i64, ptr } %t422)
  br label %bb81
bb81:
  store ptr %l2, ptr %l202, !tbaa !29
  %t425 = load ptr, ptr %l11, !tbaa !29
  store ptr %t425, ptr %l203, !tbaa !29
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/free:Free", ptr %t426, i32 0, i32 31
  %t429 = load i64, ptr %l18, !tbaa !24
  %t432 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t428, i64 %t429)
  store i64 %t432, ptr %l207
  br label %bb82
bb82:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/free:Free", ptr %t433, i32 0, i32 55
  %t436 = load i64, ptr %l17, !tbaa !24
  %t439 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t435, i64 %t436)
  store %"compiler/source:Span" %t439, ptr %l211
  br label %bb83
bb83:
  %t440 = getelementptr %"compiler/source:Span", ptr %l211, i32 0, i32 0
  %t441 = load i32, ptr %t440, !tbaa !23
  %t443 = sext i32 %t441 to i64
  %t444 = load ptr, ptr %l203, !tbaa !29
  %t445 = load i64, ptr %l207, !tbaa !24
  %t447 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s10, ptr %t444, i64 %t445, i64 %t443)
  store { i64, ptr } %t447, ptr %l214
  br label %bb84
bb84:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l215, !tbaa !29
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/free:Free", ptr %t449, i32 0, i32 31
  %t452 = load i64, ptr %l18, !tbaa !24
  %t455 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t451, i64 %t452)
  store i64 %t455, ptr %l219
  br label %bb85
bb85:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/free:Free", ptr %t456, i32 0, i32 55
  %t459 = load i64, ptr %l17, !tbaa !24
  %t462 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t458, i64 %t459)
  store %"compiler/source:Span" %t462, ptr %l223
  br label %bb86
bb86:
  %t463 = load ptr, ptr %l215, !tbaa !29
  %t464 = load i64, ptr %l219, !tbaa !24
  %t465 = load %"compiler/source:Span", ptr %l223
  %t466 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s10, ptr %t463, i64 %t464, %"compiler/source:Span" %t465)
  store { i64, ptr } %t466, ptr %l224
  br label %bb87
bb87:
  %t467 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t467, 1
  %t469 = extractvalue { i64, ptr } %t467, 0
  %t470 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t471 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t472 = add i64 %t469, %t471
  %t473 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t473, 1
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t476 = add i64 %t472, %t475
  %t477 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t478 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t479 = add i64 %t476, %t478
  %t480 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t479)
  call void @olang_textcopy(ptr %t480, ptr %t468, i64 %t469)
  %t481 = getelementptr i8, ptr %t480, i64 %t469
  call void @olang_textcopy(ptr %t481, ptr %t470, i64 %t471)
  %t482 = getelementptr i8, ptr %t481, i64 %t471
  call void @olang_textcopy(ptr %t482, ptr %t474, i64 %t475)
  %t483 = getelementptr i8, ptr %t482, i64 %t475
  call void @olang_textcopy(ptr %t483, ptr %t477, i64 %t478)
  %t484 = insertvalue { i64, ptr } undef, i64 %t479, 0
  %t485 = insertvalue { i64, ptr } %t484, ptr %t480, 1
  %t487 = extractvalue { i64, ptr } %t485, 0
  %t488 = extractvalue { i64, ptr } %t485, 1
  %t489 = mul i64 %t487, 1
  %t490 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t489)
  call void @llvm.memcpy.p0.p0.i64(ptr %t490, ptr %t488, i64 %t489, i1 false)
  %t491 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t492 = insertvalue { i64, ptr } %t491, ptr %t490, 1
  %t493 = load ptr, ptr %l202, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t493, { i64, ptr } %t492)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s10)
  br label %bb89
bb89:
  %t495 = load i64, ptr %l16, !tbaa !24
  %t497 = add i64 %t495, 1
  store i64 %t497, ptr %l16, !tbaa !24
  br label %bb45
bb90:
  %t500 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t500, ptr %l230
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  %t501 = load { i64, ptr }, ptr %l230, !tbaa !27
  store { i64, ptr } %t501, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecollection(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/free:letGo" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca %"compiler/free:letGo"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/free:letGo"
  %lp7 = alloca ptr
  %l8 = alloca i1
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/free:letGo"
  %lp13 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca i64
  %l23 = alloca %"compiler/free:letGo"
  %l27 = alloca i1
  %l31 = alloca i1
  %l35 = alloca i1
  %l38 = alloca i1
  %l42 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i64
  %l59 = alloca i64
  %l61 = alloca i1
  %l65 = alloca i1
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca i1
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca %"compiler/free:letGo"
  %l89 = alloca i1
  %l93 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l104 = alloca { i64, ptr }
  %l106 = alloca i1
  %l112 = alloca i1
  %l114 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/free:letGo" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 84
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l16, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l18
  br label %bb2
bb2:
  %t9 = load i64, ptr %l16, !tbaa !24
  %t10 = load i64, ptr %l18, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb29
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/free:letGo" %t19, ptr %l23
  br label %bb6
bb6:
  %t20 = load %"compiler/free:letGo", ptr %l23
  store %"compiler/free:letGo" %t20, ptr %l6
  %t21 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = icmp eq i64 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t33 = icmp eq i64 %t29, %a2
  store i1 %t33, ptr %l27, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l27, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  %t41 = icmp ne i64 %t37, %t38
  store i1 %t41, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l31, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 7
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  store i1 %t47, ptr %l35, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l35, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 23
  %t53 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 7
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t54)
  store i1 %t57, ptr %l42
  br label %bb18
bb17:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb19
bb18:
  %t58 = load i1, ptr %l42, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l38, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/free:letGo", ptr %l6
  %t66 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %t62, %"compiler/free:letGo" %t63)
  store { i64, ptr } %t66, ptr %l46
  br label %bb22
bb21:
  br label %bb27
bb22:
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t67, ptr %lp7
  %t68 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t69 = load ptr, ptr %lp7
  store { i64, ptr } %t68, ptr %t69, !tbaa !27
  %t70 = load ptr, ptr %lp7
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t71, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t73, ptr %l48
  br label %bb23
bb23:
  %t74 = load i1, ptr %l48, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load ptr, ptr %lp7
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb1
bb29:
  %t84 = getelementptr %"compiler/free:letGo", ptr %l3, i32 0, i32 7
  %t85 = load i64, ptr %t84, !tbaa !24
  %t87 = icmp sge i64 %t85, 0
  br i1 %t87, label %bb30, label %bb31
bb30:
  %t89 = getelementptr %"compiler/free:letGo", ptr %l3, i32 0, i32 7
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t90, ptr %l56, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/free:Free", ptr %t91, i32 0, i32 23
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l59
  br label %bb32
bb31:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb33
bb32:
  %t96 = load i64, ptr %l56, !tbaa !24
  %t97 = load i64, ptr %l59, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  store i1 %t98, ptr %l55, !tbaa !21
  br label %bb33
bb33:
  %t100 = load i1, ptr %l55, !tbaa !21
  br i1 %t100, label %bb34, label %bb35
bb34:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:Free", ptr %t101, i32 0, i32 23
  %t104 = getelementptr %"compiler/free:letGo", ptr %l3, i32 0, i32 7
  %t105 = load i64, ptr %t104, !tbaa !24
  %t108 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t103, i64 %t105)
  store i1 %t108, ptr %l65
  br label %bb36
bb35:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb37
bb36:
  %t109 = load i1, ptr %l65, !tbaa !21
  store i1 %t109, ptr %l61, !tbaa !21
  br label %bb37
bb37:
  %t110 = load i1, ptr %l61, !tbaa !21
  store i1 %t110, ptr %l8, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load %"compiler/free:letGo", ptr %l3
  %t115 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %t111, %"compiler/free:letGo" %t112)
  store { i64, ptr } %t115, ptr %l68
  br label %bb38
bb38:
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t116, ptr %lp9
  %t117 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t118 = load ptr, ptr %lp9
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  %t119 = load ptr, ptr %lp9
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t120, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t122, ptr %l70
  br label %bb39
bb39:
  %t123 = load i1, ptr %l70, !tbaa !21
  %t124 = xor i1 %t123, true
  br i1 %t124, label %bb40, label %bb41
bb40:
  %t126 = load i1, ptr %l8, !tbaa !21
  %t128 = xor i1 %t126, true
  store i1 %t128, ptr %l72, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb42
bb42:
  %t130 = load i1, ptr %l72, !tbaa !21
  br i1 %t130, label %bb43, label %bb44
bb43:
  %t131 = load ptr, ptr %lp9
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t132, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:Free", ptr %t134, i32 0, i32 84
  store ptr %t136, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb46
bb46:
  %t138 = load i64, ptr %l11, !tbaa !24
  store i64 %t138, ptr %l78, !tbaa !24
  %t139 = load ptr, ptr %l10, !tbaa !29
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t139)
  store i64 %t141, ptr %l80
  br label %bb47
bb47:
  %t142 = load i64, ptr %l78, !tbaa !24
  %t143 = load i64, ptr %l80, !tbaa !24
  %t144 = icmp slt i64 %t142, %t143
  %t146 = xor i1 %t144, true
  br i1 %t146, label %bb48, label %bb49
bb48:
  br label %bb71
bb49:
  br label %bb50
bb50:
  %t148 = load ptr, ptr %l10, !tbaa !29
  %t149 = load i64, ptr %l11, !tbaa !24
  %t152 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t148, i64 %t149)
  store %"compiler/free:letGo" %t152, ptr %l85
  br label %bb51
bb51:
  %t153 = load %"compiler/free:letGo", ptr %l85
  store %"compiler/free:letGo" %t153, ptr %l12
  %t154 = getelementptr %"compiler/free:letGo", ptr %l12, i32 0, i32 0
  %t155 = load i64, ptr %t154, !tbaa !24
  %t156 = load i64, ptr %l1, !tbaa !24
  %t159 = icmp eq i64 %t155, %t156
  br i1 %t159, label %bb52, label %bb53
bb52:
  %t161 = getelementptr %"compiler/free:letGo", ptr %l12, i32 0, i32 5
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  %t166 = icmp ne i64 %t162, %t163
  store i1 %t166, ptr %l89, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb54
bb54:
  %t168 = load i1, ptr %l89, !tbaa !21
  br i1 %t168, label %bb55, label %bb56
bb55:
  %t169 = getelementptr %"compiler/free:letGo", ptr %l12, i32 0, i32 7
  %t170 = load i64, ptr %t169, !tbaa !24
  %t172 = icmp sge i64 %t170, 0
  store i1 %t172, ptr %l93, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb57
bb57:
  %t174 = load i1, ptr %l93, !tbaa !21
  br i1 %t174, label %bb58, label %bb59
bb58:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 23
  %t178 = getelementptr %"compiler/free:letGo", ptr %l12, i32 0, i32 7
  %t179 = load i64, ptr %t178, !tbaa !24
  %t182 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t177, i64 %t179)
  store i1 %t182, ptr %l100
  br label %bb60
bb59:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb61
bb60:
  %t183 = load i1, ptr %l100, !tbaa !21
  %t184 = xor i1 %t183, true
  store i1 %t184, ptr %l96, !tbaa !21
  br label %bb61
bb61:
  %t186 = load i1, ptr %l96, !tbaa !21
  br i1 %t186, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s9
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load %"compiler/free:letGo", ptr %l12
  %t191 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %t187, %"compiler/free:letGo" %t188)
  store { i64, ptr } %t191, ptr %l104
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t192 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t192, ptr %lp13
  %t193 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t194 = load ptr, ptr %lp13
  store { i64, ptr } %t193, ptr %t194, !tbaa !27
  %t195 = load ptr, ptr %lp13
  %t196 = load { i64, ptr }, ptr %t195, !tbaa !27
  %t198 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s9, { i64, ptr } %t196, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i1 %t198, ptr %l106
  br label %bb65
bb65:
  %t199 = load i1, ptr %l106, !tbaa !21
  %t200 = xor i1 %t199, true
  br i1 %t200, label %bb66, label %bb67
bb66:
  %t202 = load ptr, ptr %lp13
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t203, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s9)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t205 = load i64, ptr %l11, !tbaa !24
  %t207 = add i64 %t205, 1
  store i64 %t207, ptr %l11, !tbaa !24
  br label %bb46
bb71:
  %t209 = load ptr, ptr %lp9
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t210, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t212, ptr %l112
  br label %bb72
bb72:
  %t213 = load i1, ptr %l112, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb73, label %bb74
bb73:
  %t216 = load ptr, ptr %lp9
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l114, !tbaa !27
  br label %bb75
bb74:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l116, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t219, ptr %l114, !tbaa !27
  br label %bb75
bb75:
  %t221 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l118, !tbaa !24
  %t223 = load i64, ptr %l118, !tbaa !24
  %t224 = mul i64 %t223, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t224)
  %t226 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  store { i64, ptr } %t227, ptr %l119, !tbaa !27
  %t228 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = load i64, ptr %l118, !tbaa !24
  %t233 = mul i64 %t232, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t229, ptr %t231, i64 %t233, i1 false)
  %t234 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t234, ptr %l114, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t235 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t235, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecopiedPlain(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i64
  %l15 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca i64
  %l36 = alloca i1
  %l54 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l61 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l67 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l81 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp eq i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr @G_2ecompiler_2ftyped_2eViewOther, !tbaa !24
  %t15 = and i64 %t11, %t12
  %t17 = icmp ne i64 %t15, 0
  store i1 %t17, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb8
bb6:
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = call i1 @compiler_2ftyped_2eViewsMoved(ptr %v1, ptr %a1, i64 %t21)
  store i1 %t24, ptr %l23
  br label %bb7
bb7:
  %t25 = load i1, ptr %l23, !tbaa !21
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l28
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l28, !tbaa !29
  store ptr %t35, ptr %l4, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l30
  br label %bb13
bb13:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t43 = load ptr, ptr %l30, !tbaa !29
  %t45 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t43, i32 %t42)
  store i64 %t45, ptr %l33
  br label %bb14
bb14:
  %t46 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t47 = load i64, ptr %l33, !tbaa !24
  %t49 = icmp ne i64 %t47, %t46
  br i1 %t49, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/typed:Body", ptr %t51, i32 0, i32 11
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  store i1 %t56, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l36, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Body", ptr %t60, i32 0, i32 11
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = icmp eq ptr %t63, null
  br i1 %t65, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_cd034f3e3abc884f_abc13ef4de953fab)
  unreachable
bb22:
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t67, i32 0, i32 11
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Block", ptr %t70, i32 0, i32 1
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  store { i64, ptr } %t74, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l7, !tbaa !24
  br label %bb24
bb24:
  %t80 = load i64, ptr %l6, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = icmp slt i64 %t80, %t81
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb25, label %bb26
bb25:
  br label %bb54
bb26:
  br label %bb27
bb27:
  %t88 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t88, ptr %l54, !tbaa !27
  %t89 = load i64, ptr %l6, !tbaa !24
  %t91 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 %t89
  %t94 = load ptr, ptr %t93, !tbaa !39
  store ptr %t94, ptr %l8, !tbaa !29
  %t96 = load ptr, ptr %l8, !tbaa !29
  store ptr %t96, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t97 = load ptr, ptr %l57, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb28, label %bb29
bb28:
  %t100 = load ptr, ptr %l57, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 17}
  %t103 = icmp eq i64 %t101, 0
  store i1 %t103, ptr %l58, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l58, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t105 = load ptr, ptr %l8, !tbaa !29
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t110 = load ptr, ptr %l63, !tbaa !29
  %t111 = icmp ne ptr %t110, null
  br i1 %t111, label %bb32, label %bb33
bb31:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb39
bb32:
  %t113 = load ptr, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %t113, !range !{i64 0, i64 18}
  %t116 = icmp eq i64 %t114, 2
  store i1 %t116, ptr %l64, !tbaa !21
  br label %bb33
bb33:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb34, label %bb35
bb34:
  %t118 = load ptr, ptr %l8, !tbaa !29
  %t120 = getelementptr { i64, [3 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t127 = load ptr, ptr %l70, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb38
bb36:
  %t130 = load ptr, ptr %l70, !tbaa !29
  %t131 = load i64, ptr %t130, !range !{i64 0, i64 8}
  %t133 = icmp eq i64 %t131, 0
  store i1 %t133, ptr %l71, !tbaa !21
  br label %bb37
bb37:
  %t134 = load i1, ptr %l71, !tbaa !21
  store i1 %t134, ptr %l67, !tbaa !21
  br label %bb38
bb38:
  %t135 = load i1, ptr %l67, !tbaa !21
  store i1 %t135, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t136 = load i1, ptr %l61, !tbaa !21
  br i1 %t136, label %bb40, label %bb41
bb40:
  %t137 = load ptr, ptr %l8, !tbaa !29
  %t139 = getelementptr { i64, [3 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t139, i32 0, i32 2
  %t141 = load ptr, ptr %t140
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t143, i32 0, i32 2
  %t145 = load ptr, ptr %t144
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t147, i32 0, i32 2
  %t149 = load i32, ptr %t148
  store i32 %t149, ptr %l9, !tbaa !23
  br label %bb42
bb41:
  br label %bb47
bb42:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Body", ptr %t151, i32 0, i32 5
  %t154 = load i32, ptr %l9, !tbaa !23
  %t157 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eHas_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t153, i32 %t154)
  store i1 %t157, ptr %l81
  br label %bb43
bb43:
  %t158 = load i1, ptr %l81, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb44, label %bb45
bb44:
  store i1 false, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  store i1 false, ptr %rv
  br label %ret
bb51:
  call void @__olang_check_failed(ptr @olang_loc_8e98c88bf995f5b7_6ee5e17bac1969d3)
  unreachable
bb52:
  br label %bb53
bb53:
  %t163 = load i64, ptr %l6, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l6, !tbaa !24
  br label %bb24
bb54:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/free:letGo"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/free:store"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca %"compiler/free:orStore"
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca %"compiler/free:orCall"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca %"compiler/free:feedCall"
  %l30 = alloca %"compiler/free:feed"
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca %"compiler/free:store"
  %l34 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca %"compiler/free:store"
  %l39 = alloca i64
  %l40 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca %"compiler/free:store"
  %l69 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l99 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca %"compiler/free:letGo"
  %l115 = alloca i1
  %l118 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l135 = alloca i64
  %l138 = alloca i64
  %l158 = alloca ptr
  %l159 = alloca i64
  %l160 = alloca i64
  %l161 = alloca %"compiler/source:Span"
  %l164 = alloca i64
  %l166 = alloca ptr
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca %"compiler/source:Span"
  %l172 = alloca i1
  %l176 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca %"compiler/source:Span"
  %l185 = alloca i64
  %l187 = alloca i64
  %l192 = alloca %"compiler/free:store"
  %l196 = alloca i1
  %l200 = alloca i1
  %l202 = alloca i1
  %l203 = alloca ptr
  %l207 = alloca i1
  %l217 = alloca i64
  %l219 = alloca i64
  %l224 = alloca %"compiler/free:orStore"
  %l228 = alloca i1
  %l230 = alloca i1
  %l233 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca %"compiler/source:Span"
  %l242 = alloca i64
  %l244 = alloca i64
  %l249 = alloca %"compiler/free:orCall"
  %l253 = alloca i1
  %l255 = alloca i1
  %l259 = alloca ptr
  %l263 = alloca i1
  %l267 = alloca i1
  %l268 = alloca ptr
  %l269 = alloca i64
  %l270 = alloca i64
  %l271 = alloca %"compiler/source:Span"
  %l276 = alloca i64
  %l278 = alloca i64
  %l283 = alloca %"compiler/free:feedCall"
  %l286 = alloca i1
  %l291 = alloca %"compiler/free:feed"
  %l292 = alloca ptr
  %l293 = alloca i64
  %l294 = alloca i64
  %l298 = alloca ptr
  %l300 = alloca i64
  %l304 = alloca ptr
  %l308 = alloca %"compiler/typed:Local"
  %l309 = alloca %"compiler/source:Span"
  %l310 = alloca i64
  %l315 = alloca ptr
  %l319 = alloca ptr
  %l323 = alloca %"compiler/typed:Local"
  %l325 = alloca { i64, ptr }
  %l332 = alloca i64
  %l334 = alloca i64
  %l339 = alloca %"compiler/free:store"
  %l343 = alloca i1
  %l346 = alloca i1
  %l348 = alloca i1
  %l349 = alloca ptr
  %l353 = alloca i64
  %l362 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l364 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l366 = alloca i64
  %l368 = alloca i64
  %l373 = alloca i64
  %l377 = alloca %"compiler/free:store"
  %l381 = alloca i1
  %l385 = alloca i1
  %l386 = alloca i1
  %l389 = alloca i1
  %l391 = alloca ptr
  %l395 = alloca i64
  %l398 = alloca i1
  %l399 = alloca ptr
  %l400 = alloca i64
  %l404 = alloca { i64, [2 x i64] }
  %l407 = alloca i1
  %l408 = alloca ptr
  %l409 = alloca i64
  %l413 = alloca { i64, [2 x i64] }
  %l418 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l419 = alloca i64
  %l422 = alloca i64
  %l423 = alloca i32
  %l443 = alloca i64
  %l446 = alloca i64
  %l467 = alloca i1
  %l468 = alloca ptr
  %l469 = alloca i64
  %l470 = alloca i64
  %l471 = alloca %"compiler/source:Span"
  %l478 = alloca i64
  %l481 = alloca i64
  %l500 = alloca ptr
  %l501 = alloca i64
  %l504 = alloca i1
  %l508 = alloca i64
  %l517 = alloca i64
  %l520 = alloca i64
  %l541 = alloca i1
  %l543 = alloca i1
  %l547 = alloca i1
  %l549 = alloca ptr
  %l553 = alloca i32
  %l554 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l556 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l558 = alloca i64
  %l560 = alloca i64
  %l565 = alloca i64
  %l569 = alloca i1
  %l570 = alloca i1
  %l574 = alloca i1
  %l578 = alloca ptr
  %l579 = alloca i64
  %l580 = alloca i64
  %l581 = alloca %"compiler/source:Span"
  %l588 = alloca i64
  %l590 = alloca i64
  %l595 = alloca %"compiler/free:store"
  %l599 = alloca i1
  %l603 = alloca i1
  %l604 = alloca i1
  %l608 = alloca i1
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s55 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l69
  br label %bb1
bb1:
  %t6 = load i64, ptr %l69, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l77, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l77, !tbaa !24
  store i64 %t35, ptr %l74, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l74, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 90
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t57, i1 false)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t63 = load i64, ptr %l1, !tbaa !24
  store i64 %t63, ptr %l99, !tbaa !24
  %t64 = load i64, ptr %l99, !tbaa !24
  %t65 = icmp sge i64 %t64, 0
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l99, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l8, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 84
  store ptr %t75, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_77e2c420ac7907a9_804235f2ad53d)
  unreachable
bb17:
  %t77 = load i64, ptr %l10, !tbaa !24
  store i64 %t77, ptr %l104, !tbaa !24
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l106
  br label %bb18
bb18:
  %t81 = load i64, ptr %l104, !tbaa !24
  %t82 = load i64, ptr %l106, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb19, label %bb20
bb19:
  br label %bb37
bb20:
  br label %bb21
bb21:
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t87, i64 %t88)
  store %"compiler/free:letGo" %t91, ptr %l111
  br label %bb22
bb22:
  %t92 = load %"compiler/free:letGo", ptr %l111
  store %"compiler/free:letGo" %t92, ptr %l11
  %t93 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 5
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t98 = icmp ne i64 %t94, %t95
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  %t103 = icmp sge i64 %t101, 0
  store i1 %t103, ptr %l115, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l115, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 5
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  %t111 = icmp eq i64 %t107, %t108
  br i1 %t111, label %bb28, label %bb29
bb27:
  store i1 false, ptr %l118, !tbaa !21
  br label %bb32
bb28:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:Free", ptr %t113, i32 0, i32 61
  %t116 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 1
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t115, i64 %t117)
  store i1 %t120, ptr %l126
  br label %bb30
bb29:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb31
bb30:
  %t121 = load i1, ptr %l126, !tbaa !21
  store i1 %t121, ptr %l122, !tbaa !21
  br label %bb31
bb31:
  %t122 = load i1, ptr %l122, !tbaa !21
  %t123 = xor i1 %t122, true
  store i1 %t123, ptr %l118, !tbaa !21
  br label %bb32
bb32:
  %t125 = load i1, ptr %l118, !tbaa !21
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t126 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 0
  %t127 = load i64, ptr %t126, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i1, ptr %t130, i64 %t127
  store i1 true, ptr %t131, !tbaa !31
  br label %bb35
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l10, !tbaa !24
  br label %bb17
bb37:
  store i64 0, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l1, !tbaa !24
  store i64 %t136, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t142 = icmp sgt i64 %t138, %t139
  br i1 %t142, label %bb38, label %bb39
bb38:
  %t144 = load i64, ptr %l14, !tbaa !24
  %t146 = icmp sgt i64 %t144, 0
  br i1 %t146, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l135, !tbaa !24
  br label %bb43
bb40:
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = sub i64 %t148, %t149
  %t153 = load i64, ptr %l14, !tbaa !24
  %t156 = add i64 %t152, %t153
  %t158 = sub i64 %t156, 1
  %t159 = load i64, ptr %l14, !tbaa !24
  %t162 = sdiv i64 %t158, %t159
  store i64 %t162, ptr %l138, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l138, !tbaa !24
  br label %bb42
bb42:
  %t164 = load i64, ptr %l138, !tbaa !24
  store i64 %t164, ptr %l135, !tbaa !24
  br label %bb43
bb43:
  %t165 = load i64, ptr %l135, !tbaa !24
  store i64 %t165, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb44
bb44:
  %t166 = load i64, ptr %l16, !tbaa !24
  %t167 = load i64, ptr %l15, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb45, label %bb46
bb45:
  br label %bb69
bb46:
  br label %bb47
bb47:
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = load i64, ptr %l16, !tbaa !24
  %t176 = load i64, ptr %l14, !tbaa !24
  %t179 = mul i64 %t175, %t176
  %t182 = add i64 %t174, %t179
  store i64 %t182, ptr %l17, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/free:Free", ptr %t184, i32 0, i32 78
  %t187 = load i1, ptr %t186, !tbaa !21
  br i1 %t187, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s10
  %t189 = load ptr, ptr %l0, !tbaa !29
  store ptr %t189, ptr %l158, !tbaa !29
  %t190 = load i64, ptr %l17, !tbaa !24
  store i64 %t190, ptr %l159, !tbaa !24
  %t191 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t191, ptr %l160, !tbaa !24
  %t192 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s10, i32 0, i32 0)
  store %"compiler/source:Span" %t192, ptr %l161
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t193 = load ptr, ptr %l158, !tbaa !29
  %t194 = load i64, ptr %l159, !tbaa !24
  %t195 = load i64, ptr %l160, !tbaa !24
  %t196 = load %"compiler/source:Span", ptr %l161
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t193, i64 %t194, i64 %t195, i64 -1, %"compiler/source:Span" %t196, { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s10)
  br label %bb52
bb52:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/free:Free", ptr %t197, i32 0, i32 76
  %t201 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t199)
  store i64 %t201, ptr %l164
  br label %bb53
bb53:
  %t202 = load i64, ptr %l164, !tbaa !24
  %t203 = icmp sgt i64 %t202, 0
  br i1 %t203, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l166, !tbaa !29
  %t206 = load i64, ptr %l17, !tbaa !24
  store i64 %t206, ptr %l167, !tbaa !24
  %t207 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t207, ptr %l168, !tbaa !24
  %t208 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 0, i32 0)
  store %"compiler/source:Span" %t208, ptr %l169
  br label %bb56
bb55:
  br label %bb58
bb56:
  %t209 = load ptr, ptr %l166, !tbaa !29
  %t210 = load i64, ptr %l167, !tbaa !24
  %t211 = load i64, ptr %l168, !tbaa !24
  %t212 = load %"compiler/source:Span", ptr %l169
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t209, i64 %t210, i64 %t211, i64 -1, %"compiler/source:Span" %t212, { i64, ptr } { i64 130, ptr getelementptr inbounds (<{ i64, [130 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s11)
  br label %bb58
bb58:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/free:Free", ptr %t213, i32 0, i32 81
  %t216 = load i1, ptr %t215, !tbaa !21
  br i1 %t216, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb62
bb60:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/free:Free", ptr %t218, i32 0, i32 82
  %t221 = load i64, ptr %l17, !tbaa !24
  %t224 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t220, i64 %t221)
  store i1 %t224, ptr %l176
  br label %bb61
bb61:
  %t225 = load i1, ptr %l176, !tbaa !21
  store i1 %t225, ptr %l172, !tbaa !21
  br label %bb62
bb62:
  %t226 = load i1, ptr %l172, !tbaa !21
  br i1 %t226, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l177, !tbaa !29
  %t228 = load i64, ptr %l17, !tbaa !24
  store i64 %t228, ptr %l178, !tbaa !24
  %t229 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t229, ptr %l179, !tbaa !24
  %t230 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 0, i32 0)
  store %"compiler/source:Span" %t230, ptr %l180
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t231 = load ptr, ptr %l177, !tbaa !29
  %t232 = load i64, ptr %l178, !tbaa !24
  %t233 = load i64, ptr %l179, !tbaa !24
  %t234 = load %"compiler/source:Span", ptr %l180
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t231, i64 %t232, i64 %t233, i64 -1, %"compiler/source:Span" %t234, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d29, i32 0, i32 1) })
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s12)
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t235 = load i64, ptr %l16, !tbaa !24
  %t237 = add i64 %t235, 1
  store i64 %t237, ptr %l16, !tbaa !24
  br label %bb44
bb69:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 83
  store ptr %t241, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb70
bb70:
  %t243 = load i64, ptr %l19, !tbaa !24
  store i64 %t243, ptr %l185, !tbaa !24
  %t244 = load ptr, ptr %l18, !tbaa !29
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t244)
  store i64 %t246, ptr %l187
  br label %bb71
bb71:
  %t247 = load i64, ptr %l185, !tbaa !24
  %t248 = load i64, ptr %l187, !tbaa !24
  %t249 = icmp slt i64 %t247, %t248
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb72, label %bb73
bb72:
  br label %bb92
bb73:
  br label %bb74
bb74:
  %t253 = load ptr, ptr %l18, !tbaa !29
  %t254 = load i64, ptr %l19, !tbaa !24
  %t257 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t253, i64 %t254)
  store %"compiler/free:store" %t257, ptr %l192
  br label %bb75
bb75:
  %t258 = load %"compiler/free:store", ptr %l192
  store %"compiler/free:store" %t258, ptr %l20
  %t259 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 4
  %t260 = load i64, ptr %t259, !tbaa !24
  %t261 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t264 = icmp eq i64 %t260, %t261
  br i1 %t264, label %bb76, label %bb77
bb76:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/free:Free", ptr %t266, i32 0, i32 113
  %t269 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 0
  %t270 = load i64, ptr %t269, !tbaa !24
  %t273 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t268, i64 %t270)
  store i1 %t273, ptr %l200
  br label %bb78
bb77:
  store i1 false, ptr %l196, !tbaa !21
  br label %bb79
bb78:
  %t274 = load i1, ptr %l200, !tbaa !21
  %t275 = xor i1 %t274, true
  store i1 %t275, ptr %l196, !tbaa !21
  br label %bb79
bb79:
  %t277 = load i1, ptr %l196, !tbaa !21
  br i1 %t277, label %bb80, label %bb81
bb80:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l203, !tbaa !29
  %t279 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 7
  %t280 = load ptr, ptr %t279, !tbaa !29
  %t282 = icmp eq ptr %t280, null
  br i1 %t282, label %bb82, label %bb83
bb81:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb86
bb82:
  call void @__olang_check_failed(ptr @olang_loc_834ee64634399a9c_46784e5d37862958)
  unreachable
bb83:
  br label %bb84
bb84:
  %t284 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 7
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t286 = load ptr, ptr %l203, !tbaa !29
  %t288 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t286, ptr %t285)
  store i1 %t288, ptr %l207
  br label %bb85
bb85:
  %t289 = load i1, ptr %l207, !tbaa !21
  store i1 %t289, ptr %l202, !tbaa !21
  br label %bb86
bb86:
  %t290 = load i1, ptr %l202, !tbaa !21
  br i1 %t290, label %bb87, label %bb88
bb87:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 0
  %t293 = load i64, ptr %t292, !tbaa !24
  %t294 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  %t295 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 2
  %t296 = load i64, ptr %t295, !tbaa !24
  %t297 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 3
  %t298 = load %"compiler/source:Span", ptr %t297
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t291, i64 %t293, i64 %t294, i64 %t296, %"compiler/source:Span" %t298, { i64, ptr } { i64 144, ptr getelementptr inbounds (<{ i64, [144 x i8] }>, ptr @.d30, i32 0, i32 1) })
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  br label %bb91
bb91:
  %t304 = load i64, ptr %l19, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l19, !tbaa !24
  br label %bb70
bb92:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/free:Free", ptr %t308, i32 0, i32 89
  store ptr %t310, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb93
bb93:
  %t312 = load i64, ptr %l22, !tbaa !24
  store i64 %t312, ptr %l217, !tbaa !24
  %t313 = load ptr, ptr %l21, !tbaa !29
  %t315 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %t313)
  store i64 %t315, ptr %l219
  br label %bb94
bb94:
  %t316 = load i64, ptr %l217, !tbaa !24
  %t317 = load i64, ptr %l219, !tbaa !24
  %t318 = icmp slt i64 %t316, %t317
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb95, label %bb96
bb95:
  br label %bb110
bb96:
  br label %bb97
bb97:
  %t322 = load ptr, ptr %l21, !tbaa !29
  %t323 = load i64, ptr %l22, !tbaa !24
  %t326 = call %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t322, i64 %t323)
  store %"compiler/free:orStore" %t326, ptr %l224
  br label %bb98
bb98:
  %t327 = load %"compiler/free:orStore", ptr %l224
  store %"compiler/free:orStore" %t327, ptr %l23
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/free:Free", ptr %t328, i32 0, i32 113
  %t331 = getelementptr %"compiler/free:orStore", ptr %l23, i32 0, i32 1
  %t332 = load i64, ptr %t331, !tbaa !24
  %t335 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t330, i64 %t332)
  store i1 %t335, ptr %l228
  br label %bb99
bb99:
  %t336 = load i1, ptr %l228, !tbaa !21
  %t337 = xor i1 %t336, true
  br i1 %t337, label %bb100, label %bb101
bb100:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/free:orStore", ptr %l23, i32 0, i32 2
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t344 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t339, ptr %t341)
  store i1 %t344, ptr %l233
  br label %bb102
bb101:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb103
bb102:
  %t345 = load i1, ptr %l233, !tbaa !21
  store i1 %t345, ptr %l230, !tbaa !21
  br label %bb103
bb103:
  %t346 = load i1, ptr %l230, !tbaa !21
  br i1 %t346, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s20
  %t347 = load ptr, ptr %l0, !tbaa !29
  store ptr %t347, ptr %l234, !tbaa !29
  %t348 = getelementptr %"compiler/free:orStore", ptr %l23, i32 0, i32 1
  %t349 = load i64, ptr %t348, !tbaa !24
  store i64 %t349, ptr %l235, !tbaa !24
  %t350 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t350, ptr %l236, !tbaa !24
  %t351 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s20, i32 0, i32 0)
  store %"compiler/source:Span" %t351, ptr %l237
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t352 = load ptr, ptr %l234, !tbaa !29
  %t353 = load i64, ptr %l235, !tbaa !24
  %t354 = load i64, ptr %l236, !tbaa !24
  %t355 = load %"compiler/source:Span", ptr %l237
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t352, i64 %t353, i64 %t354, i64 -1, %"compiler/source:Span" %t355, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d31, i32 0, i32 1) })
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s20)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t356 = load i64, ptr %l22, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l22, !tbaa !24
  br label %bb93
bb110:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/free:Free", ptr %t360, i32 0, i32 88
  store ptr %t362, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb111
bb111:
  %t364 = load i64, ptr %l25, !tbaa !24
  store i64 %t364, ptr %l242, !tbaa !24
  %t365 = load ptr, ptr %l24, !tbaa !29
  %t367 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t365)
  store i64 %t367, ptr %l244
  br label %bb112
bb112:
  %t368 = load i64, ptr %l242, !tbaa !24
  %t369 = load i64, ptr %l244, !tbaa !24
  %t370 = icmp slt i64 %t368, %t369
  %t372 = xor i1 %t370, true
  br i1 %t372, label %bb113, label %bb114
bb113:
  br label %bb132
bb114:
  br label %bb115
bb115:
  %t374 = load ptr, ptr %l24, !tbaa !29
  %t375 = load i64, ptr %l25, !tbaa !24
  %t378 = call %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t374, i64 %t375)
  store %"compiler/free:orCall" %t378, ptr %l249
  br label %bb116
bb116:
  %t379 = load %"compiler/free:orCall", ptr %l249
  store %"compiler/free:orCall" %t379, ptr %l26
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/free:Free", ptr %t380, i32 0, i32 113
  %t383 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 4
  %t384 = load i64, ptr %t383, !tbaa !24
  %t387 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t382, i64 %t384)
  store i1 %t387, ptr %l253
  br label %bb117
bb117:
  %t388 = load i1, ptr %l253, !tbaa !21
  %t389 = xor i1 %t388, true
  br i1 %t389, label %bb118, label %bb119
bb118:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = getelementptr %"compiler/free:Free", ptr %t391, i32 0, i32 1
  %t394 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 2
  %t395 = load i64, ptr %t394, !tbaa !24
  %t398 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t393, i64 %t395)
  store ptr %t398, ptr %l259
  br label %bb120
bb119:
  store i1 false, ptr %l255, !tbaa !21
  br label %bb125
bb120:
  %t399 = load ptr, ptr %l259, !tbaa !29
  %t401 = getelementptr %"compiler/typed:Body", ptr %t399, i32 0, i32 11
  %t402 = load ptr, ptr %t401, !tbaa !29
  %t404 = icmp eq ptr %t402, null
  br i1 %t404, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l263, !tbaa !21
  br label %bb124
bb122:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/free:Free", ptr %t406, i32 0, i32 75
  %t409 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 2
  %t410 = load i64, ptr %t409, !tbaa !24
  %t413 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t408, i64 %t410)
  store i1 %t413, ptr %l267
  br label %bb123
bb123:
  %t414 = load i1, ptr %l267, !tbaa !21
  store i1 %t414, ptr %l263, !tbaa !21
  br label %bb124
bb124:
  %t415 = load i1, ptr %l263, !tbaa !21
  store i1 %t415, ptr %l255, !tbaa !21
  br label %bb125
bb125:
  %t416 = load i1, ptr %l255, !tbaa !21
  br i1 %t416, label %bb126, label %bb127
bb126:
  store %olang.scope zeroinitializer, ptr %s24
  %t417 = load ptr, ptr %l0, !tbaa !29
  store ptr %t417, ptr %l268, !tbaa !29
  %t418 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 4
  %t419 = load i64, ptr %t418, !tbaa !24
  store i64 %t419, ptr %l269, !tbaa !24
  %t420 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t420, ptr %l270, !tbaa !24
  %t421 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s24, i32 0, i32 0)
  store %"compiler/source:Span" %t421, ptr %l271
  br label %bb128
bb127:
  br label %bb130
bb128:
  %t422 = load ptr, ptr %l268, !tbaa !29
  %t423 = load i64, ptr %l269, !tbaa !24
  %t424 = load i64, ptr %l270, !tbaa !24
  %t425 = load %"compiler/source:Span", ptr %l271
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t422, i64 %t423, i64 %t424, i64 -1, %"compiler/source:Span" %t425, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s24)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t426 = load i64, ptr %l25, !tbaa !24
  %t428 = add i64 %t426, 1
  store i64 %t428, ptr %l25, !tbaa !24
  br label %bb111
bb132:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/free:Free", ptr %t430, i32 0, i32 112
  store ptr %t432, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb133
bb133:
  %t434 = load i64, ptr %l28, !tbaa !24
  store i64 %t434, ptr %l276, !tbaa !24
  %t435 = load ptr, ptr %l27, !tbaa !29
  %t437 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eLen_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t435)
  store i64 %t437, ptr %l278
  br label %bb134
bb134:
  %t438 = load i64, ptr %l276, !tbaa !24
  %t439 = load i64, ptr %l278, !tbaa !24
  %t440 = icmp slt i64 %t438, %t439
  %t442 = xor i1 %t440, true
  br i1 %t442, label %bb135, label %bb136
bb135:
  br label %bb154
bb136:
  br label %bb137
bb137:
  %t444 = load ptr, ptr %l27, !tbaa !29
  %t445 = load i64, ptr %l28, !tbaa !24
  %t448 = call %"compiler/free:feedCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eAt_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t444, i64 %t445)
  store %"compiler/free:feedCall" %t448, ptr %l283
  br label %bb138
bb138:
  %t449 = load %"compiler/free:feedCall", ptr %l283
  store %"compiler/free:feedCall" %t449, ptr %l29
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load %"compiler/free:feedCall", ptr %l29
  %t454 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedFits(ptr %v0, ptr %t450, %"compiler/free:feedCall" %t451)
  store i1 %t454, ptr %l286
  br label %bb139
bb139:
  %t455 = load i1, ptr %l286, !tbaa !21
  %t456 = xor i1 %t455, true
  br i1 %t456, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s28
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/free:Free", ptr %t458, i32 0, i32 110
  %t461 = getelementptr %"compiler/free:feedCall", ptr %l29, i32 0, i32 4
  %t462 = load i64, ptr %t461, !tbaa !24
  %t465 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t460, i64 %t462)
  store %"compiler/free:feed" %t465, ptr %l291
  br label %bb142
bb141:
  br label %bb152
bb142:
  %t466 = load %"compiler/free:feed", ptr %l291
  store %"compiler/free:feed" %t466, ptr %l30
  %t467 = load ptr, ptr %l0, !tbaa !29
  store ptr %t467, ptr %l292, !tbaa !29
  %t468 = getelementptr %"compiler/free:feed", ptr %l30, i32 0, i32 2
  %t469 = load i64, ptr %t468, !tbaa !24
  store i64 %t469, ptr %l293, !tbaa !24
  %t470 = load i64, ptr @G_2ecompiler_2ffree_2eRInPlace, !tbaa !24
  store i64 %t470, ptr %l294, !tbaa !24
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = getelementptr %"compiler/free:Free", ptr %t471, i32 0, i32 1
  %t474 = getelementptr %"compiler/free:feedCall", ptr %l29, i32 0, i32 0
  %t475 = load i64, ptr %t474, !tbaa !24
  %t478 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t473, i64 %t475)
  store ptr %t478, ptr %l298
  br label %bb143
bb143:
  %t479 = load ptr, ptr %l298, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Body", ptr %t479, i32 0, i32 3
  %t482 = load i64, ptr %t481, !tbaa !24
  store i64 %t482, ptr %l300, !tbaa !24
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/free:Free", ptr %t483, i32 0, i32 1
  %t486 = getelementptr %"compiler/free:feedCall", ptr %l29, i32 0, i32 0
  %t487 = load i64, ptr %t486, !tbaa !24
  %t490 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t485, i64 %t487)
  store ptr %t490, ptr %l304
  br label %bb144
bb144:
  %t491 = load ptr, ptr %l304, !tbaa !29
  %t493 = getelementptr %"compiler/typed:Body", ptr %t491, i32 0, i32 7
  %t494 = getelementptr %"compiler/free:feed", ptr %l30, i32 0, i32 1
  %t495 = load i64, ptr %t494, !tbaa !24
  %t498 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t493, i64 %t495)
  store %"compiler/typed:Local" %t498, ptr %l308
  br label %bb145
bb145:
  %t499 = getelementptr %"compiler/typed:Local", ptr %l308, i32 0, i32 1
  %t500 = load %"compiler/source:Span", ptr %t499
  store %"compiler/source:Span" %t500, ptr %l309
  %t501 = ptrtoint ptr %v0 to i64
  store i64 %t501, ptr %l310, !tbaa !24
  %t502 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t502, label %bb146, label %bb147
bb146:
  %t504 = call ptr @__olang_region_make(ptr %v0)
  %t505 = ptrtoint ptr %t504 to i64
  store i64 %t505, ptr %l310, !tbaa !24
  br label %bb147
bb147:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/free:Free", ptr %t506, i32 0, i32 0
  %t509 = load ptr, ptr %t508, !tbaa !29
  %t511 = getelementptr %"compiler/generic:Program", ptr %t509, i32 0, i32 0
  %t512 = load ptr, ptr %t511, !tbaa !29
  %t514 = getelementptr %"compiler/load:Loader", ptr %t512, i32 0, i32 3
  %t515 = load ptr, ptr %t514, !tbaa !29
  store ptr %t515, ptr %l315, !tbaa !29
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/free:Free", ptr %t516, i32 0, i32 1
  %t519 = getelementptr %"compiler/free:feedCall", ptr %l29, i32 0, i32 0
  %t520 = load i64, ptr %t519, !tbaa !24
  %t523 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t518, i64 %t520)
  store ptr %t523, ptr %l319
  br label %bb148
bb148:
  %t524 = load ptr, ptr %l319, !tbaa !29
  %t526 = getelementptr %"compiler/typed:Body", ptr %t524, i32 0, i32 7
  %t527 = getelementptr %"compiler/free:feed", ptr %l30, i32 0, i32 1
  %t528 = load i64, ptr %t527, !tbaa !24
  %t531 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t526, i64 %t528)
  store %"compiler/typed:Local" %t531, ptr %l323
  br label %bb149
bb149:
  %t532 = getelementptr %"compiler/typed:Local", ptr %l323, i32 0, i32 0
  %t533 = load i32, ptr %t532, !tbaa !23
  %t534 = load ptr, ptr %l315, !tbaa !29
  %t536 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s28, ptr %t534, i32 %t533)
  store { i64, ptr } %t536, ptr %l325
  br label %bb150
bb150:
  %t537 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t538 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t539 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 1
  %t541 = extractvalue { i64, ptr } %t539, 0
  %t542 = add i64 %t538, %t541
  %t543 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t544 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t545 = add i64 %t542, %t544
  %t546 = load i64, ptr %l310
  %t547 = inttoptr i64 %t546 to ptr
  %t548 = call ptr @__olang_scope_alloc(ptr %t547, i64 %t545)
  call void @olang_textcopy(ptr %t548, ptr %t537, i64 %t538)
  %t549 = getelementptr i8, ptr %t548, i64 %t538
  call void @olang_textcopy(ptr %t549, ptr %t540, i64 %t541)
  %t550 = getelementptr i8, ptr %t549, i64 %t541
  call void @olang_textcopy(ptr %t550, ptr %t543, i64 %t544)
  %t551 = insertvalue { i64, ptr } undef, i64 %t545, 0
  %t552 = insertvalue { i64, ptr } %t551, ptr %t548, 1
  %t554 = load i64, ptr %l310
  %t555 = inttoptr i64 %t554 to ptr
  %t556 = extractvalue { i64, ptr } %t552, 0
  %t557 = extractvalue { i64, ptr } %t552, 1
  %t558 = mul i64 %t556, 1
  %t559 = call ptr @__olang_scope_alloc(ptr %t555, i64 %t558)
  call void @llvm.memcpy.p0.p0.i64(ptr %t559, ptr %t557, i64 %t558, i1 false)
  %t560 = insertvalue { i64, ptr } undef, i64 %t556, 0
  %t561 = insertvalue { i64, ptr } %t560, ptr %t559, 1
  %t562 = load ptr, ptr %l292, !tbaa !29
  %t563 = load i64, ptr %l293, !tbaa !24
  %t564 = load i64, ptr %l294, !tbaa !24
  %t565 = load i64, ptr %l300, !tbaa !24
  %t566 = load %"compiler/source:Span", ptr %l309
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t562, i64 %t563, i64 %t564, i64 %t565, %"compiler/source:Span" %t566, { i64, ptr } %t561)
  br label %bb151
bb151:
  call void @__olang_scope_close(ptr %s28)
  br label %bb152
bb152:
  br label %bb153
bb153:
  %t568 = load i64, ptr %l28, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l28, !tbaa !24
  br label %bb133
bb154:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/free:Free", ptr %t572, i32 0, i32 83
  store ptr %t574, ptr %l31, !tbaa !29
  store i64 0, ptr %l32, !tbaa !24
  br label %bb155
bb155:
  %t576 = load i64, ptr %l32, !tbaa !24
  store i64 %t576, ptr %l332, !tbaa !24
  %t577 = load ptr, ptr %l31, !tbaa !29
  %t579 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t577)
  store i64 %t579, ptr %l334
  br label %bb156
bb156:
  %t580 = load i64, ptr %l332, !tbaa !24
  %t581 = load i64, ptr %l334, !tbaa !24
  %t582 = icmp slt i64 %t580, %t581
  %t584 = xor i1 %t582, true
  br i1 %t584, label %bb157, label %bb158
bb157:
  br label %bb177
bb158:
  br label %bb159
bb159:
  %t586 = load ptr, ptr %l31, !tbaa !29
  %t587 = load i64, ptr %l32, !tbaa !24
  %t590 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t586, i64 %t587)
  store %"compiler/free:store" %t590, ptr %l339
  br label %bb160
bb160:
  %t591 = load %"compiler/free:store", ptr %l339
  store %"compiler/free:store" %t591, ptr %l33
  %t592 = getelementptr %"compiler/free:store", ptr %l33, i32 0, i32 4
  %t593 = load i64, ptr %t592, !tbaa !24
  %t594 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t597 = icmp eq i64 %t593, %t594
  br i1 %t597, label %bb161, label %bb162
bb161:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t600 = load %"compiler/free:store", ptr %l33
  %t603 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v0, ptr %t599, %"compiler/free:store" %t600)
  store i1 %t603, ptr %l346
  br label %bb163
bb162:
  store i1 false, ptr %l343, !tbaa !21
  br label %bb171
bb163:
  %t604 = load i1, ptr %l346, !tbaa !21
  %t605 = xor i1 %t604, true
  br i1 %t605, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l348, !tbaa !21
  br label %bb170
bb165:
  %t607 = load ptr, ptr %l0, !tbaa !29
  store ptr %t607, ptr %l349, !tbaa !29
  %t608 = getelementptr %"compiler/free:store", ptr %l33, i32 0, i32 7
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t611 = icmp eq ptr %t609, null
  br i1 %t611, label %bb166, label %bb167
bb166:
  call void @__olang_check_failed(ptr @olang_loc_dcc3c6712d01991_ec14a6947a12b86d)
  unreachable
bb167:
  br label %bb168
bb168:
  %t613 = getelementptr %"compiler/free:store", ptr %l33, i32 0, i32 7
  %t614 = load ptr, ptr %t613, !tbaa !29
  %t615 = load ptr, ptr %l349, !tbaa !29
  %t617 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t615, ptr %t614)
  store i64 %t617, ptr %l353
  br label %bb169
bb169:
  %t618 = load i64, ptr %l353, !tbaa !24
  %t619 = icmp slt i64 %t618, 0
  store i1 %t619, ptr %l348, !tbaa !21
  br label %bb170
bb170:
  %t621 = load i1, ptr %l348, !tbaa !21
  store i1 %t621, ptr %l343, !tbaa !21
  br label %bb171
bb171:
  %t622 = load i1, ptr %l343, !tbaa !21
  br i1 %t622, label %bb172, label %bb173
bb172:
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/free:store", ptr %l33, i32 0, i32 0
  %t625 = load i64, ptr %t624, !tbaa !24
  %t626 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t627 = getelementptr %"compiler/free:store", ptr %l33, i32 0, i32 2
  %t628 = load i64, ptr %t627, !tbaa !24
  %t629 = getelementptr %"compiler/free:store", ptr %l33, i32 0, i32 3
  %t630 = load %"compiler/source:Span", ptr %t629
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t623, i64 %t625, i64 %t626, i64 %t628, %"compiler/source:Span" %t630, { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb174
bb173:
  br label %bb175
bb174:
  br label %bb175
bb175:
  br label %bb176
bb176:
  %t636 = load i64, ptr %l32, !tbaa !24
  %t638 = add i64 %t636, 1
  store i64 %t638, ptr %l32, !tbaa !24
  br label %bb155
bb177:
  %t640 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t640, ptr %l362
  br label %bb178
bb178:
  %t641 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l362
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t641, ptr %l34
  store %olang.scope zeroinitializer, ptr %s35
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t644 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eouterFirst(ptr %v0, ptr %s35, ptr %t642)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t644, ptr %l364
  br label %bb179
bb179:
  %t645 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l364
  %t646 = call ptr @__olang_scope_alloc_a(ptr %s35, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t645, ptr %t646
  store ptr %t646, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s36
  %t648 = load i64, ptr %l36, !tbaa !24
  store i64 %t648, ptr %l366, !tbaa !24
  %t649 = load ptr, ptr %l35, !tbaa !29
  %t651 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s35, ptr %t649)
  store i64 %t651, ptr %l368
  br label %bb181
bb181:
  %t652 = load i64, ptr %l366, !tbaa !24
  %t653 = load i64, ptr %l368, !tbaa !24
  %t654 = icmp slt i64 %t652, %t653
  %t656 = xor i1 %t654, true
  br i1 %t656, label %bb182, label %bb183
bb182:
  call void @__olang_scope_close(ptr %s36)
  br label %bb233
bb183:
  br label %bb184
bb184:
  %t658 = load ptr, ptr %l35, !tbaa !29
  %t659 = load i64, ptr %l36, !tbaa !24
  %t662 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s35, ptr %t658, i64 %t659)
  store i64 %t662, ptr %l373
  br label %bb185
bb185:
  %t663 = load i64, ptr %l373, !tbaa !24
  %t664 = load ptr, ptr %l0, !tbaa !29
  %t666 = getelementptr %"compiler/free:Free", ptr %t664, i32 0, i32 83
  %t670 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t666, i64 %t663)
  store %"compiler/free:store" %t670, ptr %l377
  br label %bb186
bb186:
  %t671 = load %"compiler/free:store", ptr %l377
  store %"compiler/free:store" %t671, ptr %l38
  %t672 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 4
  %t673 = load i64, ptr %t672, !tbaa !24
  %t674 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t677 = icmp ne i64 %t673, %t674
  br i1 %t677, label %bb187, label %bb188
bb187:
  store i1 true, ptr %l381, !tbaa !21
  br label %bb190
bb188:
  %t679 = load ptr, ptr %l0, !tbaa !29
  %t681 = getelementptr %"compiler/free:Free", ptr %t679, i32 0, i32 22
  %t682 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 1
  %t683 = load i64, ptr %t682, !tbaa !24
  %t686 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t681, i64 %t683)
  store i1 %t686, ptr %l385
  br label %bb189
bb189:
  %t687 = load i1, ptr %l385, !tbaa !21
  store i1 %t687, ptr %l381, !tbaa !21
  br label %bb190
bb190:
  %t688 = load i1, ptr %l381, !tbaa !21
  br i1 %t688, label %bb191, label %bb192
bb191:
  store i1 true, ptr %l386, !tbaa !21
  br label %bb194
bb192:
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t690 = load %"compiler/free:store", ptr %l38
  %t693 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v0, ptr %t689, %"compiler/free:store" %t690)
  store i1 %t693, ptr %l389
  br label %bb193
bb193:
  %t694 = load i1, ptr %l389, !tbaa !21
  %t695 = xor i1 %t694, true
  store i1 %t695, ptr %l386, !tbaa !21
  br label %bb194
bb194:
  %t697 = load i1, ptr %l386, !tbaa !21
  br i1 %t697, label %bb195, label %bb196
bb195:
  call void @__olang_scope_close(ptr %s36)
  br label %bb232
bb196:
  br label %bb197
bb197:
  %t698 = load ptr, ptr %l0, !tbaa !29
  store ptr %t698, ptr %l391, !tbaa !29
  %t699 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 7
  %t700 = load ptr, ptr %t699, !tbaa !29
  %t702 = icmp eq ptr %t700, null
  br i1 %t702, label %bb198, label %bb199
bb198:
  call void @__olang_check_failed(ptr @olang_loc_1c3c578240008a_e9f41163a0859586)
  unreachable
bb199:
  br label %bb200
bb200:
  %t704 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 7
  %t705 = load ptr, ptr %t704, !tbaa !29
  %t706 = load ptr, ptr %l391, !tbaa !29
  %t708 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t706, ptr %t705)
  store i64 %t708, ptr %l395
  br label %bb201
bb201:
  %t709 = load i64, ptr %l395, !tbaa !24
  store i64 %t709, ptr %l39, !tbaa !24
  %t710 = load i64, ptr %l39, !tbaa !24
  %t712 = icmp slt i64 %t710, 0
  br i1 %t712, label %bb202, label %bb203
bb202:
  store i1 true, ptr %l398, !tbaa !21
  br label %bb208
bb203:
  %t714 = load ptr, ptr %l0, !tbaa !29
  store ptr %t714, ptr %l399, !tbaa !29
  %t715 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 1
  %t716 = load i64, ptr %t715, !tbaa !24
  store i64 %t716, ptr %l400, !tbaa !24
  %t717 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 7
  %t718 = load ptr, ptr %t717, !tbaa !29
  %t720 = icmp eq ptr %t718, null
  br i1 %t720, label %bb204, label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_66d907e33dd98677_4991ee91581ac48b)
  unreachable
bb205:
  br label %bb206
bb206:
  %t722 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 7
  %t723 = load ptr, ptr %t722, !tbaa !29
  %t724 = load ptr, ptr %l399, !tbaa !29
  %t725 = load i64, ptr %l400, !tbaa !24
  %t727 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t724, i64 %t725, ptr %t723)
  store { i64, [2 x i64] } %t727, ptr %l404
  br label %bb207
bb207:
  %t728 = load { i64, [2 x i64] }, ptr %l404
  %t730 = extractvalue { i64, [2 x i64] } %t728, 0
  %t731 = icmp eq i64 %t730, 7
  store i1 %t731, ptr %l398, !tbaa !21
  br label %bb208
bb208:
  %t733 = load i1, ptr %l398, !tbaa !21
  br i1 %t733, label %bb209, label %bb210
bb209:
  store i1 true, ptr %l407, !tbaa !21
  br label %bb215
bb210:
  %t734 = load ptr, ptr %l0, !tbaa !29
  store ptr %t734, ptr %l408, !tbaa !29
  %t735 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 1
  %t736 = load i64, ptr %t735, !tbaa !24
  store i64 %t736, ptr %l409, !tbaa !24
  %t737 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 7
  %t738 = load ptr, ptr %t737, !tbaa !29
  %t740 = icmp eq ptr %t738, null
  br i1 %t740, label %bb211, label %bb212
bb211:
  call void @__olang_check_failed(ptr @olang_loc_66d907e33dd98677_4991ee91581ac48b)
  unreachable
bb212:
  br label %bb213
bb213:
  %t742 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 7
  %t743 = load ptr, ptr %t742, !tbaa !29
  %t744 = load ptr, ptr %l408, !tbaa !29
  %t745 = load i64, ptr %l409, !tbaa !24
  %t747 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t744, i64 %t745, ptr %t743)
  store { i64, [2 x i64] } %t747, ptr %l413
  br label %bb214
bb214:
  %t748 = load { i64, [2 x i64] }, ptr %l413
  %t750 = extractvalue { i64, [2 x i64] } %t748, 0
  %t751 = icmp eq i64 %t750, 8
  store i1 %t751, ptr %l407, !tbaa !21
  br label %bb215
bb215:
  %t753 = load i1, ptr %l407, !tbaa !21
  br i1 %t753, label %bb216, label %bb217
bb216:
  call void @__olang_scope_close(ptr %s36)
  br label %bb232
bb217:
  br label %bb218
bb218:
  %t754 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 1
  %t755 = load i64, ptr %t754, !tbaa !24
  %t756 = load i64, ptr %l39, !tbaa !24
  %t759 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s36, i64 %t755, i64 %t756)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t759, ptr %l418
  br label %bb219
bb219:
  %t760 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l418
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t760, ptr %l40
  %t761 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l40
  %t764 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %s0, ptr %l34, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t761)
  %t765 = extractvalue { i32, i64 } %t764, 1
  %t766 = extractvalue { i32, i64 } %t764, 0
  store i32 %t766, ptr %l423
  %t767 = icmp ne i32 %t766, 0
  br i1 %t767, label %bb221, label %ok.768, !prof !99
ok.768:
  store i64 %t765, ptr %l422
  br label %bb220
bb220:
  %t769 = load i64, ptr %l422, !tbaa !24
  store i64 %t769, ptr %l419, !tbaa !24
  br label %bb223
bb221:
  br label %bb222
bb222:
  store i64 -1, ptr %l419, !tbaa !24
  br label %bb223
bb223:
  %t770 = load i64, ptr %l419, !tbaa !24
  store i64 %t770, ptr %l41, !tbaa !24
  %t771 = load i64, ptr %l41, !tbaa !24
  %t773 = icmp slt i64 %t771, 0
  br i1 %t773, label %bb224, label %bb225
bb224:
  %t775 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l40
  %t776 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 0
  %t777 = load i64, ptr %t776, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %s0, ptr %l34, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t775, i64 %t777)
  br label %bb226
bb225:
  %t781 = load i64, ptr %l41, !tbaa !24
  %t782 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 0
  %t783 = load i64, ptr %t782, !tbaa !24
  %t786 = icmp ne i64 %t781, %t783
  br i1 %t786, label %bb227, label %bb228
bb226:
  br label %bb231
bb227:
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t789 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 0
  %t790 = load i64, ptr %t789, !tbaa !24
  %t791 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t792 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 2
  %t793 = load i64, ptr %t792, !tbaa !24
  %t794 = getelementptr %"compiler/free:store", ptr %l38, i32 0, i32 3
  %t795 = load %"compiler/source:Span", ptr %t794
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t788, i64 %t790, i64 %t791, i64 %t793, %"compiler/source:Span" %t795, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb230
bb230:
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s36)
  br label %bb232
bb232:
  %t801 = load i64, ptr %l36, !tbaa !24
  %t803 = add i64 %t801, 1
  store i64 %t803, ptr %l36, !tbaa !24
  br label %bb180
bb233:
  call void @__olang_scope_close(ptr %s35)
  store i64 0, ptr %l42, !tbaa !24
  %t805 = load i64, ptr %l1, !tbaa !24
  store i64 %t805, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t807 = load i64, ptr %l43, !tbaa !24
  %t808 = load i64, ptr %l42, !tbaa !24
  %t811 = icmp sgt i64 %t807, %t808
  br i1 %t811, label %bb234, label %bb235
bb234:
  %t813 = load i64, ptr %l44, !tbaa !24
  %t815 = icmp sgt i64 %t813, 0
  br i1 %t815, label %bb236, label %bb237
bb235:
  store i64 0, ptr %l443, !tbaa !24
  br label %bb239
bb236:
  %t817 = load i64, ptr %l43, !tbaa !24
  %t818 = load i64, ptr %l42, !tbaa !24
  %t821 = sub i64 %t817, %t818
  %t822 = load i64, ptr %l44, !tbaa !24
  %t825 = add i64 %t821, %t822
  %t827 = sub i64 %t825, 1
  %t828 = load i64, ptr %l44, !tbaa !24
  %t831 = sdiv i64 %t827, %t828
  store i64 %t831, ptr %l446, !tbaa !24
  br label %bb238
bb237:
  store i64 0, ptr %l446, !tbaa !24
  br label %bb238
bb238:
  %t833 = load i64, ptr %l446, !tbaa !24
  store i64 %t833, ptr %l443, !tbaa !24
  br label %bb239
bb239:
  %t834 = load i64, ptr %l443, !tbaa !24
  store i64 %t834, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb240
bb240:
  %t835 = load i64, ptr %l46, !tbaa !24
  %t836 = load i64, ptr %l45, !tbaa !24
  %t839 = icmp slt i64 %t835, %t836
  %t841 = xor i1 %t839, true
  br i1 %t841, label %bb241, label %bb242
bb241:
  br label %bb251
bb242:
  br label %bb243
bb243:
  %t843 = load i64, ptr %l42, !tbaa !24
  %t844 = load i64, ptr %l46, !tbaa !24
  %t845 = load i64, ptr %l44, !tbaa !24
  %t848 = mul i64 %t844, %t845
  %t851 = add i64 %t843, %t848
  store i64 %t851, ptr %l47, !tbaa !24
  %t853 = load ptr, ptr %l0, !tbaa !29
  %t855 = getelementptr %"compiler/free:Free", ptr %t853, i32 0, i32 113
  %t856 = load i64, ptr %l47, !tbaa !24
  %t859 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t855, i64 %t856)
  store i1 %t859, ptr %l467
  br label %bb244
bb244:
  %t860 = load i1, ptr %l467, !tbaa !21
  br i1 %t860, label %bb245, label %bb246
bb245:
  store %olang.scope zeroinitializer, ptr %s45
  %t861 = load ptr, ptr %l0, !tbaa !29
  store ptr %t861, ptr %l468, !tbaa !29
  %t862 = load i64, ptr %l47, !tbaa !24
  store i64 %t862, ptr %l469, !tbaa !24
  %t863 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t863, ptr %l470, !tbaa !24
  %t864 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s45, i32 0, i32 0)
  store %"compiler/source:Span" %t864, ptr %l471
  br label %bb247
bb246:
  br label %bb249
bb247:
  %t865 = load ptr, ptr %l468, !tbaa !29
  %t866 = load i64, ptr %l469, !tbaa !24
  %t867 = load i64, ptr %l470, !tbaa !24
  %t868 = load %"compiler/source:Span", ptr %l471
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t865, i64 %t866, i64 %t867, i64 -1, %"compiler/source:Span" %t868, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb248
bb248:
  call void @__olang_scope_close(ptr %s45)
  br label %bb249
bb249:
  br label %bb250
bb250:
  %t869 = load i64, ptr %l46, !tbaa !24
  %t871 = add i64 %t869, 1
  store i64 %t871, ptr %l46, !tbaa !24
  br label %bb240
bb251:
  store i64 0, ptr %l48, !tbaa !24
  %t873 = load i64, ptr %l1, !tbaa !24
  store i64 %t873, ptr %l49, !tbaa !24
  store i64 1, ptr %l50, !tbaa !24
  %t875 = load i64, ptr %l49, !tbaa !24
  %t876 = load i64, ptr %l48, !tbaa !24
  %t879 = icmp sgt i64 %t875, %t876
  br i1 %t879, label %bb252, label %bb253
bb252:
  %t881 = load i64, ptr %l50, !tbaa !24
  %t883 = icmp sgt i64 %t881, 0
  br i1 %t883, label %bb254, label %bb255
bb253:
  store i64 0, ptr %l478, !tbaa !24
  br label %bb257
bb254:
  %t885 = load i64, ptr %l49, !tbaa !24
  %t886 = load i64, ptr %l48, !tbaa !24
  %t889 = sub i64 %t885, %t886
  %t890 = load i64, ptr %l50, !tbaa !24
  %t893 = add i64 %t889, %t890
  %t895 = sub i64 %t893, 1
  %t896 = load i64, ptr %l50, !tbaa !24
  %t899 = sdiv i64 %t895, %t896
  store i64 %t899, ptr %l481, !tbaa !24
  br label %bb256
bb255:
  store i64 0, ptr %l481, !tbaa !24
  br label %bb256
bb256:
  %t901 = load i64, ptr %l481, !tbaa !24
  store i64 %t901, ptr %l478, !tbaa !24
  br label %bb257
bb257:
  %t902 = load i64, ptr %l478, !tbaa !24
  store i64 %t902, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb258
bb258:
  %t903 = load i64, ptr %l52, !tbaa !24
  %t904 = load i64, ptr %l51, !tbaa !24
  %t907 = icmp slt i64 %t903, %t904
  %t909 = xor i1 %t907, true
  br i1 %t909, label %bb259, label %bb260
bb259:
  br label %bb268
bb260:
  br label %bb261
bb261:
  %t911 = load i64, ptr %l48, !tbaa !24
  %t912 = load i64, ptr %l52, !tbaa !24
  %t913 = load i64, ptr %l50, !tbaa !24
  %t916 = mul i64 %t912, %t913
  %t919 = add i64 %t911, %t916
  store i64 %t919, ptr %l53, !tbaa !24
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t923 = getelementptr %"compiler/free:Free", ptr %t921, i32 0, i32 90
  store ptr %t923, ptr %l500, !tbaa !29
  %t924 = load i64, ptr %l53, !tbaa !24
  store i64 %t924, ptr %l501, !tbaa !24
  %t925 = load i64, ptr %l53, !tbaa !24
  %t927 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t928 = load ptr, ptr %t927, !tbaa !27
  %t929 = getelementptr i1, ptr %t928, i64 %t925
  %t930 = load i1, ptr %t929, !tbaa !31
  br i1 %t930, label %bb262, label %bb263
bb262:
  %t932 = load ptr, ptr %l0, !tbaa !29
  %t934 = getelementptr %"compiler/free:Free", ptr %t932, i32 0, i32 85
  %t935 = load i64, ptr %l53, !tbaa !24
  %t938 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t934, i64 %t935)
  store i64 %t938, ptr %l508
  br label %bb264
bb263:
  store i1 false, ptr %l504, !tbaa !21
  br label %bb265
bb264:
  %t939 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t940 = load i64, ptr %l508, !tbaa !24
  %t942 = icmp eq i64 %t940, %t939
  store i1 %t942, ptr %l504, !tbaa !21
  br label %bb265
bb265:
  %t944 = load ptr, ptr %l500, !tbaa !29
  %t945 = load i64, ptr %l501, !tbaa !24
  %t946 = load i1, ptr %l504, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t944, i64 %t945, i1 %t946)
  br label %bb266
bb266:
  br label %bb267
bb267:
  %t947 = load i64, ptr %l52, !tbaa !24
  %t949 = add i64 %t947, 1
  store i64 %t949, ptr %l52, !tbaa !24
  br label %bb258
bb268:
  store i64 0, ptr %l54, !tbaa !24
  %t951 = load i64, ptr %l1, !tbaa !24
  store i64 %t951, ptr %l55, !tbaa !24
  store i64 1, ptr %l56, !tbaa !24
  %t953 = load i64, ptr %l55, !tbaa !24
  %t954 = load i64, ptr %l54, !tbaa !24
  %t957 = icmp sgt i64 %t953, %t954
  br i1 %t957, label %bb269, label %bb270
bb269:
  %t959 = load i64, ptr %l56, !tbaa !24
  %t961 = icmp sgt i64 %t959, 0
  br i1 %t961, label %bb271, label %bb272
bb270:
  store i64 0, ptr %l517, !tbaa !24
  br label %bb274
bb271:
  %t963 = load i64, ptr %l55, !tbaa !24
  %t964 = load i64, ptr %l54, !tbaa !24
  %t967 = sub i64 %t963, %t964
  %t968 = load i64, ptr %l56, !tbaa !24
  %t971 = add i64 %t967, %t968
  %t973 = sub i64 %t971, 1
  %t974 = load i64, ptr %l56, !tbaa !24
  %t977 = sdiv i64 %t973, %t974
  store i64 %t977, ptr %l520, !tbaa !24
  br label %bb273
bb272:
  store i64 0, ptr %l520, !tbaa !24
  br label %bb273
bb273:
  %t979 = load i64, ptr %l520, !tbaa !24
  store i64 %t979, ptr %l517, !tbaa !24
  br label %bb274
bb274:
  %t980 = load i64, ptr %l517, !tbaa !24
  store i64 %t980, ptr %l57, !tbaa !24
  store i64 0, ptr %l58, !tbaa !24
  br label %bb275
bb275:
  %t981 = load i64, ptr %l58, !tbaa !24
  %t982 = load i64, ptr %l57, !tbaa !24
  %t985 = icmp slt i64 %t981, %t982
  %t987 = xor i1 %t985, true
  br i1 %t987, label %bb276, label %bb277
bb276:
  br label %bb310
bb277:
  br label %bb278
bb278:
  %t989 = load i64, ptr %l54, !tbaa !24
  %t990 = load i64, ptr %l58, !tbaa !24
  %t991 = load i64, ptr %l56, !tbaa !24
  %t994 = mul i64 %t990, %t991
  %t997 = add i64 %t989, %t994
  store i64 %t997, ptr %l59, !tbaa !24
  %t999 = load ptr, ptr %l0, !tbaa !29
  %t1001 = getelementptr %"compiler/free:Free", ptr %t999, i32 0, i32 90
  %t1002 = load i64, ptr %l59, !tbaa !24
  %t1005 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1001, i64 %t1002)
  store i1 %t1005, ptr %l541
  br label %bb279
bb279:
  %t1006 = load i1, ptr %l541, !tbaa !21
  %t1007 = xor i1 %t1006, true
  br i1 %t1007, label %bb280, label %bb281
bb280:
  store i1 true, ptr %l543, !tbaa !21
  br label %bb283
bb281:
  %t1009 = load ptr, ptr %l0, !tbaa !29
  %t1011 = getelementptr %"compiler/free:Free", ptr %t1009, i32 0, i32 12
  %t1012 = load i64, ptr %l59, !tbaa !24
  %t1015 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1011, i64 %t1012)
  store i1 %t1015, ptr %l547
  br label %bb282
bb282:
  %t1016 = load i1, ptr %l547, !tbaa !21
  %t1017 = xor i1 %t1016, true
  store i1 %t1017, ptr %l543, !tbaa !21
  br label %bb283
bb283:
  %t1019 = load i1, ptr %l543, !tbaa !21
  br i1 %t1019, label %bb284, label %bb285
bb284:
  br label %bb309
bb285:
  br label %bb286
bb286:
  store %olang.scope zeroinitializer, ptr %s53
  %t1020 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1020, ptr %l549, !tbaa !29
  %t1021 = load ptr, ptr %l0, !tbaa !29
  %t1023 = getelementptr %"compiler/free:Free", ptr %t1021, i32 0, i32 15
  %t1024 = load i64, ptr %l59, !tbaa !24
  %t1027 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t1023, i64 %t1024)
  store i32 %t1027, ptr %l553
  br label %bb287
bb287:
  %t1028 = load ptr, ptr %l549, !tbaa !29
  %t1029 = load i32, ptr %l553, !tbaa !23
  %t1030 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s53, ptr %t1028, i32 %t1029)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1030, ptr %l554
  br label %bb288
bb288:
  %t1032 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s53, ptr %l554)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1032, ptr %l556
  br label %bb289
bb289:
  %t1033 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l556
  %t1034 = call ptr @__olang_scope_alloc_a(ptr %s53, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1033, ptr %t1034
  store ptr %t1034, ptr %l60, !tbaa !29
  store i64 0, ptr %l61, !tbaa !24
  br label %bb290
bb290:
  %t1036 = load i64, ptr %l61, !tbaa !24
  store i64 %t1036, ptr %l558, !tbaa !24
  %t1037 = load ptr, ptr %l60, !tbaa !29
  %t1039 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s53, ptr %t1037)
  store i64 %t1039, ptr %l560
  br label %bb291
bb291:
  %t1040 = load i64, ptr %l558, !tbaa !24
  %t1041 = load i64, ptr %l560, !tbaa !24
  %t1042 = icmp slt i64 %t1040, %t1041
  %t1044 = xor i1 %t1042, true
  br i1 %t1044, label %bb292, label %bb293
bb292:
  br label %bb308
bb293:
  br label %bb294
bb294:
  %t1046 = load ptr, ptr %l60, !tbaa !29
  %t1047 = load i64, ptr %l61, !tbaa !24
  %t1050 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s53, ptr %t1046, i64 %t1047)
  store i64 %t1050, ptr %l565
  br label %bb295
bb295:
  %t1051 = load i64, ptr %l565, !tbaa !24
  store i64 %t1051, ptr %l62, !tbaa !24
  %t1052 = load ptr, ptr %l0, !tbaa !29
  %t1054 = getelementptr %"compiler/free:Free", ptr %t1052, i32 0, i32 13
  %t1055 = load i64, ptr %l62, !tbaa !24
  %t1058 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1054, i64 %t1055)
  store i1 %t1058, ptr %l569
  br label %bb296
bb296:
  %t1059 = load i1, ptr %l569, !tbaa !21
  br i1 %t1059, label %bb297, label %bb298
bb297:
  %t1060 = load ptr, ptr %l0, !tbaa !29
  %t1062 = getelementptr %"compiler/free:Free", ptr %t1060, i32 0, i32 90
  %t1063 = load i64, ptr %l62, !tbaa !24
  %t1066 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1062, i64 %t1063)
  store i1 %t1066, ptr %l574
  br label %bb299
bb298:
  store i1 false, ptr %l570, !tbaa !21
  br label %bb300
bb299:
  %t1067 = load i1, ptr %l574, !tbaa !21
  store i1 %t1067, ptr %l570, !tbaa !21
  br label %bb300
bb300:
  %t1068 = load i1, ptr %l570, !tbaa !21
  br i1 %t1068, label %bb301, label %bb302
bb301:
  store %olang.scope zeroinitializer, ptr %s55
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1071 = getelementptr %"compiler/free:Free", ptr %t1069, i32 0, i32 90
  %t1072 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1071, i64 %t1072, i1 false)
  br label %bb303
bb302:
  br label %bb306
bb303:
  %t1075 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1075, ptr %l578, !tbaa !29
  %t1076 = load i64, ptr %l62, !tbaa !24
  store i64 %t1076, ptr %l579, !tbaa !24
  %t1077 = load i64, ptr @G_2ecompiler_2ffree_2eRCopied, !tbaa !24
  store i64 %t1077, ptr %l580, !tbaa !24
  %t1078 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s55, i32 0, i32 0)
  store %"compiler/source:Span" %t1078, ptr %l581
  br label %bb304
bb304:
  %t1079 = load ptr, ptr %l578, !tbaa !29
  %t1080 = load i64, ptr %l579, !tbaa !24
  %t1081 = load i64, ptr %l580, !tbaa !24
  %t1082 = load %"compiler/source:Span", ptr %l581
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1079, i64 %t1080, i64 %t1081, i64 -1, %"compiler/source:Span" %t1082, { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s55)
  br label %bb306
bb306:
  br label %bb307
bb307:
  %t1083 = load i64, ptr %l61, !tbaa !24
  %t1085 = add i64 %t1083, 1
  store i64 %t1085, ptr %l61, !tbaa !24
  br label %bb290
bb308:
  call void @__olang_scope_close(ptr %s53)
  br label %bb309
bb309:
  %t1087 = load i64, ptr %l58, !tbaa !24
  %t1089 = add i64 %t1087, 1
  store i64 %t1089, ptr %l58, !tbaa !24
  br label %bb275
bb310:
  br label %bb311
bb311:
  store i1 false, ptr %l63, !tbaa !21
  %t1091 = load ptr, ptr %l0, !tbaa !29
  %t1093 = getelementptr %"compiler/free:Free", ptr %t1091, i32 0, i32 83
  store ptr %t1093, ptr %l64, !tbaa !29
  store i64 0, ptr %l65, !tbaa !24
  br label %bb312
bb312:
  %t1095 = load i64, ptr %l65, !tbaa !24
  store i64 %t1095, ptr %l588, !tbaa !24
  %t1096 = load ptr, ptr %l64, !tbaa !29
  %t1098 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t1096)
  store i64 %t1098, ptr %l590
  br label %bb313
bb313:
  %t1099 = load i64, ptr %l588, !tbaa !24
  %t1100 = load i64, ptr %l590, !tbaa !24
  %t1101 = icmp slt i64 %t1099, %t1100
  %t1103 = xor i1 %t1101, true
  br i1 %t1103, label %bb314, label %bb315
bb314:
  br label %bb332
bb315:
  br label %bb316
bb316:
  %t1105 = load ptr, ptr %l64, !tbaa !29
  %t1106 = load i64, ptr %l65, !tbaa !24
  %t1109 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t1105, i64 %t1106)
  store %"compiler/free:store" %t1109, ptr %l595
  br label %bb317
bb317:
  %t1110 = load %"compiler/free:store", ptr %l595
  store %"compiler/free:store" %t1110, ptr %l66
  %t1111 = getelementptr %"compiler/free:store", ptr %l66, i32 0, i32 4
  %t1112 = load i64, ptr %t1111, !tbaa !24
  %t1113 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t1116 = icmp eq i64 %t1112, %t1113
  br i1 %t1116, label %bb318, label %bb319
bb318:
  %t1118 = load ptr, ptr %l0, !tbaa !29
  %t1120 = getelementptr %"compiler/free:Free", ptr %t1118, i32 0, i32 90
  %t1121 = getelementptr %"compiler/free:store", ptr %l66, i32 0, i32 0
  %t1122 = load i64, ptr %t1121, !tbaa !24
  %t1125 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1120, i64 %t1122)
  store i1 %t1125, ptr %l603
  br label %bb320
bb319:
  store i1 false, ptr %l599, !tbaa !21
  br label %bb321
bb320:
  %t1126 = load i1, ptr %l603, !tbaa !21
  store i1 %t1126, ptr %l599, !tbaa !21
  br label %bb321
bb321:
  %t1127 = load i1, ptr %l599, !tbaa !21
  br i1 %t1127, label %bb322, label %bb323
bb322:
  %t1128 = load ptr, ptr %l0, !tbaa !29
  %t1130 = getelementptr %"compiler/free:Free", ptr %t1128, i32 0, i32 90
  %t1131 = getelementptr %"compiler/free:store", ptr %l66, i32 0, i32 5
  %t1132 = load i64, ptr %t1131, !tbaa !24
  %t1135 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1130, i64 %t1132)
  store i1 %t1135, ptr %l608
  br label %bb324
bb323:
  store i1 false, ptr %l604, !tbaa !21
  br label %bb325
bb324:
  %t1136 = load i1, ptr %l608, !tbaa !21
  %t1137 = xor i1 %t1136, true
  store i1 %t1137, ptr %l604, !tbaa !21
  br label %bb325
bb325:
  %t1139 = load i1, ptr %l604, !tbaa !21
  br i1 %t1139, label %bb326, label %bb327
bb326:
  %t1140 = load ptr, ptr %l0, !tbaa !29
  %t1142 = getelementptr %"compiler/free:Free", ptr %t1140, i32 0, i32 90
  %t1143 = getelementptr %"compiler/free:store", ptr %l66, i32 0, i32 0
  %t1144 = load i64, ptr %t1143, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1142, i64 %t1144, i1 false)
  br label %bb328
bb327:
  br label %bb330
bb328:
  %t1147 = load ptr, ptr %l0, !tbaa !29
  %t1148 = getelementptr %"compiler/free:store", ptr %l66, i32 0, i32 0
  %t1149 = load i64, ptr %t1148, !tbaa !24
  %t1150 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t1151 = getelementptr %"compiler/free:store", ptr %l66, i32 0, i32 2
  %t1152 = load i64, ptr %t1151, !tbaa !24
  %t1153 = getelementptr %"compiler/free:store", ptr %l66, i32 0, i32 3
  %t1154 = load %"compiler/source:Span", ptr %t1153
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1147, i64 %t1149, i64 %t1150, i64 %t1152, %"compiler/source:Span" %t1154, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb329
bb329:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb330
bb330:
  br label %bb331
bb331:
  %t1160 = load i64, ptr %l65, !tbaa !24
  %t1162 = add i64 %t1160, 1
  store i64 %t1162, ptr %l65, !tbaa !24
  br label %bb312
bb332:
  %t1164 = load i1, ptr %l63, !tbaa !21
  %t1166 = xor i1 %t1164, true
  br i1 %t1166, label %bb333, label %bb334
bb333:
  br label %bb337
bb334:
  br label %bb335
bb335:
  br label %bb336
bb336:
  br label %bb311
bb337:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edeclaredHere(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i1
  %l26 = alloca ptr
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t4)
  store ptr %t6, ptr %l6
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t8, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t12 = load i32, ptr %l8, !tbaa !23
  %t13 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t13, ptr %l9
  br label %bb4
bb4:
  %t14 = load i64, ptr %l9, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 10
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l18
  br label %bb7
bb6:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  %t31 = load i64, ptr %l13, !tbaa !24
  %t32 = load i64, ptr %l18, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l12, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/load:Loader", ptr %t42, i32 0, i32 10
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store ptr %t48, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb11:
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t51 = getelementptr %"compiler/load:Module", ptr %t49, i32 0, i32 2
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t54, ptr %l29
  br label %bb12
bb12:
  %t55 = load i1, ptr %l29, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i1, ptr %l20, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentry(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l12, !tbaa !24
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1c505c1b55d06586_a0a7e4d6315dd1d2)
  unreachable
bb10:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb14
bb12:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 80
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l23
  br label %bb13
bb13:
  %t36 = load i1, ptr %l23, !tbaa !21
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:Free", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l30
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t53, ptr %l31
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l31, !tbaa !29
  store ptr %t54, ptr %l5, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb22
bb21:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Func", ptr %t64, i32 0, i32 7
  %t67 = load i1, ptr %t66, !tbaa !21
  store i1 %t67, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb27
bb24:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/load:Loader", ptr %t76, i32 0, i32 3
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t79, i32 %t83)
  store { i64, ptr } %t86, ptr %l46
  br label %bb25
bb25:
  %t87 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t88, ptr %l47
  br label %bb26
bb26:
  %t89 = load i1, ptr %l47, !tbaa !21
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load i1, ptr %l39, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedDest(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [2 x i64] } %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/free:feed"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca %"compiler/free:feed"
  %l20 = alloca i1
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 110
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l11
  br label %bb2
bb2:
  %t9 = load i64, ptr %l9, !tbaa !24
  %t10 = load i64, ptr %l11, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/free:feed" %t19, ptr %l16
  br label %bb6
bb6:
  %t20 = load %"compiler/free:feed", ptr %l16
  store %"compiler/free:feed" %t20, ptr %l6
  %t21 = getelementptr %"compiler/free:feed", ptr %l6, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = icmp eq i64 %t22, %a1
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = getelementptr %"compiler/free:feed", ptr %l6, i32 0, i32 6
  %t29 = load i64, ptr %t28, !tbaa !24
  %t33 = icmp eq i64 %t29, %a2
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = getelementptr %"compiler/free:feed", ptr %l6, i32 0, i32 5
  %t37 = load { i64, [2 x i64] }, ptr %t36
  store { i64, [2 x i64] } %t37, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l5, !tbaa !24
  br label %bb1
bb14:
  store { i64, [2 x i64] } %a3, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedFits(ptr %v0, ptr %a0, %"compiler/free:feedCall" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:feedCall"
  %l2 = alloca %"compiler/free:feed"
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca ptr
  %l9 = alloca %"compiler/free:feed"
  %l13 = alloca i64
  %l20 = alloca ptr
  %l25 = alloca { i64, [2 x i64] }
  %l26 = alloca { i64, [2 x i64] }
  %l28 = alloca { i64, [2 x i64] }
  %l30 = alloca i1
  %l37 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:feedCall" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 110
  %t4 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 4
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t3, i64 %t5)
  store %"compiler/free:feed" %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load %"compiler/free:feed", ptr %l9
  store %"compiler/free:feed" %t9, ptr %l2
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 3
  %t14 = load i64, ptr %t13, !tbaa !24
  %t18 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t10, i64 %t12, i64 %t14)
  store i64 %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp slt i64 %t20, 0
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:Free", ptr %t25, i32 0, i32 3
  %t28 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t27, i64 %t29)
  store ptr %t32, ptr %l20
  br label %bb6
bb6:
  %t33 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = trunc i64 %t34 to i32
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t42 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t39, i32 %t36, i64 %t38)
  store { i64, [2 x i64] } %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load { i64, [2 x i64] }, ptr %l25
  store { i64, [2 x i64] } %t43, ptr %l4
  %t44 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t44, ptr %l26
  %t45 = getelementptr %"compiler/free:feed", ptr %l2, i32 0, i32 4
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l28
  %t49 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l26, ptr %l28)
  store i1 %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load i1, ptr %l30, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 5
  %t54 = load i1, ptr %t53, !tbaa !21
  %t56 = xor i1 %t54, true
  store i1 %t56, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 1
  %t62 = load i64, ptr %t61, !tbaa !24
  %t66 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v0, ptr %t58, i64 %t60, i64 %t62)
  store ptr %t66, ptr %l37
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l37, !tbaa !29
  store ptr %t67, ptr %l5, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb13, label %bb14
bb13:
  %t72 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 5
  %t73 = load i1, ptr %t72, !tbaa !21
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load { i64, [2 x i64] }, ptr %l4
  %t84 = load i64, ptr %l3, !tbaa !24
  %t91 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t77, i64 %t79, ptr %t80, i64 %t82, { i64, [2 x i64] } %t83, i64 %t84)
  store i64 %t91, ptr %l48
  br label %bb16
bb16:
  %t92 = load i64, ptr %l48, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb19
bb18:
  %t95 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 5
  %t96 = load i1, ptr %t95, !tbaa !21
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l50, !tbaa !21
  br label %bb19
bb19:
  %t100 = load i1, ptr %l50, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l59 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l119 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca i1
  %l150 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l182 = alloca ptr
  %l203 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store i64 %t26, ptr %l40
  br label %bb6
bb6:
  %t27 = load i64, ptr %l40, !tbaa !24
  %t28 = icmp slt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t30, i32 %t31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l44
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb131
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t36 = load ptr, ptr %l45, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l45, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 6
  store i1 %t42, ptr %l46, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l46, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Call", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t67, ptr %l59, !tbaa !27
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr ptr, ptr %t71, i64 %t68
  %t73 = load ptr, ptr %t72, !tbaa !39
  %t75 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t75, ptr %t73)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  br label %bb131
bb24:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t84 = load ptr, ptr %l66, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l66, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 14
  store i1 %t90, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l67, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l9, !tbaa !29
  br label %bb29
bb28:
  br label %bb50
bb29:
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Try", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l76, !tbaa !29
  %t108 = load ptr, ptr %l9, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Try", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_7bd178b281ab108b_bca5961225cfb287)
  unreachable
bb33:
  br label %bb34
bb34:
  %t115 = load ptr, ptr %l9, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Try", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t119, ptr %t118)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t121 = load ptr, ptr %l9, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Try", ptr %t121, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb38, label %bb39
bb38:
  br label %bb49
bb39:
  br label %bb40
bb40:
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t138, ptr %l90, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 %t139
  %t144 = load ptr, ptr %t143, !tbaa !39
  store ptr %t144, ptr %l13, !tbaa !29
  %t146 = load ptr, ptr %l13, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Clause", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb41, label %bb42
bb41:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l97, !tbaa !29
  %t156 = load ptr, ptr %l13, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Clause", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb43, label %bb44
bb42:
  br label %bb47
bb43:
  call void @__olang_check_failed(ptr @olang_loc_54a8cb88ede7d99c_f1d49282556d5568)
  unreachable
bb44:
  br label %bb45
bb45:
  %t163 = load ptr, ptr %l13, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Clause", ptr %t163, i32 0, i32 3
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t167, ptr %t166)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l11, !tbaa !24
  br label %bb37
bb49:
  br label %bb131
bb50:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t174 = load ptr, ptr %l105, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t177 = load ptr, ptr %l105, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 18}
  %t180 = icmp eq i64 %t178, 12
  store i1 %t180, ptr %l106, !tbaa !21
  br label %bb52
bb52:
  %t181 = load i1, ptr %l106, !tbaa !21
  br i1 %t181, label %bb53, label %bb54
bb53:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l14, !tbaa !29
  br label %bb55
bb54:
  br label %bb70
bb55:
  %t188 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Seq", ptr %t188, i32 0, i32 0
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l17, !tbaa !24
  br label %bb56
bb56:
  %t197 = load i64, ptr %l16, !tbaa !24
  %t198 = load i64, ptr %l17, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t205 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t205, ptr %l119, !tbaa !27
  %t206 = load i64, ptr %l16, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t213 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %t213, ptr %t211)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l16, !tbaa !24
  br label %bb56
bb62:
  %t221 = load ptr, ptr %l14, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Seq", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb63, label %bb64
bb63:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l130, !tbaa !29
  %t231 = load ptr, ptr %l14, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Seq", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = icmp eq ptr %t234, null
  br i1 %t236, label %bb65, label %bb66
bb64:
  br label %bb69
bb65:
  call void @__olang_check_failed(ptr @olang_loc_df2621a9cc7e5891_c8dc80a57ad57a3d)
  unreachable
bb66:
  br label %bb67
bb67:
  %t238 = load ptr, ptr %l14, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Seq", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t242, ptr %t241)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb131
bb70:
  %t244 = load ptr, ptr %l1, !tbaa !29
  store ptr %t244, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t245 = load ptr, ptr %l136, !tbaa !29
  %t246 = icmp ne ptr %t245, null
  br i1 %t246, label %bb71, label %bb72
bb71:
  %t248 = load ptr, ptr %l136, !tbaa !29
  %t249 = load i64, ptr %t248, !range !{i64 0, i64 18}
  %t251 = icmp eq i64 %t249, 13
  store i1 %t251, ptr %l137, !tbaa !21
  br label %bb72
bb72:
  %t252 = load i1, ptr %l137, !tbaa !21
  br i1 %t252, label %bb73, label %bb74
bb73:
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t255, i32 0, i32 2
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l19, !tbaa !29
  br label %bb75
bb74:
  br label %bb119
bb75:
  %t259 = load ptr, ptr %l19, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Match", ptr %t259, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  store i64 %t266, ptr %l22, !tbaa !24
  br label %bb76
bb76:
  %t268 = load i64, ptr %l21, !tbaa !24
  %t269 = load i64, ptr %l22, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb77, label %bb78
bb77:
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t276 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t276, ptr %l150, !tbaa !27
  %t277 = load i64, ptr %l21, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr ptr, ptr %t280, i64 %t277
  %t282 = load ptr, ptr %t281, !tbaa !39
  %t284 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %t284, ptr %t282)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t288 = load i64, ptr %l21, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l21, !tbaa !24
  br label %bb76
bb82:
  %t292 = load ptr, ptr %l19, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Match", ptr %t292, i32 0, i32 1
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !27
  store { i64, ptr } %t295, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  store i64 %t299, ptr %l26, !tbaa !24
  br label %bb83
bb83:
  %t301 = load i64, ptr %l25, !tbaa !24
  %t302 = load i64, ptr %l26, !tbaa !24
  %t305 = icmp slt i64 %t301, %t302
  %t307 = xor i1 %t305, true
  br i1 %t307, label %bb84, label %bb85
bb84:
  br label %bb102
bb85:
  br label %bb86
bb86:
  %t309 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t309, ptr %l165, !tbaa !27
  %t310 = load i64, ptr %l25, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr ptr, ptr %t313, i64 %t310
  %t315 = load ptr, ptr %t314, !tbaa !39
  store ptr %t315, ptr %l27, !tbaa !29
  %t317 = load ptr, ptr %l27, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Arm", ptr %t317, i32 0, i32 3
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb87, label %bb88
bb87:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l172, !tbaa !29
  %t327 = load ptr, ptr %l27, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Arm", ptr %t327, i32 0, i32 3
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = icmp eq ptr %t330, null
  br i1 %t332, label %bb89, label %bb90
bb88:
  br label %bb93
bb89:
  call void @__olang_check_failed(ptr @olang_loc_d176219a3bee3f8a_90c874c8f8700e56)
  unreachable
bb90:
  br label %bb91
bb91:
  %t334 = load ptr, ptr %l27, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Arm", ptr %t334, i32 0, i32 3
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t338 = load ptr, ptr %l172, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t338, ptr %t337)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t340 = load ptr, ptr %l27, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Arm", ptr %t340, i32 0, i32 4
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = icmp eq ptr %t343, null
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb94, label %bb95
bb94:
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l182, !tbaa !29
  %t350 = load ptr, ptr %l27, !tbaa !29
  %t352 = getelementptr %"compiler/typed:Arm", ptr %t350, i32 0, i32 4
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = icmp eq ptr %t353, null
  br i1 %t355, label %bb96, label %bb97
bb95:
  br label %bb100
bb96:
  call void @__olang_check_failed(ptr @olang_loc_3832ed25f787c577_46d12f44adcfa45b)
  unreachable
bb97:
  br label %bb98
bb98:
  %t357 = load ptr, ptr %l27, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Arm", ptr %t357, i32 0, i32 4
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t361 = load ptr, ptr %l182, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t361, ptr %t360)
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t363 = load i64, ptr %l25, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l25, !tbaa !24
  br label %bb83
bb102:
  %t367 = load ptr, ptr %l19, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Match", ptr %t367, i32 0, i32 2
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb103, label %bb104
bb103:
  %t376 = load ptr, ptr %l19, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Match", ptr %t376, i32 0, i32 2
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t381 = icmp eq ptr %t379, null
  br i1 %t381, label %bb105, label %bb106
bb104:
  br label %bb118
bb105:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb106:
  br label %bb107
bb107:
  %t383 = load ptr, ptr %l19, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Match", ptr %t383, i32 0, i32 2
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Arm", ptr %t386, i32 0, i32 3
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = icmp eq ptr %t390, null
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb108, label %bb109
bb108:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l203, !tbaa !29
  %t397 = load ptr, ptr %l19, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Match", ptr %t397, i32 0, i32 2
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = icmp eq ptr %t400, null
  br i1 %t402, label %bb110, label %bb111
bb109:
  br label %bb117
bb110:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb111:
  br label %bb112
bb112:
  %t404 = load ptr, ptr %l19, !tbaa !29
  %t406 = getelementptr %"compiler/typed:Match", ptr %t404, i32 0, i32 2
  %t407 = load ptr, ptr %t406, !tbaa !29
  %t410 = getelementptr %"compiler/typed:Arm", ptr %t407, i32 0, i32 3
  %t411 = load ptr, ptr %t410, !tbaa !29
  store ptr %t411, ptr %l28, !tbaa !29
  %t413 = load ptr, ptr %l28, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb113, label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb114:
  br label %bb115
bb115:
  %t417 = load ptr, ptr %l28, !tbaa !29
  %t418 = load ptr, ptr %l203, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t418, ptr %t417)
  br label %bb116
bb116:
  br label %bb117
bb117:
  br label %bb118
bb118:
  br label %bb131
bb119:
  %t420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t420, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t421 = load ptr, ptr %l214, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb120, label %bb121
bb120:
  %t424 = load ptr, ptr %l214, !tbaa !29
  %t425 = load i64, ptr %t424, !range !{i64 0, i64 18}
  %t427 = icmp eq i64 %t425, 8
  store i1 %t427, ptr %l215, !tbaa !21
  br label %bb121
bb121:
  %t428 = load i1, ptr %l215, !tbaa !21
  br i1 %t428, label %bb122, label %bb123
bb122:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t431, i32 0, i32 2
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l29, !tbaa !29
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l29, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Collect", ptr %t436, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t435, ptr %t439)
  br label %bb125
bb125:
  br label %bb131
bb126:
  br i1 true, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_5c0fdc79e2d66a14_68e7480db742a728)
  unreachable
bb131:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindFeeds(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l4 = alloca %"compiler/typed:LocalUses"
  %l8 = alloca ptr
  %l12 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca i64
  %l17 = alloca ptr
  %l19 = alloca %"compiler/typed:LocalUses"
  %l20 = alloca ptr
  %l21 = alloca i64
  %s0 = alloca %olang.scope
  %t27 = alloca %"compiler/typed:LocalUses", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l8, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 14
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eLastCopies(ptr %v0, ptr %s0, ptr %t14, i1 true)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %l12
  br label %bb5
bb5:
  %t17 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l12
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l3
  %t19 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %s0, ptr %l3)
  store i64 %t19, ptr %l14
  br label %bb6
bb6:
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = icmp eq i64 %t20, 0
  br i1 %t21, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t23)
  store ptr %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = load ptr, ptr %l17, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t27, ptr %v0, ptr %v0, ptr %s0, ptr %t28, ptr %t26)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t27, i64 704, i1 false)
  br label %bb11
bb11:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l19, i64 704, i1 false)
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %l21, !tbaa !24
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 11
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_1a9841d5ac3bc9f7_8d61e2fce1a4aee3)
  unreachable
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Body", ptr %t39, i32 0, i32 11
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load ptr, ptr %l20, !tbaa !29
  %t44 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v0, ptr %s0, ptr %s0, ptr %t43, i64 %t44, ptr %t42, ptr %l3, ptr %l4)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenBodyNever(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l15 = alloca i1
  %l20 = alloca i1
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca %"compiler/typed:Local"
  %l35 = alloca i1
  %l39 = alloca i1
  %l45 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca ptr
  %l52 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l12, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 1
  %t12 = load { i64, [2 x i64] }, ptr %t11
  %t16 = extractvalue { i64, [2 x i64] } %t12, 0
  %t17 = icmp eq i64 %t16, 4
  br i1 %t17, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_51b1502f0d390a1a_ce0c44316c965fde)
  unreachable
bb10:
  %t19 = load i1, ptr %l15, !tbaa !21
  store i1 %t19, ptr %l4, !tbaa !21
  %t20 = load i1, ptr %l4, !tbaa !21
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 14
  %t27 = load i1, ptr %t26, !tbaa !21
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb14, label %bb15
bb14:
  br label %ret
bb15:
  br label %bb16
bb16:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 7
  store ptr %t34, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t36 = load i64, ptr %l6, !tbaa !24
  store i64 %t36, ptr %l26, !tbaa !24
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l28
  br label %bb18
bb18:
  %t40 = load i64, ptr %l26, !tbaa !24
  %t41 = load i64, ptr %l28, !tbaa !24
  %t42 = icmp slt i64 %t40, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb19, label %bb20
bb19:
  br label %bb42
bb20:
  br label %bb21
bb21:
  %t46 = load ptr, ptr %l5, !tbaa !29
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t46, i64 %t47)
  store %"compiler/typed:Local" %t50, ptr %l33
  br label %bb22
bb22:
  %t51 = load %"compiler/typed:Local", ptr %l33
  store %"compiler/typed:Local" %t51, ptr %l7
  %t52 = load i1, ptr %l4, !tbaa !21
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t54 = load ptr, ptr %l2, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 14
  %t57 = load i1, ptr %t56, !tbaa !21
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l35, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb25
bb25:
  %t61 = load i1, ptr %l35, !tbaa !21
  br i1 %t61, label %bb26, label %bb27
bb26:
  %t62 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t63 = load i32, ptr %t62, !range !{i32 0, i32 7}
  %t65 = trunc i64 5 to i32
  %t66 = icmp eq i32 %t63, %t65
  %t68 = xor i1 %t66, true
  store i1 %t68, ptr %l39, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb28
bb28:
  %t70 = load i1, ptr %l39, !tbaa !21
  br i1 %t70, label %bb29, label %bb30
bb29:
  br label %bb41
bb30:
  br label %bb31
bb31:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 14
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb32, label %bb33
bb32:
  store { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l45, !tbaa !27
  br label %bb34
bb34:
  %t76 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t76, ptr %l8, !tbaa !27
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t79 = load i32, ptr %t78, !tbaa !23
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efuncTy(ptr %v0, ptr %t77, i32 %t79)
  store i1 %t82, ptr %l48
  br label %bb35
bb35:
  %t83 = load i1, ptr %l48, !tbaa !21
  br i1 %t83, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l49, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t87 = load i32, ptr %t86, !tbaa !23
  %t90 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %t85, i32 %t87)
  store i64 %t90, ptr %l52
  br label %bb39
bb39:
  %t91 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Body", ptr %t92, i32 0, i32 3
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 1
  %t97 = load %"compiler/source:Span", ptr %t96
  %t98 = load ptr, ptr @__olang_prog_scope
  %t99 = load ptr, ptr %l49, !tbaa !29
  %t100 = load i64, ptr %l52, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %t98, ptr %t99, i64 %t100, { i64, ptr } %t91, i64 %t95, %"compiler/source:Span" %t97)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l6, !tbaa !24
  br label %bb17
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenKeeps(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l41 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 5
  %t8 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = icmp eq i64 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l1, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 9
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l14
  br label %bb5
bb5:
  %t17 = load i64, ptr %l14, !tbaa !24
  store i64 %t17, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb11
bb8:
  %t28 = load i64, ptr %l2, !tbaa !24
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l21, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l18, !tbaa !24
  br label %bb11
bb11:
  %t45 = load i64, ptr %l18, !tbaa !24
  store i64 %t45, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb12
bb12:
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb13, label %bb14
bb13:
  br label %bb23
bb14:
  br label %bb15
bb15:
  %t54 = load i64, ptr %l1, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l3, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l6, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenPlace(ptr %v0, ptr %t64, i64 %t65)
  store i1 %t68, ptr %l41
  br label %bb16
bb16:
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l42, !tbaa !29
  %t71 = load i64, ptr %l6, !tbaa !24
  store i64 %t71, ptr %l43, !tbaa !24
  %t72 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t72, ptr %l44, !tbaa !24
  %t73 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 0, i32 0)
  store %"compiler/source:Span" %t73, ptr %l45
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t74 = load ptr, ptr %l42, !tbaa !29
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = load i64, ptr %l44, !tbaa !24
  %t77 = load %"compiler/source:Span", ptr %l45
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t74, i64 %t75, i64 %t76, i64 -1, %"compiler/source:Span" %t77, { i64, ptr } { i64 123, ptr getelementptr inbounds (<{ i64, [123 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l5, !tbaa !24
  br label %bb12
bb23:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNever(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %lp5 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i64 %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp eq i64 %t1, -2
  br i1 %t3, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sge i64 %t5, 0
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:Free", ptr %t9, i32 0, i32 0
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/load:Loader", ptr %t15, i32 0, i32 4
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  %t23 = sext i32 %t21 to i64
  %t27 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s0, ptr %t18, i64 %t19, i64 %t23)
  store { i64, ptr } %t27, ptr %l18
  br label %bb6
bb5:
  %t28 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t30 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t32 = extractvalue { i64, ptr } %t28, 1
  %t33 = extractvalue { i64, ptr } %t28, 0
  %t34 = add i64 %t30, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t29, i64 %t30)
  %t36 = getelementptr i8, ptr %t35, i64 %t30
  call void @olang_textcopy(ptr %t36, ptr %t32, i64 %t33)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t35, 1
  store { i64, ptr } %t38, ptr %l10, !tbaa !27
  br label %bb7
bb6:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t48 = extractvalue { i64, ptr } %t40, 1
  %t49 = extractvalue { i64, ptr } %t40, 0
  %t50 = add i64 %t46, %t49
  %t51 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t50)
  call void @olang_textcopy(ptr %t51, ptr %t42, i64 %t43)
  %t52 = getelementptr i8, ptr %t51, i64 %t43
  call void @olang_textcopy(ptr %t52, ptr %t44, i64 %t45)
  %t53 = getelementptr i8, ptr %t52, i64 %t45
  call void @olang_textcopy(ptr %t53, ptr %t48, i64 %t49)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t51, 1
  store { i64, ptr } %t55, ptr %l10, !tbaa !27
  br label %bb7
bb7:
  %t57 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t57, ptr %lp5
  %t58 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t59 = load ptr, ptr %lp5
  store { i64, ptr } %t58, ptr %t59, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:Free", ptr %t60, i32 0, i32 43
  %t63 = load i1, ptr %t62, !tbaa !21
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb8, label %bb9
bb8:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:Free", ptr %t67, i32 0, i32 44
  %t70 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 %t70)
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 45
  %t76 = load ptr, ptr %lp5
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t75, { i64, ptr } %t77)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i64, ptr %l1, !tbaa !24
  %t82 = load ptr, ptr %lp5
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNeverText(ptr %v0, ptr %v0, ptr %t80, i64 %t81, { i64, ptr } %t83)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNeverAgain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i64
  %l43 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 43
  store i1 true, ptr %t3, !tbaa !21
  store i64 0, ptr %l1, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 44
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i64, ptr %l10, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l1, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t24, %t25
  %t30 = sub i64 %t28, 1
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sdiv i64 %t30, %t31
  store i64 %t34, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l17, !tbaa !24
  store i64 %t36, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l14, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb9, label %bb10
bb9:
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = mul i64 %t47, %t48
  %t54 = add i64 %t46, %t51
  store i64 %t54, ptr %l6, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l35, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 44
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t60)
  store i64 %t63, ptr %l39
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/free:Free", ptr %t64, i32 0, i32 45
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store { i64, ptr } %t70, ptr %l43
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l35, !tbaa !29
  %t72 = load i64, ptr %l39, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l43, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNeverText(ptr %v0, ptr %v0, ptr %t71, i64 %t72, { i64, ptr } %t73)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t74 = load i64, ptr %l5, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l5, !tbaa !24
  br label %bb8
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l33 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i32, ptr %l9, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l12
  br label %bb3
bb3:
  %t16 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb9:
  %t32 = load ptr, ptr %l2, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l25
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l26
  br label %bb11
bb11:
  %t41 = load i32, ptr %l26, !range !{i32 0, i32 6}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l33
  br label %bb16
bb16:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %l35, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l38
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i32, ptr %l38, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t63, i32 %t64)
  store { i64, ptr } %t65, ptr %l39
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp eq i64 %t69, 1
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l45, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 0
  %t78 = load i32, ptr %t77, !tbaa !33
  %t81 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t73, i32 %t78)
  store i1 %t81, ptr %l47
  br label %bb24
bb23:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  %t82 = load i1, ptr %l47, !tbaa !21
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l43, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l6 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  %t15 = extractvalue { i64, [2 x i64] } %t11, 0
  %t16 = icmp eq i64 %t15, 2
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_c5e41b8fc96972ee_4e89d8a2bd660d32)
  unreachable
bb10:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 85
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t9 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp ne i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %t13, i64 %t14, i64 %t15, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4)
  br label %bb5
bb5:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp sge i64 %t25, 0
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 100
  %t32 = load i64, ptr %l1, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t31, i64 %t32, i64 %t33)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %lp4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca %"compiler/free:leaf"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l30 = alloca i32
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i32
  %l39 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i32
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i32
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca ptr
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca i64
  %l111 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l115 = alloca %"compiler/free:leaf"
  %l117 = alloca %"compiler/free:leaf"
  %l119 = alloca { i64, ptr }
  %l122 = alloca i32
  %l125 = alloca i32
  %l128 = alloca i1
  %l131 = alloca i1
  %l132 = alloca i1
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca i32
  %l142 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca i64
  %l146 = alloca i64
  %l151 = alloca %"compiler/free:leaf"
  %l153 = alloca %"compiler/free:leaf"
  %l156 = alloca i64
  %l166 = alloca i64
  %l169 = alloca i64
  %l193 = alloca ptr
  %l196 = alloca %"compiler/free:leaf"
  %l198 = alloca %"compiler/free:leaf"
  %l204 = alloca ptr
  %l205 = alloca i32
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l26
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l26, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l27, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l30
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l27, !tbaa !29
  %t12 = load i32, ptr %l30, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l31
  br label %bb3
bb3:
  %t14 = load i32, ptr %l31, !tbaa !23
  store i32 %t14, ptr %l3, !tbaa !23
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l32
  br label %bb4
bb4:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t16, ptr %lp4
  %t17 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t18 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %t18
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l35
  br label %bb5
bb5:
  %t24 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb9
bb7:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l42
  br label %bb8
bb8:
  %t36 = load i1, ptr %l42, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l39, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l39, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb14
bb11:
  %t40 = load ptr, ptr %l2, !tbaa !29
  store ptr %t40, ptr %l45, !tbaa !29
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l48
  br label %bb12
bb12:
  %t46 = load ptr, ptr %l45, !tbaa !29
  %t47 = load i32, ptr %l48, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t48, ptr %l49
  br label %bb13
bb13:
  %t49 = load i32, ptr %l49, !range !{i32 0, i32 6}
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  %t54 = xor i1 %t52, true
  store i1 %t54, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l44, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %lp4
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t57
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:Free", ptr %t60, i32 0, i32 19
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He7b3466db9a608577543dd7c0832d3d6(ptr %v0, ptr %v1, ptr %t62, i32 %t63)
  %t67 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t66, 1
  %t68 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t66, 0
  store i32 %t68, ptr %l59
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb19, label %ok.70, !prof !99
ok.70:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l58
  br label %bb18
bb18:
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %l58)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l61
  br label %bb21
bb19:
  br label %bb20
bb20:
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l62
  br label %bb22
bb21:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l54
  br label %bb23
bb22:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l54
  br label %bb23
bb23:
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t76, ptr %lp5
  %t77 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  %t78 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %t78
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:Free", ptr %t79, i32 0, i32 19
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H39ca684a9144c6cba1af5dc2ea7b2e34(ptr %v0, ptr %t81, i32 %t82)
  store i1 %t85, ptr %l66
  br label %bb24
bb24:
  %t86 = load i1, ptr %l66, !tbaa !21
  br i1 %t86, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %lp5
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t87
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 19
  store ptr %t92, ptr %l69, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  store i32 %t93, ptr %l70, !tbaa !23
  %t94 = load ptr, ptr %lp4
  %t95 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l71
  %t97 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l71)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l73
  br label %bb28
bb28:
  %t98 = load ptr, ptr %l69, !tbaa !29
  %t99 = load i32, ptr %l70, !tbaa !23
  %t100 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %s0, ptr %t98, i32 %t99, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100)
  br label %bb29
bb29:
  %t101 = load ptr, ptr %l2, !tbaa !29
  store ptr %t101, ptr %l74, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t103 = load i32, ptr %l3, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l77
  br label %bb30
bb30:
  %t107 = load ptr, ptr %l74, !tbaa !29
  %t108 = load i32, ptr %l77, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t107, i32 %t108)
  store { i64, ptr } %t109, ptr %l78
  br label %bb31
bb31:
  %t110 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t110, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t115 = load i64, ptr %l8, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb37
bb34:
  %t125 = load i64, ptr %l8, !tbaa !24
  %t126 = load i64, ptr %l7, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l9, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l9, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l87, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb36
bb36:
  %t141 = load i64, ptr %l87, !tbaa !24
  store i64 %t141, ptr %l84, !tbaa !24
  br label %bb37
bb37:
  %t142 = load i64, ptr %l84, !tbaa !24
  store i64 %t142, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb38
bb38:
  %t143 = load i64, ptr %l11, !tbaa !24
  %t144 = load i64, ptr %l10, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb39, label %bb40
bb39:
  br label %bb93
bb40:
  br label %bb41
bb41:
  %t151 = load i64, ptr %l7, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  %t153 = load i64, ptr %l9, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  store i64 %t159, ptr %l12, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l3, !tbaa !23
  %t163 = load i64, ptr %l12, !tbaa !24
  %t167 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t161, i32 %t162, i64 %t163)
  store i64 %t167, ptr %l108
  br label %bb42
bb42:
  %t168 = load i64, ptr %l108, !tbaa !24
  store i64 %t168, ptr %l13, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  %t171 = icmp sge i64 %t169, 0
  br i1 %t171, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s5
  %t173 = load ptr, ptr %lp4
  store ptr %t173, ptr %l111, !tbaa !29
  %t174 = load i64, ptr %l12, !tbaa !24
  %t175 = mul i64 1, 8
  %t176 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t175)
  %t177 = insertvalue { i64, ptr } undef, i64 1, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l113, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t181 = load ptr, ptr %t180, !tbaa !27
  %t182 = getelementptr i64, ptr %t181, i64 0
  store i64 %t174, ptr %t182, !tbaa !34
  %t183 = load i64, ptr %l13, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t186 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %s5, { i64, ptr } %t184, i64 %t183)
  store %"compiler/free:leaf" %t186, ptr %l115
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t188 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s5, ptr %l115)
  store %"compiler/free:leaf" %t188, ptr %l117
  br label %bb46
bb46:
  %t189 = load ptr, ptr %l111, !tbaa !29
  %t190 = load %"compiler/free:leaf", ptr %l117
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s5, ptr %t189, %"compiler/free:leaf" %t190)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s5)
  br label %bb92
bb48:
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t192, ptr %l119, !tbaa !27
  %t193 = load i64, ptr %l12, !tbaa !24
  %t195 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = getelementptr i32, ptr %t196, i64 %t193
  %t198 = load i32, ptr %t197, !tbaa !33
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t191, i32 %t198)
  store i32 %t201, ptr %l122
  br label %bb49
bb49:
  %t202 = load i32, ptr %l122, !tbaa !23
  store i32 %t202, ptr %l14, !tbaa !23
  %t203 = load ptr, ptr %l2, !tbaa !29
  %t204 = load i32, ptr %l14, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l125
  br label %bb50
bb50:
  %t208 = load i32, ptr %l125, !range !{i32 0, i32 33}
  %t210 = trunc i64 18 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb51, label %bb52
bb51:
  %t213 = load ptr, ptr %l2, !tbaa !29
  %t214 = load i32, ptr %l14, !tbaa !23
  %t217 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t213, i32 %t214)
  store i1 %t217, ptr %l131
  br label %bb53
bb52:
  store i1 false, ptr %l128, !tbaa !21
  br label %bb54
bb53:
  %t218 = load i1, ptr %l131, !tbaa !21
  store i1 %t218, ptr %l128, !tbaa !21
  br label %bb54
bb54:
  %t219 = load i1, ptr %l128, !tbaa !21
  br i1 %t219, label %bb55, label %bb56
bb55:
  %t220 = load ptr, ptr %l2, !tbaa !29
  store ptr %t220, ptr %l133, !tbaa !29
  %t221 = load ptr, ptr %l2, !tbaa !29
  %t222 = load i32, ptr %l14, !tbaa !23
  %t225 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t221, i32 %t222)
  store i32 %t225, ptr %l136
  br label %bb57
bb56:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb59
bb57:
  %t226 = load ptr, ptr %l133, !tbaa !29
  %t227 = load i32, ptr %l136, !tbaa !23
  %t228 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t228, ptr %l137
  br label %bb58
bb58:
  %t229 = load i32, ptr %l137, !range !{i32 0, i32 6}
  %t231 = trunc i64 0 to i32
  %t232 = icmp eq i32 %t229, %t231
  store i1 %t232, ptr %l132, !tbaa !21
  br label %bb59
bb59:
  %t234 = load i1, ptr %l132, !tbaa !21
  br i1 %t234, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s7
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t236 = load i32, ptr %l14, !tbaa !23
  %t239 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s7, ptr %t235, i32 %t236)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l142
  br label %bb62
bb61:
  br label %bb91
bb62:
  %t240 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l142
  %t241 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t240, ptr %t241
  store ptr %t241, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s8
  %t243 = load i64, ptr %l16, !tbaa !24
  store i64 %t243, ptr %l144, !tbaa !24
  %t244 = load ptr, ptr %l15, !tbaa !29
  %t246 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %t244)
  store i64 %t246, ptr %l146
  br label %bb64
bb64:
  %t247 = load i64, ptr %l144, !tbaa !24
  %t248 = load i64, ptr %l146, !tbaa !24
  %t249 = icmp slt i64 %t247, %t248
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s8)
  br label %bb90
bb66:
  br label %bb67
bb67:
  %t253 = load ptr, ptr %l15, !tbaa !29
  %t254 = load i64, ptr %l16, !tbaa !24
  %t257 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s7, ptr %s7, ptr %t253, i64 %t254)
  store %"compiler/free:leaf" %t257, ptr %l151
  br label %bb68
bb68:
  %t259 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s8, ptr %l151)
  store %"compiler/free:leaf" %t259, ptr %l153
  br label %bb69
bb69:
  %t260 = load %"compiler/free:leaf", ptr %l153
  store %"compiler/free:leaf" %t260, ptr %l17
  %t261 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t266 = add i64 %t264, 1
  store i64 %t266, ptr %l156, !tbaa !24
  %t267 = load i64, ptr %l156, !tbaa !24
  %t268 = icmp sge i64 %t267, 0
  br i1 %t268, label %bb70, label %bb71
bb70:
  %t270 = load i64, ptr %l156, !tbaa !24
  %t271 = icmp sle i64 %t270, 1152921504606846975
  br i1 %t271, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd)
  unreachable
bb72:
  %t273 = load i64, ptr %l156, !tbaa !24
  %t274 = mul i64 %t273, 8
  %t275 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l18, !tbaa !27
  %t279 = load i64, ptr %l12, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i64, ptr %t282, i64 0
  store i64 %t279, ptr %t283, !tbaa !34
  store i64 0, ptr %l19, !tbaa !24
  %t284 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t285, 0
  store i64 %t287, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t289 = load i64, ptr %l20, !tbaa !24
  %t290 = load i64, ptr %l19, !tbaa !24
  %t293 = icmp sgt i64 %t289, %t290
  br i1 %t293, label %bb74, label %bb75
bb73:
  call void @__olang_check_failed(ptr @olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd)
  unreachable
bb74:
  %t295 = load i64, ptr %l21, !tbaa !24
  %t297 = icmp sgt i64 %t295, 0
  br i1 %t297, label %bb76, label %bb77
bb75:
  store i64 0, ptr %l166, !tbaa !24
  br label %bb79
bb76:
  %t299 = load i64, ptr %l20, !tbaa !24
  %t300 = load i64, ptr %l19, !tbaa !24
  %t303 = sub i64 %t299, %t300
  %t304 = load i64, ptr %l21, !tbaa !24
  %t307 = add i64 %t303, %t304
  %t309 = sub i64 %t307, 1
  %t310 = load i64, ptr %l21, !tbaa !24
  %t313 = sdiv i64 %t309, %t310
  store i64 %t313, ptr %l169, !tbaa !24
  br label %bb78
bb77:
  store i64 0, ptr %l169, !tbaa !24
  br label %bb78
bb78:
  %t315 = load i64, ptr %l169, !tbaa !24
  store i64 %t315, ptr %l166, !tbaa !24
  br label %bb79
bb79:
  %t316 = load i64, ptr %l166, !tbaa !24
  store i64 %t316, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb80
bb80:
  %t317 = load i64, ptr %l23, !tbaa !24
  %t318 = load i64, ptr %l22, !tbaa !24
  %t321 = icmp slt i64 %t317, %t318
  %t323 = xor i1 %t321, true
  br i1 %t323, label %bb81, label %bb82
bb81:
  br label %bb85
bb82:
  br label %bb83
bb83:
  %t325 = load i64, ptr %l19, !tbaa !24
  %t326 = load i64, ptr %l23, !tbaa !24
  %t327 = load i64, ptr %l21, !tbaa !24
  %t330 = mul i64 %t326, %t327
  %t333 = add i64 %t325, %t330
  store i64 %t333, ptr %l24, !tbaa !24
  %t335 = load i64, ptr %l24, !tbaa !24
  %t337 = add i64 %t335, 1
  %t338 = load i64, ptr %l24, !tbaa !24
  %t339 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 0
  %t341 = getelementptr { i64, ptr }, ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i64, ptr %t342, i64 %t338
  %t344 = load i64, ptr %t343, !tbaa !34
  %t347 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr i64, ptr %t348, i64 %t337
  store i64 %t344, ptr %t349, !tbaa !34
  br label %bb84
bb84:
  %t350 = load i64, ptr %l23, !tbaa !24
  %t352 = add i64 %t350, 1
  store i64 %t352, ptr %l23, !tbaa !24
  br label %bb80
bb85:
  %t354 = load ptr, ptr %lp4
  store ptr %t354, ptr %l193, !tbaa !29
  %t355 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t356 = getelementptr %"compiler/free:leaf", ptr %l17, i32 0, i32 1
  %t357 = load i64, ptr %t356, !tbaa !24
  %t360 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %s8, { i64, ptr } %t355, i64 %t357)
  store %"compiler/free:leaf" %t360, ptr %l196
  br label %bb86
bb86:
  %t362 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s8, ptr %l196)
  store %"compiler/free:leaf" %t362, ptr %l198
  br label %bb87
bb87:
  %t363 = load ptr, ptr %l193, !tbaa !29
  %t364 = load %"compiler/free:leaf", ptr %l198
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s8, ptr %t363, %"compiler/free:leaf" %t364)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb89:
  %t365 = load i64, ptr %l16, !tbaa !24
  %t367 = add i64 %t365, 1
  store i64 %t367, ptr %l16, !tbaa !24
  br label %bb63
bb90:
  call void @__olang_scope_close(ptr %s7)
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t369 = load i64, ptr %l11, !tbaa !24
  %t371 = add i64 %t369, 1
  store i64 %t371, ptr %l11, !tbaa !24
  br label %bb38
bb93:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/free:Free", ptr %t373, i32 0, i32 19
  store ptr %t375, ptr %l204, !tbaa !29
  %t376 = load i32, ptr %l3, !tbaa !23
  store i32 %t376, ptr %l205, !tbaa !23
  %t377 = load ptr, ptr %lp4
  %t378 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t377
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t378, ptr %l206
  %t380 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %s0, ptr %l206)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l208
  br label %bb94
bb94:
  %t381 = load ptr, ptr %l204, !tbaa !29
  %t382 = load i32, ptr %l205, !tbaa !23
  %t383 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %s0, ptr %t381, i32 %t382, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t383)
  br label %bb95
bb95:
  %t384 = load ptr, ptr %lp4
  %t385 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t384
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t385, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l79 = alloca { i64, ptr }
  %l84 = alloca i1
  %l92 = alloca i1
  %l93 = alloca ptr
  %l99 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %l118 = alloca i1
  %l128 = alloca { i64, ptr }
  %l133 = alloca i1
  %l138 = alloca ptr
  %l139 = alloca i1
  %l151 = alloca { i64, ptr }
  %l156 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l169 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l179 = alloca i1
  %l180 = alloca i1
  %l185 = alloca i1
  %l186 = alloca ptr
  %l192 = alloca i1
  %l193 = alloca i1
  %l197 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l206 = alloca i1
  %l207 = alloca ptr
  %l208 = alloca i1
  %l213 = alloca i1
  %l214 = alloca ptr
  %l215 = alloca i1
  %l218 = alloca ptr
  %l219 = alloca i1
  %l228 = alloca i1
  %l229 = alloca ptr
  %l230 = alloca i1
  %l238 = alloca i1
  %l244 = alloca i1
  %l245 = alloca ptr
  %l251 = alloca i1
  %l252 = alloca ptr
  %l253 = alloca i1
  %l262 = alloca i1
  %l263 = alloca ptr
  %l269 = alloca i1
  %l275 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t2 = load ptr, ptr %l27, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l27, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l28, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l28, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t11 = load ptr, ptr %l31, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l31, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l32, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l32, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t20 = load ptr, ptr %l35, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l35, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 2
  store i1 %t26, ptr %l36, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l36, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb17
bb12:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t29 = load ptr, ptr %l39, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb13, label %bb14
bb13:
  %t32 = load ptr, ptr %l39, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t36 = load i1, ptr %l40, !tbaa !21
  br i1 %t36, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t39 = load ptr, ptr %l44, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb19, label %bb20
bb19:
  %t42 = load ptr, ptr %l44, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l45, !tbaa !21
  br label %bb20
bb20:
  %t46 = load i1, ptr %l45, !tbaa !21
  br i1 %t46, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t49 = load ptr, ptr %l49, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb25, label %bb26
bb25:
  %t52 = load ptr, ptr %l49, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 18}
  %t55 = icmp eq i64 %t53, 5
  store i1 %t55, ptr %l50, !tbaa !21
  br label %bb26
bb26:
  %t56 = load i1, ptr %l50, !tbaa !21
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 1
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l2, !tbaa !23
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  br label %bb29
bb28:
  br label %bb35
bb29:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load i32, ptr %l2, !tbaa !23
  %t73 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t73, ptr %l59
  br label %bb30
bb30:
  %t74 = load i1, ptr %l59, !tbaa !21
  br i1 %t74, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb34
bb32:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Promote", ptr %t76, i32 0, i32 0
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t75, ptr %t79)
  store i1 %t82, ptr %l64
  br label %bb33
bb33:
  %t83 = load i1, ptr %l64, !tbaa !21
  store i1 %t83, ptr %l60, !tbaa !21
  br label %bb34
bb34:
  %t84 = load i1, ptr %l60, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb35:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t86 = load ptr, ptr %l65, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb36, label %bb37
bb36:
  %t89 = load ptr, ptr %l65, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 7
  store i1 %t92, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t93 = load i1, ptr %l66, !tbaa !21
  br i1 %t93, label %bb38, label %bb39
bb38:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Make", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t105 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t107 = extractvalue { i64, ptr } %t105, 0
  store i64 %t107, ptr %l7, !tbaa !24
  br label %bb41
bb41:
  %t109 = load i64, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l7, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb42, label %bb43
bb42:
  br label %bb50
bb43:
  br label %bb44
bb44:
  %t117 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t117, ptr %l79, !tbaa !27
  %t118 = load i64, ptr %l6, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr ptr, ptr %t121, i64 %t118
  %t123 = load ptr, ptr %t122, !tbaa !39
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t129 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t125, ptr %t123)
  store i1 %t129, ptr %l84
  br label %bb45
bb45:
  %t130 = load i1, ptr %l84, !tbaa !21
  br i1 %t130, label %bb46, label %bb47
bb46:
  store i1 true, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t132 = load i64, ptr %l6, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l6, !tbaa !24
  br label %bb41
bb50:
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Make", ptr %t136, i32 0, i32 3
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = icmp eq ptr %t139, null
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb51, label %bb52
bb51:
  %t145 = load ptr, ptr %l0, !tbaa !29
  store ptr %t145, ptr %l93, !tbaa !29
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Make", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  br i1 %t151, label %bb53, label %bb54
bb52:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb57
bb53:
  call void @__olang_check_failed(ptr @olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db)
  unreachable
bb54:
  br label %bb55
bb55:
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Make", ptr %t153, i32 0, i32 3
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load ptr, ptr %l93, !tbaa !29
  %t159 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t157, ptr %t156)
  store i1 %t159, ptr %l99
  br label %bb56
bb56:
  %t160 = load i1, ptr %l99, !tbaa !21
  store i1 %t160, ptr %l92, !tbaa !21
  br label %bb57
bb57:
  %t161 = load i1, ptr %l92, !tbaa !21
  store i1 %t161, ptr %rv
  br label %ret
bb58:
  %t162 = load ptr, ptr %l1, !tbaa !29
  store ptr %t162, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t163 = load ptr, ptr %l100, !tbaa !29
  %t164 = icmp ne ptr %t163, null
  br i1 %t164, label %bb59, label %bb60
bb59:
  %t166 = load ptr, ptr %l100, !tbaa !29
  %t167 = load i64, ptr %t166, !range !{i64 0, i64 18}
  %t169 = icmp eq i64 %t167, 16
  store i1 %t169, ptr %l101, !tbaa !21
  br label %bb60
bb60:
  %t170 = load i1, ptr %l101, !tbaa !21
  br i1 %t170, label %bb61, label %bb62
bb61:
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  %t174 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t173, i32 0, i32 2
  %t175 = load ptr, ptr %t174
  store ptr %t175, ptr %l9, !tbaa !29
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %l9, !tbaa !29
  %t181 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextMayRegister(ptr %v0, ptr %v1, ptr %t177, ptr %t178)
  store i1 %t181, ptr %l108
  br label %bb64
bb64:
  %t182 = load i1, ptr %l108, !tbaa !21
  store i1 %t182, ptr %rv
  br label %ret
bb65:
  %t183 = load ptr, ptr %l1, !tbaa !29
  store ptr %t183, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t184 = load ptr, ptr %l109, !tbaa !29
  %t185 = icmp ne ptr %t184, null
  br i1 %t185, label %bb66, label %bb67
bb66:
  %t187 = load ptr, ptr %l109, !tbaa !29
  %t188 = load i64, ptr %t187, !range !{i64 0, i64 18}
  %t190 = icmp eq i64 %t188, 6
  store i1 %t190, ptr %l110, !tbaa !21
  br label %bb67
bb67:
  %t191 = load i1, ptr %l110, !tbaa !21
  br i1 %t191, label %bb68, label %bb69
bb68:
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [5 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t194, i32 0, i32 2
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l10, !tbaa !29
  br label %bb70
bb69:
  br label %bb85
bb70:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l10, !tbaa !29
  %t201 = getelementptr %"compiler/typed:Call", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t205 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeMayRegister(ptr %v0, ptr %v1, ptr %t198, ptr %t202)
  store i1 %t205, ptr %l118
  br label %bb71
bb71:
  %t206 = load i1, ptr %l118, !tbaa !21
  br i1 %t206, label %bb72, label %bb73
bb72:
  store i1 true, ptr %rv
  br label %ret
bb73:
  br label %bb74
bb74:
  %t208 = load ptr, ptr %l10, !tbaa !29
  %t210 = getelementptr %"compiler/typed:Call", ptr %t208, i32 0, i32 1
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  store { i64, ptr } %t211, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t213 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t213, 0
  store i64 %t215, ptr %l13, !tbaa !24
  br label %bb75
bb75:
  %t217 = load i64, ptr %l12, !tbaa !24
  %t218 = load i64, ptr %l13, !tbaa !24
  %t221 = icmp slt i64 %t217, %t218
  %t223 = xor i1 %t221, true
  br i1 %t223, label %bb76, label %bb77
bb76:
  br label %bb84
bb77:
  br label %bb78
bb78:
  %t225 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t225, ptr %l128, !tbaa !27
  %t226 = load i64, ptr %l12, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr ptr, ptr %t229, i64 %t226
  %t231 = load ptr, ptr %t230, !tbaa !39
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t237 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t233, ptr %t231)
  store i1 %t237, ptr %l133
  br label %bb79
bb79:
  %t238 = load i1, ptr %l133, !tbaa !21
  br i1 %t238, label %bb80, label %bb81
bb80:
  store i1 true, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  br label %bb83
bb83:
  %t240 = load i64, ptr %l12, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l12, !tbaa !24
  br label %bb75
bb84:
  store i1 false, ptr %rv
  br label %ret
bb85:
  %t245 = load ptr, ptr %l1, !tbaa !29
  store ptr %t245, ptr %l138, !tbaa !29
  store i1 false, ptr %l139, !tbaa !21
  %t246 = load ptr, ptr %l138, !tbaa !29
  %t247 = icmp ne ptr %t246, null
  br i1 %t247, label %bb86, label %bb87
bb86:
  %t249 = load ptr, ptr %l138, !tbaa !29
  %t250 = load i64, ptr %t249, !range !{i64 0, i64 18}
  %t252 = icmp eq i64 %t250, 9
  store i1 %t252, ptr %l139, !tbaa !21
  br label %bb87
bb87:
  %t253 = load i1, ptr %l139, !tbaa !21
  br i1 %t253, label %bb88, label %bb89
bb88:
  %t254 = load ptr, ptr %l1, !tbaa !29
  %t256 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  %t257 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t256, i32 0, i32 4
  %t258 = load { i64, ptr }, ptr %t257
  store { i64, ptr } %t258, ptr %l15, !tbaa !27
  br label %bb90
bb89:
  br label %bb101
bb90:
  %t260 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t260, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  store i64 %t264, ptr %l18, !tbaa !24
  br label %bb91
bb91:
  %t266 = load i64, ptr %l17, !tbaa !24
  %t267 = load i64, ptr %l18, !tbaa !24
  %t270 = icmp slt i64 %t266, %t267
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb92, label %bb93
bb92:
  br label %bb100
bb93:
  br label %bb94
bb94:
  %t274 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t274, ptr %l151, !tbaa !27
  %t275 = load i64, ptr %l17, !tbaa !24
  %t277 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr ptr, ptr %t278, i64 %t275
  %t280 = load ptr, ptr %t279, !tbaa !39
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t286 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t282, ptr %t280)
  store i1 %t286, ptr %l156
  br label %bb95
bb95:
  %t287 = load i1, ptr %l156, !tbaa !21
  br i1 %t287, label %bb96, label %bb97
bb96:
  store i1 true, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  br label %bb99
bb99:
  %t289 = load i64, ptr %l17, !tbaa !24
  %t291 = add i64 %t289, 1
  store i64 %t291, ptr %l17, !tbaa !24
  br label %bb91
bb100:
  store i1 false, ptr %rv
  br label %ret
bb101:
  %t294 = load ptr, ptr %l1, !tbaa !29
  store ptr %t294, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t295 = load ptr, ptr %l161, !tbaa !29
  %t296 = icmp ne ptr %t295, null
  br i1 %t296, label %bb102, label %bb103
bb102:
  %t298 = load ptr, ptr %l161, !tbaa !29
  %t299 = load i64, ptr %t298, !range !{i64 0, i64 18}
  %t301 = icmp eq i64 %t299, 17
  store i1 %t301, ptr %l162, !tbaa !21
  br label %bb103
bb103:
  %t302 = load i1, ptr %l162, !tbaa !21
  br i1 %t302, label %bb104, label %bb105
bb104:
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr { i64, [5 x i64] }, ptr %t303, i32 0, i32 1
  %t306 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t305, i32 0, i32 2
  %t307 = load ptr, ptr %t306
  store ptr %t307, ptr %l20, !tbaa !29
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load ptr, ptr %l20, !tbaa !29
  %t313 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t309, ptr %t310)
  store i1 %t313, ptr %l169
  br label %bb107
bb107:
  %t314 = load i1, ptr %l169, !tbaa !21
  store i1 %t314, ptr %rv
  br label %ret
bb108:
  %t315 = load ptr, ptr %l1, !tbaa !29
  store ptr %t315, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t316 = load ptr, ptr %l170, !tbaa !29
  %t317 = icmp ne ptr %t316, null
  br i1 %t317, label %bb109, label %bb110
bb109:
  %t319 = load ptr, ptr %l170, !tbaa !29
  %t320 = load i64, ptr %t319, !range !{i64 0, i64 18}
  %t322 = icmp eq i64 %t320, 11
  store i1 %t322, ptr %l171, !tbaa !21
  br label %bb110
bb110:
  %t323 = load i1, ptr %l171, !tbaa !21
  br i1 %t323, label %bb111, label %bb112
bb111:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t326 = getelementptr { i64, [5 x i64] }, ptr %t324, i32 0, i32 1
  %t327 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t326, i32 0, i32 2
  %t328 = load ptr, ptr %t327
  store ptr %t328, ptr %l21, !tbaa !29
  br label %bb113
bb112:
  br label %bb129
bb113:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l21, !tbaa !29
  %t333 = getelementptr %"compiler/typed:Cond", ptr %t331, i32 0, i32 0
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t337 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t330, ptr %t334)
  store i1 %t337, ptr %l179
  br label %bb114
bb114:
  %t338 = load i1, ptr %l179, !tbaa !21
  br i1 %t338, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb124
bb116:
  %t339 = load ptr, ptr %l21, !tbaa !29
  %t341 = getelementptr %"compiler/typed:Cond", ptr %t339, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !29
  %t344 = icmp eq ptr %t342, null
  %t346 = xor i1 %t344, true
  br i1 %t346, label %bb117, label %bb118
bb117:
  %t348 = load ptr, ptr %l0, !tbaa !29
  store ptr %t348, ptr %l186, !tbaa !29
  %t349 = load ptr, ptr %l21, !tbaa !29
  %t351 = getelementptr %"compiler/typed:Cond", ptr %t349, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = icmp eq ptr %t352, null
  br i1 %t354, label %bb119, label %bb120
bb118:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb123
bb119:
  call void @__olang_check_failed(ptr @olang_loc_fc2fcdbc2f007840_c2f2791b7eb787ec)
  unreachable
bb120:
  br label %bb121
bb121:
  %t356 = load ptr, ptr %l21, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Cond", ptr %t356, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !29
  %t360 = load ptr, ptr %l186, !tbaa !29
  %t362 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t360, ptr %t359)
  store i1 %t362, ptr %l192
  br label %bb122
bb122:
  %t363 = load i1, ptr %l192, !tbaa !21
  store i1 %t363, ptr %l185, !tbaa !21
  br label %bb123
bb123:
  %t364 = load i1, ptr %l185, !tbaa !21
  store i1 %t364, ptr %l180, !tbaa !21
  br label %bb124
bb124:
  %t365 = load i1, ptr %l180, !tbaa !21
  br i1 %t365, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb128
bb126:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load ptr, ptr %l21, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Cond", ptr %t367, i32 0, i32 2
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t373 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t366, ptr %t370)
  store i1 %t373, ptr %l197
  br label %bb127
bb127:
  %t374 = load i1, ptr %l197, !tbaa !21
  store i1 %t374, ptr %l193, !tbaa !21
  br label %bb128
bb128:
  %t375 = load i1, ptr %l193, !tbaa !21
  store i1 %t375, ptr %rv
  br label %ret
bb129:
  %t376 = load ptr, ptr %l1, !tbaa !29
  store ptr %t376, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t377 = load ptr, ptr %l198, !tbaa !29
  %t378 = icmp ne ptr %t377, null
  br i1 %t378, label %bb130, label %bb131
bb130:
  %t380 = load ptr, ptr %l198, !tbaa !29
  %t381 = load i64, ptr %t380, !range !{i64 0, i64 18}
  %t383 = icmp eq i64 %t381, 14
  store i1 %t383, ptr %l199, !tbaa !21
  br label %bb131
bb131:
  %t384 = load i1, ptr %l199, !tbaa !21
  br i1 %t384, label %bb132, label %bb133
bb132:
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [5 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t387, i32 0, i32 2
  %t389 = load ptr, ptr %t388
  store ptr %t389, ptr %l22, !tbaa !29
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load ptr, ptr %l22, !tbaa !29
  %t395 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etryMayRegister(ptr %v0, ptr %v1, ptr %t391, ptr %t392)
  store i1 %t395, ptr %l206
  br label %bb135
bb135:
  %t396 = load i1, ptr %l206, !tbaa !21
  store i1 %t396, ptr %rv
  br label %ret
bb136:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l207, !tbaa !29
  store i1 false, ptr %l208, !tbaa !21
  %t398 = load ptr, ptr %l207, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb137, label %bb138
bb137:
  %t401 = load ptr, ptr %l207, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 18}
  %t404 = icmp eq i64 %t402, 15
  store i1 %t404, ptr %l208, !tbaa !21
  br label %bb138
bb138:
  %t405 = load i1, ptr %l208, !tbaa !21
  br i1 %t405, label %bb139, label %bb140
bb139:
  %t406 = load ptr, ptr %l1, !tbaa !29
  %t408 = getelementptr { i64, [5 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t408, i32 0, i32 2
  %t410 = load ptr, ptr %t409
  store ptr %t410, ptr %l23, !tbaa !29
  br label %bb141
bb140:
  br label %bb160
bb141:
  %t412 = load ptr, ptr %l23, !tbaa !29
  store ptr %t412, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t413 = load ptr, ptr %l214, !tbaa !29
  %t414 = icmp ne ptr %t413, null
  br i1 %t414, label %bb142, label %bb143
bb142:
  %t416 = load ptr, ptr %l214, !tbaa !29
  %t417 = load i64, ptr %t416, !range !{i64 0, i64 3}
  %t419 = icmp eq i64 %t417, 0
  store i1 %t419, ptr %l215, !tbaa !21
  br label %bb143
bb143:
  %t420 = load i1, ptr %l215, !tbaa !21
  br i1 %t420, label %bb144, label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  store i1 false, ptr %l213, !tbaa !21
  br label %bb159
bb147:
  %t421 = load ptr, ptr %l23, !tbaa !29
  store ptr %t421, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t422 = load ptr, ptr %l218, !tbaa !29
  %t423 = icmp ne ptr %t422, null
  br i1 %t423, label %bb148, label %bb149
bb148:
  %t425 = load ptr, ptr %l218, !tbaa !29
  %t426 = load i64, ptr %t425, !range !{i64 0, i64 3}
  %t428 = icmp eq i64 %t426, 1
  store i1 %t428, ptr %l219, !tbaa !21
  br label %bb149
bb149:
  %t429 = load i1, ptr %l219, !tbaa !21
  br i1 %t429, label %bb150, label %bb151
bb150:
  %t430 = load ptr, ptr %l23, !tbaa !29
  %t432 = getelementptr { i64, [4 x i64] }, ptr %t430, i32 0, i32 1
  %t433 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t432, i32 0, i32 0
  %t434 = load i32, ptr %t433
  store i32 %t434, ptr %l24, !tbaa !23
  br label %bb152
bb151:
  br label %bb154
bb152:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/free:Free", ptr %t436, i32 0, i32 75
  %t439 = load i32, ptr %l24, !tbaa !23
  %t441 = sext i32 %t439 to i64
  %t444 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t438, i64 %t441)
  store i1 %t444, ptr %l228
  br label %bb153
bb153:
  %t445 = load i1, ptr %l228, !tbaa !21
  store i1 %t445, ptr %l213, !tbaa !21
  br label %bb159
bb154:
  br i1 true, label %bb155, label %bb156
bb155:
  br label %bb157
bb156:
  br label %bb158
bb157:
  store i1 true, ptr %l213, !tbaa !21
  br label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8)
  unreachable
bb159:
  %t446 = load i1, ptr %l213, !tbaa !21
  store i1 %t446, ptr %rv
  br label %ret
bb160:
  %t447 = load ptr, ptr %l1, !tbaa !29
  store ptr %t447, ptr %l229, !tbaa !29
  store i1 false, ptr %l230, !tbaa !21
  %t448 = load ptr, ptr %l229, !tbaa !29
  %t449 = icmp ne ptr %t448, null
  br i1 %t449, label %bb161, label %bb162
bb161:
  %t451 = load ptr, ptr %l229, !tbaa !29
  %t452 = load i64, ptr %t451, !range !{i64 0, i64 18}
  %t454 = icmp eq i64 %t452, 12
  store i1 %t454, ptr %l230, !tbaa !21
  br label %bb162
bb162:
  %t455 = load i1, ptr %l230, !tbaa !21
  br i1 %t455, label %bb163, label %bb164
bb163:
  %t456 = load ptr, ptr %l1, !tbaa !29
  %t458 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 1
  %t459 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t458, i32 0, i32 2
  %t460 = load ptr, ptr %t459
  store ptr %t460, ptr %l25, !tbaa !29
  br label %bb165
bb164:
  br label %bb177
bb165:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load ptr, ptr %l25, !tbaa !29
  %t465 = getelementptr %"compiler/typed:Seq", ptr %t463, i32 0, i32 0
  %t466 = load { i64, ptr }, ptr %t465, !tbaa !27
  %t469 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t462, { i64, ptr } %t466)
  store i1 %t469, ptr %l238
  br label %bb166
bb166:
  %t470 = load i1, ptr %l238, !tbaa !21
  br i1 %t470, label %bb167, label %bb168
bb167:
  store i1 true, ptr %rv
  br label %ret
bb168:
  br label %bb169
bb169:
  %t472 = load ptr, ptr %l25, !tbaa !29
  %t474 = getelementptr %"compiler/typed:Seq", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = icmp eq ptr %t475, null
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb170, label %bb171
bb170:
  %t481 = load ptr, ptr %l0, !tbaa !29
  store ptr %t481, ptr %l245, !tbaa !29
  %t482 = load ptr, ptr %l25, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Seq", ptr %t482, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !29
  %t487 = icmp eq ptr %t485, null
  br i1 %t487, label %bb172, label %bb173
bb171:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb176
bb172:
  call void @__olang_check_failed(ptr @olang_loc_c329a7357b4632ae_1972f4ce8b92321a)
  unreachable
bb173:
  br label %bb174
bb174:
  %t489 = load ptr, ptr %l25, !tbaa !29
  %t491 = getelementptr %"compiler/typed:Seq", ptr %t489, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !29
  %t493 = load ptr, ptr %l245, !tbaa !29
  %t495 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t493, ptr %t492)
  store i1 %t495, ptr %l251
  br label %bb175
bb175:
  %t496 = load i1, ptr %l251, !tbaa !21
  store i1 %t496, ptr %l244, !tbaa !21
  br label %bb176
bb176:
  %t497 = load i1, ptr %l244, !tbaa !21
  store i1 %t497, ptr %rv
  br label %ret
bb177:
  %t498 = load ptr, ptr %l1, !tbaa !29
  store ptr %t498, ptr %l252, !tbaa !29
  store i1 false, ptr %l253, !tbaa !21
  %t499 = load ptr, ptr %l252, !tbaa !29
  %t500 = icmp ne ptr %t499, null
  br i1 %t500, label %bb178, label %bb179
bb178:
  %t502 = load ptr, ptr %l252, !tbaa !29
  %t503 = load i64, ptr %t502, !range !{i64 0, i64 18}
  %t505 = icmp eq i64 %t503, 8
  store i1 %t505, ptr %l253, !tbaa !21
  br label %bb179
bb179:
  %t506 = load i1, ptr %l253, !tbaa !21
  br i1 %t506, label %bb180, label %bb181
bb180:
  %t507 = load ptr, ptr %l1, !tbaa !29
  %t509 = getelementptr { i64, [5 x i64] }, ptr %t507, i32 0, i32 1
  %t510 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t509, i32 0, i32 2
  %t511 = load ptr, ptr %t510
  store ptr %t511, ptr %l26, !tbaa !29
  br label %bb182
bb181:
  br label %bb194
bb182:
  %t513 = load ptr, ptr %l26, !tbaa !29
  %t515 = getelementptr %"compiler/typed:Collect", ptr %t513, i32 0, i32 0
  %t516 = load ptr, ptr %t515, !tbaa !29
  %t518 = icmp eq ptr %t516, null
  %t520 = xor i1 %t518, true
  br i1 %t520, label %bb183, label %bb184
bb183:
  %t522 = load ptr, ptr %l0, !tbaa !29
  store ptr %t522, ptr %l263, !tbaa !29
  %t523 = load ptr, ptr %l26, !tbaa !29
  %t525 = getelementptr %"compiler/typed:Collect", ptr %t523, i32 0, i32 0
  %t526 = load ptr, ptr %t525, !tbaa !29
  %t528 = icmp eq ptr %t526, null
  br i1 %t528, label %bb185, label %bb186
bb184:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb189
bb185:
  call void @__olang_check_failed(ptr @olang_loc_ce4a56608212b1d3_28564c72fb26107)
  unreachable
bb186:
  br label %bb187
bb187:
  %t530 = load ptr, ptr %l26, !tbaa !29
  %t532 = getelementptr %"compiler/typed:Collect", ptr %t530, i32 0, i32 0
  %t533 = load ptr, ptr %t532, !tbaa !29
  %t534 = load ptr, ptr %l263, !tbaa !29
  %t536 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t534, ptr %t533)
  store i1 %t536, ptr %l269
  br label %bb188
bb188:
  %t537 = load i1, ptr %l269, !tbaa !21
  store i1 %t537, ptr %l262, !tbaa !21
  br label %bb189
bb189:
  %t538 = load i1, ptr %l262, !tbaa !21
  br i1 %t538, label %bb190, label %bb191
bb190:
  store i1 true, ptr %rv
  br label %ret
bb191:
  br label %bb192
bb192:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load ptr, ptr %l26, !tbaa !29
  %t543 = getelementptr %"compiler/typed:Collect", ptr %t541, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !29
  %t546 = getelementptr %"compiler/typed:Block", ptr %t544, i32 0, i32 1
  %t547 = load { i64, ptr }, ptr %t546, !tbaa !27
  %t550 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t540, { i64, ptr } %t547)
  store i1 %t550, ptr %l275
  br label %bb193
bb193:
  %t551 = load i1, ptr %l275, !tbaa !21
  store i1 %t551, ptr %rv
  br label %ret
bb194:
  br i1 true, label %bb195, label %bb196
bb195:
  br label %bb197
bb196:
  br label %bb198
bb197:
  store i1 true, ptr %rv
  br label %ret
bb198:
  call void @__olang_check_failed(ptr @olang_loc_8c3ff88e405c7c2b_15d3403d537d031f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i1
  %l24 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l9
  br label %bb2
bb2:
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l14
  br label %bb6
bb6:
  %t18 = load i64, ptr %l14, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t21 = call i64 @compiler_2ffree_2eokind(i64 %t19)
  store i64 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i64, ptr %l16, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t24 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t27 = icmp eq i64 %t23, %t24
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  store i1 %t33, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb13
bb12:
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr @G_2ecompiler_2ffree_2eOUnk, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  store i1 %t40, ptr %l24, !tbaa !21
  br label %bb13
bb13:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb14, label %bb15
bb14:
  store i1 true, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t48 = icmp eq i64 %t44, %t45
  br i1 %t48, label %bb17, label %bb18
bb17:
  store ptr %a0, ptr %l33, !tbaa !29
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = call i64 @compiler_2ffree_2eoval(i64 %t51)
  store i64 %t53, ptr %l35
  br label %bb19
bb18:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb21
bb19:
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t55 = load i64, ptr %l35, !tbaa !24
  %t56 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebufPlace(ptr %v0, ptr %t54, i64 %t55)
  store i1 %t56, ptr %l36
  br label %bb20
bb20:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t58 = load i1, ptr %l32, !tbaa !21
  br i1 %t58, label %bb22, label %bb23
bb22:
  store i1 true, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l3, !tbaa !24
  br label %bb1
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l49 = alloca ptr
  %l55 = alloca %"compiler/free:mustW"
  %l59 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l94 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l120 = alloca ptr
  %l124 = alloca i32
  %l128 = alloca ptr
  %l132 = alloca i32
  %l137 = alloca ptr
  %l145 = alloca i64
  %l149 = alloca i64
  %l152 = alloca i64
  %l173 = alloca i64
  %l176 = alloca i1
  %l179 = alloca i1
  %l183 = alloca i64
  %l184 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i64
  %l195 = alloca i64
  %l204 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca ptr
  %l212 = alloca ptr
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i64
  %l219 = alloca i64
  %l232 = alloca ptr
  %l233 = alloca ptr
  %l234 = alloca i64
  %l239 = alloca i64
  %l241 = alloca i64
  %l246 = alloca i64
  %l247 = alloca ptr
  %l248 = alloca i64
  %l257 = alloca i64
  %l259 = alloca i64
  %l264 = alloca ptr
  %l265 = alloca i64
  %l268 = alloca i64
  %l269 = alloca i64
  %l272 = alloca i1
  %l276 = alloca i64
  %l280 = alloca i64
  %l287 = alloca i1
  %l291 = alloca i1
  %l293 = alloca i1
  %l297 = alloca i1
  %l305 = alloca ptr
  %l306 = alloca ptr
  %l307 = alloca i64
  %l312 = alloca i64
  %l314 = alloca i64
  %l319 = alloca i64
  %l320 = alloca ptr
  %l321 = alloca i64
  %l330 = alloca ptr
  %l331 = alloca ptr
  %l332 = alloca i64
  %l337 = alloca i64
  %l341 = alloca i64
  %l344 = alloca i64
  %l362 = alloca ptr
  %l363 = alloca i64
  %l365 = alloca ptr
  %l368 = alloca i1
  %t18 = alloca %"compiler/free:mustW", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l49
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l49, !tbaa !29
  store ptr %t8, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l2, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_3amustW_2ector(ptr %t18, ptr %v0, ptr %v0, ptr %t16, i64 %t17)
  call void @llvm.memmove.p0.p0.i64(ptr %l55, ptr %t18, i64 176, i1 false)
  br label %bb5
bb5:
  %t21 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 176, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %l55, i64 176, i1 false)
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 7
  %t27 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t25)
  store i64 %t27, ptr %l59
  br label %bb6
bb6:
  %t28 = load i64, ptr %l59, !tbaa !24
  store i64 %t28, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t29 = load i64, ptr %l5, !tbaa !24
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb12
bb9:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l66, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb11
bb11:
  %t55 = load i64, ptr %l66, !tbaa !24
  store i64 %t55, ptr %l63, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l63, !tbaa !24
  store i64 %t56, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  br label %bb16
bb16:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l9, !tbaa !24
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/free:mustW", ptr %t75, i32 0, i32 2
  %t78 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t77, i64 %t78)
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/free:mustW", ptr %t81, i32 0, i32 3
  %t84 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t87 = load i64, ptr %l8, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l8, !tbaa !24
  br label %bb13
bb20:
  store i64 0, ptr %l10, !tbaa !24
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Body", ptr %t91, i32 0, i32 5
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t93)
  store i64 %t95, ptr %l94
  br label %bb21
bb21:
  %t96 = load i64, ptr %l94, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i64, ptr %l12, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb27
bb24:
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l12, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l101, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb26
bb26:
  %t123 = load i64, ptr %l101, !tbaa !24
  store i64 %t123, ptr %l98, !tbaa !24
  br label %bb27
bb27:
  %t124 = load i64, ptr %l98, !tbaa !24
  store i64 %t124, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb28
bb28:
  %t125 = load i64, ptr %l14, !tbaa !24
  %t126 = load i64, ptr %l13, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l14, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l15, !tbaa !24
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr %"compiler/free:mustW", ptr %t143, i32 0, i32 2
  store ptr %t145, ptr %l120, !tbaa !29
  %t146 = load ptr, ptr %l2, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Body", ptr %t146, i32 0, i32 5
  %t149 = load i64, ptr %l15, !tbaa !24
  %t152 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t148, i64 %t149)
  store i32 %t152, ptr %l124
  br label %bb32
bb32:
  %t153 = load i32, ptr %l124, !tbaa !23
  %t154 = sext i32 %t153 to i64
  %t155 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  %t156 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t156, i64 %t154, i64 %t155)
  br label %bb33
bb33:
  %t159 = load ptr, ptr %l3, !tbaa !29
  %t161 = getelementptr %"compiler/free:mustW", ptr %t159, i32 0, i32 3
  store ptr %t161, ptr %l128, !tbaa !29
  %t162 = load ptr, ptr %l2, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Body", ptr %t162, i32 0, i32 5
  %t165 = load i64, ptr %l15, !tbaa !24
  %t168 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t164, i64 %t165)
  store i32 %t168, ptr %l132
  br label %bb34
bb34:
  %t169 = load i32, ptr %l132, !tbaa !23
  %t170 = sext i32 %t169 to i64
  %t171 = load i64, ptr %l15, !tbaa !24
  %t172 = load ptr, ptr %l128, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t172, i64 %t170, i64 %t171)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t175 = load i64, ptr %l14, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l14, !tbaa !24
  br label %bb28
bb37:
  %t179 = load ptr, ptr %l3, !tbaa !29
  store ptr %t179, ptr %l137, !tbaa !29
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t182 = getelementptr %"compiler/typed:Body", ptr %t180, i32 0, i32 11
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_1d9a56a827ed845f_5cc839dbc781b743)
  unreachable
bb39:
  br label %bb40
bb40:
  %t187 = load ptr, ptr %l2, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Body", ptr %t187, i32 0, i32 11
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v0, ptr %t191, ptr %t190)
  br label %bb41
bb41:
  br label %bb42
bb42:
  store i1 false, ptr %l16, !tbaa !21
  store i64 0, ptr %l17, !tbaa !24
  %t193 = load ptr, ptr %l3, !tbaa !29
  %t195 = getelementptr %"compiler/free:mustW", ptr %t193, i32 0, i32 4
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t195)
  store i64 %t197, ptr %l145
  br label %bb43
bb43:
  %t198 = load i64, ptr %l145, !tbaa !24
  store i64 %t198, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t199 = load i64, ptr %l18, !tbaa !24
  %t200 = load i64, ptr %l17, !tbaa !24
  %t203 = icmp sgt i64 %t199, %t200
  br i1 %t203, label %bb44, label %bb45
bb44:
  %t205 = load i64, ptr %l19, !tbaa !24
  %t207 = icmp sgt i64 %t205, 0
  br i1 %t207, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l149, !tbaa !24
  br label %bb49
bb46:
  %t209 = load i64, ptr %l18, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  %t213 = sub i64 %t209, %t210
  %t214 = load i64, ptr %l19, !tbaa !24
  %t217 = add i64 %t213, %t214
  %t219 = sub i64 %t217, 1
  %t220 = load i64, ptr %l19, !tbaa !24
  %t223 = sdiv i64 %t219, %t220
  store i64 %t223, ptr %l152, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb48
bb48:
  %t225 = load i64, ptr %l152, !tbaa !24
  store i64 %t225, ptr %l149, !tbaa !24
  br label %bb49
bb49:
  %t226 = load i64, ptr %l149, !tbaa !24
  store i64 %t226, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb50
bb50:
  %t227 = load i64, ptr %l21, !tbaa !24
  %t228 = load i64, ptr %l20, !tbaa !24
  %t231 = icmp slt i64 %t227, %t228
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb51, label %bb52
bb51:
  br label %bb81
bb52:
  br label %bb53
bb53:
  %t235 = load i64, ptr %l17, !tbaa !24
  %t236 = load i64, ptr %l21, !tbaa !24
  %t237 = load i64, ptr %l19, !tbaa !24
  %t240 = mul i64 %t236, %t237
  %t243 = add i64 %t235, %t240
  store i64 %t243, ptr %l22, !tbaa !24
  %t245 = load ptr, ptr %l3, !tbaa !29
  %t247 = getelementptr %"compiler/free:mustW", ptr %t245, i32 0, i32 4
  %t248 = load i64, ptr %l22, !tbaa !24
  %t251 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t247, i64 %t248)
  store i64 %t251, ptr %l173
  br label %bb54
bb54:
  %t252 = load i64, ptr %l173, !tbaa !24
  store i64 %t252, ptr %l23, !tbaa !24
  %t253 = load i64, ptr %l23, !tbaa !24
  %t255 = icmp slt i64 %t253, 0
  br i1 %t255, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb58
bb56:
  %t257 = load ptr, ptr %l3, !tbaa !29
  %t258 = load i64, ptr %l23, !tbaa !24
  %t261 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t257, i64 %t258)
  store i1 %t261, ptr %l179
  br label %bb57
bb57:
  %t262 = load i1, ptr %l179, !tbaa !21
  store i1 %t262, ptr %l176, !tbaa !21
  br label %bb58
bb58:
  %t263 = load i1, ptr %l176, !tbaa !21
  br i1 %t263, label %bb59, label %bb60
bb59:
  br label %bb80
bb60:
  br label %bb61
bb61:
  %t264 = load ptr, ptr %l3, !tbaa !29
  %t266 = getelementptr %"compiler/free:mustW", ptr %t264, i32 0, i32 2
  %t267 = load i64, ptr %l23, !tbaa !24
  %t270 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t266, i64 %t267)
  store i64 %t270, ptr %l183
  br label %bb62
bb62:
  %t271 = load ptr, ptr %l3, !tbaa !29
  store ptr %t271, ptr %l184, !tbaa !29
  %t272 = load ptr, ptr %l3, !tbaa !29
  %t274 = getelementptr %"compiler/free:mustW", ptr %t272, i32 0, i32 5
  %t275 = load i64, ptr %l22, !tbaa !24
  %t278 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t274, i64 %t275)
  store ptr %t278, ptr %l188
  br label %bb63
bb63:
  %t279 = load ptr, ptr %l184, !tbaa !29
  %t280 = load ptr, ptr %l188, !tbaa !29
  %t281 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v0, ptr %t279, ptr %t280)
  store i64 %t281, ptr %l189
  br label %bb64
bb64:
  %t282 = load i64, ptr %l183, !tbaa !24
  %t283 = load i64, ptr %l189, !tbaa !24
  %t284 = call i64 @compiler_2ffree_2emeet(i64 %t282, i64 %t283)
  store i64 %t284, ptr %l190
  br label %bb65
bb65:
  %t285 = load i64, ptr %l190, !tbaa !24
  store i64 %t285, ptr %l24, !tbaa !24
  %t286 = load i64, ptr %l24, !tbaa !24
  store i64 %t286, ptr %l191, !tbaa !24
  %t287 = load ptr, ptr %l3, !tbaa !29
  %t289 = getelementptr %"compiler/free:mustW", ptr %t287, i32 0, i32 2
  %t290 = load i64, ptr %l23, !tbaa !24
  %t293 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t289, i64 %t290)
  store i64 %t293, ptr %l195
  br label %bb66
bb66:
  %t294 = load i64, ptr %l191, !tbaa !24
  %t295 = load i64, ptr %l195, !tbaa !24
  %t296 = icmp ne i64 %t294, %t295
  br i1 %t296, label %bb67, label %bb68
bb67:
  %t298 = load ptr, ptr %l3, !tbaa !29
  %t300 = getelementptr %"compiler/free:mustW", ptr %t298, i32 0, i32 2
  %t301 = load i64, ptr %l23, !tbaa !24
  %t302 = load i64, ptr %l24, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t300, i64 %t301, i64 %t302)
  br label %bb69
bb68:
  br label %bb70
bb69:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb70
bb70:
  %t306 = load ptr, ptr %l3, !tbaa !29
  %t308 = getelementptr %"compiler/free:mustW", ptr %t306, i32 0, i32 3
  %t309 = load i64, ptr %l23, !tbaa !24
  %t312 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t308, i64 %t309)
  store i64 %t312, ptr %l204
  br label %bb71
bb71:
  %t313 = load ptr, ptr %l3, !tbaa !29
  %t315 = getelementptr %"compiler/free:mustW", ptr %t313, i32 0, i32 0
  %t316 = load ptr, ptr %t315, !tbaa !29
  store ptr %t316, ptr %l206, !tbaa !29
  %t317 = load ptr, ptr %l3, !tbaa !29
  %t319 = getelementptr %"compiler/free:mustW", ptr %t317, i32 0, i32 3
  store ptr %t319, ptr %l208, !tbaa !29
  %t320 = load ptr, ptr %l3, !tbaa !29
  %t322 = getelementptr %"compiler/free:mustW", ptr %t320, i32 0, i32 5
  %t323 = load i64, ptr %l22, !tbaa !24
  %t326 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t322, i64 %t323)
  store ptr %t326, ptr %l212
  br label %bb72
bb72:
  %t327 = load ptr, ptr %l206, !tbaa !29
  %t328 = load ptr, ptr %l208, !tbaa !29
  %t329 = load ptr, ptr %l212, !tbaa !29
  %t330 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v0, ptr %v0, ptr %t327, ptr %t328, ptr %t329)
  store i64 %t330, ptr %l213
  br label %bb73
bb73:
  %t331 = load i64, ptr %l204, !tbaa !24
  %t332 = load i64, ptr %l213, !tbaa !24
  %t333 = call i64 @compiler_2ffree_2emeet(i64 %t331, i64 %t332)
  store i64 %t333, ptr %l214
  br label %bb74
bb74:
  %t334 = load i64, ptr %l214, !tbaa !24
  store i64 %t334, ptr %l25, !tbaa !24
  %t335 = load i64, ptr %l25, !tbaa !24
  store i64 %t335, ptr %l215, !tbaa !24
  %t336 = load ptr, ptr %l3, !tbaa !29
  %t338 = getelementptr %"compiler/free:mustW", ptr %t336, i32 0, i32 3
  %t339 = load i64, ptr %l23, !tbaa !24
  %t342 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t338, i64 %t339)
  store i64 %t342, ptr %l219
  br label %bb75
bb75:
  %t343 = load i64, ptr %l215, !tbaa !24
  %t344 = load i64, ptr %l219, !tbaa !24
  %t345 = icmp ne i64 %t343, %t344
  br i1 %t345, label %bb76, label %bb77
bb76:
  %t347 = load ptr, ptr %l3, !tbaa !29
  %t349 = getelementptr %"compiler/free:mustW", ptr %t347, i32 0, i32 3
  %t350 = load i64, ptr %l23, !tbaa !24
  %t351 = load i64, ptr %l25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t349, i64 %t350, i64 %t351)
  br label %bb78
bb77:
  br label %bb79
bb78:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t355 = load i64, ptr %l21, !tbaa !24
  %t357 = add i64 %t355, 1
  store i64 %t357, ptr %l21, !tbaa !24
  br label %bb50
bb81:
  %t359 = load i1, ptr %l16, !tbaa !21
  %t361 = xor i1 %t359, true
  br i1 %t361, label %bb82, label %bb83
bb82:
  br label %bb86
bb83:
  br label %bb84
bb84:
  br label %bb85
bb85:
  br label %bb42
bb86:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = getelementptr %"compiler/free:Free", ptr %t363, i32 0, i32 95
  %t366 = load i64, ptr %l1, !tbaa !24
  %t369 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t365, i64 %t366)
  store ptr %t369, ptr %l232
  br label %bb87
bb87:
  %t370 = load ptr, ptr %l232, !tbaa !29
  store ptr %t370, ptr %l26, !tbaa !29
  %t371 = load ptr, ptr %l26, !tbaa !29
  store ptr %t371, ptr %l233, !tbaa !29
  %t372 = ptrtoint ptr %v0 to i64
  store i64 %t372, ptr %l234, !tbaa !24
  %t373 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t373, label %bb88, label %bb89
bb88:
  %t375 = load ptr, ptr %l233, !tbaa !29
  %t376 = call ptr @__olang_region_or(ptr %t375, ptr %v0)
  %t377 = ptrtoint ptr %t376 to i64
  store i64 %t377, ptr %l234, !tbaa !24
  br label %bb89
bb89:
  %t378 = load ptr, ptr %l26, !tbaa !29
  %t379 = load i64, ptr %l234
  %t380 = inttoptr i64 %t379 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %t380, ptr %t378)
  br label %bb90
bb90:
  %t382 = load ptr, ptr %l3, !tbaa !29
  %t384 = getelementptr %"compiler/free:mustW", ptr %t382, i32 0, i32 3
  store ptr %t384, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb91
bb91:
  %t386 = load i64, ptr %l28, !tbaa !24
  store i64 %t386, ptr %l239, !tbaa !24
  %t387 = load ptr, ptr %l27, !tbaa !29
  %t389 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t387)
  store i64 %t389, ptr %l241
  br label %bb92
bb92:
  %t390 = load i64, ptr %l239, !tbaa !24
  %t391 = load i64, ptr %l241, !tbaa !24
  %t392 = icmp slt i64 %t390, %t391
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb93, label %bb94
bb93:
  br label %bb101
bb94:
  br label %bb95
bb95:
  %t396 = load ptr, ptr %l27, !tbaa !29
  %t397 = load i64, ptr %l28, !tbaa !24
  %t400 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t396, i64 %t397)
  store i64 %t400, ptr %l246
  br label %bb96
bb96:
  %t401 = load i64, ptr %l246, !tbaa !24
  store i64 %t401, ptr %l29, !tbaa !24
  %t402 = load ptr, ptr %l26, !tbaa !29
  store ptr %t402, ptr %l247, !tbaa !29
  %t403 = ptrtoint ptr %v0 to i64
  store i64 %t403, ptr %l248, !tbaa !24
  %t404 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t404, label %bb97, label %bb98
bb97:
  %t406 = load ptr, ptr %l247, !tbaa !29
  %t407 = call ptr @__olang_region_or(ptr %t406, ptr %v0)
  %t408 = ptrtoint ptr %t407 to i64
  store i64 %t408, ptr %l248, !tbaa !24
  br label %bb98
bb98:
  %t409 = load ptr, ptr %l26, !tbaa !29
  %t410 = load i64, ptr %l29, !tbaa !24
  %t411 = load i64, ptr %l248
  %t412 = inttoptr i64 %t411 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %t412, ptr %t409, i64 %t410)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t415 = load i64, ptr %l28, !tbaa !24
  %t417 = add i64 %t415, 1
  store i64 %t417, ptr %l28, !tbaa !24
  br label %bb91
bb101:
  %t419 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t419, ptr %l30, !tbaa !24
  store i1 true, ptr %l31, !tbaa !21
  %t421 = load ptr, ptr %l3, !tbaa !29
  %t423 = getelementptr %"compiler/free:mustW", ptr %t421, i32 0, i32 6
  store ptr %t423, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb102
bb102:
  %t425 = load i64, ptr %l33, !tbaa !24
  store i64 %t425, ptr %l257, !tbaa !24
  %t426 = load ptr, ptr %l32, !tbaa !29
  %t428 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t426)
  store i64 %t428, ptr %l259
  br label %bb103
bb103:
  %t429 = load i64, ptr %l257, !tbaa !24
  %t430 = load i64, ptr %l259, !tbaa !24
  %t431 = icmp slt i64 %t429, %t430
  %t433 = xor i1 %t431, true
  br i1 %t433, label %bb104, label %bb105
bb104:
  br label %bb115
bb105:
  br label %bb106
bb106:
  %t435 = load ptr, ptr %l32, !tbaa !29
  %t436 = load i64, ptr %l33, !tbaa !24
  %t439 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t435, i64 %t436)
  store ptr %t439, ptr %l264
  br label %bb107
bb107:
  %t440 = load ptr, ptr %l264, !tbaa !29
  store ptr %t440, ptr %l34, !tbaa !29
  %t441 = load i64, ptr %l30, !tbaa !24
  store i64 %t441, ptr %l265, !tbaa !24
  %t442 = load ptr, ptr %l3, !tbaa !29
  %t443 = load ptr, ptr %l34, !tbaa !29
  %t446 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v0, ptr %t442, ptr %t443)
  store i64 %t446, ptr %l268
  br label %bb108
bb108:
  %t447 = load i64, ptr %l265, !tbaa !24
  %t448 = load i64, ptr %l268, !tbaa !24
  %t449 = call i64 @compiler_2ffree_2emeet(i64 %t447, i64 %t448)
  store i64 %t449, ptr %l269
  br label %bb109
bb109:
  %t450 = load i64, ptr %l269, !tbaa !24
  store i64 %t450, ptr %l30, !tbaa !24
  %t451 = load ptr, ptr %l3, !tbaa !29
  %t452 = load ptr, ptr %l34, !tbaa !29
  %t455 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t451, ptr %t452, i64 0)
  store i1 %t455, ptr %l272
  br label %bb110
bb110:
  %t456 = load i1, ptr %l272, !tbaa !21
  %t457 = xor i1 %t456, true
  br i1 %t457, label %bb111, label %bb112
bb111:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb113
bb112:
  br label %bb113
bb113:
  br label %bb114
bb114:
  %t459 = load i64, ptr %l33, !tbaa !24
  %t461 = add i64 %t459, 1
  store i64 %t461, ptr %l33, !tbaa !24
  br label %bb102
bb115:
  %t463 = load i64, ptr %l30, !tbaa !24
  store i64 %t463, ptr %l276, !tbaa !24
  %t464 = load ptr, ptr %l0, !tbaa !29
  %t466 = getelementptr %"compiler/free:Free", ptr %t464, i32 0, i32 73
  %t467 = load i64, ptr %l1, !tbaa !24
  %t470 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t466, i64 %t467)
  store i64 %t470, ptr %l280
  br label %bb116
bb116:
  %t471 = load i64, ptr %l276, !tbaa !24
  %t472 = load i64, ptr %l280, !tbaa !24
  %t473 = icmp ne i64 %t471, %t472
  br i1 %t473, label %bb117, label %bb118
bb117:
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/free:Free", ptr %t475, i32 0, i32 73
  %t478 = load i64, ptr %l1, !tbaa !24
  %t479 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t477, i64 %t478, i64 %t479)
  br label %bb119
bb118:
  br label %bb120
bb119:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t485 = getelementptr %"compiler/free:Free", ptr %t483, i32 0, i32 77
  store i1 true, ptr %t485, !tbaa !21
  br label %bb120
bb120:
  %t486 = load i1, ptr %l31, !tbaa !21
  store i1 %t486, ptr %l287, !tbaa !21
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/free:Free", ptr %t487, i32 0, i32 74
  %t490 = load i64, ptr %l1, !tbaa !24
  %t493 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t489, i64 %t490)
  store i1 %t493, ptr %l291
  br label %bb121
bb121:
  %t494 = load i1, ptr %l287, !tbaa !21
  %t495 = load i1, ptr %l291, !tbaa !21
  %t496 = icmp ne i1 %t494, %t495
  br i1 %t496, label %bb122, label %bb123
bb122:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/free:Free", ptr %t498, i32 0, i32 74
  %t501 = load i64, ptr %l1, !tbaa !24
  %t504 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t500, i64 %t501)
  store i1 %t504, ptr %l297
  br label %bb124
bb123:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb125
bb124:
  %t505 = load i1, ptr %l297, !tbaa !21
  store i1 %t505, ptr %l293, !tbaa !21
  br label %bb125
bb125:
  %t506 = load i1, ptr %l293, !tbaa !21
  br i1 %t506, label %bb126, label %bb127
bb126:
  %t507 = load ptr, ptr %l0, !tbaa !29
  %t509 = getelementptr %"compiler/free:Free", ptr %t507, i32 0, i32 74
  %t510 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t509, i64 %t510, i1 false)
  br label %bb128
bb127:
  br label %bb129
bb128:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/free:Free", ptr %t513, i32 0, i32 77
  store i1 true, ptr %t515, !tbaa !21
  br label %bb129
bb129:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/free:Free", ptr %t516, i32 0, i32 94
  %t519 = load i64, ptr %l1, !tbaa !24
  %t522 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t518, i64 %t519)
  store ptr %t522, ptr %l305
  br label %bb130
bb130:
  %t523 = load ptr, ptr %l305, !tbaa !29
  store ptr %t523, ptr %l35, !tbaa !29
  %t524 = load ptr, ptr %l35, !tbaa !29
  store ptr %t524, ptr %l306, !tbaa !29
  %t525 = ptrtoint ptr %v0 to i64
  store i64 %t525, ptr %l307, !tbaa !24
  %t526 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t526, label %bb131, label %bb132
bb131:
  %t528 = load ptr, ptr %l306, !tbaa !29
  %t529 = call ptr @__olang_region_or(ptr %t528, ptr %v0)
  %t530 = ptrtoint ptr %t529 to i64
  store i64 %t530, ptr %l307, !tbaa !24
  br label %bb132
bb132:
  %t531 = load ptr, ptr %l35, !tbaa !29
  %t532 = load i64, ptr %l307
  %t533 = inttoptr i64 %t532 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %t533, ptr %t531)
  br label %bb133
bb133:
  %t535 = load ptr, ptr %l3, !tbaa !29
  %t537 = getelementptr %"compiler/free:mustW", ptr %t535, i32 0, i32 2
  store ptr %t537, ptr %l36, !tbaa !29
  store i64 0, ptr %l37, !tbaa !24
  br label %bb134
bb134:
  %t539 = load i64, ptr %l37, !tbaa !24
  store i64 %t539, ptr %l312, !tbaa !24
  %t540 = load ptr, ptr %l36, !tbaa !29
  %t542 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t540)
  store i64 %t542, ptr %l314
  br label %bb135
bb135:
  %t543 = load i64, ptr %l312, !tbaa !24
  %t544 = load i64, ptr %l314, !tbaa !24
  %t545 = icmp slt i64 %t543, %t544
  %t547 = xor i1 %t545, true
  br i1 %t547, label %bb136, label %bb137
bb136:
  br label %bb144
bb137:
  br label %bb138
bb138:
  %t549 = load ptr, ptr %l36, !tbaa !29
  %t550 = load i64, ptr %l37, !tbaa !24
  %t553 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t549, i64 %t550)
  store i64 %t553, ptr %l319
  br label %bb139
bb139:
  %t554 = load i64, ptr %l319, !tbaa !24
  store i64 %t554, ptr %l38, !tbaa !24
  %t555 = load ptr, ptr %l35, !tbaa !29
  store ptr %t555, ptr %l320, !tbaa !29
  %t556 = ptrtoint ptr %v0 to i64
  store i64 %t556, ptr %l321, !tbaa !24
  %t557 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t557, label %bb140, label %bb141
bb140:
  %t559 = load ptr, ptr %l320, !tbaa !29
  %t560 = call ptr @__olang_region_or(ptr %t559, ptr %v0)
  %t561 = ptrtoint ptr %t560 to i64
  store i64 %t561, ptr %l321, !tbaa !24
  br label %bb141
bb141:
  %t562 = load ptr, ptr %l35, !tbaa !29
  %t563 = load i64, ptr %l38, !tbaa !24
  %t564 = load i64, ptr %l321
  %t565 = inttoptr i64 %t564 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %t565, ptr %t562, i64 %t563)
  br label %bb142
bb142:
  br label %bb143
bb143:
  %t568 = load i64, ptr %l37, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l37, !tbaa !24
  br label %bb134
bb144:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = getelementptr %"compiler/free:Free", ptr %t572, i32 0, i32 96
  %t575 = load i64, ptr %l1, !tbaa !24
  %t578 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_Ha64a825bb0b4fc6c7596ac96329c2853(ptr %v0, ptr %v0, ptr %t574, i64 %t575)
  store ptr %t578, ptr %l330
  br label %bb145
bb145:
  %t579 = load ptr, ptr %l330, !tbaa !29
  store ptr %t579, ptr %l39, !tbaa !29
  %t580 = load ptr, ptr %l39, !tbaa !29
  store ptr %t580, ptr %l331, !tbaa !29
  %t581 = ptrtoint ptr %v0 to i64
  store i64 %t581, ptr %l332, !tbaa !24
  %t582 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1
  br i1 %t582, label %bb146, label %bb147
bb146:
  %t584 = load ptr, ptr %l331, !tbaa !29
  %t585 = call ptr @__olang_region_or(ptr %t584, ptr %v0)
  %t586 = ptrtoint ptr %t585 to i64
  store i64 %t586, ptr %l332, !tbaa !24
  br label %bb147
bb147:
  %t587 = load ptr, ptr %l39, !tbaa !29
  %t588 = load i64, ptr %l332
  %t589 = inttoptr i64 %t588 to ptr
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %t589, ptr %t587)
  br label %bb148
bb148:
  store i64 0, ptr %l40, !tbaa !24
  %t591 = load ptr, ptr %l2, !tbaa !29
  %t593 = getelementptr %"compiler/typed:Body", ptr %t591, i32 0, i32 7
  %t595 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t593)
  store i64 %t595, ptr %l337
  br label %bb149
bb149:
  %t596 = load i64, ptr %l337, !tbaa !24
  store i64 %t596, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t597 = load i64, ptr %l41, !tbaa !24
  %t598 = load i64, ptr %l40, !tbaa !24
  %t601 = icmp sgt i64 %t597, %t598
  br i1 %t601, label %bb150, label %bb151
bb150:
  %t603 = load i64, ptr %l42, !tbaa !24
  %t605 = icmp sgt i64 %t603, 0
  br i1 %t605, label %bb152, label %bb153
bb151:
  store i64 0, ptr %l341, !tbaa !24
  br label %bb155
bb152:
  %t607 = load i64, ptr %l41, !tbaa !24
  %t608 = load i64, ptr %l40, !tbaa !24
  %t611 = sub i64 %t607, %t608
  %t612 = load i64, ptr %l42, !tbaa !24
  %t615 = add i64 %t611, %t612
  %t617 = sub i64 %t615, 1
  %t618 = load i64, ptr %l42, !tbaa !24
  %t621 = sdiv i64 %t617, %t618
  store i64 %t621, ptr %l344, !tbaa !24
  br label %bb154
bb153:
  store i64 0, ptr %l344, !tbaa !24
  br label %bb154
bb154:
  %t623 = load i64, ptr %l344, !tbaa !24
  store i64 %t623, ptr %l341, !tbaa !24
  br label %bb155
bb155:
  %t624 = load i64, ptr %l341, !tbaa !24
  store i64 %t624, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb156
bb156:
  %t625 = load i64, ptr %l44, !tbaa !24
  %t626 = load i64, ptr %l43, !tbaa !24
  %t629 = icmp slt i64 %t625, %t626
  %t631 = xor i1 %t629, true
  br i1 %t631, label %bb157, label %bb158
bb157:
  br label %bb165
bb158:
  br label %bb159
bb159:
  %t633 = load i64, ptr %l40, !tbaa !24
  %t634 = load i64, ptr %l44, !tbaa !24
  %t635 = load i64, ptr %l42, !tbaa !24
  %t638 = mul i64 %t634, %t635
  %t641 = add i64 %t633, %t638
  store i64 %t641, ptr %l45, !tbaa !24
  %t643 = load ptr, ptr %l39, !tbaa !29
  store ptr %t643, ptr %l362, !tbaa !29
  %t644 = ptrtoint ptr %v0 to i64
  store i64 %t644, ptr %l363, !tbaa !24
  %t645 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1
  br i1 %t645, label %bb160, label %bb161
bb160:
  %t647 = load ptr, ptr %l362, !tbaa !29
  %t648 = call ptr @__olang_region_or(ptr %t647, ptr %v0)
  %t649 = ptrtoint ptr %t648 to i64
  store i64 %t649, ptr %l363, !tbaa !24
  br label %bb161
bb161:
  %t650 = load ptr, ptr %l39, !tbaa !29
  store ptr %t650, ptr %l365, !tbaa !29
  %t651 = load ptr, ptr %l3, !tbaa !29
  %t652 = load i64, ptr %l45, !tbaa !24
  %t655 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %t651, i64 %t652)
  store i1 %t655, ptr %l368
  br label %bb162
bb162:
  %t656 = load i64, ptr %l363
  %t657 = inttoptr i64 %t656 to ptr
  %t658 = load ptr, ptr %l365, !tbaa !29
  %t659 = load i1, ptr %l368, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %t657, ptr %t658, i1 %t659)
  br label %bb163
bb163:
  br label %bb164
bb164:
  %t660 = load i64, ptr %l44, !tbaa !24
  %t662 = add i64 %t660, 1
  store i64 %t662, ptr %l44, !tbaa !24
  br label %bb156
bb165:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 4
  %t5 = load %"compiler/source:Span", ptr %t4
  %t9 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %t3, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainElems(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 15
  %t13 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9, i64 %a1)
  store i32 %t13, ptr %l11
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load i32, ptr %l11, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t18 = load i32, ptr %l12, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t19, ptr %l13
  br label %bb4
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  store i32 %t20, ptr %l3, !tbaa !23
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l3, !tbaa !23
  %t33 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t29, i32 %t30)
  store i1 %t33, ptr %l21
  br label %bb8
bb7:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb8:
  %t34 = load i1, ptr %l21, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l18, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l14 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 10
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb4
bb4:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = icmp sge i64 %t23, %t24
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/load:Loader", ptr %t35, i32 0, i32 10
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l22
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t47, ptr %l25
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i1, ptr %l25, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachTy(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l9 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 28
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t4)
  store ptr %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eReach(ptr %v0, ptr %v0, ptr %t8, ptr %t9, i32 %t7)
  store i64 %t11, ptr %l9
  br label %bb2
bb2:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2fmir_2eReachNone, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i64 -2, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fmir_2eReachAny, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t27)
  store ptr %t29, ptr %l19
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l19, !tbaa !29
  store ptr %t30, ptr %l3, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l20, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  store ptr %t32, ptr %l21, !tbaa !29
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l24
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = load i32, ptr %l24, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l25
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l20, !tbaa !29
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = load i32, ptr %l26, !tbaa !23
  %t45 = sext i32 %t44 to i64
  store i64 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachedTasks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i64
  %l49 = alloca i64
  %l69 = alloca i1
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca i64
  %l84 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l113 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca i64
  %l136 = alloca ptr
  %l137 = alloca i64
  %l140 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca i64
  %l148 = alloca i64
  %l151 = alloca i1
  %l157 = alloca ptr
  %l163 = alloca i64
  %l165 = alloca i64
  %l170 = alloca i64
  %l174 = alloca i1
  %l179 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l192 = alloca i1
  %l196 = alloca i1
  %l206 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca i64
  %l212 = alloca i64
  %l217 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l37
  br label %bb1
bb1:
  %t6 = load i64, ptr %l37, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l38, !tbaa !24
  %t8 = load i64, ptr %l38, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l38, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l41
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_98179ed2ec661f5d_533fcebe8f905861)
  unreachable
bb4:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb10
bb7:
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l49, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l49, !tbaa !24
  store i64 %t47, ptr %l46, !tbaa !24
  br label %bb10
bb10:
  %t48 = load i64, ptr %l46, !tbaa !24
  store i64 %t48, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb12, label %bb13
bb12:
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t57 = load i64, ptr %l4, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  store i64 %t65, ptr %l9, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentry(ptr %v0, ptr %t67, i64 %t68)
  store i1 %t71, ptr %l69
  br label %bb15
bb15:
  %t72 = load i1, ptr %l69, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t75 = load i64, ptr %l9, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr i1, ptr %t78, i64 %t75
  store i1 true, ptr %t79, !tbaa !31
  %t80 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t80)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb11
bb21:
  %t87 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %l76
  br label %bb22
bb22:
  %t88 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t88, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l1, !tbaa !24
  store i64 %t89, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t92 = load i64, ptr %l11, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb23, label %bb24
bb23:
  %t97 = load i64, ptr %l13, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb28
bb25:
  %t101 = load i64, ptr %l12, !tbaa !24
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l13, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l13, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l84, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb27
bb27:
  %t117 = load i64, ptr %l84, !tbaa !24
  store i64 %t117, ptr %l81, !tbaa !24
  br label %bb28
bb28:
  %t118 = load i64, ptr %l81, !tbaa !24
  store i64 %t118, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t119 = load i64, ptr %l15, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb31:
  br label %bb32
bb32:
  %t127 = load i64, ptr %l11, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t129 = load i64, ptr %l13, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l16, !tbaa !24
  store ptr %l10, ptr %l102, !tbaa !29
  %t137 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l103
  br label %bb33
bb33:
  %t138 = load ptr, ptr %l102, !tbaa !29
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s0, ptr %s6, ptr %t138, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t140 = load i64, ptr %l15, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l15, !tbaa !24
  br label %bb29
bb36:
  store i64 0, ptr %l17, !tbaa !24
  %t144 = load i64, ptr %l1, !tbaa !24
  store i64 %t144, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t146 = load i64, ptr %l18, !tbaa !24
  %t147 = load i64, ptr %l17, !tbaa !24
  %t150 = icmp sgt i64 %t146, %t147
  br i1 %t150, label %bb37, label %bb38
bb37:
  %t152 = load i64, ptr %l19, !tbaa !24
  %t154 = icmp sgt i64 %t152, 0
  br i1 %t154, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb42
bb39:
  %t156 = load i64, ptr %l18, !tbaa !24
  %t157 = load i64, ptr %l17, !tbaa !24
  %t160 = sub i64 %t156, %t157
  %t161 = load i64, ptr %l19, !tbaa !24
  %t164 = add i64 %t160, %t161
  %t166 = sub i64 %t164, 1
  %t167 = load i64, ptr %l19, !tbaa !24
  %t170 = sdiv i64 %t166, %t167
  store i64 %t170, ptr %l113, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb41
bb41:
  %t172 = load i64, ptr %l113, !tbaa !24
  store i64 %t172, ptr %l110, !tbaa !24
  br label %bb42
bb42:
  %t173 = load i64, ptr %l110, !tbaa !24
  store i64 %t173, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb43
bb43:
  %t174 = load i64, ptr %l21, !tbaa !24
  %t175 = load i64, ptr %l20, !tbaa !24
  %t178 = icmp slt i64 %t174, %t175
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb44, label %bb45
bb44:
  br label %bb69
bb45:
  br label %bb46
bb46:
  %t182 = load i64, ptr %l17, !tbaa !24
  %t183 = load i64, ptr %l21, !tbaa !24
  %t184 = load i64, ptr %l19, !tbaa !24
  %t187 = mul i64 %t183, %t184
  %t190 = add i64 %t182, %t187
  store i64 %t190, ptr %l22, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/free:Free", ptr %t192, i32 0, i32 97
  %t195 = load i64, ptr %l22, !tbaa !24
  %t198 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t194, i64 %t195)
  store ptr %t198, ptr %l134
  br label %bb47
bb47:
  %t199 = load ptr, ptr %l134, !tbaa !29
  store ptr %t199, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb48
bb48:
  %t200 = load i64, ptr %l24, !tbaa !24
  store i64 %t200, ptr %l135, !tbaa !24
  %t201 = load ptr, ptr %l23, !tbaa !29
  store ptr %t201, ptr %l136, !tbaa !29
  %t202 = ptrtoint ptr %v0 to i64
  store i64 %t202, ptr %l137, !tbaa !24
  %t203 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t203, label %bb49, label %bb50
bb49:
  %t205 = load ptr, ptr %l136, !tbaa !29
  %t206 = call ptr @__olang_region_or(ptr %t205, ptr %v0)
  %t207 = ptrtoint ptr %t206 to i64
  store i64 %t207, ptr %l137, !tbaa !24
  br label %bb50
bb50:
  %t208 = load ptr, ptr %l23, !tbaa !29
  %t209 = load i64, ptr %l137
  %t210 = inttoptr i64 %t209 to ptr
  %t212 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t210, ptr %t208)
  store i64 %t212, ptr %l140
  br label %bb51
bb51:
  %t213 = load i64, ptr %l135, !tbaa !24
  %t214 = load i64, ptr %l140, !tbaa !24
  %t215 = icmp slt i64 %t213, %t214
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb52, label %bb53
bb52:
  br label %bb67
bb53:
  br label %bb54
bb54:
  %t219 = load ptr, ptr %l23, !tbaa !29
  store ptr %t219, ptr %l143, !tbaa !29
  %t220 = ptrtoint ptr %v0 to i64
  store i64 %t220, ptr %l144, !tbaa !24
  %t221 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t221, label %bb55, label %bb56
bb55:
  %t223 = load ptr, ptr %l143, !tbaa !29
  %t224 = call ptr @__olang_region_or(ptr %t223, ptr %v0)
  %t225 = ptrtoint ptr %t224 to i64
  store i64 %t225, ptr %l144, !tbaa !24
  br label %bb56
bb56:
  %t226 = load ptr, ptr %l23, !tbaa !29
  %t227 = load i64, ptr %l24, !tbaa !24
  %t228 = load i64, ptr %l144
  %t229 = inttoptr i64 %t228 to ptr
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t229, ptr %t226, i64 %t227)
  store i64 %t232, ptr %l148
  br label %bb57
bb57:
  %t233 = load i64, ptr %l148, !tbaa !24
  store i64 %t233, ptr %l25, !tbaa !24
  %t234 = load i64, ptr %l25, !tbaa !24
  %t236 = icmp sge i64 %t234, 0
  br i1 %t236, label %bb58, label %bb59
bb58:
  %t238 = load i64, ptr %l25, !tbaa !24
  %t239 = load i64, ptr %l1, !tbaa !24
  %t242 = icmp slt i64 %t238, %t239
  store i1 %t242, ptr %l151, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb60
bb60:
  %t244 = load i1, ptr %l151, !tbaa !21
  br i1 %t244, label %bb61, label %bb62
bb61:
  %t245 = load i64, ptr %l25, !tbaa !24
  %t248 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %s0, ptr %s0, ptr %l10, i64 %t245)
  store ptr %t248, ptr %l157
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t249 = load i64, ptr %l22, !tbaa !24
  %t250 = load ptr, ptr %l157, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t250, i64 %t249)
  br label %bb64
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t252 = load i64, ptr %l24, !tbaa !24
  %t254 = add i64 %t252, 1
  store i64 %t254, ptr %l24, !tbaa !24
  br label %bb48
bb67:
  br label %bb68
bb68:
  %t256 = load i64, ptr %l21, !tbaa !24
  %t258 = add i64 %t256, 1
  store i64 %t258, ptr %l21, !tbaa !24
  br label %bb43
bb69:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb70
bb70:
  %t260 = load i64, ptr %l26, !tbaa !24
  store i64 %t260, ptr %l163, !tbaa !24
  %t262 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l3)
  store i64 %t262, ptr %l165
  br label %bb71
bb71:
  %t263 = load i64, ptr %l163, !tbaa !24
  %t264 = load i64, ptr %l165, !tbaa !24
  %t265 = icmp slt i64 %t263, %t264
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb72, label %bb73
bb72:
  br label %bb112
bb73:
  br label %bb74
bb74:
  %t269 = load i64, ptr %l26, !tbaa !24
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l3, i64 %t269)
  store i64 %t272, ptr %l170
  br label %bb75
bb75:
  %t273 = load i64, ptr %l170, !tbaa !24
  store i64 %t273, ptr %l27, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/free:Free", ptr %t274, i32 0, i32 79
  %t277 = load i64, ptr %l27, !tbaa !24
  %t280 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t276, i64 %t277)
  store i1 %t280, ptr %l174
  br label %bb76
bb76:
  %t281 = load i1, ptr %l174, !tbaa !21
  br i1 %t281, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s18
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/free:Free", ptr %t283, i32 0, i32 2
  %t286 = load ptr, ptr %t285, !tbaa !29
  %t287 = load i64, ptr %l27, !tbaa !24
  %t290 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %s18, ptr %t286, i64 %t287)
  store { i64, ptr } %t290, ptr %l179
  br label %bb80
bb80:
  %t291 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t292 = extractvalue { i64, ptr } %t291, 0
  %t293 = extractvalue { i64, ptr } %t291, 1
  %t294 = mul i64 %t292, 8
  %t295 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t294)
  call void @llvm.memcpy.p0.p0.i64(ptr %t295, ptr %t293, i64 %t294, i1 false)
  %t296 = insertvalue { i64, ptr } undef, i64 %t292, 0
  %t297 = insertvalue { i64, ptr } %t296, ptr %t295, 1
  store { i64, ptr } %t297, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t299 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l30, !tbaa !24
  br label %bb81
bb81:
  %t303 = load i64, ptr %l29, !tbaa !24
  %t304 = load i64, ptr %l30, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb82, label %bb83
bb82:
  br label %bb96
bb83:
  br label %bb84
bb84:
  %t311 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t311, ptr %l187, !tbaa !27
  %t312 = load i64, ptr %l29, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr i64, ptr %t315, i64 %t312
  %t317 = load i64, ptr %t316, !tbaa !34
  store i64 %t317, ptr %l31, !tbaa !24
  %t319 = load i64, ptr %l31, !tbaa !24
  %t321 = icmp slt i64 %t319, 0
  br i1 %t321, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb87
bb86:
  %t323 = load i64, ptr %l31, !tbaa !24
  %t324 = load i64, ptr %l1, !tbaa !24
  %t327 = icmp sge i64 %t323, %t324
  store i1 %t327, ptr %l192, !tbaa !21
  br label %bb87
bb87:
  %t329 = load i1, ptr %l192, !tbaa !21
  br i1 %t329, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l196, !tbaa !21
  br label %bb90
bb89:
  %t330 = load i64, ptr %l31, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr i1, ptr %t333, i64 %t330
  %t335 = load i1, ptr %t334, !tbaa !31
  store i1 %t335, ptr %l196, !tbaa !21
  br label %bb90
bb90:
  %t337 = load i1, ptr %l196, !tbaa !21
  br i1 %t337, label %bb91, label %bb92
bb91:
  br label %bb95
bb92:
  br label %bb93
bb93:
  %t338 = load i64, ptr %l31, !tbaa !24
  %t340 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr i1, ptr %t341, i64 %t338
  store i1 true, ptr %t342, !tbaa !31
  %t343 = load i64, ptr %l31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t343)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t346 = load i64, ptr %l29, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l29, !tbaa !24
  br label %bb81
bb96:
  call void @__olang_scope_close(ptr %s18)
  store %olang.scope zeroinitializer, ptr %s22
  %t350 = load i64, ptr %l27, !tbaa !24
  %t353 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s22, ptr %l10, i64 %t350)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, ptr %l206
  br label %bb97
bb97:
  %t355 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s22, ptr %l206)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t355, ptr %l208
  br label %bb98
bb98:
  %t356 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208
  %t357 = call ptr @__olang_scope_alloc_a(ptr %s22, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t356, ptr %t357
  store ptr %t357, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb99
bb99:
  %t359 = load i64, ptr %l33, !tbaa !24
  store i64 %t359, ptr %l210, !tbaa !24
  %t360 = load ptr, ptr %l32, !tbaa !29
  %t362 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s22, ptr %t360)
  store i64 %t362, ptr %l212
  br label %bb100
bb100:
  %t363 = load i64, ptr %l210, !tbaa !24
  %t364 = load i64, ptr %l212, !tbaa !24
  %t365 = icmp slt i64 %t363, %t364
  %t367 = xor i1 %t365, true
  br i1 %t367, label %bb101, label %bb102
bb101:
  br label %bb110
bb102:
  br label %bb103
bb103:
  %t369 = load ptr, ptr %l32, !tbaa !29
  %t370 = load i64, ptr %l33, !tbaa !24
  %t373 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s22, ptr %t369, i64 %t370)
  store i64 %t373, ptr %l217
  br label %bb104
bb104:
  %t374 = load i64, ptr %l217, !tbaa !24
  store i64 %t374, ptr %l34, !tbaa !24
  %t375 = load i64, ptr %l34, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i1, ptr %t378, i64 %t375
  %t380 = load i1, ptr %t379, !tbaa !31
  br i1 %t380, label %bb105, label %bb106
bb105:
  br label %bb109
bb106:
  br label %bb107
bb107:
  %t382 = load i64, ptr %l34, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr i1, ptr %t385, i64 %t382
  store i1 true, ptr %t386, !tbaa !31
  %t387 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l3, i64 %t387)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t390 = load i64, ptr %l33, !tbaa !24
  %t392 = add i64 %t390, 1
  store i64 %t392, ptr %l33, !tbaa !24
  br label %bb99
bb110:
  call void @__olang_scope_close(ptr %s22)
  br label %bb111
bb111:
  %t394 = load i64, ptr %l26, !tbaa !24
  %t396 = add i64 %t394, 1
  store i64 %t396, ptr %l26, !tbaa !24
  br label %bb70
bb112:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecKeeps(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i1
  %l23 = alloca ptr
  %l25 = alloca i1
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l43 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 64
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load ptr, ptr %l9, !tbaa !29
  %t11 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t9, i64 %t8)
  store i1 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i1, ptr %l11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb7
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 65
  %t16 = load i64, ptr %l1, !tbaa !24
  %t19 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store ptr %t19, ptr %l16
  br label %bb5
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t23 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t21, i64 %t20)
  store i1 %t23, ptr %l18
  br label %bb6
bb6:
  %t24 = load i1, ptr %l18, !tbaa !21
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t25 = load i1, ptr %l12, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb12
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 67
  %t29 = load i64, ptr %l1, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store ptr %t32, ptr %l23
  br label %bb10
bb10:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load ptr, ptr %l23, !tbaa !29
  %t36 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t34, i64 %t33)
  store i1 %t36, ptr %l25
  br label %bb11
bb11:
  %t37 = load i1, ptr %l25, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb17
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 72
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store ptr %t45, ptr %l30
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l30, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t46)
  store i64 %t47, ptr %l31
  br label %bb16
bb16:
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = icmp sgt i64 %t48, 0
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb18, label %bb19
bb18:
  store i1 true, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 63
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t55, i64 %t56)
  store ptr %t59, ptr %l37
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l37, !tbaa !29
  store ptr %t60, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb22
bb22:
  %t61 = load i64, ptr %l4, !tbaa !24
  store i64 %t61, ptr %l38, !tbaa !24
  %t62 = load ptr, ptr %l3, !tbaa !29
  store ptr %t62, ptr %l39, !tbaa !29
  %t63 = ptrtoint ptr %v0 to i64
  store i64 %t63, ptr %l40, !tbaa !24
  %t64 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t64, label %bb23, label %bb24
bb23:
  %t66 = load ptr, ptr %l39, !tbaa !29
  %t67 = call ptr @__olang_region_or(ptr %t66, ptr %v0)
  %t68 = ptrtoint ptr %t67 to i64
  store i64 %t68, ptr %l40, !tbaa !24
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t70 = load i64, ptr %l40
  %t71 = inttoptr i64 %t70 to ptr
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t71, ptr %t69)
  store i64 %t73, ptr %l43
  br label %bb25
bb25:
  %t74 = load i64, ptr %l38, !tbaa !24
  %t75 = load i64, ptr %l43, !tbaa !24
  %t76 = icmp slt i64 %t74, %t75
  %t78 = xor i1 %t76, true
  br i1 %t78, label %bb26, label %bb27
bb26:
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t80 = load ptr, ptr %l3, !tbaa !29
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = ptrtoint ptr %v0 to i64
  store i64 %t81, ptr %l47, !tbaa !24
  %t82 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t82, label %bb29, label %bb30
bb29:
  %t84 = load ptr, ptr %l46, !tbaa !29
  %t85 = call ptr @__olang_region_or(ptr %t84, ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l47, !tbaa !24
  br label %bb30
bb30:
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t88 = load i64, ptr %l4, !tbaa !24
  %t89 = load i64, ptr %l47
  %t90 = inttoptr i64 %t89 to ptr
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t90, ptr %t87, i64 %t88)
  store i64 %t93, ptr %l51
  br label %bb31
bb31:
  %t94 = load i64, ptr %l51, !tbaa !24
  %t97 = ashr i64 %t94, 32
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = icmp eq i64 %t97, %t98
  br i1 %t101, label %bb32, label %bb33
bb32:
  store i1 true, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t104 = load i64, ptr %l4, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l4, !tbaa !24
  br label %bb22
bb36:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l48 = alloca i64
  %l51 = alloca i1
  %l54 = alloca i1
  %l58 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, [2 x i64] }
  %l75 = alloca { i64, [2 x i64] }
  %l77 = alloca i1
  %l79 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca i1
  %l89 = alloca i1
  %l91 = alloca { i64, ptr }
  %l95 = alloca { i64, [2 x i64] }
  %l97 = alloca { i64, [2 x i64] }
  %l99 = alloca i1
  %l101 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l113 = alloca i1
  %l121 = alloca i1
  %l123 = alloca i1
  %l125 = alloca { i64, ptr }
  %l129 = alloca { i64, [2 x i64] }
  %l131 = alloca { i64, [2 x i64] }
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l159 = alloca i1
  %l165 = alloca i1
  %l167 = alloca { i64, ptr }
  %l171 = alloca { i64, [2 x i64] }
  %l173 = alloca { i64, [2 x i64] }
  %l175 = alloca i1
  %l177 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca i1
  %l189 = alloca i1
  %l191 = alloca { i64, ptr }
  %l195 = alloca { i64, [2 x i64] }
  %l197 = alloca { i64, [2 x i64] }
  %l199 = alloca i1
  %l201 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l207 = alloca i1
  %l213 = alloca i64
  %l216 = alloca i1
  %l220 = alloca i1
  %l224 = alloca ptr
  %l230 = alloca i64
  %l232 = alloca ptr
  %l236 = alloca ptr
  %l239 = alloca i64
  %l244 = alloca i1
  %l247 = alloca i1
  %l252 = alloca i1
  %l257 = alloca { i64, [2 x i64] }
  %l259 = alloca { i64, [2 x i64] }
  %l261 = alloca i1
  %l269 = alloca i64
  %l275 = alloca i64
  %l278 = alloca i64
  %l297 = alloca i64
  %l314 = alloca i64
  %l317 = alloca i64
  %l338 = alloca i64
  %l341 = alloca i1
  %l344 = alloca i1
  %l346 = alloca i64
  %l353 = alloca { i64, ptr }
  %l360 = alloca ptr
  %l361 = alloca i1
  %l373 = alloca ptr
  %l374 = alloca i1
  %l383 = alloca ptr
  %l384 = alloca i64
  %t13 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [2 x i64] } %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l41
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l41, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = trunc i64 %t9 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 4, ptr %t14
  %t16 = insertvalue { i32 } undef, i32 %t11, 0
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 1
  store { i32 } %t16, ptr %t17
  %t18 = load { i64, [2 x i64] }, ptr %t13
  store { i64, [2 x i64] } %t18, ptr %l8
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l48
  br label %bb2
bb2:
  %t25 = load i64, ptr %l48, !tbaa !24
  store i64 %t25, ptr %l9, !tbaa !24
  %t26 = load i1, ptr %l5, !tbaa !21
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb3, label %bb4
bb3:
  %t30 = load i64, ptr %l9, !tbaa !24
  %t32 = icmp sge i64 %t30, 0
  store i1 %t32, ptr %l51, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l51, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp ne i64 %t35, %t36
  store i1 %t39, ptr %l54, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l54, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Plan", ptr %t42, i32 0, i32 5
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l60, !tbaa !27
  %t46 = load i64, ptr %l9, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i64, ptr %t49, i64 %t46
  %t51 = load i64, ptr %t50, !tbaa !34
  %t53 = icmp eq i64 %t51, 1
  br i1 %t53, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb14
bb11:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb13
bb12:
  %t55 = load ptr, ptr %l7, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Plan", ptr %t55, i32 0, i32 5
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l66, !tbaa !27
  %t59 = load i64, ptr %l9, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t59
  %t64 = load i64, ptr %t63, !tbaa !34
  %t66 = icmp eq i64 %t64, 3
  store i1 %t66, ptr %l64, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l64, !tbaa !21
  store i1 %t68, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t69 = load i1, ptr %l58, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Plan", ptr %t70, i32 0, i32 6
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l71, !tbaa !27
  %t74 = load i64, ptr %l9, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, [2 x i64] }, ptr %t77, i64 %t74
  %t79 = load { i64, [2 x i64] }, ptr %t78
  store { i64, [2 x i64] } %t79, ptr %l73
  %t80 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t80, ptr %l75
  %t83 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l73, ptr %l75)
  store i1 %t83, ptr %l77
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t84 = load i1, ptr %l77, !tbaa !21
  br i1 %t84, label %bb18, label %bb19
bb18:
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Plan", ptr %t85, i32 0, i32 6
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l79, !tbaa !27
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t93 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i64 %t89
  store { i64, [2 x i64] } %t90, ptr %t95
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %ret
bb21:
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t97 = load ptr, ptr %l82, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb22, label %bb23
bb22:
  %t100 = load ptr, ptr %l82, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 5
  store i1 %t103, ptr %l83, !tbaa !21
  br label %bb23
bb23:
  %t104 = load i1, ptr %l83, !tbaa !21
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l10, !tbaa !29
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t111 = load i1, ptr %l5, !tbaa !21
  br i1 %t111, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l89, !tbaa !21
  br label %bb30
bb28:
  %t113 = load ptr, ptr %l7, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Plan", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l91, !tbaa !27
  %t117 = load ptr, ptr %l10, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Promote", ptr %t117, i32 0, i32 1
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t124 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [2 x i64] }, ptr %t125, i64 %t122
  %t127 = load { i64, [2 x i64] }, ptr %t126
  store { i64, [2 x i64] } %t127, ptr %l95
  %t128 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t128, ptr %l97
  %t131 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l95, ptr %l97)
  store i1 %t131, ptr %l99
  br label %bb29
bb29:
  %t132 = load i1, ptr %l99, !tbaa !21
  store i1 %t132, ptr %l89, !tbaa !21
  br label %bb30
bb30:
  %t133 = load i1, ptr %l89, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t134 = load ptr, ptr %l7, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Plan", ptr %t134, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l101, !tbaa !27
  %t138 = load ptr, ptr %l10, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Promote", ptr %t138, i32 0, i32 1
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t144 = load { i64, [2 x i64] }, ptr %l8
  %t147 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr { i64, [2 x i64] }, ptr %t148, i64 %t143
  store { i64, [2 x i64] } %t144, ptr %t149
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load ptr, ptr %l10, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Promote", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l3, !tbaa !24
  %t157 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t150, i64 %t151, ptr %t155, i64 %t156, { i64, [2 x i64] } %t157, i1 false, i1 true)
  br label %bb34
bb34:
  br label %bb190
bb35:
  %t163 = load ptr, ptr %l2, !tbaa !29
  store ptr %t163, ptr %l112, !tbaa !29
  store i1 false, ptr %l113, !tbaa !21
  %t164 = load ptr, ptr %l112, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb36, label %bb37
bb36:
  %t167 = load ptr, ptr %l112, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 18}
  %t170 = icmp eq i64 %t168, 7
  store i1 %t170, ptr %l113, !tbaa !21
  br label %bb37
bb37:
  %t171 = load i1, ptr %l113, !tbaa !21
  br i1 %t171, label %bb38, label %bb39
bb38:
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l11, !tbaa !29
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t178 = load ptr, ptr %l11, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Make", ptr %t178, i32 0, i32 4
  %t181 = load i32, ptr %t180, !tbaa !23
  %t183 = icmp sge i32 %t181, 0
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load i1, ptr %l5, !tbaa !21
  br i1 %t185, label %bb43, label %bb44
bb42:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb47
bb43:
  store i1 true, ptr %l123, !tbaa !21
  br label %bb46
bb44:
  %t187 = load ptr, ptr %l7, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Plan", ptr %t187, i32 0, i32 0
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l125, !tbaa !27
  %t191 = load ptr, ptr %l11, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Make", ptr %t191, i32 0, i32 4
  %t194 = load i32, ptr %t193, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t198 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, [2 x i64] }, ptr %t199, i64 %t196
  %t201 = load { i64, [2 x i64] }, ptr %t200
  store { i64, [2 x i64] } %t201, ptr %l129
  %t202 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t202, ptr %l131
  %t205 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l129, ptr %l131)
  store i1 %t205, ptr %l133
  br label %bb45
bb45:
  %t206 = load i1, ptr %l133, !tbaa !21
  store i1 %t206, ptr %l123, !tbaa !21
  br label %bb46
bb46:
  %t207 = load i1, ptr %l123, !tbaa !21
  store i1 %t207, ptr %l121, !tbaa !21
  br label %bb47
bb47:
  %t208 = load i1, ptr %l121, !tbaa !21
  br i1 %t208, label %bb48, label %bb49
bb48:
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Plan", ptr %t209, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l135, !tbaa !27
  %t213 = load ptr, ptr %l11, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Make", ptr %t213, i32 0, i32 4
  %t216 = load i32, ptr %t215, !tbaa !23
  %t218 = sext i32 %t216 to i64
  %t219 = load { i64, [2 x i64] }, ptr %l8
  %t222 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr { i64, [2 x i64] }, ptr %t223, i64 %t218
  store { i64, [2 x i64] } %t219, ptr %t224
  br label %bb50
bb49:
  br label %bb50
bb50:
  %t225 = load ptr, ptr %l11, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Make", ptr %t225, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l14, !tbaa !24
  br label %bb51
bb51:
  %t234 = load i64, ptr %l13, !tbaa !24
  %t235 = load i64, ptr %l14, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb52, label %bb53
bb52:
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t242, ptr %l148, !tbaa !27
  %t243 = load i64, ptr %l13, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr ptr, ptr %t246, i64 %t243
  %t248 = load ptr, ptr %t247, !tbaa !39
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l1, !tbaa !24
  %t253 = load i64, ptr %l3, !tbaa !24
  %t254 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t250, i64 %t251, ptr %t248, i64 %t253, { i64, [2 x i64] } %t254, i1 false, i1 false)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t260 = load i64, ptr %l13, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l13, !tbaa !24
  br label %bb51
bb57:
  br label %bb190
bb58:
  %t264 = load ptr, ptr %l2, !tbaa !29
  store ptr %t264, ptr %l158, !tbaa !29
  store i1 false, ptr %l159, !tbaa !21
  %t265 = load ptr, ptr %l158, !tbaa !29
  %t266 = icmp ne ptr %t265, null
  br i1 %t266, label %bb59, label %bb60
bb59:
  %t268 = load ptr, ptr %l158, !tbaa !29
  %t269 = load i64, ptr %t268, !range !{i64 0, i64 18}
  %t271 = icmp eq i64 %t269, 16
  store i1 %t271, ptr %l159, !tbaa !21
  br label %bb60
bb60:
  %t272 = load i1, ptr %l159, !tbaa !21
  br i1 %t272, label %bb61, label %bb62
bb61:
  %t273 = load ptr, ptr %l2, !tbaa !29
  %t275 = getelementptr { i64, [5 x i64] }, ptr %t273, i32 0, i32 1
  %t276 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t275, i32 0, i32 2
  %t277 = load ptr, ptr %t276
  store ptr %t277, ptr %l16, !tbaa !29
  br label %bb63
bb62:
  br label %bb71
bb63:
  %t279 = load i1, ptr %l5, !tbaa !21
  br i1 %t279, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l165, !tbaa !21
  br label %bb67
bb65:
  %t281 = load ptr, ptr %l7, !tbaa !29
  %t283 = getelementptr %"compiler/typed:Plan", ptr %t281, i32 0, i32 0
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  store { i64, ptr } %t284, ptr %l167, !tbaa !27
  %t285 = load ptr, ptr %l16, !tbaa !29
  %t287 = getelementptr %"compiler/typed:Text", ptr %t285, i32 0, i32 1
  %t288 = load i32, ptr %t287, !tbaa !23
  %t290 = sext i32 %t288 to i64
  %t292 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr { i64, [2 x i64] }, ptr %t293, i64 %t290
  %t295 = load { i64, [2 x i64] }, ptr %t294
  store { i64, [2 x i64] } %t295, ptr %l171
  %t296 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t296, ptr %l173
  %t299 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l171, ptr %l173)
  store i1 %t299, ptr %l175
  br label %bb66
bb66:
  %t300 = load i1, ptr %l175, !tbaa !21
  store i1 %t300, ptr %l165, !tbaa !21
  br label %bb67
bb67:
  %t301 = load i1, ptr %l165, !tbaa !21
  br i1 %t301, label %bb68, label %bb69
bb68:
  %t302 = load ptr, ptr %l7, !tbaa !29
  %t304 = getelementptr %"compiler/typed:Plan", ptr %t302, i32 0, i32 0
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  store { i64, ptr } %t305, ptr %l177, !tbaa !27
  %t306 = load ptr, ptr %l16, !tbaa !29
  %t308 = getelementptr %"compiler/typed:Text", ptr %t306, i32 0, i32 1
  %t309 = load i32, ptr %t308, !tbaa !23
  %t311 = sext i32 %t309 to i64
  %t312 = load { i64, [2 x i64] }, ptr %l8
  %t315 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr { i64, [2 x i64] }, ptr %t316, i64 %t311
  store { i64, [2 x i64] } %t312, ptr %t317
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %bb190
bb71:
  %t318 = load ptr, ptr %l2, !tbaa !29
  store ptr %t318, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t319 = load ptr, ptr %l182, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb72, label %bb73
bb72:
  %t322 = load ptr, ptr %l182, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 18}
  %t325 = icmp eq i64 %t323, 8
  store i1 %t325, ptr %l183, !tbaa !21
  br label %bb73
bb73:
  %t326 = load i1, ptr %l183, !tbaa !21
  br i1 %t326, label %bb74, label %bb75
bb74:
  %t327 = load ptr, ptr %l2, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l17, !tbaa !29
  br label %bb76
bb75:
  br label %bb84
bb76:
  %t333 = load i1, ptr %l5, !tbaa !21
  br i1 %t333, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb80
bb78:
  %t335 = load ptr, ptr %l7, !tbaa !29
  %t337 = getelementptr %"compiler/typed:Plan", ptr %t335, i32 0, i32 0
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l191, !tbaa !27
  %t339 = load ptr, ptr %l17, !tbaa !29
  %t341 = getelementptr %"compiler/typed:Collect", ptr %t339, i32 0, i32 2
  %t342 = load i32, ptr %t341, !tbaa !23
  %t344 = sext i32 %t342 to i64
  %t346 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr { i64, [2 x i64] }, ptr %t347, i64 %t344
  %t349 = load { i64, [2 x i64] }, ptr %t348
  store { i64, [2 x i64] } %t349, ptr %l195
  %t350 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t350, ptr %l197
  %t353 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l195, ptr %l197)
  store i1 %t353, ptr %l199
  br label %bb79
bb79:
  %t354 = load i1, ptr %l199, !tbaa !21
  store i1 %t354, ptr %l189, !tbaa !21
  br label %bb80
bb80:
  %t355 = load i1, ptr %l189, !tbaa !21
  br i1 %t355, label %bb81, label %bb82
bb81:
  %t356 = load ptr, ptr %l7, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Plan", ptr %t356, i32 0, i32 0
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  store { i64, ptr } %t359, ptr %l201, !tbaa !27
  %t360 = load ptr, ptr %l17, !tbaa !29
  %t362 = getelementptr %"compiler/typed:Collect", ptr %t360, i32 0, i32 2
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t366 = load { i64, [2 x i64] }, ptr %l8
  %t369 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr { i64, [2 x i64] }, ptr %t370, i64 %t365
  store { i64, [2 x i64] } %t366, ptr %t371
  br label %bb83
bb82:
  br label %bb83
bb83:
  br label %bb190
bb84:
  %t372 = load ptr, ptr %l2, !tbaa !29
  store ptr %t372, ptr %l206, !tbaa !29
  store i1 false, ptr %l207, !tbaa !21
  %t373 = load ptr, ptr %l206, !tbaa !29
  %t374 = icmp ne ptr %t373, null
  br i1 %t374, label %bb85, label %bb86
bb85:
  %t376 = load ptr, ptr %l206, !tbaa !29
  %t377 = load i64, ptr %t376, !range !{i64 0, i64 18}
  %t379 = icmp eq i64 %t377, 6
  store i1 %t379, ptr %l207, !tbaa !21
  br label %bb86
bb86:
  %t380 = load i1, ptr %l207, !tbaa !21
  br i1 %t380, label %bb87, label %bb88
bb87:
  %t381 = load ptr, ptr %l2, !tbaa !29
  %t383 = getelementptr { i64, [5 x i64] }, ptr %t381, i32 0, i32 1
  %t384 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t383, i32 0, i32 2
  %t385 = load ptr, ptr %t384
  store ptr %t385, ptr %l18, !tbaa !29
  br label %bb89
bb88:
  br label %bb165
bb89:
  %t387 = load ptr, ptr %l18, !tbaa !29
  %t389 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t387)
  store i64 %t389, ptr %l213
  br label %bb90
bb90:
  %t390 = load i64, ptr %l213, !tbaa !24
  store i64 %t390, ptr %l19, !tbaa !24
  %t391 = load i64, ptr %l19, !tbaa !24
  %t393 = icmp slt i64 %t391, 0
  br i1 %t393, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l216, !tbaa !21
  br label %bb93
bb92:
  %t395 = load ptr, ptr %l18, !tbaa !29
  %t397 = getelementptr %"compiler/typed:Call", ptr %t395, i32 0, i32 2
  %t398 = load i32, ptr %t397, !tbaa !23
  %t400 = icmp slt i32 %t398, 0
  store i1 %t400, ptr %l216, !tbaa !21
  br label %bb93
bb93:
  %t402 = load i1, ptr %l216, !tbaa !21
  br i1 %t402, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l220, !tbaa !21
  br label %bb97
bb95:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/free:Free", ptr %t403, i32 0, i32 1
  %t406 = load i64, ptr %l19, !tbaa !24
  %t409 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t405, i64 %t406)
  store ptr %t409, ptr %l224
  br label %bb96
bb96:
  %t410 = load ptr, ptr %l224, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Body", ptr %t410, i32 0, i32 11
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  store i1 %t415, ptr %l220, !tbaa !21
  br label %bb97
bb97:
  %t417 = load i1, ptr %l220, !tbaa !21
  br i1 %t417, label %bb98, label %bb99
bb98:
  br label %ret
bb99:
  br label %bb100
bb100:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load i64, ptr %l19, !tbaa !24
  %t422 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t418, i64 %t419)
  store i64 %t422, ptr %l230
  br label %bb101
bb101:
  %t423 = load i64, ptr %l230, !tbaa !24
  store i64 %t423, ptr %l20, !tbaa !24
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t424)
  store ptr %t426, ptr %l232
  br label %bb102
bb102:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/free:Free", ptr %t427, i32 0, i32 1
  %t430 = load i64, ptr %l19, !tbaa !24
  %t433 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t429, i64 %t430)
  store ptr %t433, ptr %l236
  br label %bb103
bb103:
  %t434 = load ptr, ptr %l236, !tbaa !29
  %t436 = getelementptr %"compiler/typed:Body", ptr %t434, i32 0, i32 2
  %t437 = load i32, ptr %t436, !tbaa !23
  %t438 = load ptr, ptr %l232, !tbaa !29
  %t440 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t438, i32 %t437)
  store i64 %t440, ptr %l239
  br label %bb104
bb104:
  %t441 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t442 = load i64, ptr %l239, !tbaa !24
  %t444 = icmp eq i64 %t442, %t441
  store i1 %t444, ptr %l21, !tbaa !21
  %t446 = load i1, ptr %l5, !tbaa !21
  %t448 = xor i1 %t446, true
  br i1 %t448, label %bb105, label %bb106
bb105:
  %t450 = load i1, ptr %l21, !tbaa !21
  %t452 = xor i1 %t450, true
  store i1 %t452, ptr %l244, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb107
bb107:
  %t454 = load i1, ptr %l244, !tbaa !21
  br i1 %t454, label %bb108, label %bb109
bb108:
  %t455 = load i1, ptr %l6, !tbaa !21
  %t457 = xor i1 %t455, true
  store i1 %t457, ptr %l247, !tbaa !21
  br label %bb110
bb109:
  store i1 false, ptr %l247, !tbaa !21
  br label %bb110
bb110:
  %t459 = load i1, ptr %l247, !tbaa !21
  br i1 %t459, label %bb111, label %bb112
bb111:
  br label %ret
bb112:
  br label %bb113
bb113:
  %t460 = load i1, ptr %l5, !tbaa !21
  %t462 = xor i1 %t460, true
  br i1 %t462, label %bb114, label %bb115
bb114:
  %t464 = load ptr, ptr %l7, !tbaa !29
  %t465 = load ptr, ptr %l18, !tbaa !29
  %t467 = getelementptr %"compiler/typed:Call", ptr %t465, i32 0, i32 2
  %t468 = load i32, ptr %t467, !tbaa !23
  %t469 = load i64, ptr %l20, !tbaa !24
  %t473 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t464, i32 %t468, i64 %t469)
  store { i64, [2 x i64] } %t473, ptr %l257
  br label %bb116
bb115:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb118
bb116:
  %t474 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t474, ptr %l259
  %t477 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l257, ptr %l259)
  store i1 %t477, ptr %l261
  br label %bb117
bb117:
  %t478 = load i1, ptr %l261, !tbaa !21
  %t479 = xor i1 %t478, true
  store i1 %t479, ptr %l252, !tbaa !21
  br label %bb118
bb118:
  %t481 = load i1, ptr %l252, !tbaa !21
  br i1 %t481, label %bb119, label %bb120
bb119:
  br label %ret
bb120:
  br label %bb121
bb121:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i64, ptr %l1, !tbaa !24
  %t484 = load ptr, ptr %l18, !tbaa !29
  %t485 = load i64, ptr %l19, !tbaa !24
  %t486 = load { i64, [2 x i64] }, ptr %l4
  %t487 = load i64, ptr %l20, !tbaa !24
  %t494 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %t482, i64 %t483, ptr %t484, i64 %t485, { i64, [2 x i64] } %t486, i64 %t487)
  store i64 %t494, ptr %l269
  br label %bb122
bb122:
  %t495 = load i64, ptr %l269, !tbaa !24
  store i64 %t495, ptr %l22, !tbaa !24
  %t496 = load i64, ptr %l22, !tbaa !24
  %t498 = icmp slt i64 %t496, 0
  br i1 %t498, label %bb123, label %bb124
bb123:
  br label %ret
bb124:
  br label %bb125
bb125:
  store i64 0, ptr %l23, !tbaa !24
  store i64 63, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t500 = load i64, ptr %l24, !tbaa !24
  %t501 = load i64, ptr %l23, !tbaa !24
  %t504 = icmp sgt i64 %t500, %t501
  br i1 %t504, label %bb126, label %bb127
bb126:
  %t506 = load i64, ptr %l25, !tbaa !24
  %t508 = icmp sgt i64 %t506, 0
  br i1 %t508, label %bb128, label %bb129
bb127:
  store i64 0, ptr %l275, !tbaa !24
  br label %bb131
bb128:
  %t510 = load i64, ptr %l24, !tbaa !24
  %t511 = load i64, ptr %l23, !tbaa !24
  %t514 = sub i64 %t510, %t511
  %t515 = load i64, ptr %l25, !tbaa !24
  %t518 = add i64 %t514, %t515
  %t520 = sub i64 %t518, 1
  %t521 = load i64, ptr %l25, !tbaa !24
  %t524 = sdiv i64 %t520, %t521
  store i64 %t524, ptr %l278, !tbaa !24
  br label %bb130
bb129:
  store i64 0, ptr %l278, !tbaa !24
  br label %bb130
bb130:
  %t526 = load i64, ptr %l278, !tbaa !24
  store i64 %t526, ptr %l275, !tbaa !24
  br label %bb131
bb131:
  %t527 = load i64, ptr %l275, !tbaa !24
  store i64 %t527, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb132
bb132:
  %t528 = load i64, ptr %l27, !tbaa !24
  %t529 = load i64, ptr %l26, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb133, label %bb134
bb133:
  br label %bb141
bb134:
  br label %bb135
bb135:
  %t536 = load i64, ptr %l23, !tbaa !24
  %t537 = load i64, ptr %l27, !tbaa !24
  %t538 = load i64, ptr %l25, !tbaa !24
  %t541 = mul i64 %t537, %t538
  %t544 = add i64 %t536, %t541
  store i64 %t544, ptr %l28, !tbaa !24
  %t546 = load i64, ptr %l22, !tbaa !24
  %t547 = load i64, ptr %l28, !tbaa !24
  store i64 %t547, ptr %l297, !tbaa !24
  %t548 = load i64, ptr %l297, !tbaa !24
  %t549 = load i64, ptr %l297, !tbaa !24
  %t550 = shl i64 1, %t549
  %t553 = and i64 %t546, %t550
  %t555 = icmp ne i64 %t553, 0
  br i1 %t555, label %bb136, label %bb137
bb136:
  %t557 = load ptr, ptr %l7, !tbaa !29
  %t558 = load ptr, ptr %l18, !tbaa !29
  %t560 = getelementptr %"compiler/typed:Call", ptr %t558, i32 0, i32 2
  %t561 = load i32, ptr %t560, !tbaa !23
  %t562 = load i64, ptr %l28, !tbaa !24
  %t563 = load { i64, [2 x i64] }, ptr %l8
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %t557, i32 %t561, i64 %t562, { i64, [2 x i64] } %t563)
  br label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t568 = load i64, ptr %l27, !tbaa !24
  %t570 = add i64 %t568, 1
  store i64 %t570, ptr %l27, !tbaa !24
  br label %bb132
bb141:
  store i64 0, ptr %l29, !tbaa !24
  %t572 = load ptr, ptr %l18, !tbaa !29
  %t574 = getelementptr %"compiler/typed:Call", ptr %t572, i32 0, i32 1
  %t575 = load { i64, ptr }, ptr %t574, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t575, 0
  store i64 %t577, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t579 = load i64, ptr %l30, !tbaa !24
  %t580 = load i64, ptr %l29, !tbaa !24
  %t583 = icmp sgt i64 %t579, %t580
  br i1 %t583, label %bb142, label %bb143
bb142:
  %t585 = load i64, ptr %l31, !tbaa !24
  %t587 = icmp sgt i64 %t585, 0
  br i1 %t587, label %bb144, label %bb145
bb143:
  store i64 0, ptr %l314, !tbaa !24
  br label %bb147
bb144:
  %t589 = load i64, ptr %l30, !tbaa !24
  %t590 = load i64, ptr %l29, !tbaa !24
  %t593 = sub i64 %t589, %t590
  %t594 = load i64, ptr %l31, !tbaa !24
  %t597 = add i64 %t593, %t594
  %t599 = sub i64 %t597, 1
  %t600 = load i64, ptr %l31, !tbaa !24
  %t603 = sdiv i64 %t599, %t600
  store i64 %t603, ptr %l317, !tbaa !24
  br label %bb146
bb145:
  store i64 0, ptr %l317, !tbaa !24
  br label %bb146
bb146:
  %t605 = load i64, ptr %l317, !tbaa !24
  store i64 %t605, ptr %l314, !tbaa !24
  br label %bb147
bb147:
  %t606 = load i64, ptr %l314, !tbaa !24
  store i64 %t606, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb148
bb148:
  %t607 = load i64, ptr %l33, !tbaa !24
  %t608 = load i64, ptr %l32, !tbaa !24
  %t611 = icmp slt i64 %t607, %t608
  %t613 = xor i1 %t611, true
  br i1 %t613, label %bb149, label %bb150
bb149:
  br label %bb164
bb150:
  br label %bb151
bb151:
  %t615 = load i64, ptr %l29, !tbaa !24
  %t616 = load i64, ptr %l33, !tbaa !24
  %t617 = load i64, ptr %l31, !tbaa !24
  %t620 = mul i64 %t616, %t617
  %t623 = add i64 %t615, %t620
  store i64 %t623, ptr %l34, !tbaa !24
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t626 = load i64, ptr %l19, !tbaa !24
  %t627 = load i64, ptr %l34, !tbaa !24
  %t631 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t625, i64 %t626, i64 %t627)
  store i64 %t631, ptr %l338
  br label %bb152
bb152:
  %t632 = load i64, ptr %l338, !tbaa !24
  store i64 %t632, ptr %l35, !tbaa !24
  %t633 = load i64, ptr %l35, !tbaa !24
  %t635 = icmp sge i64 %t633, 0
  br i1 %t635, label %bb153, label %bb154
bb153:
  %t637 = load i64, ptr %l35, !tbaa !24
  %t639 = icmp slt i64 %t637, 63
  store i1 %t639, ptr %l341, !tbaa !21
  br label %bb155
bb154:
  store i1 false, ptr %l341, !tbaa !21
  br label %bb155
bb155:
  %t641 = load i1, ptr %l341, !tbaa !21
  br i1 %t641, label %bb156, label %bb157
bb156:
  %t642 = load i64, ptr %l22, !tbaa !24
  %t643 = load i64, ptr %l35, !tbaa !24
  store i64 %t643, ptr %l346, !tbaa !24
  %t644 = load i64, ptr %l346, !tbaa !24
  %t645 = load i64, ptr %l346, !tbaa !24
  %t646 = shl i64 1, %t645
  %t649 = and i64 %t642, %t646
  %t651 = icmp ne i64 %t649, 0
  store i1 %t651, ptr %l344, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l344, !tbaa !21
  br label %bb158
bb158:
  %t653 = load i1, ptr %l344, !tbaa !21
  br i1 %t653, label %bb159, label %bb160
bb159:
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load i64, ptr %l1, !tbaa !24
  %t656 = load ptr, ptr %l18, !tbaa !29
  %t658 = getelementptr %"compiler/typed:Call", ptr %t656, i32 0, i32 1
  %t659 = load { i64, ptr }, ptr %t658, !tbaa !27
  store { i64, ptr } %t659, ptr %l353, !tbaa !27
  %t660 = load i64, ptr %l34, !tbaa !24
  %t662 = getelementptr { i64, ptr }, ptr %l353, i32 0, i32 1
  %t663 = load ptr, ptr %t662, !tbaa !27
  %t664 = getelementptr ptr, ptr %t663, i64 %t660
  %t665 = load ptr, ptr %t664, !tbaa !39
  %t666 = load i64, ptr %l3, !tbaa !24
  %t667 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t654, i64 %t655, ptr %t665, i64 %t666, { i64, [2 x i64] } %t667, i1 false, i1 false)
  br label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t673 = load i64, ptr %l33, !tbaa !24
  %t675 = add i64 %t673, 1
  store i64 %t675, ptr %l33, !tbaa !24
  br label %bb148
bb164:
  br label %bb190
bb165:
  %t677 = load ptr, ptr %l2, !tbaa !29
  store ptr %t677, ptr %l360, !tbaa !29
  store i1 false, ptr %l361, !tbaa !21
  %t678 = load ptr, ptr %l360, !tbaa !29
  %t679 = icmp ne ptr %t678, null
  br i1 %t679, label %bb166, label %bb167
bb166:
  %t681 = load ptr, ptr %l360, !tbaa !29
  %t682 = load i64, ptr %t681, !range !{i64 0, i64 18}
  %t684 = icmp eq i64 %t682, 17
  store i1 %t684, ptr %l361, !tbaa !21
  br label %bb167
bb167:
  %t685 = load i1, ptr %l361, !tbaa !21
  br i1 %t685, label %bb168, label %bb169
bb168:
  %t686 = load ptr, ptr %l2, !tbaa !29
  %t688 = getelementptr { i64, [5 x i64] }, ptr %t686, i32 0, i32 1
  %t689 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t688, i32 0, i32 2
  %t690 = load ptr, ptr %t689
  store ptr %t690, ptr %l36, !tbaa !29
  br label %bb170
bb169:
  br label %bb172
bb170:
  %t692 = load ptr, ptr %l0, !tbaa !29
  %t693 = load i64, ptr %l1, !tbaa !24
  %t694 = load ptr, ptr %l36, !tbaa !29
  %t695 = load i64, ptr %l3, !tbaa !24
  %t696 = load { i64, [2 x i64] }, ptr %l4
  %t697 = load i1, ptr %l5, !tbaa !21
  %t698 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t692, i64 %t693, ptr %t694, i64 %t695, { i64, [2 x i64] } %t696, i1 %t697, i1 %t698)
  br label %bb171
bb171:
  br label %bb190
bb172:
  %t706 = load ptr, ptr %l2, !tbaa !29
  store ptr %t706, ptr %l373, !tbaa !29
  store i1 false, ptr %l374, !tbaa !21
  %t707 = load ptr, ptr %l373, !tbaa !29
  %t708 = icmp ne ptr %t707, null
  br i1 %t708, label %bb173, label %bb174
bb173:
  %t710 = load ptr, ptr %l373, !tbaa !29
  %t711 = load i64, ptr %t710, !range !{i64 0, i64 18}
  %t713 = icmp eq i64 %t711, 12
  store i1 %t713, ptr %l374, !tbaa !21
  br label %bb174
bb174:
  %t714 = load i1, ptr %l374, !tbaa !21
  br i1 %t714, label %bb175, label %bb176
bb175:
  %t715 = load ptr, ptr %l2, !tbaa !29
  %t717 = getelementptr { i64, [5 x i64] }, ptr %t715, i32 0, i32 1
  %t718 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t717, i32 0, i32 2
  %t719 = load ptr, ptr %t718
  store ptr %t719, ptr %l37, !tbaa !29
  br label %bb177
bb176:
  br label %bb185
bb177:
  %t721 = load ptr, ptr %l37, !tbaa !29
  %t723 = getelementptr %"compiler/typed:Seq", ptr %t721, i32 0, i32 1
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t726 = icmp eq ptr %t724, null
  %t728 = xor i1 %t726, true
  br i1 %t728, label %bb178, label %bb179
bb178:
  %t730 = load ptr, ptr %l0, !tbaa !29
  store ptr %t730, ptr %l383, !tbaa !29
  %t731 = load i64, ptr %l1, !tbaa !24
  store i64 %t731, ptr %l384, !tbaa !24
  %t732 = load ptr, ptr %l37, !tbaa !29
  %t734 = getelementptr %"compiler/typed:Seq", ptr %t732, i32 0, i32 1
  %t735 = load ptr, ptr %t734, !tbaa !29
  %t737 = icmp eq ptr %t735, null
  br i1 %t737, label %bb180, label %bb181
bb179:
  br label %bb184
bb180:
  call void @__olang_check_failed(ptr @olang_loc_21335a5a6f6a0d23_1fb4d5f27249eebf)
  unreachable
bb181:
  br label %bb182
bb182:
  %t739 = load ptr, ptr %l37, !tbaa !29
  %t741 = getelementptr %"compiler/typed:Seq", ptr %t739, i32 0, i32 1
  %t742 = load ptr, ptr %t741, !tbaa !29
  %t743 = load i64, ptr %l3, !tbaa !24
  %t744 = load { i64, [2 x i64] }, ptr %l4
  %t745 = load i1, ptr %l5, !tbaa !21
  %t746 = load i1, ptr %l6, !tbaa !21
  %t747 = load ptr, ptr %l383, !tbaa !29
  %t748 = load i64, ptr %l384, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t747, i64 %t748, ptr %t742, i64 %t743, { i64, [2 x i64] } %t744, i1 %t745, i1 %t746)
  br label %bb183
bb183:
  br label %bb184
bb184:
  br label %bb190
bb185:
  br i1 true, label %bb186, label %bb187
bb186:
  br label %bb188
bb187:
  br label %bb189
bb188:
  br label %bb190
bb189:
  call void @__olang_check_failed(ptr @olang_loc_80551b5782bfdb3b_907a9dbefd6aabe7)
  unreachable
bb190:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitLeaf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i32 %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:leaf"
  %l13 = alloca i1
  %l16 = alloca i64
  %l18 = alloca i64
  %l23 = alloca %"compiler/free:leaf"
  %l25 = alloca %"compiler/free:leaf"
  %l32 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l5, !tbaa !24
  %t9 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eonlyLeaf(ptr %v0, ptr %v1, ptr %t1, i32 %t2, ptr %t3, i64 %t4)
  store i1 %t9, ptr %l13
  br label %bb1
bb1:
  %t10 = load i1, ptr %l13, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l4, !tbaa !29
  store ptr %t12, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l16, !tbaa !24
  %t15 = load ptr, ptr %l6, !tbaa !29
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t15)
  store i64 %t17, ptr %l18
  br label %bb6
bb6:
  %t18 = load i64, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l18, !tbaa !24
  %t20 = icmp slt i64 %t18, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t24 = load ptr, ptr %l6, !tbaa !29
  %t25 = load i64, ptr %l7, !tbaa !24
  %t28 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t24, i64 %t25)
  store %"compiler/free:leaf" %t28, ptr %l23
  br label %bb10
bb10:
  %t30 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s3, ptr %l23)
  store %"compiler/free:leaf" %t30, ptr %l25
  br label %bb11
bb11:
  %t31 = load %"compiler/free:leaf", ptr %l25
  store %"compiler/free:leaf" %t31, ptr %l8
  %t32 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp ne i64 %t33, %t34
  br i1 %t37, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t46 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitPath(ptr %v0, ptr %s3, ptr %t39, i32 %t40, { i64, ptr } %t42, i64 0)
  store i1 %t46, ptr %l32
  br label %bb15
bb15:
  %t47 = load i1, ptr %l32, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/free:Free", ptr %t51, i32 0, i32 109
  store ptr %t53, ptr %l36, !tbaa !29
  %t58 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t58, ptr %l39
  br label %bb19
bb19:
  %t59 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 0
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l39
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H58704f470d09c6c466fe07940700ab7b(ptr %v0, ptr %t61, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t62, { i64, ptr } %t60)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l7, !tbaa !24
  br label %bb5
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i64
  %l75 = alloca ptr
  %l81 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 1
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  store i64 %t21, ptr %l9, !tbaa !24
  br label %bb55
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 18}
  %t30 = icmp eq i64 %t28, 7
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Make", ptr %t38, i32 0, i32 4
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb55
bb12:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l28, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 16
  store i1 %t52, ptr %l29, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t60 = load ptr, ptr %l4, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Text", ptr %t60, i32 0, i32 1
  %t63 = load i32, ptr %t62, !tbaa !23
  %t65 = sext i32 %t63 to i64
  store i64 %t65, ptr %l9, !tbaa !24
  br label %bb55
bb18:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %bb19, label %bb20
bb19:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i64, ptr %t71, !range !{i64 0, i64 18}
  %t74 = icmp eq i64 %t72, 8
  store i1 %t74, ptr %l38, !tbaa !21
  br label %bb20
bb20:
  %t75 = load i1, ptr %l38, !tbaa !21
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr { i64, [5 x i64] }, ptr %t76, i32 0, i32 1
  %t79 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t78, i32 0, i32 2
  %t80 = load ptr, ptr %t79
  store ptr %t80, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Collect", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  store i64 %t87, ptr %l9, !tbaa !24
  br label %bb55
bb24:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 18}
  %t96 = icmp eq i64 %t94, 6
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb27, label %bb28
bb27:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/typed:Call", ptr %t104, i32 0, i32 2
  %t107 = load i32, ptr %t106, !tbaa !23
  %t109 = sext i32 %t107 to i64
  store i64 %t109, ptr %l9, !tbaa !24
  br label %bb55
bb30:
  %t111 = load ptr, ptr %l1, !tbaa !29
  store ptr %t111, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = icmp ne ptr %t112, null
  br i1 %t113, label %bb31, label %bb32
bb31:
  %t115 = load ptr, ptr %l55, !tbaa !29
  %t116 = load i64, ptr %t115, !range !{i64 0, i64 18}
  %t118 = icmp eq i64 %t116, 17
  store i1 %t118, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l56, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  %t123 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t122, i32 0, i32 2
  %t124 = load ptr, ptr %t123
  store ptr %t124, ptr %l7, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t130 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t126, ptr %t127)
  store i64 %t130, ptr %l63
  br label %bb36
bb36:
  %t131 = load i64, ptr %l63, !tbaa !24
  store i64 %t131, ptr %l9, !tbaa !24
  br label %bb55
bb37:
  %t132 = load ptr, ptr %l1, !tbaa !29
  store ptr %t132, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t133 = load ptr, ptr %l64, !tbaa !29
  %t134 = icmp ne ptr %t133, null
  br i1 %t134, label %bb38, label %bb39
bb38:
  %t136 = load ptr, ptr %l64, !tbaa !29
  %t137 = load i64, ptr %t136, !range !{i64 0, i64 18}
  %t139 = icmp eq i64 %t137, 12
  store i1 %t139, ptr %l65, !tbaa !21
  br label %bb39
bb39:
  %t140 = load i1, ptr %l65, !tbaa !21
  br i1 %t140, label %bb40, label %bb41
bb40:
  %t141 = load ptr, ptr %l1, !tbaa !29
  %t143 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  %t144 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t143, i32 0, i32 2
  %t145 = load ptr, ptr %t144
  store ptr %t145, ptr %l8, !tbaa !29
  br label %bb42
bb41:
  br label %bb50
bb42:
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Seq", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb43, label %bb44
bb43:
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l75, !tbaa !29
  %t157 = load ptr, ptr %l8, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Seq", ptr %t157, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb45, label %bb46
bb44:
  store i64 -1, ptr %l74, !tbaa !24
  br label %bb49
bb45:
  call void @__olang_check_failed(ptr @olang_loc_2a5f6fd698855c53_bf46ca1a958c9ea7)
  unreachable
bb46:
  br label %bb47
bb47:
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Seq", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t168 = load ptr, ptr %l75, !tbaa !29
  %t170 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t168, ptr %t167)
  store i64 %t170, ptr %l81
  br label %bb48
bb48:
  %t171 = load i64, ptr %l81, !tbaa !24
  store i64 %t171, ptr %l74, !tbaa !24
  br label %bb49
bb49:
  %t172 = load i64, ptr %l74, !tbaa !24
  store i64 %t172, ptr %l9, !tbaa !24
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_4959d0728bd157ab_d85fd94b6e31a9bf)
  unreachable
bb55:
  %t173 = load i64, ptr %l9, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etypeModule(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l18
  br label %bb6
bb6:
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp ne i32 %t28, 0
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l15, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i64 -3, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l2, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t35 = load i32, ptr %l3, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l21, !tbaa !29
  %t40 = load i32, ptr %l24, !tbaa !23
  %t41 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb32
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i64, ptr %l16, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = call i64 @compiler_2ffree_2eokind(i64 %t23)
  store i64 %t25, ptr %l18
  br label %bb8
bb8:
  %t26 = load i64, ptr %l18, !tbaa !24
  store i64 %t26, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t37 = icmp eq i64 %t33, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @compiler_2ffree_2eoval(i64 %t41)
  store i64 %t43, ptr %l29
  br label %bb14
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb21
bb14:
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t44, i64 %t45)
  store i1 %t46, ptr %l30
  br label %bb15
bb15:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 13
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = call i64 @compiler_2ffree_2eoval(i64 %t51)
  store i64 %t53, ptr %l35
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t55 = load i64, ptr %l35, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t54, i64 %t55)
  store i1 %t56, ptr %l36
  br label %bb19
bb19:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l31, !tbaa !21
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb21
bb21:
  %t59 = load i1, ptr %l26, !tbaa !21
  br i1 %t59, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t60 = load ptr, ptr %lp2
  store ptr %t60, ptr %l37, !tbaa !29
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t65 = icmp eq i64 %t61, %t62
  br i1 %t65, label %bb25, label %bb26
bb25:
  %t67 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  store i64 %t67, ptr %l42, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = call i64 @compiler_2ffree_2eoval(i64 %t68)
  store i64 %t70, ptr %l44
  br label %bb27
bb26:
  %t71 = load i64, ptr %l5, !tbaa !24
  store i64 %t71, ptr %l41, !tbaa !24
  br label %bb29
bb27:
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = call i64 @compiler_2ffree_2eorig(i64 %t73, i64 %t74)
  store i64 %t75, ptr %l45
  br label %bb28
bb28:
  %t76 = load i64, ptr %l45, !tbaa !24
  store i64 %t76, ptr %l41, !tbaa !24
  br label %bb29
bb29:
  %t77 = load ptr, ptr %l37, !tbaa !29
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t77, i64 %t78)
  store i64 %t79, ptr %l47
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l4, !tbaa !24
  br label %bb2
bb32:
  %t84 = load ptr, ptr %lp2
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca i1
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l51 = alloca i64
  %l54 = alloca i1
  %l58 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca ptr
  %l67 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l78 = alloca ptr
  %l81 = alloca i64
  %l84 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i1
  %l116 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca ptr
  %l135 = alloca i1
  %l143 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca i1
  %l154 = alloca i1
  %l155 = alloca i64
  %l158 = alloca { i64, ptr }
  %l160 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l18, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t6 = load ptr, ptr %l19, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l19, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l20, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t14 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
bb7:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t17 = load ptr, ptr %l24, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l24, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 2
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t37 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t31, ptr %t32, ptr %t33)
  store i64 %t37, ptr %l33
  br label %bb13
bb13:
  %t38 = load i64, ptr %l33, !tbaa !24
  store i64 %t38, ptr %rv
  br label %ret
bb14:
  %t39 = load ptr, ptr %l2, !tbaa !29
  store ptr %t39, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t40 = load ptr, ptr %l34, !tbaa !29
  %t41 = icmp ne ptr %t40, null
  br i1 %t41, label %bb15, label %bb16
bb15:
  %t43 = load ptr, ptr %l34, !tbaa !29
  %t44 = load i64, ptr %t43, !range !{i64 0, i64 18}
  %t46 = icmp eq i64 %t44, 3
  store i1 %t46, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb17, label %bb18
bb17:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr { i64, [5 x i64] }, ptr %t48, i32 0, i32 1
  %t51 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t50, i32 0, i32 2
  %t52 = load ptr, ptr %t51
  store ptr %t52, ptr %l5, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t54, ptr %t55, ptr %t56)
  store i64 %t60, ptr %l43
  br label %bb20
bb20:
  %t61 = load i64, ptr %l43, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
bb21:
  %t62 = load ptr, ptr %l2, !tbaa !29
  store ptr %t62, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t63 = load ptr, ptr %l44, !tbaa !29
  %t64 = icmp ne ptr %t63, null
  br i1 %t64, label %bb22, label %bb23
bb22:
  %t66 = load ptr, ptr %l44, !tbaa !29
  %t67 = load i64, ptr %t66, !range !{i64 0, i64 18}
  %t69 = icmp eq i64 %t67, 6
  store i1 %t69, ptr %l45, !tbaa !21
  br label %bb23
bb23:
  %t70 = load i1, ptr %l45, !tbaa !21
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr { i64, [5 x i64] }, ptr %t71, i32 0, i32 1
  %t74 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t73, i32 0, i32 2
  %t75 = load ptr, ptr %t74
  store ptr %t75, ptr %l6, !tbaa !29
  br label %bb26
bb25:
  br label %bb49
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = load ptr, ptr %l6, !tbaa !29
  %t79 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t77)
  store i64 %t79, ptr %l51
  br label %bb27
bb27:
  %t80 = load i64, ptr %l51, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  br i1 %t83, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb31
bb29:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 1
  %t88 = load i64, ptr %l7, !tbaa !24
  %t91 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t87, i64 %t88)
  store ptr %t91, ptr %l58
  br label %bb30
bb30:
  %t92 = load ptr, ptr %l58, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Body", ptr %t92, i32 0, i32 11
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = icmp eq ptr %t95, null
  store i1 %t97, ptr %l54, !tbaa !21
  br label %bb31
bb31:
  %t99 = load i1, ptr %l54, !tbaa !21
  br i1 %t99, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb36
bb33:
  %t100 = load ptr, ptr %l3, !tbaa !29
  store ptr %t100, ptr %l63, !tbaa !29
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:Free", ptr %t101, i32 0, i32 1
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t103, i64 %t104)
  store ptr %t107, ptr %l67
  br label %bb34
bb34:
  %t108 = load ptr, ptr %l67, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 2
  %t111 = load i32, ptr %t110, !tbaa !23
  %t112 = load ptr, ptr %l63, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t112, i32 %t111)
  store { i64, ptr } %t114, ptr %l70
  br label %bb35
bb35:
  %t115 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  %t118 = icmp ne i64 %t116, 1
  store i1 %t118, ptr %l62, !tbaa !21
  br label %bb36
bb36:
  %t120 = load i1, ptr %l62, !tbaa !21
  br i1 %t120, label %bb37, label %bb38
bb37:
  %t121 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t121, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t123 = load ptr, ptr %l3, !tbaa !29
  store ptr %t123, ptr %l74, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 1
  %t127 = load i64, ptr %l7, !tbaa !24
  %t130 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t126, i64 %t127)
  store ptr %t130, ptr %l78
  br label %bb40
bb40:
  %t131 = load ptr, ptr %l78, !tbaa !29
  %t133 = getelementptr %"compiler/typed:Body", ptr %t131, i32 0, i32 2
  %t134 = load i32, ptr %t133, !tbaa !23
  %t135 = load ptr, ptr %l74, !tbaa !29
  %t137 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t135, i32 %t134, i64 0)
  store i64 %t137, ptr %l81
  br label %bb41
bb41:
  %t138 = load i64, ptr %l81, !tbaa !24
  store i64 %t138, ptr %l8, !tbaa !24
  %t139 = load i64, ptr %l8, !tbaa !24
  %t141 = icmp slt i64 %t139, 0
  br i1 %t141, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb44
bb43:
  %t143 = load i64, ptr %l8, !tbaa !24
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t146 = getelementptr %"compiler/typed:Call", ptr %t144, i32 0, i32 1
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t147, 0
  %t152 = icmp sge i64 %t143, %t149
  store i1 %t152, ptr %l84, !tbaa !21
  br label %bb44
bb44:
  %t154 = load i1, ptr %l84, !tbaa !21
  br i1 %t154, label %bb45, label %bb46
bb45:
  %t155 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  store i64 %t155, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load ptr, ptr %l1, !tbaa !29
  %t159 = load ptr, ptr %l6, !tbaa !29
  %t161 = getelementptr %"compiler/typed:Call", ptr %t159, i32 0, i32 1
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l94, !tbaa !27
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t163
  %t168 = load ptr, ptr %t167, !tbaa !39
  %t172 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t157, ptr %t158, ptr %t168)
  store i64 %t172, ptr %l97
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s4)
  %t173 = load i64, ptr %l97, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
bb49:
  %t174 = load ptr, ptr %l2, !tbaa !29
  store ptr %t174, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t175 = load ptr, ptr %l98, !tbaa !29
  %t176 = icmp ne ptr %t175, null
  br i1 %t176, label %bb50, label %bb51
bb50:
  %t178 = load ptr, ptr %l98, !tbaa !29
  %t179 = load i64, ptr %t178, !range !{i64 0, i64 18}
  %t181 = icmp eq i64 %t179, 14
  store i1 %t181, ptr %l99, !tbaa !21
  br label %bb51
bb51:
  %t182 = load i1, ptr %l99, !tbaa !21
  br i1 %t182, label %bb52, label %bb53
bb52:
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = getelementptr { i64, [5 x i64] }, ptr %t183, i32 0, i32 1
  %t186 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t185, i32 0, i32 2
  %t187 = load ptr, ptr %t186
  store ptr %t187, ptr %l9, !tbaa !29
  br label %bb54
bb53:
  br label %bb71
bb54:
  %t189 = load ptr, ptr %l9, !tbaa !29
  %t191 = getelementptr %"compiler/typed:Try", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = icmp eq ptr %t192, null
  br i1 %t194, label %bb55, label %bb56
bb55:
  %t196 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t196, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t198 = load ptr, ptr %l9, !tbaa !29
  %t200 = getelementptr %"compiler/typed:Try", ptr %t198, i32 0, i32 1
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t203 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  store i64 %t205, ptr %l12, !tbaa !24
  br label %bb58
bb58:
  %t207 = load i64, ptr %l11, !tbaa !24
  %t208 = load i64, ptr %l12, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb59, label %bb60
bb59:
  br label %bb66
bb60:
  br label %bb61
bb61:
  %t215 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t215, ptr %l116, !tbaa !27
  %t216 = load i64, ptr %l11, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr ptr, ptr %t219, i64 %t216
  %t221 = load ptr, ptr %t220, !tbaa !39
  %t225 = getelementptr %"compiler/typed:Clause", ptr %t221, i32 0, i32 4
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t230 = icmp sgt i64 %t228, 0
  br i1 %t230, label %bb62, label %bb63
bb62:
  %t232 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t232, ptr %rv
  br label %ret
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t234 = load i64, ptr %l11, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l11, !tbaa !24
  br label %bb58
bb66:
  %t238 = load ptr, ptr %l0, !tbaa !29
  store ptr %t238, ptr %l126, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  store ptr %t239, ptr %l127, !tbaa !29
  %t240 = load ptr, ptr %l9, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Try", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = icmp eq ptr %t243, null
  br i1 %t245, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_4acb4c8921e8c407_808d59af97a4073)
  unreachable
bb68:
  br label %bb69
bb69:
  %t247 = load ptr, ptr %l9, !tbaa !29
  %t249 = getelementptr %"compiler/typed:Try", ptr %t247, i32 0, i32 0
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t251 = load ptr, ptr %l126, !tbaa !29
  %t252 = load ptr, ptr %l127, !tbaa !29
  %t254 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t251, ptr %t252, ptr %t250)
  store i64 %t254, ptr %l133
  br label %bb70
bb70:
  %t255 = load i64, ptr %l133, !tbaa !24
  store i64 %t255, ptr %rv
  br label %ret
bb71:
  %t256 = load ptr, ptr %l2, !tbaa !29
  store ptr %t256, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t257 = load ptr, ptr %l134, !tbaa !29
  %t258 = icmp ne ptr %t257, null
  br i1 %t258, label %bb72, label %bb73
bb72:
  %t260 = load ptr, ptr %l134, !tbaa !29
  %t261 = load i64, ptr %t260, !range !{i64 0, i64 18}
  %t263 = icmp eq i64 %t261, 17
  store i1 %t263, ptr %l135, !tbaa !21
  br label %bb73
bb73:
  %t264 = load i1, ptr %l135, !tbaa !21
  br i1 %t264, label %bb74, label %bb75
bb74:
  %t265 = load ptr, ptr %l2, !tbaa !29
  %t267 = getelementptr { i64, [5 x i64] }, ptr %t265, i32 0, i32 1
  %t268 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t267, i32 0, i32 2
  %t269 = load ptr, ptr %t268
  store ptr %t269, ptr %l14, !tbaa !29
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load ptr, ptr %l1, !tbaa !29
  %t273 = load ptr, ptr %l14, !tbaa !29
  %t277 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t271, ptr %t272, ptr %t273)
  store i64 %t277, ptr %l143
  br label %bb77
bb77:
  %t278 = load i64, ptr %l143, !tbaa !24
  store i64 %t278, ptr %rv
  br label %ret
bb78:
  %t279 = load ptr, ptr %l2, !tbaa !29
  store ptr %t279, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t280 = load ptr, ptr %l144, !tbaa !29
  %t281 = icmp ne ptr %t280, null
  br i1 %t281, label %bb79, label %bb80
bb79:
  %t283 = load ptr, ptr %l144, !tbaa !29
  %t284 = load i64, ptr %t283, !range !{i64 0, i64 18}
  %t286 = icmp eq i64 %t284, 9
  store i1 %t286, ptr %l145, !tbaa !21
  br label %bb80
bb80:
  %t287 = load i1, ptr %l145, !tbaa !21
  br i1 %t287, label %bb81, label %bb82
bb81:
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = getelementptr { i64, [5 x i64] }, ptr %t288, i32 0, i32 1
  %t291 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t290, i32 0, i32 2
  %t292 = load i32, ptr %t291, !range !{i32 0, i32 52}
  store i32 %t292, ptr %l15
  %t294 = load ptr, ptr %l2, !tbaa !29
  %t296 = getelementptr { i64, [5 x i64] }, ptr %t294, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t296, i32 0, i32 4
  %t298 = load { i64, ptr }, ptr %t297
  store { i64, ptr } %t298, ptr %l16, !tbaa !27
  br label %bb83
bb82:
  br label %bb89
bb83:
  %t300 = load i32, ptr %l15, !range !{i32 0, i32 52}
  %t301 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t304 = call i1 @compiler_2ffree_2eisConversion(ptr %v2, i32 %t300, { i64, ptr } %t301)
  store i1 %t304, ptr %l154
  br label %bb84
bb84:
  %t305 = load i1, ptr %l154, !tbaa !21
  br i1 %t305, label %bb85, label %bb86
bb85:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t308 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t308, ptr %l158, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = getelementptr ptr, ptr %t310, i64 0
  %t312 = load ptr, ptr %t311, !tbaa !39
  %t316 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t306, ptr %t307, ptr %t312)
  store i64 %t316, ptr %l160
  br label %bb87
bb86:
  %t317 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t317, ptr %l155, !tbaa !24
  br label %bb88
bb87:
  %t319 = load i64, ptr %l160, !tbaa !24
  store i64 %t319, ptr %l155, !tbaa !24
  br label %bb88
bb88:
  %t320 = load i64, ptr %l155, !tbaa !24
  store i64 %t320, ptr %rv
  br label %ret
bb89:
  br i1 true, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t321 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t321, ptr %rv
  br label %ret
bb93:
  call void @__olang_check_failed(ptr @olang_loc_d1dd1febe39b41f_df28cb247c1abe4b)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewriteFeedCalls(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/free:feedCall"
  %l4 = alloca %"compiler/free:feed"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, [2 x i64] }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca i64
  %l29 = alloca i64
  %l31 = alloca i64
  %l36 = alloca %"compiler/free:feedCall"
  %l40 = alloca %"compiler/free:feed"
  %l43 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l57 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l66 = alloca i64
  %l75 = alloca { i64, [2 x i64] }
  %l76 = alloca { i64, [2 x i64] }
  %l78 = alloca { i64, [2 x i64] }
  %l80 = alloca i1
  %l85 = alloca ptr
  %l94 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l126 = alloca i64
  %l142 = alloca i64
  %l145 = alloca i64
  %l166 = alloca i64
  %l169 = alloca i1
  %l172 = alloca i1
  %l174 = alloca i64
  %l178 = alloca i1
  %l183 = alloca { i64, ptr }
  %l188 = alloca i64
  %l191 = alloca i1
  %l193 = alloca { i64, ptr }
  %l197 = alloca i1
  %l199 = alloca { i64, ptr }
  %l204 = alloca { i64, ptr }
  %l206 = alloca { i64, [2 x i64] }
  %l208 = alloca { i64, [2 x i64] }
  %l210 = alloca i1
  %l212 = alloca { i64, ptr }
  %t156 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 112
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l29, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eLen_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l31
  br label %bb2
bb2:
  %t9 = load i64, ptr %l29, !tbaa !24
  %t10 = load i64, ptr %l31, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb97
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/free:feedCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eAt_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/free:feedCall" %t19, ptr %l36
  br label %bb6
bb6:
  %t20 = load %"compiler/free:feedCall", ptr %l36
  store %"compiler/free:feedCall" %t20, ptr %l3
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 110
  %t24 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 4
  %t25 = load i64, ptr %t24, !tbaa !24
  %t28 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t23, i64 %t25)
  store %"compiler/free:feed" %t28, ptr %l40
  br label %bb7
bb7:
  %t29 = load %"compiler/free:feed", ptr %l40
  store %"compiler/free:feed" %t29, ptr %l4
  %t30 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp slt i64 %t31, 0
  br i1 %t33, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb15
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 22
  %t38 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t37, i64 %t39)
  store i1 %t42, ptr %l47
  br label %bb10
bb10:
  %t43 = load i1, ptr %l47, !tbaa !21
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 90
  %t47 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 2
  %t48 = load i64, ptr %t47, !tbaa !24
  %t51 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t46, i64 %t48)
  store i1 %t51, ptr %l52
  br label %bb13
bb12:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb14
bb13:
  %t52 = load i1, ptr %l52, !tbaa !21
  %t53 = xor i1 %t52, true
  store i1 %t53, ptr %l48, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l48, !tbaa !21
  store i1 %t55, ptr %l43, !tbaa !21
  br label %bb15
bb15:
  %t56 = load i1, ptr %l43, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb96
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 3
  %t60 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t59, i64 %t61)
  store ptr %t64, ptr %l57
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l57, !tbaa !29
  store ptr %t65, ptr %l5, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Plan", ptr %t66, i32 0, i32 5
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l59, !tbaa !27
  %t70 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t71
  %t76 = load i64, ptr %t75, !tbaa !34
  %t78 = icmp ne i64 %t76, 1
  br i1 %t78, label %bb20, label %bb21
bb20:
  br label %bb96
bb21:
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 3
  %t84 = load i64, ptr %t83, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t80, i64 %t82, i64 %t84)
  store i64 %t88, ptr %l66
  br label %bb23
bb23:
  %t89 = load i64, ptr %l66, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb24, label %bb25
bb24:
  br label %bb96
bb25:
  br label %bb26
bb26:
  %t94 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  %t97 = trunc i64 %t95 to i32
  store i32 %t97, ptr %l7, !tbaa !23
  %t100 = load ptr, ptr %l5, !tbaa !29
  %t101 = load i32, ptr %l7, !tbaa !23
  %t102 = load i64, ptr %l6, !tbaa !24
  %t106 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t100, i32 %t101, i64 %t102)
  store { i64, [2 x i64] } %t106, ptr %l75
  br label %bb27
bb27:
  %t107 = load { i64, [2 x i64] }, ptr %l75
  store { i64, [2 x i64] } %t107, ptr %l8
  %t108 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t108, ptr %l76
  %t109 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 4
  %t110 = load { i64, [2 x i64] }, ptr %t109
  store { i64, [2 x i64] } %t110, ptr %l78
  %t113 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l76, ptr %l78)
  store i1 %t113, ptr %l80
  br label %bb28
bb28:
  %t114 = load i1, ptr %l80, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb96
bb30:
  br label %bb31
bb31:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t125 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v0, ptr %t117, i64 %t119, i64 %t121)
  store ptr %t125, ptr %l85
  br label %bb32
bb32:
  %t126 = load ptr, ptr %l85, !tbaa !29
  store ptr %t126, ptr %l9, !tbaa !29
  %t127 = load ptr, ptr %l9, !tbaa !29
  %t129 = icmp eq ptr %t127, null
  br i1 %t129, label %bb33, label %bb34
bb33:
  br label %bb96
bb34:
  br label %bb35
bb35:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load ptr, ptr %l9, !tbaa !29
  %t135 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = load { i64, [2 x i64] }, ptr %l8
  %t138 = load i64, ptr %l6, !tbaa !24
  %t145 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t131, i64 %t133, ptr %t134, i64 %t136, { i64, [2 x i64] } %t137, i64 %t138)
  store i64 %t145, ptr %l94
  br label %bb36
bb36:
  %t146 = load i64, ptr %l94, !tbaa !24
  store i64 %t146, ptr %l10, !tbaa !24
  %t147 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp slt i64 %t147, 0
  br i1 %t149, label %bb37, label %bb38
bb37:
  br label %bb96
bb38:
  br label %bb39
bb39:
  %t151 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t152 = load i64, ptr %t151, !tbaa !24
  %t154 = trunc i64 %t152 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 4, ptr %t157
  %t159 = insertvalue { i32 } undef, i32 %t154, 0
  %t160 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 1
  store { i32 } %t159, ptr %t160
  %t161 = load { i64, [2 x i64] }, ptr %t156
  store { i64, [2 x i64] } %t161, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  store i64 63, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t163 = load i64, ptr %l13, !tbaa !24
  %t164 = load i64, ptr %l12, !tbaa !24
  %t167 = icmp sgt i64 %t163, %t164
  br i1 %t167, label %bb40, label %bb41
bb40:
  %t169 = load i64, ptr %l14, !tbaa !24
  %t171 = icmp sgt i64 %t169, 0
  br i1 %t171, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb45
bb42:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = sub i64 %t173, %t174
  %t178 = load i64, ptr %l14, !tbaa !24
  %t181 = add i64 %t177, %t178
  %t183 = sub i64 %t181, 1
  %t184 = load i64, ptr %l14, !tbaa !24
  %t187 = sdiv i64 %t183, %t184
  store i64 %t187, ptr %l107, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb44
bb44:
  %t189 = load i64, ptr %l107, !tbaa !24
  store i64 %t189, ptr %l104, !tbaa !24
  br label %bb45
bb45:
  %t190 = load i64, ptr %l104, !tbaa !24
  store i64 %t190, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb46
bb46:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t192 = load i64, ptr %l15, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb47, label %bb48
bb47:
  br label %bb55
bb48:
  br label %bb49
bb49:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l14, !tbaa !24
  %t204 = mul i64 %t200, %t201
  %t207 = add i64 %t199, %t204
  store i64 %t207, ptr %l17, !tbaa !24
  %t209 = load i64, ptr %l10, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  store i64 %t210, ptr %l126, !tbaa !24
  %t211 = load i64, ptr %l126, !tbaa !24
  %t212 = load i64, ptr %l126, !tbaa !24
  %t213 = shl i64 1, %t212
  %t216 = and i64 %t209, %t213
  %t218 = icmp ne i64 %t216, 0
  br i1 %t218, label %bb50, label %bb51
bb50:
  %t220 = load ptr, ptr %l5, !tbaa !29
  %t221 = load i32, ptr %l7, !tbaa !23
  %t222 = load i64, ptr %l17, !tbaa !24
  %t223 = load { i64, [2 x i64] }, ptr %l11
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %t220, i32 %t221, i64 %t222, { i64, [2 x i64] } %t223)
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t228 = load i64, ptr %l16, !tbaa !24
  %t230 = add i64 %t228, 1
  store i64 %t230, ptr %l16, !tbaa !24
  br label %bb46
bb55:
  store i64 0, ptr %l18, !tbaa !24
  %t232 = load ptr, ptr %l9, !tbaa !29
  %t234 = getelementptr %"compiler/typed:Call", ptr %t232, i32 0, i32 1
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t239 = load i64, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l18, !tbaa !24
  %t243 = icmp sgt i64 %t239, %t240
  br i1 %t243, label %bb56, label %bb57
bb56:
  %t245 = load i64, ptr %l20, !tbaa !24
  %t247 = icmp sgt i64 %t245, 0
  br i1 %t247, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb61
bb58:
  %t249 = load i64, ptr %l19, !tbaa !24
  %t250 = load i64, ptr %l18, !tbaa !24
  %t253 = sub i64 %t249, %t250
  %t254 = load i64, ptr %l20, !tbaa !24
  %t257 = add i64 %t253, %t254
  %t259 = sub i64 %t257, 1
  %t260 = load i64, ptr %l20, !tbaa !24
  %t263 = sdiv i64 %t259, %t260
  store i64 %t263, ptr %l145, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb60
bb60:
  %t265 = load i64, ptr %l145, !tbaa !24
  store i64 %t265, ptr %l142, !tbaa !24
  br label %bb61
bb61:
  %t266 = load i64, ptr %l142, !tbaa !24
  store i64 %t266, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb62
bb62:
  %t267 = load i64, ptr %l22, !tbaa !24
  %t268 = load i64, ptr %l21, !tbaa !24
  %t271 = icmp slt i64 %t267, %t268
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb63, label %bb64
bb63:
  br label %bb95
bb64:
  br label %bb65
bb65:
  %t275 = load i64, ptr %l18, !tbaa !24
  %t276 = load i64, ptr %l22, !tbaa !24
  %t277 = load i64, ptr %l20, !tbaa !24
  %t280 = mul i64 %t276, %t277
  %t283 = add i64 %t275, %t280
  store i64 %t283, ptr %l23, !tbaa !24
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 2
  %t287 = load i64, ptr %t286, !tbaa !24
  %t288 = load i64, ptr %l23, !tbaa !24
  %t292 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t285, i64 %t287, i64 %t288)
  store i64 %t292, ptr %l166
  br label %bb66
bb66:
  %t293 = load i64, ptr %l166, !tbaa !24
  store i64 %t293, ptr %l24, !tbaa !24
  %t294 = load i64, ptr %l24, !tbaa !24
  %t296 = icmp slt i64 %t294, 0
  br i1 %t296, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb69
bb68:
  %t298 = load i64, ptr %l24, !tbaa !24
  %t300 = icmp sge i64 %t298, 63
  store i1 %t300, ptr %l169, !tbaa !21
  br label %bb69
bb69:
  %t302 = load i1, ptr %l169, !tbaa !21
  br i1 %t302, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l172, !tbaa !21
  br label %bb72
bb71:
  %t303 = load i64, ptr %l10, !tbaa !24
  %t304 = load i64, ptr %l24, !tbaa !24
  store i64 %t304, ptr %l174, !tbaa !24
  %t305 = load i64, ptr %l174, !tbaa !24
  %t306 = load i64, ptr %l174, !tbaa !24
  %t307 = shl i64 1, %t306
  %t310 = and i64 %t303, %t307
  %t312 = icmp eq i64 %t310, 0
  store i1 %t312, ptr %l172, !tbaa !21
  br label %bb72
bb72:
  %t314 = load i1, ptr %l172, !tbaa !21
  br i1 %t314, label %bb73, label %bb74
bb73:
  store i1 true, ptr %l178, !tbaa !21
  br label %bb75
bb74:
  %t315 = load i64, ptr %l24, !tbaa !24
  %t316 = load i64, ptr %l6, !tbaa !24
  %t319 = icmp eq i64 %t315, %t316
  store i1 %t319, ptr %l178, !tbaa !21
  br label %bb75
bb75:
  %t321 = load i1, ptr %l178, !tbaa !21
  br i1 %t321, label %bb76, label %bb77
bb76:
  br label %bb94
bb77:
  br label %bb78
bb78:
  %t322 = load ptr, ptr %l9, !tbaa !29
  %t324 = getelementptr %"compiler/typed:Call", ptr %t322, i32 0, i32 1
  %t325 = load { i64, ptr }, ptr %t324, !tbaa !27
  store { i64, ptr } %t325, ptr %l183, !tbaa !27
  %t326 = load i64, ptr %l23, !tbaa !24
  %t328 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr ptr, ptr %t329, i64 %t326
  %t331 = load ptr, ptr %t330, !tbaa !39
  store ptr %t331, ptr %l25, !tbaa !29
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load ptr, ptr %l25, !tbaa !29
  %t337 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t333, ptr %t334)
  store i64 %t337, ptr %l188
  br label %bb79
bb79:
  %t338 = load i64, ptr %l188, !tbaa !24
  store i64 %t338, ptr %l26, !tbaa !24
  %t339 = load i64, ptr %l26, !tbaa !24
  %t341 = icmp sge i64 %t339, 0
  br i1 %t341, label %bb80, label %bb81
bb80:
  %t343 = load ptr, ptr %l5, !tbaa !29
  %t345 = getelementptr %"compiler/typed:Plan", ptr %t343, i32 0, i32 5
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  store { i64, ptr } %t346, ptr %l193, !tbaa !27
  %t347 = load i64, ptr %l26, !tbaa !24
  %t349 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !27
  %t351 = getelementptr i64, ptr %t350, i64 %t347
  %t352 = load i64, ptr %t351, !tbaa !34
  %t354 = icmp eq i64 %t352, 1
  br i1 %t354, label %bb82, label %bb83
bb81:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb85
bb82:
  store i1 true, ptr %l197, !tbaa !21
  br label %bb84
bb83:
  %t356 = load ptr, ptr %l5, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Plan", ptr %t356, i32 0, i32 5
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  store { i64, ptr } %t359, ptr %l199, !tbaa !27
  %t360 = load i64, ptr %l26, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr i64, ptr %t363, i64 %t360
  %t365 = load i64, ptr %t364, !tbaa !34
  %t367 = icmp eq i64 %t365, 3
  store i1 %t367, ptr %l197, !tbaa !21
  br label %bb84
bb84:
  %t369 = load i1, ptr %l197, !tbaa !21
  store i1 %t369, ptr %l191, !tbaa !21
  br label %bb85
bb85:
  %t370 = load i1, ptr %l191, !tbaa !21
  br i1 %t370, label %bb86, label %bb87
bb86:
  %t371 = load ptr, ptr %l5, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Plan", ptr %t371, i32 0, i32 6
  %t374 = load { i64, ptr }, ptr %t373, !tbaa !27
  store { i64, ptr } %t374, ptr %l204, !tbaa !27
  %t375 = load i64, ptr %l26, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr { i64, [2 x i64] }, ptr %t378, i64 %t375
  %t380 = load { i64, [2 x i64] }, ptr %t379
  store { i64, [2 x i64] } %t380, ptr %l206
  %t381 = load { i64, [2 x i64] }, ptr %l8
  store { i64, [2 x i64] } %t381, ptr %l208
  %t384 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l206, ptr %l208)
  store i1 %t384, ptr %l210
  br label %bb88
bb87:
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/free:feedCall", ptr %l3, i32 0, i32 0
  %t387 = load i64, ptr %t386, !tbaa !24
  %t388 = load ptr, ptr %l25, !tbaa !29
  %t389 = getelementptr %"compiler/free:feed", ptr %l4, i32 0, i32 6
  %t390 = load i64, ptr %t389, !tbaa !24
  %t391 = load { i64, [2 x i64] }, ptr %l8
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t385, i64 %t387, ptr %t388, i64 %t390, { i64, [2 x i64] } %t391, i1 false, i1 false)
  br label %bb92
bb88:
  %t397 = load i1, ptr %l210, !tbaa !21
  br i1 %t397, label %bb89, label %bb90
bb89:
  %t398 = load ptr, ptr %l5, !tbaa !29
  %t400 = getelementptr %"compiler/typed:Plan", ptr %t398, i32 0, i32 6
  %t401 = load { i64, ptr }, ptr %t400, !tbaa !27
  store { i64, ptr } %t401, ptr %l212, !tbaa !27
  %t402 = load i64, ptr %l26, !tbaa !24
  %t403 = load { i64, [2 x i64] }, ptr %l11
  %t406 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !27
  %t408 = getelementptr { i64, [2 x i64] }, ptr %t407, i64 %t402
  store { i64, [2 x i64] } %t403, ptr %t408
  br label %bb91
bb90:
  br label %bb91
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t409 = load i64, ptr %l22, !tbaa !24
  %t411 = add i64 %t409, 1
  store i64 %t411, ptr %l22, !tbaa !24
  br label %bb62
bb95:
  br label %bb96
bb96:
  %t413 = load i64, ptr %l2, !tbaa !24
  %t415 = add i64 %t413, 1
  store i64 %t415, ptr %l2, !tbaa !24
  br label %bb1
bb97:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eassignedFresh(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i1
  %l43 = alloca ptr
  %l47 = alloca ptr
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i64, ptr %l11, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l5, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l15, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr %l7, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l8, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:mustW", ptr %t53, i32 0, i32 4
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l39
  br label %bb12
bb12:
  %t61 = load i64, ptr %l39, !tbaa !24
  %t63 = icmp eq i64 %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l43, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:mustW", ptr %t66, i32 0, i32 5
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l47
  br label %bb15
bb14:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb17
bb15:
  %t75 = add i64 %a2, 1
  %t76 = load ptr, ptr %l43, !tbaa !29
  %t77 = load ptr, ptr %l47, !tbaa !29
  %t79 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t76, ptr %t77, i64 %t75)
  store i1 %t79, ptr %l50
  br label %bb16
bb16:
  %t80 = load i1, ptr %l50, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t83 = load i1, ptr %l42, !tbaa !21
  br i1 %t83, label %bb18, label %bb19
bb18:
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb8
bb22:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2ebinds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Alt", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb8
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:mustW", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Bind", ptr %t29, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t34)
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:mustW", ptr %t37, i32 0, i32 5
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Bind", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t39, ptr %t43)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca i1
  %l63 = alloca i64
  %l66 = alloca i1
  %l70 = alloca ptr
  %l78 = alloca ptr
  %l82 = alloca i64
  %l89 = alloca { i64, ptr }
  %l96 = alloca i64
  %l99 = alloca i1
  %l107 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca i1
  %l114 = alloca ptr
  %l115 = alloca i1
  %l123 = alloca i1
  %l125 = alloca i1
  %l130 = alloca i1
  %l132 = alloca ptr
  %l133 = alloca i1
  %l141 = alloca i1
  %l142 = alloca ptr
  %l150 = alloca i1
  %l161 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l179 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l197 = alloca i1
  %l198 = alloca ptr
  %l199 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i1
  %l211 = alloca { i64, ptr }
  %l215 = alloca i1
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l26
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l26, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t10, 8
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t16 = load ptr, ptr %l30, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load ptr, ptr %l30, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l31, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l31, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l34, !tbaa !29
  store i1 false, ptr %l35, !tbaa !21
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l34, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l35, !tbaa !21
  br label %bb10
bb10:
  %t32 = load i1, ptr %l35, !tbaa !21
  br i1 %t32, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t35 = load ptr, ptr %l39, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb15, label %bb16
bb15:
  %t38 = load ptr, ptr %l39, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 18}
  %t41 = icmp eq i64 %t39, 5
  store i1 %t41, ptr %l40, !tbaa !21
  br label %bb16
bb16:
  %t42 = load i1, ptr %l40, !tbaa !21
  br i1 %t42, label %bb17, label %bb18
bb17:
  br label %bb31
bb18:
  %t43 = load ptr, ptr %l1, !tbaa !29
  store ptr %t43, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t44 = load ptr, ptr %l43, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb19, label %bb20
bb19:
  %t47 = load ptr, ptr %l43, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 18}
  %t50 = icmp eq i64 %t48, 7
  store i1 %t50, ptr %l44, !tbaa !21
  br label %bb20
bb20:
  %t51 = load i1, ptr %l44, !tbaa !21
  br i1 %t51, label %bb21, label %bb22
bb21:
  br label %bb31
bb22:
  %t52 = load ptr, ptr %l1, !tbaa !29
  store ptr %t52, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t53 = load ptr, ptr %l47, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb23, label %bb24
bb23:
  %t56 = load ptr, ptr %l47, !tbaa !29
  %t57 = load i64, ptr %t56, !range !{i64 0, i64 18}
  %t59 = icmp eq i64 %t57, 16
  store i1 %t59, ptr %l48, !tbaa !21
  br label %bb24
bb24:
  %t60 = load i1, ptr %l48, !tbaa !21
  br i1 %t60, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t61 = load ptr, ptr %l1, !tbaa !29
  store ptr %t61, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t62 = load ptr, ptr %l51, !tbaa !29
  %t63 = icmp ne ptr %t62, null
  br i1 %t63, label %bb27, label %bb28
bb27:
  %t65 = load ptr, ptr %l51, !tbaa !29
  %t66 = load i64, ptr %t65, !range !{i64 0, i64 18}
  %t68 = icmp eq i64 %t66, 8
  store i1 %t68, ptr %l52, !tbaa !21
  br label %bb28
bb28:
  %t69 = load i1, ptr %l52, !tbaa !21
  br i1 %t69, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %rv
  br label %ret
bb32:
  %t71 = load ptr, ptr %l1, !tbaa !29
  store ptr %t71, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t72 = load ptr, ptr %l56, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb33, label %bb34
bb33:
  %t75 = load ptr, ptr %l56, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 6
  store i1 %t78, ptr %l57, !tbaa !21
  br label %bb34
bb34:
  %t79 = load i1, ptr %l57, !tbaa !21
  br i1 %t79, label %bb35, label %bb36
bb35:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l5, !tbaa !29
  br label %bb37
bb36:
  br label %bb63
bb37:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t86)
  store i64 %t88, ptr %l63
  br label %bb38
bb38:
  %t89 = load i64, ptr %l63, !tbaa !24
  store i64 %t89, ptr %l6, !tbaa !24
  %t90 = load i64, ptr %l6, !tbaa !24
  %t92 = icmp slt i64 %t90, 0
  br i1 %t92, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb42
bb40:
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/free:Free", ptr %t94, i32 0, i32 1
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t96, i64 %t97)
  store ptr %t100, ptr %l70
  br label %bb41
bb41:
  %t101 = load ptr, ptr %l70, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Body", ptr %t101, i32 0, i32 11
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  store i1 %t106, ptr %l66, !tbaa !21
  br label %bb42
bb42:
  %t108 = load i1, ptr %l66, !tbaa !21
  br i1 %t108, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 1
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l78
  br label %bb46
bb46:
  %t117 = load ptr, ptr %l78, !tbaa !29
  store ptr %t117, ptr %l7, !tbaa !29
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t119 = load ptr, ptr %l7, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Body", ptr %t119, i32 0, i32 2
  %t122 = load i32, ptr %t121, !tbaa !23
  %t125 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t118, i32 %t122)
  store i64 %t125, ptr %l82
  br label %bb47
bb47:
  %t126 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t127 = load i64, ptr %l82, !tbaa !24
  %t129 = icmp eq i64 %t127, %t126
  br i1 %t129, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s4)
  store i1 true, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t132 = load ptr, ptr %l4, !tbaa !29
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Body", ptr %t133, i32 0, i32 2
  %t136 = load i32, ptr %t135, !tbaa !23
  %t139 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s4, ptr %t132, i32 %t136)
  store { i64, ptr } %t139, ptr %l89
  br label %bb51
bb51:
  %t140 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  %t143 = icmp ne i64 %t141, 1
  br i1 %t143, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t146 = load ptr, ptr %l4, !tbaa !29
  %t147 = load ptr, ptr %l7, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %t149, !tbaa !23
  %t153 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t146, i32 %t150, i64 0)
  store i64 %t153, ptr %l96
  br label %bb55
bb55:
  %t154 = load i64, ptr %l96, !tbaa !24
  store i64 %t154, ptr %l8, !tbaa !24
  %t155 = load i64, ptr %l8, !tbaa !24
  %t157 = icmp sge i64 %t155, 0
  br i1 %t157, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb58
bb57:
  %t159 = load i64, ptr %l8, !tbaa !24
  %t160 = load i64, ptr @G_2ecompiler_2ftypes_2eFromTypeVar, !tbaa !24
  %t163 = icmp eq i64 %t159, %t160
  store i1 %t163, ptr %l99, !tbaa !21
  br label %bb58
bb58:
  %t165 = load i1, ptr %l99, !tbaa !21
  br i1 %t165, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s4)
  store i1 false, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = getelementptr %"compiler/free:Free", ptr %t167, i32 0, i32 74
  %t170 = load i64, ptr %l6, !tbaa !24
  %t173 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t169, i64 %t170)
  store i1 %t173, ptr %l107
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s4)
  %t174 = load i1, ptr %l107, !tbaa !21
  store i1 %t174, ptr %rv
  br label %ret
bb63:
  %t175 = load ptr, ptr %l1, !tbaa !29
  store ptr %t175, ptr %l108, !tbaa !29
  store i1 false, ptr %l109, !tbaa !21
  %t176 = load ptr, ptr %l108, !tbaa !29
  %t177 = icmp ne ptr %t176, null
  br i1 %t177, label %bb64, label %bb65
bb64:
  %t179 = load ptr, ptr %l108, !tbaa !29
  %t180 = load i64, ptr %t179, !range !{i64 0, i64 18}
  %t182 = icmp eq i64 %t180, 2
  store i1 %t182, ptr %l109, !tbaa !21
  br label %bb65
bb65:
  %t183 = load i1, ptr %l109, !tbaa !21
  br i1 %t183, label %bb66, label %bb67
bb66:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr { i64, [5 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t186, i32 0, i32 2
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l9, !tbaa !29
  br label %bb68
bb67:
  br label %bb84
bb68:
  %t190 = load ptr, ptr %l9, !tbaa !29
  store ptr %t190, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t191 = load ptr, ptr %l114, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb69, label %bb70
bb69:
  %t194 = load ptr, ptr %l114, !tbaa !29
  %t195 = load i64, ptr %t194, !range !{i64 0, i64 8}
  %t197 = icmp eq i64 %t195, 0
  store i1 %t197, ptr %l115, !tbaa !21
  br label %bb70
bb70:
  %t198 = load i1, ptr %l115, !tbaa !21
  br i1 %t198, label %bb71, label %bb72
bb71:
  %t199 = load ptr, ptr %l9, !tbaa !29
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t201, i32 0, i32 2
  %t203 = load i32, ptr %t202
  store i32 %t203, ptr %l10, !tbaa !23
  br label %bb73
bb72:
  br label %bb79
bb73:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i32, ptr %l10, !tbaa !23
  %t208 = sext i32 %t206 to i64
  %t211 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t205, i64 %t208)
  store i1 %t211, ptr %l123
  br label %bb74
bb74:
  %t212 = load i1, ptr %l123, !tbaa !21
  %t213 = xor i1 %t212, true
  br i1 %t213, label %bb75, label %bb76
bb75:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l10, !tbaa !23
  %t218 = sext i32 %t216 to i64
  %t219 = load i64, ptr %l2, !tbaa !24
  %t223 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eassignedFresh(ptr %v0, ptr %t215, i64 %t218, i64 %t219)
  store i1 %t223, ptr %l130
  br label %bb77
bb76:
  store i1 false, ptr %l125, !tbaa !21
  br label %bb78
bb77:
  %t224 = load i1, ptr %l130, !tbaa !21
  store i1 %t224, ptr %l125, !tbaa !21
  br label %bb78
bb78:
  %t225 = load i1, ptr %l125, !tbaa !21
  store i1 %t225, ptr %rv
  br label %ret
bb79:
  br i1 true, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  store i1 false, ptr %rv
  br label %ret
bb83:
  call void @__olang_check_failed(ptr @olang_loc_7a954698926d7de_664d4c02e090fa22)
  unreachable
bb84:
  %t227 = load ptr, ptr %l1, !tbaa !29
  store ptr %t227, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t228 = load ptr, ptr %l132, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb85, label %bb86
bb85:
  %t231 = load ptr, ptr %l132, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 18}
  %t234 = icmp eq i64 %t232, 14
  store i1 %t234, ptr %l133, !tbaa !21
  br label %bb86
bb86:
  %t235 = load i1, ptr %l133, !tbaa !21
  br i1 %t235, label %bb87, label %bb88
bb87:
  %t236 = load ptr, ptr %l1, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t238, i32 0, i32 2
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l11, !tbaa !29
  br label %bb89
bb88:
  br label %bb116
bb89:
  %t242 = load ptr, ptr %l11, !tbaa !29
  %t244 = getelementptr %"compiler/typed:Try", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = icmp eq ptr %t245, null
  br i1 %t247, label %bb90, label %bb91
bb90:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb96
bb91:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l142, !tbaa !29
  %t250 = load ptr, ptr %l11, !tbaa !29
  %t252 = getelementptr %"compiler/typed:Try", ptr %t250, i32 0, i32 0
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = icmp eq ptr %t253, null
  br i1 %t255, label %bb92, label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_893474d063c17328_1c44af56cc3f848c)
  unreachable
bb93:
  br label %bb94
bb94:
  %t257 = load ptr, ptr %l11, !tbaa !29
  %t259 = getelementptr %"compiler/typed:Try", ptr %t257, i32 0, i32 0
  %t260 = load ptr, ptr %t259, !tbaa !29
  %t261 = load i64, ptr %l2, !tbaa !24
  %t263 = add i64 %t261, 1
  %t264 = load ptr, ptr %l142, !tbaa !29
  %t267 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t264, ptr %t260, i64 %t263)
  store i1 %t267, ptr %l150
  br label %bb95
bb95:
  %t268 = load i1, ptr %l150, !tbaa !21
  %t269 = xor i1 %t268, true
  store i1 %t269, ptr %l141, !tbaa !21
  br label %bb96
bb96:
  %t271 = load i1, ptr %l141, !tbaa !21
  br i1 %t271, label %bb97, label %bb98
bb97:
  store i1 false, ptr %rv
  br label %ret
bb98:
  br label %bb99
bb99:
  %t273 = load ptr, ptr %l11, !tbaa !29
  %t275 = getelementptr %"compiler/typed:Try", ptr %t273, i32 0, i32 1
  %t276 = load { i64, ptr }, ptr %t275, !tbaa !27
  store { i64, ptr } %t276, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t278 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t278, 0
  store i64 %t280, ptr %l14, !tbaa !24
  br label %bb100
bb100:
  %t282 = load i64, ptr %l13, !tbaa !24
  %t283 = load i64, ptr %l14, !tbaa !24
  %t286 = icmp slt i64 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb101, label %bb102
bb101:
  br label %bb115
bb102:
  br label %bb103
bb103:
  %t290 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t290, ptr %l161, !tbaa !27
  %t291 = load i64, ptr %l13, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr ptr, ptr %t294, i64 %t291
  %t296 = load ptr, ptr %t295, !tbaa !39
  %t300 = getelementptr %"compiler/typed:Clause", ptr %t296, i32 0, i32 4
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  store { i64, ptr } %t301, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t303 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 0
  store i64 %t305, ptr %l18, !tbaa !24
  br label %bb104
bb104:
  %t307 = load i64, ptr %l17, !tbaa !24
  %t308 = load i64, ptr %l18, !tbaa !24
  %t311 = icmp slt i64 %t307, %t308
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb105, label %bb106
bb105:
  br label %bb113
bb106:
  br label %bb107
bb107:
  %t315 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t315, ptr %l172, !tbaa !27
  %t316 = load i64, ptr %l17, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr ptr, ptr %t319, i64 %t316
  %t321 = load ptr, ptr %t320, !tbaa !39
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = load i64, ptr %l2, !tbaa !24
  %t327 = add i64 %t325, 1
  %t331 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t323, ptr %t321, i64 %t327)
  store i1 %t331, ptr %l179
  br label %bb108
bb108:
  %t332 = load i1, ptr %l179, !tbaa !21
  %t333 = xor i1 %t332, true
  br i1 %t333, label %bb109, label %bb110
bb109:
  store i1 false, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t336 = load i64, ptr %l17, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l17, !tbaa !24
  br label %bb104
bb113:
  br label %bb114
bb114:
  %t340 = load i64, ptr %l13, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l13, !tbaa !24
  br label %bb100
bb115:
  store i1 true, ptr %rv
  br label %ret
bb116:
  %t345 = load ptr, ptr %l1, !tbaa !29
  store ptr %t345, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t346 = load ptr, ptr %l187, !tbaa !29
  %t347 = icmp ne ptr %t346, null
  br i1 %t347, label %bb117, label %bb118
bb117:
  %t349 = load ptr, ptr %l187, !tbaa !29
  %t350 = load i64, ptr %t349, !range !{i64 0, i64 18}
  %t352 = icmp eq i64 %t350, 17
  store i1 %t352, ptr %l188, !tbaa !21
  br label %bb118
bb118:
  %t353 = load i1, ptr %l188, !tbaa !21
  br i1 %t353, label %bb119, label %bb120
bb119:
  %t354 = load ptr, ptr %l1, !tbaa !29
  %t356 = getelementptr { i64, [5 x i64] }, ptr %t354, i32 0, i32 1
  %t357 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t356, i32 0, i32 2
  %t358 = load ptr, ptr %t357
  store ptr %t358, ptr %l20, !tbaa !29
  br label %bb121
bb120:
  br label %bb123
bb121:
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t361 = load ptr, ptr %l20, !tbaa !29
  %t362 = load i64, ptr %l2, !tbaa !24
  %t364 = add i64 %t362, 1
  %t368 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t360, ptr %t361, i64 %t364)
  store i1 %t368, ptr %l197
  br label %bb122
bb122:
  %t369 = load i1, ptr %l197, !tbaa !21
  store i1 %t369, ptr %rv
  br label %ret
bb123:
  %t370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t370, ptr %l198, !tbaa !29
  store i1 false, ptr %l199, !tbaa !21
  %t371 = load ptr, ptr %l198, !tbaa !29
  %t372 = icmp ne ptr %t371, null
  br i1 %t372, label %bb124, label %bb125
bb124:
  %t374 = load ptr, ptr %l198, !tbaa !29
  %t375 = load i64, ptr %t374, !range !{i64 0, i64 18}
  %t377 = icmp eq i64 %t375, 9
  store i1 %t377, ptr %l199, !tbaa !21
  br label %bb125
bb125:
  %t378 = load i1, ptr %l199, !tbaa !21
  br i1 %t378, label %bb126, label %bb127
bb126:
  %t379 = load ptr, ptr %l1, !tbaa !29
  %t381 = getelementptr { i64, [5 x i64] }, ptr %t379, i32 0, i32 1
  %t382 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t381, i32 0, i32 2
  %t383 = load i32, ptr %t382, !range !{i32 0, i32 52}
  store i32 %t383, ptr %l21
  %t385 = load ptr, ptr %l1, !tbaa !29
  %t387 = getelementptr { i64, [5 x i64] }, ptr %t385, i32 0, i32 1
  %t388 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t387, i32 0, i32 4
  %t389 = load { i64, ptr }, ptr %t388
  store { i64, ptr } %t389, ptr %l22, !tbaa !27
  br label %bb128
bb127:
  br label %bb134
bb128:
  %t391 = load i32, ptr %l21, !range !{i32 0, i32 52}
  %t392 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t395 = call i1 @compiler_2ffree_2eisConversion(ptr %v1, i32 %t391, { i64, ptr } %t392)
  store i1 %t395, ptr %l208
  br label %bb129
bb129:
  %t396 = load i1, ptr %l208, !tbaa !21
  br i1 %t396, label %bb130, label %bb131
bb130:
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t398, ptr %l211, !tbaa !27
  %t399 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr ptr, ptr %t400, i64 0
  %t402 = load ptr, ptr %t401, !tbaa !39
  %t403 = load i64, ptr %l2, !tbaa !24
  %t405 = add i64 %t403, 1
  %t409 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %t397, ptr %t402, i64 %t405)
  store i1 %t409, ptr %l215
  br label %bb132
bb131:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb133
bb132:
  %t410 = load i1, ptr %l215, !tbaa !21
  store i1 %t410, ptr %l209, !tbaa !21
  br label %bb133
bb133:
  %t411 = load i1, ptr %l209, !tbaa !21
  store i1 %t411, ptr %rv
  br label %ret
bb134:
  br i1 true, label %bb135, label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb138
bb137:
  store i1 false, ptr %rv
  br label %ret
bb138:
  call void @__olang_check_failed(ptr @olang_loc_a532406d51285a24_27441d0f137c6648)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2etryMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l15 = alloca ptr
  %l21 = alloca i64
  %l30 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l15, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/typed:Try", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1777536395e8cd8b_97ff53b4c3030f1f)
  unreachable
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Try", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t22, ptr %t21)
  store i64 %t24, ptr %l21
  br label %bb7
bb7:
  %t25 = load i64, ptr %l21, !tbaa !24
  store i64 %t25, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load i64, ptr %l4, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t53 = getelementptr %"compiler/typed:Clause", ptr %t49, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l9, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb13, label %bb14
bb13:
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t68, ptr %l41, !tbaa !27
  %t69 = load i64, ptr %l8, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t76 = load i64, ptr %l2, !tbaa !24
  store i64 %t76, ptr %l44, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t77, ptr %t74)
  store i64 %t81, ptr %l47
  br label %bb16
bb16:
  %t82 = load i64, ptr %l44, !tbaa !24
  %t83 = load i64, ptr %l47, !tbaa !24
  %t84 = call i64 @compiler_2ffree_2emeet(i64 %t82, i64 %t83)
  store i64 %t84, ptr %l48
  br label %bb17
bb17:
  %t85 = load i64, ptr %l48, !tbaa !24
  store i64 %t85, ptr %l2, !tbaa !24
  br label %bb18
bb18:
  %t86 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb12
bb19:
  br label %bb20
bb20:
  %t90 = load i64, ptr %l4, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l4, !tbaa !24
  br label %bb8
bb21:
  %t94 = load i64, ptr %l2, !tbaa !24
  store i64 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:walker", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t7, i32 0, i32 1
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t6, i64 %t10)
  store ptr %t13, ptr %l6
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l6, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp4 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t4, ptr %t7)
  store i64 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t14 = icmp sge i64 %t11, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t18)
  store i32 %t20, ptr %l15
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t21, ptr %t22, i32 %t23)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l16
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l19
  br label %bb7
bb7:
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t31, ptr %lp4
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t33 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t33
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %lp4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t34, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %lp4
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca ptr
  %l38 = alloca i64
  %l40 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca i64
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca ptr
  %l82 = alloca i1
  %l92 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca i1
  %l103 = alloca i1
  %l106 = alloca i1
  %l126 = alloca ptr
  %l129 = alloca i64
  %l133 = alloca i1
  %l135 = alloca i1
  %l139 = alloca i1
  %l140 = alloca i1
  %l146 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca i1
  %l158 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l165 = alloca ptr
  %l166 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca i1
  %l179 = alloca ptr
  %l180 = alloca i1
  %l188 = alloca ptr
  %l192 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l197 = alloca i1
  %l199 = alloca i1
  %l201 = alloca i1
  %l203 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca i64
  %l213 = alloca i64
  %l232 = alloca { i64, ptr }
  %l237 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l240 = alloca i1
  %l243 = alloca i1
  %l247 = alloca i64
  %l250 = alloca i64
  %l251 = alloca ptr
  %l253 = alloca i32
  %l254 = alloca i1
  %l257 = alloca i1
  %l260 = alloca i1
  %l266 = alloca ptr
  %l276 = alloca %"compiler/free:feedCall"
  %l278 = alloca ptr
  %l279 = alloca ptr
  %l282 = alloca i64
  %l287 = alloca %"compiler/free:feed"
  %l290 = alloca ptr
  %l291 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l293 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l298 = alloca i1
  %l299 = alloca i1
  %l303 = alloca ptr
  %l308 = alloca i64
  %l309 = alloca i64
  %l312 = alloca i1
  %l315 = alloca i1
  %l318 = alloca i64
  %l320 = alloca i1
  %l326 = alloca i1
  %l328 = alloca i1
  %l332 = alloca ptr
  %l338 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l341 = alloca i1
  %l343 = alloca i1
  %l346 = alloca i64
  %l348 = alloca i1
  %l351 = alloca i1
  %l363 = alloca i1
  %l368 = alloca i1
  %l370 = alloca i64
  %l372 = alloca i64
  %l377 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l379 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l382 = alloca i64
  %l388 = alloca i1
  %l391 = alloca i1
  %l396 = alloca i64
  %l400 = alloca i64
  %l403 = alloca i64
  %l422 = alloca ptr
  %l424 = alloca ptr
  %l426 = alloca { i64, ptr }
  %l429 = alloca i32
  %l430 = alloca i64
  %l433 = alloca i1
  %l434 = alloca ptr
  %l437 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l439 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l441 = alloca i1
  %l454 = alloca ptr
  %l455 = alloca i64
  %l459 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l461 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l463 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l470 = alloca ptr
  %l471 = alloca i64
  %l472 = alloca ptr
  %l473 = alloca i64
  %l476 = alloca i64
  %l479 = alloca ptr
  %l480 = alloca i64
  %l484 = alloca i64
  %l492 = alloca ptr
  %l496 = alloca ptr
  %l499 = alloca i64
  %l505 = alloca ptr
  %l506 = alloca i64
  %l507 = alloca ptr
  %l508 = alloca i64
  %l511 = alloca i64
  %l514 = alloca ptr
  %l515 = alloca i64
  %l519 = alloca i64
  %l526 = alloca i64
  %l528 = alloca i64
  %l530 = alloca i1
  %l535 = alloca i1
  %l540 = alloca i1
  %l541 = alloca ptr
  %l542 = alloca i64
  %l544 = alloca { i64, ptr }
  %l546 = alloca ptr
  %l549 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l551 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l561 = alloca ptr
  %l562 = alloca i64
  %l563 = alloca ptr
  %l564 = alloca i64
  %l567 = alloca i64
  %l570 = alloca ptr
  %l571 = alloca i64
  %l575 = alloca i64
  %l576 = alloca i64
  %l578 = alloca i64
  %l580 = alloca ptr
  %l582 = alloca { i64, ptr }
  %l584 = alloca ptr
  %l587 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l589 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l597 = alloca ptr
  %l598 = alloca i64
  %l599 = alloca ptr
  %l600 = alloca i64
  %l603 = alloca i64
  %l606 = alloca ptr
  %l607 = alloca i64
  %l611 = alloca i64
  %l612 = alloca i64
  %l614 = alloca i64
  %l616 = alloca ptr
  %l619 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l621 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l629 = alloca ptr
  %l630 = alloca i64
  %l631 = alloca ptr
  %l632 = alloca i64
  %l635 = alloca i64
  %l638 = alloca ptr
  %l639 = alloca i64
  %l643 = alloca i64
  %l644 = alloca i64
  %l646 = alloca i64
  %l648 = alloca ptr
  %l649 = alloca ptr
  %l652 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l654 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l656 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l664 = alloca i1
  %l672 = alloca ptr
  %l673 = alloca i64
  %l674 = alloca ptr
  %l675 = alloca i64
  %l678 = alloca i64
  %l681 = alloca ptr
  %l682 = alloca i64
  %l686 = alloca i64
  %l687 = alloca ptr
  %l688 = alloca i64
  %l689 = alloca i64
  %l690 = alloca %"compiler/source:Span"
  %l692 = alloca %"compiler/source:Span"
  %l703 = alloca i1
  %l710 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l712 = alloca i64
  %l714 = alloca i64
  %l719 = alloca i64
  %l721 = alloca i64
  %l733 = alloca ptr
  %l734 = alloca i1
  %l747 = alloca i64
  %l749 = alloca i64
  %l754 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l756 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l759 = alloca i64
  %l767 = alloca ptr
  %l769 = alloca i64
  %l770 = alloca i64
  %l780 = alloca { i64, ptr }
  %l784 = alloca ptr
  %l786 = alloca ptr
  %l788 = alloca i32
  %l789 = alloca i32
  %l790 = alloca i32
  %l801 = alloca i64
  %l803 = alloca i64
  %l808 = alloca i64
  %l817 = alloca ptr
  %l820 = alloca i64
  %l824 = alloca ptr
  %l825 = alloca i64
  %l827 = alloca i1
  %l831 = alloca i1
  %l832 = alloca i1
  %l836 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s43 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s62 = alloca %olang.scope
  %s63 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l78
  br label %bb1
bb1:
  %t7 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t7, ptr %lp5
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  %t9 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  store i64 -1, ptr %l6, !tbaa !24
  store i1 true, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  store i1 false, ptr %l9, !tbaa !21
  store i1 false, ptr %l10, !tbaa !21
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Call", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l11, !tbaa !29
  store ptr %t15, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t16 = load ptr, ptr %l81, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l81, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 5}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l82, !tbaa !21
  br label %bb3
bb3:
  %t23 = load i1, ptr %l82, !tbaa !21
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t24 = load ptr, ptr %l11, !tbaa !29
  %t26 = getelementptr { i64, [3 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { i32 }, ptr %t26, i32 0, i32 0
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l12, !tbaa !23
  br label %bb6
bb5:
  br label %bb44
bb6:
  %t30 = load i32, ptr %l12, !tbaa !23
  %t32 = sext i32 %t30 to i64
  store i64 %t32, ptr %l6, !tbaa !24
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t36, i64 %t37)
  store ptr %t40, ptr %l92
  br label %bb7
bb7:
  %t41 = load ptr, ptr %l92, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 11
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = icmp eq ptr %t44, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l4, !tbaa !29
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t52, ptr %l99
  br label %bb10
bb9:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb11
bb10:
  %t53 = load i1, ptr %l99, !tbaa !21
  %t54 = xor i1 %t53, true
  store i1 %t54, ptr %l96, !tbaa !21
  br label %bb11
bb11:
  %t56 = load i1, ptr %l96, !tbaa !21
  store i1 %t56, ptr %l7, !tbaa !21
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 2
  %t60 = load i1, ptr %t59, !tbaa !21
  br i1 %t60, label %bb12, label %bb13
bb12:
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/free:Free", ptr %t62, i32 0, i32 27
  %t65 = load i1, ptr %t64, !tbaa !21
  store i1 %t65, ptr %l103, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb14
bb14:
  %t67 = load i1, ptr %l103, !tbaa !21
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 30
  %t71 = load i64, ptr %t70, !tbaa !24
  %t73 = icmp eq i64 %t71, 0
  store i1 %t73, ptr %l106, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb17
bb17:
  %t75 = load i1, ptr %l106, !tbaa !21
  br i1 %t75, label %bb18, label %bb19
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 56
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 12
  %t82 = load i64, ptr %t81, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t78, i64 %t82)
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 57
  %t88 = load %"compiler/source:Span", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t87, %"compiler/source:Span" %t88)
  br label %bb21
bb21:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/free:walker", ptr %t91, i32 0, i32 58
  %t94 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t93, i64 %t94)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/free:walker", ptr %t97, i32 0, i32 2
  %t100 = load i1, ptr %t99, !tbaa !21
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb24, label %bb25
bb24:
  %t104 = load ptr, ptr %l4, !tbaa !29
  %t106 = getelementptr %"compiler/free:Free", ptr %t104, i32 0, i32 97
  %t107 = load i64, ptr %l6, !tbaa !24
  %t110 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t106, i64 %t107)
  store ptr %t110, ptr %l126
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t111, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load ptr, ptr %l126, !tbaa !29
  %t117 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t115, i64 %t114)
  store i64 %t117, ptr %l129
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/free:walker", ptr %t118, i32 0, i32 2
  %t121 = load i1, ptr %t120, !tbaa !21
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb29, label %bb30
bb29:
  %t125 = load i1, ptr %l7, !tbaa !21
  br i1 %t125, label %bb31, label %bb32
bb30:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb35
bb31:
  store i1 true, ptr %l135, !tbaa !21
  br label %bb34
bb32:
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t129 = getelementptr %"compiler/free:Free", ptr %t127, i32 0, i32 75
  %t130 = load i64, ptr %l6, !tbaa !24
  %t133 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t129, i64 %t130)
  store i1 %t133, ptr %l139
  br label %bb33
bb33:
  %t134 = load i1, ptr %l139, !tbaa !21
  store i1 %t134, ptr %l135, !tbaa !21
  br label %bb34
bb34:
  %t135 = load i1, ptr %l135, !tbaa !21
  store i1 %t135, ptr %l133, !tbaa !21
  br label %bb35
bb35:
  %t136 = load i1, ptr %l133, !tbaa !21
  br i1 %t136, label %bb36, label %bb37
bb36:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:walker", ptr %t138, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t143 = load i64, ptr %l6, !tbaa !24
  %t148 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epassesVar(ptr %v0, ptr %v1, ptr %t137, i64 %t141, ptr %t142, i64 %t143)
  store i1 %t148, ptr %l146
  br label %bb38
bb37:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb39
bb38:
  %t149 = load i1, ptr %l146, !tbaa !21
  store i1 %t149, ptr %l140, !tbaa !21
  br label %bb39
bb39:
  %t150 = load i1, ptr %l140, !tbaa !21
  br i1 %t150, label %bb40, label %bb41
bb40:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/free:walker", ptr %t152, i32 0, i32 1
  %t155 = load i64, ptr %t154, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t151, i64 %t155)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb89
bb44:
  %t158 = load ptr, ptr %l11, !tbaa !29
  store ptr %t158, ptr %l150, !tbaa !29
  store i1 false, ptr %l151, !tbaa !21
  %t159 = load ptr, ptr %l150, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb45, label %bb46
bb45:
  %t162 = load ptr, ptr %l150, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 5}
  %t165 = icmp eq i64 %t163, 2
  store i1 %t165, ptr %l151, !tbaa !21
  br label %bb46
bb46:
  %t166 = load i1, ptr %l151, !tbaa !21
  br i1 %t166, label %bb47, label %bb48
bb47:
  %t167 = load ptr, ptr %l11, !tbaa !29
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { ptr }, ptr %t169, i32 0, i32 0
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l13, !tbaa !29
  br label %bb49
bb48:
  br label %bb55
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load ptr, ptr %l13, !tbaa !29
  %t177 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s5, ptr %t173, ptr %t174)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %l158
  br label %bb50
bb50:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:walker", ptr %t178, i32 0, i32 2
  %t181 = load i1, ptr %t180, !tbaa !21
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb51, label %bb52
bb51:
  %t185 = load ptr, ptr %l4, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/free:walker", ptr %t186, i32 0, i32 1
  %t189 = load i64, ptr %t188, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t185, i64 %t189)
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  br label %bb89
bb55:
  %t192 = load ptr, ptr %l11, !tbaa !29
  store ptr %t192, ptr %l165, !tbaa !29
  store i1 false, ptr %l166, !tbaa !21
  %t193 = load ptr, ptr %l165, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb56, label %bb57
bb56:
  %t196 = load ptr, ptr %l165, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 5}
  %t199 = icmp eq i64 %t197, 3
  store i1 %t199, ptr %l166, !tbaa !21
  br label %bb57
bb57:
  %t200 = load i1, ptr %l166, !tbaa !21
  br i1 %t200, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb65
bb60:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/free:walker", ptr %t201, i32 0, i32 2
  %t204 = load i1, ptr %t203, !tbaa !21
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb61, label %bb62
bb61:
  %t208 = load ptr, ptr %l4, !tbaa !29
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 1
  %t212 = load i64, ptr %t211, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t208, i64 %t212)
  br label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb64
bb64:
  br label %bb89
bb65:
  %t215 = load ptr, ptr %l11, !tbaa !29
  store ptr %t215, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t216 = load ptr, ptr %l175, !tbaa !29
  %t217 = icmp ne ptr %t216, null
  br i1 %t217, label %bb66, label %bb67
bb66:
  %t219 = load ptr, ptr %l175, !tbaa !29
  %t220 = load i64, ptr %t219, !range !{i64 0, i64 5}
  %t222 = icmp eq i64 %t220, 4
  store i1 %t222, ptr %l176, !tbaa !21
  br label %bb67
bb67:
  %t223 = load i1, ptr %l176, !tbaa !21
  br i1 %t223, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb89
bb71:
  %t224 = load ptr, ptr %l11, !tbaa !29
  store ptr %t224, ptr %l179, !tbaa !29
  store i1 false, ptr %l180, !tbaa !21
  %t225 = load ptr, ptr %l179, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb72, label %bb73
bb72:
  %t228 = load ptr, ptr %l179, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 5}
  %t231 = icmp eq i64 %t229, 1
  store i1 %t231, ptr %l180, !tbaa !21
  br label %bb73
bb73:
  %t232 = load i1, ptr %l180, !tbaa !21
  br i1 %t232, label %bb74, label %bb75
bb74:
  %t233 = load ptr, ptr %l11, !tbaa !29
  %t235 = getelementptr { i64, [3 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { i64 }, ptr %t235, i32 0, i32 0
  %t237 = load i64, ptr %t236
  store i64 %t237, ptr %l14, !tbaa !24
  br label %bb76
bb75:
  br label %bb84
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  store i1 true, ptr %l9, !tbaa !21
  %t239 = load ptr, ptr %l4, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 0
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/load:Loader", ptr %t245, i32 0, i32 3
  %t248 = load ptr, ptr %t247, !tbaa !29
  store ptr %t248, ptr %l188, !tbaa !29
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = getelementptr %"compiler/free:Free", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t253 = load i64, ptr %l14, !tbaa !24
  %t256 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s10, ptr %t252, i64 %t253)
  store ptr %t256, ptr %l192
  br label %bb77
bb77:
  %t257 = load ptr, ptr %l192, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Func", ptr %t257, i32 0, i32 2
  %t260 = load i32, ptr %t259, !tbaa !23
  %t261 = load ptr, ptr %l188, !tbaa !29
  %t263 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t261, i32 %t260)
  store { i64, ptr } %t263, ptr %l195
  br label %bb78
bb78:
  %t264 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t264, ptr %l15, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t267 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s10, { i64, ptr } %t265, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t267, ptr %l197
  br label %bb79
bb79:
  %t268 = load i1, ptr %l197, !tbaa !21
  %t269 = xor i1 %t268, true
  br i1 %t269, label %bb80, label %bb81
bb80:
  %t271 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t273 = call i1 @compiler_2ftyped_2eNoCallbackExtern(ptr %v0, { i64, ptr } %t271)
  store i1 %t273, ptr %l201
  br label %bb82
bb81:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb83
bb82:
  %t274 = load i1, ptr %l201, !tbaa !21
  %t275 = xor i1 %t274, true
  store i1 %t275, ptr %l199, !tbaa !21
  br label %bb83
bb83:
  %t277 = load i1, ptr %l199, !tbaa !21
  store i1 %t277, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  br label %bb89
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_ec84fe6443685676_e22a9bc60a48a0b2)
  unreachable
bb89:
  %t278 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %l203
  br label %bb90
bb90:
  %t279 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l203
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t279, ptr %l16
  store i64 0, ptr %l17, !tbaa !24
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t282 = getelementptr %"compiler/typed:Call", ptr %t280, i32 0, i32 1
  %t283 = load { i64, ptr }, ptr %t282, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  store i64 %t285, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t287 = load i64, ptr %l18, !tbaa !24
  %t288 = load i64, ptr %l17, !tbaa !24
  %t291 = icmp sgt i64 %t287, %t288
  br i1 %t291, label %bb91, label %bb92
bb91:
  %t293 = load i64, ptr %l19, !tbaa !24
  %t295 = icmp sgt i64 %t293, 0
  br i1 %t295, label %bb93, label %bb94
bb92:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb96
bb93:
  %t297 = load i64, ptr %l18, !tbaa !24
  %t298 = load i64, ptr %l17, !tbaa !24
  %t301 = sub i64 %t297, %t298
  %t302 = load i64, ptr %l19, !tbaa !24
  %t305 = add i64 %t301, %t302
  %t307 = sub i64 %t305, 1
  %t308 = load i64, ptr %l19, !tbaa !24
  %t311 = sdiv i64 %t307, %t308
  store i64 %t311, ptr %l213, !tbaa !24
  br label %bb95
bb94:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb95
bb95:
  %t313 = load i64, ptr %l213, !tbaa !24
  store i64 %t313, ptr %l210, !tbaa !24
  br label %bb96
bb96:
  %t314 = load i64, ptr %l210, !tbaa !24
  store i64 %t314, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s13
  %t315 = load i64, ptr %l21, !tbaa !24
  %t316 = load i64, ptr %l20, !tbaa !24
  %t319 = icmp slt i64 %t315, %t316
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb98, label %bb99
bb98:
  call void @__olang_scope_close(ptr %s13)
  br label %bb136
bb99:
  br label %bb100
bb100:
  %t323 = load i64, ptr %l17, !tbaa !24
  %t324 = load i64, ptr %l21, !tbaa !24
  %t325 = load i64, ptr %l19, !tbaa !24
  %t328 = mul i64 %t324, %t325
  %t331 = add i64 %t323, %t328
  store i64 %t331, ptr %l22, !tbaa !24
  %t333 = load ptr, ptr %l1, !tbaa !29
  %t335 = getelementptr %"compiler/typed:Call", ptr %t333, i32 0, i32 1
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !27
  store { i64, ptr } %t336, ptr %l232, !tbaa !27
  %t337 = load i64, ptr %l22, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr ptr, ptr %t340, i64 %t337
  %t342 = load ptr, ptr %t341, !tbaa !39
  store ptr %t342, ptr %l23, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load ptr, ptr %l23, !tbaa !29
  %t348 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s13, ptr %t344, ptr %t345)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t348, ptr %l237
  br label %bb101
bb101:
  %t349 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l237
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t349, ptr %l24
  %t350 = load i64, ptr %l6, !tbaa !24
  %t352 = icmp sge i64 %t350, 0
  br i1 %t352, label %bb102, label %bb103
bb102:
  %t354 = load i1, ptr %l7, !tbaa !21
  %t356 = xor i1 %t354, true
  store i1 %t356, ptr %l240, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l240, !tbaa !21
  br label %bb104
bb104:
  %t358 = load i1, ptr %l240, !tbaa !21
  br i1 %t358, label %bb105, label %bb106
bb105:
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t361 = getelementptr %"compiler/typed:Call", ptr %t359, i32 0, i32 2
  %t362 = load i32, ptr %t361, !tbaa !23
  %t364 = icmp sge i32 %t362, 0
  store i1 %t364, ptr %l243, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb107
bb107:
  %t366 = load i1, ptr %l243, !tbaa !21
  br i1 %t366, label %bb108, label %bb109
bb108:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l23, !tbaa !29
  %t371 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeederArg(ptr %v0, ptr %v1, ptr %t367, ptr %t368)
  store i64 %t371, ptr %l250
  br label %bb110
bb109:
  store i64 -1, ptr %l247, !tbaa !24
  br label %bb111
bb110:
  %t372 = load i64, ptr %l250, !tbaa !24
  store i64 %t372, ptr %l247, !tbaa !24
  br label %bb111
bb111:
  %t373 = load i64, ptr %l247, !tbaa !24
  store i64 %t373, ptr %l25, !tbaa !24
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l251, !tbaa !29
  %t375 = load ptr, ptr %l23, !tbaa !29
  %t377 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t375)
  store i32 %t377, ptr %l253
  br label %bb112
bb112:
  %t378 = load ptr, ptr %l251, !tbaa !29
  %t379 = load i32, ptr %l253, !tbaa !23
  %t380 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewritable(ptr %v0, ptr %t378, i32 %t379)
  store i1 %t380, ptr %l254
  br label %bb113
bb113:
  %t381 = load i1, ptr %l254, !tbaa !21
  store i1 %t381, ptr %l26, !tbaa !21
  %t382 = load i64, ptr %l25, !tbaa !24
  %t384 = icmp sge i64 %t382, 0
  br i1 %t384, label %bb114, label %bb115
bb114:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/free:walker", ptr %t386, i32 0, i32 2
  %t389 = load i1, ptr %t388, !tbaa !21
  store i1 %t389, ptr %l257, !tbaa !21
  br label %bb116
bb115:
  store i1 false, ptr %l257, !tbaa !21
  br label %bb116
bb116:
  %t391 = load i1, ptr %l257, !tbaa !21
  br i1 %t391, label %bb117, label %bb118
bb117:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/free:walker", ptr %t392, i32 0, i32 30
  %t395 = load i64, ptr %t394, !tbaa !24
  %t397 = icmp eq i64 %t395, 0
  store i1 %t397, ptr %l260, !tbaa !21
  br label %bb119
bb118:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb119
bb119:
  %t399 = load i1, ptr %l260, !tbaa !21
  br i1 %t399, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s14
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/free:walker", ptr %t400, i32 0, i32 0
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t405 = getelementptr %"compiler/free:Free", ptr %t403, i32 0, i32 112
  store ptr %t405, ptr %l266, !tbaa !29
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr %"compiler/free:walker", ptr %t406, i32 0, i32 1
  %t409 = load i64, ptr %t408, !tbaa !24
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr %"compiler/typed:Call", ptr %t410, i32 0, i32 2
  %t413 = load i32, ptr %t412, !tbaa !23
  %t415 = sext i32 %t413 to i64
  %t416 = load i64, ptr %l6, !tbaa !24
  %t417 = load i64, ptr %l22, !tbaa !24
  %t418 = load i64, ptr %l25, !tbaa !24
  %t419 = load i1, ptr %l26, !tbaa !21
  %t426 = call %"compiler/free:feedCall" @compiler_2ffree_3afeedCall_2ector(ptr %s14, i64 %t409, i64 %t415, i64 %t416, i64 %t417, i64 %t418, i1 %t419)
  store %"compiler/free:feedCall" %t426, ptr %l276
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t427 = load ptr, ptr %l266, !tbaa !29
  %t428 = load %"compiler/free:feedCall", ptr %l276
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2ePush_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t427, %"compiler/free:feedCall" %t428)
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s14)
  br label %bb124
bb124:
  %t429 = load i1, ptr %l26, !tbaa !21
  br i1 %t429, label %bb125, label %bb126
bb125:
  store %olang.scope zeroinitializer, ptr %s15
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l278, !tbaa !29
  store ptr %l24, ptr %l279, !tbaa !29
  %t432 = load i64, ptr %l25, !tbaa !24
  %t434 = icmp sge i64 %t432, 0
  br i1 %t434, label %bb127, label %bb128
bb126:
  br label %bb132
bb127:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/free:walker", ptr %t436, i32 0, i32 0
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t441 = getelementptr %"compiler/free:Free", ptr %t439, i32 0, i32 110
  %t442 = load i64, ptr %l25, !tbaa !24
  %t445 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t441, i64 %t442)
  store %"compiler/free:feed" %t445, ptr %l287
  br label %bb129
bb128:
  store i64 -1, ptr %l282, !tbaa !24
  br label %bb130
bb129:
  %t446 = getelementptr %"compiler/free:feed", ptr %l287, i32 0, i32 2
  %t447 = load i64, ptr %t446, !tbaa !24
  store i64 %t447, ptr %l282, !tbaa !24
  br label %bb130
bb130:
  %t449 = load %"compiler/source:Span", ptr %l3
  %t450 = load ptr, ptr %l278, !tbaa !29
  %t451 = load ptr, ptr %l279, !tbaa !29
  %t452 = load i64, ptr %l282, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %s13, ptr %s15, ptr %t450, ptr %t451, i64 %t452, %"compiler/source:Span" %t449, { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s15)
  br label %bb132
bb132:
  store ptr %l16, ptr %l290, !tbaa !29
  %t454 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t454, ptr %l291
  %t456 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s13, ptr %l291)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t456, ptr %l293
  br label %bb133
bb133:
  %t457 = load ptr, ptr %l290, !tbaa !29
  %t458 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l293
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s0, ptr %s13, ptr %t457, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t458)
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s13)
  br label %bb135
bb135:
  %t459 = load i64, ptr %l21, !tbaa !24
  %t461 = add i64 %t459, 1
  store i64 %t461, ptr %l21, !tbaa !24
  br label %bb97
bb136:
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load i32, ptr %l2, !tbaa !23
  %t467 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t463, i32 %t464)
  store i1 %t467, ptr %l298
  br label %bb137
bb137:
  %t468 = load i1, ptr %l298, !tbaa !21
  br i1 %t468, label %bb138, label %bb139
bb138:
  %t469 = load ptr, ptr %l1, !tbaa !29
  %t471 = getelementptr %"compiler/typed:Call", ptr %t469, i32 0, i32 2
  %t472 = load i32, ptr %t471, !tbaa !23
  %t474 = icmp sge i32 %t472, 0
  store i1 %t474, ptr %l299, !tbaa !21
  br label %bb140
bb139:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb140
bb140:
  %t476 = load i1, ptr %l299, !tbaa !21
  br i1 %t476, label %bb141, label %bb142
bb141:
  %t477 = load ptr, ptr %lp5
  store ptr %t477, ptr %l303, !tbaa !29
  %t478 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t479 = load ptr, ptr %l1, !tbaa !29
  %t481 = getelementptr %"compiler/typed:Call", ptr %t479, i32 0, i32 2
  %t482 = load i32, ptr %t481, !tbaa !23
  %t484 = sext i32 %t482 to i64
  %t487 = call i64 @compiler_2ffree_2eorig(i64 %t478, i64 %t484)
  store i64 %t487, ptr %l308
  br label %bb143
bb142:
  br label %bb145
bb143:
  %t488 = load ptr, ptr %l303, !tbaa !29
  %t489 = load i64, ptr %l308, !tbaa !24
  %t490 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t488, i64 %t489)
  store i64 %t490, ptr %l309
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t491 = load i64, ptr %l6, !tbaa !24
  %t493 = icmp sge i64 %t491, 0
  br i1 %t493, label %bb146, label %bb147
bb146:
  %t495 = load i1, ptr %l7, !tbaa !21
  %t497 = xor i1 %t495, true
  store i1 %t497, ptr %l312, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l312, !tbaa !21
  br label %bb148
bb148:
  %t499 = load i1, ptr %l312, !tbaa !21
  br i1 %t499, label %bb149, label %bb150
bb149:
  %t500 = load ptr, ptr %l4, !tbaa !29
  %t501 = load i64, ptr %l6, !tbaa !24
  %t504 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t500, i64 %t501)
  store i64 %t504, ptr %l318
  br label %bb151
bb150:
  store i1 false, ptr %l315, !tbaa !21
  br label %bb152
bb151:
  %t505 = load i64, ptr %l318, !tbaa !24
  %t506 = icmp ne i64 %t505, 0
  store i1 %t506, ptr %l315, !tbaa !21
  br label %bb152
bb152:
  %t508 = load i1, ptr %l315, !tbaa !21
  br i1 %t508, label %bb153, label %bb154
bb153:
  %t509 = load ptr, ptr %l4, !tbaa !29
  %t510 = load ptr, ptr %l1, !tbaa !29
  %t511 = load i64, ptr %l6, !tbaa !24
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/free:walker", ptr %t512, i32 0, i32 1
  %t515 = load i64, ptr %t514, !tbaa !24
  %t520 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efreshCtor(ptr %v0, ptr %v1, ptr %t509, ptr %t510, i64 %t511, i64 %t515)
  store i1 %t520, ptr %l326
  br label %bb155
bb154:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb156
bb155:
  %t521 = load i1, ptr %l326, !tbaa !21
  store i1 %t521, ptr %l320, !tbaa !21
  br label %bb156
bb156:
  %t522 = load i1, ptr %l320, !tbaa !21
  store i1 %t522, ptr %l27, !tbaa !21
  %t523 = load i1, ptr %l27, !tbaa !21
  br i1 %t523, label %bb157, label %bb158
bb157:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/free:walker", ptr %t525, i32 0, i32 2
  %t528 = load i1, ptr %t527, !tbaa !21
  store i1 %t528, ptr %l328, !tbaa !21
  br label %bb159
bb158:
  store i1 false, ptr %l328, !tbaa !21
  br label %bb159
bb159:
  %t530 = load i1, ptr %l328, !tbaa !21
  br i1 %t530, label %bb160, label %bb161
bb160:
  store %olang.scope zeroinitializer, ptr %s18
  %t531 = load ptr, ptr %l4, !tbaa !29
  %t533 = getelementptr %"compiler/free:Free", ptr %t531, i32 0, i32 108
  store ptr %t533, ptr %l332, !tbaa !29
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr %"compiler/free:walker", ptr %t534, i32 0, i32 1
  %t537 = load i64, ptr %t536, !tbaa !24
  %t538 = load ptr, ptr %l1, !tbaa !29
  %t540 = getelementptr %"compiler/typed:Call", ptr %t538, i32 0, i32 2
  %t541 = load i32, ptr %t540, !tbaa !23
  %t543 = sext i32 %t541 to i64
  %t546 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s18, i64 %t537, i64 %t543)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t546, ptr %l338
  br label %bb162
bb161:
  br label %bb164
bb162:
  %t547 = load ptr, ptr %l332, !tbaa !29
  %t548 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l338
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t547, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t548, i1 true)
  br label %bb163
bb163:
  call void @__olang_scope_close(ptr %s18)
  br label %bb164
bb164:
  %t549 = load i64, ptr %l6, !tbaa !24
  %t551 = icmp slt i64 %t549, 0
  br i1 %t551, label %bb165, label %bb166
bb165:
  store i1 true, ptr %l341, !tbaa !21
  br label %bb167
bb166:
  %t553 = load i1, ptr %l7, !tbaa !21
  store i1 %t553, ptr %l341, !tbaa !21
  br label %bb167
bb167:
  %t555 = load i1, ptr %l341, !tbaa !21
  br i1 %t555, label %bb168, label %bb169
bb168:
  store i1 true, ptr %l343, !tbaa !21
  br label %bb174
bb169:
  %t556 = load ptr, ptr %l4, !tbaa !29
  %t557 = load i64, ptr %l6, !tbaa !24
  %t560 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t556, i64 %t557)
  store i64 %t560, ptr %l346
  br label %bb170
bb170:
  %t561 = load i64, ptr %l346, !tbaa !24
  %t562 = icmp ne i64 %t561, 0
  br i1 %t562, label %bb171, label %bb172
bb171:
  %t564 = load i1, ptr %l27, !tbaa !21
  %t566 = xor i1 %t564, true
  store i1 %t566, ptr %l348, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l348, !tbaa !21
  br label %bb173
bb173:
  %t568 = load i1, ptr %l348, !tbaa !21
  store i1 %t568, ptr %l343, !tbaa !21
  br label %bb174
bb174:
  %t569 = load i1, ptr %l343, !tbaa !21
  br i1 %t569, label %bb175, label %bb176
bb175:
  %t570 = load ptr, ptr %l1, !tbaa !29
  %t572 = getelementptr %"compiler/typed:Call", ptr %t570, i32 0, i32 2
  %t573 = load i32, ptr %t572, !tbaa !23
  %t575 = sext i32 %t573 to i64
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/free:walker", ptr %t576, i32 0, i32 33
  %t579 = load i64, ptr %t578, !tbaa !24
  %t582 = icmp ne i64 %t575, %t579
  store i1 %t582, ptr %l351, !tbaa !21
  br label %bb177
bb176:
  store i1 false, ptr %l351, !tbaa !21
  br label %bb177
bb177:
  %t584 = load i1, ptr %l351, !tbaa !21
  br i1 %t584, label %bb178, label %bb179
bb178:
  store %olang.scope zeroinitializer, ptr %s19
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t586 = load i32, ptr %l2, !tbaa !23
  %t587 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %s19, ptr %t585, i32 %t586, %"compiler/source:Span" %t587, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb180
bb179:
  br label %bb181
bb180:
  call void @__olang_scope_close(ptr %s19)
  br label %bb181
bb181:
  %t591 = load i64, ptr %l6, !tbaa !24
  %t593 = icmp sge i64 %t591, 0
  br i1 %t593, label %bb182, label %bb183
bb182:
  %t595 = load i1, ptr %l7, !tbaa !21
  %t597 = xor i1 %t595, true
  store i1 %t597, ptr %l363, !tbaa !21
  br label %bb184
bb183:
  store i1 false, ptr %l363, !tbaa !21
  br label %bb184
bb184:
  %t599 = load i1, ptr %l363, !tbaa !21
  br i1 %t599, label %bb185, label %bb186
bb185:
  store %olang.scope zeroinitializer, ptr %s20
  %t600 = load ptr, ptr %l4, !tbaa !29
  %t601 = load i64, ptr %l6, !tbaa !24
  %t604 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisCase(ptr %v0, ptr %t600, i64 %t601)
  store i1 %t604, ptr %l368
  br label %bb187
bb186:
  br label %bb390
bb187:
  %t605 = load i1, ptr %l368, !tbaa !21
  br i1 %t605, label %bb188, label %bb189
bb188:
  store ptr %l16, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb190
bb189:
  br label %bb200
bb190:
  store %olang.scope zeroinitializer, ptr %s23
  %t607 = load i64, ptr %l29, !tbaa !24
  store i64 %t607, ptr %l370, !tbaa !24
  %t608 = load ptr, ptr %l28, !tbaa !29
  %t610 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %t608)
  store i64 %t610, ptr %l372
  br label %bb191
bb191:
  %t611 = load i64, ptr %l370, !tbaa !24
  %t612 = load i64, ptr %l372, !tbaa !24
  %t613 = icmp slt i64 %t611, %t612
  %t615 = xor i1 %t613, true
  br i1 %t615, label %bb192, label %bb193
bb192:
  call void @__olang_scope_close(ptr %s23)
  br label %bb199
bb193:
  br label %bb194
bb194:
  %t617 = load ptr, ptr %l28, !tbaa !29
  %t618 = load i64, ptr %l29, !tbaa !24
  %t621 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %t617, i64 %t618)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t621, ptr %l377
  br label %bb195
bb195:
  %t623 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s23, ptr %l377)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t623, ptr %l379
  br label %bb196
bb196:
  %t624 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l379
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t624, ptr %l30
  %t625 = load ptr, ptr %lp5
  %t628 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s23, ptr %t625, ptr %l30)
  store i64 %t628, ptr %l382
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s23)
  br label %bb198
bb198:
  %t629 = load i64, ptr %l29, !tbaa !24
  %t631 = add i64 %t629, 1
  store i64 %t631, ptr %l29, !tbaa !24
  br label %bb190
bb199:
  %t633 = load ptr, ptr %lp5
  %t634 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t633
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t634, ptr %rv
  br label %ret
bb200:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t638 = getelementptr %"compiler/free:walker", ptr %t636, i32 0, i32 2
  %t639 = load i1, ptr %t638, !tbaa !21
  br i1 %t639, label %bb201, label %bb202
bb201:
  %t641 = load ptr, ptr %l4, !tbaa !29
  %t643 = getelementptr %"compiler/free:Free", ptr %t641, i32 0, i32 46
  %t644 = load i1, ptr %t643, !tbaa !21
  store i1 %t644, ptr %l388, !tbaa !21
  br label %bb203
bb202:
  store i1 false, ptr %l388, !tbaa !21
  br label %bb203
bb203:
  %t646 = load i1, ptr %l388, !tbaa !21
  br i1 %t646, label %bb204, label %bb205
bb204:
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/free:walker", ptr %t647, i32 0, i32 30
  %t650 = load i64, ptr %t649, !tbaa !24
  %t652 = icmp eq i64 %t650, 0
  store i1 %t652, ptr %l391, !tbaa !21
  br label %bb206
bb205:
  store i1 false, ptr %l391, !tbaa !21
  br label %bb206
bb206:
  %t654 = load i1, ptr %l391, !tbaa !21
  br i1 %t654, label %bb207, label %bb208
bb207:
  store i64 0, ptr %l31, !tbaa !24
  %t656 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l16)
  store i64 %t656, ptr %l396
  br label %bb209
bb208:
  br label %bb243
bb209:
  %t657 = load i64, ptr %l396, !tbaa !24
  store i64 %t657, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t658 = load i64, ptr %l32, !tbaa !24
  %t659 = load i64, ptr %l31, !tbaa !24
  %t662 = icmp sgt i64 %t658, %t659
  br i1 %t662, label %bb210, label %bb211
bb210:
  %t664 = load i64, ptr %l33, !tbaa !24
  %t666 = icmp sgt i64 %t664, 0
  br i1 %t666, label %bb212, label %bb213
bb211:
  store i64 0, ptr %l400, !tbaa !24
  br label %bb215
bb212:
  %t668 = load i64, ptr %l32, !tbaa !24
  %t669 = load i64, ptr %l31, !tbaa !24
  %t672 = sub i64 %t668, %t669
  %t673 = load i64, ptr %l33, !tbaa !24
  %t676 = add i64 %t672, %t673
  %t678 = sub i64 %t676, 1
  %t679 = load i64, ptr %l33, !tbaa !24
  %t682 = sdiv i64 %t678, %t679
  store i64 %t682, ptr %l403, !tbaa !24
  br label %bb214
bb213:
  store i64 0, ptr %l403, !tbaa !24
  br label %bb214
bb214:
  %t684 = load i64, ptr %l403, !tbaa !24
  store i64 %t684, ptr %l400, !tbaa !24
  br label %bb215
bb215:
  %t685 = load i64, ptr %l400, !tbaa !24
  store i64 %t685, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb216
bb216:
  store %olang.scope zeroinitializer, ptr %s27
  %t686 = load i64, ptr %l35, !tbaa !24
  %t687 = load i64, ptr %l34, !tbaa !24
  %t690 = icmp slt i64 %t686, %t687
  %t692 = xor i1 %t690, true
  br i1 %t692, label %bb217, label %bb218
bb217:
  call void @__olang_scope_close(ptr %s27)
  br label %bb242
bb218:
  br label %bb219
bb219:
  %t694 = load i64, ptr %l31, !tbaa !24
  %t695 = load i64, ptr %l35, !tbaa !24
  %t696 = load i64, ptr %l33, !tbaa !24
  %t699 = mul i64 %t695, %t696
  %t702 = add i64 %t694, %t699
  store i64 %t702, ptr %l36, !tbaa !24
  %t704 = load ptr, ptr %l4, !tbaa !29
  %t706 = getelementptr %"compiler/free:Free", ptr %t704, i32 0, i32 28
  store ptr %t706, ptr %l422, !tbaa !29
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t707)
  store ptr %t709, ptr %l424
  br label %bb220
bb220:
  %t710 = load ptr, ptr %l1, !tbaa !29
  %t712 = getelementptr %"compiler/typed:Call", ptr %t710, i32 0, i32 1
  %t713 = load { i64, ptr }, ptr %t712, !tbaa !27
  store { i64, ptr } %t713, ptr %l426, !tbaa !27
  %t714 = load i64, ptr %l36, !tbaa !24
  %t716 = getelementptr { i64, ptr }, ptr %l426, i32 0, i32 1
  %t717 = load ptr, ptr %t716, !tbaa !27
  %t718 = getelementptr ptr, ptr %t717, i64 %t714
  %t719 = load ptr, ptr %t718, !tbaa !39
  %t721 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t719)
  store i32 %t721, ptr %l429
  br label %bb221
bb221:
  %t722 = load ptr, ptr %l422, !tbaa !29
  %t723 = load ptr, ptr %l424, !tbaa !29
  %t724 = load i32, ptr %l429, !tbaa !23
  %t725 = call i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eViewOf(ptr %v0, ptr %v0, ptr %t722, ptr %t723, i32 %t724)
  store i64 %t725, ptr %l430
  br label %bb222
bb222:
  %t726 = load i64, ptr @G_2ecompiler_2fmir_2eViewNone, !tbaa !24
  %t727 = load i64, ptr %l430, !tbaa !24
  %t729 = icmp eq i64 %t727, %t726
  br i1 %t729, label %bb223, label %bb224
bb223:
  store i1 true, ptr %l433, !tbaa !21
  br label %bb228
bb224:
  %t731 = load ptr, ptr %l4, !tbaa !29
  store ptr %t731, ptr %l434, !tbaa !29
  %t732 = load i64, ptr %l36, !tbaa !24
  %t735 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l16, i64 %t732)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t735, ptr %l437
  br label %bb225
bb225:
  %t737 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l437)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t737, ptr %l439
  br label %bb226
bb226:
  %t738 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l439
  %t739 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t738, ptr %t739
  %t740 = load ptr, ptr %l434, !tbaa !29
  %t742 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %s0, ptr %t740, ptr %t739)
  store i1 %t742, ptr %l441
  br label %bb227
bb227:
  %t743 = load i1, ptr %l441, !tbaa !21
  %t744 = xor i1 %t743, true
  store i1 %t744, ptr %l433, !tbaa !21
  br label %bb228
bb228:
  %t746 = load i1, ptr %l433, !tbaa !21
  br i1 %t746, label %bb229, label %bb230
bb229:
  call void @__olang_scope_close(ptr %s27)
  br label %bb241
bb230:
  br label %bb231
bb231:
  %t747 = load ptr, ptr %l4, !tbaa !29
  %t749 = getelementptr %"compiler/free:Free", ptr %t747, i32 0, i32 49
  %t750 = load ptr, ptr %l0, !tbaa !29
  %t752 = getelementptr %"compiler/free:walker", ptr %t750, i32 0, i32 1
  %t753 = load i64, ptr %t752, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t749, i64 %t753)
  br label %bb232
bb232:
  %t756 = load ptr, ptr %l4, !tbaa !29
  %t758 = getelementptr %"compiler/free:Free", ptr %t756, i32 0, i32 50
  %t759 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t758, i64 %t759)
  br label %bb233
bb233:
  %t762 = load ptr, ptr %l4, !tbaa !29
  %t764 = getelementptr %"compiler/free:Free", ptr %t762, i32 0, i32 51
  %t765 = load i64, ptr %l36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t764, i64 %t765)
  br label %bb234
bb234:
  %t768 = load ptr, ptr %l4, !tbaa !29
  %t770 = getelementptr %"compiler/free:Free", ptr %t768, i32 0, i32 52
  store ptr %t770, ptr %l454, !tbaa !29
  %t771 = ptrtoint ptr %v0 to i64
  store i64 %t771, ptr %l455, !tbaa !24
  %t772 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t772, label %bb235, label %bb236
bb235:
  %t774 = call ptr @__olang_region_make(ptr %v0)
  %t775 = ptrtoint ptr %t774 to i64
  store i64 %t775, ptr %l455, !tbaa !24
  br label %bb236
bb236:
  %t776 = load i64, ptr %l36, !tbaa !24
  %t779 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l16, i64 %t776)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t779, ptr %l459
  br label %bb237
bb237:
  %t781 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l459)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t781, ptr %l461
  br label %bb238
bb238:
  %t782 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l461
  %t783 = call ptr @__olang_scope_alloc_a(ptr %s27, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t782, ptr %t783
  %t784 = load i64, ptr %l455
  %t785 = inttoptr i64 %t784 to ptr
  %t787 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %s0, ptr %t785, ptr %t783)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t787, ptr %l463
  br label %bb239
bb239:
  %t788 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l463
  %t789 = load i64, ptr %l455
  %t790 = inttoptr i64 %t789 to ptr
  %t791 = call ptr @__olang_scope_alloc_a(ptr %t790, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t788, ptr %t791
  %t792 = load ptr, ptr %l454, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t792, ptr %t791)
  br label %bb240
bb240:
  call void @__olang_scope_close(ptr %s27)
  br label %bb241
bb241:
  %t794 = load i64, ptr %l35, !tbaa !24
  %t796 = add i64 %t794, 1
  store i64 %t796, ptr %l35, !tbaa !24
  br label %bb216
bb242:
  br label %bb243
bb243:
  %t798 = load ptr, ptr %l4, !tbaa !29
  %t800 = getelementptr %"compiler/free:Free", ptr %t798, i32 0, i32 62
  %t801 = load i64, ptr %l6, !tbaa !24
  %t804 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t800, i64 %t801)
  store ptr %t804, ptr %l470
  br label %bb244
bb244:
  %t805 = load ptr, ptr %l470, !tbaa !29
  store ptr %t805, ptr %l37, !tbaa !29
  store i64 0, ptr %l38, !tbaa !24
  br label %bb245
bb245:
  %t806 = load i64, ptr %l38, !tbaa !24
  store i64 %t806, ptr %l471, !tbaa !24
  %t807 = load ptr, ptr %l37, !tbaa !29
  store ptr %t807, ptr %l472, !tbaa !29
  %t808 = ptrtoint ptr %v0 to i64
  store i64 %t808, ptr %l473, !tbaa !24
  %t809 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t809, label %bb246, label %bb247
bb246:
  %t811 = load ptr, ptr %l472, !tbaa !29
  %t812 = call ptr @__olang_region_or(ptr %t811, ptr %v0)
  %t813 = ptrtoint ptr %t812 to i64
  store i64 %t813, ptr %l473, !tbaa !24
  br label %bb247
bb247:
  %t814 = load ptr, ptr %l37, !tbaa !29
  %t815 = load i64, ptr %l473
  %t816 = inttoptr i64 %t815 to ptr
  %t818 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t816, ptr %t814)
  store i64 %t818, ptr %l476
  br label %bb248
bb248:
  %t819 = load i64, ptr %l471, !tbaa !24
  %t820 = load i64, ptr %l476, !tbaa !24
  %t821 = icmp slt i64 %t819, %t820
  %t823 = xor i1 %t821, true
  br i1 %t823, label %bb249, label %bb250
bb249:
  br label %bb257
bb250:
  br label %bb251
bb251:
  %t825 = load ptr, ptr %l37, !tbaa !29
  store ptr %t825, ptr %l479, !tbaa !29
  %t826 = ptrtoint ptr %v0 to i64
  store i64 %t826, ptr %l480, !tbaa !24
  %t827 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t827, label %bb252, label %bb253
bb252:
  %t829 = load ptr, ptr %l479, !tbaa !29
  %t830 = call ptr @__olang_region_or(ptr %t829, ptr %v0)
  %t831 = ptrtoint ptr %t830 to i64
  store i64 %t831, ptr %l480, !tbaa !24
  br label %bb253
bb253:
  %t832 = load ptr, ptr %l37, !tbaa !29
  %t833 = load i64, ptr %l38, !tbaa !24
  %t834 = load i64, ptr %l480
  %t835 = inttoptr i64 %t834 to ptr
  %t838 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t835, ptr %t832, i64 %t833)
  store i64 %t838, ptr %l484
  br label %bb254
bb254:
  %t839 = load i64, ptr %l484, !tbaa !24
  %t840 = load ptr, ptr %l4, !tbaa !29
  %t842 = load ptr, ptr %lp5
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %s0, ptr %v2, ptr %t840, i64 %t839, ptr %l16, ptr %t842)
  br label %bb255
bb255:
  br label %bb256
bb256:
  %t847 = load i64, ptr %l38, !tbaa !24
  %t849 = add i64 %t847, 1
  store i64 %t849, ptr %l38, !tbaa !24
  br label %bb245
bb257:
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t853 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t851)
  store ptr %t853, ptr %l492
  br label %bb258
bb258:
  %t854 = load ptr, ptr %l4, !tbaa !29
  %t856 = getelementptr %"compiler/free:Free", ptr %t854, i32 0, i32 1
  %t857 = load i64, ptr %l6, !tbaa !24
  %t860 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t856, i64 %t857)
  store ptr %t860, ptr %l496
  br label %bb259
bb259:
  %t861 = load ptr, ptr %l496, !tbaa !29
  %t863 = getelementptr %"compiler/typed:Body", ptr %t861, i32 0, i32 2
  %t864 = load i32, ptr %t863, !tbaa !23
  %t865 = load ptr, ptr %l492, !tbaa !29
  %t867 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t865, i32 %t864)
  store i64 %t867, ptr %l499
  br label %bb260
bb260:
  %t868 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t869 = load i64, ptr %l499, !tbaa !24
  %t871 = icmp eq i64 %t869, %t868
  store i1 %t871, ptr %l40, !tbaa !21
  %t873 = load ptr, ptr %l4, !tbaa !29
  %t875 = getelementptr %"compiler/free:Free", ptr %t873, i32 0, i32 63
  %t876 = load i64, ptr %l6, !tbaa !24
  %t879 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t875, i64 %t876)
  store ptr %t879, ptr %l505
  br label %bb261
bb261:
  %t880 = load ptr, ptr %l505, !tbaa !29
  store ptr %t880, ptr %l41, !tbaa !29
  store i64 0, ptr %l42, !tbaa !24
  br label %bb262
bb262:
  %t881 = load i64, ptr %l42, !tbaa !24
  store i64 %t881, ptr %l506, !tbaa !24
  %t882 = load ptr, ptr %l41, !tbaa !29
  store ptr %t882, ptr %l507, !tbaa !29
  %t883 = ptrtoint ptr %v0 to i64
  store i64 %t883, ptr %l508, !tbaa !24
  %t884 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t884, label %bb263, label %bb264
bb263:
  %t886 = load ptr, ptr %l507, !tbaa !29
  %t887 = call ptr @__olang_region_or(ptr %t886, ptr %v0)
  %t888 = ptrtoint ptr %t887 to i64
  store i64 %t888, ptr %l508, !tbaa !24
  br label %bb264
bb264:
  %t889 = load ptr, ptr %l41, !tbaa !29
  %t890 = load i64, ptr %l508
  %t891 = inttoptr i64 %t890 to ptr
  %t893 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t891, ptr %t889)
  store i64 %t893, ptr %l511
  br label %bb265
bb265:
  %t894 = load i64, ptr %l506, !tbaa !24
  %t895 = load i64, ptr %l511, !tbaa !24
  %t896 = icmp slt i64 %t894, %t895
  %t898 = xor i1 %t896, true
  br i1 %t898, label %bb266, label %bb267
bb266:
  br label %bb285
bb267:
  br label %bb268
bb268:
  %t900 = load ptr, ptr %l41, !tbaa !29
  store ptr %t900, ptr %l514, !tbaa !29
  %t901 = ptrtoint ptr %v0 to i64
  store i64 %t901, ptr %l515, !tbaa !24
  %t902 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t902, label %bb269, label %bb270
bb269:
  %t904 = load ptr, ptr %l514, !tbaa !29
  %t905 = call ptr @__olang_region_or(ptr %t904, ptr %v0)
  %t906 = ptrtoint ptr %t905 to i64
  store i64 %t906, ptr %l515, !tbaa !24
  br label %bb270
bb270:
  %t907 = load ptr, ptr %l41, !tbaa !29
  %t908 = load i64, ptr %l42, !tbaa !24
  %t909 = load i64, ptr %l515
  %t910 = inttoptr i64 %t909 to ptr
  %t913 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t910, ptr %t907, i64 %t908)
  store i64 %t913, ptr %l519
  br label %bb271
bb271:
  %t914 = load i64, ptr %l519, !tbaa !24
  store i64 %t914, ptr %l43, !tbaa !24
  %t915 = load i64, ptr %l43, !tbaa !24
  %t917 = ashr i64 %t915, 32
  store i64 %t917, ptr %l44, !tbaa !24
  %t919 = load i64, ptr %l43, !tbaa !24
  %t920 = shl i64 1, 32
  %t922 = sub i64 %t920, 1
  %t925 = and i64 %t919, %t922
  store i64 %t925, ptr %l45, !tbaa !24
  %t927 = load i64, ptr %l44, !tbaa !24
  store i64 %t927, ptr %l526, !tbaa !24
  %t929 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l16)
  store i64 %t929, ptr %l528
  br label %bb272
bb272:
  %t930 = load i64, ptr %l526, !tbaa !24
  %t931 = load i64, ptr %l528, !tbaa !24
  %t932 = icmp slt i64 %t930, %t931
  br i1 %t932, label %bb273, label %bb274
bb273:
  %t934 = load ptr, ptr %l0, !tbaa !29
  %t935 = load ptr, ptr %l1, !tbaa !29
  %t936 = load i64, ptr %l6, !tbaa !24
  %t937 = load i64, ptr %l44, !tbaa !24
  %t942 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCopied(ptr %v0, ptr %v1, ptr %t934, ptr %t935, i64 %t936, i64 %t937)
  store i1 %t942, ptr %l535
  br label %bb275
bb274:
  store i1 false, ptr %l530, !tbaa !21
  br label %bb276
bb275:
  %t943 = load i1, ptr %l535, !tbaa !21
  %t944 = xor i1 %t943, true
  store i1 %t944, ptr %l530, !tbaa !21
  br label %bb276
bb276:
  %t946 = load i1, ptr %l530, !tbaa !21
  br i1 %t946, label %bb277, label %bb278
bb277:
  store %olang.scope zeroinitializer, ptr %s35
  %t947 = load ptr, ptr %l4, !tbaa !29
  %t948 = load i64, ptr %l6, !tbaa !24
  %t949 = load i64, ptr %l44, !tbaa !24
  %t953 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %t947, i64 %t948, i64 %t949)
  store i1 %t953, ptr %l540
  br label %bb279
bb278:
  br label %bb283
bb279:
  %t954 = load i1, ptr %l540, !tbaa !21
  store i1 %t954, ptr %l46, !tbaa !21
  %t955 = load ptr, ptr %l0, !tbaa !29
  store ptr %t955, ptr %l541, !tbaa !29
  %t956 = load i64, ptr %l45, !tbaa !24
  store i64 %t956, ptr %l542, !tbaa !24
  %t957 = load ptr, ptr %l1, !tbaa !29
  %t959 = getelementptr %"compiler/typed:Call", ptr %t957, i32 0, i32 1
  %t960 = load { i64, ptr }, ptr %t959, !tbaa !27
  store { i64, ptr } %t960, ptr %l544, !tbaa !27
  %t961 = load i64, ptr %l44, !tbaa !24
  %t963 = getelementptr { i64, ptr }, ptr %l544, i32 0, i32 1
  %t964 = load ptr, ptr %t963, !tbaa !27
  %t965 = getelementptr ptr, ptr %t964, i64 %t961
  %t966 = load ptr, ptr %t965, !tbaa !39
  store ptr %t966, ptr %l546, !tbaa !29
  %t967 = load i64, ptr %l44, !tbaa !24
  %t970 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l16, i64 %t967)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t970, ptr %l549
  br label %bb280
bb280:
  %t972 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l549)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t972, ptr %l551
  br label %bb281
bb281:
  %t973 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l551
  %t974 = call ptr @__olang_scope_alloc_a(ptr %s35, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t973, ptr %t974
  %t975 = load %"compiler/source:Span", ptr %l3
  %t976 = load i1, ptr %l46, !tbaa !21
  %t977 = load i1, ptr %l40, !tbaa !21
  %t978 = load ptr, ptr %l541, !tbaa !29
  %t979 = load i64, ptr %l542, !tbaa !24
  %t980 = load ptr, ptr %l546, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %s0, ptr %s35, ptr %t978, i64 %t979, ptr %t980, ptr %t974, %"compiler/source:Span" %t975, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, i1 %t976, i1 %t977)
  br label %bb282
bb282:
  call void @__olang_scope_close(ptr %s35)
  br label %bb283
bb283:
  br label %bb284
bb284:
  %t985 = load i64, ptr %l42, !tbaa !24
  %t987 = add i64 %t985, 1
  store i64 %t987, ptr %l42, !tbaa !24
  br label %bb262
bb285:
  %t989 = load ptr, ptr %l4, !tbaa !29
  %t991 = getelementptr %"compiler/free:Free", ptr %t989, i32 0, i32 67
  %t992 = load i64, ptr %l6, !tbaa !24
  %t995 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t991, i64 %t992)
  store ptr %t995, ptr %l561
  br label %bb286
bb286:
  %t996 = load ptr, ptr %l561, !tbaa !29
  store ptr %t996, ptr %l47, !tbaa !29
  store i64 0, ptr %l48, !tbaa !24
  br label %bb287
bb287:
  %t997 = load i64, ptr %l48, !tbaa !24
  store i64 %t997, ptr %l562, !tbaa !24
  %t998 = load ptr, ptr %l47, !tbaa !29
  store ptr %t998, ptr %l563, !tbaa !29
  %t999 = ptrtoint ptr %v0 to i64
  store i64 %t999, ptr %l564, !tbaa !24
  %t1000 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1000, label %bb288, label %bb289
bb288:
  %t1002 = load ptr, ptr %l563, !tbaa !29
  %t1003 = call ptr @__olang_region_or(ptr %t1002, ptr %v0)
  %t1004 = ptrtoint ptr %t1003 to i64
  store i64 %t1004, ptr %l564, !tbaa !24
  br label %bb289
bb289:
  %t1005 = load ptr, ptr %l47, !tbaa !29
  %t1006 = load i64, ptr %l564
  %t1007 = inttoptr i64 %t1006 to ptr
  %t1009 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t1007, ptr %t1005)
  store i64 %t1009, ptr %l567
  br label %bb290
bb290:
  %t1010 = load i64, ptr %l562, !tbaa !24
  %t1011 = load i64, ptr %l567, !tbaa !24
  %t1012 = icmp slt i64 %t1010, %t1011
  %t1014 = xor i1 %t1012, true
  br i1 %t1014, label %bb291, label %bb292
bb291:
  br label %bb305
bb292:
  br label %bb293
bb293:
  %t1016 = load ptr, ptr %l47, !tbaa !29
  store ptr %t1016, ptr %l570, !tbaa !29
  %t1017 = ptrtoint ptr %v0 to i64
  store i64 %t1017, ptr %l571, !tbaa !24
  %t1018 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1018, label %bb294, label %bb295
bb294:
  %t1020 = load ptr, ptr %l570, !tbaa !29
  %t1021 = call ptr @__olang_region_or(ptr %t1020, ptr %v0)
  %t1022 = ptrtoint ptr %t1021 to i64
  store i64 %t1022, ptr %l571, !tbaa !24
  br label %bb295
bb295:
  %t1023 = load ptr, ptr %l47, !tbaa !29
  %t1024 = load i64, ptr %l48, !tbaa !24
  %t1025 = load i64, ptr %l571
  %t1026 = inttoptr i64 %t1025 to ptr
  %t1029 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t1026, ptr %t1023, i64 %t1024)
  store i64 %t1029, ptr %l575
  br label %bb296
bb296:
  %t1030 = load i64, ptr %l575, !tbaa !24
  store i64 %t1030, ptr %l49, !tbaa !24
  %t1031 = load i64, ptr %l49, !tbaa !24
  store i64 %t1031, ptr %l576, !tbaa !24
  %t1033 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l16)
  store i64 %t1033, ptr %l578
  br label %bb297
bb297:
  %t1034 = load i64, ptr %l576, !tbaa !24
  %t1035 = load i64, ptr %l578, !tbaa !24
  %t1036 = icmp slt i64 %t1034, %t1035
  br i1 %t1036, label %bb298, label %bb299
bb298:
  %t1038 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1038, ptr %l580, !tbaa !29
  %t1039 = load ptr, ptr %l1, !tbaa !29
  %t1041 = getelementptr %"compiler/typed:Call", ptr %t1039, i32 0, i32 1
  %t1042 = load { i64, ptr }, ptr %t1041, !tbaa !27
  store { i64, ptr } %t1042, ptr %l582, !tbaa !27
  %t1043 = load i64, ptr %l49, !tbaa !24
  %t1045 = getelementptr { i64, ptr }, ptr %l582, i32 0, i32 1
  %t1046 = load ptr, ptr %t1045, !tbaa !27
  %t1047 = getelementptr ptr, ptr %t1046, i64 %t1043
  %t1048 = load ptr, ptr %t1047, !tbaa !39
  store ptr %t1048, ptr %l584, !tbaa !29
  %t1049 = load i64, ptr %l49, !tbaa !24
  %t1052 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l16, i64 %t1049)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1052, ptr %l587
  br label %bb300
bb299:
  br label %bb303
bb300:
  %t1054 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l587)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1054, ptr %l589
  br label %bb301
bb301:
  %t1055 = load %"compiler/source:Span", ptr %l3
  %t1056 = load ptr, ptr %l580, !tbaa !29
  %t1057 = load ptr, ptr %l584, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeArg(ptr %v0, ptr %v1, ptr %s0, ptr %t1056, ptr %t1057, ptr %l589, %"compiler/source:Span" %t1055)
  br label %bb302
bb302:
  br label %bb303
bb303:
  br label %bb304
bb304:
  %t1060 = load i64, ptr %l48, !tbaa !24
  %t1062 = add i64 %t1060, 1
  store i64 %t1062, ptr %l48, !tbaa !24
  br label %bb287
bb305:
  %t1064 = load ptr, ptr %l4, !tbaa !29
  %t1066 = getelementptr %"compiler/free:Free", ptr %t1064, i32 0, i32 64
  %t1067 = load i64, ptr %l6, !tbaa !24
  %t1070 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1066, i64 %t1067)
  store ptr %t1070, ptr %l597
  br label %bb306
bb306:
  %t1071 = load ptr, ptr %l597, !tbaa !29
  store ptr %t1071, ptr %l50, !tbaa !29
  store i64 0, ptr %l51, !tbaa !24
  br label %bb307
bb307:
  %t1072 = load i64, ptr %l51, !tbaa !24
  store i64 %t1072, ptr %l598, !tbaa !24
  %t1073 = load ptr, ptr %l50, !tbaa !29
  store ptr %t1073, ptr %l599, !tbaa !29
  %t1074 = ptrtoint ptr %v0 to i64
  store i64 %t1074, ptr %l600, !tbaa !24
  %t1075 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1075, label %bb308, label %bb309
bb308:
  %t1077 = load ptr, ptr %l599, !tbaa !29
  %t1078 = call ptr @__olang_region_or(ptr %t1077, ptr %v0)
  %t1079 = ptrtoint ptr %t1078 to i64
  store i64 %t1079, ptr %l600, !tbaa !24
  br label %bb309
bb309:
  %t1080 = load ptr, ptr %l50, !tbaa !29
  %t1081 = load i64, ptr %l600
  %t1082 = inttoptr i64 %t1081 to ptr
  %t1084 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t1082, ptr %t1080)
  store i64 %t1084, ptr %l603
  br label %bb310
bb310:
  %t1085 = load i64, ptr %l598, !tbaa !24
  %t1086 = load i64, ptr %l603, !tbaa !24
  %t1087 = icmp slt i64 %t1085, %t1086
  %t1089 = xor i1 %t1087, true
  br i1 %t1089, label %bb311, label %bb312
bb311:
  br label %bb325
bb312:
  br label %bb313
bb313:
  %t1091 = load ptr, ptr %l50, !tbaa !29
  store ptr %t1091, ptr %l606, !tbaa !29
  %t1092 = ptrtoint ptr %v0 to i64
  store i64 %t1092, ptr %l607, !tbaa !24
  %t1093 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1093, label %bb314, label %bb315
bb314:
  %t1095 = load ptr, ptr %l606, !tbaa !29
  %t1096 = call ptr @__olang_region_or(ptr %t1095, ptr %v0)
  %t1097 = ptrtoint ptr %t1096 to i64
  store i64 %t1097, ptr %l607, !tbaa !24
  br label %bb315
bb315:
  %t1098 = load ptr, ptr %l50, !tbaa !29
  %t1099 = load i64, ptr %l51, !tbaa !24
  %t1100 = load i64, ptr %l607
  %t1101 = inttoptr i64 %t1100 to ptr
  %t1104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t1101, ptr %t1098, i64 %t1099)
  store i64 %t1104, ptr %l611
  br label %bb316
bb316:
  %t1105 = load i64, ptr %l611, !tbaa !24
  store i64 %t1105, ptr %l52, !tbaa !24
  %t1106 = load i64, ptr %l52, !tbaa !24
  store i64 %t1106, ptr %l612, !tbaa !24
  %t1108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l16)
  store i64 %t1108, ptr %l614
  br label %bb317
bb317:
  %t1109 = load i64, ptr %l612, !tbaa !24
  %t1110 = load i64, ptr %l614, !tbaa !24
  %t1111 = icmp slt i64 %t1109, %t1110
  br i1 %t1111, label %bb318, label %bb319
bb318:
  store %olang.scope zeroinitializer, ptr %s43
  %t1113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1113, ptr %l616, !tbaa !29
  %t1114 = load i64, ptr %l52, !tbaa !24
  %t1117 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l16, i64 %t1114)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1117, ptr %l619
  br label %bb320
bb319:
  br label %bb323
bb320:
  %t1119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l619)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1119, ptr %l621
  br label %bb321
bb321:
  %t1120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l621
  %t1121 = call ptr @__olang_scope_alloc_a(ptr %s43, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1120, ptr %t1121
  %t1122 = load %"compiler/source:Span", ptr %l3
  %t1123 = load ptr, ptr %l616, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s0, ptr %s43, ptr %t1123, ptr %t1121, %"compiler/source:Span" %t1122, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s43)
  br label %bb323
bb323:
  br label %bb324
bb324:
  %t1126 = load i64, ptr %l51, !tbaa !24
  %t1128 = add i64 %t1126, 1
  store i64 %t1128, ptr %l51, !tbaa !24
  br label %bb307
bb325:
  %t1130 = load ptr, ptr %l4, !tbaa !29
  %t1132 = getelementptr %"compiler/free:Free", ptr %t1130, i32 0, i32 65
  %t1133 = load i64, ptr %l6, !tbaa !24
  %t1136 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1132, i64 %t1133)
  store ptr %t1136, ptr %l629
  br label %bb326
bb326:
  %t1137 = load ptr, ptr %l629, !tbaa !29
  store ptr %t1137, ptr %l53, !tbaa !29
  store i64 0, ptr %l54, !tbaa !24
  br label %bb327
bb327:
  %t1138 = load i64, ptr %l54, !tbaa !24
  store i64 %t1138, ptr %l630, !tbaa !24
  %t1139 = load ptr, ptr %l53, !tbaa !29
  store ptr %t1139, ptr %l631, !tbaa !29
  %t1140 = ptrtoint ptr %v0 to i64
  store i64 %t1140, ptr %l632, !tbaa !24
  %t1141 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1141, label %bb328, label %bb329
bb328:
  %t1143 = load ptr, ptr %l631, !tbaa !29
  %t1144 = call ptr @__olang_region_or(ptr %t1143, ptr %v0)
  %t1145 = ptrtoint ptr %t1144 to i64
  store i64 %t1145, ptr %l632, !tbaa !24
  br label %bb329
bb329:
  %t1146 = load ptr, ptr %l53, !tbaa !29
  %t1147 = load i64, ptr %l632
  %t1148 = inttoptr i64 %t1147 to ptr
  %t1150 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t1148, ptr %t1146)
  store i64 %t1150, ptr %l635
  br label %bb330
bb330:
  %t1151 = load i64, ptr %l630, !tbaa !24
  %t1152 = load i64, ptr %l635, !tbaa !24
  %t1153 = icmp slt i64 %t1151, %t1152
  %t1155 = xor i1 %t1153, true
  br i1 %t1155, label %bb331, label %bb332
bb331:
  br label %bb346
bb332:
  br label %bb333
bb333:
  %t1157 = load ptr, ptr %l53, !tbaa !29
  store ptr %t1157, ptr %l638, !tbaa !29
  %t1158 = ptrtoint ptr %v0 to i64
  store i64 %t1158, ptr %l639, !tbaa !24
  %t1159 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1159, label %bb334, label %bb335
bb334:
  %t1161 = load ptr, ptr %l638, !tbaa !29
  %t1162 = call ptr @__olang_region_or(ptr %t1161, ptr %v0)
  %t1163 = ptrtoint ptr %t1162 to i64
  store i64 %t1163, ptr %l639, !tbaa !24
  br label %bb335
bb335:
  %t1164 = load ptr, ptr %l53, !tbaa !29
  %t1165 = load i64, ptr %l54, !tbaa !24
  %t1166 = load i64, ptr %l639
  %t1167 = inttoptr i64 %t1166 to ptr
  %t1170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t1167, ptr %t1164, i64 %t1165)
  store i64 %t1170, ptr %l643
  br label %bb336
bb336:
  %t1171 = load i64, ptr %l643, !tbaa !24
  store i64 %t1171, ptr %l55, !tbaa !24
  %t1172 = load i64, ptr %l55, !tbaa !24
  store i64 %t1172, ptr %l644, !tbaa !24
  %t1174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %l16)
  store i64 %t1174, ptr %l646
  br label %bb337
bb337:
  %t1175 = load i64, ptr %l644, !tbaa !24
  %t1176 = load i64, ptr %l646, !tbaa !24
  %t1177 = icmp slt i64 %t1175, %t1176
  br i1 %t1177, label %bb338, label %bb339
bb338:
  store %olang.scope zeroinitializer, ptr %s47
  %t1179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1179, ptr %l648, !tbaa !29
  %t1180 = load ptr, ptr %l4, !tbaa !29
  store ptr %t1180, ptr %l649, !tbaa !29
  %t1181 = load i64, ptr %l55, !tbaa !24
  %t1184 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %l16, i64 %t1181)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1184, ptr %l652
  br label %bb340
bb339:
  br label %bb344
bb340:
  %t1186 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s0, ptr %l652)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1186, ptr %l654
  br label %bb341
bb341:
  %t1187 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l654
  %t1188 = call ptr @__olang_scope_alloc_a(ptr %s47, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1187, ptr %t1188
  %t1189 = load ptr, ptr %l649, !tbaa !29
  %t1191 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %s0, ptr %s47, ptr %t1189, ptr %t1188)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1191, ptr %l656
  br label %bb342
bb342:
  %t1192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l656
  %t1193 = call ptr @__olang_scope_alloc_a(ptr %s47, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1192, ptr %t1193
  %t1194 = load %"compiler/source:Span", ptr %l3
  %t1195 = load ptr, ptr %l648, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s47, ptr %s47, ptr %t1195, ptr %t1193, %"compiler/source:Span" %t1194, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d53, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb343
bb343:
  call void @__olang_scope_close(ptr %s47)
  br label %bb344
bb344:
  br label %bb345
bb345:
  %t1198 = load i64, ptr %l54, !tbaa !24
  %t1200 = add i64 %t1198, 1
  store i64 %t1200, ptr %l54, !tbaa !24
  br label %bb327
bb346:
  %t1202 = load ptr, ptr %l4, !tbaa !29
  %t1204 = getelementptr %"compiler/free:Free", ptr %t1202, i32 0, i32 69
  %t1205 = load i64, ptr %l6, !tbaa !24
  %t1208 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1204, i64 %t1205)
  store i1 %t1208, ptr %l664
  br label %bb347
bb347:
  %t1209 = load i1, ptr %l664, !tbaa !21
  br i1 %t1209, label %bb348, label %bb349
bb348:
  %t1210 = load ptr, ptr %l0, !tbaa !29
  %t1211 = load %"compiler/source:Span", ptr %l3
  %t1212 = load ptr, ptr %l1, !tbaa !29
  %t1213 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t1210, %"compiler/source:Span" %t1211, ptr %t1212, i64 %t1213)
  br label %bb350
bb349:
  %t1218 = load ptr, ptr %l4, !tbaa !29
  %t1220 = getelementptr %"compiler/free:Free", ptr %t1218, i32 0, i32 68
  %t1221 = load i64, ptr %l6, !tbaa !24
  %t1224 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1220, i64 %t1221)
  store ptr %t1224, ptr %l672
  br label %bb351
bb350:
  br label %bb366
bb351:
  %t1225 = load ptr, ptr %l672, !tbaa !29
  store ptr %t1225, ptr %l56, !tbaa !29
  store i64 0, ptr %l57, !tbaa !24
  br label %bb352
bb352:
  %t1226 = load i64, ptr %l57, !tbaa !24
  store i64 %t1226, ptr %l673, !tbaa !24
  %t1227 = load ptr, ptr %l56, !tbaa !29
  store ptr %t1227, ptr %l674, !tbaa !29
  %t1228 = ptrtoint ptr %v0 to i64
  store i64 %t1228, ptr %l675, !tbaa !24
  %t1229 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1229, label %bb353, label %bb354
bb353:
  %t1231 = load ptr, ptr %l674, !tbaa !29
  %t1232 = call ptr @__olang_region_or(ptr %t1231, ptr %v0)
  %t1233 = ptrtoint ptr %t1232 to i64
  store i64 %t1233, ptr %l675, !tbaa !24
  br label %bb354
bb354:
  %t1234 = load ptr, ptr %l56, !tbaa !29
  %t1235 = load i64, ptr %l675
  %t1236 = inttoptr i64 %t1235 to ptr
  %t1238 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t1236, ptr %t1234)
  store i64 %t1238, ptr %l678
  br label %bb355
bb355:
  %t1239 = load i64, ptr %l673, !tbaa !24
  %t1240 = load i64, ptr %l678, !tbaa !24
  %t1241 = icmp slt i64 %t1239, %t1240
  %t1243 = xor i1 %t1241, true
  br i1 %t1243, label %bb356, label %bb357
bb356:
  br label %bb365
bb357:
  br label %bb358
bb358:
  %t1245 = load ptr, ptr %l56, !tbaa !29
  store ptr %t1245, ptr %l681, !tbaa !29
  %t1246 = ptrtoint ptr %v0 to i64
  store i64 %t1246, ptr %l682, !tbaa !24
  %t1247 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t1247, label %bb359, label %bb360
bb359:
  %t1249 = load ptr, ptr %l681, !tbaa !29
  %t1250 = call ptr @__olang_region_or(ptr %t1249, ptr %v0)
  %t1251 = ptrtoint ptr %t1250 to i64
  store i64 %t1251, ptr %l682, !tbaa !24
  br label %bb360
bb360:
  %t1252 = load ptr, ptr %l56, !tbaa !29
  %t1253 = load i64, ptr %l57, !tbaa !24
  %t1254 = load i64, ptr %l682
  %t1255 = inttoptr i64 %t1254 to ptr
  %t1258 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t1255, ptr %t1252, i64 %t1253)
  store i64 %t1258, ptr %l686
  br label %bb361
bb361:
  %t1259 = load i64, ptr %l686, !tbaa !24
  %t1260 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1260, ptr %l687, !tbaa !29
  store i64 %t1259, ptr %l688, !tbaa !24
  %t1262 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t1262, ptr %l689, !tbaa !24
  %t1263 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t1263, ptr %l690
  %t1264 = load ptr, ptr %l1, !tbaa !29
  %t1266 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t1264)
  store %"compiler/source:Span" %t1266, ptr %l692
  br label %bb362
bb362:
  %t1267 = load i64, ptr %l6, !tbaa !24
  %t1268 = load ptr, ptr %l687, !tbaa !29
  %t1269 = load i64, ptr %l688, !tbaa !24
  %t1270 = load i64, ptr %l689, !tbaa !24
  %t1271 = load %"compiler/source:Span", ptr %l690
  %t1272 = load %"compiler/source:Span", ptr %l692
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t1268, i64 %t1269, i64 %t1270, %"compiler/source:Span" %t1271, %"compiler/source:Span" %t1272, i64 %t1267)
  br label %bb363
bb363:
  br label %bb364
bb364:
  %t1274 = load i64, ptr %l57, !tbaa !24
  %t1276 = add i64 %t1274, 1
  store i64 %t1276, ptr %l57, !tbaa !24
  br label %bb352
bb365:
  br label %bb366
bb366:
  %t1278 = load ptr, ptr %l0, !tbaa !29
  %t1279 = load ptr, ptr %l1, !tbaa !29
  %t1280 = load i64, ptr %l6, !tbaa !24
  %t1281 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviaCall(ptr %v0, ptr %v1, ptr %s0, ptr %t1278, ptr %t1279, i64 %t1280, i64 0, ptr %l16, %"compiler/source:Span" %t1281)
  br label %bb367
bb367:
  %t1287 = load ptr, ptr %l0, !tbaa !29
  %t1289 = getelementptr %"compiler/free:walker", ptr %t1287, i32 0, i32 2
  %t1290 = load i1, ptr %t1289, !tbaa !21
  br i1 %t1290, label %bb368, label %bb369
bb368:
  %t1292 = load ptr, ptr %l0, !tbaa !29
  %t1294 = getelementptr %"compiler/free:walker", ptr %t1292, i32 0, i32 30
  %t1295 = load i64, ptr %t1294, !tbaa !24
  %t1297 = icmp eq i64 %t1295, 0
  store i1 %t1297, ptr %l703, !tbaa !21
  br label %bb370
bb369:
  store i1 false, ptr %l703, !tbaa !21
  br label %bb370
bb370:
  %t1299 = load i1, ptr %l703, !tbaa !21
  br i1 %t1299, label %bb371, label %bb372
bb371:
  %t1300 = load ptr, ptr %l0, !tbaa !29
  %t1301 = load ptr, ptr %l1, !tbaa !29
  %t1302 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorCallOf(ptr %v0, ptr %v1, ptr %t1300, ptr %t1301, i64 %t1302)
  br label %bb373
bb372:
  br label %bb374
bb373:
  br label %bb374
bb374:
  %t1306 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s20, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1306, ptr %l710
  br label %bb375
bb375:
  %t1307 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l710
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1307, ptr %l59
  %t1308 = load ptr, ptr %lp5
  store ptr %t1308, ptr %l60, !tbaa !29
  store i64 0, ptr %l61, !tbaa !24
  br label %bb376
bb376:
  %t1310 = load i64, ptr %l61, !tbaa !24
  store i64 %t1310, ptr %l712, !tbaa !24
  %t1311 = load ptr, ptr %l60, !tbaa !29
  %t1313 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t1311)
  store i64 %t1313, ptr %l714
  br label %bb377
bb377:
  %t1314 = load i64, ptr %l712, !tbaa !24
  %t1315 = load i64, ptr %l714, !tbaa !24
  %t1316 = icmp slt i64 %t1314, %t1315
  %t1318 = xor i1 %t1316, true
  br i1 %t1318, label %bb378, label %bb379
bb378:
  br label %bb388
bb379:
  br label %bb380
bb380:
  %t1320 = load ptr, ptr %l60, !tbaa !29
  %t1321 = load i64, ptr %l61, !tbaa !24
  %t1324 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t1320, i64 %t1321)
  store i64 %t1324, ptr %l719
  br label %bb381
bb381:
  %t1325 = load i64, ptr %l719, !tbaa !24
  store i64 %t1325, ptr %l62, !tbaa !24
  %t1326 = load i64, ptr %l62, !tbaa !24
  %t1328 = call i64 @compiler_2ffree_2eokind(i64 %t1326)
  store i64 %t1328, ptr %l721
  br label %bb382
bb382:
  %t1329 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t1330 = load i64, ptr %l721, !tbaa !24
  %t1332 = icmp eq i64 %t1330, %t1329
  br i1 %t1332, label %bb383, label %bb384
bb383:
  %t1334 = load i64, ptr %l62, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s20, ptr %l59, i64 %t1334)
  br label %bb385
bb384:
  br label %bb386
bb385:
  br label %bb386
bb386:
  br label %bb387
bb387:
  %t1337 = load i64, ptr %l61, !tbaa !24
  %t1339 = add i64 %t1337, 1
  store i64 %t1339, ptr %l61, !tbaa !24
  br label %bb376
bb388:
  %t1341 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %s20, ptr %t1341, ptr %l59)
  br label %bb389
bb389:
  %t1344 = load ptr, ptr %lp5
  %t1345 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1344
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1345, ptr %rv
  br label %ret
bb390:
  %t1347 = load ptr, ptr %l1, !tbaa !29
  %t1349 = getelementptr %"compiler/typed:Call", ptr %t1347, i32 0, i32 0
  %t1350 = load ptr, ptr %t1349, !tbaa !29
  store ptr %t1350, ptr %l63, !tbaa !29
  %t1352 = load ptr, ptr %l63, !tbaa !29
  store ptr %t1352, ptr %l733, !tbaa !29
  store i1 false, ptr %l734, !tbaa !21
  %t1353 = load ptr, ptr %l733, !tbaa !29
  %t1354 = icmp ne ptr %t1353, null
  br i1 %t1354, label %bb391, label %bb392
bb391:
  %t1356 = load ptr, ptr %l733, !tbaa !29
  %t1357 = load i64, ptr %t1356, !range !{i64 0, i64 5}
  %t1359 = icmp eq i64 %t1357, 2
  store i1 %t1359, ptr %l734, !tbaa !21
  br label %bb392
bb392:
  %t1360 = load i1, ptr %l734, !tbaa !21
  br i1 %t1360, label %bb393, label %bb394
bb393:
  %t1361 = load ptr, ptr %l63, !tbaa !29
  %t1363 = getelementptr { i64, [3 x i64] }, ptr %t1361, i32 0, i32 1
  %t1364 = getelementptr { ptr }, ptr %t1363, i32 0, i32 0
  %t1365 = load ptr, ptr %t1364
  store ptr %t1365, ptr %l64, !tbaa !29
  br label %bb395
bb394:
  br label %bb397
bb395:
  %t1367 = load ptr, ptr %l0, !tbaa !29
  %t1368 = load ptr, ptr %l1, !tbaa !29
  %t1369 = load ptr, ptr %l64, !tbaa !29
  %t1370 = load %"compiler/source:Span", ptr %l3
  %t1371 = load ptr, ptr %lp5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2evalueCall(ptr %v0, ptr %v1, ptr %v1, ptr %s0, ptr %v2, ptr %t1367, ptr %t1368, ptr %t1369, ptr %l16, %"compiler/source:Span" %t1370, ptr %t1371)
  br label %bb396
bb396:
  %t1378 = load ptr, ptr %lp5
  %t1379 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1378
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1379, ptr %rv
  br label %ret
bb397:
  br i1 true, label %bb398, label %bb399
bb398:
  br label %bb400
bb399:
  br label %bb401
bb400:
  br label %bb402
bb401:
  call void @__olang_check_failed(ptr @olang_loc_d4fc5cdd71cd4f17_b1c92b5edf644a33)
  unreachable
bb402:
  store ptr %l16, ptr %l65, !tbaa !29
  store i64 0, ptr %l66, !tbaa !24
  br label %bb403
bb403:
  store %olang.scope zeroinitializer, ptr %s62
  %t1382 = load i64, ptr %l66, !tbaa !24
  store i64 %t1382, ptr %l747, !tbaa !24
  %t1383 = load ptr, ptr %l65, !tbaa !29
  %t1385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %s0, ptr %t1383)
  store i64 %t1385, ptr %l749
  br label %bb404
bb404:
  %t1386 = load i64, ptr %l747, !tbaa !24
  %t1387 = load i64, ptr %l749, !tbaa !24
  %t1388 = icmp slt i64 %t1386, %t1387
  %t1390 = xor i1 %t1388, true
  br i1 %t1390, label %bb405, label %bb406
bb405:
  call void @__olang_scope_close(ptr %s62)
  br label %bb416
bb406:
  br label %bb407
bb407:
  %t1392 = load ptr, ptr %l65, !tbaa !29
  %t1393 = load i64, ptr %l66, !tbaa !24
  %t1396 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %s0, ptr %s0, ptr %t1392, i64 %t1393)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1396, ptr %l754
  br label %bb408
bb408:
  %t1398 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s62, ptr %l754)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1398, ptr %l756
  br label %bb409
bb409:
  %t1399 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l756
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1399, ptr %l67
  %t1400 = load ptr, ptr %lp5
  %t1403 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s62, ptr %t1400, ptr %l67)
  store i64 %t1403, ptr %l759
  br label %bb410
bb410:
  %t1404 = load i1, ptr %l8, !tbaa !21
  %t1406 = xor i1 %t1404, true
  br i1 %t1406, label %bb411, label %bb412
bb411:
  store %olang.scope zeroinitializer, ptr %s63
  %t1408 = load ptr, ptr %l0, !tbaa !29
  %t1409 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s62, ptr %s63, ptr %t1408, ptr %l67, %"compiler/source:Span" %t1409, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d54, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb413
bb412:
  br label %bb414
bb413:
  call void @__olang_scope_close(ptr %s63)
  br label %bb414
bb414:
  call void @__olang_scope_close(ptr %s62)
  br label %bb415
bb415:
  %t1413 = load i64, ptr %l66, !tbaa !24
  %t1415 = add i64 %t1413, 1
  store i64 %t1415, ptr %l66, !tbaa !24
  br label %bb403
bb416:
  %t1417 = load ptr, ptr %lp5
  store ptr %t1417, ptr %l767, !tbaa !29
  %t1418 = load i64, ptr @G_2ecompiler_2ffree_2eOUnk, !tbaa !24
  %t1420 = call i64 @compiler_2ffree_2eorig(i64 %t1418, i64 0)
  store i64 %t1420, ptr %l769
  br label %bb417
bb417:
  %t1421 = load ptr, ptr %l767, !tbaa !29
  %t1422 = load i64, ptr %l769, !tbaa !24
  %t1423 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t1421, i64 %t1422)
  store i64 %t1423, ptr %l770
  br label %bb418
bb418:
  %t1424 = load i1, ptr %l9, !tbaa !21
  br i1 %t1424, label %bb419, label %bb420
bb419:
  %t1426 = load ptr, ptr %l1, !tbaa !29
  %t1428 = getelementptr %"compiler/typed:Call", ptr %t1426, i32 0, i32 1
  %t1429 = load { i64, ptr }, ptr %t1428, !tbaa !27
  store { i64, ptr } %t1429, ptr %l68, !tbaa !27
  store i64 0, ptr %l69, !tbaa !24
  %t1431 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t1433 = extractvalue { i64, ptr } %t1431, 0
  store i64 %t1433, ptr %l70, !tbaa !24
  br label %bb421
bb420:
  %t1435 = load i1, ptr %l8, !tbaa !21
  %t1437 = xor i1 %t1435, true
  br i1 %t1437, label %bb469, label %bb470
bb421:
  %t1439 = load i64, ptr %l69, !tbaa !24
  %t1440 = load i64, ptr %l70, !tbaa !24
  %t1443 = icmp slt i64 %t1439, %t1440
  %t1445 = xor i1 %t1443, true
  br i1 %t1445, label %bb422, label %bb423
bb422:
  br label %bb435
bb423:
  br label %bb424
bb424:
  %t1447 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t1447, ptr %l780, !tbaa !27
  %t1448 = load i64, ptr %l69, !tbaa !24
  %t1450 = getelementptr { i64, ptr }, ptr %l780, i32 0, i32 1
  %t1451 = load ptr, ptr %t1450, !tbaa !27
  %t1452 = getelementptr ptr, ptr %t1451, i64 %t1448
  %t1453 = load ptr, ptr %t1452, !tbaa !39
  store ptr %t1453, ptr %l71, !tbaa !29
  %t1455 = load ptr, ptr %l0, !tbaa !29
  %t1457 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t1455)
  store ptr %t1457, ptr %l784
  br label %bb425
bb425:
  %t1458 = load ptr, ptr %l0, !tbaa !29
  %t1460 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t1458)
  store ptr %t1460, ptr %l786
  br label %bb426
bb426:
  %t1461 = load ptr, ptr %l71, !tbaa !29
  %t1463 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1461)
  store i32 %t1463, ptr %l788
  br label %bb427
bb427:
  %t1464 = load ptr, ptr %l786, !tbaa !29
  %t1465 = load i32, ptr %l788, !tbaa !23
  %t1466 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t1464, i32 %t1465)
  store i32 %t1466, ptr %l789
  br label %bb428
bb428:
  %t1467 = load ptr, ptr %l784, !tbaa !29
  %t1468 = load i32, ptr %l789, !tbaa !23
  %t1469 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1467, i32 %t1468)
  store i32 %t1469, ptr %l790
  br label %bb429
bb429:
  %t1470 = load i32, ptr %l790, !range !{i32 0, i32 33}
  %t1472 = trunc i64 21 to i32
  %t1473 = icmp eq i32 %t1470, %t1472
  br i1 %t1473, label %bb430, label %bb431
bb430:
  %t1475 = load ptr, ptr %l4, !tbaa !29
  %t1477 = getelementptr %"compiler/free:Free", ptr %t1475, i32 0, i32 79
  %t1478 = load ptr, ptr %l0, !tbaa !29
  %t1480 = getelementptr %"compiler/free:walker", ptr %t1478, i32 0, i32 1
  %t1481 = load i64, ptr %t1480, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1477, i64 %t1481, i1 true)
  br label %bb432
bb431:
  br label %bb433
bb432:
  br label %bb433
bb433:
  br label %bb434
bb434:
  %t1484 = load i64, ptr %l69, !tbaa !24
  %t1486 = add i64 %t1484, 1
  store i64 %t1486, ptr %l69, !tbaa !24
  br label %bb421
bb435:
  store i1 false, ptr %l72, !tbaa !21
  %t1488 = load ptr, ptr %l4, !tbaa !29
  %t1490 = getelementptr %"compiler/free:Free", ptr %t1488, i32 0, i32 76
  store ptr %t1490, ptr %l73, !tbaa !29
  store i64 0, ptr %l74, !tbaa !24
  br label %bb436
bb436:
  %t1492 = load i64, ptr %l74, !tbaa !24
  store i64 %t1492, ptr %l801, !tbaa !24
  %t1493 = load ptr, ptr %l73, !tbaa !29
  %t1495 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t1493)
  store i64 %t1495, ptr %l803
  br label %bb437
bb437:
  %t1496 = load i64, ptr %l801, !tbaa !24
  %t1497 = load i64, ptr %l803, !tbaa !24
  %t1498 = icmp slt i64 %t1496, %t1497
  %t1500 = xor i1 %t1498, true
  br i1 %t1500, label %bb438, label %bb439
bb438:
  br label %bb464
bb439:
  br label %bb440
bb440:
  %t1502 = load ptr, ptr %l73, !tbaa !29
  %t1503 = load i64, ptr %l74, !tbaa !24
  %t1506 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t1502, i64 %t1503)
  store i64 %t1506, ptr %l808
  br label %bb441
bb441:
  %t1507 = load i64, ptr %l808, !tbaa !24
  store i64 %t1507, ptr %l75, !tbaa !24
  %t1508 = load i1, ptr %l10, !tbaa !21
  %t1510 = xor i1 %t1508, true
  br i1 %t1510, label %bb442, label %bb443
bb442:
  br label %bb464
bb443:
  br label %bb444
bb444:
  %t1512 = load ptr, ptr %l0, !tbaa !29
  %t1514 = getelementptr %"compiler/free:walker", ptr %t1512, i32 0, i32 2
  %t1515 = load i1, ptr %t1514, !tbaa !21
  %t1517 = xor i1 %t1515, true
  br i1 %t1517, label %bb445, label %bb446
bb445:
  %t1519 = load ptr, ptr %l4, !tbaa !29
  %t1521 = getelementptr %"compiler/free:Free", ptr %t1519, i32 0, i32 97
  %t1522 = load i64, ptr %l75, !tbaa !24
  %t1525 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1521, i64 %t1522)
  store ptr %t1525, ptr %l817
  br label %bb447
bb446:
  br label %bb449
bb447:
  %t1526 = load ptr, ptr %l0, !tbaa !29
  %t1528 = getelementptr %"compiler/free:walker", ptr %t1526, i32 0, i32 1
  %t1529 = load i64, ptr %t1528, !tbaa !24
  %t1530 = load ptr, ptr %l817, !tbaa !29
  %t1532 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t1530, i64 %t1529)
  store i64 %t1532, ptr %l820
  br label %bb448
bb448:
  br label %bb449
bb449:
  %t1533 = load ptr, ptr %l4, !tbaa !29
  %t1535 = getelementptr %"compiler/free:Free", ptr %t1533, i32 0, i32 68
  %t1536 = load i64, ptr %l75, !tbaa !24
  %t1539 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t1535, i64 %t1536)
  store ptr %t1539, ptr %l824
  br label %bb450
bb450:
  %t1540 = load ptr, ptr %l824, !tbaa !29
  %t1541 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t1540)
  store i64 %t1541, ptr %l825
  br label %bb451
bb451:
  %t1542 = load i64, ptr %l825, !tbaa !24
  %t1543 = icmp sgt i64 %t1542, 0
  br i1 %t1543, label %bb452, label %bb453
bb452:
  store i1 true, ptr %l827, !tbaa !21
  br label %bb455
bb453:
  %t1545 = load ptr, ptr %l4, !tbaa !29
  %t1547 = getelementptr %"compiler/free:Free", ptr %t1545, i32 0, i32 69
  %t1548 = load i64, ptr %l75, !tbaa !24
  %t1551 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1547, i64 %t1548)
  store i1 %t1551, ptr %l831
  br label %bb454
bb454:
  %t1552 = load i1, ptr %l831, !tbaa !21
  store i1 %t1552, ptr %l827, !tbaa !21
  br label %bb455
bb455:
  %t1553 = load i1, ptr %l827, !tbaa !21
  br i1 %t1553, label %bb456, label %bb457
bb456:
  store i1 true, ptr %l832, !tbaa !21
  br label %bb459
bb457:
  %t1554 = load ptr, ptr %l4, !tbaa !29
  %t1556 = getelementptr %"compiler/free:Free", ptr %t1554, i32 0, i32 70
  %t1557 = load i64, ptr %l75, !tbaa !24
  %t1560 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t1556, i64 %t1557)
  store i64 %t1560, ptr %l836
  br label %bb458
bb458:
  %t1561 = load i64, ptr %l836, !tbaa !24
  %t1562 = icmp ne i64 %t1561, 0
  store i1 %t1562, ptr %l832, !tbaa !21
  br label %bb459
bb459:
  %t1564 = load i1, ptr %l832, !tbaa !21
  br i1 %t1564, label %bb460, label %bb461
bb460:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb462
bb461:
  br label %bb462
bb462:
  br label %bb463
bb463:
  %t1565 = load i64, ptr %l74, !tbaa !24
  %t1567 = add i64 %t1565, 1
  store i64 %t1567, ptr %l74, !tbaa !24
  br label %bb436
bb464:
  %t1569 = load i1, ptr %l72, !tbaa !21
  br i1 %t1569, label %bb465, label %bb466
bb465:
  %t1571 = load ptr, ptr %l0, !tbaa !29
  %t1572 = load %"compiler/source:Span", ptr %l3
  %t1573 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t1571, %"compiler/source:Span" %t1572, ptr %t1573, i64 -1)
  br label %bb467
bb466:
  br label %bb468
bb467:
  br label %bb468
bb468:
  br label %bb473
bb469:
  %t1577 = load ptr, ptr %l0, !tbaa !29
  %t1578 = load %"compiler/source:Span", ptr %l3
  %t1579 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t1577, %"compiler/source:Span" %t1578, ptr %t1579, i64 -1)
  br label %bb471
bb470:
  br label %bb472
bb471:
  br label %bb472
bb472:
  br label %bb473
bb473:
  %t1583 = load ptr, ptr %lp5
  %t1584 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1583
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1584, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i64
  %l68 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i64
  %l81 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 16
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l19
  br label %bb4
bb4:
  %t13 = load i64, ptr %l19, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l26, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t41 = load i64, ptr %l23, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb12, label %bb13
bb12:
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 16
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l47
  br label %bb15
bb15:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l47, !tbaa !24
  %t70 = icmp sle i64 %t68, %t67
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load i64, ptr %l1, !tbaa !24
  store i64 %t72, ptr %l51, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 17
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l55
  br label %bb18
bb17:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb19
bb18:
  %t80 = load i64, ptr %l51, !tbaa !24
  %t81 = load i64, ptr %l55, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  store i1 %t82, ptr %l50, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l50, !tbaa !21
  store i1 %t84, ptr %l9, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 18
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l60
  br label %bb20
bb20:
  %t92 = load i64, ptr %l1, !tbaa !24
  %t93 = load i64, ptr %l60, !tbaa !24
  %t95 = icmp sle i64 %t93, %t92
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %l64, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:walker", ptr %t98, i32 0, i32 19
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l68
  br label %bb23
bb22:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb24
bb23:
  %t105 = load i64, ptr %l64, !tbaa !24
  %t106 = load i64, ptr %l68, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  store i1 %t107, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l63, !tbaa !21
  store i1 %t109, ptr %l10, !tbaa !21
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/free:walker", ptr %t110, i32 0, i32 16
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l73
  br label %bb25
bb25:
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr %l73, !tbaa !24
  %t120 = icmp sle i64 %t118, %t117
  br i1 %t120, label %bb26, label %bb27
bb26:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l77, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 17
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l81
  br label %bb28
bb27:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb29
bb28:
  %t130 = load i64, ptr %l77, !tbaa !24
  %t131 = load i64, ptr %l81, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l76, !tbaa !21
  br label %bb29
bb29:
  %t134 = load i1, ptr %l76, !tbaa !21
  store i1 %t134, ptr %l11, !tbaa !21
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t135, i32 0, i32 18
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l86
  br label %bb30
bb30:
  %t142 = load i64, ptr %l2, !tbaa !24
  %t143 = load i64, ptr %l86, !tbaa !24
  %t145 = icmp sle i64 %t143, %t142
  br i1 %t145, label %bb31, label %bb32
bb31:
  %t147 = load i64, ptr %l2, !tbaa !24
  store i64 %t147, ptr %l90, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/free:walker", ptr %t148, i32 0, i32 19
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l94
  br label %bb33
bb32:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb34
bb33:
  %t155 = load i64, ptr %l90, !tbaa !24
  %t156 = load i64, ptr %l94, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  store i1 %t157, ptr %l89, !tbaa !21
  br label %bb34
bb34:
  %t159 = load i1, ptr %l89, !tbaa !21
  store i1 %t159, ptr %l12, !tbaa !21
  %t160 = load i1, ptr %l9, !tbaa !21
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load i1, ptr %l12, !tbaa !21
  store i1 %t162, ptr %l97, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb37
bb37:
  %t164 = load i1, ptr %l97, !tbaa !21
  br i1 %t164, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb43
bb39:
  %t165 = load i1, ptr %l10, !tbaa !21
  br i1 %t165, label %bb40, label %bb41
bb40:
  %t167 = load i1, ptr %l11, !tbaa !21
  store i1 %t167, ptr %l101, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t169 = load i1, ptr %l101, !tbaa !21
  store i1 %t169, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t170 = load i1, ptr %l99, !tbaa !21
  br i1 %t170, label %bb44, label %bb45
bb44:
  store i1 true, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t172 = load i64, ptr %l7, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l7, !tbaa !24
  br label %bb11
bb48:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i64
  %l92 = alloca ptr
  %l93 = alloca i64
  %l96 = alloca i64
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i64
  %l104 = alloca i1
  %l105 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l2, !tbaa !24
  br label %bb54
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t39 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l25
  br label %bb12
bb12:
  %t40 = load i64, ptr %l25, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 8}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l35
  br label %bb19
bb19:
  %t64 = load i64, ptr %l35, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l36, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l45
  br label %bb26
bb26:
  %t88 = load i64, ptr %l45, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
bb27:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb29
bb29:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb32, label %bb33
bb31:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb39
bb32:
  %t106 = load ptr, ptr %l52, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 2
  store i1 %t109, ptr %l53, !tbaa !21
  br label %bb33
bb33:
  %t110 = load i1, ptr %l53, !tbaa !21
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t120 = load ptr, ptr %l59, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb38
bb36:
  %t123 = load ptr, ptr %l59, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 8}
  %t126 = icmp eq i64 %t124, 0
  store i1 %t126, ptr %l60, !tbaa !21
  br label %bb37
bb37:
  %t127 = load i1, ptr %l60, !tbaa !21
  store i1 %t127, ptr %l56, !tbaa !21
  br label %bb38
bb38:
  %t128 = load i1, ptr %l56, !tbaa !21
  store i1 %t128, ptr %l50, !tbaa !21
  br label %bb39
bb39:
  %t129 = load i1, ptr %l50, !tbaa !21
  br i1 %t129, label %bb40, label %bb41
bb40:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t140, i32 0, i32 2
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l7, !tbaa !23
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t144 = load i32, ptr %l7, !tbaa !23
  %t146 = sext i32 %t144 to i64
  store i64 %t146, ptr %l2, !tbaa !24
  br label %bb54
bb43:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t149 = load ptr, ptr %l69, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = load ptr, ptr %l69, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 8}
  %t155 = icmp eq i64 %t153, 2
  store i1 %t155, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l70, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i64 -1, ptr %rv
  br label %ret
bb53:
  call void @__olang_check_failed(ptr @olang_loc_e32699ce7a94654a_1a46213a714ace46)
  unreachable
bb54:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 6
  %t162 = load i64, ptr %l2, !tbaa !24
  %t165 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l78
  br label %bb55
bb55:
  %t166 = load i1, ptr %l78, !tbaa !21
  br i1 %t166, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb59
bb57:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:walker", ptr %t167, i32 0, i32 7
  %t170 = load i64, ptr %l2, !tbaa !24
  %t173 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t169, i64 %t170)
  store i1 %t173, ptr %l83
  br label %bb58
bb58:
  %t174 = load i1, ptr %l83, !tbaa !21
  store i1 %t174, ptr %l79, !tbaa !21
  br label %bb59
bb59:
  %t175 = load i1, ptr %l79, !tbaa !21
  br i1 %t175, label %bb60, label %bb61
bb60:
  store i64 -1, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/free:Free", ptr %t180, i32 0, i32 96
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:walker", ptr %t183, i32 0, i32 1
  %t186 = load i64, ptr %t185, !tbaa !24
  %t189 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_Ha64a825bb0b4fc6c7596ac96329c2853(ptr %v0, ptr %v0, ptr %t182, i64 %t186)
  store ptr %t189, ptr %l90
  br label %bb63
bb63:
  %t190 = load ptr, ptr %l90, !tbaa !29
  store ptr %t190, ptr %l8, !tbaa !29
  %t191 = load i64, ptr %l2, !tbaa !24
  store i64 %t191, ptr %l91, !tbaa !24
  %t192 = load ptr, ptr %l8, !tbaa !29
  store ptr %t192, ptr %l92, !tbaa !29
  %t193 = ptrtoint ptr %v0 to i64
  store i64 %t193, ptr %l93, !tbaa !24
  %t194 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1
  br i1 %t194, label %bb64, label %bb65
bb64:
  %t196 = load ptr, ptr %l92, !tbaa !29
  %t197 = call ptr @__olang_region_or(ptr %t196, ptr %v0)
  %t198 = ptrtoint ptr %t197 to i64
  store i64 %t198, ptr %l93, !tbaa !24
  br label %bb65
bb65:
  %t199 = load ptr, ptr %l8, !tbaa !29
  %t200 = load i64, ptr %l93
  %t201 = inttoptr i64 %t200 to ptr
  %t203 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %t201, ptr %t199)
  store i64 %t203, ptr %l96
  br label %bb66
bb66:
  %t204 = load i64, ptr %l91, !tbaa !24
  %t205 = load i64, ptr %l96, !tbaa !24
  %t206 = icmp slt i64 %t204, %t205
  br i1 %t206, label %bb67, label %bb68
bb67:
  %t208 = load ptr, ptr %l8, !tbaa !29
  store ptr %t208, ptr %l99, !tbaa !29
  %t209 = ptrtoint ptr %v0 to i64
  store i64 %t209, ptr %l100, !tbaa !24
  %t210 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1
  br i1 %t210, label %bb69, label %bb70
bb68:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb72
bb69:
  %t212 = load ptr, ptr %l99, !tbaa !29
  %t213 = call ptr @__olang_region_or(ptr %t212, ptr %v0)
  %t214 = ptrtoint ptr %t213 to i64
  store i64 %t214, ptr %l100, !tbaa !24
  br label %bb70
bb70:
  %t215 = load ptr, ptr %l8, !tbaa !29
  %t216 = load i64, ptr %l2, !tbaa !24
  %t217 = load i64, ptr %l100
  %t218 = inttoptr i64 %t217 to ptr
  %t221 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %t218, ptr %t215, i64 %t216)
  store i1 %t221, ptr %l104
  br label %bb71
bb71:
  %t222 = load i1, ptr %l104, !tbaa !21
  store i1 %t222, ptr %l98, !tbaa !21
  br label %bb72
bb72:
  %t223 = load i1, ptr %l98, !tbaa !21
  br i1 %t223, label %bb73, label %bb74
bb73:
  %t224 = load i64, ptr %l2, !tbaa !24
  store i64 %t224, ptr %l105, !tbaa !24
  br label %bb75
bb74:
  store i64 -1, ptr %l105, !tbaa !24
  br label %bb75
bb75:
  %t226 = load i64, ptr %l105, !tbaa !24
  store i64 %t226, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca %"compiler/typed:Local"
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 0
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/load:Loader", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  store ptr %t13, ptr %l6, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l8
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 7
  %t23 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t19, i64 %a1)
  store %"compiler/typed:Local" %t23, ptr %l12
  br label %bb2
bb2:
  %t24 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 0
  %t25 = load i32, ptr %t24, !tbaa !23
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s0, ptr %t26, i32 %t25)
  store { i64, ptr } %t28, ptr %l14
  br label %bb3
bb3:
  %t29 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  call void @olang_textcopy(ptr %t32, ptr %t30, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeStores(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i64
  %l39 = alloca i1
  %l48 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Make", ptr %t6, i32 0, i32 0
  %t9 = load i32, ptr %t8, !range !{i32 0, i32 5}
  %t11 = trunc i64 2 to i32
  %t12 = icmp eq i32 %t9, %t11
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb1, label %bb2
bb1:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 3 to i32
  %t22 = icmp eq i32 %t19, %t21
  %t24 = xor i1 %t22, true
  store i1 %t24, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l4, !tbaa !29
  store ptr %t27, ptr %l25, !tbaa !29
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t32 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t28, i32 %a2)
  store i32 %t32, ptr %l28
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l25, !tbaa !29
  %t34 = load i32, ptr %l28, !tbaa !23
  %t35 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t33, i32 %t34, i64 -1)
  store i64 %t35, ptr %l29
  br label %bb8
bb8:
  %t36 = load i64, ptr %l29, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Make", ptr %t41, i32 0, i32 0
  %t44 = load i32, ptr %t43, !range !{i32 0, i32 5}
  %t46 = trunc i64 3 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 61
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 1
  %t55 = load i64, ptr %t54, !tbaa !24
  %t58 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t51, i64 %t55)
  store i1 %t58, ptr %l39
  br label %bb14
bb13:
  br label %bb25
bb14:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t62 = getelementptr %"compiler/typed:Make", ptr %t60, i32 0, i32 2
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l8, !tbaa !24
  br label %bb18
bb18:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t77 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t77, ptr %l48, !tbaa !27
  %t78 = load i64, ptr %l7, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i64, ptr %l5, !tbaa !24
  %t88 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %t85, i64 %t86, ptr %t83, %"compiler/source:Span" %t88, i1 true)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t93 = load i64, ptr %l7, !tbaa !24
  %t95 = add i64 %t93, 1
  store i64 %t95, ptr %l7, !tbaa !24
  br label %bb18
bb24:
  br label %ret
bb25:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/typed:Make", ptr %t97, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  %t106 = load i64, ptr %l11, !tbaa !24
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t114 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t114, ptr %l65, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l5, !tbaa !24
  %t125 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %t122, i64 %t123, ptr %t120, %"compiler/source:Span" %t125, i1 false)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l11, !tbaa !24
  br label %bb26
bb32:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emayWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca i32
  %l9 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l21 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i64
  %l38 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l18, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t33 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t28)
  store i32 %t33, ptr %l23
  br label %bb6
bb6:
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l24
  br label %bb7
bb7:
  %t37 = load i32, ptr %l24, !tbaa !23
  store i32 %t37, ptr %l7, !tbaa !23
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t39 = load i32, ptr %l7, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l27
  br label %bb8
bb8:
  %t43 = load i1, ptr %l27, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t48 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t44, i32 %t45)
  store i64 %t48, ptr %l31
  br label %bb11
bb10:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb12
bb11:
  %t49 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t50 = load i64, ptr %l31, !tbaa !24
  %t52 = and i64 %t50, %t49
  %t54 = icmp ne i64 %t52, 0
  store i1 %t54, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l7, !tbaa !23
  %t62 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t58, i32 %t59)
  store i1 %t62, ptr %l38
  br label %bb16
bb16:
  %t63 = load i1, ptr %l38, !tbaa !21
  %t64 = xor i1 %t63, true
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t67 = load i32, ptr %l7, !tbaa !23
  %t70 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t66, i32 %t67)
  store i1 %t70, ptr %l43
  br label %bb19
bb18:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb20
bb19:
  %t71 = load i1, ptr %l43, !tbaa !21
  store i1 %t71, ptr %l40, !tbaa !21
  br label %bb20
bb20:
  %t72 = load i1, ptr %l40, !tbaa !21
  br i1 %t72, label %bb21, label %bb22
bb21:
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l4, !tbaa !24
  br label %bb2
bb25:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eorCallOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l51 = alloca i64
  %l56 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l70 = alloca %"compiler/free:orCall"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 2
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Call", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb9
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l5, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l23, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb8
bb8:
  %t41 = load i64, ptr %l23, !tbaa !24
  store i64 %t41, ptr %l20, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l20, !tbaa !24
  store i64 %t42, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:Call", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l43, !tbaa !27
  %t66 = load i64, ptr %l8, !tbaa !24
  %t68 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr ptr, ptr %t69, i64 %t66
  %t71 = load ptr, ptr %t70, !tbaa !39
  %t74 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %v1, ptr %t61, ptr %t71)
  store ptr %t74, ptr %l46
  br label %bb14
bb14:
  %t75 = load ptr, ptr %l46, !tbaa !29
  store ptr %t75, ptr %l9, !tbaa !29
  %t76 = load ptr, ptr %l9, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  br i1 %t78, label %bb15, label %bb16
bb15:
  br label %bb24
bb16:
  br label %bb17
bb17:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l9, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %t80, ptr %t81)
  store i64 %t84, ptr %l51
  br label %bb18
bb18:
  %t85 = load i64, ptr %l51, !tbaa !24
  store i64 %t85, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  br i1 %t88, label %bb19, label %bb20
bb19:
  br label %bb24
bb20:
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:walker", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 88
  store ptr %t95, ptr %l56, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:walker", ptr %t96, i32 0, i32 1
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Call", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %t102, !tbaa !23
  %t105 = sext i32 %t103 to i64
  %t107 = load i64, ptr %l8, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load ptr, ptr %l9, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Call", ptr %t110, i32 0, i32 1
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  store { i64, ptr } %t113, ptr %l67, !tbaa !27
  %t114 = load i64, ptr %l8, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr ptr, ptr %t117, i64 %t114
  %t119 = load ptr, ptr %t118, !tbaa !39
  %t127 = call %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v1, ptr %v1, ptr %v0, i64 %t99, i64 %t105, i64 %a2, i64 %t107, i64 %t108, ptr %t109, ptr %t119)
  store %"compiler/free:orCall" %t127, ptr %l70
  br label %bb22
bb22:
  %t128 = load ptr, ptr %l56, !tbaa !29
  %t129 = load %"compiler/free:orCall", ptr %l70
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2ePush_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t128, %"compiler/free:orCall" %t129)
  br label %bb23
bb23:
  br label %ret
bb24:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l7, !tbaa !24
  br label %bb10
bb25:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i64
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 8}
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t27, i32 0, i32 2
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 6
  %t34 = load i32, ptr %l3, !tbaa !23
  %t36 = sext i32 %t34 to i64
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t33, i64 %t36)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l25
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb12, label %ok.43, !prof !99
ok.43:
  store i64 %t40, ptr %l24
  br label %bb11
bb11:
  %t44 = load i64, ptr %l24, !tbaa !24
  store i64 %t44, ptr %l19, !tbaa !24
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t49 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i64 %t49, ptr %l28
  br label %bb14
bb14:
  %t50 = load i64, ptr %l28, !tbaa !24
  store i64 %t50, ptr %l19, !tbaa !24
  br label %bb15
bb15:
  %t51 = load i64, ptr %l19, !tbaa !24
  store i64 %t51, ptr %l12, !tbaa !24
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_f81460935a0747e6_f4792861f5ca2502)
  unreachable
bb21:
  %t52 = load i64, ptr %l12, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb35
bb22:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l29, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 17
  store i1 %t60, ptr %l30, !tbaa !21
  br label %bb24
bb24:
  %t61 = load i1, ptr %l30, !tbaa !21
  br i1 %t61, label %bb25, label %bb26
bb25:
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l4, !tbaa !29
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t72 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamOf(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i64 %t72, ptr %l37
  br label %bb28
bb28:
  %t73 = load i64, ptr %l37, !tbaa !24
  store i64 %t73, ptr %l5, !tbaa !24
  br label %bb35
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t78 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t74, ptr %t75)
  store i64 %t78, ptr %l40
  br label %bb33
bb33:
  %t79 = load i64, ptr %l40, !tbaa !24
  store i64 %t79, ptr %l5, !tbaa !24
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_e3a1bae50be73c47_b8cb15515377d683)
  unreachable
bb35:
  %t80 = load i64, ptr %l5, !tbaa !24
  store i64 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2evia(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l18 = alloca ptr
  %l20 = alloca i64
  %l25 = alloca i64
  %l30 = alloca i1
  %l35 = alloca i64
  %l40 = alloca ptr
  %l42 = alloca i64
  %l47 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l7, !tbaa !24
  %t7 = load i64, ptr %l7, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = shl i64 1, %t8
  store i64 %t9, ptr %l4, !tbaa !24
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 70
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 1
  %t17 = load i64, ptr %t16, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t17)
  store i64 %t20, ptr %l13
  br label %bb1
bb1:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l13, !tbaa !24
  %t24 = and i64 %t22, %t21
  %t26 = icmp eq i64 %t24, 0
  br i1 %t26, label %bb2, label %bb3
bb2:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 70
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 70
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:walker", ptr %t38, i32 0, i32 1
  %t41 = load i64, ptr %t40, !tbaa !24
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t37, i64 %t41)
  store i64 %t44, ptr %l25
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l25, !tbaa !24
  %t48 = or i64 %t46, %t45
  %t49 = load ptr, ptr %l18, !tbaa !29
  %t50 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t49, i64 %t50, i64 %t48)
  br label %bb5
bb5:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t54 = getelementptr %"compiler/free:Free", ptr %t52, i32 0, i32 77
  store i1 true, ptr %t54, !tbaa !21
  br label %bb6
bb6:
  br i1 %a2, label %bb7, label %bb8
bb7:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 71
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t59, i64 %t63)
  store i64 %t66, ptr %l35
  br label %bb9
bb8:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb10
bb9:
  %t67 = load i64, ptr %l4, !tbaa !24
  %t68 = load i64, ptr %l35, !tbaa !24
  %t70 = and i64 %t68, %t67
  %t72 = icmp eq i64 %t70, 0
  store i1 %t72, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t74 = load i1, ptr %l30, !tbaa !21
  br i1 %t74, label %bb11, label %bb12
bb11:
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = getelementptr %"compiler/free:Free", ptr %t75, i32 0, i32 71
  store ptr %t77, ptr %l40, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 1
  %t81 = load i64, ptr %t80, !tbaa !24
  store i64 %t81, ptr %l42, !tbaa !24
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/free:Free", ptr %t82, i32 0, i32 71
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t84, i64 %t88)
  store i64 %t91, ptr %l47
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t93 = load i64, ptr %l47, !tbaa !24
  %t95 = or i64 %t93, %t92
  %t96 = load ptr, ptr %l40, !tbaa !29
  %t97 = load i64, ptr %l42, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t96, i64 %t97, i64 %t95)
  br label %bb14
bb14:
  %t99 = load ptr, ptr %l3, !tbaa !29
  %t101 = getelementptr %"compiler/free:Free", ptr %t99, i32 0, i32 77
  store i1 true, ptr %t101, !tbaa !21
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviaCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca i64
  %l75 = alloca i64
  %l79 = alloca i1
  %l91 = alloca i32
  %l92 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l104 = alloca i32
  %l108 = alloca i64
  %l109 = alloca i64
  %l121 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca ptr
  %l124 = alloca i64
  %l127 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca i64
  %l135 = alloca i64
  %l147 = alloca i1
  %l153 = alloca i1
  %l156 = alloca i1
  %l157 = alloca i64
  %l159 = alloca i64
  %l161 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l165 = alloca ptr
  %l169 = alloca i64
  %l172 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l174 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 70
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t8, i64 %t9)
  store i64 %t12, ptr %l27
  br label %bb1
bb1:
  %t13 = load i64, ptr %l27, !tbaa !24
  store i64 %t13, ptr %l7, !tbaa !24
  %t14 = load i64, ptr %l7, !tbaa !24
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t20 = getelementptr %"compiler/free:Free", ptr %t18, i32 0, i32 72
  %t21 = load i64, ptr %l2, !tbaa !24
  %t24 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t20, i64 %t21)
  store ptr %t24, ptr %l34
  br label %bb4
bb3:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb6
bb4:
  %t25 = load ptr, ptr %l34, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t25)
  store i64 %t26, ptr %l35
  br label %bb5
bb5:
  %t27 = load i64, ptr %l35, !tbaa !24
  %t28 = icmp eq i64 %t27, 0
  store i1 %t28, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l30, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t31)
  store ptr %t33, ptr %l38
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t34)
  store ptr %t36, ptr %l40
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l6, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %l2, !tbaa !24
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store ptr %t43, ptr %l44
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l44, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Body", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %t46, !tbaa !23
  %t48 = load ptr, ptr %l40, !tbaa !29
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t48, i32 %t47)
  store i32 %t50, ptr %l47
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l38, !tbaa !29
  %t52 = load i32, ptr %l47, !tbaa !23
  %t53 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t51, i32 %t52)
  store { i64, ptr } %t53, ptr %l48
  br label %bb14
bb14:
  %t54 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t54, ptr %l8, !tbaa !27
  %t55 = load i64, ptr %l3, !tbaa !24
  store i64 %t55, ptr %l9, !tbaa !24
  store i64 62, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t57 = load i64, ptr %l10, !tbaa !24
  %t58 = load i64, ptr %l9, !tbaa !24
  %t61 = icmp sgt i64 %t57, %t58
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t63 = load i64, ptr %l11, !tbaa !24
  %t65 = icmp sgt i64 %t63, 0
  br i1 %t65, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb20
bb17:
  %t67 = load i64, ptr %l10, !tbaa !24
  %t68 = load i64, ptr %l9, !tbaa !24
  %t71 = sub i64 %t67, %t68
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = add i64 %t71, %t72
  %t77 = sub i64 %t75, 1
  %t78 = load i64, ptr %l11, !tbaa !24
  %t81 = sdiv i64 %t77, %t78
  store i64 %t81, ptr %l56, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb19
bb19:
  %t83 = load i64, ptr %l56, !tbaa !24
  store i64 %t83, ptr %l53, !tbaa !24
  br label %bb20
bb20:
  %t84 = load i64, ptr %l53, !tbaa !24
  store i64 %t84, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb21
bb21:
  %t85 = load i64, ptr %l13, !tbaa !24
  %t86 = load i64, ptr %l12, !tbaa !24
  %t89 = icmp slt i64 %t85, %t86
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb22, label %bb23
bb22:
  br label %bb37
bb23:
  br label %bb24
bb24:
  %t93 = load i64, ptr %l9, !tbaa !24
  %t94 = load i64, ptr %l13, !tbaa !24
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = mul i64 %t94, %t95
  %t101 = add i64 %t93, %t98
  store i64 %t101, ptr %l14, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  %t104 = load i64, ptr %l14, !tbaa !24
  store i64 %t104, ptr %l75, !tbaa !24
  %t105 = load i64, ptr %l75, !tbaa !24
  %t106 = load i64, ptr %l75, !tbaa !24
  %t107 = shl i64 1, %t106
  %t110 = and i64 %t103, %t107
  %t112 = icmp eq i64 %t110, 0
  br i1 %t112, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb27
bb26:
  %t114 = load i64, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l3, !tbaa !24
  %t118 = sub i64 %t114, %t115
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/typed:Call", ptr %t119, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = icmp sge i64 %t118, %t124
  store i1 %t127, ptr %l79, !tbaa !21
  br label %bb27
bb27:
  %t129 = load i1, ptr %l79, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t130 = load i64, ptr %l14, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t131, 0
  %t136 = icmp slt i64 %t130, %t133
  br i1 %t136, label %bb31, label %bb32
bb31:
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t138, ptr %l92, !tbaa !27
  %t139 = load i64, ptr %l14, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  store i32 %t144, ptr %l91, !tbaa !23
  br label %bb33
bb32:
  %t146 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t146, ptr %l91, !tbaa !23
  br label %bb33
bb33:
  %t148 = load i32, ptr %l91, !tbaa !23
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l96, !tbaa !29
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l97, !tbaa !29
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Call", ptr %t151, i32 0, i32 1
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l99, !tbaa !27
  %t155 = load i64, ptr %l14, !tbaa !24
  %t156 = load i64, ptr %l3, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t161 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr ptr, ptr %t162, i64 %t159
  %t164 = load ptr, ptr %t163, !tbaa !39
  store ptr %t164, ptr %l103, !tbaa !29
  store i32 %t148, ptr %l104, !tbaa !23
  %t166 = load ptr, ptr %l6, !tbaa !29
  %t168 = getelementptr %"compiler/free:Free", ptr %t166, i32 0, i32 71
  %t169 = load i64, ptr %l2, !tbaa !24
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t168, i64 %t169)
  store i64 %t172, ptr %l108
  br label %bb34
bb34:
  %t173 = load i64, ptr %l14, !tbaa !24
  store i64 %t173, ptr %l109, !tbaa !24
  %t174 = load i64, ptr %l109, !tbaa !24
  %t175 = load i64, ptr %l109, !tbaa !24
  %t176 = shl i64 1, %t175
  %t177 = load i64, ptr %l108, !tbaa !24
  %t179 = and i64 %t177, %t176
  %t181 = icmp ne i64 %t179, 0
  %t182 = load %"compiler/source:Span", ptr %l5
  %t183 = load ptr, ptr %l96, !tbaa !29
  %t184 = load ptr, ptr %l97, !tbaa !29
  %t185 = load ptr, ptr %l103, !tbaa !29
  %t186 = load i32, ptr %l104, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eletsThrough(ptr %v0, ptr %v1, ptr %v1, ptr %t183, ptr %t184, ptr %t185, i32 %t186, i1 %t181, %"compiler/source:Span" %t182)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t189 = load i64, ptr %l13, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l13, !tbaa !24
  br label %bb21
bb37:
  %t193 = shl i64 1, 20
  %t195 = sub i64 %t193, 1
  store i64 %t195, ptr %l16, !tbaa !24
  %t197 = load ptr, ptr %l6, !tbaa !29
  %t199 = getelementptr %"compiler/free:Free", ptr %t197, i32 0, i32 72
  %t200 = load i64, ptr %l2, !tbaa !24
  %t203 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t199, i64 %t200)
  store ptr %t203, ptr %l121
  br label %bb38
bb38:
  %t204 = load ptr, ptr %l121, !tbaa !29
  store ptr %t204, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t205 = load i64, ptr %l18, !tbaa !24
  store i64 %t205, ptr %l122, !tbaa !24
  %t206 = load ptr, ptr %l17, !tbaa !29
  store ptr %t206, ptr %l123, !tbaa !29
  %t207 = ptrtoint ptr %v0 to i64
  store i64 %t207, ptr %l124, !tbaa !24
  %t208 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t208, label %bb40, label %bb41
bb40:
  %t210 = load ptr, ptr %l123, !tbaa !29
  %t211 = call ptr @__olang_region_or(ptr %t210, ptr %v0)
  %t212 = ptrtoint ptr %t211 to i64
  store i64 %t212, ptr %l124, !tbaa !24
  br label %bb41
bb41:
  %t213 = load ptr, ptr %l17, !tbaa !29
  %t214 = load i64, ptr %l124
  %t215 = inttoptr i64 %t214 to ptr
  %t217 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t215, ptr %t213)
  store i64 %t217, ptr %l127
  br label %bb42
bb42:
  %t218 = load i64, ptr %l122, !tbaa !24
  %t219 = load i64, ptr %l127, !tbaa !24
  %t220 = icmp slt i64 %t218, %t219
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb44:
  br label %bb45
bb45:
  %t224 = load ptr, ptr %l17, !tbaa !29
  store ptr %t224, ptr %l130, !tbaa !29
  %t225 = ptrtoint ptr %v0 to i64
  store i64 %t225, ptr %l131, !tbaa !24
  %t226 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t226, label %bb46, label %bb47
bb46:
  %t228 = load ptr, ptr %l130, !tbaa !29
  %t229 = call ptr @__olang_region_or(ptr %t228, ptr %v0)
  %t230 = ptrtoint ptr %t229 to i64
  store i64 %t230, ptr %l131, !tbaa !24
  br label %bb47
bb47:
  %t231 = load ptr, ptr %l17, !tbaa !29
  %t232 = load i64, ptr %l18, !tbaa !24
  %t233 = load i64, ptr %l131
  %t234 = inttoptr i64 %t233 to ptr
  %t237 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t234, ptr %t231, i64 %t232)
  store i64 %t237, ptr %l135
  br label %bb48
bb48:
  %t238 = load i64, ptr %l135, !tbaa !24
  store i64 %t238, ptr %l19, !tbaa !24
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = ashr i64 %t239, 40
  %t242 = load i64, ptr %l3, !tbaa !24
  %t245 = sub i64 %t241, %t242
  store i64 %t245, ptr %l20, !tbaa !24
  %t247 = load i64, ptr %l19, !tbaa !24
  %t248 = load i64, ptr %l16, !tbaa !24
  %t251 = and i64 %t247, %t248
  %t252 = load i64, ptr %l3, !tbaa !24
  %t255 = sub i64 %t251, %t252
  store i64 %t255, ptr %l21, !tbaa !24
  %t257 = load i64, ptr %l20, !tbaa !24
  %t259 = icmp slt i64 %t257, 0
  br i1 %t259, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l147, !tbaa !21
  br label %bb51
bb50:
  %t261 = load i64, ptr %l20, !tbaa !24
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr %"compiler/typed:Call", ptr %t262, i32 0, i32 1
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t270 = icmp sge i64 %t261, %t267
  store i1 %t270, ptr %l147, !tbaa !21
  br label %bb51
bb51:
  %t272 = load i1, ptr %l147, !tbaa !21
  br i1 %t272, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb54
bb53:
  %t273 = load i64, ptr %l21, !tbaa !24
  %t275 = icmp slt i64 %t273, 0
  store i1 %t275, ptr %l153, !tbaa !21
  br label %bb54
bb54:
  %t277 = load i1, ptr %l153, !tbaa !21
  br i1 %t277, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l156, !tbaa !21
  br label %bb58
bb56:
  %t278 = load i64, ptr %l21, !tbaa !24
  store i64 %t278, ptr %l157, !tbaa !24
  %t279 = load ptr, ptr %l4, !tbaa !29
  %t281 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t279)
  store i64 %t281, ptr %l159
  br label %bb57
bb57:
  %t282 = load i64, ptr %l157, !tbaa !24
  %t283 = load i64, ptr %l159, !tbaa !24
  %t284 = icmp sge i64 %t282, %t283
  store i1 %t284, ptr %l156, !tbaa !21
  br label %bb58
bb58:
  %t286 = load i1, ptr %l156, !tbaa !21
  br i1 %t286, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb60:
  br label %bb61
bb61:
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l161, !tbaa !29
  %t288 = load ptr, ptr %l1, !tbaa !29
  %t290 = getelementptr %"compiler/typed:Call", ptr %t288, i32 0, i32 1
  %t291 = load { i64, ptr }, ptr %t290, !tbaa !27
  store { i64, ptr } %t291, ptr %l163, !tbaa !27
  %t292 = load i64, ptr %l20, !tbaa !24
  %t294 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr ptr, ptr %t295, i64 %t292
  %t297 = load ptr, ptr %t296, !tbaa !39
  store ptr %t297, ptr %l165, !tbaa !29
  %t298 = load i64, ptr %l19, !tbaa !24
  %t300 = ashr i64 %t298, 20
  %t301 = load i64, ptr %l16, !tbaa !24
  %t304 = and i64 %t300, %t301
  store i64 %t304, ptr %l169, !tbaa !24
  %t305 = load ptr, ptr %l4, !tbaa !29
  %t306 = load i64, ptr %l21, !tbaa !24
  %t309 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t305, i64 %t306)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t309, ptr %l172
  br label %bb62
bb62:
  %t311 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v2, ptr %l172)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t311, ptr %l174
  br label %bb63
bb63:
  %t312 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l174
  %t313 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t312, ptr %t313
  %t314 = load %"compiler/source:Span", ptr %l5
  %t315 = load ptr, ptr %l161, !tbaa !29
  %t316 = load ptr, ptr %l165, !tbaa !29
  %t317 = load i64, ptr %l169, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescThrough(ptr %v0, ptr %v1, ptr %v2, ptr %t315, ptr %t316, i64 %t317, ptr %t313, %"compiler/source:Span" %t314)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb65:
  %t320 = load i64, ptr %l18, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l18, !tbaa !24
  br label %bb39
bb66:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l15 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call i64 @compiler_2ffree_2eorig(i64 %t8, i64 %t9)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t13, i64 %t14)
  store i1 %t15, ptr %l10
  br label %bb3
bb3:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb9
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 3
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l15
  br label %bb6
bb6:
  %t24 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call i64 @compiler_2ffree_2eorig(i64 %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l15, !tbaa !29
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t31, ptr %l19
  br label %bb8
bb8:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %l11, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l11, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewritable(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca i1
  %l17 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr %l11, !range !{i32 0, i32 33}
  %t18 = trunc i64 20 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i32, ptr %l3, !tbaa !23
  %t25 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l17
  br label %bb6
bb5:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb7
bb6:
  %t26 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t27 = load i64, ptr %l17, !tbaa !24
  %t29 = and i64 %t27, %t26
  %t31 = icmp ne i64 %t29, 0
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l14, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 10
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb39
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb27
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Cond", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Cond", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb22
bb18:
  call void @__olang_check_failed(ptr @olang_loc_228ad70617d44d77_1dee412aac6cbab)
  unreachable
bb19:
  br label %bb20
bb20:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Cond", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %t53)
  store i1 %t55, ptr %l28
  br label %bb21
bb21:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %l22, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l22, !tbaa !21
  br i1 %t57, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb26
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Cond", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %t61)
  store i1 %t63, ptr %l32
  br label %bb25
bb25:
  %t64 = load i1, ptr %l32, !tbaa !21
  store i1 %t64, ptr %l29, !tbaa !21
  br label %bb26
bb26:
  %t65 = load i1, ptr %l29, !tbaa !21
  store i1 %t65, ptr %l3, !tbaa !21
  br label %bb39
bb27:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb28, label %bb29
bb28:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 17
  store i1 %t73, ptr %l34, !tbaa !21
  br label %bb29
bb29:
  %t74 = load i1, ptr %l34, !tbaa !21
  br i1 %t74, label %bb30, label %bb31
bb30:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l2, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %t81)
  store i1 %t83, ptr %l40
  br label %bb33
bb33:
  %t84 = load i1, ptr %l40, !tbaa !21
  store i1 %t84, ptr %l3, !tbaa !21
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5e2122fa9519644f_a9d9059c63542dd3)
  unreachable
bb39:
  %t85 = load i1, ptr %l3, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2efieldRootLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l19 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l3, !tbaa !24
  br label %bb18
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call i64 @compiler_2ffree_2efieldRootLocal(ptr %v0, ptr %t35)
  store i64 %t37, ptr %l19
  br label %bb12
bb12:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_c3fd4e13fe372032_611898922dc4483e)
  unreachable
bb18:
  %t39 = load i64, ptr %l3, !tbaa !24
  store i64 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l56 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i1
  %l123 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i1
  %l150 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca i1
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i1
  %l196 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l219 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca i1
  %l230 = alloca ptr
  %l246 = alloca ptr
  %l255 = alloca ptr
  %l256 = alloca ptr
  %l257 = alloca i1
  %l264 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t2 = load ptr, ptr %l35, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l35, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l36, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb31
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = icmp eq i64 %t21, %t22
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l56, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t53, i64 %t56)
  store ptr %t59, ptr %l61
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l61, !tbaa !29
  store ptr %t60, ptr %l7, !tbaa !29
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l7, !tbaa !29
  store ptr %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb9
bb18:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Call", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l8, !tbaa !29
  %t79 = load ptr, ptr %l8, !tbaa !29
  store ptr %t79, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t80 = load ptr, ptr %l71, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb19, label %bb20
bb19:
  %t83 = load ptr, ptr %l71, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 5}
  %t86 = icmp eq i64 %t84, 2
  store i1 %t86, ptr %l72, !tbaa !21
  br label %bb20
bb20:
  %t87 = load i1, ptr %l72, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { ptr }, ptr %t90, i32 0, i32 0
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l9, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t94 = load ptr, ptr %l9, !tbaa !29
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t94, i64 %t95)
  store ptr %t98, ptr %l79
  br label %bb24
bb24:
  %t99 = load ptr, ptr %l79, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_16263ed1acd4aa7e_23dcb8f717a142b2)
  unreachable
bb30:
  store ptr null, ptr %rv
  br label %ret
bb31:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t102 = load ptr, ptr %l81, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t105 = load ptr, ptr %l81, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 18}
  %t108 = icmp eq i64 %t106, 5
  store i1 %t108, ptr %l82, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l82, !tbaa !21
  br i1 %t109, label %bb34, label %bb35
bb34:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l10, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t116 = load ptr, ptr %l10, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Promote", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l1, !tbaa !24
  %t123 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t119, i64 %t120)
  store ptr %t123, ptr %l90
  br label %bb37
bb37:
  %t124 = load ptr, ptr %l90, !tbaa !29
  store ptr %t124, ptr %rv
  br label %ret
bb38:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t126 = load ptr, ptr %l91, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = load ptr, ptr %l91, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 2
  store i1 %t132, ptr %l92, !tbaa !21
  br label %bb40
bb40:
  %t133 = load i1, ptr %l92, !tbaa !21
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t141 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l99
  br label %bb44
bb44:
  %t145 = load ptr, ptr %l99, !tbaa !29
  store ptr %t145, ptr %rv
  br label %ret
bb45:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t147 = load ptr, ptr %l100, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb46, label %bb47
bb46:
  %t150 = load ptr, ptr %l100, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 18}
  %t153 = icmp eq i64 %t151, 3
  store i1 %t153, ptr %l101, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l101, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr { i64, [5 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l12, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t161 = load ptr, ptr %l12, !tbaa !29
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t161, i64 %t162)
  store ptr %t165, ptr %l108
  br label %bb51
bb51:
  %t166 = load ptr, ptr %l108, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb52:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t168 = load ptr, ptr %l109, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t171 = load ptr, ptr %l109, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 18}
  %t174 = icmp eq i64 %t172, 7
  store i1 %t174, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t175 = load i1, ptr %l110, !tbaa !21
  br i1 %t175, label %bb55, label %bb56
bb55:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l13, !tbaa !29
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t182 = load ptr, ptr %l13, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Make", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l16, !tbaa !24
  br label %bb58
bb58:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb59, label %bb60
bb59:
  br label %bb67
bb60:
  br label %bb61
bb61:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t199, ptr %l123, !tbaa !27
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr ptr, ptr %t203, i64 %t200
  %t205 = load ptr, ptr %t204, !tbaa !39
  %t208 = load i64, ptr %l1, !tbaa !24
  %t211 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t205, i64 %t208)
  store ptr %t211, ptr %l128
  br label %bb62
bb62:
  %t212 = load ptr, ptr %l128, !tbaa !29
  store ptr %t212, ptr %l18, !tbaa !29
  %t213 = load ptr, ptr %l18, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb63, label %bb64
bb63:
  %t219 = load ptr, ptr %l18, !tbaa !29
  store ptr %t219, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t222 = load i64, ptr %l15, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l15, !tbaa !24
  br label %bb58
bb67:
  store ptr null, ptr %rv
  br label %ret
bb68:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t228 = load ptr, ptr %l137, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb69, label %bb70
bb69:
  %t231 = load ptr, ptr %l137, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 18}
  %t234 = icmp eq i64 %t232, 9
  store i1 %t234, ptr %l138, !tbaa !21
  br label %bb70
bb70:
  %t235 = load i1, ptr %l138, !tbaa !21
  br i1 %t235, label %bb71, label %bb72
bb71:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t238, i32 0, i32 4
  %t240 = load { i64, ptr }, ptr %t239
  store { i64, ptr } %t240, ptr %l19, !tbaa !27
  br label %bb73
bb72:
  br label %bb84
bb73:
  %t242 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t242, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l22, !tbaa !24
  br label %bb74
bb74:
  %t248 = load i64, ptr %l21, !tbaa !24
  %t249 = load i64, ptr %l22, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb75, label %bb76
bb75:
  br label %bb83
bb76:
  br label %bb77
bb77:
  %t256 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t256, ptr %l150, !tbaa !27
  %t257 = load i64, ptr %l21, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 %t257
  %t262 = load ptr, ptr %t261, !tbaa !39
  %t265 = load i64, ptr %l1, !tbaa !24
  %t268 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t262, i64 %t265)
  store ptr %t268, ptr %l155
  br label %bb78
bb78:
  %t269 = load ptr, ptr %l155, !tbaa !29
  store ptr %t269, ptr %l24, !tbaa !29
  %t270 = load ptr, ptr %l24, !tbaa !29
  %t272 = icmp eq ptr %t270, null
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb79, label %bb80
bb79:
  %t276 = load ptr, ptr %l24, !tbaa !29
  store ptr %t276, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t279 = load i64, ptr %l21, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l21, !tbaa !24
  br label %bb74
bb83:
  store ptr null, ptr %rv
  br label %ret
bb84:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t285 = load ptr, ptr %l164, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb85, label %bb86
bb85:
  %t288 = load ptr, ptr %l164, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 18}
  %t291 = icmp eq i64 %t289, 14
  store i1 %t291, ptr %l165, !tbaa !21
  br label %bb86
bb86:
  %t292 = load i1, ptr %l165, !tbaa !21
  br i1 %t292, label %bb87, label %bb88
bb87:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr { i64, [5 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t295, i32 0, i32 2
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l25, !tbaa !29
  br label %bb89
bb88:
  br label %bb97
bb89:
  %t299 = load ptr, ptr %l25, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Try", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb90, label %bb91
bb90:
  %t308 = load ptr, ptr %l25, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Try", ptr %t308, i32 0, i32 0
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  br i1 %t313, label %bb92, label %bb93
bb91:
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_ea2e0f0d6ffcb248_fe73fa1c8e55849c)
  unreachable
bb93:
  br label %bb94
bb94:
  %t315 = load ptr, ptr %l25, !tbaa !29
  %t317 = getelementptr %"compiler/typed:Try", ptr %t315, i32 0, i32 0
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load i64, ptr %l1, !tbaa !24
  %t322 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t318, i64 %t319)
  store ptr %t322, ptr %l180
  br label %bb95
bb95:
  %t323 = load ptr, ptr %l180, !tbaa !29
  store ptr %t323, ptr %rv
  br label %ret
bb96:
  store ptr null, ptr %rv
  br label %ret
bb97:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t326 = load ptr, ptr %l182, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb98, label %bb99
bb98:
  %t329 = load ptr, ptr %l182, !tbaa !29
  %t330 = load i64, ptr %t329, !range !{i64 0, i64 18}
  %t332 = icmp eq i64 %t330, 12
  store i1 %t332, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t333 = load i1, ptr %l183, !tbaa !21
  br i1 %t333, label %bb100, label %bb101
bb100:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t336, i32 0, i32 2
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l26, !tbaa !29
  br label %bb102
bb101:
  br label %bb120
bb102:
  %t340 = load ptr, ptr %l26, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Seq", ptr %t340, i32 0, i32 0
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  store { i64, ptr } %t343, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t345 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  store i64 %t347, ptr %l29, !tbaa !24
  br label %bb103
bb103:
  %t349 = load i64, ptr %l28, !tbaa !24
  %t350 = load i64, ptr %l29, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb104, label %bb105
bb104:
  br label %bb112
bb105:
  br label %bb106
bb106:
  %t357 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t357, ptr %l196, !tbaa !27
  %t358 = load i64, ptr %l28, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr ptr, ptr %t361, i64 %t358
  %t363 = load ptr, ptr %t362, !tbaa !39
  %t366 = load i64, ptr %l1, !tbaa !24
  %t369 = call ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %t363, i64 %t366)
  store ptr %t369, ptr %l201
  br label %bb107
bb107:
  %t370 = load ptr, ptr %l201, !tbaa !29
  store ptr %t370, ptr %l31, !tbaa !29
  %t371 = load ptr, ptr %l31, !tbaa !29
  %t373 = icmp eq ptr %t371, null
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb108, label %bb109
bb108:
  %t377 = load ptr, ptr %l31, !tbaa !29
  store ptr %t377, ptr %rv
  br label %ret
bb109:
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t380 = load i64, ptr %l28, !tbaa !24
  %t382 = add i64 %t380, 1
  store i64 %t382, ptr %l28, !tbaa !24
  br label %bb103
bb112:
  %t384 = load ptr, ptr %l26, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Seq", ptr %t384, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = icmp eq ptr %t387, null
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb113, label %bb114
bb113:
  %t393 = load ptr, ptr %l26, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Seq", ptr %t393, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb115, label %bb116
bb114:
  br label %bb119
bb115:
  call void @__olang_check_failed(ptr @olang_loc_6e2453cb19a4d71d_88f1503d6cec0391)
  unreachable
bb116:
  br label %bb117
bb117:
  %t400 = load ptr, ptr %l26, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Seq", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t404 = load i64, ptr %l1, !tbaa !24
  %t407 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t403, i64 %t404)
  store ptr %t407, ptr %l219
  br label %bb118
bb118:
  %t408 = load ptr, ptr %l219, !tbaa !29
  store ptr %t408, ptr %rv
  br label %ret
bb119:
  store ptr null, ptr %rv
  br label %ret
bb120:
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t411 = load ptr, ptr %l221, !tbaa !29
  %t412 = icmp ne ptr %t411, null
  br i1 %t412, label %bb121, label %bb122
bb121:
  %t414 = load ptr, ptr %l221, !tbaa !29
  %t415 = load i64, ptr %t414, !range !{i64 0, i64 18}
  %t417 = icmp eq i64 %t415, 11
  store i1 %t417, ptr %l222, !tbaa !21
  br label %bb122
bb122:
  %t418 = load i1, ptr %l222, !tbaa !21
  br i1 %t418, label %bb123, label %bb124
bb123:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t421, i32 0, i32 2
  %t423 = load ptr, ptr %t422
  store ptr %t423, ptr %l32, !tbaa !29
  br label %bb125
bb124:
  br label %bb141
bb125:
  %t425 = load ptr, ptr %l32, !tbaa !29
  %t427 = getelementptr %"compiler/typed:Cond", ptr %t425, i32 0, i32 0
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t429 = load i64, ptr %l1, !tbaa !24
  %t432 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t428, i64 %t429)
  store ptr %t432, ptr %l230
  br label %bb126
bb126:
  %t433 = load ptr, ptr %l230, !tbaa !29
  store ptr %t433, ptr %l33, !tbaa !29
  %t434 = load ptr, ptr %l33, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb127, label %bb128
bb127:
  %t440 = load ptr, ptr %l33, !tbaa !29
  store ptr %t440, ptr %rv
  br label %ret
bb128:
  br label %bb129
bb129:
  %t443 = load ptr, ptr %l32, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Cond", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = icmp eq ptr %t446, null
  %t450 = xor i1 %t448, true
  br i1 %t450, label %bb130, label %bb131
bb130:
  %t452 = load ptr, ptr %l32, !tbaa !29
  %t454 = getelementptr %"compiler/typed:Cond", ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = icmp eq ptr %t455, null
  br i1 %t457, label %bb132, label %bb133
bb131:
  br label %bb139
bb132:
  call void @__olang_check_failed(ptr @olang_loc_a8e684701cb727b6_7b41502ddc5bea8a)
  unreachable
bb133:
  br label %bb134
bb134:
  %t459 = load ptr, ptr %l32, !tbaa !29
  %t461 = getelementptr %"compiler/typed:Cond", ptr %t459, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !29
  %t463 = load i64, ptr %l1, !tbaa !24
  %t466 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t462, i64 %t463)
  store ptr %t466, ptr %l246
  br label %bb135
bb135:
  %t467 = load ptr, ptr %l246, !tbaa !29
  store ptr %t467, ptr %l33, !tbaa !29
  %t468 = load ptr, ptr %l33, !tbaa !29
  %t470 = icmp eq ptr %t468, null
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb136, label %bb137
bb136:
  %t474 = load ptr, ptr %l33, !tbaa !29
  store ptr %t474, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  br label %bb139
bb139:
  %t477 = load ptr, ptr %l32, !tbaa !29
  %t479 = getelementptr %"compiler/typed:Cond", ptr %t477, i32 0, i32 2
  %t480 = load ptr, ptr %t479, !tbaa !29
  %t481 = load i64, ptr %l1, !tbaa !24
  %t484 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t480, i64 %t481)
  store ptr %t484, ptr %l255
  br label %bb140
bb140:
  %t485 = load ptr, ptr %l255, !tbaa !29
  store ptr %t485, ptr %rv
  br label %ret
bb141:
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t487 = load ptr, ptr %l256, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb142, label %bb143
bb142:
  %t490 = load ptr, ptr %l256, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 18}
  %t493 = icmp eq i64 %t491, 17
  store i1 %t493, ptr %l257, !tbaa !21
  br label %bb143
bb143:
  %t494 = load i1, ptr %l257, !tbaa !21
  br i1 %t494, label %bb144, label %bb145
bb144:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t497, i32 0, i32 2
  %t499 = load ptr, ptr %t498
  store ptr %t499, ptr %l34, !tbaa !29
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t501 = load ptr, ptr %l34, !tbaa !29
  %t502 = load i64, ptr %l1, !tbaa !24
  %t505 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t501, i64 %t502)
  store ptr %t505, ptr %l264
  br label %bb147
bb147:
  %t506 = load ptr, ptr %l264, !tbaa !29
  store ptr %t506, ptr %rv
  br label %ret
bb148:
  br i1 true, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  store ptr null, ptr %rv
  br label %ret
bb152:
  call void @__olang_check_failed(ptr @olang_loc_3e8b13b2a7075e62_22250d1a20f2250e)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2einElement(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb25
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2einElement(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l15
  br label %bb12
bb12:
  %t28 = load i1, ptr %l15, !tbaa !21
  store i1 %t28, ptr %l3, !tbaa !21
  br label %bb25
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 5
  store i1 %t36, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = getelementptr %"compiler/typed:Payload", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = call i1 @compiler_2ffree_2einElement(ptr %v0, ptr %t47)
  store i1 %t49, ptr %l24
  br label %bb19
bb19:
  %t50 = load i1, ptr %l24, !tbaa !21
  store i1 %t50, ptr %l3, !tbaa !21
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_ed7f6e6daad964a6_bdb604c7994d314a)
  unreachable
bb25:
  %t51 = load i1, ptr %l3, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eisBlock({ i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a0, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_5434155b39f9a43a_fb30a073eb5144de)
  unreachable
bb9:
  %t6 = load i1, ptr %l1, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2eisVar({ i64, [2 x i64] } %a0) #0 {
entry:
  %l1 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, [2 x i64] } %a0, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3f15d8a4ec391f6e_384039254c446aaa)
  unreachable
bb9:
  %t6 = load i1, ptr %l1, !tbaa !21
  store i1 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2emeet(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l13 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  %t13 = icmp eq i64 %t9, %t10
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t15 = load i64, ptr %l0, !tbaa !24
  store i64 %t15, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t17 = load i64, ptr %l0, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = icmp eq i64 %t17, %t18
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l0, !tbaa !24
  store i64 %t23, ptr %l13, !tbaa !24
  br label %bb9
bb8:
  %t25 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t25, ptr %l13, !tbaa !24
  br label %bb9
bb9:
  %t27 = load i64, ptr %l13, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2eprotocolName(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca [32 x { i64, ptr }]
  %l18 = alloca i1
  %l19 = alloca i1
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 0
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %t1
  %t2 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 1
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %t2
  %t3 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 2
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %t3
  %t4 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 3
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %t4
  %t5 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 4
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %t5
  %t6 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 5
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %t6
  %t7 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 6
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %t7
  %t8 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 7
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %t8
  %t9 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 8
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %t9
  %t10 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 9
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %t10
  %t11 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 10
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %t11
  %t12 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 11
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %t12
  %t13 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 12
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %t13
  %t14 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 13
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %t14
  %t15 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 14
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %t15
  %t16 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 15
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %t16
  %t17 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 16
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %t17
  %t18 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 17
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %t18
  %t19 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 18
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %t19
  %t20 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 19
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d74, i32 0, i32 1) }, ptr %t20
  %t21 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 20
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %t21
  %t22 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 21
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %t22
  %t23 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 22
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d77, i32 0, i32 1) }, ptr %t23
  %t24 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 23
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d78, i32 0, i32 1) }, ptr %t24
  %t25 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 24
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %t25
  %t26 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 25
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d80, i32 0, i32 1) }, ptr %t26
  %t27 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 26
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) }, ptr %t27
  %t28 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 27
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d82, i32 0, i32 1) }, ptr %t28
  %t29 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 28
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d83, i32 0, i32 1) }, ptr %t29
  %t30 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 29
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %t30
  %t31 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 30
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %t31
  %t32 = getelementptr [32 x { i64, ptr }], ptr %l5, i64 0, i64 31
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %t32
  %t33 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 512, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t33, ptr %l5, i64 512, i1 false)
  store ptr %t33, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t35 = load ptr, ptr %l1
  store i64 32, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t38 = load i64, ptr %l2, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb2, label %bb3
bb2:
  br label %bb32
bb3:
  br label %bb4
bb4:
  %t46 = load ptr, ptr %l1
  %t47 = load i64, ptr %l2, !tbaa !24
  %t50 = getelementptr [32 x { i64, ptr }], ptr %t46, i64 0, i64 %t47
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !37
  store { i64, ptr } %t51, ptr %l4, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t55 = load ptr, ptr @__olang_prog_scope
  %t58 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t55, { i64, ptr } %t53, { i64, ptr } %t54)
  store i1 %t58, ptr %l18
  br label %bb5
bb5:
  %t59 = load i1, ptr %l18, !tbaa !21
  br i1 %t59, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb27
bb7:
  %t60 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t68 = icmp eq i64 %t62, %t65
  br i1 %t68, label %bb8, label %bb9
bb8:
  %t70 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t70, ptr %l26, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t71, 0
  store i64 %t74, ptr %l29, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l30, !tbaa !24
  %t77 = icmp sge i64 1, 0
  br i1 %t77, label %bb10, label %bb11
bb9:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb23
bb10:
  %t79 = load i64, ptr %l29, !tbaa !24
  %t80 = icmp sle i64 1, %t79
  br i1 %t80, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_73f26af0fcc48e45_46c1c71f8da67531)
  unreachable
bb12:
  %t82 = load i64, ptr %l29, !tbaa !24
  %t83 = load i64, ptr %l30, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_73f26af0fcc48e45_46c1c71f8da67531)
  unreachable
bb14:
  %t86 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l29, !tbaa !24
  %t89 = getelementptr i8, ptr %t87, i64 1
  %t90 = sub i64 %t88, 1
  %t91 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t89, 1
  store { i64, ptr } %t92, ptr %l34, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l35, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t94, 0
  store i64 %t97, ptr %l38, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  store i64 %t99, ptr %l39, !tbaa !24
  %t100 = icmp sge i64 1, 0
  br i1 %t100, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_73f26af0fcc48e45_46c1c71f8da67531)
  unreachable
bb16:
  %t102 = load i64, ptr %l38, !tbaa !24
  %t103 = icmp sle i64 1, %t102
  br i1 %t103, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_73f26af0fcc48e45_46c1c71f8da67531)
  unreachable
bb18:
  %t105 = load i64, ptr %l38, !tbaa !24
  %t106 = load i64, ptr %l39, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  br i1 %t107, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_73f26af0fcc48e45_46c1c71f8da67531)
  unreachable
bb20:
  %t109 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l38, !tbaa !24
  %t112 = getelementptr i8, ptr %t110, i64 1
  %t113 = sub i64 %t111, 1
  %t114 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t112, 1
  %t116 = load ptr, ptr @__olang_prog_scope
  %t117 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t116, { i64, ptr } %t117, { i64, ptr } %t115)
  store i1 %t119, ptr %l44
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_73f26af0fcc48e45_46c1c71f8da67531)
  unreachable
bb22:
  %t120 = load i1, ptr %l44, !tbaa !21
  store i1 %t120, ptr %l25, !tbaa !21
  br label %bb23
bb23:
  %t121 = load i1, ptr %l25, !tbaa !21
  br i1 %t121, label %bb24, label %bb25
bb24:
  %t122 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t122, ptr %l46, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i8, ptr %t124, i64 0
  %t126 = load i8, ptr %t125, !tbaa !32
  %t127 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t127, ptr %l48, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i8, ptr %t129, i64 0
  %t131 = load i8, ptr %t130, !tbaa !32
  %t133 = add i8 %t131, 32
  %t136 = icmp eq i8 %t126, %t133
  store i1 %t136, ptr %l45, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb26
bb26:
  %t138 = load i1, ptr %l45, !tbaa !21
  store i1 %t138, ptr %l19, !tbaa !21
  br label %bb27
bb27:
  %t139 = load i1, ptr %l19, !tbaa !21
  br i1 %t139, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t141 = load i64, ptr %l2, !tbaa !24
  %t143 = add i64 %t141, 1
  store i64 %t143, ptr %l2, !tbaa !24
  br label %bb1
bb32:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb36
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb36
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb31
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  store ptr %t44, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l25, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = call i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %t59)
  store i1 %t61, ptr %l31
  br label %bb24
bb24:
  %t62 = load i1, ptr %l31, !tbaa !21
  store i1 %t62, ptr %l23, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_73267d5e0cab398e_8c6ff0bab5f15012)
  unreachable
bb30:
  %t63 = load i1, ptr %l23, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a4448d4b24e169cf_c9af2cff75b97a13)
  unreachable
bb36:
  %t64 = load i1, ptr %l4, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l9 = alloca i1
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l54 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i1, ptr %l9, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t9 = load ptr, ptr %l12, !tbaa !29
  %t10 = icmp ne ptr %t9, null
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l12, !tbaa !29
  %t13 = load i64, ptr %t12, !range !{i64 0, i64 18}
  %t15 = icmp eq i64 %t13, 2
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr { i64, [5 x i64] }, ptr %t17, i32 0, i32 1
  %t20 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t19, i32 0, i32 2
  %t21 = load ptr, ptr %t20
  store ptr %t21, ptr %l2, !tbaa !29
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l20
  br label %bb10
bb10:
  %t28 = load i1, ptr %l20, !tbaa !21
  store i1 %t28, ptr %l11, !tbaa !21
  br label %bb41
bb11:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t33 = load ptr, ptr %l21, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 18}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t37 = load i1, ptr %l22, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [5 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l3, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t48 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t44, ptr %t45)
  store i1 %t48, ptr %l29
  br label %bb17
bb17:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l11, !tbaa !21
  br label %bb41
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb19, label %bb20
bb19:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l4, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t69 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t65, ptr %t66)
  store i1 %t69, ptr %l38
  br label %bb24
bb24:
  %t70 = load i1, ptr %l38, !tbaa !21
  store i1 %t70, ptr %l11, !tbaa !21
  br label %bb41
bb25:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t72 = load ptr, ptr %l39, !tbaa !29
  %t73 = icmp ne ptr %t72, null
  br i1 %t73, label %bb26, label %bb27
bb26:
  %t75 = load ptr, ptr %l39, !tbaa !29
  %t76 = load i64, ptr %t75, !range !{i64 0, i64 18}
  %t78 = icmp eq i64 %t76, 9
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t79 = load i1, ptr %l40, !tbaa !21
  br i1 %t79, label %bb28, label %bb29
bb28:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr { i64, [5 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t82, i32 0, i32 2
  %t84 = load i32, ptr %t83, !range !{i32 0, i32 52}
  store i32 %t84, ptr %l5
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t88, i32 0, i32 4
  %t90 = load { i64, ptr }, ptr %t89
  store { i64, ptr } %t90, ptr %l6, !tbaa !27
  br label %bb30
bb29:
  br label %bb36
bb30:
  %t92 = load i32, ptr %l5, !range !{i32 0, i32 52}
  %t93 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %t92, { i64, ptr } %t93)
  store i1 %t96, ptr %l49
  br label %bb31
bb31:
  %t97 = load i1, ptr %l49, !tbaa !21
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t98 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t98, ptr %l51, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr ptr, ptr %t100, i64 0
  %t102 = load ptr, ptr %t101, !tbaa !39
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t106 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l54
  br label %bb34
bb33:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb35
bb34:
  %t107 = load i1, ptr %l54, !tbaa !21
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb35
bb35:
  %t108 = load i1, ptr %l50, !tbaa !21
  store i1 %t108, ptr %l11, !tbaa !21
  br label %bb41
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_365b62d925fe4616_77c77337a4accaaa)
  unreachable
bb41:
  %t109 = load i1, ptr %l11, !tbaa !21
  store i1 %t109, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l0 = alloca %"compiler/source:Span"
  %l1 = alloca %"compiler/source:Span"
  %l5 = alloca i1
  %rv = alloca i1
  store %"compiler/source:Span" %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t3 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  %t7 = icmp sge i32 %t2, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr %"compiler/source:Span", ptr %l0, i32 0, i32 1
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t12 = load i32, ptr %t11, !tbaa !23
  %t15 = icmp sle i32 %t10, %t12
  store i1 %t15, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l5, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ewholeCopySite(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 4 to i32
  %t22 = icmp eq i32 %t19, %t21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Make", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l13, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l13, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Make", ptr %t34, i32 0, i32 2
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l20, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr ptr, ptr %t39, i64 0
  %t41 = load ptr, ptr %t40, !tbaa !39
  %t43 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l22
  br label %bb11
bb10:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb12
bb11:
  %t44 = load i64, ptr %l22, !tbaa !24
  %t45 = icmp sge i64 %t44, 0
  store i1 %t45, ptr %l18, !tbaa !21
  br label %bb12
bb12:
  %t47 = load i1, ptr %l18, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Make", ptr %t48, i32 0, i32 4
  %t51 = load i32, ptr %t50, !tbaa !23
  %t53 = sext i32 %t51 to i64
  store i64 %t53, ptr %l24, !tbaa !24
  br label %bb15
bb14:
  store i64 -1, ptr %l24, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l24, !tbaa !24
  store i64 %t55, ptr %l3, !tbaa !24
  br label %bb28
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = icmp ne ptr %t57, null
  br i1 %t58, label %bb17, label %bb18
bb17:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %t60, !range !{i64 0, i64 18}
  %t63 = icmp eq i64 %t61, 17
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t64 = load i1, ptr %l29, !tbaa !21
  br i1 %t64, label %bb19, label %bb20
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr { i64, [5 x i64] }, ptr %t65, i32 0, i32 1
  %t68 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t67, i32 0, i32 2
  %t69 = load ptr, ptr %t68
  store ptr %t69, ptr %l2, !tbaa !29
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t71 = load ptr, ptr %l2, !tbaa !29
  %t73 = call i64 @compiler_2ffree_2ewholeCopySite(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l35
  br label %bb22
bb22:
  %t74 = load i64, ptr %l35, !tbaa !24
  store i64 %t74, ptr %l3, !tbaa !24
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ab601f37ca7d11ca_d79a21710a30c0d6)
  unreachable
bb28:
  %t75 = load i64, ptr %l3, !tbaa !24
  store i64 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t28 = call i1 @compiler_2ffree_2estmtMoves(ptr %v0, ptr %t24)
  store i1 %t28, ptr %l17
  br label %bb5
bb5:
  %t29 = load i1, ptr %l17, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/free:feedCall" @compiler_2ffree_3afeedCall_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i1 %a5) #0 {
entry:
  %rv = alloca %"compiler/free:feedCall"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/free:feedCall" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/free:feedCall" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/free:feedCall" %t16, i64 %a2, 2
  %t20 = insertvalue %"compiler/free:feedCall" %t18, i64 %a3, 3
  %t22 = insertvalue %"compiler/free:feedCall" %t20, i64 %a4, 4
  %t24 = insertvalue %"compiler/free:feedCall" %t22, i1 %a5, 5
  store %"compiler/free:feedCall" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:feedCall", ptr %rv
  ret %"compiler/free:feedCall" %rr
}

define dso_local %"compiler/free:feed" @compiler_2ffree_3afeed_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, { i64, [2 x i64] } %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %rv = alloca %"compiler/free:feed"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/free:feed" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/free:feed" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/free:feed" %t16, i64 %a2, 2
  %t20 = insertvalue %"compiler/free:feed" %t18, i64 %a3, 3
  %t22 = insertvalue %"compiler/free:feed" %t20, { i64, [2 x i64] } %a4, 4
  %t24 = insertvalue %"compiler/free:feed" %t22, { i64, [2 x i64] } %a5, 5
  %t26 = insertvalue %"compiler/free:feed" %t24, i64 -1, 6
  store %"compiler/free:feed" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:feed", ptr %rv
  ret %"compiler/free:feed" %rr
}

define dso_local %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %v0, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/free:leaf" undef, { i64, ptr } %a0, 0
  %t8 = insertvalue %"compiler/free:leaf" %t6, i64 %a1, 1
  store %"compiler/free:leaf" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

define dso_local %"compiler/free:reason" @compiler_2ffree_3areason_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/free:reason"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/free:reason" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/free:reason" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/free:reason" %t12, %"compiler/source:Span" %a2, 2
  %t16 = insertvalue %"compiler/free:reason" %t14, { i64, ptr } %a3, 3
  store %"compiler/free:reason" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:reason", ptr %rv
  ret %"compiler/free:reason" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d0 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"free: " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d1 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" bodies, " }>, align 8
@.d2 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c" places; must " }>, align 8
@.d3 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" bodies " }>, align 8
@.d4 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" ms; may " }>, align 8
@.d5 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" walks " }>, align 8
@.d6 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" passes " }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d8 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"free: final " }>, align 8
@.d9 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms, " }>, align 8
@.d10 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c" let-goes, " }>, align 8
@.d11 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" stores; decide " }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d13 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"memory: the arrays a " }>, align 8
@.d14 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c" holds in place are kept until their scope closes\0A" }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d16 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"memory: the arrays a " }>, align 8
@.d17 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c" holds in place are put back with it, unless a view of one is in use\0A" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d18 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c": memory: '" }>, align 8
@.d19 = private constant <{ i64, [64 x i8] }> <{ i64 0, [64 x i8] c"' keeps the arrays of what it reclaims until their scope closes\0A" }>, align 8
@.d20 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c": note: '" }>, align 8
@.d21 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"', which may view one, is in use across this call\0A" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"its elements" }>, align 8
@.d27 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"a task can reach it: nothing is freed early where a program has tasks" }>, align 8
@.d28 = private constant <{ i64, [130 x i8] }> <{ i64 0, [130 x i8] c"C may call an export fn from a thread of its own: nothing is freed early where C is given one, links C of its own, or is a library" }>, align 8
@.d29 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"a destructor, Str, Eq or Hash lets go of it where no call is written" }>, align 8
@.d30 = private constant <{ i64, [144 x i8] }> <{ i64 0, [144 x i8] c"its new value may hold an instance whose destructor is still to run (O16), which a let-go would run early: build that instance outside the value" }>, align 8
@.d31 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"a value built into what it holds may hold an instance whose destructor is still to run (O16)" }>, align 8
@.d32 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"a call building into what it holds may register an instance whose destructor is still to run (O16)" }>, align 8
@olang_2esole_2ecompiler_2ffree_3areason_2e3 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d33 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"what is built for it is changed by a call that cannot build where it is: '" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d35 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"its new value cannot be built in a region of its own here" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d36 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"its new value is built where another place's is" }>, align 8
@.d37 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"what it holds has a destructor still to run when it lets go (O15): its holder ends it" }>, align 8
@.d38 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"what holds it is an owner held in a place of early freeing, whose storage is one region" }>, align 8
@.d39 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"its new value is moved out of a place that keeps" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d41 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d42 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"a generator holds a reference that may reach one across a yield" }>, align 8
@.d43 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"a lambda captures a reference that may reach one" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d44 = private constant <{ i64, [123 x i8] }> <{ i64 0, [123 x i8] c"what it holds is generational - a weak reference names its type - and is let go of by the count of its owning places (T13d)" }>, align 8
@.d45 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"note: " }>, align 8
@.d46 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c": note: " }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ffree_3aleaf_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@.d47 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
@.d48 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
@.d49 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"a writable reference to it handed to a call" }>, align 8
@.d50 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"a call's value copied" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d54 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d56 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Iter" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Next" }>, align 8
@.d61 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"RunFrom" }>, align 8
@.d62 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"At" }>, align 8
@.d63 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"SetAt" }>, align 8
@.d64 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d65 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Has" }>, align 8
@.d66 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Contains" }>, align 8
@.d67 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d68 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
@.d69 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Less" }>, align 8
@.d70 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Plus" }>, align 8
@.d71 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Minus" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Mul" }>, align 8
@.d73 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Div" }>, align 8
@.d74 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Rem" }>, align 8
@.d75 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"MatMul" }>, align 8
@.d76 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Neg" }>, align 8
@.d77 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Pow" }>, align 8
@.d78 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitAnd" }>, align 8
@.d79 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"BitOr" }>, align 8
@.d80 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitXor" }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Shl" }>, align 8
@.d82 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Shr" }>, align 8
@.d83 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"BitNot" }>, align 8
@.d84 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inc" }>, align 8
@.d85 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Dec" }>, align 8
@.d86 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"FromIter" }>, align 8
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %rv = alloca { i64, ptr }
  %t16 = alloca %"compiler/typed:Plan", align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 568
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/typed:Plan", ptr %t14, i64 %t12
  call void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %t16, ptr %v0, ptr %t15)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %t16, i64 568, i1 false)
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr %"compiler/typed:Plan", ptr %t21, i64 %t19
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %l6, i64 568, i1 false)
  %t23 = load i64, ptr %l3, !tbaa !24
  %t24 = add i64 %t23, 1
  store i64 %t24, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2ffree_3aleaf_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/free:leaf"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 24
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/free:leaf", ptr %t14, i64 %t12
  %t17 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %t15)
  store %"compiler/free:leaf" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/free:leaf", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/free:leaf", ptr %t22, i64 %t20
  store %"compiler/free:leaf" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr void @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ftyped_3aPlan(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/typed:Plan"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 568, i1 false)
  %t2 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  %t29 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %t27)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  %t31 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t30, ptr %t31
  %t32 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t32)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t36 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %t36
  %t37 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %t37)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t41 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %t41
  %t42 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/typed:Plan", ptr %l1, i32 0, i32 22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 568, i1 false)
  br label %ret
ret:
  ret void
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aScope_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H37dabf8663d733dfb3cf8a6ba127be58(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t10 = load { i64, ptr }, ptr %t9, !tbaa !27
  store { i64, ptr } %t10, ptr %l4, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t14 = mul i64 %t13, 8
  %t15 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l6, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = mul i64 %t22, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t25 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t24, ptr %t25, !tbaa !27
  %t26 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l8, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l9, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = mul i64 %t39, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t42 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  %t43 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t43, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec__Hdbcf217951d8a5e6be477b9bbf1b3074(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std__Hc31c075a081277beb11a6149e950d3c3(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %t15)
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t22, i64 %t20
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelud_Hc8a994261b444ea12c5b83da9413a98f(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %a0
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %l1
  store %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %rv
  ret %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aDerivedArg_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 40
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 40
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_Ha270003b2266a12c55eea6eacf9a4be1(ptr %v0, ptr %a0)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_H3054d603499f3fef5e3f6df62ca84cee(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cI64_2c_20std_2fprelude_2ftext_3_H9d7da39dd81a932fb2b877accbcd070c(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/map:MapKeyIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_Hc20348a7e3f4966d079d7d53957fcef1(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapKeyIter_3cstd_2fprelude_2ftext_3aString_2_H25a1fa74df5469e35efe3ff4130517ef(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20Boo_H6b1fa5c8028973ecd947936aac3caef3(ptr %v0, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eAnyLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eaddBody(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_873f02c5d3f91a6b_c0b0bcdb30583717 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2ftime_2eNow()
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesFirst(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_cfa78d5b759fffbc_7789424fbd23b3b0 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emustFixedPoint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayFixedPoint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehiddenLetGo(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewalk(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eclassifyHolders(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenDecide(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_26303021143ae8be_4bef98a84a02e70a = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2ePartOfGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eletsLeaves(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftyped_2eViewOther = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\40" }>, align 8
declare i1 @compiler_2ftyped_2eViewsMoved(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_cd034f3e3abc884f_abc13ef4de953fab = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eHas_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8e98c88bf995f5b7_6ee5e17bac1969d3 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_77e2c420ac7907a9_804235f2ad53d = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_834ee64634399a9c_46784e5d37862958 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eLen_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:feedCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eAt_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRInPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
@olang_loc_dcc3c6712d01991_ec14a6947a12b86d = external constant [0 x i8]
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eouterFirst(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1c3c578240008a_e9f41163a0859586 = external constant [0 x i8]
@olang_loc_66d907e33dd98677_4991ee91581ac48b = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eRCopied = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_1c505c1b55d06586_a0a7e4d6315dd1d2 = external constant [0 x i8]
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eLen_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_7bd178b281ab108b_bca5961225cfb287 = external constant [0 x i8]
@olang_loc_54a8cb88ede7d99c_f1d49282556d5568 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_df2621a9cc7e5891_c8dc80a57ad57a3d = external constant [0 x i8]
@olang_loc_d176219a3bee3f8a_90c874c8f8700e56 = external constant [0 x i8]
@olang_loc_3832ed25f787c577_46d12f44adcfa45b = external constant [0 x i8]
@olang_loc_78b7d87e61167558_7d12aa6674d4d96c = external constant [0 x i8]
@olang_loc_5c0fdc79e2d66a14_68e7480db742a728 = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2ftyped_2eLastCopies(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eLen_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_1a9841d5ac3bc9f7_8d61e2fce1a4aee3 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedBlock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4)
@olang_loc_51b1502f0d390a1a_ce0c44316c965fde = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efuncTy(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenPlace(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2egenNeverText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c5e41b8fc96972ee_4e89d8a2bd660d32 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eRView = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He7b3466db9a608577543dd7c0832d3d6(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H39ca684a9144c6cba1af5dc2ea7b2e34(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_He39f97315596c9568e753bccdda19b63(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_8d4a0f6b46bd0ce9_6c774f94eb5bbfbd = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_ec4c329f8a2f93df_8cb0fdf9b7b252db = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_fc2fcdbc2f007840_c2f2791b7eb787ec = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etryMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f9703b3e8b4d3f8c_114f0f1572d2eea8 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c329a7357b4632ae_1972f4ce8b92321a = external constant [0 x i8]
@olang_loc_ce4a56608212b1d3_28564c72fb26107 = external constant [0 x i8]
@olang_loc_8c3ff88e405c7c2b_15d3403d537d031f = external constant [0 x i8]
declare i64 @compiler_2ffree_2eokind(i64 %a0)
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOParC = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOUnk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eoval(i64 %a0)
declare void @compiler_2ffree_3amustW_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_1d9a56a827ed845f_5cc839dbc781b743 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_Ha64a825bb0b4fc6c7596ac96329c2853(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eReach(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fmir_2eReachNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eReachAny = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_98179ed2ec661f5d_533fcebe8f905861 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hcb8bb928db85b876b7f95fc01a2ef730(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [2 x i64] } %a3)
@olang_loc_21335a5a6f6a0d23_1fb4d5f27249eebf = external constant [0 x i8]
@olang_loc_80551b5782bfdb3b_907a9dbefd6aabe7 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eonlyLeaf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitPath(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H58704f470d09c6c466fe07940700ab7b(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, { i64, ptr } %a2)
@olang_loc_2a5f6fd698855c53_bf46ca1a958c9ea7 = external constant [0 x i8]
@olang_loc_4959d0728bd157ab_d85fd94b6e31a9bf = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_4acb4c8921e8c407_808d59af97a4073 = external constant [0 x i8]
declare i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_d1dd1febe39b41f_df28cb247c1abe4b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftypes_2eFromTypeVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_7a954698926d7de_664d4c02e090fa22 = external constant [0 x i8]
@olang_loc_893474d063c17328_1c44af56cc3f848c = external constant [0 x i8]
@olang_loc_a532406d51285a24_27441d0f137c6648 = external constant [0 x i8]
@olang_loc_1777536395e8cd8b_97ff53b4c3030f1f = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epassesVar(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2ftyped_2eNoCallbackExtern(ptr %v0, { i64, ptr } %a0)
@olang_loc_ec84fe6443685676_e22a9bc60a48a0b2 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeederArg(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2ePush_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %a0, %"compiler/free:feedCall" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efreshCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %a0)
declare i64 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eViewOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fmir_2eViewNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estoredMore(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2evalueCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5)
@olang_loc_d4fc5cdd71cd4f17_b1c92b5edf644a33 = external constant [0 x i8]
@olang_loc_e32699ce7a94654a_1a46213a714ace46 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/free:orCall" @compiler_2ffree_3aorCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, ptr %a5, ptr %a6)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2ePush_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:orCall" %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_f81460935a0747e6_f4792861f5ca2502 = external constant [0 x i8]
@olang_loc_e3a1bae50be73c47_b8cb15515377d683 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eletsThrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3, i1 %a4, %"compiler/source:Span" %a5)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescThrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4)
@olang_loc_228ad70617d44d77_1dee412aac6cbab = external constant [0 x i8]
@olang_loc_5e2122fa9519644f_a9d9059c63542dd3 = external constant [0 x i8]
@olang_loc_c3fd4e13fe372032_611898922dc4483e = external constant [0 x i8]
@olang_loc_16263ed1acd4aa7e_23dcb8f717a142b2 = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ea2e0f0d6ffcb248_fe73fa1c8e55849c = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6e2453cb19a4d71d_88f1503d6cec0391 = external constant [0 x i8]
@olang_loc_a8e684701cb727b6_7b41502ddc5bea8a = external constant [0 x i8]
@olang_loc_3e8b13b2a7075e62_22250d1a20f2250e = external constant [0 x i8]
@olang_loc_ed7f6e6daad964a6_bdb604c7994d314a = external constant [0 x i8]
@olang_loc_5434155b39f9a43a_fb30a073eb5144de = external constant [0 x i8]
@olang_loc_3f15d8a4ec391f6e_384039254c446aaa = external constant [0 x i8]
@olang_loc_73f26af0fcc48e45_46c1c71f8da67531 = external constant [0 x i8]
@olang_loc_73267d5e0cab398e_8c6ff0bab5f15012 = external constant [0 x i8]
@olang_loc_a4448d4b24e169cf_c9af2cff75b97a13 = external constant [0 x i8]
declare i1 @compiler_2ffree_2esamePure(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_365b62d925fe4616_77c77337a4accaaa = external constant [0 x i8]
declare i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0)
@olang_loc_ab601f37ca7d11ca_d79a21710a30c0d6 = external constant [0 x i8]
declare i1 @compiler_2ffree_2estmtMoves(ptr %v0, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
