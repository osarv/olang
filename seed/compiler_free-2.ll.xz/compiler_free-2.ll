; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/free:Free" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, i1 }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { ptr, ptr }, { ptr, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, i64, i1, %"compiler/typed:Plan", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [2 x i64] }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, { i64, [2 x i64] }, i1, i1, i1, i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, i64, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
define dso_local void @compiler_2ffree_2eLDrop_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ffree_2eLDrop, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLLeaf_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eLVacate_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eMovBase_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1073741824, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRDtor_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eRView_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2ffree_2eRView, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eSFresh_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 1, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2eSOk_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDroppedMove(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i1
  %l17 = alloca ptr
  %l25 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 67
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t9, ptr %a1)
  store i64 %t13, ptr %l10
  br label %bb4
bb4:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb8
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:Free", ptr %t19, i32 0, i32 1
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t21, i64 %t22)
  store ptr %t25, ptr %l17
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l17, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Body", ptr %t26, i32 0, i32 11
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  store i1 %t31, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t33 = load i1, ptr %l13, !tbaa !21
  br i1 %t33, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 26
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  store i64 %t41, ptr %l25
  br label %bb12
bb12:
  %t42 = load i64, ptr %l25, !tbaa !24
  store i64 %t42, ptr %l3, !tbaa !24
  %t43 = load i64, ptr %l3, !tbaa !24
  %t44 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  br i1 %t47, label %bb13, label %bb14
bb13:
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  %t52 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t58 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t50, i64 %t55)
  store i1 %t58, ptr %l34
  br label %bb16
bb16:
  %t59 = load i1, ptr %l34, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t61 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t64 = sub i64 %t60, %t61
  store i64 %t64, ptr %l35, !tbaa !24
  br label %bb19
bb18:
  store i64 -1, ptr %l35, !tbaa !24
  br label %bb19
bb19:
  %t66 = load i64, ptr %l35, !tbaa !24
  store i64 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDump(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"compiler/free:letGo"
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/free:store"
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"compiler/free:store"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"compiler/free:letGo"
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca ptr
  %l47 = alloca i64
  %l51 = alloca i64
  %l54 = alloca i64
  %l74 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l87 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l115 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l136 = alloca { ptr, ptr }
  %l140 = alloca i32
  %l141 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l146 = alloca i32
  %l147 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca i64
  %l151 = alloca { i64, ptr }
  %l155 = alloca i64
  %l159 = alloca i1
  %l160 = alloca { i64, ptr }
  %l163 = alloca i1
  %l164 = alloca i64
  %l165 = alloca i64
  %l169 = alloca i64
  %l173 = alloca %"compiler/free:reason"
  %l181 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca i32
  %l194 = alloca { i64, ptr }
  %l197 = alloca ptr
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i64
  %l201 = alloca i64
  %l209 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l223 = alloca i32
  %l232 = alloca { i64, ptr }
  %l235 = alloca ptr
  %l236 = alloca i64
  %l237 = alloca i64
  %l238 = alloca i64
  %l246 = alloca { i64, ptr }
  %l249 = alloca { i64, ptr }
  %l259 = alloca i64
  %l263 = alloca i64
  %l266 = alloca i64
  %l287 = alloca ptr
  %l288 = alloca i64
  %l290 = alloca i1
  %l294 = alloca ptr
  %l295 = alloca i64
  %l297 = alloca i1
  %l301 = alloca ptr
  %l302 = alloca i64
  %l304 = alloca ptr
  %l305 = alloca i64
  %l308 = alloca { i64, ptr }
  %l312 = alloca ptr
  %l316 = alloca ptr
  %l320 = alloca ptr
  %l324 = alloca ptr
  %l329 = alloca { i64, ptr }
  %l341 = alloca { i64, ptr }
  %l342 = alloca { i64, ptr }
  %l343 = alloca i64
  %l344 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s29 = alloca %olang.builder
  %s29room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l42
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l42
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t3)
  store ptr %t5, ptr %l44
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l44, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 8
  %t11 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l47
  br label %bb3
bb3:
  %t12 = load i64, ptr %l47, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l54, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l54, !tbaa !24
  store i64 %t39, ptr %l51, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l51, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb67
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 35
  store ptr %t61, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load ptr, ptr %l10, !tbaa !29
  %t64 = load i64, ptr %l11, !tbaa !24
  %t67 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t63, i64 %t64)
  %t68 = extractvalue { i32, { i64, ptr } } %t67, 1
  %t69 = extractvalue { i32, { i64, ptr } } %t67, 0
  store i32 %t69, ptr %l78
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb16, label %ok.71
ok.71:
  store { i64, ptr } %t68, ptr %l77
  br label %bb15
bb15:
  %t72 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t72, ptr %l74, !tbaa !27
  br label %bb20
bb16:
  %t73 = load i32, ptr %l78, !tbaa !23
  %t74 = ashr i32 %t73, 16
  %t76 = icmp eq i32 %t74, 1
  br i1 %t76, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_bd50611d1e2a0638_e097f182a5e2b38c)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb20:
  %t78 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t78, ptr %l12, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  store i64 %t81, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load i64, ptr %l14, !tbaa !24
  %t84 = load i64, ptr %l13, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t91 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t91, ptr %l87, !tbaa !27
  %t92 = load i64, ptr %l14, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr %"compiler/free:letGo", ptr %t95, i64 %t92
  %t97 = load %"compiler/free:letGo", ptr %t96
  store %"compiler/free:letGo" %t97, ptr %l15
  %t99 = getelementptr %"compiler/free:letGo", ptr %l15, i32 0, i32 0
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = icmp eq i64 %t100, %t101
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l9, !tbaa !24
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t110 = load i64, ptr %l14, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l14, !tbaa !24
  br label %bb21
bb29:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = add i64 %t114, %t115
  store i64 %t118, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  br label %bb14
bb31:
  store i64 0, ptr %l16, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/free:Free", ptr %t120, i32 0, i32 34
  store ptr %t122, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s9
  %t124 = load ptr, ptr %l17, !tbaa !29
  %t125 = load i64, ptr %l18, !tbaa !24
  %t128 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t124, i64 %t125)
  %t129 = extractvalue { i32, { i64, ptr } } %t128, 1
  %t130 = extractvalue { i32, { i64, ptr } } %t128, 0
  store i32 %t130, ptr %l106
  %t131 = icmp ne i32 %t130, 0
  br i1 %t131, label %bb34, label %ok.132
ok.132:
  store { i64, ptr } %t129, ptr %l105
  br label %bb33
bb33:
  %t133 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t133, ptr %l102, !tbaa !27
  br label %bb38
bb34:
  %t134 = load i32, ptr %l106, !tbaa !23
  %t135 = ashr i32 %t134, 16
  %t137 = icmp eq i32 %t135, 1
  br i1 %t137, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_c2d5333a05d32c09_964b2d9d99056abd)
  unreachable
bb37:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb49
bb38:
  %t139 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t139, ptr %l19, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t140, 0
  store i64 %t142, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  %t144 = load i64, ptr %l21, !tbaa !24
  %t145 = load i64, ptr %l20, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s10)
  br label %bb47
bb41:
  br label %bb42
bb42:
  %t152 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t152, ptr %l115, !tbaa !27
  %t153 = load i64, ptr %l21, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr %"compiler/free:store", ptr %t156, i64 %t153
  %t158 = load %"compiler/free:store", ptr %t157
  store %"compiler/free:store" %t158, ptr %l22
  %t160 = getelementptr %"compiler/free:store", ptr %l22, i32 0, i32 0
  %t161 = load i64, ptr %t160, !tbaa !24
  %t162 = load i64, ptr %l8, !tbaa !24
  %t165 = icmp eq i64 %t161, %t162
  br i1 %t165, label %bb43, label %bb44
bb43:
  %t167 = load i64, ptr %l16, !tbaa !24
  %t169 = add i64 %t167, 1
  store i64 %t169, ptr %l16, !tbaa !24
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb46
bb46:
  %t171 = load i64, ptr %l21, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l21, !tbaa !24
  br label %bb39
bb47:
  %t175 = load i64, ptr %l18, !tbaa !24
  %t176 = load i64, ptr %l20, !tbaa !24
  %t179 = add i64 %t175, %t176
  store i64 %t179, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb48:
  br label %bb32
bb49:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/free:Free", ptr %t181, i32 0, i32 2
  %t184 = load ptr, ptr %t183, !tbaa !29
  %t186 = getelementptr %"compiler/scope:Scoper", ptr %t184, i32 0, i32 5
  %t187 = load { ptr, ptr }, ptr %t186
  %t189 = extractvalue { ptr, ptr } %t187, 0
  %t190 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t191 = icmp eq ptr %t189, %t190
  %t192 = extractvalue { ptr, ptr } %t187, 1
  %t193 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t194 = icmp eq ptr %t192, %t193
  %t195 = and i1 %t191, %t194
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb50, label %bb51
bb50:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/free:Free", ptr %t199, i32 0, i32 2
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/scope:Scoper", ptr %t202, i32 0, i32 5
  %t205 = load { ptr, ptr }, ptr %t204
  store { ptr, ptr } %t205, ptr %l136
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/free:Free", ptr %t206, i32 0, i32 8
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t208, i64 %t209)
  store i32 %t212, ptr %l140
  br label %bb52
bb51:
  %t213 = load ptr, ptr %l2, !tbaa !29
  store ptr %t213, ptr %l142, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/free:Free", ptr %t214, i32 0, i32 8
  %t217 = load i64, ptr %l8, !tbaa !24
  %t220 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t216, i64 %t217)
  store i32 %t220, ptr %l146
  br label %bb54
bb52:
  %t221 = load { ptr, ptr }, ptr %l136
  %t222 = extractvalue { ptr, ptr } %t221, 0
  %t223 = extractvalue { ptr, ptr } %t221, 1
  %t224 = load i32, ptr %l140, !tbaa !23
  %t225 = call { i64, ptr } %t222(ptr %t223, ptr %s2, i32 %t224)
  store { i64, ptr } %t225, ptr %l141
  br label %bb53
bb53:
  %t226 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t226, ptr %l133, !tbaa !27
  br label %bb56
bb54:
  %t227 = load ptr, ptr %l142, !tbaa !29
  %t228 = load i32, ptr %l146, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t227, i32 %t228)
  store { i64, ptr } %t229, ptr %l147
  br label %bb55
bb55:
  %t230 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 1
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t231, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l133, !tbaa !27
  br label %bb56
bb56:
  %t237 = load { i64, ptr }, ptr %l133, !tbaa !27
  store ptr %l1, ptr %l149, !tbaa !29
  %t238 = load i64, ptr %l8, !tbaa !24
  store i64 %t238, ptr %l150, !tbaa !24
  store { i64, ptr } %t237, ptr %l151, !tbaa !27
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/free:Free", ptr %t240, i32 0, i32 9
  %t243 = load i64, ptr %l8, !tbaa !24
  %t246 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t242, i64 %t243)
  store i64 %t246, ptr %l155
  br label %bb57
bb57:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/free:Free", ptr %t247, i32 0, i32 10
  %t250 = load i64, ptr %l8, !tbaa !24
  %t253 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t249, i64 %t250)
  store i1 %t253, ptr %l159
  br label %bb58
bb58:
  %t254 = load i1, ptr %l159, !tbaa !21
  br i1 %t254, label %bb59, label %bb60
bb59:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l160, !tbaa !27
  br label %bb61
bb60:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l160, !tbaa !27
  br label %bb61
bb61:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l8, !tbaa !24
  %t259 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t255, i64 %t256)
  store i1 %t259, ptr %l163
  br label %bb62
bb62:
  %t260 = load i64, ptr %l9, !tbaa !24
  store i64 %t260, ptr %l164, !tbaa !24
  %t261 = load i64, ptr %l16, !tbaa !24
  store i64 %t261, ptr %l165, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/free:Free", ptr %t262, i32 0, i32 36
  %t265 = load i64, ptr %l8, !tbaa !24
  %t268 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t264, i64 %t265)
  store i64 %t268, ptr %l169
  br label %bb63
bb63:
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t271 = getelementptr %"compiler/free:Free", ptr %t269, i32 0, i32 38
  %t272 = load i64, ptr %l8, !tbaa !24
  %t275 = call %"compiler/free:reason" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t271, i64 %t272)
  store %"compiler/free:reason" %t275, ptr %l173
  br label %bb64
bb64:
  %t276 = getelementptr %"compiler/free:reason", ptr %l173, i32 0, i32 3
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  %t278 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t279 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t280 = load i64, ptr %l150, !tbaa !24
  %t281 = call i64 @__olang_fmt_i64(ptr null, i64 %t280)
  %t282 = add i64 %t279, %t281
  %t283 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = add i64 %t285, %t288
  %t290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t291 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t292 = add i64 %t289, %t291
  %t293 = load i64, ptr %l155, !tbaa !24
  %t294 = call i64 @__olang_fmt_i64(ptr null, i64 %t293)
  %t295 = add i64 %t292, %t294
  %t296 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = extractvalue { i64, ptr } %t296, 0
  %t299 = add i64 %t295, %t298
  %t300 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t302 = add i64 %t299, %t301
  %t303 = load i1, ptr %l163, !tbaa !21
  %t304 = select i1 %t303, ptr @.c6, ptr @.c7
  %t305 = select i1 %t303, i64 4, i64 5
  %t306 = add i64 %t302, %t305
  %t307 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t308 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t309 = add i64 %t306, %t308
  %t310 = load i64, ptr %l164, !tbaa !24
  %t311 = call i64 @__olang_fmt_i64(ptr null, i64 %t310)
  %t312 = add i64 %t309, %t311
  %t313 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t315 = add i64 %t312, %t314
  %t316 = load i64, ptr %l165, !tbaa !24
  %t317 = call i64 @__olang_fmt_i64(ptr null, i64 %t316)
  %t318 = add i64 %t315, %t317
  %t319 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t321 = add i64 %t318, %t320
  %t322 = load i64, ptr %l169, !tbaa !24
  %t323 = call i64 @__olang_fmt_i64(ptr null, i64 %t322)
  %t324 = add i64 %t321, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t329 = extractvalue { i64, ptr } %t277, 1
  %t330 = extractvalue { i64, ptr } %t277, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t334)
  call void @olang_textcopy(ptr %t335, ptr %t278, i64 %t279)
  %t336 = getelementptr i8, ptr %t335, i64 %t279
  %t337 = call i64 @__olang_fmt_i64(ptr %t336, i64 %t280)
  %t338 = getelementptr i8, ptr %t336, i64 %t281
  call void @olang_textcopy(ptr %t338, ptr %t283, i64 %t284)
  %t339 = getelementptr i8, ptr %t338, i64 %t284
  call void @olang_textcopy(ptr %t339, ptr %t287, i64 %t288)
  %t340 = getelementptr i8, ptr %t339, i64 %t288
  call void @olang_textcopy(ptr %t340, ptr %t290, i64 %t291)
  %t341 = getelementptr i8, ptr %t340, i64 %t291
  %t342 = call i64 @__olang_fmt_i64(ptr %t341, i64 %t293)
  %t343 = getelementptr i8, ptr %t341, i64 %t294
  call void @olang_textcopy(ptr %t343, ptr %t297, i64 %t298)
  %t344 = getelementptr i8, ptr %t343, i64 %t298
  call void @olang_textcopy(ptr %t344, ptr %t300, i64 %t301)
  %t345 = getelementptr i8, ptr %t344, i64 %t301
  call void @olang_textcopy(ptr %t345, ptr %t304, i64 %t305)
  %t346 = getelementptr i8, ptr %t345, i64 %t305
  call void @olang_textcopy(ptr %t346, ptr %t307, i64 %t308)
  %t347 = getelementptr i8, ptr %t346, i64 %t308
  %t348 = call i64 @__olang_fmt_i64(ptr %t347, i64 %t310)
  %t349 = getelementptr i8, ptr %t347, i64 %t311
  call void @olang_textcopy(ptr %t349, ptr %t313, i64 %t314)
  %t350 = getelementptr i8, ptr %t349, i64 %t314
  %t351 = call i64 @__olang_fmt_i64(ptr %t350, i64 %t316)
  %t352 = getelementptr i8, ptr %t350, i64 %t317
  call void @olang_textcopy(ptr %t352, ptr %t319, i64 %t320)
  %t353 = getelementptr i8, ptr %t352, i64 %t320
  %t354 = call i64 @__olang_fmt_i64(ptr %t353, i64 %t322)
  %t355 = getelementptr i8, ptr %t353, i64 %t323
  call void @olang_textcopy(ptr %t355, ptr %t325, i64 %t326)
  %t356 = getelementptr i8, ptr %t355, i64 %t326
  call void @olang_textcopy(ptr %t356, ptr %t329, i64 %t330)
  %t357 = getelementptr i8, ptr %t356, i64 %t330
  call void @olang_textcopy(ptr %t357, ptr %t332, i64 %t333)
  %t358 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t335, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = extractvalue { i64, ptr } %t359, 1
  %t363 = mul i64 %t361, 1
  %t364 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t364, ptr %t362, i64 %t363, i1 false)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  %t367 = load ptr, ptr %l149, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t367, { i64, ptr } %t366)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s2)
  br label %bb66
bb66:
  %t369 = load i64, ptr %l7, !tbaa !24
  %t371 = add i64 %t369, 1
  store i64 %t371, ptr %l7, !tbaa !24
  br label %bb10
bb67:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/free:Free", ptr %t373, i32 0, i32 34
  store ptr %t375, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s17
  %t377 = load ptr, ptr %l24, !tbaa !29
  %t378 = load i64, ptr %l25, !tbaa !24
  %t381 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t377, i64 %t378)
  %t382 = extractvalue { i32, { i64, ptr } } %t381, 1
  %t383 = extractvalue { i32, { i64, ptr } } %t381, 0
  store i32 %t383, ptr %l185
  %t384 = icmp ne i32 %t383, 0
  br i1 %t384, label %bb70, label %ok.385
ok.385:
  store { i64, ptr } %t382, ptr %l184
  br label %bb69
bb69:
  %t386 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t386, ptr %l181, !tbaa !27
  br label %bb74
bb70:
  %t387 = load i32, ptr %l185, !tbaa !23
  %t388 = ashr i32 %t387, 16
  %t390 = icmp eq i32 %t388, 1
  br i1 %t390, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_c15d1cb682121452_ddf973d5edb43126)
  unreachable
bb73:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb84
bb74:
  %t392 = load { i64, ptr }, ptr %l181, !tbaa !27
  store { i64, ptr } %t392, ptr %l26, !tbaa !27
  %t393 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t393, 0
  store i64 %t395, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb75
bb75:
  store %olang.scope zeroinitializer, ptr %s18
  %t397 = load i64, ptr %l28, !tbaa !24
  %t398 = load i64, ptr %l27, !tbaa !24
  %t401 = icmp slt i64 %t397, %t398
  %t403 = xor i1 %t401, true
  br i1 %t403, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s18)
  br label %bb82
bb77:
  br label %bb78
bb78:
  %t405 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t405, ptr %l194, !tbaa !27
  %t406 = load i64, ptr %l28, !tbaa !24
  %t408 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr %"compiler/free:store", ptr %t409, i64 %t406
  %t411 = load %"compiler/free:store", ptr %t410
  store %"compiler/free:store" %t411, ptr %l29
  store ptr %l1, ptr %l197, !tbaa !29
  %t413 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 0
  %t414 = load i64, ptr %t413, !tbaa !24
  store i64 %t414, ptr %l198, !tbaa !24
  %t415 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 1
  %t416 = load i64, ptr %t415, !tbaa !24
  store i64 %t416, ptr %l199, !tbaa !24
  %t417 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 4
  %t418 = load i64, ptr %t417, !tbaa !24
  store i64 %t418, ptr %l200, !tbaa !24
  %t419 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 6
  %t420 = load i64, ptr %t419, !tbaa !24
  store i64 %t420, ptr %l201, !tbaa !24
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/free:Free", ptr %t421, i32 0, i32 0
  %t424 = load ptr, ptr %t423, !tbaa !29
  %t426 = getelementptr %"compiler/generic:Program", ptr %t424, i32 0, i32 0
  %t427 = load ptr, ptr %t426, !tbaa !29
  %t429 = getelementptr %"compiler/load:Loader", ptr %t427, i32 0, i32 4
  %t430 = load ptr, ptr %t429, !tbaa !29
  %t431 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 2
  %t432 = load i64, ptr %t431, !tbaa !24
  %t433 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 3
  %t434 = getelementptr %"compiler/source:Span", ptr %t433, i32 0, i32 0
  %t435 = load i32, ptr %t434, !tbaa !23
  %t437 = sext i32 %t435 to i64
  %t441 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s18, ptr %t430, i64 %t432, i64 %t437)
  store { i64, ptr } %t441, ptr %l209
  br label %bb79
bb79:
  %t442 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t443 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t444 = load i64, ptr %l198, !tbaa !24
  %t445 = call i64 @__olang_fmt_i64(ptr null, i64 %t444)
  %t446 = add i64 %t443, %t445
  %t447 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t448 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t449 = add i64 %t446, %t448
  %t450 = load i64, ptr %l199, !tbaa !24
  %t451 = call i64 @__olang_fmt_i64(ptr null, i64 %t450)
  %t452 = add i64 %t449, %t451
  %t453 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t454 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t455 = add i64 %t452, %t454
  %t456 = load i64, ptr %l200, !tbaa !24
  %t457 = call i64 @__olang_fmt_i64(ptr null, i64 %t456)
  %t458 = add i64 %t455, %t457
  %t459 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t460 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t461 = add i64 %t458, %t460
  %t462 = load i64, ptr %l201, !tbaa !24
  %t463 = call i64 @__olang_fmt_i64(ptr null, i64 %t462)
  %t464 = add i64 %t461, %t463
  %t465 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t466 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t467 = add i64 %t464, %t466
  %t468 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t468, 1
  %t470 = extractvalue { i64, ptr } %t468, 0
  %t471 = add i64 %t467, %t470
  %t472 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t474)
  call void @olang_textcopy(ptr %t475, ptr %t442, i64 %t443)
  %t476 = getelementptr i8, ptr %t475, i64 %t443
  %t477 = call i64 @__olang_fmt_i64(ptr %t476, i64 %t444)
  %t478 = getelementptr i8, ptr %t476, i64 %t445
  call void @olang_textcopy(ptr %t478, ptr %t447, i64 %t448)
  %t479 = getelementptr i8, ptr %t478, i64 %t448
  %t480 = call i64 @__olang_fmt_i64(ptr %t479, i64 %t450)
  %t481 = getelementptr i8, ptr %t479, i64 %t451
  call void @olang_textcopy(ptr %t481, ptr %t453, i64 %t454)
  %t482 = getelementptr i8, ptr %t481, i64 %t454
  %t483 = call i64 @__olang_fmt_i64(ptr %t482, i64 %t456)
  %t484 = getelementptr i8, ptr %t482, i64 %t457
  call void @olang_textcopy(ptr %t484, ptr %t459, i64 %t460)
  %t485 = getelementptr i8, ptr %t484, i64 %t460
  %t486 = call i64 @__olang_fmt_i64(ptr %t485, i64 %t462)
  %t487 = getelementptr i8, ptr %t485, i64 %t463
  call void @olang_textcopy(ptr %t487, ptr %t465, i64 %t466)
  %t488 = getelementptr i8, ptr %t487, i64 %t466
  call void @olang_textcopy(ptr %t488, ptr %t469, i64 %t470)
  %t489 = getelementptr i8, ptr %t488, i64 %t470
  call void @olang_textcopy(ptr %t489, ptr %t472, i64 %t473)
  %t490 = insertvalue { i64, ptr } undef, i64 %t474, 0
  %t491 = insertvalue { i64, ptr } %t490, ptr %t475, 1
  %t493 = extractvalue { i64, ptr } %t491, 0
  %t494 = extractvalue { i64, ptr } %t491, 1
  %t495 = mul i64 %t493, 1
  %t496 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t495)
  call void @llvm.memcpy.p0.p0.i64(ptr %t496, ptr %t494, i64 %t495, i1 false)
  %t497 = insertvalue { i64, ptr } undef, i64 %t493, 0
  %t498 = insertvalue { i64, ptr } %t497, ptr %t496, 1
  %t499 = load ptr, ptr %l197, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s18, ptr %t499, { i64, ptr } %t498)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s18)
  br label %bb81
bb81:
  %t501 = load i64, ptr %l28, !tbaa !24
  %t503 = add i64 %t501, 1
  store i64 %t503, ptr %l28, !tbaa !24
  br label %bb75
bb82:
  %t505 = load i64, ptr %l25, !tbaa !24
  %t506 = load i64, ptr %l27, !tbaa !24
  %t509 = add i64 %t505, %t506
  store i64 %t509, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb83
bb83:
  br label %bb68
bb84:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr %"compiler/free:Free", ptr %t511, i32 0, i32 35
  store ptr %t513, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s22
  %t515 = load ptr, ptr %l30, !tbaa !29
  %t516 = load i64, ptr %l31, !tbaa !24
  %t519 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t515, i64 %t516)
  %t520 = extractvalue { i32, { i64, ptr } } %t519, 1
  %t521 = extractvalue { i32, { i64, ptr } } %t519, 0
  store i32 %t521, ptr %l223
  %t522 = icmp ne i32 %t521, 0
  br i1 %t522, label %bb87, label %ok.523
ok.523:
  store { i64, ptr } %t520, ptr %l222
  br label %bb86
bb86:
  %t524 = load { i64, ptr }, ptr %l222, !tbaa !27
  store { i64, ptr } %t524, ptr %l219, !tbaa !27
  br label %bb91
bb87:
  %t525 = load i32, ptr %l223, !tbaa !23
  %t526 = ashr i32 %t525, 16
  %t528 = icmp eq i32 %t526, 1
  br i1 %t528, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_af0f3c7979dc9853_f8576f39d689087)
  unreachable
bb90:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb102
bb91:
  %t530 = load { i64, ptr }, ptr %l219, !tbaa !27
  store { i64, ptr } %t530, ptr %l32, !tbaa !27
  %t531 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t533 = extractvalue { i64, ptr } %t531, 0
  store i64 %t533, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s23
  %t535 = load i64, ptr %l34, !tbaa !24
  %t536 = load i64, ptr %l33, !tbaa !24
  %t539 = icmp slt i64 %t535, %t536
  %t541 = xor i1 %t539, true
  br i1 %t541, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s23)
  br label %bb100
bb94:
  br label %bb95
bb95:
  %t543 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t543, ptr %l232, !tbaa !27
  %t544 = load i64, ptr %l34, !tbaa !24
  %t546 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr %"compiler/free:letGo", ptr %t547, i64 %t544
  %t549 = load %"compiler/free:letGo", ptr %t548
  store %"compiler/free:letGo" %t549, ptr %l35
  store ptr %l1, ptr %l235, !tbaa !29
  %t551 = getelementptr %"compiler/free:letGo", ptr %l35, i32 0, i32 0
  %t552 = load i64, ptr %t551, !tbaa !24
  store i64 %t552, ptr %l236, !tbaa !24
  %t553 = getelementptr %"compiler/free:letGo", ptr %l35, i32 0, i32 1
  %t554 = load i64, ptr %t553, !tbaa !24
  store i64 %t554, ptr %l237, !tbaa !24
  %t555 = getelementptr %"compiler/free:letGo", ptr %l35, i32 0, i32 5
  %t556 = load i64, ptr %t555, !tbaa !24
  store i64 %t556, ptr %l238, !tbaa !24
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/free:Free", ptr %t557, i32 0, i32 0
  %t560 = load ptr, ptr %t559, !tbaa !29
  %t562 = getelementptr %"compiler/generic:Program", ptr %t560, i32 0, i32 0
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t565 = getelementptr %"compiler/load:Loader", ptr %t563, i32 0, i32 4
  %t566 = load ptr, ptr %t565, !tbaa !29
  %t567 = getelementptr %"compiler/free:letGo", ptr %l35, i32 0, i32 2
  %t568 = load i64, ptr %t567, !tbaa !24
  %t569 = getelementptr %"compiler/free:letGo", ptr %l35, i32 0, i32 4
  %t570 = getelementptr %"compiler/source:Span", ptr %t569, i32 0, i32 0
  %t571 = load i32, ptr %t570, !tbaa !23
  %t573 = sext i32 %t571 to i64
  %t577 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s23, ptr %t566, i64 %t568, i64 %t573)
  store { i64, ptr } %t577, ptr %l246
  br label %bb96
bb96:
  %t578 = load ptr, ptr %l0, !tbaa !29
  %t579 = load %"compiler/free:letGo", ptr %l35
  %t582 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s23, ptr %t578, %"compiler/free:letGo" %t579)
  store { i64, ptr } %t582, ptr %l249
  br label %bb97
bb97:
  %t583 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t584 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t585 = load i64, ptr %l236, !tbaa !24
  %t586 = call i64 @__olang_fmt_i64(ptr null, i64 %t585)
  %t587 = add i64 %t584, %t586
  %t588 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t589 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t590 = add i64 %t587, %t589
  %t591 = load i64, ptr %l237, !tbaa !24
  %t592 = call i64 @__olang_fmt_i64(ptr null, i64 %t591)
  %t593 = add i64 %t590, %t592
  %t594 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t595 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t596 = add i64 %t593, %t595
  %t597 = load i64, ptr %l238, !tbaa !24
  %t598 = call i64 @__olang_fmt_i64(ptr null, i64 %t597)
  %t599 = add i64 %t596, %t598
  %t600 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t601 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t602 = add i64 %t599, %t601
  %t603 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t604 = extractvalue { i64, ptr } %t603, 1
  %t605 = extractvalue { i64, ptr } %t603, 0
  %t606 = add i64 %t602, %t605
  %t607 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t608 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t609 = add i64 %t606, %t608
  %t610 = load { i64, ptr }, ptr %l249, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 1
  %t612 = extractvalue { i64, ptr } %t610, 0
  %t613 = add i64 %t609, %t612
  %t614 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t615 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t616 = add i64 %t613, %t615
  %t617 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t616)
  call void @olang_textcopy(ptr %t617, ptr %t583, i64 %t584)
  %t618 = getelementptr i8, ptr %t617, i64 %t584
  %t619 = call i64 @__olang_fmt_i64(ptr %t618, i64 %t585)
  %t620 = getelementptr i8, ptr %t618, i64 %t586
  call void @olang_textcopy(ptr %t620, ptr %t588, i64 %t589)
  %t621 = getelementptr i8, ptr %t620, i64 %t589
  %t622 = call i64 @__olang_fmt_i64(ptr %t621, i64 %t591)
  %t623 = getelementptr i8, ptr %t621, i64 %t592
  call void @olang_textcopy(ptr %t623, ptr %t594, i64 %t595)
  %t624 = getelementptr i8, ptr %t623, i64 %t595
  %t625 = call i64 @__olang_fmt_i64(ptr %t624, i64 %t597)
  %t626 = getelementptr i8, ptr %t624, i64 %t598
  call void @olang_textcopy(ptr %t626, ptr %t600, i64 %t601)
  %t627 = getelementptr i8, ptr %t626, i64 %t601
  call void @olang_textcopy(ptr %t627, ptr %t604, i64 %t605)
  %t628 = getelementptr i8, ptr %t627, i64 %t605
  call void @olang_textcopy(ptr %t628, ptr %t607, i64 %t608)
  %t629 = getelementptr i8, ptr %t628, i64 %t608
  call void @olang_textcopy(ptr %t629, ptr %t611, i64 %t612)
  %t630 = getelementptr i8, ptr %t629, i64 %t612
  call void @olang_textcopy(ptr %t630, ptr %t614, i64 %t615)
  %t631 = insertvalue { i64, ptr } undef, i64 %t616, 0
  %t632 = insertvalue { i64, ptr } %t631, ptr %t617, 1
  %t634 = extractvalue { i64, ptr } %t632, 0
  %t635 = extractvalue { i64, ptr } %t632, 1
  %t636 = mul i64 %t634, 1
  %t637 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t636)
  call void @llvm.memcpy.p0.p0.i64(ptr %t637, ptr %t635, i64 %t636, i1 false)
  %t638 = insertvalue { i64, ptr } undef, i64 %t634, 0
  %t639 = insertvalue { i64, ptr } %t638, ptr %t637, 1
  %t640 = load ptr, ptr %l235, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t640, { i64, ptr } %t639)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s23)
  br label %bb99
bb99:
  %t642 = load i64, ptr %l34, !tbaa !24
  %t644 = add i64 %t642, 1
  store i64 %t644, ptr %l34, !tbaa !24
  br label %bb92
bb100:
  %t646 = load i64, ptr %l31, !tbaa !24
  %t647 = load i64, ptr %l33, !tbaa !24
  %t650 = add i64 %t646, %t647
  store i64 %t650, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb101
bb101:
  br label %bb85
bb102:
  store i64 0, ptr %l36, !tbaa !24
  %t652 = load ptr, ptr %l0, !tbaa !29
  %t654 = getelementptr %"compiler/free:Free", ptr %t652, i32 0, i32 1
  %t656 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %t654)
  store i64 %t656, ptr %l259
  br label %bb103
bb103:
  %t657 = load i64, ptr %l259, !tbaa !24
  store i64 %t657, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t658 = load i64, ptr %l37, !tbaa !24
  %t659 = load i64, ptr %l36, !tbaa !24
  %t662 = icmp sgt i64 %t658, %t659
  br i1 %t662, label %bb104, label %bb105
bb104:
  %t664 = load i64, ptr %l38, !tbaa !24
  %t666 = icmp sgt i64 %t664, 0
  br i1 %t666, label %bb106, label %bb107
bb105:
  store i64 0, ptr %l263, !tbaa !24
  br label %bb109
bb106:
  %t668 = load i64, ptr %l37, !tbaa !24
  %t669 = load i64, ptr %l36, !tbaa !24
  %t672 = sub i64 %t668, %t669
  %t673 = load i64, ptr %l38, !tbaa !24
  %t676 = add i64 %t672, %t673
  %t678 = sub i64 %t676, 1
  %t679 = load i64, ptr %l38, !tbaa !24
  %t682 = sdiv i64 %t678, %t679
  store i64 %t682, ptr %l266, !tbaa !24
  br label %bb108
bb107:
  store i64 0, ptr %l266, !tbaa !24
  br label %bb108
bb108:
  %t684 = load i64, ptr %l266, !tbaa !24
  store i64 %t684, ptr %l263, !tbaa !24
  br label %bb109
bb109:
  %t685 = load i64, ptr %l263, !tbaa !24
  store i64 %t685, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s27
  %t686 = load i64, ptr %l40, !tbaa !24
  %t687 = load i64, ptr %l39, !tbaa !24
  %t690 = icmp slt i64 %t686, %t687
  %t692 = xor i1 %t690, true
  br i1 %t692, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s27)
  br label %bb140
bb112:
  br label %bb113
bb113:
  %t694 = load i64, ptr %l36, !tbaa !24
  %t695 = load i64, ptr %l40, !tbaa !24
  %t696 = load i64, ptr %l38, !tbaa !24
  %t699 = mul i64 %t695, %t696
  %t702 = add i64 %t694, %t699
  store i64 %t702, ptr %l41, !tbaa !24
  %t704 = load ptr, ptr %l0, !tbaa !29
  %t706 = getelementptr %"compiler/free:Free", ptr %t704, i32 0, i32 21
  %t707 = load i64, ptr %l41, !tbaa !24
  %t710 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t706, i64 %t707)
  store ptr %t710, ptr %l287
  br label %bb114
bb114:
  %t711 = load ptr, ptr %l287, !tbaa !29
  %t712 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t711)
  store i64 %t712, ptr %l288
  br label %bb115
bb115:
  %t713 = load i64, ptr %l288, !tbaa !24
  %t714 = icmp eq i64 %t713, 0
  br i1 %t714, label %bb116, label %bb117
bb116:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t718 = getelementptr %"compiler/free:Free", ptr %t716, i32 0, i32 22
  %t719 = load i64, ptr %l41, !tbaa !24
  %t722 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t718, i64 %t719)
  store ptr %t722, ptr %l294
  br label %bb118
bb117:
  store i1 false, ptr %l290, !tbaa !21
  br label %bb120
bb118:
  %t723 = load ptr, ptr %l294, !tbaa !29
  %t724 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t723)
  store i64 %t724, ptr %l295
  br label %bb119
bb119:
  %t725 = load i64, ptr %l295, !tbaa !24
  %t726 = icmp eq i64 %t725, 0
  store i1 %t726, ptr %l290, !tbaa !21
  br label %bb120
bb120:
  %t728 = load i1, ptr %l290, !tbaa !21
  br i1 %t728, label %bb121, label %bb122
bb121:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/free:Free", ptr %t729, i32 0, i32 23
  %t732 = load i64, ptr %l41, !tbaa !24
  %t735 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t731, i64 %t732)
  store ptr %t735, ptr %l301
  br label %bb123
bb122:
  store i1 false, ptr %l297, !tbaa !21
  br label %bb125
bb123:
  %t736 = load ptr, ptr %l301, !tbaa !29
  %t737 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t736)
  store i64 %t737, ptr %l302
  br label %bb124
bb124:
  %t738 = load i64, ptr %l302, !tbaa !24
  %t739 = icmp eq i64 %t738, 0
  store i1 %t739, ptr %l297, !tbaa !21
  br label %bb125
bb125:
  %t741 = load i1, ptr %l297, !tbaa !21
  br i1 %t741, label %bb126, label %bb127
bb126:
  call void @__olang_scope_close(ptr %s27)
  br label %bb139
bb127:
  br label %bb128
bb128:
  store ptr %l1, ptr %l304, !tbaa !29
  %t742 = load i64, ptr %l41, !tbaa !24
  store i64 %t742, ptr %l305, !tbaa !24
  %t743 = load ptr, ptr %l0, !tbaa !29
  %t744 = load i64, ptr %l41, !tbaa !24
  %t747 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s27, ptr %t743, i64 %t744)
  store { i64, ptr } %t747, ptr %l308
  br label %bb129
bb129:
  %t748 = load ptr, ptr %l0, !tbaa !29
  %t750 = getelementptr %"compiler/free:Free", ptr %t748, i32 0, i32 21
  %t751 = load i64, ptr %l41, !tbaa !24
  %t754 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t750, i64 %t751)
  store ptr %t754, ptr %l312
  br label %bb130
bb130:
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t757 = getelementptr %"compiler/free:Free", ptr %t755, i32 0, i32 22
  %t758 = load i64, ptr %l41, !tbaa !24
  %t761 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t757, i64 %t758)
  store ptr %t761, ptr %l316
  br label %bb131
bb131:
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t764 = getelementptr %"compiler/free:Free", ptr %t762, i32 0, i32 23
  %t765 = load i64, ptr %l41, !tbaa !24
  %t768 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t764, i64 %t765)
  store ptr %t768, ptr %l320
  br label %bb132
bb132:
  %t769 = load ptr, ptr %l0, !tbaa !29
  %t771 = getelementptr %"compiler/free:Free", ptr %t769, i32 0, i32 20
  %t772 = load i64, ptr %l41, !tbaa !24
  %t775 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t771, i64 %t772)
  store ptr %t775, ptr %l324
  br label %bb133
bb133:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s29
  store ptr %s29room, ptr %s29
  %t776 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s29, ptr %t776, i64 %t777)
  %t778 = load i64, ptr %l305, !tbaa !24
  %t779 = call ptr @__olang_sb_room(ptr %s29, i64 24)
  %t780 = call i64 @__olang_fmt_i64(ptr %t779, i64 %t778)
  call void @__olang_sb_add(ptr %s29, i64 %t780)
  %t781 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t782 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s29, ptr %t781, i64 %t782)
  %t783 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t784 = extractvalue { i64, ptr } %t783, 1
  %t785 = extractvalue { i64, ptr } %t783, 0
  call void @__olang_sb_put(ptr %s29, ptr %t784, i64 %t785)
  %t786 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t787 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s29, ptr %t786, i64 %t787)
  call void @olang_2eHelperKind_2eRender_2emut_20std_2fprelude_2flist_3aList_3cI64_3e_26(ptr %s29, ptr %l312, i64 0)
  br label %bb134
bb134:
  %t789 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t790 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s29, ptr %t789, i64 %t790)
  call void @olang_2eHelperKind_2eRender_2emut_20std_2fprelude_2flist_3aList_3cI64_3e_26(ptr %s29, ptr %l316, i64 0)
  br label %bb135
bb135:
  %t792 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t793 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s29, ptr %t792, i64 %t793)
  call void @olang_2eHelperKind_2eRender_2emut_20std_2fprelude_2flist_3aList_3cI64_3e_26(ptr %s29, ptr %l320, i64 0)
  br label %bb136
bb136:
  %t795 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t796 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s29, ptr %t795, i64 %t796)
  call void @olang_2eHelperKind_2eRender_2emut_20std_2fprelude_2flist_3aList_3cI64_3e_26(ptr %s29, ptr %l324, i64 0)
  br label %bb137
bb137:
  %t798 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t799 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s29, ptr %t798, i64 %t799)
  %t800 = load ptr, ptr %s29
  %t801 = getelementptr %olang.builder, ptr %s29, i32 0, i32 1
  %t802 = load i64, ptr %t801
  %t803 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t802)
  call void @olang_textcopy(ptr %t803, ptr %t800, i64 %t802)
  %t804 = insertvalue { i64, ptr } undef, i64 %t802, 0
  %t805 = insertvalue { i64, ptr } %t804, ptr %t803, 1
  store { i64, ptr } %t805, ptr %l329, !tbaa !27
  %t806 = getelementptr %olang.builder, ptr %s29, i32 0, i32 3
  %t807 = load ptr, ptr %t806
  %t808 = icmp ne ptr %t807, null
  br i1 %t808, label %sbgrew.809, label %sbdone.810
sbgrew.809:
  call void @__olang_sb_done(ptr %s29)
  br label %sbdone.810
sbdone.810:
  %t811 = load { i64, ptr }, ptr %l329, !tbaa !27
  %t812 = extractvalue { i64, ptr } %t811, 0
  %t813 = extractvalue { i64, ptr } %t811, 1
  %t814 = mul i64 %t812, 1
  %t815 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t814)
  call void @llvm.memcpy.p0.p0.i64(ptr %t815, ptr %t813, i64 %t814, i1 false)
  %t816 = insertvalue { i64, ptr } undef, i64 %t812, 0
  %t817 = insertvalue { i64, ptr } %t816, ptr %t815, 1
  %t818 = load ptr, ptr %l304, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s27, ptr %t818, { i64, ptr } %t817)
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s27)
  br label %bb139
bb139:
  %t820 = load i64, ptr %l40, !tbaa !24
  %t822 = add i64 %t820, 1
  store i64 %t822, ptr %l40, !tbaa !24
  br label %bb110
bb140:
  %t824 = load ptr, ptr %l0, !tbaa !29
  %t826 = getelementptr %"compiler/free:Free", ptr %t824, i32 0, i32 31
  %t827 = load i1, ptr %t826, !tbaa !21
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t830 = getelementptr %"compiler/free:Free", ptr %t828, i32 0, i32 32
  %t831 = load i1, ptr %t830, !tbaa !21
  %t832 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t833 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t835 = select i1 %t827, ptr @.c6, ptr @.c7
  %t836 = select i1 %t827, i64 4, i64 5
  %t837 = add i64 %t833, %t836
  %t838 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t839 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t840 = add i64 %t837, %t839
  %t842 = select i1 %t831, ptr @.c6, ptr @.c7
  %t843 = select i1 %t831, i64 4, i64 5
  %t844 = add i64 %t840, %t843
  %t845 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t846 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t847 = add i64 %t844, %t846
  %t848 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t847)
  call void @olang_textcopy(ptr %t848, ptr %t832, i64 %t833)
  %t849 = getelementptr i8, ptr %t848, i64 %t833
  call void @olang_textcopy(ptr %t849, ptr %t835, i64 %t836)
  %t850 = getelementptr i8, ptr %t849, i64 %t836
  call void @olang_textcopy(ptr %t850, ptr %t838, i64 %t839)
  %t851 = getelementptr i8, ptr %t850, i64 %t839
  call void @olang_textcopy(ptr %t851, ptr %t842, i64 %t843)
  %t852 = getelementptr i8, ptr %t851, i64 %t843
  call void @olang_textcopy(ptr %t852, ptr %t845, i64 %t846)
  %t853 = insertvalue { i64, ptr } undef, i64 %t847, 0
  %t854 = insertvalue { i64, ptr } %t853, ptr %t848, 1
  %t856 = extractvalue { i64, ptr } %t854, 0
  %t857 = extractvalue { i64, ptr } %t854, 1
  %t858 = mul i64 %t856, 1
  %t859 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t858)
  call void @llvm.memcpy.p0.p0.i64(ptr %t859, ptr %t857, i64 %t858, i1 false)
  %t860 = insertvalue { i64, ptr } undef, i64 %t856, 0
  %t861 = insertvalue { i64, ptr } %t860, ptr %t859, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t861)
  br label %bb141
bb141:
  %t865 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t865, ptr %l341
  br label %bb142
bb142:
  %t866 = load { i64, ptr }, ptr %l341, !tbaa !27
  store { i64, ptr } %t866, ptr %l342, !tbaa !27
  %t867 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t868 = extractvalue { i64, ptr } %t867, 0
  store i64 %t868, ptr %l343, !tbaa !24
  %t869 = load i64, ptr %l343, !tbaa !24
  %t870 = mul i64 %t869, 1
  %t871 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t870)
  %t872 = insertvalue { i64, ptr } undef, i64 %t869, 0
  %t873 = insertvalue { i64, ptr } %t872, ptr %t871, 1
  store { i64, ptr } %t873, ptr %l344, !tbaa !27
  %t874 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t875 = load ptr, ptr %t874, !tbaa !27
  %t876 = getelementptr { i64, ptr }, ptr %l342, i32 0, i32 1
  %t877 = load ptr, ptr %t876, !tbaa !27
  %t878 = load i64, ptr %l343, !tbaa !24
  %t879 = mul i64 %t878, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t875, ptr %t877, i64 %t879, i1 false)
  %t880 = load { i64, ptr }, ptr %l344, !tbaa !27
  store { i64, ptr } %t880, ptr %l342, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t881 = load { i64, ptr }, ptr %l342, !tbaa !27
  store { i64, ptr } %t881, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:leaf"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l31 = alloca { i64, ptr }
  %l36 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 67
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp2
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t15, i32 %a1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l16
  br label %bb5
bb5:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  %t21 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %t21
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t23, i64 %t24)
  %t28 = extractvalue { i32, { i64, ptr } } %t27, 1
  %t29 = extractvalue { i32, { i64, ptr } } %t27, 0
  store i32 %t29, ptr %l22
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb8, label %ok.31
ok.31:
  store { i64, ptr } %t28, ptr %l21
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t32, ptr %l18, !tbaa !27
  br label %bb12
bb8:
  %t33 = load i32, ptr %l22, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b6badb915820fc29_a28e19f30b26ee8d)
  unreachable
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb12:
  %t38 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t38, ptr %l5, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb15:
  br label %bb16
bb16:
  %t51 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t51, ptr %l31, !tbaa !27
  %t52 = load i64, ptr %l7, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr %"compiler/free:leaf", ptr %t55, i64 %t52
  %t57 = load %"compiler/free:leaf", ptr %t56
  store %"compiler/free:leaf" %t57, ptr %l8
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  %t64 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t59, i64 %t61)
  store i1 %t64, ptr %l36
  br label %bb17
bb17:
  %t65 = load i1, ptr %l36, !tbaa !21
  br i1 %t65, label %bb18, label %bb19
bb18:
  %t66 = load ptr, ptr %lp2
  %t67 = load %"compiler/free:leaf", ptr %l8
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v0, ptr %t66, %"compiler/free:leaf" %t67)
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l7, !tbaa !24
  br label %bb13
bb23:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = add i64 %t74, %t75
  store i64 %t78, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  br label %bb6
bb25:
  call void @__olang_scope_close(ptr %s2)
  %t80 = load ptr, ptr %lp2
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load i32, ptr %l3, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp ne i64 %t2, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp slt i64 %t10, %t12
  store i1 %t15, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 3
  %t18 = getelementptr %"compiler/source:Span", ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 3
  %t21 = getelementptr %"compiler/source:Span", ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = icmp slt i32 %t19, %t22
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %lp3 = alloca ptr
  %l7 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t8, ptr %lp3
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %lp3
  store ptr %t9, ptr %t10, !tbaa !29
  %t11 = load ptr, ptr %lp3
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 11
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = icmp eq ptr %t15, null
  br i1 %t17, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %lp3
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Body", ptr %t21, i32 0, i32 11
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = icmp eq ptr %t24, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3a516a19293feeda_7f77204653e04cce)
  unreachable
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %lp3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 11
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %t32, i64 %a2)
  store ptr %t36, ptr %l18
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l18, !tbaa !29
  store ptr %t37, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecollection(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/free:letGo" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/free:letGo"
  %lp10 = alloca ptr
  %lp11 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l27 = alloca { i64, ptr }
  %l33 = alloca i1
  %l37 = alloca i1
  %l41 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l52 = alloca { i64, ptr }
  %l54 = alloca i1
  %l64 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 35
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l18
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l17
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t14, ptr %l14, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f6ef9e24276337f6_9f5fd13826c6ac8a)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb7:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t20, ptr %l6, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l8, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t33, ptr %l27, !tbaa !27
  %t34 = load i64, ptr %l8, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/free:letGo", ptr %t37, i64 %t34
  %t39 = load %"compiler/free:letGo", ptr %t38
  store %"compiler/free:letGo" %t39, ptr %l9
  %t41 = getelementptr %"compiler/free:letGo", ptr %l9, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t46 = icmp eq i64 %t42, %a1
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = getelementptr %"compiler/free:letGo", ptr %l9, i32 0, i32 1
  %t49 = load i64, ptr %t48, !tbaa !24
  %t53 = icmp eq i64 %t49, %a2
  store i1 %t53, ptr %l33, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t56 = getelementptr %"compiler/free:letGo", ptr %l9, i32 0, i32 5
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  %t61 = icmp ne i64 %t57, %t58
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb18, label %bb19
bb18:
  %t64 = getelementptr %"compiler/free:letGo", ptr %l9, i32 0, i32 7
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = icmp sge i64 %t65, 0
  store i1 %t67, ptr %l41, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  %t69 = load i1, ptr %l41, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 18
  %t73 = getelementptr %"compiler/free:letGo", ptr %l9, i32 0, i32 7
  %t74 = load i64, ptr %t73, !tbaa !24
  %t77 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t72, i64 %t74)
  store i1 %t77, ptr %l48
  br label %bb23
bb22:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb24
bb23:
  %t78 = load i1, ptr %l48, !tbaa !21
  %t79 = xor i1 %t78, true
  store i1 %t79, ptr %l44, !tbaa !21
  br label %bb24
bb24:
  %t81 = load i1, ptr %l44, !tbaa !21
  br i1 %t81, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load %"compiler/free:letGo", ptr %l9
  %t86 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %t82, %"compiler/free:letGo" %t83)
  store { i64, ptr } %t86, ptr %l52
  br label %bb27
bb26:
  br label %bb32
bb27:
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t87, ptr %lp10
  %t88 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t89 = load ptr, ptr %lp10
  store { i64, ptr } %t88, ptr %t89, !tbaa !27
  %t90 = load ptr, ptr %lp10
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t91, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t93, ptr %l54
  br label %bb28
bb28:
  %t94 = load i1, ptr %l54, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb29, label %bb30
bb29:
  %t97 = load ptr, ptr %lp10
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t98, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb33:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l8, !tbaa !24
  br label %bb8
bb34:
  %t104 = load i64, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = add i64 %t104, %t105
  store i64 %t108, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  br label %bb1
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t114 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %t110, %"compiler/free:letGo" %a3)
  store { i64, ptr } %t114, ptr %l64
  br label %bb37
bb37:
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t115, ptr %lp11
  %t116 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t117 = load ptr, ptr %lp11
  store { i64, ptr } %t116, ptr %t117, !tbaa !27
  %t118 = load ptr, ptr %lp11
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  %t121 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t119, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t121, ptr %l66
  br label %bb38
bb38:
  %t122 = load i1, ptr %l66, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb39, label %bb40
bb39:
  %t125 = load ptr, ptr %lp11
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l68, !tbaa !27
  br label %bb41
bb40:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l70, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t128, ptr %l68, !tbaa !27
  br label %bb41
bb41:
  %t130 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l72, !tbaa !24
  %t132 = load i64, ptr %l72, !tbaa !24
  %t133 = mul i64 %t132, 1
  %t134 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l73, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = load i64, ptr %l72, !tbaa !24
  %t142 = mul i64 %t141, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t138, ptr %t140, i64 %t142, i1 false)
  %t143 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t143, ptr %l68, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t144 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/free:letGo"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca %"compiler/free:store"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca %"compiler/free:orStore"
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/free:orCall"
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca %"compiler/free:store"
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca %"compiler/free:store"
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca %"compiler/free:store"
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca %"compiler/free:store"
  %l91 = alloca i64
  %l92 = alloca %"compiler/free:reason"
  %l93 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca %"compiler/free:store"
  %l101 = alloca i64
  %l106 = alloca i64
  %l109 = alloca i64
  %l131 = alloca i64
  %l136 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca i32
  %l149 = alloca { i64, ptr }
  %l155 = alloca i1
  %l158 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l171 = alloca i1
  %l183 = alloca i64
  %l186 = alloca i64
  %l206 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca i64
  %l211 = alloca i64
  %l212 = alloca %"compiler/source:Span"
  %l215 = alloca i64
  %l217 = alloca ptr
  %l218 = alloca i64
  %l219 = alloca i64
  %l220 = alloca %"compiler/source:Span"
  %l223 = alloca i1
  %l227 = alloca i1
  %l228 = alloca ptr
  %l229 = alloca i64
  %l230 = alloca i64
  %l231 = alloca %"compiler/source:Span"
  %l236 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca i32
  %l249 = alloca { i64, ptr }
  %l255 = alloca i1
  %l258 = alloca i1
  %l260 = alloca i1
  %l264 = alloca i1
  %l266 = alloca i1
  %l267 = alloca ptr
  %l271 = alloca i1
  %l284 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l288 = alloca i32
  %l297 = alloca { i64, ptr }
  %l302 = alloca i1
  %l304 = alloca i1
  %l308 = alloca i1
  %l310 = alloca i1
  %l313 = alloca i1
  %l314 = alloca ptr
  %l315 = alloca i64
  %l316 = alloca i64
  %l317 = alloca %"compiler/source:Span"
  %l325 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l329 = alloca i32
  %l338 = alloca { i64, ptr }
  %l343 = alloca i1
  %l345 = alloca i1
  %l349 = alloca i1
  %l351 = alloca i1
  %l355 = alloca ptr
  %l359 = alloca i1
  %l363 = alloca i1
  %l364 = alloca ptr
  %l365 = alloca i64
  %l366 = alloca i64
  %l367 = alloca %"compiler/source:Span"
  %l375 = alloca { i64, ptr }
  %l378 = alloca { i64, ptr }
  %l379 = alloca i32
  %l388 = alloca { i64, ptr }
  %l394 = alloca i1
  %l397 = alloca i1
  %l399 = alloca i1
  %l400 = alloca ptr
  %l404 = alloca i64
  %l420 = alloca i64
  %l423 = alloca i64
  %l442 = alloca ptr
  %l443 = alloca i64
  %l447 = alloca i1
  %l448 = alloca i1
  %l452 = alloca i64
  %l459 = alloca { i64, ptr }
  %l462 = alloca { i64, ptr }
  %l463 = alloca i32
  %l472 = alloca { i64, ptr }
  %l478 = alloca i1
  %l482 = alloca i1
  %l483 = alloca i1
  %l487 = alloca i1
  %l488 = alloca i1
  %l492 = alloca i1
  %l496 = alloca i1
  %l512 = alloca i64
  %l515 = alloca i64
  %l536 = alloca i1
  %l537 = alloca ptr
  %l538 = alloca i64
  %l539 = alloca i64
  %l540 = alloca %"compiler/source:Span"
  %l547 = alloca i64
  %l550 = alloca i64
  %l569 = alloca ptr
  %l570 = alloca i64
  %l573 = alloca i1
  %l577 = alloca i64
  %l580 = alloca i1
  %l583 = alloca i1
  %l589 = alloca { i64, ptr }
  %l592 = alloca { i64, ptr }
  %l593 = alloca i32
  %l602 = alloca { i64, ptr }
  %l608 = alloca i1
  %l612 = alloca i1
  %l613 = alloca i1
  %l617 = alloca i1
  %l638 = alloca i64
  %l641 = alloca i64
  %l661 = alloca i1
  %l666 = alloca i64
  %l669 = alloca i1
  %l673 = alloca i1
  %l677 = alloca { i64, ptr }
  %l680 = alloca { i64, ptr }
  %l681 = alloca i32
  %l690 = alloca { i64, ptr }
  %l703 = alloca i1
  %l713 = alloca i1
  %l723 = alloca i1
  %l728 = alloca %"compiler/free:reason"
  %l729 = alloca ptr
  %l730 = alloca i64
  %l731 = alloca i64
  %l734 = alloca i64
  %l739 = alloca %"compiler/source:Span"
  %l760 = alloca ptr
  %l761 = alloca i64
  %l762 = alloca i64
  %l763 = alloca %"compiler/source:Span"
  %l765 = alloca ptr
  %l766 = alloca i64
  %l768 = alloca i1
  %l772 = alloca i64
  %l778 = alloca i1
  %l782 = alloca { i64, ptr }
  %l785 = alloca { i64, ptr }
  %l786 = alloca i32
  %l795 = alloca { i64, ptr }
  %l801 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %s51 = alloca %olang.scope
  %s53 = alloca %olang.scope
  %s55 = alloca %olang.scope
  %s56 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s61 = alloca %olang.scope
  %s64 = alloca %olang.scope
  %s65 = alloca %olang.scope
  %s68 = alloca %olang.scope
  %s70 = alloca %olang.scope
  %s72 = alloca %olang.scope
  %s75 = alloca %olang.scope
  %s77 = alloca %olang.scope
  %s80 = alloca %olang.scope
  %s81 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l101
  br label %bb1
bb1:
  %t6 = load i64, ptr %l101, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l109, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l109, !tbaa !24
  store i64 %t35, ptr %l106, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l106, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 41
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t57, i1 false)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t63 = load i64, ptr %l1, !tbaa !24
  store i64 %t63, ptr %l131, !tbaa !24
  %t64 = load i64, ptr %l131, !tbaa !24
  %t65 = icmp sge i64 %t64, 0
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l131, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l8, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 35
  store ptr %t75, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_77e2c420ac7907a9_804235f2ad53d)
  unreachable
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t77 = load ptr, ptr %l9, !tbaa !29
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t77, i64 %t78)
  %t82 = extractvalue { i32, { i64, ptr } } %t81, 1
  %t83 = extractvalue { i32, { i64, ptr } } %t81, 0
  store i32 %t83, ptr %l140
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb19, label %ok.85
ok.85:
  store { i64, ptr } %t82, ptr %l139
  br label %bb18
bb18:
  %t86 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t86, ptr %l136, !tbaa !27
  br label %bb23
bb19:
  %t87 = load i32, ptr %l140, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  br i1 %t90, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_13d43c3a12e7be33_d312cf328348084f)
  unreachable
bb22:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb48
bb23:
  %t92 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t92, ptr %l11, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb26:
  br label %bb27
bb27:
  %t105 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t105, ptr %l149, !tbaa !27
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"compiler/free:letGo", ptr %t109, i64 %t106
  %t111 = load %"compiler/free:letGo", ptr %t110
  store %"compiler/free:letGo" %t111, ptr %l14
  %t113 = getelementptr %"compiler/free:letGo", ptr %l14, i32 0, i32 5
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t118 = icmp ne i64 %t114, %t115
  br i1 %t118, label %bb28, label %bb29
bb28:
  %t120 = getelementptr %"compiler/free:letGo", ptr %l14, i32 0, i32 0
  %t121 = load i64, ptr %t120, !tbaa !24
  %t123 = icmp sge i64 %t121, 0
  store i1 %t123, ptr %l155, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb30
bb30:
  %t125 = load i1, ptr %l155, !tbaa !21
  br i1 %t125, label %bb31, label %bb32
bb31:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:Free", ptr %t126, i32 0, i32 17
  %t129 = getelementptr %"compiler/free:letGo", ptr %l14, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t128, i64 %t130)
  store i1 %t133, ptr %l162
  br label %bb33
bb32:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb34
bb33:
  %t134 = load i1, ptr %l162, !tbaa !21
  store i1 %t134, ptr %l158, !tbaa !21
  br label %bb34
bb34:
  %t135 = load i1, ptr %l158, !tbaa !21
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t136 = getelementptr %"compiler/free:letGo", ptr %l14, i32 0, i32 5
  %t137 = load i64, ptr %t136, !tbaa !24
  %t138 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  %t141 = icmp eq i64 %t137, %t138
  br i1 %t141, label %bb37, label %bb38
bb36:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb41
bb37:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:Free", ptr %t143, i32 0, i32 19
  %t146 = getelementptr %"compiler/free:letGo", ptr %l14, i32 0, i32 1
  %t147 = load i64, ptr %t146, !tbaa !24
  %t150 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t145, i64 %t147)
  store i1 %t150, ptr %l171
  br label %bb39
bb38:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb40
bb39:
  %t151 = load i1, ptr %l171, !tbaa !21
  store i1 %t151, ptr %l167, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l167, !tbaa !21
  %t153 = xor i1 %t152, true
  store i1 %t153, ptr %l163, !tbaa !21
  br label %bb41
bb41:
  %t155 = load i1, ptr %l163, !tbaa !21
  br i1 %t155, label %bb42, label %bb43
bb42:
  %t156 = getelementptr %"compiler/free:letGo", ptr %l14, i32 0, i32 0
  %t157 = load i64, ptr %t156, !tbaa !24
  %t159 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i1, ptr %t160, i64 %t157
  store i1 true, ptr %t161, !tbaa !31
  br label %bb44
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb45:
  %t162 = load i64, ptr %l13, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l13, !tbaa !24
  br label %bb24
bb46:
  %t166 = load i64, ptr %l10, !tbaa !24
  %t167 = load i64, ptr %l12, !tbaa !24
  %t170 = add i64 %t166, %t167
  store i64 %t170, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb47:
  br label %bb17
bb48:
  store i64 0, ptr %l15, !tbaa !24
  %t172 = load i64, ptr %l1, !tbaa !24
  store i64 %t172, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t174 = load i64, ptr %l16, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb49, label %bb50
bb49:
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb54
bb51:
  %t184 = load i64, ptr %l16, !tbaa !24
  %t185 = load i64, ptr %l15, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l17, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l17, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l186, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb53
bb53:
  %t200 = load i64, ptr %l186, !tbaa !24
  store i64 %t200, ptr %l183, !tbaa !24
  br label %bb54
bb54:
  %t201 = load i64, ptr %l183, !tbaa !24
  store i64 %t201, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t202 = load i64, ptr %l19, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb57:
  br label %bb58
bb58:
  %t210 = load i64, ptr %l15, !tbaa !24
  %t211 = load i64, ptr %l19, !tbaa !24
  %t212 = load i64, ptr %l17, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l20, !tbaa !24
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load i64, ptr %l20, !tbaa !24
  %t224 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t220, i64 %t221)
  store i1 %t224, ptr %l206
  br label %bb59
bb59:
  %t225 = load i1, ptr %l206, !tbaa !21
  br i1 %t225, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb61:
  br label %bb62
bb62:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:Free", ptr %t226, i32 0, i32 31
  %t229 = load i1, ptr %t228, !tbaa !21
  br i1 %t229, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l209, !tbaa !29
  %t232 = load i64, ptr %l20, !tbaa !24
  store i64 %t232, ptr %l210, !tbaa !24
  %t233 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t233, ptr %l211, !tbaa !24
  %t234 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 0, i32 0)
  store %"compiler/source:Span" %t234, ptr %l212
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t235 = load ptr, ptr %l209, !tbaa !29
  %t236 = load i64, ptr %l210, !tbaa !24
  %t237 = load i64, ptr %l211, !tbaa !24
  %t238 = load %"compiler/source:Span", ptr %l212
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s12, ptr %t235, i64 %t236, i64 %t237, i64 -1, %"compiler/source:Span" %t238, { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s12)
  br label %bb67
bb67:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t239, i32 0, i32 29
  %t243 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t241)
  store i64 %t243, ptr %l215
  br label %bb68
bb68:
  %t244 = load i64, ptr %l215, !tbaa !24
  %t245 = icmp sgt i64 %t244, 0
  br i1 %t245, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s13
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l217, !tbaa !29
  %t248 = load i64, ptr %l20, !tbaa !24
  store i64 %t248, ptr %l218, !tbaa !24
  %t249 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t249, ptr %l219, !tbaa !24
  %t250 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 0, i32 0)
  store %"compiler/source:Span" %t250, ptr %l220
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t251 = load ptr, ptr %l217, !tbaa !29
  %t252 = load i64, ptr %l218, !tbaa !24
  %t253 = load i64, ptr %l219, !tbaa !24
  %t254 = load %"compiler/source:Span", ptr %l220
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s13, ptr %t251, i64 %t252, i64 %t253, i64 -1, %"compiler/source:Span" %t254, { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s13)
  br label %bb73
bb73:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/free:Free", ptr %t255, i32 0, i32 32
  %t258 = load i1, ptr %t257, !tbaa !21
  br i1 %t258, label %bb74, label %bb75
bb74:
  store i1 true, ptr %l223, !tbaa !21
  br label %bb77
bb75:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/free:Free", ptr %t260, i32 0, i32 33
  %t263 = load i64, ptr %l20, !tbaa !24
  %t266 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t262, i64 %t263)
  store i1 %t266, ptr %l227
  br label %bb76
bb76:
  %t267 = load i1, ptr %l227, !tbaa !21
  store i1 %t267, ptr %l223, !tbaa !21
  br label %bb77
bb77:
  %t268 = load i1, ptr %l223, !tbaa !21
  br i1 %t268, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l228, !tbaa !29
  %t270 = load i64, ptr %l20, !tbaa !24
  store i64 %t270, ptr %l229, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t271, ptr %l230, !tbaa !24
  %t272 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s14, i32 0, i32 0)
  store %"compiler/source:Span" %t272, ptr %l231
  br label %bb80
bb79:
  br label %bb82
bb80:
  %t273 = load ptr, ptr %l228, !tbaa !29
  %t274 = load i64, ptr %l229, !tbaa !24
  %t275 = load i64, ptr %l230, !tbaa !24
  %t276 = load %"compiler/source:Span", ptr %l231
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s14, ptr %t273, i64 %t274, i64 %t275, i64 -1, %"compiler/source:Span" %t276, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s14)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s10)
  br label %bb83
bb83:
  %t277 = load i64, ptr %l19, !tbaa !24
  %t279 = add i64 %t277, 1
  store i64 %t279, ptr %l19, !tbaa !24
  br label %bb55
bb84:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/free:Free", ptr %t281, i32 0, i32 34
  store ptr %t283, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s17
  %t285 = load ptr, ptr %l21, !tbaa !29
  %t286 = load i64, ptr %l22, !tbaa !24
  %t289 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t285, i64 %t286)
  %t290 = extractvalue { i32, { i64, ptr } } %t289, 1
  %t291 = extractvalue { i32, { i64, ptr } } %t289, 0
  store i32 %t291, ptr %l240
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb87, label %ok.293
ok.293:
  store { i64, ptr } %t290, ptr %l239
  br label %bb86
bb86:
  %t294 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t294, ptr %l236, !tbaa !27
  br label %bb91
bb87:
  %t295 = load i32, ptr %l240, !tbaa !23
  %t296 = ashr i32 %t295, 16
  %t298 = icmp eq i32 %t296, 1
  br i1 %t298, label %bb88, label %bb89
bb88:
  br label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_b10cc208e99f9718_d49c9c08520d6614)
  unreachable
bb90:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb118
bb91:
  %t300 = load { i64, ptr }, ptr %l236, !tbaa !27
  store { i64, ptr } %t300, ptr %l23, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t301, 0
  store i64 %t303, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s18
  %t305 = load i64, ptr %l25, !tbaa !24
  %t306 = load i64, ptr %l24, !tbaa !24
  %t309 = icmp slt i64 %t305, %t306
  %t311 = xor i1 %t309, true
  br i1 %t311, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s18)
  br label %bb116
bb94:
  br label %bb95
bb95:
  %t313 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t313, ptr %l249, !tbaa !27
  %t314 = load i64, ptr %l25, !tbaa !24
  %t316 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr %"compiler/free:store", ptr %t317, i64 %t314
  %t319 = load %"compiler/free:store", ptr %t318
  store %"compiler/free:store" %t319, ptr %l26
  %t321 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 4
  %t322 = load i64, ptr %t321, !tbaa !24
  %t323 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t326 = icmp eq i64 %t322, %t323
  br i1 %t326, label %bb96, label %bb97
bb96:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 0
  %t330 = load i64, ptr %t329, !tbaa !24
  %t333 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t328, i64 %t330)
  store i1 %t333, ptr %l258
  br label %bb98
bb97:
  store i1 false, ptr %l255, !tbaa !21
  br label %bb99
bb98:
  %t334 = load i1, ptr %l258, !tbaa !21
  %t335 = xor i1 %t334, true
  store i1 %t335, ptr %l255, !tbaa !21
  br label %bb99
bb99:
  %t337 = load i1, ptr %l255, !tbaa !21
  br i1 %t337, label %bb100, label %bb101
bb100:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 62
  %t341 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 0
  %t342 = load i64, ptr %t341, !tbaa !24
  %t345 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t340, i64 %t342)
  store i1 %t345, ptr %l264
  br label %bb102
bb101:
  store i1 false, ptr %l260, !tbaa !21
  br label %bb103
bb102:
  %t346 = load i1, ptr %l264, !tbaa !21
  %t347 = xor i1 %t346, true
  store i1 %t347, ptr %l260, !tbaa !21
  br label %bb103
bb103:
  %t349 = load i1, ptr %l260, !tbaa !21
  br i1 %t349, label %bb104, label %bb105
bb104:
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l267, !tbaa !29
  %t351 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 7
  %t352 = load ptr, ptr %t351, !tbaa !29
  %t354 = icmp eq ptr %t352, null
  br i1 %t354, label %bb106, label %bb107
bb105:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb110
bb106:
  call void @__olang_check_failed(ptr @olang_loc_1c3c578240008a_e9f41163a0859586)
  unreachable
bb107:
  br label %bb108
bb108:
  %t356 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 7
  %t357 = load ptr, ptr %t356, !tbaa !29
  %t358 = load ptr, ptr %l267, !tbaa !29
  %t360 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t358, ptr %t357)
  store i1 %t360, ptr %l271
  br label %bb109
bb109:
  %t361 = load i1, ptr %l271, !tbaa !21
  store i1 %t361, ptr %l266, !tbaa !21
  br label %bb110
bb110:
  %t362 = load i1, ptr %l266, !tbaa !21
  br i1 %t362, label %bb111, label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s19
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 0
  %t365 = load i64, ptr %t364, !tbaa !24
  %t366 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  %t367 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 2
  %t368 = load i64, ptr %t367, !tbaa !24
  %t369 = getelementptr %"compiler/free:store", ptr %l26, i32 0, i32 3
  %t370 = load %"compiler/source:Span", ptr %t369
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s19, ptr %t363, i64 %t365, i64 %t366, i64 %t368, %"compiler/source:Span" %t370, { i64, ptr } { i64 144, ptr getelementptr inbounds (<{ i64, [144 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb113
bb112:
  br label %bb114
bb113:
  call void @__olang_scope_close(ptr %s19)
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s18)
  br label %bb115
bb115:
  %t376 = load i64, ptr %l25, !tbaa !24
  %t378 = add i64 %t376, 1
  store i64 %t378, ptr %l25, !tbaa !24
  br label %bb92
bb116:
  %t380 = load i64, ptr %l22, !tbaa !24
  %t381 = load i64, ptr %l24, !tbaa !24
  %t384 = add i64 %t380, %t381
  store i64 %t384, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb117
bb117:
  br label %bb85
bb118:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/free:Free", ptr %t386, i32 0, i32 40
  store ptr %t388, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb119
bb119:
  store %olang.scope zeroinitializer, ptr %s22
  %t390 = load ptr, ptr %l27, !tbaa !29
  %t391 = load i64, ptr %l28, !tbaa !24
  %t394 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2eRunF_Hfb62abbaadc4bc18a4ac1ddebfb1ceda(ptr %v0, ptr %t390, i64 %t391)
  %t395 = extractvalue { i32, { i64, ptr } } %t394, 1
  %t396 = extractvalue { i32, { i64, ptr } } %t394, 0
  store i32 %t396, ptr %l288
  %t397 = icmp ne i32 %t396, 0
  br i1 %t397, label %bb121, label %ok.398
ok.398:
  store { i64, ptr } %t395, ptr %l287
  br label %bb120
bb120:
  %t399 = load { i64, ptr }, ptr %l287, !tbaa !27
  store { i64, ptr } %t399, ptr %l284, !tbaa !27
  br label %bb125
bb121:
  %t400 = load i32, ptr %l288, !tbaa !23
  %t401 = ashr i32 %t400, 16
  %t403 = icmp eq i32 %t401, 1
  br i1 %t403, label %bb122, label %bb123
bb122:
  br label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_427e00c4471cf70e_a3ac6b2261c0f5b2)
  unreachable
bb124:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb147
bb125:
  %t405 = load { i64, ptr }, ptr %l284, !tbaa !27
  store { i64, ptr } %t405, ptr %l29, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t406, 0
  store i64 %t408, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb126
bb126:
  store %olang.scope zeroinitializer, ptr %s23
  %t410 = load i64, ptr %l31, !tbaa !24
  %t411 = load i64, ptr %l30, !tbaa !24
  %t414 = icmp slt i64 %t410, %t411
  %t416 = xor i1 %t414, true
  br i1 %t416, label %bb127, label %bb128
bb127:
  call void @__olang_scope_close(ptr %s23)
  br label %bb145
bb128:
  br label %bb129
bb129:
  %t418 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t418, ptr %l297, !tbaa !27
  %t419 = load i64, ptr %l31, !tbaa !24
  %t421 = getelementptr { i64, ptr }, ptr %l297, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr %"compiler/free:orStore", ptr %t422, i64 %t419
  %t424 = load %"compiler/free:orStore", ptr %t423
  store %"compiler/free:orStore" %t424, ptr %l32
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/free:orStore", ptr %l32, i32 0, i32 1
  %t428 = load i64, ptr %t427, !tbaa !24
  %t431 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t426, i64 %t428)
  store i1 %t431, ptr %l302
  br label %bb130
bb130:
  %t432 = load i1, ptr %l302, !tbaa !21
  %t433 = xor i1 %t432, true
  br i1 %t433, label %bb131, label %bb132
bb131:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/free:Free", ptr %t435, i32 0, i32 62
  %t438 = getelementptr %"compiler/free:orStore", ptr %l32, i32 0, i32 1
  %t439 = load i64, ptr %t438, !tbaa !24
  %t442 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t437, i64 %t439)
  store i1 %t442, ptr %l308
  br label %bb133
bb132:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb134
bb133:
  %t443 = load i1, ptr %l308, !tbaa !21
  %t444 = xor i1 %t443, true
  store i1 %t444, ptr %l304, !tbaa !21
  br label %bb134
bb134:
  %t446 = load i1, ptr %l304, !tbaa !21
  br i1 %t446, label %bb135, label %bb136
bb135:
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/free:orStore", ptr %l32, i32 0, i32 2
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t452 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t447, ptr %t449)
  store i1 %t452, ptr %l313
  br label %bb137
bb136:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb138
bb137:
  %t453 = load i1, ptr %l313, !tbaa !21
  store i1 %t453, ptr %l310, !tbaa !21
  br label %bb138
bb138:
  %t454 = load i1, ptr %l310, !tbaa !21
  br i1 %t454, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s24
  %t455 = load ptr, ptr %l0, !tbaa !29
  store ptr %t455, ptr %l314, !tbaa !29
  %t456 = getelementptr %"compiler/free:orStore", ptr %l32, i32 0, i32 1
  %t457 = load i64, ptr %t456, !tbaa !24
  store i64 %t457, ptr %l315, !tbaa !24
  %t458 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t458, ptr %l316, !tbaa !24
  %t459 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s24, i32 0, i32 0)
  store %"compiler/source:Span" %t459, ptr %l317
  br label %bb141
bb140:
  br label %bb143
bb141:
  %t460 = load ptr, ptr %l314, !tbaa !29
  %t461 = load i64, ptr %l315, !tbaa !24
  %t462 = load i64, ptr %l316, !tbaa !24
  %t463 = load %"compiler/source:Span", ptr %l317
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s24, ptr %t460, i64 %t461, i64 %t462, i64 -1, %"compiler/source:Span" %t463, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s24)
  br label %bb143
bb143:
  call void @__olang_scope_close(ptr %s23)
  br label %bb144
bb144:
  %t464 = load i64, ptr %l31, !tbaa !24
  %t466 = add i64 %t464, 1
  store i64 %t466, ptr %l31, !tbaa !24
  br label %bb126
bb145:
  %t468 = load i64, ptr %l28, !tbaa !24
  %t469 = load i64, ptr %l30, !tbaa !24
  %t472 = add i64 %t468, %t469
  store i64 %t472, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb146
bb146:
  br label %bb119
bb147:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = getelementptr %"compiler/free:Free", ptr %t474, i32 0, i32 39
  store ptr %t476, ptr %l33, !tbaa !29
  store i64 0, ptr %l34, !tbaa !24
  br label %bb148
bb148:
  store %olang.scope zeroinitializer, ptr %s27
  %t478 = load ptr, ptr %l33, !tbaa !29
  %t479 = load i64, ptr %l34, !tbaa !24
  %t482 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2eRunFrom_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t478, i64 %t479)
  %t483 = extractvalue { i32, { i64, ptr } } %t482, 1
  %t484 = extractvalue { i32, { i64, ptr } } %t482, 0
  store i32 %t484, ptr %l329
  %t485 = icmp ne i32 %t484, 0
  br i1 %t485, label %bb150, label %ok.486
ok.486:
  store { i64, ptr } %t483, ptr %l328
  br label %bb149
bb149:
  %t487 = load { i64, ptr }, ptr %l328, !tbaa !27
  store { i64, ptr } %t487, ptr %l325, !tbaa !27
  br label %bb154
bb150:
  %t488 = load i32, ptr %l329, !tbaa !23
  %t489 = ashr i32 %t488, 16
  %t491 = icmp eq i32 %t489, 1
  br i1 %t491, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  call void @__olang_check_failed(ptr @olang_loc_739c10b15f53274f_734afabb36dc9f33)
  unreachable
bb153:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s27)
  br label %bb180
bb154:
  %t493 = load { i64, ptr }, ptr %l325, !tbaa !27
  store { i64, ptr } %t493, ptr %l35, !tbaa !27
  %t494 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t496 = extractvalue { i64, ptr } %t494, 0
  store i64 %t496, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb155
bb155:
  store %olang.scope zeroinitializer, ptr %s28
  %t498 = load i64, ptr %l37, !tbaa !24
  %t499 = load i64, ptr %l36, !tbaa !24
  %t502 = icmp slt i64 %t498, %t499
  %t504 = xor i1 %t502, true
  br i1 %t504, label %bb156, label %bb157
bb156:
  call void @__olang_scope_close(ptr %s28)
  br label %bb178
bb157:
  br label %bb158
bb158:
  %t506 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t506, ptr %l338, !tbaa !27
  %t507 = load i64, ptr %l37, !tbaa !24
  %t509 = getelementptr { i64, ptr }, ptr %l338, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !27
  %t511 = getelementptr %"compiler/free:orCall", ptr %t510, i64 %t507
  %t512 = load %"compiler/free:orCall", ptr %t511
  store %"compiler/free:orCall" %t512, ptr %l38
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/free:orCall", ptr %l38, i32 0, i32 4
  %t516 = load i64, ptr %t515, !tbaa !24
  %t519 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t514, i64 %t516)
  store i1 %t519, ptr %l343
  br label %bb159
bb159:
  %t520 = load i1, ptr %l343, !tbaa !21
  %t521 = xor i1 %t520, true
  br i1 %t521, label %bb160, label %bb161
bb160:
  %t523 = load ptr, ptr %l0, !tbaa !29
  %t525 = getelementptr %"compiler/free:Free", ptr %t523, i32 0, i32 62
  %t526 = getelementptr %"compiler/free:orCall", ptr %l38, i32 0, i32 4
  %t527 = load i64, ptr %t526, !tbaa !24
  %t530 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t525, i64 %t527)
  store i1 %t530, ptr %l349
  br label %bb162
bb161:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb163
bb162:
  %t531 = load i1, ptr %l349, !tbaa !21
  %t532 = xor i1 %t531, true
  store i1 %t532, ptr %l345, !tbaa !21
  br label %bb163
bb163:
  %t534 = load i1, ptr %l345, !tbaa !21
  br i1 %t534, label %bb164, label %bb165
bb164:
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t537 = getelementptr %"compiler/free:Free", ptr %t535, i32 0, i32 1
  %t538 = getelementptr %"compiler/free:orCall", ptr %l38, i32 0, i32 2
  %t539 = load i64, ptr %t538, !tbaa !24
  %t542 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t537, i64 %t539)
  store ptr %t542, ptr %l355
  br label %bb166
bb165:
  store i1 false, ptr %l351, !tbaa !21
  br label %bb171
bb166:
  %t543 = load ptr, ptr %l355, !tbaa !29
  %t545 = getelementptr %"compiler/typed:Body", ptr %t543, i32 0, i32 11
  %t546 = load ptr, ptr %t545, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  br i1 %t548, label %bb167, label %bb168
bb167:
  store i1 true, ptr %l359, !tbaa !21
  br label %bb170
bb168:
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t552 = getelementptr %"compiler/free:Free", ptr %t550, i32 0, i32 28
  %t553 = getelementptr %"compiler/free:orCall", ptr %l38, i32 0, i32 2
  %t554 = load i64, ptr %t553, !tbaa !24
  %t557 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t552, i64 %t554)
  store i1 %t557, ptr %l363
  br label %bb169
bb169:
  %t558 = load i1, ptr %l363, !tbaa !21
  store i1 %t558, ptr %l359, !tbaa !21
  br label %bb170
bb170:
  %t559 = load i1, ptr %l359, !tbaa !21
  store i1 %t559, ptr %l351, !tbaa !21
  br label %bb171
bb171:
  %t560 = load i1, ptr %l351, !tbaa !21
  br i1 %t560, label %bb172, label %bb173
bb172:
  store %olang.scope zeroinitializer, ptr %s29
  %t561 = load ptr, ptr %l0, !tbaa !29
  store ptr %t561, ptr %l364, !tbaa !29
  %t562 = getelementptr %"compiler/free:orCall", ptr %l38, i32 0, i32 4
  %t563 = load i64, ptr %t562, !tbaa !24
  store i64 %t563, ptr %l365, !tbaa !24
  %t564 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t564, ptr %l366, !tbaa !24
  %t565 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s29, i32 0, i32 0)
  store %"compiler/source:Span" %t565, ptr %l367
  br label %bb174
bb173:
  br label %bb176
bb174:
  %t566 = load ptr, ptr %l364, !tbaa !29
  %t567 = load i64, ptr %l365, !tbaa !24
  %t568 = load i64, ptr %l366, !tbaa !24
  %t569 = load %"compiler/source:Span", ptr %l367
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s29, ptr %t566, i64 %t567, i64 %t568, i64 -1, %"compiler/source:Span" %t569, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s29)
  br label %bb176
bb176:
  call void @__olang_scope_close(ptr %s28)
  br label %bb177
bb177:
  %t570 = load i64, ptr %l37, !tbaa !24
  %t572 = add i64 %t570, 1
  store i64 %t572, ptr %l37, !tbaa !24
  br label %bb155
bb178:
  %t574 = load i64, ptr %l34, !tbaa !24
  %t575 = load i64, ptr %l36, !tbaa !24
  %t578 = add i64 %t574, %t575
  store i64 %t578, ptr %l34, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb179
bb179:
  br label %bb148
bb180:
  %t580 = load ptr, ptr %l0, !tbaa !29
  %t582 = getelementptr %"compiler/free:Free", ptr %t580, i32 0, i32 34
  store ptr %t582, ptr %l39, !tbaa !29
  store i64 0, ptr %l40, !tbaa !24
  br label %bb181
bb181:
  store %olang.scope zeroinitializer, ptr %s32
  %t584 = load ptr, ptr %l39, !tbaa !29
  %t585 = load i64, ptr %l40, !tbaa !24
  %t588 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t584, i64 %t585)
  %t589 = extractvalue { i32, { i64, ptr } } %t588, 1
  %t590 = extractvalue { i32, { i64, ptr } } %t588, 0
  store i32 %t590, ptr %l379
  %t591 = icmp ne i32 %t590, 0
  br i1 %t591, label %bb183, label %ok.592
ok.592:
  store { i64, ptr } %t589, ptr %l378
  br label %bb182
bb182:
  %t593 = load { i64, ptr }, ptr %l378, !tbaa !27
  store { i64, ptr } %t593, ptr %l375, !tbaa !27
  br label %bb187
bb183:
  %t594 = load i32, ptr %l379, !tbaa !23
  %t595 = ashr i32 %t594, 16
  %t597 = icmp eq i32 %t595, 1
  br i1 %t597, label %bb184, label %bb185
bb184:
  br label %bb186
bb185:
  call void @__olang_check_failed(ptr @olang_loc_7525dd872e188514_1083808a0d947818)
  unreachable
bb186:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s32)
  br label %bb210
bb187:
  %t599 = load { i64, ptr }, ptr %l375, !tbaa !27
  store { i64, ptr } %t599, ptr %l41, !tbaa !27
  %t600 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t602 = extractvalue { i64, ptr } %t600, 0
  store i64 %t602, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb188
bb188:
  store %olang.scope zeroinitializer, ptr %s33
  %t604 = load i64, ptr %l43, !tbaa !24
  %t605 = load i64, ptr %l42, !tbaa !24
  %t608 = icmp slt i64 %t604, %t605
  %t610 = xor i1 %t608, true
  br i1 %t610, label %bb189, label %bb190
bb189:
  call void @__olang_scope_close(ptr %s33)
  br label %bb208
bb190:
  br label %bb191
bb191:
  %t612 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t612, ptr %l388, !tbaa !27
  %t613 = load i64, ptr %l43, !tbaa !24
  %t615 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !27
  %t617 = getelementptr %"compiler/free:store", ptr %t616, i64 %t613
  %t618 = load %"compiler/free:store", ptr %t617
  store %"compiler/free:store" %t618, ptr %l44
  %t620 = getelementptr %"compiler/free:store", ptr %l44, i32 0, i32 4
  %t621 = load i64, ptr %t620, !tbaa !24
  %t622 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t625 = icmp eq i64 %t621, %t622
  br i1 %t625, label %bb192, label %bb193
bb192:
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load %"compiler/free:store", ptr %l44
  %t631 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v0, ptr %t627, %"compiler/free:store" %t628)
  store i1 %t631, ptr %l397
  br label %bb194
bb193:
  store i1 false, ptr %l394, !tbaa !21
  br label %bb202
bb194:
  %t632 = load i1, ptr %l397, !tbaa !21
  %t633 = xor i1 %t632, true
  br i1 %t633, label %bb195, label %bb196
bb195:
  store i1 true, ptr %l399, !tbaa !21
  br label %bb201
bb196:
  %t635 = load ptr, ptr %l0, !tbaa !29
  store ptr %t635, ptr %l400, !tbaa !29
  %t636 = getelementptr %"compiler/free:store", ptr %l44, i32 0, i32 7
  %t637 = load ptr, ptr %t636, !tbaa !29
  %t639 = icmp eq ptr %t637, null
  br i1 %t639, label %bb197, label %bb198
bb197:
  call void @__olang_check_failed(ptr @olang_loc_4ad9b6421067a286_9f369779125df38a)
  unreachable
bb198:
  br label %bb199
bb199:
  %t641 = getelementptr %"compiler/free:store", ptr %l44, i32 0, i32 7
  %t642 = load ptr, ptr %t641, !tbaa !29
  %t643 = load ptr, ptr %l400, !tbaa !29
  %t645 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t643, ptr %t642)
  store i64 %t645, ptr %l404
  br label %bb200
bb200:
  %t646 = load i64, ptr %l404, !tbaa !24
  %t647 = icmp slt i64 %t646, 0
  store i1 %t647, ptr %l399, !tbaa !21
  br label %bb201
bb201:
  %t649 = load i1, ptr %l399, !tbaa !21
  store i1 %t649, ptr %l394, !tbaa !21
  br label %bb202
bb202:
  %t650 = load i1, ptr %l394, !tbaa !21
  br i1 %t650, label %bb203, label %bb204
bb203:
  store %olang.scope zeroinitializer, ptr %s34
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = getelementptr %"compiler/free:store", ptr %l44, i32 0, i32 0
  %t653 = load i64, ptr %t652, !tbaa !24
  %t654 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t655 = getelementptr %"compiler/free:store", ptr %l44, i32 0, i32 2
  %t656 = load i64, ptr %t655, !tbaa !24
  %t657 = getelementptr %"compiler/free:store", ptr %l44, i32 0, i32 3
  %t658 = load %"compiler/source:Span", ptr %t657
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s34, ptr %t651, i64 %t653, i64 %t654, i64 %t656, %"compiler/source:Span" %t658, { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb205
bb204:
  br label %bb206
bb205:
  call void @__olang_scope_close(ptr %s34)
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s33)
  br label %bb207
bb207:
  %t664 = load i64, ptr %l43, !tbaa !24
  %t666 = add i64 %t664, 1
  store i64 %t666, ptr %l43, !tbaa !24
  br label %bb188
bb208:
  %t668 = load i64, ptr %l40, !tbaa !24
  %t669 = load i64, ptr %l42, !tbaa !24
  %t672 = add i64 %t668, %t669
  store i64 %t672, ptr %l40, !tbaa !24
  call void @__olang_scope_close(ptr %s32)
  br label %bb209
bb209:
  br label %bb181
bb210:
  store i64 0, ptr %l45, !tbaa !24
  %t674 = load i64, ptr %l1, !tbaa !24
  store i64 %t674, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t676 = load i64, ptr %l46, !tbaa !24
  %t677 = load i64, ptr %l45, !tbaa !24
  %t680 = icmp sgt i64 %t676, %t677
  br i1 %t680, label %bb211, label %bb212
bb211:
  %t682 = load i64, ptr %l47, !tbaa !24
  %t684 = icmp sgt i64 %t682, 0
  br i1 %t684, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l420, !tbaa !24
  br label %bb216
bb213:
  %t686 = load i64, ptr %l46, !tbaa !24
  %t687 = load i64, ptr %l45, !tbaa !24
  %t690 = sub i64 %t686, %t687
  %t691 = load i64, ptr %l47, !tbaa !24
  %t694 = add i64 %t690, %t691
  %t696 = sub i64 %t694, 1
  %t697 = load i64, ptr %l47, !tbaa !24
  %t700 = sdiv i64 %t696, %t697
  store i64 %t700, ptr %l423, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l423, !tbaa !24
  br label %bb215
bb215:
  %t702 = load i64, ptr %l423, !tbaa !24
  store i64 %t702, ptr %l420, !tbaa !24
  br label %bb216
bb216:
  %t703 = load i64, ptr %l420, !tbaa !24
  store i64 %t703, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb217
bb217:
  store %olang.scope zeroinitializer, ptr %s37
  %t704 = load i64, ptr %l49, !tbaa !24
  %t705 = load i64, ptr %l48, !tbaa !24
  %t708 = icmp slt i64 %t704, %t705
  %t710 = xor i1 %t708, true
  br i1 %t710, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s37)
  br label %bb228
bb219:
  br label %bb220
bb220:
  %t712 = load i64, ptr %l45, !tbaa !24
  %t713 = load i64, ptr %l49, !tbaa !24
  %t714 = load i64, ptr %l47, !tbaa !24
  %t717 = mul i64 %t713, %t714
  %t720 = add i64 %t712, %t717
  store i64 %t720, ptr %l50, !tbaa !24
  %t722 = load ptr, ptr %l0, !tbaa !29
  %t724 = getelementptr %"compiler/free:Free", ptr %t722, i32 0, i32 63
  store ptr %t724, ptr %l442, !tbaa !29
  %t725 = load i64, ptr %l50, !tbaa !24
  store i64 %t725, ptr %l443, !tbaa !24
  %t726 = load ptr, ptr %l0, !tbaa !29
  %t728 = getelementptr %"compiler/free:Free", ptr %t726, i32 0, i32 62
  %t729 = load i64, ptr %l50, !tbaa !24
  %t732 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t728, i64 %t729)
  store i1 %t732, ptr %l447
  br label %bb221
bb221:
  %t733 = load i1, ptr %l447, !tbaa !21
  br i1 %t733, label %bb222, label %bb223
bb222:
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t736 = getelementptr %"compiler/free:Free", ptr %t734, i32 0, i32 36
  %t737 = load i64, ptr %l50, !tbaa !24
  %t740 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t736, i64 %t737)
  store i64 %t740, ptr %l452
  br label %bb224
bb223:
  store i1 false, ptr %l448, !tbaa !21
  br label %bb225
bb224:
  %t741 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t742 = load i64, ptr %l452, !tbaa !24
  %t744 = icmp eq i64 %t742, %t741
  store i1 %t744, ptr %l448, !tbaa !21
  br label %bb225
bb225:
  %t746 = load ptr, ptr %l442, !tbaa !29
  %t747 = load i64, ptr %l443, !tbaa !24
  %t748 = load i1, ptr %l448, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t746, i64 %t747, i1 %t748)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s37)
  br label %bb227
bb227:
  %t749 = load i64, ptr %l49, !tbaa !24
  %t751 = add i64 %t749, 1
  store i64 %t751, ptr %l49, !tbaa !24
  br label %bb217
bb228:
  br label %bb229
bb229:
  store %olang.scope zeroinitializer, ptr %s39
  store i1 false, ptr %l51, !tbaa !21
  %t753 = load ptr, ptr %l0, !tbaa !29
  %t755 = getelementptr %"compiler/free:Free", ptr %t753, i32 0, i32 34
  store ptr %t755, ptr %l52, !tbaa !29
  store i64 0, ptr %l53, !tbaa !24
  br label %bb230
bb230:
  store %olang.scope zeroinitializer, ptr %s41
  %t757 = load ptr, ptr %l52, !tbaa !29
  %t758 = load i64, ptr %l53, !tbaa !24
  %t761 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t757, i64 %t758)
  %t762 = extractvalue { i32, { i64, ptr } } %t761, 1
  %t763 = extractvalue { i32, { i64, ptr } } %t761, 0
  store i32 %t763, ptr %l463
  %t764 = icmp ne i32 %t763, 0
  br i1 %t764, label %bb232, label %ok.765
ok.765:
  store { i64, ptr } %t762, ptr %l462
  br label %bb231
bb231:
  %t766 = load { i64, ptr }, ptr %l462, !tbaa !27
  store { i64, ptr } %t766, ptr %l459, !tbaa !27
  br label %bb236
bb232:
  %t767 = load i32, ptr %l463, !tbaa !23
  %t768 = ashr i32 %t767, 16
  %t770 = icmp eq i32 %t768, 1
  br i1 %t770, label %bb233, label %bb234
bb233:
  br label %bb235
bb234:
  call void @__olang_check_failed(ptr @olang_loc_ead41433cbf9310a_52e529e4fec80746)
  unreachable
bb235:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s41)
  br label %bb263
bb236:
  %t772 = load { i64, ptr }, ptr %l459, !tbaa !27
  store { i64, ptr } %t772, ptr %l54, !tbaa !27
  %t773 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t775 = extractvalue { i64, ptr } %t773, 0
  store i64 %t775, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb237
bb237:
  store %olang.scope zeroinitializer, ptr %s42
  %t777 = load i64, ptr %l56, !tbaa !24
  %t778 = load i64, ptr %l55, !tbaa !24
  %t781 = icmp slt i64 %t777, %t778
  %t783 = xor i1 %t781, true
  br i1 %t783, label %bb238, label %bb239
bb238:
  call void @__olang_scope_close(ptr %s42)
  br label %bb261
bb239:
  br label %bb240
bb240:
  %t785 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t785, ptr %l472, !tbaa !27
  %t786 = load i64, ptr %l56, !tbaa !24
  %t788 = getelementptr { i64, ptr }, ptr %l472, i32 0, i32 1
  %t789 = load ptr, ptr %t788, !tbaa !27
  %t790 = getelementptr %"compiler/free:store", ptr %t789, i64 %t786
  %t791 = load %"compiler/free:store", ptr %t790
  store %"compiler/free:store" %t791, ptr %l57
  %t793 = getelementptr %"compiler/free:store", ptr %l57, i32 0, i32 4
  %t794 = load i64, ptr %t793, !tbaa !24
  %t795 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t798 = icmp eq i64 %t794, %t795
  br i1 %t798, label %bb241, label %bb242
bb241:
  %t800 = load ptr, ptr %l0, !tbaa !29
  %t802 = getelementptr %"compiler/free:Free", ptr %t800, i32 0, i32 62
  %t803 = getelementptr %"compiler/free:store", ptr %l57, i32 0, i32 0
  %t804 = load i64, ptr %t803, !tbaa !24
  %t807 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t802, i64 %t804)
  store i1 %t807, ptr %l482
  br label %bb243
bb242:
  store i1 false, ptr %l478, !tbaa !21
  br label %bb244
bb243:
  %t808 = load i1, ptr %l482, !tbaa !21
  store i1 %t808, ptr %l478, !tbaa !21
  br label %bb244
bb244:
  %t809 = load i1, ptr %l478, !tbaa !21
  br i1 %t809, label %bb245, label %bb246
bb245:
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t812 = getelementptr %"compiler/free:Free", ptr %t810, i32 0, i32 63
  %t813 = getelementptr %"compiler/free:store", ptr %l57, i32 0, i32 0
  %t814 = load i64, ptr %t813, !tbaa !24
  %t817 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t812, i64 %t814)
  store i1 %t817, ptr %l487
  br label %bb247
bb246:
  store i1 false, ptr %l483, !tbaa !21
  br label %bb248
bb247:
  %t818 = load i1, ptr %l487, !tbaa !21
  store i1 %t818, ptr %l483, !tbaa !21
  br label %bb248
bb248:
  %t819 = load i1, ptr %l483, !tbaa !21
  br i1 %t819, label %bb249, label %bb250
bb249:
  %t820 = getelementptr %"compiler/free:store", ptr %l57, i32 0, i32 5
  %t821 = load i64, ptr %t820, !tbaa !24
  %t822 = getelementptr %"compiler/free:store", ptr %l57, i32 0, i32 0
  %t823 = load i64, ptr %t822, !tbaa !24
  %t826 = icmp ne i64 %t821, %t823
  store i1 %t826, ptr %l488, !tbaa !21
  br label %bb251
bb250:
  store i1 false, ptr %l488, !tbaa !21
  br label %bb251
bb251:
  %t828 = load i1, ptr %l488, !tbaa !21
  br i1 %t828, label %bb252, label %bb253
bb252:
  %t829 = load ptr, ptr %l0, !tbaa !29
  %t831 = getelementptr %"compiler/free:Free", ptr %t829, i32 0, i32 63
  %t832 = getelementptr %"compiler/free:store", ptr %l57, i32 0, i32 5
  %t833 = load i64, ptr %t832, !tbaa !24
  %t836 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t831, i64 %t833)
  store i1 %t836, ptr %l496
  br label %bb254
bb253:
  store i1 false, ptr %l492, !tbaa !21
  br label %bb255
bb254:
  %t837 = load i1, ptr %l496, !tbaa !21
  %t838 = xor i1 %t837, true
  store i1 %t838, ptr %l492, !tbaa !21
  br label %bb255
bb255:
  %t840 = load i1, ptr %l492, !tbaa !21
  br i1 %t840, label %bb256, label %bb257
bb256:
  %t841 = load ptr, ptr %l0, !tbaa !29
  %t843 = getelementptr %"compiler/free:Free", ptr %t841, i32 0, i32 63
  %t844 = getelementptr %"compiler/free:store", ptr %l57, i32 0, i32 0
  %t845 = load i64, ptr %t844, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t843, i64 %t845, i1 false)
  br label %bb258
bb257:
  br label %bb259
bb258:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s42)
  br label %bb260
bb260:
  %t848 = load i64, ptr %l56, !tbaa !24
  %t850 = add i64 %t848, 1
  store i64 %t850, ptr %l56, !tbaa !24
  br label %bb237
bb261:
  %t852 = load i64, ptr %l53, !tbaa !24
  %t853 = load i64, ptr %l55, !tbaa !24
  %t856 = add i64 %t852, %t853
  store i64 %t856, ptr %l53, !tbaa !24
  call void @__olang_scope_close(ptr %s41)
  br label %bb262
bb262:
  br label %bb230
bb263:
  %t858 = load i1, ptr %l51, !tbaa !21
  %t860 = xor i1 %t858, true
  br i1 %t860, label %bb264, label %bb265
bb264:
  call void @__olang_scope_close(ptr %s39)
  br label %bb268
bb265:
  br label %bb266
bb266:
  call void @__olang_scope_close(ptr %s39)
  br label %bb267
bb267:
  br label %bb229
bb268:
  store i64 0, ptr %l58, !tbaa !24
  %t862 = load i64, ptr %l1, !tbaa !24
  store i64 %t862, ptr %l59, !tbaa !24
  store i64 1, ptr %l60, !tbaa !24
  %t864 = load i64, ptr %l59, !tbaa !24
  %t865 = load i64, ptr %l58, !tbaa !24
  %t868 = icmp sgt i64 %t864, %t865
  br i1 %t868, label %bb269, label %bb270
bb269:
  %t870 = load i64, ptr %l60, !tbaa !24
  %t872 = icmp sgt i64 %t870, 0
  br i1 %t872, label %bb271, label %bb272
bb270:
  store i64 0, ptr %l512, !tbaa !24
  br label %bb274
bb271:
  %t874 = load i64, ptr %l59, !tbaa !24
  %t875 = load i64, ptr %l58, !tbaa !24
  %t878 = sub i64 %t874, %t875
  %t879 = load i64, ptr %l60, !tbaa !24
  %t882 = add i64 %t878, %t879
  %t884 = sub i64 %t882, 1
  %t885 = load i64, ptr %l60, !tbaa !24
  %t888 = sdiv i64 %t884, %t885
  store i64 %t888, ptr %l515, !tbaa !24
  br label %bb273
bb272:
  store i64 0, ptr %l515, !tbaa !24
  br label %bb273
bb273:
  %t890 = load i64, ptr %l515, !tbaa !24
  store i64 %t890, ptr %l512, !tbaa !24
  br label %bb274
bb274:
  %t891 = load i64, ptr %l512, !tbaa !24
  store i64 %t891, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  br label %bb275
bb275:
  store %olang.scope zeroinitializer, ptr %s47
  %t892 = load i64, ptr %l62, !tbaa !24
  %t893 = load i64, ptr %l61, !tbaa !24
  %t896 = icmp slt i64 %t892, %t893
  %t898 = xor i1 %t896, true
  br i1 %t898, label %bb276, label %bb277
bb276:
  call void @__olang_scope_close(ptr %s47)
  br label %bb286
bb277:
  br label %bb278
bb278:
  %t900 = load i64, ptr %l58, !tbaa !24
  %t901 = load i64, ptr %l62, !tbaa !24
  %t902 = load i64, ptr %l60, !tbaa !24
  %t905 = mul i64 %t901, %t902
  %t908 = add i64 %t900, %t905
  store i64 %t908, ptr %l63, !tbaa !24
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t912 = getelementptr %"compiler/free:Free", ptr %t910, i32 0, i32 62
  %t913 = load i64, ptr %l63, !tbaa !24
  %t916 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t912, i64 %t913)
  store i1 %t916, ptr %l536
  br label %bb279
bb279:
  %t917 = load i1, ptr %l536, !tbaa !21
  br i1 %t917, label %bb280, label %bb281
bb280:
  store %olang.scope zeroinitializer, ptr %s48
  %t918 = load ptr, ptr %l0, !tbaa !29
  store ptr %t918, ptr %l537, !tbaa !29
  %t919 = load i64, ptr %l63, !tbaa !24
  store i64 %t919, ptr %l538, !tbaa !24
  %t920 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t920, ptr %l539, !tbaa !24
  %t921 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s48, i32 0, i32 0)
  store %"compiler/source:Span" %t921, ptr %l540
  br label %bb282
bb281:
  br label %bb284
bb282:
  %t922 = load ptr, ptr %l537, !tbaa !29
  %t923 = load i64, ptr %l538, !tbaa !24
  %t924 = load i64, ptr %l539, !tbaa !24
  %t925 = load %"compiler/source:Span", ptr %l540
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s48, ptr %t922, i64 %t923, i64 %t924, i64 -1, %"compiler/source:Span" %t925, { i64, ptr } { i64 135, ptr getelementptr inbounds (<{ i64, [135 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s48)
  br label %bb284
bb284:
  call void @__olang_scope_close(ptr %s47)
  br label %bb285
bb285:
  %t926 = load i64, ptr %l62, !tbaa !24
  %t928 = add i64 %t926, 1
  store i64 %t928, ptr %l62, !tbaa !24
  br label %bb275
bb286:
  store i64 0, ptr %l64, !tbaa !24
  %t930 = load i64, ptr %l1, !tbaa !24
  store i64 %t930, ptr %l65, !tbaa !24
  store i64 1, ptr %l66, !tbaa !24
  %t932 = load i64, ptr %l65, !tbaa !24
  %t933 = load i64, ptr %l64, !tbaa !24
  %t936 = icmp sgt i64 %t932, %t933
  br i1 %t936, label %bb287, label %bb288
bb287:
  %t938 = load i64, ptr %l66, !tbaa !24
  %t940 = icmp sgt i64 %t938, 0
  br i1 %t940, label %bb289, label %bb290
bb288:
  store i64 0, ptr %l547, !tbaa !24
  br label %bb292
bb289:
  %t942 = load i64, ptr %l65, !tbaa !24
  %t943 = load i64, ptr %l64, !tbaa !24
  %t946 = sub i64 %t942, %t943
  %t947 = load i64, ptr %l66, !tbaa !24
  %t950 = add i64 %t946, %t947
  %t952 = sub i64 %t950, 1
  %t953 = load i64, ptr %l66, !tbaa !24
  %t956 = sdiv i64 %t952, %t953
  store i64 %t956, ptr %l550, !tbaa !24
  br label %bb291
bb290:
  store i64 0, ptr %l550, !tbaa !24
  br label %bb291
bb291:
  %t958 = load i64, ptr %l550, !tbaa !24
  store i64 %t958, ptr %l547, !tbaa !24
  br label %bb292
bb292:
  %t959 = load i64, ptr %l547, !tbaa !24
  store i64 %t959, ptr %l67, !tbaa !24
  store i64 0, ptr %l68, !tbaa !24
  br label %bb293
bb293:
  store %olang.scope zeroinitializer, ptr %s51
  %t960 = load i64, ptr %l68, !tbaa !24
  %t961 = load i64, ptr %l67, !tbaa !24
  %t964 = icmp slt i64 %t960, %t961
  %t966 = xor i1 %t964, true
  br i1 %t966, label %bb294, label %bb295
bb294:
  call void @__olang_scope_close(ptr %s51)
  br label %bb307
bb295:
  br label %bb296
bb296:
  %t968 = load i64, ptr %l64, !tbaa !24
  %t969 = load i64, ptr %l68, !tbaa !24
  %t970 = load i64, ptr %l66, !tbaa !24
  %t973 = mul i64 %t969, %t970
  %t976 = add i64 %t968, %t973
  store i64 %t976, ptr %l69, !tbaa !24
  %t978 = load ptr, ptr %l0, !tbaa !29
  %t980 = getelementptr %"compiler/free:Free", ptr %t978, i32 0, i32 41
  store ptr %t980, ptr %l569, !tbaa !29
  %t981 = load i64, ptr %l69, !tbaa !24
  store i64 %t981, ptr %l570, !tbaa !24
  %t982 = load i64, ptr %l69, !tbaa !24
  %t984 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t985 = load ptr, ptr %t984, !tbaa !27
  %t986 = getelementptr i1, ptr %t985, i64 %t982
  %t987 = load i1, ptr %t986, !tbaa !31
  br i1 %t987, label %bb297, label %bb298
bb297:
  %t989 = load ptr, ptr %l0, !tbaa !29
  %t991 = getelementptr %"compiler/free:Free", ptr %t989, i32 0, i32 36
  %t992 = load i64, ptr %l69, !tbaa !24
  %t995 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t991, i64 %t992)
  store i64 %t995, ptr %l577
  br label %bb299
bb298:
  store i1 false, ptr %l573, !tbaa !21
  br label %bb300
bb299:
  %t996 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t997 = load i64, ptr %l577, !tbaa !24
  %t999 = icmp eq i64 %t997, %t996
  store i1 %t999, ptr %l573, !tbaa !21
  br label %bb300
bb300:
  %t1001 = load i1, ptr %l573, !tbaa !21
  br i1 %t1001, label %bb301, label %bb302
bb301:
  %t1002 = load ptr, ptr %l0, !tbaa !29
  %t1003 = load i64, ptr %l69, !tbaa !24
  %t1006 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t1002, i64 %t1003)
  store i1 %t1006, ptr %l583
  br label %bb303
bb302:
  store i1 false, ptr %l580, !tbaa !21
  br label %bb304
bb303:
  %t1007 = load i1, ptr %l583, !tbaa !21
  %t1008 = xor i1 %t1007, true
  store i1 %t1008, ptr %l580, !tbaa !21
  br label %bb304
bb304:
  %t1010 = load ptr, ptr %l569, !tbaa !29
  %t1011 = load i64, ptr %l570, !tbaa !24
  %t1012 = load i1, ptr %l580, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1010, i64 %t1011, i1 %t1012)
  br label %bb305
bb305:
  call void @__olang_scope_close(ptr %s51)
  br label %bb306
bb306:
  %t1013 = load i64, ptr %l68, !tbaa !24
  %t1015 = add i64 %t1013, 1
  store i64 %t1015, ptr %l68, !tbaa !24
  br label %bb293
bb307:
  br label %bb308
bb308:
  store %olang.scope zeroinitializer, ptr %s53
  store i1 false, ptr %l70, !tbaa !21
  %t1017 = load ptr, ptr %l0, !tbaa !29
  %t1019 = getelementptr %"compiler/free:Free", ptr %t1017, i32 0, i32 34
  store ptr %t1019, ptr %l71, !tbaa !29
  store i64 0, ptr %l72, !tbaa !24
  br label %bb309
bb309:
  store %olang.scope zeroinitializer, ptr %s55
  %t1021 = load ptr, ptr %l71, !tbaa !29
  %t1022 = load i64, ptr %l72, !tbaa !24
  %t1025 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t1021, i64 %t1022)
  %t1026 = extractvalue { i32, { i64, ptr } } %t1025, 1
  %t1027 = extractvalue { i32, { i64, ptr } } %t1025, 0
  store i32 %t1027, ptr %l593
  %t1028 = icmp ne i32 %t1027, 0
  br i1 %t1028, label %bb311, label %ok.1029
ok.1029:
  store { i64, ptr } %t1026, ptr %l592
  br label %bb310
bb310:
  %t1030 = load { i64, ptr }, ptr %l592, !tbaa !27
  store { i64, ptr } %t1030, ptr %l589, !tbaa !27
  br label %bb315
bb311:
  %t1031 = load i32, ptr %l593, !tbaa !23
  %t1032 = ashr i32 %t1031, 16
  %t1034 = icmp eq i32 %t1032, 1
  br i1 %t1034, label %bb312, label %bb313
bb312:
  br label %bb314
bb313:
  call void @__olang_check_failed(ptr @olang_loc_28957fcf5fdf754b_19b1529d8a3f7d27)
  unreachable
bb314:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s55)
  br label %bb336
bb315:
  %t1036 = load { i64, ptr }, ptr %l589, !tbaa !27
  store { i64, ptr } %t1036, ptr %l73, !tbaa !27
  %t1037 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t1039 = extractvalue { i64, ptr } %t1037, 0
  store i64 %t1039, ptr %l74, !tbaa !24
  store i64 0, ptr %l75, !tbaa !24
  br label %bb316
bb316:
  store %olang.scope zeroinitializer, ptr %s56
  %t1041 = load i64, ptr %l75, !tbaa !24
  %t1042 = load i64, ptr %l74, !tbaa !24
  %t1045 = icmp slt i64 %t1041, %t1042
  %t1047 = xor i1 %t1045, true
  br i1 %t1047, label %bb317, label %bb318
bb317:
  call void @__olang_scope_close(ptr %s56)
  br label %bb334
bb318:
  br label %bb319
bb319:
  %t1049 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t1049, ptr %l602, !tbaa !27
  %t1050 = load i64, ptr %l75, !tbaa !24
  %t1052 = getelementptr { i64, ptr }, ptr %l602, i32 0, i32 1
  %t1053 = load ptr, ptr %t1052, !tbaa !27
  %t1054 = getelementptr %"compiler/free:store", ptr %t1053, i64 %t1050
  %t1055 = load %"compiler/free:store", ptr %t1054
  store %"compiler/free:store" %t1055, ptr %l76
  %t1057 = getelementptr %"compiler/free:store", ptr %l76, i32 0, i32 4
  %t1058 = load i64, ptr %t1057, !tbaa !24
  %t1059 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t1062 = icmp eq i64 %t1058, %t1059
  br i1 %t1062, label %bb320, label %bb321
bb320:
  %t1064 = load ptr, ptr %l0, !tbaa !29
  %t1066 = getelementptr %"compiler/free:Free", ptr %t1064, i32 0, i32 41
  %t1067 = getelementptr %"compiler/free:store", ptr %l76, i32 0, i32 0
  %t1068 = load i64, ptr %t1067, !tbaa !24
  %t1071 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1066, i64 %t1068)
  store i1 %t1071, ptr %l612
  br label %bb322
bb321:
  store i1 false, ptr %l608, !tbaa !21
  br label %bb323
bb322:
  %t1072 = load i1, ptr %l612, !tbaa !21
  store i1 %t1072, ptr %l608, !tbaa !21
  br label %bb323
bb323:
  %t1073 = load i1, ptr %l608, !tbaa !21
  br i1 %t1073, label %bb324, label %bb325
bb324:
  %t1074 = load ptr, ptr %l0, !tbaa !29
  %t1076 = getelementptr %"compiler/free:Free", ptr %t1074, i32 0, i32 41
  %t1077 = getelementptr %"compiler/free:store", ptr %l76, i32 0, i32 5
  %t1078 = load i64, ptr %t1077, !tbaa !24
  %t1081 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1076, i64 %t1078)
  store i1 %t1081, ptr %l617
  br label %bb326
bb325:
  store i1 false, ptr %l613, !tbaa !21
  br label %bb327
bb326:
  %t1082 = load i1, ptr %l617, !tbaa !21
  %t1083 = xor i1 %t1082, true
  store i1 %t1083, ptr %l613, !tbaa !21
  br label %bb327
bb327:
  %t1085 = load i1, ptr %l613, !tbaa !21
  br i1 %t1085, label %bb328, label %bb329
bb328:
  store %olang.scope zeroinitializer, ptr %s57
  %t1086 = load ptr, ptr %l0, !tbaa !29
  %t1088 = getelementptr %"compiler/free:Free", ptr %t1086, i32 0, i32 41
  %t1089 = getelementptr %"compiler/free:store", ptr %l76, i32 0, i32 0
  %t1090 = load i64, ptr %t1089, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1088, i64 %t1090, i1 false)
  br label %bb330
bb329:
  br label %bb332
bb330:
  %t1093 = load ptr, ptr %l0, !tbaa !29
  %t1094 = getelementptr %"compiler/free:store", ptr %l76, i32 0, i32 0
  %t1095 = load i64, ptr %t1094, !tbaa !24
  %t1096 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t1097 = getelementptr %"compiler/free:store", ptr %l76, i32 0, i32 2
  %t1098 = load i64, ptr %t1097, !tbaa !24
  %t1099 = getelementptr %"compiler/free:store", ptr %l76, i32 0, i32 3
  %t1100 = load %"compiler/source:Span", ptr %t1099
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s57, ptr %t1093, i64 %t1095, i64 %t1096, i64 %t1098, %"compiler/source:Span" %t1100, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb331
bb331:
  store i1 true, ptr %l70, !tbaa !21
  call void @__olang_scope_close(ptr %s57)
  br label %bb332
bb332:
  call void @__olang_scope_close(ptr %s56)
  br label %bb333
bb333:
  %t1106 = load i64, ptr %l75, !tbaa !24
  %t1108 = add i64 %t1106, 1
  store i64 %t1108, ptr %l75, !tbaa !24
  br label %bb316
bb334:
  %t1110 = load i64, ptr %l72, !tbaa !24
  %t1111 = load i64, ptr %l74, !tbaa !24
  %t1114 = add i64 %t1110, %t1111
  store i64 %t1114, ptr %l72, !tbaa !24
  call void @__olang_scope_close(ptr %s55)
  br label %bb335
bb335:
  br label %bb309
bb336:
  %t1116 = load i1, ptr %l70, !tbaa !21
  %t1118 = xor i1 %t1116, true
  br i1 %t1118, label %bb337, label %bb338
bb337:
  call void @__olang_scope_close(ptr %s53)
  br label %bb341
bb338:
  br label %bb339
bb339:
  call void @__olang_scope_close(ptr %s53)
  br label %bb340
bb340:
  br label %bb308
bb341:
  store i64 0, ptr %l77, !tbaa !24
  %t1120 = load i64, ptr %l1, !tbaa !24
  store i64 %t1120, ptr %l78, !tbaa !24
  store i64 1, ptr %l79, !tbaa !24
  %t1122 = load i64, ptr %l78, !tbaa !24
  %t1123 = load i64, ptr %l77, !tbaa !24
  %t1126 = icmp sgt i64 %t1122, %t1123
  br i1 %t1126, label %bb342, label %bb343
bb342:
  %t1128 = load i64, ptr %l79, !tbaa !24
  %t1130 = icmp sgt i64 %t1128, 0
  br i1 %t1130, label %bb344, label %bb345
bb343:
  store i64 0, ptr %l638, !tbaa !24
  br label %bb347
bb344:
  %t1132 = load i64, ptr %l78, !tbaa !24
  %t1133 = load i64, ptr %l77, !tbaa !24
  %t1136 = sub i64 %t1132, %t1133
  %t1137 = load i64, ptr %l79, !tbaa !24
  %t1140 = add i64 %t1136, %t1137
  %t1142 = sub i64 %t1140, 1
  %t1143 = load i64, ptr %l79, !tbaa !24
  %t1146 = sdiv i64 %t1142, %t1143
  store i64 %t1146, ptr %l641, !tbaa !24
  br label %bb346
bb345:
  store i64 0, ptr %l641, !tbaa !24
  br label %bb346
bb346:
  %t1148 = load i64, ptr %l641, !tbaa !24
  store i64 %t1148, ptr %l638, !tbaa !24
  br label %bb347
bb347:
  %t1149 = load i64, ptr %l638, !tbaa !24
  store i64 %t1149, ptr %l80, !tbaa !24
  store i64 0, ptr %l81, !tbaa !24
  br label %bb348
bb348:
  store %olang.scope zeroinitializer, ptr %s61
  %t1150 = load i64, ptr %l81, !tbaa !24
  %t1151 = load i64, ptr %l80, !tbaa !24
  %t1154 = icmp slt i64 %t1150, %t1151
  %t1156 = xor i1 %t1154, true
  br i1 %t1156, label %bb349, label %bb350
bb349:
  call void @__olang_scope_close(ptr %s61)
  br label %bb445
bb350:
  br label %bb351
bb351:
  %t1158 = load i64, ptr %l77, !tbaa !24
  %t1159 = load i64, ptr %l81, !tbaa !24
  %t1160 = load i64, ptr %l79, !tbaa !24
  %t1163 = mul i64 %t1159, %t1160
  %t1166 = add i64 %t1158, %t1163
  store i64 %t1166, ptr %l82, !tbaa !24
  %t1168 = load ptr, ptr %l0, !tbaa !29
  %t1169 = load i64, ptr %l82, !tbaa !24
  %t1172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t1168, i64 %t1169)
  store i1 %t1172, ptr %l661
  br label %bb352
bb352:
  %t1173 = load i1, ptr %l661, !tbaa !21
  %t1174 = xor i1 %t1173, true
  br i1 %t1174, label %bb353, label %bb354
bb353:
  call void @__olang_scope_close(ptr %s61)
  br label %bb444
bb354:
  br label %bb355
bb355:
  %t1176 = load ptr, ptr %l0, !tbaa !29
  %t1178 = getelementptr %"compiler/free:Free", ptr %t1176, i32 0, i32 36
  %t1179 = load i64, ptr %l82, !tbaa !24
  %t1182 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t1178, i64 %t1179)
  store i64 %t1182, ptr %l666
  br label %bb356
bb356:
  %t1183 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t1184 = load i64, ptr %l666, !tbaa !24
  %t1186 = icmp eq i64 %t1184, %t1183
  br i1 %t1186, label %bb357, label %bb358
bb357:
  %t1188 = load ptr, ptr %l0, !tbaa !29
  %t1190 = getelementptr %"compiler/free:Free", ptr %t1188, i32 0, i32 58
  %t1191 = load i64, ptr %l82, !tbaa !24
  %t1194 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1190, i64 %t1191)
  store i1 %t1194, ptr %l673
  br label %bb359
bb358:
  store i1 false, ptr %l669, !tbaa !21
  br label %bb360
bb359:
  %t1195 = load i1, ptr %l673, !tbaa !21
  %t1196 = xor i1 %t1195, true
  store i1 %t1196, ptr %l669, !tbaa !21
  br label %bb360
bb360:
  %t1198 = load i1, ptr %l669, !tbaa !21
  store i1 %t1198, ptr %l83, !tbaa !21
  store i1 false, ptr %l84, !tbaa !21
  %t1199 = load ptr, ptr %l0, !tbaa !29
  %t1201 = getelementptr %"compiler/free:Free", ptr %t1199, i32 0, i32 34
  store ptr %t1201, ptr %l85, !tbaa !29
  store i64 0, ptr %l86, !tbaa !24
  br label %bb361
bb361:
  store %olang.scope zeroinitializer, ptr %s64
  %t1203 = load ptr, ptr %l85, !tbaa !29
  %t1204 = load i64, ptr %l86, !tbaa !24
  %t1207 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t1203, i64 %t1204)
  %t1208 = extractvalue { i32, { i64, ptr } } %t1207, 1
  %t1209 = extractvalue { i32, { i64, ptr } } %t1207, 0
  store i32 %t1209, ptr %l681
  %t1210 = icmp ne i32 %t1209, 0
  br i1 %t1210, label %bb363, label %ok.1211
ok.1211:
  store { i64, ptr } %t1208, ptr %l680
  br label %bb362
bb362:
  %t1212 = load { i64, ptr }, ptr %l680, !tbaa !27
  store { i64, ptr } %t1212, ptr %l677, !tbaa !27
  br label %bb367
bb363:
  %t1213 = load i32, ptr %l681, !tbaa !23
  %t1214 = ashr i32 %t1213, 16
  %t1216 = icmp eq i32 %t1214, 1
  br i1 %t1216, label %bb364, label %bb365
bb364:
  br label %bb366
bb365:
  call void @__olang_check_failed(ptr @olang_loc_970b795e64a6e941_bb6c860f435c1735)
  unreachable
bb366:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s64)
  br label %bb407
bb367:
  %t1218 = load { i64, ptr }, ptr %l677, !tbaa !27
  store { i64, ptr } %t1218, ptr %l87, !tbaa !27
  %t1219 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1221 = extractvalue { i64, ptr } %t1219, 0
  store i64 %t1221, ptr %l88, !tbaa !24
  store i64 0, ptr %l89, !tbaa !24
  br label %bb368
bb368:
  store %olang.scope zeroinitializer, ptr %s65
  %t1223 = load i64, ptr %l89, !tbaa !24
  %t1224 = load i64, ptr %l88, !tbaa !24
  %t1227 = icmp slt i64 %t1223, %t1224
  %t1229 = xor i1 %t1227, true
  br i1 %t1229, label %bb369, label %bb370
bb369:
  call void @__olang_scope_close(ptr %s65)
  br label %bb405
bb370:
  br label %bb371
bb371:
  %t1231 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t1231, ptr %l690, !tbaa !27
  %t1232 = load i64, ptr %l89, !tbaa !24
  %t1234 = getelementptr { i64, ptr }, ptr %l690, i32 0, i32 1
  %t1235 = load ptr, ptr %t1234, !tbaa !27
  %t1236 = getelementptr %"compiler/free:store", ptr %t1235, i64 %t1232
  %t1237 = load %"compiler/free:store", ptr %t1236
  store %"compiler/free:store" %t1237, ptr %l90
  %t1239 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 0
  %t1240 = load i64, ptr %t1239, !tbaa !24
  %t1241 = load i64, ptr %l82, !tbaa !24
  %t1244 = icmp ne i64 %t1240, %t1241
  br i1 %t1244, label %bb372, label %bb373
bb372:
  call void @__olang_scope_close(ptr %s65)
  br label %bb404
bb373:
  br label %bb374
bb374:
  store i1 true, ptr %l84, !tbaa !21
  %t1246 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 4
  %t1247 = load i64, ptr %t1246, !tbaa !24
  %t1248 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t1251 = icmp eq i64 %t1247, %t1248
  br i1 %t1251, label %bb375, label %bb376
bb375:
  %t1253 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 5
  %t1254 = load i64, ptr %t1253, !tbaa !24
  store i64 %t1254, ptr %l91, !tbaa !24
  %t1256 = load ptr, ptr %l0, !tbaa !29
  %t1258 = getelementptr %"compiler/free:Free", ptr %t1256, i32 0, i32 62
  %t1259 = load i64, ptr %l91, !tbaa !24
  %t1262 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1258, i64 %t1259)
  store i1 %t1262, ptr %l703
  br label %bb377
bb376:
  %t1263 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 4
  %t1264 = load i64, ptr %t1263, !tbaa !24
  %t1265 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  %t1268 = icmp eq i64 %t1264, %t1265
  br i1 %t1268, label %bb399, label %bb400
bb377:
  %t1270 = load i1, ptr %l703, !tbaa !21
  %t1271 = xor i1 %t1270, true
  br i1 %t1271, label %bb378, label %bb379
bb378:
  store %olang.scope zeroinitializer, ptr %s68
  %t1273 = load ptr, ptr %l0, !tbaa !29
  %t1274 = load i64, ptr %l82, !tbaa !24
  %t1275 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t1276 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 2
  %t1277 = load i64, ptr %t1276, !tbaa !24
  %t1278 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 3
  %t1279 = load %"compiler/source:Span", ptr %t1278
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s68, ptr %t1273, i64 %t1274, i64 %t1275, i64 %t1277, %"compiler/source:Span" %t1279, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb380
bb379:
  %t1285 = load ptr, ptr %l0, !tbaa !29
  %t1287 = getelementptr %"compiler/free:Free", ptr %t1285, i32 0, i32 17
  %t1288 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 1
  %t1289 = load i64, ptr %t1288, !tbaa !24
  %t1292 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1287, i64 %t1289)
  store i1 %t1292, ptr %l713
  br label %bb381
bb380:
  call void @__olang_scope_close(ptr %s68)
  br label %bb398
bb381:
  %t1293 = load i1, ptr %l713, !tbaa !21
  %t1294 = xor i1 %t1293, true
  br i1 %t1294, label %bb382, label %bb383
bb382:
  store %olang.scope zeroinitializer, ptr %s70
  %t1296 = load ptr, ptr %l0, !tbaa !29
  %t1297 = load i64, ptr %l82, !tbaa !24
  %t1298 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t1299 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 2
  %t1300 = load i64, ptr %t1299, !tbaa !24
  %t1301 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 3
  %t1302 = load %"compiler/source:Span", ptr %t1301
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s70, ptr %t1296, i64 %t1297, i64 %t1298, i64 %t1300, %"compiler/source:Span" %t1302, { i64, ptr } { i64 127, ptr getelementptr inbounds (<{ i64, [127 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb384
bb383:
  %t1308 = load ptr, ptr %l0, !tbaa !29
  %t1310 = getelementptr %"compiler/free:Free", ptr %t1308, i32 0, i32 63
  %t1311 = load i64, ptr %l91, !tbaa !24
  %t1314 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1310, i64 %t1311)
  store i1 %t1314, ptr %l723
  br label %bb385
bb384:
  call void @__olang_scope_close(ptr %s70)
  br label %bb397
bb385:
  %t1315 = load i1, ptr %l723, !tbaa !21
  %t1316 = xor i1 %t1315, true
  br i1 %t1316, label %bb386, label %bb387
bb386:
  store %olang.scope zeroinitializer, ptr %s72
  %t1318 = load ptr, ptr %l0, !tbaa !29
  %t1320 = getelementptr %"compiler/free:Free", ptr %t1318, i32 0, i32 38
  %t1321 = load i64, ptr %l91, !tbaa !24
  %t1324 = call %"compiler/free:reason" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t1320, i64 %t1321)
  store %"compiler/free:reason" %t1324, ptr %l728
  br label %bb388
bb387:
  br label %bb396
bb388:
  %t1325 = load %"compiler/free:reason", ptr %l728
  store %"compiler/free:reason" %t1325, ptr %l92
  %t1326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1326, ptr %l729, !tbaa !29
  %t1327 = load i64, ptr %l82, !tbaa !24
  store i64 %t1327, ptr %l730, !tbaa !24
  %t1328 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t1328, ptr %l731, !tbaa !24
  %t1329 = getelementptr %"compiler/free:reason", ptr %l92, i32 0, i32 1
  %t1330 = load i64, ptr %t1329, !tbaa !24
  %t1332 = icmp sge i64 %t1330, 0
  br i1 %t1332, label %bb389, label %bb390
bb389:
  %t1334 = getelementptr %"compiler/free:reason", ptr %l92, i32 0, i32 1
  %t1335 = load i64, ptr %t1334, !tbaa !24
  store i64 %t1335, ptr %l734, !tbaa !24
  br label %bb391
bb390:
  %t1337 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 2
  %t1338 = load i64, ptr %t1337, !tbaa !24
  store i64 %t1338, ptr %l734, !tbaa !24
  br label %bb391
bb391:
  %t1340 = getelementptr %"compiler/free:reason", ptr %l92, i32 0, i32 1
  %t1341 = load i64, ptr %t1340, !tbaa !24
  %t1343 = icmp sge i64 %t1341, 0
  br i1 %t1343, label %bb392, label %bb393
bb392:
  %t1345 = getelementptr %"compiler/free:reason", ptr %l92, i32 0, i32 2
  %t1346 = load %"compiler/source:Span", ptr %t1345
  store %"compiler/source:Span" %t1346, ptr %l739
  br label %bb394
bb393:
  %t1348 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 3
  %t1349 = load %"compiler/source:Span", ptr %t1348
  store %"compiler/source:Span" %t1349, ptr %l739
  br label %bb394
bb394:
  %t1351 = getelementptr %"compiler/free:reason", ptr %l92, i32 0, i32 3
  %t1352 = load { i64, ptr }, ptr %t1351, !tbaa !27
  %t1353 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t1354 = extractvalue { i64, ptr } { i64 75, ptr getelementptr inbounds (<{ i64, [75 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t1356 = extractvalue { i64, ptr } %t1352, 1
  %t1357 = extractvalue { i64, ptr } %t1352, 0
  %t1358 = add i64 %t1354, %t1357
  %t1359 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1358)
  call void @olang_textcopy(ptr %t1359, ptr %t1353, i64 %t1354)
  %t1360 = getelementptr i8, ptr %t1359, i64 %t1354
  call void @olang_textcopy(ptr %t1360, ptr %t1356, i64 %t1357)
  %t1361 = insertvalue { i64, ptr } undef, i64 %t1358, 0
  %t1362 = insertvalue { i64, ptr } %t1361, ptr %t1359, 1
  %t1364 = extractvalue { i64, ptr } %t1362, 0
  %t1365 = extractvalue { i64, ptr } %t1362, 1
  %t1366 = mul i64 %t1364, 1
  %t1367 = call ptr @__olang_scope_alloc(ptr %s72, i64 %t1366)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1367, ptr %t1365, i64 %t1366, i1 false)
  %t1368 = insertvalue { i64, ptr } undef, i64 %t1364, 0
  %t1369 = insertvalue { i64, ptr } %t1368, ptr %t1367, 1
  %t1370 = load ptr, ptr %l729, !tbaa !29
  %t1371 = load i64, ptr %l730, !tbaa !24
  %t1372 = load i64, ptr %l731, !tbaa !24
  %t1373 = load i64, ptr %l734, !tbaa !24
  %t1374 = load %"compiler/source:Span", ptr %l739
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s72, ptr %t1370, i64 %t1371, i64 %t1372, i64 %t1373, %"compiler/source:Span" %t1374, { i64, ptr } %t1369)
  br label %bb395
bb395:
  call void @__olang_scope_close(ptr %s72)
  br label %bb396
bb396:
  br label %bb397
bb397:
  br label %bb398
bb398:
  br label %bb403
bb399:
  store %olang.scope zeroinitializer, ptr %s75
  %t1376 = load ptr, ptr %l0, !tbaa !29
  %t1377 = load i64, ptr %l82, !tbaa !24
  %t1378 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t1379 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 2
  %t1380 = load i64, ptr %t1379, !tbaa !24
  %t1381 = getelementptr %"compiler/free:store", ptr %l90, i32 0, i32 3
  %t1382 = load %"compiler/source:Span", ptr %t1381
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s75, ptr %t1376, i64 %t1377, i64 %t1378, i64 %t1380, %"compiler/source:Span" %t1382, { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb401
bb400:
  br label %bb402
bb401:
  call void @__olang_scope_close(ptr %s75)
  br label %bb402
bb402:
  br label %bb403
bb403:
  call void @__olang_scope_close(ptr %s65)
  br label %bb404
bb404:
  %t1388 = load i64, ptr %l89, !tbaa !24
  %t1390 = add i64 %t1388, 1
  store i64 %t1390, ptr %l89, !tbaa !24
  br label %bb368
bb405:
  %t1392 = load i64, ptr %l86, !tbaa !24
  %t1393 = load i64, ptr %l88, !tbaa !24
  %t1396 = add i64 %t1392, %t1393
  store i64 %t1396, ptr %l86, !tbaa !24
  call void @__olang_scope_close(ptr %s64)
  br label %bb406
bb406:
  br label %bb361
bb407:
  %t1398 = load i1, ptr %l84, !tbaa !21
  %t1400 = xor i1 %t1398, true
  br i1 %t1400, label %bb408, label %bb409
bb408:
  store %olang.scope zeroinitializer, ptr %s77
  %t1402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1402, ptr %l760, !tbaa !29
  %t1403 = load i64, ptr %l82, !tbaa !24
  store i64 %t1403, ptr %l761, !tbaa !24
  %t1404 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t1404, ptr %l762, !tbaa !24
  %t1405 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s77, i32 0, i32 0)
  store %"compiler/source:Span" %t1405, ptr %l763
  br label %bb410
bb409:
  br label %bb412
bb410:
  %t1406 = load ptr, ptr %l760, !tbaa !29
  %t1407 = load i64, ptr %l761, !tbaa !24
  %t1408 = load i64, ptr %l762, !tbaa !24
  %t1409 = load %"compiler/source:Span", ptr %l763
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s77, ptr %t1406, i64 %t1407, i64 %t1408, i64 -1, %"compiler/source:Span" %t1409, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb411
bb411:
  call void @__olang_scope_close(ptr %s77)
  br label %bb412
bb412:
  %t1410 = load ptr, ptr %l0, !tbaa !29
  %t1412 = getelementptr %"compiler/free:Free", ptr %t1410, i32 0, i32 60
  store ptr %t1412, ptr %l765, !tbaa !29
  %t1413 = load i64, ptr %l82, !tbaa !24
  store i64 %t1413, ptr %l766, !tbaa !24
  %t1414 = load i1, ptr %l83, !tbaa !21
  br i1 %t1414, label %bb413, label %bb414
bb413:
  %t1416 = load ptr, ptr %l0, !tbaa !29
  %t1418 = getelementptr %"compiler/free:Free", ptr %t1416, i32 0, i32 36
  %t1419 = load i64, ptr %l82, !tbaa !24
  %t1422 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t1418, i64 %t1419)
  store i64 %t1422, ptr %l772
  br label %bb415
bb414:
  store i1 false, ptr %l768, !tbaa !21
  br label %bb416
bb415:
  %t1423 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t1424 = load i64, ptr %l772, !tbaa !24
  %t1426 = icmp eq i64 %t1424, %t1423
  store i1 %t1426, ptr %l768, !tbaa !21
  br label %bb416
bb416:
  %t1428 = load ptr, ptr %l765, !tbaa !29
  %t1429 = load i64, ptr %l766, !tbaa !24
  %t1430 = load i1, ptr %l768, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1428, i64 %t1429, i1 %t1430)
  br label %bb417
bb417:
  %t1431 = load ptr, ptr %l0, !tbaa !29
  %t1433 = getelementptr %"compiler/free:Free", ptr %t1431, i32 0, i32 60
  %t1434 = load i64, ptr %l82, !tbaa !24
  %t1437 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1433, i64 %t1434)
  store i1 %t1437, ptr %l778
  br label %bb418
bb418:
  %t1438 = load i1, ptr %l778, !tbaa !21
  %t1439 = xor i1 %t1438, true
  br i1 %t1439, label %bb419, label %bb420
bb419:
  call void @__olang_scope_close(ptr %s61)
  br label %bb444
bb420:
  br label %bb421
bb421:
  %t1441 = load ptr, ptr %l0, !tbaa !29
  %t1443 = getelementptr %"compiler/free:Free", ptr %t1441, i32 0, i32 34
  store ptr %t1443, ptr %l93, !tbaa !29
  store i64 0, ptr %l94, !tbaa !24
  br label %bb422
bb422:
  store %olang.scope zeroinitializer, ptr %s80
  %t1445 = load ptr, ptr %l93, !tbaa !29
  %t1446 = load i64, ptr %l94, !tbaa !24
  %t1449 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t1445, i64 %t1446)
  %t1450 = extractvalue { i32, { i64, ptr } } %t1449, 1
  %t1451 = extractvalue { i32, { i64, ptr } } %t1449, 0
  store i32 %t1451, ptr %l786
  %t1452 = icmp ne i32 %t1451, 0
  br i1 %t1452, label %bb424, label %ok.1453
ok.1453:
  store { i64, ptr } %t1450, ptr %l785
  br label %bb423
bb423:
  %t1454 = load { i64, ptr }, ptr %l785, !tbaa !27
  store { i64, ptr } %t1454, ptr %l782, !tbaa !27
  br label %bb428
bb424:
  %t1455 = load i32, ptr %l786, !tbaa !23
  %t1456 = ashr i32 %t1455, 16
  %t1458 = icmp eq i32 %t1456, 1
  br i1 %t1458, label %bb425, label %bb426
bb425:
  br label %bb427
bb426:
  call void @__olang_check_failed(ptr @olang_loc_83b66f45861ca9b0_7b02274503008844)
  unreachable
bb427:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s80)
  br label %bb443
bb428:
  %t1460 = load { i64, ptr }, ptr %l782, !tbaa !27
  store { i64, ptr } %t1460, ptr %l95, !tbaa !27
  %t1461 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t1463 = extractvalue { i64, ptr } %t1461, 0
  store i64 %t1463, ptr %l96, !tbaa !24
  store i64 0, ptr %l97, !tbaa !24
  br label %bb429
bb429:
  store %olang.scope zeroinitializer, ptr %s81
  %t1465 = load i64, ptr %l97, !tbaa !24
  %t1466 = load i64, ptr %l96, !tbaa !24
  %t1469 = icmp slt i64 %t1465, %t1466
  %t1471 = xor i1 %t1469, true
  br i1 %t1471, label %bb430, label %bb431
bb430:
  call void @__olang_scope_close(ptr %s81)
  br label %bb441
bb431:
  br label %bb432
bb432:
  %t1473 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t1473, ptr %l795, !tbaa !27
  %t1474 = load i64, ptr %l97, !tbaa !24
  %t1476 = getelementptr { i64, ptr }, ptr %l795, i32 0, i32 1
  %t1477 = load ptr, ptr %t1476, !tbaa !27
  %t1478 = getelementptr %"compiler/free:store", ptr %t1477, i64 %t1474
  %t1479 = load %"compiler/free:store", ptr %t1478
  store %"compiler/free:store" %t1479, ptr %l98
  %t1481 = getelementptr %"compiler/free:store", ptr %l98, i32 0, i32 0
  %t1482 = load i64, ptr %t1481, !tbaa !24
  %t1483 = load i64, ptr %l82, !tbaa !24
  %t1486 = icmp eq i64 %t1482, %t1483
  br i1 %t1486, label %bb433, label %bb434
bb433:
  %t1488 = getelementptr %"compiler/free:store", ptr %l98, i32 0, i32 4
  %t1489 = load i64, ptr %t1488, !tbaa !24
  %t1490 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t1493 = icmp eq i64 %t1489, %t1490
  store i1 %t1493, ptr %l801, !tbaa !21
  br label %bb435
bb434:
  store i1 false, ptr %l801, !tbaa !21
  br label %bb435
bb435:
  %t1495 = load i1, ptr %l801, !tbaa !21
  br i1 %t1495, label %bb436, label %bb437
bb436:
  %t1496 = load ptr, ptr %l0, !tbaa !29
  %t1498 = getelementptr %"compiler/free:Free", ptr %t1496, i32 0, i32 64
  %t1499 = getelementptr %"compiler/free:store", ptr %l98, i32 0, i32 5
  %t1500 = load i64, ptr %t1499, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1498, i64 %t1500, i1 true)
  br label %bb438
bb437:
  br label %bb439
bb438:
  br label %bb439
bb439:
  call void @__olang_scope_close(ptr %s81)
  br label %bb440
bb440:
  %t1503 = load i64, ptr %l97, !tbaa !24
  %t1505 = add i64 %t1503, 1
  store i64 %t1505, ptr %l97, !tbaa !24
  br label %bb429
bb441:
  %t1507 = load i64, ptr %l94, !tbaa !24
  %t1508 = load i64, ptr %l96, !tbaa !24
  %t1511 = add i64 %t1507, %t1508
  store i64 %t1511, ptr %l94, !tbaa !24
  call void @__olang_scope_close(ptr %s80)
  br label %bb442
bb442:
  br label %bb422
bb443:
  call void @__olang_scope_close(ptr %s61)
  br label %bb444
bb444:
  %t1513 = load i64, ptr %l81, !tbaa !24
  %t1515 = add i64 %t1513, 1
  store i64 %t1515, ptr %l81, !tbaa !24
  br label %bb348
bb445:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i32, ptr %l19
  %t34 = trunc i64 18 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t37, i32 %t38)
  store i1 %t41, ptr %l25
  br label %bb12
bb11:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb13
bb12:
  %t42 = load i1, ptr %l25, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l22, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t45 = load i32, ptr %l3, !tbaa !23
  %t48 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t44, i32 %t45)
  store i1 %t48, ptr %l29
  br label %bb16
bb15:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb17
bb16:
  %t49 = load i1, ptr %l29, !tbaa !21
  store i1 %t49, ptr %l26, !tbaa !21
  br label %bb17
bb17:
  %t50 = load i1, ptr %l26, !tbaa !21
  store i1 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindDestroy(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l22 = alloca i1
  %l26 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l29 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l50 = alloca i1
  %l54 = alloca i64
  %l77 = alloca ptr
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 9
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 4
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb45
bb5:
  %t22 = load i32, ptr %l3
  %t24 = trunc i64 30 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb8
bb7:
  %t29 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t33 = icmp ne i64 %t31, 1
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t36, ptr %l26, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = getelementptr ptr, ptr %t38, i64 0
  %t40 = load ptr, ptr %t39, !tbaa !39
  store ptr %t40, ptr %l5, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb12, label %bb13
bb12:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 2
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb14, label %bb15
bb14:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr { i64, [5 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t53, i32 0, i32 1
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l6, !tbaa !23
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l7, !tbaa !29
  br label %bb16
bb15:
  br label %bb39
bb16:
  %t63 = load ptr, ptr %l7, !tbaa !29
  store ptr %t63, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 0
  store i1 %t70, ptr %l37, !tbaa !21
  br label %bb18
bb18:
  %t71 = load i1, ptr %l37, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t72 = load ptr, ptr %l7, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t74, i32 0, i32 2
  %t76 = load i32, ptr %t75
  store i32 %t76, ptr %l8, !tbaa !23
  br label %bb21
bb20:
  br label %bb33
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:Free", ptr %t78, i32 0, i32 65
  %t81 = load i64, ptr %t80, !tbaa !24
  %t82 = load i32, ptr %l8, !tbaa !23
  %t84 = sext i32 %t82 to i64
  %t87 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t81, i64 %t84)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t87, ptr %l46
  br label %bb22
bb22:
  %t88 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l46
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t88, ptr %l9
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 53
  %t92 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l9
  %t95 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t91, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t92)
  store i1 %t95, ptr %l50
  br label %bb23
bb23:
  %t96 = load i1, ptr %l50, !tbaa !21
  br i1 %t96, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb25:
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l6, !tbaa !23
  %t99 = load i32, ptr %l6, !tbaa !23
  %t103 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t97, i32 %t98, i64 -2, i1 false, i32 %t99, i1 false)
  store i64 %t103, ptr %l54
  br label %bb27
bb27:
  %t104 = load i64, ptr %l54, !tbaa !24
  store i64 %t104, ptr %l10, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:Free", ptr %t105, i32 0, i32 53
  %t108 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l9
  %t109 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t107, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t108, i64 %t109)
  br label %bb28
bb28:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:Free", ptr %t113, i32 0, i32 54
  %t116 = load i64, ptr %l10, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:Free", ptr %t117, i32 0, i32 65
  %t120 = load i64, ptr %t119, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t115, i64 %t116, i64 %t120)
  br label %bb29
bb29:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:Free", ptr %t124, i32 0, i32 55
  %t127 = load i64, ptr %l10, !tbaa !24
  %t128 = load i32, ptr %l8, !tbaa !23
  %t130 = sext i32 %t128 to i64
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t126, i64 %t127, i64 %t130)
  br label %bb30
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:Free", ptr %t134, i32 0, i32 56
  %t137 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t136, i64 %t137, %"compiler/source:Span" %a1)
  br label %bb31
bb31:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/free:Free", ptr %t142, i32 0, i32 61
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:Free", ptr %t145, i32 0, i32 65
  %t148 = load i64, ptr %t147, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t144, i64 %t148, i1 true)
  br label %bb32
bb32:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l77, !tbaa !29
  %t152 = load ptr, ptr %l77, !tbaa !29
  %t153 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 52
  %t154 = load i64, ptr %t153, !tbaa !24
  %t156 = add i64 %t154, 1
  %t158 = load ptr, ptr %l77, !tbaa !29
  %t159 = getelementptr %"compiler/free:Free", ptr %t158, i32 0, i32 52
  store i64 %t156, ptr %t159, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_abb447fb014369ff_ca54bae4e013147b)
  unreachable
bb38:
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_b390d81e3df133fe_1bb65207cb7ceffa)
  unreachable
bb44:
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_f1cf9d8b5dd1d1b5_4d41c45ca418d191)
  unreachable
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i64
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l59 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l119 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca i1
  %l150 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l182 = alloca ptr
  %l203 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i1
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store i64 %t26, ptr %l40
  br label %bb6
bb6:
  %t27 = load i64, ptr %l40, !tbaa !24
  %t28 = icmp slt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t30, i32 %t31)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l44
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %bb131
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t36 = load ptr, ptr %l45, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l45, !tbaa !29
  %t40 = load i64, ptr %t39
  %t42 = icmp eq i64 %t40, 6
  store i1 %t42, ptr %l46, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l46, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Call", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t67, ptr %l59, !tbaa !27
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr ptr, ptr %t71, i64 %t68
  %t73 = load ptr, ptr %t72, !tbaa !39
  %t75 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t75, ptr %t73)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  br label %bb131
bb24:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t84 = load ptr, ptr %l66, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l66, !tbaa !29
  %t88 = load i64, ptr %t87
  %t90 = icmp eq i64 %t88, 14
  store i1 %t90, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l67, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l9, !tbaa !29
  br label %bb29
bb28:
  br label %bb50
bb29:
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Try", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l76, !tbaa !29
  %t108 = load ptr, ptr %l9, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Try", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_7bd178b281ab108b_bca5961225cfb287)
  unreachable
bb33:
  br label %bb34
bb34:
  %t115 = load ptr, ptr %l9, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Try", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t119, ptr %t118)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t121 = load ptr, ptr %l9, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Try", ptr %t121, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb39:
  br label %bb40
bb40:
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t138, ptr %l90, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 %t139
  %t144 = load ptr, ptr %t143, !tbaa !39
  store ptr %t144, ptr %l13, !tbaa !29
  %t146 = load ptr, ptr %l13, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Clause", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb41, label %bb42
bb41:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l97, !tbaa !29
  %t156 = load ptr, ptr %l13, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Clause", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb43, label %bb44
bb42:
  br label %bb47
bb43:
  call void @__olang_check_failed(ptr @olang_loc_54a8cb88ede7d99c_f1d49282556d5568)
  unreachable
bb44:
  br label %bb45
bb45:
  %t163 = load ptr, ptr %l13, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Clause", ptr %t163, i32 0, i32 3
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t167, ptr %t166)
  br label %bb46
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb48:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l11, !tbaa !24
  br label %bb37
bb49:
  br label %bb131
bb50:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t174 = load ptr, ptr %l105, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t177 = load ptr, ptr %l105, !tbaa !29
  %t178 = load i64, ptr %t177
  %t180 = icmp eq i64 %t178, 12
  store i1 %t180, ptr %l106, !tbaa !21
  br label %bb52
bb52:
  %t181 = load i1, ptr %l106, !tbaa !21
  br i1 %t181, label %bb53, label %bb54
bb53:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l14, !tbaa !29
  br label %bb55
bb54:
  br label %bb70
bb55:
  %t188 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Seq", ptr %t188, i32 0, i32 0
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l17, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s15
  %t197 = load i64, ptr %l16, !tbaa !24
  %t198 = load i64, ptr %l17, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t205 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t205, ptr %l119, !tbaa !27
  %t206 = load i64, ptr %l16, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t213 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %t213, ptr %t211)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s15)
  br label %bb61
bb61:
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l16, !tbaa !24
  br label %bb56
bb62:
  %t221 = load ptr, ptr %l14, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Seq", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb63, label %bb64
bb63:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l130, !tbaa !29
  %t231 = load ptr, ptr %l14, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Seq", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = icmp eq ptr %t234, null
  br i1 %t236, label %bb65, label %bb66
bb64:
  br label %bb69
bb65:
  call void @__olang_check_failed(ptr @olang_loc_df2621a9cc7e5891_c8dc80a57ad57a3d)
  unreachable
bb66:
  br label %bb67
bb67:
  %t238 = load ptr, ptr %l14, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Seq", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t242, ptr %t241)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb131
bb70:
  %t244 = load ptr, ptr %l1, !tbaa !29
  store ptr %t244, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t245 = load ptr, ptr %l136, !tbaa !29
  %t246 = icmp ne ptr %t245, null
  br i1 %t246, label %bb71, label %bb72
bb71:
  %t248 = load ptr, ptr %l136, !tbaa !29
  %t249 = load i64, ptr %t248
  %t251 = icmp eq i64 %t249, 13
  store i1 %t251, ptr %l137, !tbaa !21
  br label %bb72
bb72:
  %t252 = load i1, ptr %l137, !tbaa !21
  br i1 %t252, label %bb73, label %bb74
bb73:
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t255, i32 0, i32 2
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l19, !tbaa !29
  br label %bb75
bb74:
  br label %bb119
bb75:
  %t259 = load ptr, ptr %l19, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Match", ptr %t259, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  store i64 %t266, ptr %l22, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s20
  %t268 = load i64, ptr %l21, !tbaa !24
  %t269 = load i64, ptr %l22, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s20)
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t276 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t276, ptr %l150, !tbaa !27
  %t277 = load i64, ptr %l21, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr ptr, ptr %t280, i64 %t277
  %t282 = load ptr, ptr %t281, !tbaa !39
  %t284 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %t284, ptr %t282)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s20)
  br label %bb81
bb81:
  %t288 = load i64, ptr %l21, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l21, !tbaa !24
  br label %bb76
bb82:
  %t292 = load ptr, ptr %l19, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Match", ptr %t292, i32 0, i32 1
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !27
  store { i64, ptr } %t295, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  store i64 %t299, ptr %l26, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s23
  %t301 = load i64, ptr %l25, !tbaa !24
  %t302 = load i64, ptr %l26, !tbaa !24
  %t305 = icmp slt i64 %t301, %t302
  %t307 = xor i1 %t305, true
  br i1 %t307, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s23)
  br label %bb102
bb85:
  br label %bb86
bb86:
  %t309 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t309, ptr %l165, !tbaa !27
  %t310 = load i64, ptr %l25, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr ptr, ptr %t313, i64 %t310
  %t315 = load ptr, ptr %t314, !tbaa !39
  store ptr %t315, ptr %l27, !tbaa !29
  %t317 = load ptr, ptr %l27, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Arm", ptr %t317, i32 0, i32 3
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb87, label %bb88
bb87:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l172, !tbaa !29
  %t327 = load ptr, ptr %l27, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Arm", ptr %t327, i32 0, i32 3
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = icmp eq ptr %t330, null
  br i1 %t332, label %bb89, label %bb90
bb88:
  br label %bb93
bb89:
  call void @__olang_check_failed(ptr @olang_loc_d176219a3bee3f8a_90c874c8f8700e56)
  unreachable
bb90:
  br label %bb91
bb91:
  %t334 = load ptr, ptr %l27, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Arm", ptr %t334, i32 0, i32 3
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t338 = load ptr, ptr %l172, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t338, ptr %t337)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t340 = load ptr, ptr %l27, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Arm", ptr %t340, i32 0, i32 4
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = icmp eq ptr %t343, null
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb94, label %bb95
bb94:
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l182, !tbaa !29
  %t350 = load ptr, ptr %l27, !tbaa !29
  %t352 = getelementptr %"compiler/typed:Arm", ptr %t350, i32 0, i32 4
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = icmp eq ptr %t353, null
  br i1 %t355, label %bb96, label %bb97
bb95:
  br label %bb100
bb96:
  call void @__olang_check_failed(ptr @olang_loc_3832ed25f787c577_46d12f44adcfa45b)
  unreachable
bb97:
  br label %bb98
bb98:
  %t357 = load ptr, ptr %l27, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Arm", ptr %t357, i32 0, i32 4
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t361 = load ptr, ptr %l182, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t361, ptr %t360)
  br label %bb99
bb99:
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s23)
  br label %bb101
bb101:
  %t363 = load i64, ptr %l25, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l25, !tbaa !24
  br label %bb83
bb102:
  %t367 = load ptr, ptr %l19, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Match", ptr %t367, i32 0, i32 2
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb103, label %bb104
bb103:
  %t376 = load ptr, ptr %l19, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Match", ptr %t376, i32 0, i32 2
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t381 = icmp eq ptr %t379, null
  br i1 %t381, label %bb105, label %bb106
bb104:
  br label %bb118
bb105:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb106:
  br label %bb107
bb107:
  %t383 = load ptr, ptr %l19, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Match", ptr %t383, i32 0, i32 2
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Arm", ptr %t386, i32 0, i32 3
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = icmp eq ptr %t390, null
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb108, label %bb109
bb108:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l203, !tbaa !29
  %t397 = load ptr, ptr %l19, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Match", ptr %t397, i32 0, i32 2
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = icmp eq ptr %t400, null
  br i1 %t402, label %bb110, label %bb111
bb109:
  br label %bb117
bb110:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb111:
  br label %bb112
bb112:
  %t404 = load ptr, ptr %l19, !tbaa !29
  %t406 = getelementptr %"compiler/typed:Match", ptr %t404, i32 0, i32 2
  %t407 = load ptr, ptr %t406, !tbaa !29
  %t410 = getelementptr %"compiler/typed:Arm", ptr %t407, i32 0, i32 3
  %t411 = load ptr, ptr %t410, !tbaa !29
  store ptr %t411, ptr %l28, !tbaa !29
  %t413 = load ptr, ptr %l28, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb113, label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb114:
  br label %bb115
bb115:
  %t417 = load ptr, ptr %l28, !tbaa !29
  %t418 = load ptr, ptr %l203, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t418, ptr %t417)
  br label %bb116
bb116:
  br label %bb117
bb117:
  br label %bb118
bb118:
  br label %bb131
bb119:
  %t420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t420, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t421 = load ptr, ptr %l214, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb120, label %bb121
bb120:
  %t424 = load ptr, ptr %l214, !tbaa !29
  %t425 = load i64, ptr %t424
  %t427 = icmp eq i64 %t425, 8
  store i1 %t427, ptr %l215, !tbaa !21
  br label %bb121
bb121:
  %t428 = load i1, ptr %l215, !tbaa !21
  br i1 %t428, label %bb122, label %bb123
bb122:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t431, i32 0, i32 2
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l29, !tbaa !29
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l29, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Collect", ptr %t436, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t435, ptr %t439)
  br label %bb125
bb125:
  br label %bb131
bb126:
  br i1 true, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_5c0fdc79e2d66a14_68e7480db742a728)
  unreachable
bb131:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l33 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i32, ptr %l9, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l12
  br label %bb3
bb3:
  %t16 = load i32, ptr %l12
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb9:
  %t32 = load ptr, ptr %l2, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l25
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l26
  br label %bb11
bb11:
  %t41 = load i32, ptr %l26
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l33
  br label %bb16
bb16:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %l35, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l38
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i32, ptr %l38, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t63, i32 %t64)
  store { i64, ptr } %t65, ptr %l39
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp eq i64 %t69, 1
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l45, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 0
  %t78 = load i32, ptr %t77, !tbaa !33
  %t81 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t73, i32 %t78)
  store i1 %t81, ptr %l47
  br label %bb24
bb23:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  %t82 = load i1, ptr %l47, !tbaa !21
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l43, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i1
  %l25 = alloca %"compiler/typed:Plan"
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l64 = alloca i1
  %l72 = alloca { i64, [1 x i64] }
  %l74 = alloca { i64, [1 x i64] }
  %l76 = alloca i1
  %l77 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca i64
  %l85 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, [1 x i64] }
  %l94 = alloca { i64, [1 x i64] }
  %l96 = alloca i1
  %l98 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  %t15 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t15, ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t15, i64 152, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l25, i64 152, i1 false)
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l26, !tbaa !24
  %t19 = load i64, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = shl i64 1, %t20
  store i64 %t21, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Call", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l10, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l10, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l12, !tbaa !24
  %t59 = load i64, ptr %l11, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l13, !tbaa !24
  %t82 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  store i64 %t82, ptr %l58
  br label %bb18
bb18:
  %t83 = load i64, ptr %l58, !tbaa !24
  store i64 %t83, ptr %l14, !tbaa !24
  %t84 = load i64, ptr %l14, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  %t88 = load i64, ptr %l14, !tbaa !24
  %t90 = icmp sge i64 %t88, 63
  store i1 %t90, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l61, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb24
bb23:
  %t93 = load i64, ptr %l14, !tbaa !24
  %t94 = load i64, ptr %l5, !tbaa !24
  %t97 = icmp eq i64 %t93, %t94
  store i1 %t97, ptr %l64, !tbaa !21
  br label %bb24
bb24:
  %t99 = load i1, ptr %l64, !tbaa !21
  br i1 %t99, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Call", ptr %t100, i32 0, i32 3
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = load i64, ptr %l14, !tbaa !24
  %t108 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l6, i32 %t103, i64 %t104)
  store { i64, [1 x i64] } %t108, ptr %l72
  br label %bb28
bb28:
  %t109 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t109, ptr %l74
  %t112 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l72, ptr %l74)
  store i1 %t112, ptr %l76
  br label %bb29
bb29:
  %t113 = load i1, ptr %l76, !tbaa !21
  br i1 %t113, label %bb30, label %bb31
bb30:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load ptr, ptr %l2, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Call", ptr %t115, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l80, !tbaa !27
  %t119 = load i64, ptr %l13, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr ptr, ptr %t122, i64 %t119
  %t124 = load ptr, ptr %t123, !tbaa !39
  %t127 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t114, ptr %t124)
  store i64 %t127, ptr %l83
  br label %bb32
bb31:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb33
bb32:
  %t128 = load i64, ptr %l83, !tbaa !24
  %t129 = icmp sge i64 %t128, 0
  store i1 %t129, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t131 = load i1, ptr %l77, !tbaa !21
  br i1 %t131, label %bb34, label %bb35
bb34:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Call", ptr %t134, i32 0, i32 1
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l89, !tbaa !27
  %t138 = load i64, ptr %l13, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr ptr, ptr %t141, i64 %t138
  %t143 = load ptr, ptr %t142, !tbaa !39
  %t147 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t132, i64 %t133, ptr %t143)
  store { i64, [1 x i64] } %t147, ptr %l92
  br label %bb36
bb35:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb38
bb36:
  %t148 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t148, ptr %l94
  %t151 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l92, ptr %l94)
  store i1 %t151, ptr %l96
  br label %bb37
bb37:
  %t152 = load i1, ptr %l96, !tbaa !21
  store i1 %t152, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t153 = load i1, ptr %l85, !tbaa !21
  br i1 %t153, label %bb39, label %bb40
bb39:
  %t154 = load i64, ptr %l7, !tbaa !24
  %t155 = load i64, ptr %l14, !tbaa !24
  store i64 %t155, ptr %l98, !tbaa !24
  %t156 = load i64, ptr %l98, !tbaa !24
  %t157 = load i64, ptr %l98, !tbaa !24
  %t158 = shl i64 1, %t157
  %t161 = or i64 %t154, %t158
  store i64 %t161, ptr %l7, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t163 = load i64, ptr %l12, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l12, !tbaa !24
  br label %bb14
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:Free", ptr %t167, i32 0, i32 2
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l3, !tbaa !24
  %t174 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t170, i64 %t171)
  store { i64, ptr } %t174, ptr %l106
  br label %bb44
bb44:
  %t175 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i64, ptr %l7, !tbaa !24
  %t182 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t176, { i64, ptr } %t175, i64 %t178)
  store i1 %t182, ptr %l110
  br label %bb45
bb45:
  %t183 = load i1, ptr %l110, !tbaa !21
  br i1 %t183, label %bb46, label %bb47
bb46:
  %t184 = load i64, ptr %l7, !tbaa !24
  store i64 %t184, ptr %l111, !tbaa !24
  br label %bb48
bb47:
  store i64 -1, ptr %l111, !tbaa !24
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t186 = load i64, ptr %l111, !tbaa !24
  store i64 %t186, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 4
  %t5 = load %"compiler/source:Span", ptr %t4
  %t9 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %t3, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i32, ptr %l16, !tbaa !23
  %t30 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t27, i32 %t28, i64 %t26)
  store i64 %t30, ptr %l18
  br label %bb7
bb7:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb22
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l25, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t52)
  store i32 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i32, ptr %l29, !tbaa !23
  %t57 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t57, ptr %l30
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l25, !tbaa !29
  %t59 = load i32, ptr %l30, !tbaa !23
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t58, i32 %t59, i64 -1)
  store i64 %t60, ptr %l31
  br label %bb16
bb16:
  %t61 = load i64, ptr %l31, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c44d6b41b035ab1_55f561a861d07b6d)
  unreachable
bb22:
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:store"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca ptr
  %l44 = alloca %"compiler/free:store"
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l56 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i64
  %l67 = alloca { i64, [1 x i64] }
  %l70 = alloca i64
  %l71 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:store" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t2 = load ptr, ptr %t1, !tbaa !29
  %t4 = icmp eq ptr %t2, null
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_3bfd4abaed3d7178_ecedd42d9535955c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t6 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t16 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t9, i64 %t11, ptr %t12)
  store { i64, [1 x i64] } %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load { i64, [1 x i64] }, ptr %l13
  %t18 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t17)
  store i1 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call ptr @compiler_2ffree_2ecallOf(ptr %v1, ptr %t23)
  store ptr %t25, ptr %l18
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l18, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t28 = load ptr, ptr %l19, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 5
  store i1 %t34, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t35 = load i1, ptr %l20, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t38, i32 0, i32 2
  %t40 = load ptr, ptr %t39
  store ptr %t40, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Promote", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = call ptr @compiler_2ffree_2ectorCall(ptr %v1, ptr %t45)
  store ptr %t47, ptr %l27
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l27, !tbaa !29
  store ptr %t48, ptr %l3, !tbaa !29
  br label %bb35
bb16:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t50 = load ptr, ptr %l28, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = load ptr, ptr %l28, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 17
  store i1 %t56, ptr %l29, !tbaa !21
  br label %bb18
bb18:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb24
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 0
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 3
  %t72 = load %"compiler/source:Span", ptr %t71
  %t73 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 5
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 6
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load ptr, ptr %l5, !tbaa !29
  %t89 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %s3, ptr %s3, i64 %t66, i64 %t68, i64 %t70, %"compiler/source:Span" %t72, i64 %t74, i64 %t76, i64 %t78, ptr %t79, ptr null)
  store %"compiler/free:store" %t89, ptr %l44
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l34, !tbaa !29
  %t91 = load %"compiler/free:store", ptr %l44
  %t92 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %s3, ptr %t90, %"compiler/free:store" %t91)
  store i1 %t92, ptr %l45
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  %t93 = load i1, ptr %l45, !tbaa !21
  store i1 %t93, ptr %rv
  br label %ret
bb24:
  %t94 = load ptr, ptr %l2, !tbaa !29
  store ptr %t94, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t95 = load ptr, ptr %l46, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb25, label %bb26
bb25:
  %t98 = load ptr, ptr %l46, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 6
  store i1 %t101, ptr %l47, !tbaa !21
  br label %bb26
bb26:
  %t102 = load i1, ptr %l47, !tbaa !21
  br i1 %t102, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572)
  unreachable
bb35:
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb36, label %bb37
bb36:
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t113 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  store i64 %t113, ptr %l56
  br label %bb39
bb39:
  %t114 = load i64, ptr %l56, !tbaa !24
  store i64 %t114, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = icmp slt i64 %t115, 0
  br i1 %t117, label %bb40, label %bb41
bb40:
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l60, !tbaa !29
  %t121 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t122 = load i64, ptr %t121, !tbaa !24
  store i64 %t122, ptr %l61, !tbaa !24
  %t123 = load ptr, ptr %l3, !tbaa !29
  store ptr %t123, ptr %l62, !tbaa !29
  %t124 = load i64, ptr %l6, !tbaa !24
  store i64 %t124, ptr %l63, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t127 = load i64, ptr %t126, !tbaa !24
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t132 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t125, i64 %t127, ptr %t128)
  store { i64, [1 x i64] } %t132, ptr %l67
  br label %bb43
bb43:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l6, !tbaa !24
  %t137 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l70
  br label %bb44
bb44:
  %t138 = load ptr, ptr %l60, !tbaa !29
  %t139 = load i64, ptr %l61, !tbaa !24
  %t140 = load ptr, ptr %l62, !tbaa !29
  %t141 = load i64, ptr %l63, !tbaa !24
  %t142 = load { i64, [1 x i64] }, ptr %l67
  %t143 = load i64, ptr %l70, !tbaa !24
  %t144 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %t138, i64 %t139, ptr %t140, i64 %t141, { i64, [1 x i64] } %t142, i64 %t143)
  store i64 %t144, ptr %l71
  br label %bb45
bb45:
  %t145 = load i64, ptr %l71, !tbaa !24
  %t146 = icmp sge i64 %t145, 0
  store i1 %t146, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 6
  %t5 = load %"compiler/source:Span", ptr %t4
  %t9 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %t3, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i1
  %l23 = alloca i1
  %l27 = alloca { i64, ptr }
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 18
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t18 = icmp ne i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 18
  %t30 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t31)
  store i1 %t34, ptr %l23
  br label %bb11
bb11:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s0, ptr %t37, i64 %t39)
  store { i64, ptr } %t42, ptr %l27
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store ptr @G_2ecompiler_2ffree_2eRemovalNames, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t45 = load ptr, ptr %l3
  store i64 9, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l3
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr [9 x { i64, ptr }], ptr %t56, i64 0, i64 %t57
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = load ptr, ptr @__olang_prog_scope
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t65, ptr %s0, { i64, ptr } %t61, { i64, ptr } %t64)
  store i1 %t68, ptr %l40
  br label %bb20
bb20:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb24
bb24:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb16
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l24 = alloca i1
  %l29 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t5, ptr %l9, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 4
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l17
  br label %bb4
bb4:
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = sext i32 %t37 to i64
  store i64 %t39, ptr %l4, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  store i64 %t44, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb6:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t56 = icmp sgt i64 %t50, %t53
  store i1 %t56, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t58 = load i1, ptr %l24, !tbaa !21
  br i1 %t58, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb10
bb9:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp sge i64 %t59, %t60
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t65 = load i1, ptr %l29, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t66, ptr %l34, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l35, !tbaa !24
  %t69 = load i64, ptr %l35, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l36, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t80, ptr %l34, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t82, ptr %l37, !tbaa !27
  %t83 = load i64, ptr %l4, !tbaa !24
  store i64 %t83, ptr %l38, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  store i64 %t84, ptr %l39, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l40, !tbaa !24
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t90 = load i64, ptr %l38, !tbaa !24
  %t91 = load i64, ptr %l39, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bdafa441ac13699b_f5af7a3548cb73f)
  unreachable
bb16:
  %t94 = load i64, ptr %l39, !tbaa !24
  %t95 = load i64, ptr %l40, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bdafa441ac13699b_f5af7a3548cb73f)
  unreachable
bb18:
  %t98 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l38, !tbaa !24
  %t101 = load i64, ptr %l39, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bdafa441ac13699b_f5af7a3548cb73f)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca %"compiler/typed:Plan"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca %"compiler/typed:Plan"
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l68 = alloca { i64, [1 x i64] }
  %l70 = alloca { i64, [1 x i64] }
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, [1 x i64] }
  %l82 = alloca { i64, [1 x i64] }
  %l84 = alloca i1
  %l86 = alloca i64
  %l94 = alloca { i64, ptr }
  %l98 = alloca i1
  %l100 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  %t15 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t15, ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t15, i64 152, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l25, i64 152, i1 false)
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l26, !tbaa !24
  %t19 = load i64, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = shl i64 1, %t20
  store i64 %t21, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Call", ptr %t23, i32 0, i32 1
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t26, 0
  store i64 %t28, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t31 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp sgt i64 %t30, %t31
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load i64, ptr %l10, !tbaa !24
  %t38 = icmp sgt i64 %t36, 0
  br i1 %t38, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t40 = load i64, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l8, !tbaa !24
  %t44 = sub i64 %t40, %t41
  %t45 = load i64, ptr %l10, !tbaa !24
  %t48 = add i64 %t44, %t45
  %t50 = sub i64 %t48, 1
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = sdiv i64 %t50, %t51
  store i64 %t54, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t56 = load i64, ptr %l37, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t58 = load i64, ptr %l12, !tbaa !24
  %t59 = load i64, ptr %l11, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = load i64, ptr %l12, !tbaa !24
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = mul i64 %t67, %t68
  %t74 = add i64 %t66, %t71
  store i64 %t74, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t78 = load i64, ptr %l13, !tbaa !24
  %t82 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t76, i64 %t77, i64 %t78)
  store i64 %t82, ptr %l58
  br label %bb18
bb18:
  %t83 = load i64, ptr %l58, !tbaa !24
  store i64 %t83, ptr %l14, !tbaa !24
  %t84 = load i64, ptr %l14, !tbaa !24
  %t86 = icmp slt i64 %t84, 0
  br i1 %t86, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  %t88 = load i64, ptr %l14, !tbaa !24
  %t90 = icmp sge i64 %t88, 63
  store i1 %t90, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t92 = load i1, ptr %l61, !tbaa !21
  br i1 %t92, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb23:
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Call", ptr %t93, i32 0, i32 3
  %t96 = load i32, ptr %t95, !tbaa !23
  %t97 = load i64, ptr %l14, !tbaa !24
  %t101 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l6, i32 %t96, i64 %t97)
  store { i64, [1 x i64] } %t101, ptr %l68
  br label %bb25
bb25:
  %t102 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t102, ptr %l70
  %t105 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l68, ptr %l70)
  store i1 %t105, ptr %l72
  br label %bb26
bb26:
  %t106 = load i1, ptr %l72, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l1, !tbaa !24
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Call", ptr %t109, i32 0, i32 1
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l77, !tbaa !27
  %t113 = load i64, ptr %l13, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 %t113
  %t118 = load ptr, ptr %t117, !tbaa !39
  %t122 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t107, i64 %t108, ptr %t118)
  store { i64, [1 x i64] } %t122, ptr %l80
  br label %bb29
bb28:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb31
bb29:
  %t123 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t123, ptr %l82
  %t126 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l80, ptr %l82)
  store i1 %t126, ptr %l84
  br label %bb30
bb30:
  %t127 = load i1, ptr %l84, !tbaa !21
  store i1 %t127, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t128 = load i1, ptr %l73, !tbaa !21
  br i1 %t128, label %bb32, label %bb33
bb32:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load i64, ptr %l14, !tbaa !24
  store i64 %t130, ptr %l86, !tbaa !24
  %t131 = load i64, ptr %l86, !tbaa !24
  %t132 = load i64, ptr %l86, !tbaa !24
  %t133 = shl i64 1, %t132
  %t136 = or i64 %t129, %t133
  store i64 %t136, ptr %l7, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb35
bb35:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l12, !tbaa !24
  br label %bb14
bb36:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/free:Free", ptr %t142, i32 0, i32 2
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t146 = load i64, ptr %l3, !tbaa !24
  %t149 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t145, i64 %t146)
  store { i64, ptr } %t149, ptr %l94
  br label %bb37
bb37:
  %t150 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t150, ptr %l15, !tbaa !27
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t153 = load i64, ptr %l7, !tbaa !24
  %t157 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t151, { i64, ptr } %t152, i64 %t153)
  store i1 %t157, ptr %l98
  br label %bb38
bb38:
  %t158 = load i1, ptr %l98, !tbaa !21
  br i1 %t158, label %bb39, label %bb40
bb39:
  %t159 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t159, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t161 = load i64, ptr %l5, !tbaa !24
  store i64 %t161, ptr %l100, !tbaa !24
  %t162 = load i64, ptr %l100, !tbaa !24
  %t163 = load i64, ptr %l100, !tbaa !24
  %t164 = shl i64 1, %t163
  store i64 %t164, ptr %l7, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t168 = load i64, ptr %l7, !tbaa !24
  %t172 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t166, { i64, ptr } %t167, i64 %t168)
  store i1 %t172, ptr %l105
  br label %bb42
bb42:
  %t173 = load i1, ptr %l105, !tbaa !21
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t174 = load i64, ptr %l7, !tbaa !24
  store i64 %t174, ptr %l106, !tbaa !24
  br label %bb45
bb44:
  store i64 -1, ptr %l106, !tbaa !24
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t176 = load i64, ptr %l106, !tbaa !24
  store i64 %t176, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l13, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i1, ptr %l16, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t13, ptr %l19, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l20, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = mul i64 %t25, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %t24, i64 %t26, i1 false)
  %t27 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t27, ptr %l19, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l23, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l26
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l27
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i32, ptr %l27, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l28
  br label %bb8
bb8:
  %t42 = load i32, ptr %l28, !tbaa !23
  store i32 %t42, ptr %l3, !tbaa !23
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l31
  br label %bb9
bb9:
  %t48 = load i32, ptr %l31
  %t50 = trunc i64 18 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb13
bb11:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load i1, ptr %l38, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l35, !tbaa !21
  br label %bb13
bb13:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb18
bb15:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l41, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l44
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i32, ptr %l44, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l45
  br label %bb17
bb17:
  %t73 = load i32, ptr %l45
  %t75 = trunc i64 1 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l51, !tbaa !24
  %t84 = load i64, ptr %l51, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l52, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l51, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l53, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l56
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l53, !tbaa !29
  %t104 = load i32, ptr %l56, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l57
  br label %bb23
bb23:
  %t106 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t106, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l6, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t111 = load i64, ptr %l5, !tbaa !24
  %t112 = load i64, ptr %l6, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t119, ptr %l64, !tbaa !27
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t127 = load ptr, ptr %l2, !tbaa !29
  store ptr %t127, ptr %l67, !tbaa !29
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t128, i32 %t125)
  store i32 %t132, ptr %l70
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l67, !tbaa !29
  %t134 = load i32, ptr %l70, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l71
  br label %bb29
bb29:
  %t136 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t136, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l10, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb32:
  br label %bb33
bb33:
  %t149 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t149, ptr %l78, !tbaa !27
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  store i32 %t155, ptr %l11, !tbaa !23
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t158 = load i32, ptr %l11, !tbaa !23
  %t161 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t161, ptr %l83
  br label %bb34
bb34:
  %t162 = load i1, ptr %l83, !tbaa !21
  br i1 %t162, label %bb35, label %bb36
bb35:
  %t163 = load ptr, ptr %l2, !tbaa !29
  store ptr %t163, ptr %l85, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l86, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t166 = load i32, ptr %l11, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l89
  br label %bb37
bb36:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb40
bb37:
  %t170 = load ptr, ptr %l86, !tbaa !29
  %t171 = load i32, ptr %l89, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t172, ptr %l90
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l85, !tbaa !29
  %t174 = load i32, ptr %l90, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t175, ptr %l91
  br label %bb39
bb39:
  %t176 = load i32, ptr %l3, !tbaa !23
  %t177 = load i32, ptr %l91, !tbaa !23
  %t179 = icmp eq i32 %t177, %t176
  store i1 %t179, ptr %l84, !tbaa !21
  br label %bb40
bb40:
  %t181 = load i1, ptr %l84, !tbaa !21
  br i1 %t181, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t182, ptr %l95, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l96, !tbaa !24
  %t185 = load i64, ptr %l96, !tbaa !24
  %t186 = mul i64 %t185, 1
  %t187 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t186)
  %t188 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l97, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l96, !tbaa !24
  %t195 = mul i64 %t194, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t191, ptr %t193, i64 %t195, i1 false)
  %t196 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t196, ptr %l95, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  %t197 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t197, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  %t198 = load i64, ptr %l9, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l9, !tbaa !24
  br label %bb30
bb45:
  call void @__olang_scope_close(ptr %s4)
  br label %bb46
bb46:
  %t202 = load i64, ptr %l5, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l5, !tbaa !24
  br label %bb24
bb47:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l102, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t206, ptr %l103, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  store i64 %t208, ptr %l104, !tbaa !24
  %t209 = load i64, ptr %l104, !tbaa !24
  %t210 = mul i64 %t209, 1
  %t211 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l105, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l104, !tbaa !24
  %t219 = mul i64 %t218, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  %t220 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t220, ptr %l103, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t221, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l18, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t32 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t29)
  store i64 %t32, ptr %l24
  br label %bb9
bb8:
  %t33 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb10
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l20, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  br label %bb44
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 3
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t53, ptr %t54)
  store i64 %t58, ptr %l35
  br label %bb17
bb17:
  %t59 = load i64, ptr %l35, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  br label %bb44
bb18:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 4
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Elem", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t75, ptr %t76, ptr %t80)
  store i64 %t84, ptr %l46
  br label %bb24
bb24:
  %t85 = load i64, ptr %l46, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb44
bb25:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t87 = load ptr, ptr %l47, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l47, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Payload", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t110 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  store i64 %t110, ptr %l57
  br label %bb31
bb31:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb44
bb32:
  %t112 = load ptr, ptr %l2, !tbaa !29
  store ptr %t112, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t113 = load ptr, ptr %l58, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load i64, ptr %t116
  %t119 = icmp eq i64 %t117, 2
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l59, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t133 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t127, ptr %t128, ptr %t129)
  store i64 %t133, ptr %l67
  br label %bb38
bb38:
  %t134 = load i64, ptr %l67, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t135 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t135, ptr %l8, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6cb79447255537d7_e828faabaec907d3)
  unreachable
bb44:
  %t137 = load i64, ptr %l8, !tbaa !24
  store i64 %t137, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/free:store"
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"compiler/typed:Plan"
  %l11 = alloca { i64, [1 x i64] }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/free:store"
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/free:orStore"
  %l25 = alloca i64
  %l26 = alloca %"compiler/typed:Plan"
  %l27 = alloca { i64, [1 x i64] }
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca %"compiler/free:orCall"
  %l34 = alloca %"compiler/typed:Plan"
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca { i64, [1 x i64] }
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l71 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l96 = alloca i1
  %l98 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l113 = alloca i64
  %l119 = alloca %"compiler/typed:Plan"
  %l120 = alloca { i64, ptr }
  %l127 = alloca { i64, [1 x i64] }
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i32
  %l158 = alloca { i64, ptr }
  %l164 = alloca i1
  %l167 = alloca i1
  %l169 = alloca i1
  %l173 = alloca i1
  %l175 = alloca ptr
  %l179 = alloca i64
  %l182 = alloca i1
  %l186 = alloca %"compiler/typed:Plan"
  %l187 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l210 = alloca i32
  %l219 = alloca { i64, ptr }
  %l225 = alloca i1
  %l229 = alloca i64
  %l235 = alloca %"compiler/typed:Plan"
  %l239 = alloca { i64, [1 x i64] }
  %l241 = alloca i1
  %l243 = alloca i1
  %l244 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %l266 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l285 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l289 = alloca i32
  %l298 = alloca { i64, ptr }
  %l304 = alloca i1
  %l309 = alloca %"compiler/typed:Plan"
  %l310 = alloca { i64, ptr }
  %l315 = alloca ptr
  %l319 = alloca i64
  %l328 = alloca { i64, [1 x i64] }
  %l330 = alloca i1
  %l335 = alloca ptr
  %l344 = alloca i64
  %l347 = alloca { i64, ptr }
  %l349 = alloca { i64, ptr }
  %l352 = alloca { i64, ptr }
  %l359 = alloca i64
  %l362 = alloca i64
  %l381 = alloca i64
  %l398 = alloca i64
  %l401 = alloca i64
  %l422 = alloca i64
  %l425 = alloca i1
  %l428 = alloca i1
  %l430 = alloca i64
  %l434 = alloca i1
  %l439 = alloca { i64, ptr }
  %l444 = alloca i64
  %l447 = alloca i1
  %l448 = alloca { i64, ptr }
  %l452 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %t130 = alloca %"compiler/typed:Plan", align 8
  %t280 = alloca %"compiler/typed:Plan", align 8
  %t392 = alloca %"compiler/typed:Plan", align 8
  %t572 = alloca %"compiler/typed:Plan", align 8
  %t749 = alloca { i64, [1 x i64] }, align 8
  %t891 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 34
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l62
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l61
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t14, ptr %l58, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l62, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_59b1cf5f5f6723c1_2bbad9bd6a5cb915)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb7:
  %t20 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb53
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l71, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/free:store", ptr %t37, i64 %t34
  %t39 = load %"compiler/free:store", ptr %t38
  store %"compiler/free:store" %t39, ptr %l6
  %t41 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 4
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t46 = icmp ne i64 %t42, %t43
  br i1 %t46, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb13:
  br label %bb14
bb14:
  %t48 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/free:Free", ptr %t51, i32 0, i32 41
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t53, i64 %t54)
  store i1 %t57, ptr %l81
  br label %bb15
bb15:
  %t58 = load i1, ptr %l81, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb23
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 62
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t61, i64 %t62)
  store i1 %t65, ptr %l86
  br label %bb18
bb18:
  %t66 = load i1, ptr %l86, !tbaa !21
  br i1 %t66, label %bb19, label %bb20
bb19:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:Free", ptr %t67, i32 0, i32 64
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t69, i64 %t70)
  store i1 %t73, ptr %l91
  br label %bb21
bb20:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb22
bb21:
  %t74 = load i1, ptr %l91, !tbaa !21
  store i1 %t74, ptr %l87, !tbaa !21
  br label %bb22
bb22:
  %t75 = load i1, ptr %l87, !tbaa !21
  store i1 %t75, ptr %l82, !tbaa !21
  br label %bb23
bb23:
  %t76 = load i1, ptr %l82, !tbaa !21
  br i1 %t76, label %bb24, label %bb25
bb24:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:Free", ptr %t77, i32 0, i32 17
  %t80 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 1
  %t81 = load i64, ptr %t80, !tbaa !24
  %t84 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t79, i64 %t81)
  store i1 %t84, ptr %l96
  br label %bb26
bb25:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb27
bb26:
  %t85 = load i1, ptr %l96, !tbaa !21
  store i1 %t85, ptr %l92, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l92, !tbaa !21
  %t87 = xor i1 %t86, true
  br i1 %t87, label %bb28, label %bb29
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l7, !tbaa !24
  %t93 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l101
  br label %bb30
bb29:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb35
bb30:
  %t94 = load i1, ptr %l101, !tbaa !21
  br i1 %t94, label %bb31, label %bb32
bb31:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/free:Free", ptr %t95, i32 0, i32 60
  %t98 = load i64, ptr %l7, !tbaa !24
  %t101 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t97, i64 %t98)
  store i1 %t101, ptr %l106
  br label %bb33
bb32:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb34
bb33:
  %t102 = load i1, ptr %l106, !tbaa !21
  store i1 %t102, ptr %l102, !tbaa !21
  br label %bb34
bb34:
  %t103 = load i1, ptr %l102, !tbaa !21
  %t104 = xor i1 %t103, true
  store i1 %t104, ptr %l98, !tbaa !21
  br label %bb35
bb35:
  %t106 = load i1, ptr %l98, !tbaa !21
  br i1 %t106, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb37:
  br label %bb38
bb38:
  %t107 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 7
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = icmp eq ptr %t108, null
  br i1 %t110, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_68d66244454596f9_ea33ff3f8eb363fd)
  unreachable
bb40:
  br label %bb41
bb41:
  %t112 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 7
  %t113 = load ptr, ptr %t112, !tbaa !29
  store ptr %t113, ptr %l8, !tbaa !29
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load ptr, ptr %l8, !tbaa !29
  %t119 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t115, ptr %t116)
  store i64 %t119, ptr %l113
  br label %bb42
bb42:
  %t120 = load i64, ptr %l113, !tbaa !24
  store i64 %t120, ptr %l9, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp slt i64 %t121, 0
  br i1 %t123, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb44:
  br label %bb45
bb45:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 3
  %t128 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 1
  %t129 = load i64, ptr %t128, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t130, ptr %v0, ptr %v0, ptr %t127, i64 %t129)
  call void @llvm.memmove.p0.p0.i64(ptr %l119, ptr %t130, i64 152, i1 false)
  br label %bb46
bb46:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l119, i64 152, i1 false)
  %t133 = getelementptr %"compiler/typed:Plan", ptr %l10, i32 0, i32 4
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l120, !tbaa !27
  %t135 = load i64, ptr %l9, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i64, ptr %t138, i64 %t135
  %t140 = load i64, ptr %t139, !tbaa !34
  %t142 = icmp ne i64 %t140, 0
  br i1 %t142, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb48:
  br label %bb49
bb49:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 1
  %t146 = load i64, ptr %t145, !tbaa !24
  %t147 = load ptr, ptr %l8, !tbaa !29
  %t151 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t144, i64 %t146, ptr %t147)
  store { i64, [1 x i64] } %t151, ptr %l127
  br label %bb50
bb50:
  %t152 = load { i64, [1 x i64] }, ptr %l127
  store { i64, [1 x i64] } %t152, ptr %l11
  %t153 = getelementptr %"compiler/typed:Plan", ptr %l10, i32 0, i32 4
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l128, !tbaa !27
  %t155 = load i64, ptr %l9, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i64, ptr %t158, i64 %t155
  store i64 1, ptr %t159, !tbaa !34
  %t160 = getelementptr %"compiler/typed:Plan", ptr %l10, i32 0, i32 5
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l130, !tbaa !27
  %t162 = load i64, ptr %l9, !tbaa !24
  %t163 = load { i64, [1 x i64] }, ptr %l11
  %t166 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr { i64, [1 x i64] }, ptr %t167, i64 %t162
  store { i64, [1 x i64] } %t163, ptr %t168
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:store", ptr %l6, i32 0, i32 1
  %t171 = load i64, ptr %t170, !tbaa !24
  %t172 = load ptr, ptr %l8, !tbaa !29
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load { i64, [1 x i64] }, ptr %l11
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t169, i64 %t171, ptr %t172, i64 %t173, { i64, [1 x i64] } %t174, i1 true, i1 false)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s3)
  br label %bb52
bb52:
  %t180 = load i64, ptr %l5, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l5, !tbaa !24
  br label %bb8
bb53:
  %t184 = load i64, ptr %l2, !tbaa !24
  %t185 = load i64, ptr %l4, !tbaa !24
  %t188 = add i64 %t184, %t185
  store i64 %t188, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb54
bb54:
  br label %bb1
bb55:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t192 = getelementptr %"compiler/free:Free", ptr %t190, i32 0, i32 34
  store ptr %t192, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t194 = load ptr, ptr %l12, !tbaa !29
  %t195 = load i64, ptr %l13, !tbaa !24
  %t198 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t194, i64 %t195)
  %t199 = extractvalue { i32, { i64, ptr } } %t198, 1
  %t200 = extractvalue { i32, { i64, ptr } } %t198, 0
  store i32 %t200, ptr %l149
  %t201 = icmp ne i32 %t200, 0
  br i1 %t201, label %bb58, label %ok.202
ok.202:
  store { i64, ptr } %t199, ptr %l148
  br label %bb57
bb57:
  %t203 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t203, ptr %l145, !tbaa !27
  br label %bb62
bb58:
  %t204 = load i32, ptr %l149, !tbaa !23
  %t205 = ashr i32 %t204, 16
  %t207 = icmp eq i32 %t205, 1
  br i1 %t207, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_24949bfdf5bb746b_61a8afba06ee945f)
  unreachable
bb61:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  br label %bb94
bb62:
  %t209 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t209, ptr %l14, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  store i64 %t212, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s11
  %t214 = load i64, ptr %l16, !tbaa !24
  %t215 = load i64, ptr %l15, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb64, label %bb65
bb64:
  call void @__olang_scope_close(ptr %s11)
  br label %bb92
bb65:
  br label %bb66
bb66:
  %t222 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t222, ptr %l158, !tbaa !27
  %t223 = load i64, ptr %l16, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr %"compiler/free:store", ptr %t226, i64 %t223
  %t228 = load %"compiler/free:store", ptr %t227
  store %"compiler/free:store" %t228, ptr %l17
  %t230 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 4
  %t231 = load i64, ptr %t230, !tbaa !24
  %t232 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t235 = icmp ne i64 %t231, %t232
  br i1 %t235, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l164, !tbaa !21
  br label %bb70
bb68:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 0
  %t239 = load i64, ptr %t238, !tbaa !24
  %t242 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t237, i64 %t239)
  store i1 %t242, ptr %l167
  br label %bb69
bb69:
  %t243 = load i1, ptr %l167, !tbaa !21
  %t244 = xor i1 %t243, true
  store i1 %t244, ptr %l164, !tbaa !21
  br label %bb70
bb70:
  %t246 = load i1, ptr %l164, !tbaa !21
  br i1 %t246, label %bb71, label %bb72
bb71:
  store i1 true, ptr %l169, !tbaa !21
  br label %bb74
bb72:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t249 = getelementptr %"compiler/free:Free", ptr %t247, i32 0, i32 60
  %t250 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 0
  %t251 = load i64, ptr %t250, !tbaa !24
  %t254 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t249, i64 %t251)
  store i1 %t254, ptr %l173
  br label %bb73
bb73:
  %t255 = load i1, ptr %l173, !tbaa !21
  %t256 = xor i1 %t255, true
  store i1 %t256, ptr %l169, !tbaa !21
  br label %bb74
bb74:
  %t258 = load i1, ptr %l169, !tbaa !21
  br i1 %t258, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s11)
  br label %bb91
bb76:
  br label %bb77
bb77:
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l175, !tbaa !29
  %t260 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 7
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = icmp eq ptr %t261, null
  br i1 %t263, label %bb78, label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_a27303051a78a613_6e77afe7cfa56447)
  unreachable
bb79:
  br label %bb80
bb80:
  %t265 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 7
  %t266 = load ptr, ptr %t265, !tbaa !29
  %t267 = load ptr, ptr %l175, !tbaa !29
  %t269 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t267, ptr %t266)
  store i64 %t269, ptr %l179
  br label %bb81
bb81:
  %t270 = load i64, ptr %l179, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  %t271 = load i64, ptr %l18, !tbaa !24
  %t273 = icmp slt i64 %t271, 0
  br i1 %t273, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb85
bb83:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/free:Free", ptr %t275, i32 0, i32 3
  %t278 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 1
  %t279 = load i64, ptr %t278, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t280, ptr %v0, ptr %v0, ptr %t277, i64 %t279)
  call void @llvm.memmove.p0.p0.i64(ptr %l186, ptr %t280, i64 152, i1 false)
  br label %bb84
bb84:
  %t283 = getelementptr %"compiler/typed:Plan", ptr %l186, i32 0, i32 4
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  store { i64, ptr } %t284, ptr %l187, !tbaa !27
  %t285 = load i64, ptr %l18, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr i64, ptr %t288, i64 %t285
  %t290 = load i64, ptr %t289, !tbaa !34
  %t292 = icmp ne i64 %t290, 1
  store i1 %t292, ptr %l182, !tbaa !21
  br label %bb85
bb85:
  %t294 = load i1, ptr %l182, !tbaa !21
  br i1 %t294, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s13
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/free:Free", ptr %t295, i32 0, i32 60
  %t298 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 0
  %t299 = load i64, ptr %t298, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t297, i64 %t299, i1 false)
  br label %bb88
bb87:
  br label %bb90
bb88:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 0
  %t304 = load i64, ptr %t303, !tbaa !24
  %t305 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t306 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 2
  %t307 = load i64, ptr %t306, !tbaa !24
  %t308 = getelementptr %"compiler/free:store", ptr %l17, i32 0, i32 3
  %t309 = load %"compiler/source:Span", ptr %t308
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s13, ptr %t302, i64 %t304, i64 %t305, i64 %t307, %"compiler/source:Span" %t309, { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s13)
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s11)
  br label %bb91
bb91:
  %t315 = load i64, ptr %l16, !tbaa !24
  %t317 = add i64 %t315, 1
  store i64 %t317, ptr %l16, !tbaa !24
  br label %bb63
bb92:
  %t319 = load i64, ptr %l13, !tbaa !24
  %t320 = load i64, ptr %l15, !tbaa !24
  %t323 = add i64 %t319, %t320
  store i64 %t323, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb93
bb93:
  br label %bb56
bb94:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/free:Free", ptr %t325, i32 0, i32 40
  store ptr %t327, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  br label %bb95
bb95:
  store %olang.scope zeroinitializer, ptr %s16
  %t329 = load ptr, ptr %l19, !tbaa !29
  %t330 = load i64, ptr %l20, !tbaa !24
  %t333 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2eRunF_Hfb62abbaadc4bc18a4ac1ddebfb1ceda(ptr %v0, ptr %t329, i64 %t330)
  %t334 = extractvalue { i32, { i64, ptr } } %t333, 1
  %t335 = extractvalue { i32, { i64, ptr } } %t333, 0
  store i32 %t335, ptr %l210
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb97, label %ok.337
ok.337:
  store { i64, ptr } %t334, ptr %l209
  br label %bb96
bb96:
  %t338 = load { i64, ptr }, ptr %l209, !tbaa !27
  store { i64, ptr } %t338, ptr %l206, !tbaa !27
  br label %bb101
bb97:
  %t339 = load i32, ptr %l210, !tbaa !23
  %t340 = ashr i32 %t339, 16
  %t342 = icmp eq i32 %t340, 1
  br i1 %t342, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_963836c0f8071dfd_af84cd38f37029b9)
  unreachable
bb100:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s16)
  br label %bb136
bb101:
  %t344 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t344, ptr %l21, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  store i64 %t347, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb102
bb102:
  store %olang.scope zeroinitializer, ptr %s17
  %t349 = load i64, ptr %l23, !tbaa !24
  %t350 = load i64, ptr %l22, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s17)
  br label %bb134
bb104:
  br label %bb105
bb105:
  %t357 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t357, ptr %l219, !tbaa !27
  %t358 = load i64, ptr %l23, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr %"compiler/free:orStore", ptr %t361, i64 %t358
  %t363 = load %"compiler/free:orStore", ptr %t362
  store %"compiler/free:orStore" %t363, ptr %l24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/free:Free", ptr %t365, i32 0, i32 41
  %t368 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 1
  %t369 = load i64, ptr %t368, !tbaa !24
  %t372 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t367, i64 %t369)
  store i1 %t372, ptr %l225
  br label %bb106
bb106:
  %t373 = load i1, ptr %l225, !tbaa !21
  %t374 = xor i1 %t373, true
  br i1 %t374, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s17)
  br label %bb133
bb108:
  br label %bb109
bb109:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 2
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t381 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t376, ptr %t378)
  store i64 %t381, ptr %l229
  br label %bb110
bb110:
  %t382 = load i64, ptr %l229, !tbaa !24
  store i64 %t382, ptr %l25, !tbaa !24
  %t383 = load i64, ptr %l25, !tbaa !24
  %t385 = icmp slt i64 %t383, 0
  br i1 %t385, label %bb111, label %bb112
bb111:
  call void @__olang_scope_close(ptr %s17)
  br label %bb133
bb112:
  br label %bb113
bb113:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/free:Free", ptr %t387, i32 0, i32 3
  %t390 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 0
  %t391 = load i64, ptr %t390, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t392, ptr %v0, ptr %v0, ptr %t389, i64 %t391)
  call void @llvm.memmove.p0.p0.i64(ptr %l235, ptr %t392, i64 152, i1 false)
  br label %bb114
bb114:
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %l235, i64 152, i1 false)
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 0
  %t397 = load i64, ptr %t396, !tbaa !24
  %t398 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 2
  %t399 = load ptr, ptr %t398, !tbaa !29
  %t403 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t395, i64 %t397, ptr %t399)
  store { i64, [1 x i64] } %t403, ptr %l239
  br label %bb115
bb115:
  %t404 = load { i64, [1 x i64] }, ptr %l239
  store { i64, [1 x i64] } %t404, ptr %l27
  %t405 = load { i64, [1 x i64] }, ptr %l27
  %t407 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t405)
  store i1 %t407, ptr %l241
  br label %bb116
bb116:
  %t408 = load i1, ptr %l241, !tbaa !21
  %t409 = xor i1 %t408, true
  br i1 %t409, label %bb117, label %bb118
bb117:
  %t411 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 4
  %t412 = load { i64, ptr }, ptr %t411, !tbaa !27
  store { i64, ptr } %t412, ptr %l244, !tbaa !27
  %t413 = load i64, ptr %l25, !tbaa !24
  %t415 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr i64, ptr %t416, i64 %t413
  %t418 = load i64, ptr %t417, !tbaa !34
  %t420 = icmp eq i64 %t418, 0
  store i1 %t420, ptr %l243, !tbaa !21
  br label %bb119
bb118:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb119
bb119:
  %t422 = load i1, ptr %l243, !tbaa !21
  br i1 %t422, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s17)
  br label %bb133
bb121:
  br label %bb122
bb122:
  %t423 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 4
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !27
  store { i64, ptr } %t424, ptr %l248, !tbaa !27
  %t425 = load i64, ptr %l25, !tbaa !24
  %t427 = getelementptr { i64, ptr }, ptr %l248, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr i64, ptr %t428, i64 %t425
  %t430 = load i64, ptr %t429, !tbaa !34
  %t432 = icmp eq i64 %t430, 1
  br i1 %t432, label %bb123, label %bb124
bb123:
  %t434 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 6
  %t435 = load { i64, ptr }, ptr %t434, !tbaa !27
  store { i64, ptr } %t435, ptr %l252, !tbaa !27
  %t436 = load i64, ptr %l25, !tbaa !24
  %t438 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !27
  %t440 = getelementptr ptr, ptr %t439, i64 %t436
  %t441 = load ptr, ptr %t440, !tbaa !39
  %t443 = icmp eq ptr %t441, null
  br i1 %t443, label %bb125, label %bb126
bb124:
  br label %bb128
bb125:
  %t445 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 6
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !27
  store { i64, ptr } %t446, ptr %l256, !tbaa !27
  %t447 = load i64, ptr %l25, !tbaa !24
  %t448 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 3
  %t449 = load ptr, ptr %t448, !tbaa !29
  %t453 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = getelementptr ptr, ptr %t454, i64 %t447
  store ptr %t449, ptr %t455, !tbaa !39
  br label %bb127
bb126:
  br label %bb127
bb127:
  call void @__olang_scope_close(ptr %s17)
  br label %bb133
bb128:
  %t456 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 4
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !27
  store { i64, ptr } %t457, ptr %l260, !tbaa !27
  %t458 = load i64, ptr %l25, !tbaa !24
  %t460 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !27
  %t462 = getelementptr i64, ptr %t461, i64 %t458
  %t463 = load i64, ptr %t462, !tbaa !34
  %t465 = icmp ne i64 %t463, 0
  br i1 %t465, label %bb129, label %bb130
bb129:
  call void @__olang_scope_close(ptr %s17)
  br label %bb133
bb130:
  br label %bb131
bb131:
  %t467 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 4
  %t468 = load { i64, ptr }, ptr %t467, !tbaa !27
  store { i64, ptr } %t468, ptr %l264, !tbaa !27
  %t469 = load i64, ptr %l25, !tbaa !24
  %t471 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr i64, ptr %t472, i64 %t469
  store i64 2, ptr %t473, !tbaa !34
  %t474 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 5
  %t475 = load { i64, ptr }, ptr %t474, !tbaa !27
  store { i64, ptr } %t475, ptr %l266, !tbaa !27
  %t476 = load i64, ptr %l25, !tbaa !24
  %t477 = load { i64, [1 x i64] }, ptr %l27
  %t480 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !27
  %t482 = getelementptr { i64, [1 x i64] }, ptr %t481, i64 %t476
  store { i64, [1 x i64] } %t477, ptr %t482
  %t483 = getelementptr %"compiler/typed:Plan", ptr %l26, i32 0, i32 6
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l269, !tbaa !27
  %t485 = load i64, ptr %l25, !tbaa !24
  %t486 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 3
  %t487 = load ptr, ptr %t486, !tbaa !29
  %t491 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = getelementptr ptr, ptr %t492, i64 %t485
  store ptr %t487, ptr %t493, !tbaa !39
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 0
  %t496 = load i64, ptr %t495, !tbaa !24
  %t497 = getelementptr %"compiler/free:orStore", ptr %l24, i32 0, i32 2
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t499 = load i64, ptr %l25, !tbaa !24
  %t500 = load { i64, [1 x i64] }, ptr %l27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t494, i64 %t496, ptr %t498, i64 %t499, { i64, [1 x i64] } %t500, i1 true, i1 false)
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s17)
  br label %bb133
bb133:
  %t506 = load i64, ptr %l23, !tbaa !24
  %t508 = add i64 %t506, 1
  store i64 %t508, ptr %l23, !tbaa !24
  br label %bb102
bb134:
  %t510 = load i64, ptr %l20, !tbaa !24
  %t511 = load i64, ptr %l22, !tbaa !24
  %t514 = add i64 %t510, %t511
  store i64 %t514, ptr %l20, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb135
bb135:
  br label %bb95
bb136:
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/free:Free", ptr %t516, i32 0, i32 39
  store ptr %t518, ptr %l28, !tbaa !29
  store i64 0, ptr %l29, !tbaa !24
  br label %bb137
bb137:
  store %olang.scope zeroinitializer, ptr %s26
  %t520 = load ptr, ptr %l28, !tbaa !29
  %t521 = load i64, ptr %l29, !tbaa !24
  %t524 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2eRunFrom_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t520, i64 %t521)
  %t525 = extractvalue { i32, { i64, ptr } } %t524, 1
  %t526 = extractvalue { i32, { i64, ptr } } %t524, 0
  store i32 %t526, ptr %l289
  %t527 = icmp ne i32 %t526, 0
  br i1 %t527, label %bb139, label %ok.528
ok.528:
  store { i64, ptr } %t525, ptr %l288
  br label %bb138
bb138:
  %t529 = load { i64, ptr }, ptr %l288, !tbaa !27
  store { i64, ptr } %t529, ptr %l285, !tbaa !27
  br label %bb143
bb139:
  %t530 = load i32, ptr %l289, !tbaa !23
  %t531 = ashr i32 %t530, 16
  %t533 = icmp eq i32 %t531, 1
  br i1 %t533, label %bb140, label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_e84a97658b0243cc_8016afdefcf039e8)
  unreachable
bb142:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s26)
  br label %bb226
bb143:
  %t535 = load { i64, ptr }, ptr %l285, !tbaa !27
  store { i64, ptr } %t535, ptr %l30, !tbaa !27
  %t536 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t538 = extractvalue { i64, ptr } %t536, 0
  store i64 %t538, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb144
bb144:
  store %olang.scope zeroinitializer, ptr %s27
  %t540 = load i64, ptr %l32, !tbaa !24
  %t541 = load i64, ptr %l31, !tbaa !24
  %t544 = icmp slt i64 %t540, %t541
  %t546 = xor i1 %t544, true
  br i1 %t546, label %bb145, label %bb146
bb145:
  call void @__olang_scope_close(ptr %s27)
  br label %bb224
bb146:
  br label %bb147
bb147:
  %t548 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t548, ptr %l298, !tbaa !27
  %t549 = load i64, ptr %l32, !tbaa !24
  %t551 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr %"compiler/free:orCall", ptr %t552, i64 %t549
  %t554 = load %"compiler/free:orCall", ptr %t553
  store %"compiler/free:orCall" %t554, ptr %l33
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/free:Free", ptr %t556, i32 0, i32 41
  %t559 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 4
  %t560 = load i64, ptr %t559, !tbaa !24
  %t563 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t558, i64 %t560)
  store i1 %t563, ptr %l304
  br label %bb148
bb148:
  %t564 = load i1, ptr %l304, !tbaa !21
  %t565 = xor i1 %t564, true
  br i1 %t565, label %bb149, label %bb150
bb149:
  call void @__olang_scope_close(ptr %s27)
  br label %bb223
bb150:
  br label %bb151
bb151:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t569 = getelementptr %"compiler/free:Free", ptr %t567, i32 0, i32 3
  %t570 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 0
  %t571 = load i64, ptr %t570, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t572, ptr %v0, ptr %v0, ptr %t569, i64 %t571)
  call void @llvm.memmove.p0.p0.i64(ptr %l309, ptr %t572, i64 152, i1 false)
  br label %bb152
bb152:
  call void @llvm.memmove.p0.p0.i64(ptr %l34, ptr %l309, i64 152, i1 false)
  %t575 = getelementptr %"compiler/typed:Plan", ptr %l34, i32 0, i32 4
  %t576 = load { i64, ptr }, ptr %t575, !tbaa !27
  store { i64, ptr } %t576, ptr %l310, !tbaa !27
  %t577 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 1
  %t578 = load i64, ptr %t577, !tbaa !24
  %t580 = getelementptr { i64, ptr }, ptr %l310, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr i64, ptr %t581, i64 %t578
  %t583 = load i64, ptr %t582, !tbaa !34
  %t585 = icmp ne i64 %t583, 0
  br i1 %t585, label %bb153, label %bb154
bb153:
  call void @__olang_scope_close(ptr %s27)
  br label %bb223
bb154:
  br label %bb155
bb155:
  %t587 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 6
  %t588 = load ptr, ptr %t587, !tbaa !29
  %t590 = call ptr @compiler_2ffree_2ecallOf(ptr %v0, ptr %t588)
  store ptr %t590, ptr %l315
  br label %bb156
bb156:
  %t591 = load ptr, ptr %l315, !tbaa !29
  store ptr %t591, ptr %l35, !tbaa !29
  %t592 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 2
  %t594 = load i64, ptr %t593, !tbaa !24
  %t595 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 3
  %t596 = load i64, ptr %t595, !tbaa !24
  %t600 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t592, i64 %t594, i64 %t596)
  store i64 %t600, ptr %l319
  br label %bb157
bb157:
  %t601 = load i64, ptr %l319, !tbaa !24
  store i64 %t601, ptr %l36, !tbaa !24
  %t602 = load i64, ptr %l36, !tbaa !24
  %t604 = icmp slt i64 %t602, 0
  br i1 %t604, label %bb158, label %bb159
bb158:
  call void @__olang_scope_close(ptr %s27)
  br label %bb223
bb159:
  br label %bb160
bb160:
  %t606 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 1
  %t607 = load i64, ptr %t606, !tbaa !24
  %t609 = trunc i64 %t607 to i32
  store i32 %t609, ptr %l37, !tbaa !23
  %t612 = load i32, ptr %l37, !tbaa !23
  %t613 = load i64, ptr %l36, !tbaa !24
  %t617 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %l34, i32 %t612, i64 %t613)
  store { i64, [1 x i64] } %t617, ptr %l328
  br label %bb161
bb161:
  %t618 = load { i64, [1 x i64] }, ptr %l328
  store { i64, [1 x i64] } %t618, ptr %l38
  %t619 = load { i64, [1 x i64] }, ptr %l38
  %t621 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t619)
  store i1 %t621, ptr %l330
  br label %bb162
bb162:
  %t622 = load i1, ptr %l330, !tbaa !21
  %t623 = xor i1 %t622, true
  br i1 %t623, label %bb163, label %bb164
bb163:
  call void @__olang_scope_close(ptr %s27)
  br label %bb223
bb164:
  br label %bb165
bb165:
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 0
  %t627 = load i64, ptr %t626, !tbaa !24
  %t628 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 1
  %t629 = load i64, ptr %t628, !tbaa !24
  %t633 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %t625, i64 %t627, i64 %t629)
  store ptr %t633, ptr %l335
  br label %bb166
bb166:
  %t634 = load ptr, ptr %l335, !tbaa !29
  store ptr %t634, ptr %l39, !tbaa !29
  %t635 = load ptr, ptr %l39, !tbaa !29
  %t637 = icmp eq ptr %t635, null
  br i1 %t637, label %bb167, label %bb168
bb167:
  call void @__olang_scope_close(ptr %s27)
  br label %bb223
bb168:
  br label %bb169
bb169:
  %t639 = load ptr, ptr %l0, !tbaa !29
  %t640 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 0
  %t641 = load i64, ptr %t640, !tbaa !24
  %t642 = load ptr, ptr %l39, !tbaa !29
  %t643 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 2
  %t644 = load i64, ptr %t643, !tbaa !24
  %t645 = load { i64, [1 x i64] }, ptr %l38
  %t646 = load i64, ptr %l36, !tbaa !24
  %t653 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t639, i64 %t641, ptr %t642, i64 %t644, { i64, [1 x i64] } %t645, i64 %t646)
  store i64 %t653, ptr %l344
  br label %bb170
bb170:
  %t654 = load i64, ptr %l344, !tbaa !24
  store i64 %t654, ptr %l40, !tbaa !24
  %t655 = load i64, ptr %l40, !tbaa !24
  %t657 = icmp slt i64 %t655, 0
  br i1 %t657, label %bb171, label %bb172
bb171:
  call void @__olang_scope_close(ptr %s27)
  br label %bb223
bb172:
  br label %bb173
bb173:
  %t659 = getelementptr %"compiler/typed:Plan", ptr %l34, i32 0, i32 4
  %t660 = load { i64, ptr }, ptr %t659, !tbaa !27
  store { i64, ptr } %t660, ptr %l347, !tbaa !27
  %t661 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 1
  %t662 = load i64, ptr %t661, !tbaa !24
  %t664 = getelementptr { i64, ptr }, ptr %l347, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !27
  %t666 = getelementptr i64, ptr %t665, i64 %t662
  store i64 2, ptr %t666, !tbaa !34
  %t667 = getelementptr %"compiler/typed:Plan", ptr %l34, i32 0, i32 5
  %t668 = load { i64, ptr }, ptr %t667, !tbaa !27
  store { i64, ptr } %t668, ptr %l349, !tbaa !27
  %t669 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 1
  %t670 = load i64, ptr %t669, !tbaa !24
  %t671 = load { i64, [1 x i64] }, ptr %l38
  %t674 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t675 = load ptr, ptr %t674, !tbaa !27
  %t676 = getelementptr { i64, [1 x i64] }, ptr %t675, i64 %t670
  store { i64, [1 x i64] } %t671, ptr %t676
  %t677 = getelementptr %"compiler/typed:Plan", ptr %l34, i32 0, i32 6
  %t678 = load { i64, ptr }, ptr %t677, !tbaa !27
  store { i64, ptr } %t678, ptr %l352, !tbaa !27
  %t679 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 1
  %t680 = load i64, ptr %t679, !tbaa !24
  %t681 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 5
  %t682 = load ptr, ptr %t681, !tbaa !29
  %t686 = getelementptr { i64, ptr }, ptr %l352, i32 0, i32 1
  %t687 = load ptr, ptr %t686, !tbaa !27
  %t688 = getelementptr ptr, ptr %t687, i64 %t680
  store ptr %t682, ptr %t688, !tbaa !39
  store i64 0, ptr %l41, !tbaa !24
  store i64 63, ptr %l42, !tbaa !24
  store i64 1, ptr %l43, !tbaa !24
  %t689 = load i64, ptr %l42, !tbaa !24
  %t690 = load i64, ptr %l41, !tbaa !24
  %t693 = icmp sgt i64 %t689, %t690
  br i1 %t693, label %bb174, label %bb175
bb174:
  %t695 = load i64, ptr %l43, !tbaa !24
  %t697 = icmp sgt i64 %t695, 0
  br i1 %t697, label %bb176, label %bb177
bb175:
  store i64 0, ptr %l359, !tbaa !24
  br label %bb179
bb176:
  %t699 = load i64, ptr %l42, !tbaa !24
  %t700 = load i64, ptr %l41, !tbaa !24
  %t703 = sub i64 %t699, %t700
  %t704 = load i64, ptr %l43, !tbaa !24
  %t707 = add i64 %t703, %t704
  %t709 = sub i64 %t707, 1
  %t710 = load i64, ptr %l43, !tbaa !24
  %t713 = sdiv i64 %t709, %t710
  store i64 %t713, ptr %l362, !tbaa !24
  br label %bb178
bb177:
  store i64 0, ptr %l362, !tbaa !24
  br label %bb178
bb178:
  %t715 = load i64, ptr %l362, !tbaa !24
  store i64 %t715, ptr %l359, !tbaa !24
  br label %bb179
bb179:
  %t716 = load i64, ptr %l359, !tbaa !24
  store i64 %t716, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s35
  %t717 = load i64, ptr %l45, !tbaa !24
  %t718 = load i64, ptr %l44, !tbaa !24
  %t721 = icmp slt i64 %t717, %t718
  %t723 = xor i1 %t721, true
  br i1 %t723, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s35)
  br label %bb189
bb182:
  br label %bb183
bb183:
  %t725 = load i64, ptr %l41, !tbaa !24
  %t726 = load i64, ptr %l45, !tbaa !24
  %t727 = load i64, ptr %l43, !tbaa !24
  %t730 = mul i64 %t726, %t727
  %t733 = add i64 %t725, %t730
  store i64 %t733, ptr %l46, !tbaa !24
  %t735 = load i64, ptr %l40, !tbaa !24
  %t736 = load i64, ptr %l46, !tbaa !24
  store i64 %t736, ptr %l381, !tbaa !24
  %t737 = load i64, ptr %l381, !tbaa !24
  %t738 = load i64, ptr %l381, !tbaa !24
  %t739 = shl i64 1, %t738
  %t742 = and i64 %t735, %t739
  %t744 = icmp ne i64 %t742, 0
  br i1 %t744, label %bb184, label %bb185
bb184:
  %t746 = load i32, ptr %l37, !tbaa !23
  %t747 = load i64, ptr %l46, !tbaa !24
  %t748 = load i32, ptr %l37, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t749
  %t750 = getelementptr { i64, [1 x i64] }, ptr %t749, i32 0, i32 0
  store i64 4, ptr %t750
  %t752 = insertvalue { i32 } undef, i32 %t748, 0
  %t753 = getelementptr { i64, [1 x i64] }, ptr %t749, i32 0, i32 1
  store { i32 } %t752, ptr %t753
  %t754 = load { i64, [1 x i64] }, ptr %t749
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %l34, i32 %t746, i64 %t747, { i64, [1 x i64] } %t754)
  br label %bb186
bb185:
  br label %bb187
bb186:
  br label %bb187
bb187:
  call void @__olang_scope_close(ptr %s35)
  br label %bb188
bb188:
  %t759 = load i64, ptr %l45, !tbaa !24
  %t761 = add i64 %t759, 1
  store i64 %t761, ptr %l45, !tbaa !24
  br label %bb180
bb189:
  store i64 0, ptr %l47, !tbaa !24
  %t763 = load ptr, ptr %l39, !tbaa !29
  %t765 = getelementptr %"compiler/typed:Call", ptr %t763, i32 0, i32 1
  %t766 = load { i64, ptr }, ptr %t765, !tbaa !27
  %t768 = extractvalue { i64, ptr } %t766, 0
  store i64 %t768, ptr %l48, !tbaa !24
  store i64 1, ptr %l49, !tbaa !24
  %t770 = load i64, ptr %l48, !tbaa !24
  %t771 = load i64, ptr %l47, !tbaa !24
  %t774 = icmp sgt i64 %t770, %t771
  br i1 %t774, label %bb190, label %bb191
bb190:
  %t776 = load i64, ptr %l49, !tbaa !24
  %t778 = icmp sgt i64 %t776, 0
  br i1 %t778, label %bb192, label %bb193
bb191:
  store i64 0, ptr %l398, !tbaa !24
  br label %bb195
bb192:
  %t780 = load i64, ptr %l48, !tbaa !24
  %t781 = load i64, ptr %l47, !tbaa !24
  %t784 = sub i64 %t780, %t781
  %t785 = load i64, ptr %l49, !tbaa !24
  %t788 = add i64 %t784, %t785
  %t790 = sub i64 %t788, 1
  %t791 = load i64, ptr %l49, !tbaa !24
  %t794 = sdiv i64 %t790, %t791
  store i64 %t794, ptr %l401, !tbaa !24
  br label %bb194
bb193:
  store i64 0, ptr %l401, !tbaa !24
  br label %bb194
bb194:
  %t796 = load i64, ptr %l401, !tbaa !24
  store i64 %t796, ptr %l398, !tbaa !24
  br label %bb195
bb195:
  %t797 = load i64, ptr %l398, !tbaa !24
  store i64 %t797, ptr %l50, !tbaa !24
  store i64 0, ptr %l51, !tbaa !24
  br label %bb196
bb196:
  store %olang.scope zeroinitializer, ptr %s39
  %t798 = load i64, ptr %l51, !tbaa !24
  %t799 = load i64, ptr %l50, !tbaa !24
  %t802 = icmp slt i64 %t798, %t799
  %t804 = xor i1 %t802, true
  br i1 %t804, label %bb197, label %bb198
bb197:
  call void @__olang_scope_close(ptr %s39)
  br label %bb222
bb198:
  br label %bb199
bb199:
  %t806 = load i64, ptr %l47, !tbaa !24
  %t807 = load i64, ptr %l51, !tbaa !24
  %t808 = load i64, ptr %l49, !tbaa !24
  %t811 = mul i64 %t807, %t808
  %t814 = add i64 %t806, %t811
  store i64 %t814, ptr %l52, !tbaa !24
  %t816 = load ptr, ptr %l0, !tbaa !29
  %t817 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 2
  %t818 = load i64, ptr %t817, !tbaa !24
  %t819 = load i64, ptr %l52, !tbaa !24
  %t823 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t816, i64 %t818, i64 %t819)
  store i64 %t823, ptr %l422
  br label %bb200
bb200:
  %t824 = load i64, ptr %l422, !tbaa !24
  store i64 %t824, ptr %l53, !tbaa !24
  %t825 = load i64, ptr %l53, !tbaa !24
  %t827 = icmp slt i64 %t825, 0
  br i1 %t827, label %bb201, label %bb202
bb201:
  store i1 true, ptr %l425, !tbaa !21
  br label %bb203
bb202:
  %t829 = load i64, ptr %l53, !tbaa !24
  %t831 = icmp sge i64 %t829, 63
  store i1 %t831, ptr %l425, !tbaa !21
  br label %bb203
bb203:
  %t833 = load i1, ptr %l425, !tbaa !21
  br i1 %t833, label %bb204, label %bb205
bb204:
  store i1 true, ptr %l428, !tbaa !21
  br label %bb206
bb205:
  %t834 = load i64, ptr %l40, !tbaa !24
  %t835 = load i64, ptr %l53, !tbaa !24
  store i64 %t835, ptr %l430, !tbaa !24
  %t836 = load i64, ptr %l430, !tbaa !24
  %t837 = load i64, ptr %l430, !tbaa !24
  %t838 = shl i64 1, %t837
  %t841 = and i64 %t834, %t838
  %t843 = icmp eq i64 %t841, 0
  store i1 %t843, ptr %l428, !tbaa !21
  br label %bb206
bb206:
  %t845 = load i1, ptr %l428, !tbaa !21
  br i1 %t845, label %bb207, label %bb208
bb207:
  store i1 true, ptr %l434, !tbaa !21
  br label %bb209
bb208:
  %t846 = load i64, ptr %l52, !tbaa !24
  %t847 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 3
  %t848 = load i64, ptr %t847, !tbaa !24
  %t851 = icmp eq i64 %t846, %t848
  store i1 %t851, ptr %l434, !tbaa !21
  br label %bb209
bb209:
  %t853 = load i1, ptr %l434, !tbaa !21
  br i1 %t853, label %bb210, label %bb211
bb210:
  call void @__olang_scope_close(ptr %s39)
  br label %bb221
bb211:
  br label %bb212
bb212:
  %t854 = load ptr, ptr %l39, !tbaa !29
  %t856 = getelementptr %"compiler/typed:Call", ptr %t854, i32 0, i32 1
  %t857 = load { i64, ptr }, ptr %t856, !tbaa !27
  store { i64, ptr } %t857, ptr %l439, !tbaa !27
  %t858 = load i64, ptr %l52, !tbaa !24
  %t860 = getelementptr { i64, ptr }, ptr %l439, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !27
  %t862 = getelementptr ptr, ptr %t861, i64 %t858
  %t863 = load ptr, ptr %t862, !tbaa !39
  store ptr %t863, ptr %l54, !tbaa !29
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t866 = load ptr, ptr %l54, !tbaa !29
  %t869 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t865, ptr %t866)
  store i64 %t869, ptr %l444
  br label %bb213
bb213:
  %t870 = load i64, ptr %l444, !tbaa !24
  store i64 %t870, ptr %l55, !tbaa !24
  %t871 = load i64, ptr %l55, !tbaa !24
  %t873 = icmp sge i64 %t871, 0
  br i1 %t873, label %bb214, label %bb215
bb214:
  %t875 = getelementptr %"compiler/typed:Plan", ptr %l34, i32 0, i32 4
  %t876 = load { i64, ptr }, ptr %t875, !tbaa !27
  store { i64, ptr } %t876, ptr %l448, !tbaa !27
  %t877 = load i64, ptr %l55, !tbaa !24
  %t879 = getelementptr { i64, ptr }, ptr %l448, i32 0, i32 1
  %t880 = load ptr, ptr %t879, !tbaa !27
  %t881 = getelementptr i64, ptr %t880, i64 %t877
  %t882 = load i64, ptr %t881, !tbaa !34
  %t884 = icmp eq i64 %t882, 1
  store i1 %t884, ptr %l447, !tbaa !21
  br label %bb216
bb215:
  store i1 false, ptr %l447, !tbaa !21
  br label %bb216
bb216:
  %t886 = load i1, ptr %l447, !tbaa !21
  br i1 %t886, label %bb217, label %bb218
bb217:
  %t887 = getelementptr %"compiler/typed:Plan", ptr %l34, i32 0, i32 5
  %t888 = load { i64, ptr }, ptr %t887, !tbaa !27
  store { i64, ptr } %t888, ptr %l452, !tbaa !27
  %t889 = load i64, ptr %l55, !tbaa !24
  %t890 = load i32, ptr %l37, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t891
  %t892 = getelementptr { i64, [1 x i64] }, ptr %t891, i32 0, i32 0
  store i64 4, ptr %t892
  %t894 = insertvalue { i32 } undef, i32 %t890, 0
  %t895 = getelementptr { i64, [1 x i64] }, ptr %t891, i32 0, i32 1
  store { i32 } %t894, ptr %t895
  %t896 = load { i64, [1 x i64] }, ptr %t891
  %t899 = getelementptr { i64, ptr }, ptr %l452, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !27
  %t901 = getelementptr { i64, [1 x i64] }, ptr %t900, i64 %t889
  store { i64, [1 x i64] } %t896, ptr %t901
  br label %bb220
bb218:
  %t902 = load ptr, ptr %l0, !tbaa !29
  %t903 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 0
  %t904 = load i64, ptr %t903, !tbaa !24
  %t905 = load ptr, ptr %l54, !tbaa !29
  %t906 = getelementptr %"compiler/free:orCall", ptr %l33, i32 0, i32 1
  %t907 = load i64, ptr %t906, !tbaa !24
  %t908 = load { i64, [1 x i64] }, ptr %l38
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t902, i64 %t904, ptr %t905, i64 %t907, { i64, [1 x i64] } %t908, i1 false, i1 false)
  br label %bb219
bb219:
  br label %bb220
bb220:
  call void @__olang_scope_close(ptr %s39)
  br label %bb221
bb221:
  %t914 = load i64, ptr %l51, !tbaa !24
  %t916 = add i64 %t914, 1
  store i64 %t916, ptr %l51, !tbaa !24
  br label %bb196
bb222:
  call void @__olang_scope_close(ptr %s27)
  br label %bb223
bb223:
  %t918 = load i64, ptr %l32, !tbaa !24
  %t920 = add i64 %t918, 1
  store i64 %t920, ptr %l32, !tbaa !24
  br label %bb144
bb224:
  %t922 = load i64, ptr %l29, !tbaa !24
  %t923 = load i64, ptr %l31, !tbaa !24
  %t926 = add i64 %t922, %t923
  store i64 %t926, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s26)
  br label %bb225
bb225:
  br label %bb137
bb226:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t24)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i64
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t7 = load ptr, ptr %l13, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t15, ptr %l12, !tbaa !24
  br label %bb61
bb6:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t18 = load ptr, ptr %l18, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l18, !tbaa !29
  %t22 = load i64, ptr %t21
  %t24 = icmp eq i64 %t22, 2
  store i1 %t24, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t36 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eplaceMust(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i64 %t36, ptr %l26
  br label %bb12
bb12:
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l12, !tbaa !24
  br label %bb61
bb13:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l27, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l28, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t57 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store i64 %t57, ptr %l35
  br label %bb19
bb19:
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t61 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  store i64 %t61, ptr %l38, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i64 %t66, ptr %l41
  br label %bb22
bb21:
  %t67 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t67, ptr %l37, !tbaa !24
  br label %bb23
bb22:
  %t69 = load i64, ptr %l38, !tbaa !24
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = add i64 %t69, %t70
  store i64 %t71, ptr %l37, !tbaa !24
  br label %bb23
bb23:
  %t73 = load i64, ptr %l37, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb61
bb24:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = load i64, ptr %t78
  %t81 = icmp eq i64 %t79, 6
  store i1 %t81, ptr %l45, !tbaa !21
  br label %bb26
bb26:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb27, label %bb28
bb27:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t93 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  store i64 %t93, ptr %l52
  br label %bb30
bb30:
  %t94 = load i64, ptr %l52, !tbaa !24
  store i64 %t94, ptr %l12, !tbaa !24
  br label %bb61
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t96 = load ptr, ptr %l53, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %l53, !tbaa !29
  %t100 = load i64, ptr %t99
  %t102 = icmp eq i64 %t100, 14
  store i1 %t102, ptr %l54, !tbaa !21
  br label %bb33
bb33:
  %t103 = load i1, ptr %l54, !tbaa !21
  br i1 %t103, label %bb34, label %bb35
bb34:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t114 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2etryMust(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store i64 %t114, ptr %l61
  br label %bb37
bb37:
  %t115 = load i64, ptr %l61, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  br label %bb61
bb38:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t120 = load ptr, ptr %l62, !tbaa !29
  %t121 = load i64, ptr %t120
  %t123 = icmp eq i64 %t121, 17
  store i1 %t123, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t124 = load i1, ptr %l63, !tbaa !21
  br i1 %t124, label %bb41, label %bb42
bb41:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t135 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t131, ptr %t132)
  store i64 %t135, ptr %l70
  br label %bb44
bb44:
  %t136 = load i64, ptr %l70, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  br label %bb61
bb45:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb46, label %bb47
bb46:
  %t141 = load ptr, ptr %l71, !tbaa !29
  %t142 = load i64, ptr %t141
  %t144 = icmp eq i64 %t142, 9
  store i1 %t144, ptr %l72, !tbaa !21
  br label %bb47
bb47:
  %t145 = load i1, ptr %l72, !tbaa !21
  br i1 %t145, label %bb48, label %bb49
bb48:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t148, i32 0, i32 2
  %t150 = load i32, ptr %t149
  store i32 %t150, ptr %l8
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t154, i32 0, i32 4
  %t156 = load { i64, ptr }, ptr %t155
  store { i64, ptr } %t156, ptr %l9, !tbaa !27
  br label %bb50
bb49:
  br label %bb56
bb50:
  %t158 = load i32, ptr %l8
  %t159 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t162 = call i1 @compiler_2ffree_2eisConversion(ptr %v1, i32 %t158, { i64, ptr } %t159)
  store i1 %t162, ptr %l81
  br label %bb51
bb51:
  %t163 = load i1, ptr %l81, !tbaa !21
  br i1 %t163, label %bb52, label %bb53
bb52:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %l84, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 0
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t172 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t164, ptr %t169)
  store i64 %t172, ptr %l86
  br label %bb54
bb53:
  %t173 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t173, ptr %l82, !tbaa !24
  br label %bb55
bb54:
  %t175 = load i64, ptr %l86, !tbaa !24
  store i64 %t175, ptr %l82, !tbaa !24
  br label %bb55
bb55:
  %t176 = load i64, ptr %l82, !tbaa !24
  store i64 %t176, ptr %l12, !tbaa !24
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t177 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t177, ptr %l12, !tbaa !24
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2f86b0bb9e05ec4_6260055ddf2cdd10)
  unreachable
bb61:
  %t179 = load i64, ptr %l12, !tbaa !24
  store i64 %t179, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l2, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:mustW", ptr %t8, i32 0, i32 4
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb5
bb5:
  %t13 = load i64, ptr %l15, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb11
bb8:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb11
bb11:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:mustW", ptr %t60, i32 0, i32 4
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l43
  br label %bb16
bb16:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp ne i64 %t68, %t67
  br i1 %t70, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l46, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:mustW", ptr %t73, i32 0, i32 5
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  store ptr %t79, ptr %l50
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t80, ptr %t81, i64 1)
  store i1 %t82, ptr %l51
  br label %bb21
bb21:
  %t83 = load i1, ptr %l51, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i1 true, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb12
bb26:
  %t91 = load i1, ptr %l2, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:walker", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca { i64, ptr }
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l42 = alloca i64
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca i64
  %l55 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca i64
  %l63 = alloca ptr
  %l65 = alloca i64
  %l67 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l89 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca ptr
  %l104 = alloca ptr
  %l110 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Alt", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t30, ptr %t34)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l27
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb24
bb9:
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t55, ptr %l36, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l10, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Bind", ptr %t64, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t69 = sext i32 %t67 to i64
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l10, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Bind", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s4, ptr %t70, ptr %t74)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l46
  br label %bb11
bb11:
  %t78 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %t79
  %t80 = load ptr, ptr %l39, !tbaa !29
  %t81 = load i64, ptr %l42, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s4, ptr %t80, i64 %t81, ptr %t79)
  br label %bb12
bb12:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l10, !tbaa !29
  %t86 = getelementptr %"compiler/typed:Bind", ptr %t84, i32 0, i32 0
  %t87 = load i32, ptr %t86, !tbaa !23
  %t89 = sext i32 %t87 to i64
  %t92 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %t83, i64 %t89)
  store i64 %t92, ptr %l52
  br label %bb13
bb13:
  %t93 = load i64, ptr %l52, !tbaa !24
  store i64 %t93, ptr %l11, !tbaa !24
  %t94 = load i64, ptr %l11, !tbaa !24
  %t96 = icmp sge i64 %t94, 0
  br i1 %t96, label %bb14, label %bb15
bb14:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:walker", ptr %t98, i32 0, i32 2
  %t101 = load i1, ptr %t100, !tbaa !21
  store i1 %t101, ptr %l55, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb16
bb16:
  %t103 = load i1, ptr %l55, !tbaa !21
  br i1 %t103, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/free:walker", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  %t108 = load i64, ptr %l11, !tbaa !24
  store i64 %t108, ptr %l60, !tbaa !24
  %t109 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t109, ptr %l61, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t110)
  store ptr %t112, ptr %l63
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t113 = load ptr, ptr %l63, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 3
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l65, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 33
  %t120 = load %"compiler/source:Span", ptr %t119
  store %"compiler/source:Span" %t120, ptr %l67
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l10, !tbaa !29
  %t124 = getelementptr %"compiler/typed:Bind", ptr %t122, i32 0, i32 0
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  %t130 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %s5, ptr %t121, i64 %t127)
  store { i64, ptr } %t130, ptr %l72
  br label %bb20
bb20:
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t133 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t134, i64 %t135)
  %t142 = getelementptr i8, ptr %t141, i64 %t135
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t152 = load ptr, ptr %l59, !tbaa !29
  %t153 = load i64, ptr %l60, !tbaa !24
  %t154 = load i64, ptr %l61, !tbaa !24
  %t155 = load i64, ptr %l65, !tbaa !24
  %t156 = load %"compiler/source:Span", ptr %l67
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s5, ptr %t152, i64 %t153, i64 %t154, i64 %t155, %"compiler/source:Span" %t156, { i64, ptr } %t151)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s5)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t158 = load i64, ptr %l8, !tbaa !24
  %t160 = add i64 %t158, 1
  store i64 %t160, ptr %l8, !tbaa !24
  br label %bb7
bb24:
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  %t162 = load i64, ptr %l4, !tbaa !24
  %t164 = add i64 %t162, 1
  store i64 %t164, ptr %l4, !tbaa !24
  br label %bb2
bb26:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Arm", ptr %t166, i32 0, i32 2
  %t169 = load ptr, ptr %t168, !tbaa !29
  %t171 = icmp eq ptr %t169, null
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l83, !tbaa !29
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Arm", ptr %t176, i32 0, i32 2
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = icmp eq ptr %t179, null
  br i1 %t181, label %bb29, label %bb30
bb28:
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_304dd9f782c5c299_7aedab6f7faf5da5)
  unreachable
bb30:
  br label %bb31
bb31:
  %t183 = load ptr, ptr %l1, !tbaa !29
  %t185 = getelementptr %"compiler/typed:Arm", ptr %t183, i32 0, i32 2
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t187 = load ptr, ptr %l83, !tbaa !29
  %t189 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t187, ptr %t186)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %l89
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s9)
  br label %bb33
bb33:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = getelementptr %"compiler/typed:Arm", ptr %t190, i32 0, i32 3
  %t193 = load ptr, ptr %t192, !tbaa !29
  %t195 = icmp eq ptr %t193, null
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb34, label %bb35
bb34:
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l94, !tbaa !29
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr %"compiler/typed:Arm", ptr %t200, i32 0, i32 3
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = icmp eq ptr %t203, null
  br i1 %t205, label %bb36, label %bb37
bb35:
  br label %bb40
bb36:
  call void @__olang_check_failed(ptr @olang_loc_ceff65db82d42b72_bd0ee798a65f80fe)
  unreachable
bb37:
  br label %bb38
bb38:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/typed:Arm", ptr %t207, i32 0, i32 3
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load ptr, ptr %l94, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t211, ptr %t210)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Arm", ptr %t213, i32 0, i32 4
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = icmp eq ptr %t216, null
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb41, label %bb42
bb41:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l104, !tbaa !29
  %t223 = load ptr, ptr %l1, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Arm", ptr %t223, i32 0, i32 4
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  br i1 %t228, label %bb43, label %bb44
bb42:
  br label %bb47
bb43:
  call void @__olang_check_failed(ptr @olang_loc_1c2ece56a8f93bb3_9a04e0623a4a84af)
  unreachable
bb44:
  br label %bb45
bb45:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/typed:Arm", ptr %t230, i32 0, i32 4
  %t233 = load ptr, ptr %t232, !tbaa !29
  %t234 = load ptr, ptr %l104, !tbaa !29
  %t236 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t234, ptr %t233)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t236, ptr %l110
  br label %bb46
bb46:
  %t237 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  %t238 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t237, ptr %t238
  br label %bb47
bb47:
  %t239 = load ptr, ptr %lp2
  %t240 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t239
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t240, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp4 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t4, ptr %t7)
  store i64 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t14 = icmp sge i64 %t11, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v1, ptr %t18)
  store i32 %t20, ptr %l15
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t21, ptr %t22, i32 %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l16
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t30 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t27)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l19
  br label %bb7
bb7:
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t31, ptr %lp4
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  %t33 = load ptr, ptr %lp4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %t33
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %lp4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t34, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %lp4
  %t39 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t38
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"compiler/free:leaf"
  %l27 = alloca ptr
  %l29 = alloca ptr
  %l33 = alloca i64
  %l36 = alloca i64
  %l39 = alloca i1
  %l43 = alloca ptr
  %l48 = alloca i1
  %l49 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca i64
  %l59 = alloca i1
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l82 = alloca i32
  %l85 = alloca i32
  %l86 = alloca i1
  %l87 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i32
  %l108 = alloca { i64, ptr }
  %l112 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l125 = alloca ptr
  %l126 = alloca ptr
  %l131 = alloca { i64, ptr }
  %l134 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l136 = alloca i1
  %l139 = alloca i1
  %l145 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l158 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l161 = alloca i1
  %l166 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %l170 = alloca i32
  %l179 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l184 = alloca i64
  %l186 = alloca i64
  %l188 = alloca ptr
  %l195 = alloca %"compiler/free:store"
  %l196 = alloca ptr
  %l197 = alloca i64
  %l198 = alloca i64
  %l200 = alloca ptr
  %l202 = alloca i64
  %l203 = alloca %"compiler/source:Span"
  %l204 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca { i64, ptr }
  %l216 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l27
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l27, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = call ptr @compiler_2ffree_2ecallOf(ptr %v2, ptr %t10)
  store ptr %t12, ptr %l29
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l29, !tbaa !29
  store ptr %t13, ptr %l8, !tbaa !29
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = load ptr, ptr %l8, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v2, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l36
  br label %bb5
bb4:
  store i64 -1, ptr %l33, !tbaa !24
  br label %bb6
bb5:
  %t25 = load i64, ptr %l36, !tbaa !24
  store i64 %t25, ptr %l33, !tbaa !24
  br label %bb6
bb6:
  %t26 = load i64, ptr %l33, !tbaa !24
  store i64 %t26, ptr %l9, !tbaa !24
  %t27 = load i64, ptr %l9, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 1
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  store ptr %t37, ptr %l43
  br label %bb9
bb8:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb10
bb9:
  %t38 = load ptr, ptr %l43, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Body", ptr %t38, i32 0, i32 11
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  %t45 = xor i1 %t43, true
  store i1 %t45, ptr %l39, !tbaa !21
  br label %bb10
bb10:
  %t47 = load i1, ptr %l39, !tbaa !21
  br i1 %t47, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l7, !tbaa !29
  store ptr %t48, ptr %l49, !tbaa !29
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 1
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t55, ptr %l53
  br label %bb13
bb12:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb15
bb13:
  %t56 = load ptr, ptr %l53, !tbaa !29
  %t58 = getelementptr %"compiler/typed:Body", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %t58, !tbaa !23
  %t60 = load ptr, ptr %l49, !tbaa !29
  %t62 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t60, i32 %t59)
  store i64 %t62, ptr %l56
  br label %bb14
bb14:
  %t63 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t64 = load i64, ptr %l56, !tbaa !24
  %t66 = icmp eq i64 %t64, %t63
  store i1 %t66, ptr %l48, !tbaa !21
  br label %bb15
bb15:
  %t68 = load i1, ptr %l48, !tbaa !21
  br i1 %t68, label %bb16, label %bb17
bb16:
  %t69 = load ptr, ptr %l7, !tbaa !29
  store ptr %t69, ptr %l60, !tbaa !29
  %t70 = load ptr, ptr %l6, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 1
  %t73 = load i64, ptr %l9, !tbaa !24
  %t76 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t72, i64 %t73)
  store ptr %t76, ptr %l64
  br label %bb18
bb17:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb20
bb18:
  %t77 = load ptr, ptr %l64, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l60, !tbaa !29
  %t83 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t81, i32 %t80)
  store { i64, ptr } %t83, ptr %l67
  br label %bb19
bb19:
  %t84 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  %t87 = icmp eq i64 %t85, 1
  store i1 %t87, ptr %l59, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l59, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  %t90 = load ptr, ptr %l7, !tbaa !29
  store ptr %t90, ptr %l71, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  store ptr %t91, ptr %l72, !tbaa !29
  %t92 = load ptr, ptr %l7, !tbaa !29
  store ptr %t92, ptr %l73, !tbaa !29
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 1
  %t96 = load i64, ptr %l9, !tbaa !24
  %t99 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t95, i64 %t96)
  store ptr %t99, ptr %l77
  br label %bb23
bb22:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb28
bb23:
  %t100 = load ptr, ptr %l77, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Body", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %t102, !tbaa !23
  %t104 = load ptr, ptr %l73, !tbaa !29
  %t106 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t104, i32 %t103)
  store { i64, ptr } %t106, ptr %l80
  br label %bb24
bb24:
  %t107 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 0
  %t110 = load i32, ptr %t109, !tbaa !33
  %t111 = load ptr, ptr %l72, !tbaa !29
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t111, i32 %t110)
  store i32 %t113, ptr %l82
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l7, !tbaa !29
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t114, i32 %a2)
  store i32 %t118, ptr %l85
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l71, !tbaa !29
  %t120 = load i32, ptr %l82, !tbaa !23
  %t121 = load i32, ptr %l85, !tbaa !23
  %t122 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t119, i32 %t120, i32 %t121)
  store i1 %t122, ptr %l86
  br label %bb27
bb27:
  %t123 = load i1, ptr %l86, !tbaa !21
  store i1 %t123, ptr %l70, !tbaa !21
  br label %bb28
bb28:
  %t124 = load i1, ptr %l70, !tbaa !21
  br i1 %t124, label %bb29, label %bb30
bb29:
  %t125 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t125, ptr %l87
  br label %bb31
bb30:
  br label %bb65
bb31:
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 8, i64 8)
  store ptr %t126, ptr %lp10
  %t127 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  %t128 = load ptr, ptr %lp10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t127, ptr %t128
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l88, !tbaa !29
  %t130 = load ptr, ptr %l88, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t130, i32 0, i32 29
  %t132 = load i64, ptr %t131, !tbaa !24
  %t134 = add i64 %t132, 1
  %t136 = load ptr, ptr %l88, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t136, i32 0, i32 29
  store i64 %t134, ptr %t137, !tbaa !24
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = getelementptr %"compiler/free:Free", ptr %t138, i32 0, i32 20
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l94
  br label %bb32
bb32:
  %t145 = load ptr, ptr %l94, !tbaa !29
  store ptr %t145, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t146 = load ptr, ptr %l11, !tbaa !29
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t146, i64 %t147)
  %t151 = extractvalue { i32, { i64, ptr } } %t150, 1
  %t152 = extractvalue { i32, { i64, ptr } } %t150, 0
  store i32 %t152, ptr %l99
  %t153 = icmp ne i32 %t152, 0
  br i1 %t153, label %bb35, label %ok.154
ok.154:
  store { i64, ptr } %t151, ptr %l98
  br label %bb34
bb34:
  %t155 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t155, ptr %l95, !tbaa !27
  br label %bb39
bb35:
  %t156 = load i32, ptr %l99, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_bcb566df5976d573_60ca408bac10c90f)
  unreachable
bb38:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb64
bb39:
  %t161 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t161, ptr %l13, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  store i64 %t164, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t166 = load i64, ptr %l15, !tbaa !24
  %t167 = load i64, ptr %l14, !tbaa !24
  %t170 = icmp slt i64 %t166, %t167
  %t172 = xor i1 %t170, true
  br i1 %t172, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  br label %bb62
bb42:
  br label %bb43
bb43:
  %t174 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t174, ptr %l108, !tbaa !27
  %t175 = load i64, ptr %l15, !tbaa !24
  %t177 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i64, ptr %t178, i64 %t175
  %t180 = load i64, ptr %t179, !tbaa !34
  store i64 %t180, ptr %l16, !tbaa !24
  %t182 = load i64, ptr %l16, !tbaa !24
  %t184 = call i64 @compiler_2ffree_2eokind(i64 %t182)
  store i64 %t184, ptr %l112
  br label %bb44
bb44:
  %t185 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t186 = load i64, ptr %l112, !tbaa !24
  %t188 = icmp eq i64 %t186, %t185
  br i1 %t188, label %bb45, label %bb46
bb45:
  %t190 = load i64, ptr %l16, !tbaa !24
  %t192 = call i64 @compiler_2ffree_2eoval(i64 %t190)
  store i64 %t192, ptr %l116
  br label %bb47
bb46:
  %t193 = load ptr, ptr %lp10
  %t194 = load i64, ptr %l16, !tbaa !24
  %t197 = call i1 @compiler_2ffree_2eaddTo(ptr %v4, ptr %t193, i64 %t194)
  store i1 %t197, ptr %l139
  br label %bb59
bb47:
  %t198 = load i64, ptr %l116, !tbaa !24
  store i64 %t198, ptr %l17, !tbaa !24
  %t199 = load i64, ptr %l17, !tbaa !24
  store i64 %t199, ptr %l117, !tbaa !24
  %t200 = load ptr, ptr %l8, !tbaa !29
  %t202 = icmp eq ptr %t200, null
  br i1 %t202, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237)
  unreachable
bb49:
  br label %bb50
bb50:
  %t204 = load ptr, ptr %l8, !tbaa !29
  %t207 = getelementptr %"compiler/typed:Call", ptr %t204, i32 0, i32 1
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t208, 0
  %t211 = load i64, ptr %l117, !tbaa !24
  %t213 = icmp slt i64 %t211, %t210
  br i1 %t213, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s6
  %t215 = load ptr, ptr %lp10
  store ptr %t215, ptr %l125, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  store ptr %t216, ptr %l126, !tbaa !29
  %t217 = load ptr, ptr %l8, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb53, label %bb54
bb52:
  br label %bb58
bb53:
  call void @__olang_check_failed(ptr @olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237)
  unreachable
bb54:
  br label %bb55
bb55:
  %t221 = load ptr, ptr %l8, !tbaa !29
  %t224 = getelementptr %"compiler/typed:Call", ptr %t221, i32 0, i32 1
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  store { i64, ptr } %t225, ptr %l131, !tbaa !27
  %t226 = load i64, ptr %l17, !tbaa !24
  %t228 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t229 = load ptr, ptr %t228, !tbaa !27
  %t230 = getelementptr ptr, ptr %t229, i64 %t226
  %t231 = load ptr, ptr %t230, !tbaa !39
  %t232 = load ptr, ptr %l126, !tbaa !29
  %t234 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s6, ptr %t232, ptr %t231)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t234, ptr %l134
  br label %bb56
bb56:
  %t235 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l134
  %t236 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t235, ptr %t236
  %t237 = load ptr, ptr %l125, !tbaa !29
  %t239 = call i1 @compiler_2ffree_2eaddAllTo(ptr %v4, ptr %s6, ptr %t237, ptr %t236)
  store i1 %t239, ptr %l136
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb58:
  br label %bb60
bb59:
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s4)
  br label %bb61
bb61:
  %t240 = load i64, ptr %l15, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l15, !tbaa !24
  br label %bb40
bb62:
  %t244 = load i64, ptr %l12, !tbaa !24
  %t245 = load i64, ptr %l14, !tbaa !24
  %t248 = add i64 %t244, %t245
  store i64 %t248, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb63
bb63:
  br label %bb33
bb64:
  %t250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t250, ptr %l145, !tbaa !29
  %t251 = load ptr, ptr %l145, !tbaa !29
  %t252 = getelementptr %"compiler/free:walker", ptr %t251, i32 0, i32 29
  %t253 = load i64, ptr %t252, !tbaa !24
  %t255 = sub i64 %t253, 1
  %t257 = load ptr, ptr %l145, !tbaa !29
  %t258 = getelementptr %"compiler/free:walker", ptr %t257, i32 0, i32 29
  store i64 %t255, ptr %t258, !tbaa !24
  %t259 = load ptr, ptr %lp10
  %t260 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t259
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t260, ptr %rv
  br label %ret
bb65:
  %t262 = load ptr, ptr %l3, !tbaa !29
  store ptr %t262, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t263 = load ptr, ptr %l149, !tbaa !29
  %t264 = icmp ne ptr %t263, null
  br i1 %t264, label %bb66, label %bb67
bb66:
  %t266 = load ptr, ptr %l149, !tbaa !29
  %t267 = load i64, ptr %t266
  %t269 = icmp eq i64 %t267, 0
  store i1 %t269, ptr %l150, !tbaa !21
  br label %bb67
bb67:
  %t270 = load i1, ptr %l150, !tbaa !21
  br i1 %t270, label %bb68, label %bb69
bb68:
  br label %bb74
bb69:
  %t271 = load ptr, ptr %l3, !tbaa !29
  store ptr %t271, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t272 = load ptr, ptr %l153, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb70, label %bb71
bb70:
  %t275 = load ptr, ptr %l153, !tbaa !29
  %t276 = load i64, ptr %t275
  %t278 = icmp eq i64 %t276, 1
  store i1 %t278, ptr %l154, !tbaa !21
  br label %bb71
bb71:
  %t279 = load i1, ptr %l154, !tbaa !21
  br i1 %t279, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb76
bb74:
  %t280 = load ptr, ptr %l4, !tbaa !29
  %t282 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v3, ptr %v4, ptr %t280)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t282, ptr %l158
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t283 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l158
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t283, ptr %rv
  br label %ret
bb76:
  br i1 true, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_7f12d3772dd0a929_45b952e679e83a85)
  unreachable
bb81:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/free:walker", ptr %t284, i32 0, i32 2
  %t287 = load i1, ptr %t286, !tbaa !21
  br i1 %t287, label %bb82, label %bb83
bb82:
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/free:walker", ptr %t289, i32 0, i32 29
  %t292 = load i64, ptr %t291, !tbaa !24
  %t294 = icmp eq i64 %t292, 0
  store i1 %t294, ptr %l161, !tbaa !21
  br label %bb84
bb83:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb84
bb84:
  %t296 = load i1, ptr %l161, !tbaa !21
  br i1 %t296, label %bb85, label %bb86
bb85:
  store ptr %a1, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb87
bb86:
  br label %bb109
bb87:
  store %olang.scope zeroinitializer, ptr %s13
  %t299 = load ptr, ptr %l18, !tbaa !29
  %t300 = load i64, ptr %l19, !tbaa !24
  %t303 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t299, i64 %t300)
  %t304 = extractvalue { i32, { i64, ptr } } %t303, 1
  %t305 = extractvalue { i32, { i64, ptr } } %t303, 0
  store i32 %t305, ptr %l170
  %t306 = icmp ne i32 %t305, 0
  br i1 %t306, label %bb89, label %ok.307
ok.307:
  store { i64, ptr } %t304, ptr %l169
  br label %bb88
bb88:
  %t308 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t308, ptr %l166, !tbaa !27
  br label %bb93
bb89:
  %t309 = load i32, ptr %l170, !tbaa !23
  %t310 = ashr i32 %t309, 16
  %t312 = icmp eq i32 %t310, 1
  br i1 %t312, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_fd03f9e0e77d658_c5fe745f2729a3d4)
  unreachable
bb92:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb108
bb93:
  %t314 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t314, ptr %l20, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t315, 0
  store i64 %t317, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb94
bb94:
  store %olang.scope zeroinitializer, ptr %s14
  %t319 = load i64, ptr %l22, !tbaa !24
  %t320 = load i64, ptr %l21, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb95, label %bb96
bb95:
  call void @__olang_scope_close(ptr %s14)
  br label %bb106
bb96:
  br label %bb97
bb97:
  %t327 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t327, ptr %l179, !tbaa !27
  %t328 = load i64, ptr %l22, !tbaa !24
  %t330 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr %"compiler/free:leaf", ptr %t331, i64 %t328
  %t333 = load %"compiler/free:leaf", ptr %t332
  store %"compiler/free:leaf" %t333, ptr %l23
  %t335 = load ptr, ptr %l6, !tbaa !29
  %t337 = getelementptr %"compiler/free:Free", ptr %t335, i32 0, i32 34
  store ptr %t337, ptr %l183, !tbaa !29
  %t338 = getelementptr %"compiler/free:leaf", ptr %l23, i32 0, i32 1
  %t339 = load i64, ptr %t338, !tbaa !24
  store i64 %t339, ptr %l184, !tbaa !24
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/free:walker", ptr %t340, i32 0, i32 1
  %t343 = load i64, ptr %t342, !tbaa !24
  store i64 %t343, ptr %l186, !tbaa !24
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t344)
  store ptr %t346, ptr %l188
  br label %bb98
bb98:
  %t347 = load ptr, ptr %l188, !tbaa !29
  %t349 = getelementptr %"compiler/typed:Body", ptr %t347, i32 0, i32 3
  %t350 = load i64, ptr %t349, !tbaa !24
  %t351 = load %"compiler/source:Span", ptr %l5
  %t352 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t353 = load ptr, ptr %l3, !tbaa !29
  %t355 = load i64, ptr %l184, !tbaa !24
  %t356 = load i64, ptr %l186, !tbaa !24
  %t361 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t355, i64 %t356, i64 %t350, %"compiler/source:Span" %t351, i64 %t352, i64 -1, i64 -1, ptr %t353, ptr null)
  store %"compiler/free:store" %t361, ptr %l195
  br label %bb99
bb99:
  %t362 = load ptr, ptr %l183, !tbaa !29
  %t363 = load %"compiler/free:store", ptr %l195
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t362, %"compiler/free:store" %t363)
  br label %bb100
bb100:
  %t364 = load ptr, ptr %l6, !tbaa !29
  store ptr %t364, ptr %l196, !tbaa !29
  %t365 = getelementptr %"compiler/free:leaf", ptr %l23, i32 0, i32 1
  %t366 = load i64, ptr %t365, !tbaa !24
  store i64 %t366, ptr %l197, !tbaa !24
  %t367 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t367, ptr %l198, !tbaa !24
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t370 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t368)
  store ptr %t370, ptr %l200
  br label %bb101
bb101:
  %t371 = load ptr, ptr %l200, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Body", ptr %t371, i32 0, i32 3
  %t374 = load i64, ptr %t373, !tbaa !24
  store i64 %t374, ptr %l202, !tbaa !24
  %t375 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t375, ptr %l203
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l204, !tbaa !29
  %t377 = load ptr, ptr %l3, !tbaa !29
  %t379 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t377)
  store %"compiler/source:Span" %t379, ptr %l206
  br label %bb102
bb102:
  %t380 = load ptr, ptr %l204, !tbaa !29
  %t381 = load %"compiler/source:Span", ptr %l206
  %t382 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s14, ptr %t380, %"compiler/source:Span" %t381)
  store { i64, ptr } %t382, ptr %l207
  br label %bb103
bb103:
  %t383 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t385 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = extractvalue { i64, ptr } %t385, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t391 = add i64 %t388, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t383, i64 %t384)
  %t393 = getelementptr i8, ptr %t392, i64 %t384
  call void @olang_textcopy(ptr %t393, ptr %t386, i64 %t387)
  %t394 = getelementptr i8, ptr %t393, i64 %t387
  call void @olang_textcopy(ptr %t394, ptr %t389, i64 %t390)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t392, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = extractvalue { i64, ptr } %t396, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  %t404 = load ptr, ptr %l196, !tbaa !29
  %t405 = load i64, ptr %l197, !tbaa !24
  %t406 = load i64, ptr %l198, !tbaa !24
  %t407 = load i64, ptr %l202, !tbaa !24
  %t408 = load %"compiler/source:Span", ptr %l203
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s14, ptr %t404, i64 %t405, i64 %t406, i64 %t407, %"compiler/source:Span" %t408, { i64, ptr } %t403)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s14)
  br label %bb105
bb105:
  %t410 = load i64, ptr %l22, !tbaa !24
  %t412 = add i64 %t410, 1
  store i64 %t412, ptr %l22, !tbaa !24
  br label %bb94
bb106:
  %t414 = load i64, ptr %l19, !tbaa !24
  %t415 = load i64, ptr %l21, !tbaa !24
  %t418 = add i64 %t414, %t415
  store i64 %t418, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb107
bb107:
  br label %bb87
bb108:
  br label %bb109
bb109:
  %t420 = load ptr, ptr %l4, !tbaa !29
  %t422 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v3, ptr %v4, ptr %t420)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t422, ptr %l216
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s0)
  %t423 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l216
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t423, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, { i64, ptr } }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i1
  %l22 = alloca { i64, i64, i64, { i64, ptr } }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, i64, i64, { i64, ptr } }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l47 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, i64, i64, { i64, ptr } }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, { i64, ptr } }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, i64, i64, { i64, ptr } }
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l80 = alloca i64
  %l83 = alloca i64
  %l86 = alloca i1
  %l90 = alloca ptr
  %l95 = alloca i1
  %l99 = alloca i64
  %l102 = alloca i64
  %l106 = alloca i64
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, i64, i64, { i64, ptr } }
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %l116 = alloca i1
  %l120 = alloca { i64, i64, i64, { i64, ptr } }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca ptr
  %l127 = alloca %"compiler/source:Span"
  %l128 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, i64, i64, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t7 = load ptr, ptr %l14, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l14, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 17
  store i1 %t13, ptr %l15, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t25 = call { i64, i64, i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyMade(ptr %v0, ptr %v1, ptr %v2, ptr %t21, ptr %t22)
  store { i64, i64, i64, { i64, ptr } } %t25, ptr %l22
  br label %bb6
bb6:
  %t26 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l22, i32 0, i32 3
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l23, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = mul i64 %t30, 1
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l25, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !27
  %t37 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !27
  %t39 = load i64, ptr %l24, !tbaa !24
  %t40 = mul i64 %t39, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t36, ptr %t38, i64 %t40, i1 false)
  %t41 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t42 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l22, i32 0, i32 3
  store { i64, ptr } %t41, ptr %t42, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t43 = load { i64, i64, i64, { i64, ptr } }, ptr %l22
  store { i64, i64, i64, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb7:
  %t44 = load ptr, ptr %l1, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb8, label %bb9
bb8:
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 14
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb9
bb9:
  %t52 = load i1, ptr %l27, !tbaa !21
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t59 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t62 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t59, 0
  %t63 = insertvalue { i64, i64, i64, { i64, ptr } } %t62, i64 -1, 1
  %t64 = insertvalue { i64, i64, i64, { i64, ptr } } %t63, i64 -1, 2
  %t66 = insertvalue { i64, i64, i64, { i64, ptr } } %t64, { i64, ptr } %t60, 3
  store { i64, i64, i64, { i64, ptr } } %t66, ptr %l35
  %t67 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l35, i32 0, i32 3
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l36, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l37, !tbaa !24
  %t71 = load i64, ptr %l37, !tbaa !24
  %t72 = mul i64 %t71, 1
  %t73 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t72)
  %t74 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l38, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = load i64, ptr %l37, !tbaa !24
  %t81 = mul i64 %t80, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %t79, i64 %t81, i1 false)
  %t82 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t83 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l35, i32 0, i32 3
  store { i64, ptr } %t82, ptr %t83, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, i64, i64, { i64, ptr } }, ptr %l35
  store { i64, i64, i64, { i64, ptr } } %t84, ptr %rv
  br label %ret
bb13:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t86 = load ptr, ptr %l39, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb14, label %bb15
bb14:
  %t89 = load ptr, ptr %l39, !tbaa !29
  %t90 = load i64, ptr %t89
  %t92 = icmp eq i64 %t90, 4
  store i1 %t92, ptr %l40, !tbaa !21
  br label %bb15
bb15:
  %t93 = load i1, ptr %l40, !tbaa !21
  br i1 %t93, label %bb16, label %bb17
bb16:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb18
bb17:
  br label %bb23
bb18:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t104 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t100, ptr %t101)
  store i64 %t104, ptr %l47
  br label %bb19
bb19:
  %t105 = load i64, ptr %l47, !tbaa !24
  store i64 %t105, ptr %l6, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = icmp sge i64 %t106, 0
  br i1 %t108, label %bb20, label %bb21
bb20:
  %t110 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t114 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t110, 0
  %t116 = insertvalue { i64, i64, i64, { i64, ptr } } %t114, i64 %t111, 1
  %t117 = insertvalue { i64, i64, i64, { i64, ptr } } %t116, i64 -1, 2
  %t119 = insertvalue { i64, i64, i64, { i64, ptr } } %t117, { i64, ptr } %t112, 3
  store { i64, i64, i64, { i64, ptr } } %t119, ptr %l54
  %t120 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l54, i32 0, i32 3
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l55, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l56, !tbaa !24
  %t124 = load i64, ptr %l56, !tbaa !24
  %t125 = mul i64 %t124, 1
  %t126 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l57, !tbaa !27
  %t129 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = load i64, ptr %l56, !tbaa !24
  %t134 = mul i64 %t133, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t130, ptr %t132, i64 %t134, i1 false)
  %t135 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t136 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l54, i32 0, i32 3
  store { i64, ptr } %t135, ptr %t136, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t137 = load { i64, i64, i64, { i64, ptr } }, ptr %l54
  store { i64, i64, i64, { i64, ptr } } %t137, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb28
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_ecfdd571afc7fb57_85e5c41b21451123)
  unreachable
bb28:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t142 = call { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %s0, ptr %t138, ptr %t139)
  store { i64, { i64, ptr } } %t142, ptr %l60
  br label %bb29
bb29:
  %t143 = load { i64, { i64, ptr } }, ptr %l60
  store { i64, { i64, ptr } } %t143, ptr %l7
  %t144 = getelementptr { i64, { i64, ptr } }, ptr %l7, i32 0, i32 0
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l8, !tbaa !24
  %t147 = getelementptr { i64, { i64, ptr } }, ptr %l7, i32 0, i32 1
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l62, !tbaa !27
  %t149 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  store i64 %t150, ptr %l63, !tbaa !24
  %t151 = load i64, ptr %l63, !tbaa !24
  %t152 = mul i64 %t151, 1
  %t153 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t152)
  %t154 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l64, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l63, !tbaa !24
  %t161 = mul i64 %t160, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t157, ptr %t159, i64 %t161, i1 false)
  %t162 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t162, ptr %l9, !tbaa !27
  %t163 = load i64, ptr %l8, !tbaa !24
  %t165 = icmp sge i64 %t163, 0
  br i1 %t165, label %bb30, label %bb31
bb30:
  %t167 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t168 = load i64, ptr %l8, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l69, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t171 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t167, 0
  %t172 = insertvalue { i64, i64, i64, { i64, ptr } } %t171, i64 -1, 1
  %t174 = insertvalue { i64, i64, i64, { i64, ptr } } %t172, i64 %t168, 2
  %t176 = insertvalue { i64, i64, i64, { i64, ptr } } %t174, { i64, ptr } %t169, 3
  store { i64, i64, i64, { i64, ptr } } %t176, ptr %l71
  %t177 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l71, i32 0, i32 3
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  store { i64, ptr } %t178, ptr %l72, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l73, !tbaa !24
  %t181 = load i64, ptr %l73, !tbaa !24
  %t182 = mul i64 %t181, 1
  %t183 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l74, !tbaa !27
  %t186 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = load i64, ptr %l73, !tbaa !24
  %t191 = mul i64 %t190, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t187, ptr %t189, i64 %t191, i1 false)
  %t192 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t193 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l71, i32 0, i32 3
  store { i64, ptr } %t192, ptr %t193, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t194 = load { i64, i64, i64, { i64, ptr } }, ptr %l71
  store { i64, i64, i64, { i64, ptr } } %t194, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = call ptr @compiler_2ffree_2ecallOf(ptr %v1, ptr %t195)
  store ptr %t197, ptr %l76
  br label %bb33
bb33:
  %t198 = load ptr, ptr %l76, !tbaa !29
  store ptr %t198, ptr %l10, !tbaa !29
  %t199 = load ptr, ptr %l10, !tbaa !29
  %t201 = icmp eq ptr %t199, null
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb34, label %bb35
bb34:
  %t205 = load ptr, ptr %l2, !tbaa !29
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t209 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t205, ptr %t206)
  store i64 %t209, ptr %l83
  br label %bb36
bb35:
  store i64 -1, ptr %l80, !tbaa !24
  br label %bb37
bb36:
  %t210 = load i64, ptr %l83, !tbaa !24
  store i64 %t210, ptr %l80, !tbaa !24
  br label %bb37
bb37:
  %t211 = load i64, ptr %l80, !tbaa !24
  store i64 %t211, ptr %l11, !tbaa !24
  %t212 = load i64, ptr %l11, !tbaa !24
  %t214 = icmp sge i64 %t212, 0
  br i1 %t214, label %bb38, label %bb39
bb38:
  %t216 = load ptr, ptr %l2, !tbaa !29
  %t218 = getelementptr %"compiler/free:Free", ptr %t216, i32 0, i32 1
  %t219 = load i64, ptr %l11, !tbaa !24
  %t222 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t218, i64 %t219)
  store ptr %t222, ptr %l90
  br label %bb40
bb39:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb41
bb40:
  %t223 = load ptr, ptr %l90, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Body", ptr %t223, i32 0, i32 11
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = icmp eq ptr %t226, null
  %t230 = xor i1 %t228, true
  store i1 %t230, ptr %l86, !tbaa !21
  br label %bb41
bb41:
  %t232 = load i1, ptr %l86, !tbaa !21
  br i1 %t232, label %bb42, label %bb43
bb42:
  %t233 = load ptr, ptr %l2, !tbaa !29
  %t235 = getelementptr %"compiler/free:Free", ptr %t233, i32 0, i32 26
  %t236 = load i64, ptr %l11, !tbaa !24
  %t239 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t235, i64 %t236)
  store i64 %t239, ptr %l99
  br label %bb44
bb43:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb45
bb44:
  %t240 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t241 = load i64, ptr %l99, !tbaa !24
  %t243 = icmp sge i64 %t241, %t240
  store i1 %t243, ptr %l95, !tbaa !21
  br label %bb45
bb45:
  %t245 = load i1, ptr %l95, !tbaa !21
  br i1 %t245, label %bb46, label %bb47
bb46:
  %t246 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t246, ptr %l102, !tbaa !24
  %t247 = load ptr, ptr %l2, !tbaa !29
  %t249 = getelementptr %"compiler/free:Free", ptr %t247, i32 0, i32 26
  %t250 = load i64, ptr %l11, !tbaa !24
  %t253 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t249, i64 %t250)
  store i64 %t253, ptr %l106
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t254 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t255 = load i64, ptr %l106, !tbaa !24
  %t257 = sub i64 %t255, %t254
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l109, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t259 = load i64, ptr %l102, !tbaa !24
  %t260 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t259, 0
  %t262 = insertvalue { i64, i64, i64, { i64, ptr } } %t260, i64 %t257, 1
  %t263 = insertvalue { i64, i64, i64, { i64, ptr } } %t262, i64 -1, 2
  %t265 = insertvalue { i64, i64, i64, { i64, ptr } } %t263, { i64, ptr } %t258, 3
  store { i64, i64, i64, { i64, ptr } } %t265, ptr %l111
  %t266 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l111, i32 0, i32 3
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  store { i64, ptr } %t267, ptr %l112, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  store i64 %t269, ptr %l113, !tbaa !24
  %t270 = load i64, ptr %l113, !tbaa !24
  %t271 = mul i64 %t270, 1
  %t272 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t271)
  %t273 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  store { i64, ptr } %t274, ptr %l114, !tbaa !27
  %t275 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = load i64, ptr %l113, !tbaa !24
  %t280 = mul i64 %t279, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %t278, i64 %t280, i1 false)
  %t281 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t282 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l111, i32 0, i32 3
  store { i64, ptr } %t281, ptr %t282, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t283 = load { i64, i64, i64, { i64, ptr } }, ptr %l111
  store { i64, i64, i64, { i64, ptr } } %t283, ptr %rv
  br label %ret
bb49:
  %t284 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t286 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t284, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t286, ptr %l116
  br label %bb50
bb50:
  %t287 = load i1, ptr %l116, !tbaa !21
  %t288 = xor i1 %t287, true
  br i1 %t288, label %bb51, label %bb52
bb51:
  %t290 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t291 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t293 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t290, 0
  %t294 = insertvalue { i64, i64, i64, { i64, ptr } } %t293, i64 -1, 1
  %t295 = insertvalue { i64, i64, i64, { i64, ptr } } %t294, i64 -1, 2
  %t297 = insertvalue { i64, i64, i64, { i64, ptr } } %t295, { i64, ptr } %t291, 3
  store { i64, i64, i64, { i64, ptr } } %t297, ptr %l120
  %t298 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l120, i32 0, i32 3
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  store { i64, ptr } %t299, ptr %l121, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t300, 0
  store i64 %t301, ptr %l122, !tbaa !24
  %t302 = load i64, ptr %l122, !tbaa !24
  %t303 = mul i64 %t302, 1
  %t304 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t303)
  %t305 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } %t306, ptr %l123, !tbaa !27
  %t307 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t310 = load ptr, ptr %t309, !tbaa !27
  %t311 = load i64, ptr %l122, !tbaa !24
  %t312 = mul i64 %t311, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t308, ptr %t310, i64 %t312, i1 false)
  %t313 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t314 = getelementptr { i64, i64, i64, { i64, ptr } }, ptr %l120, i32 0, i32 3
  store { i64, ptr } %t313, ptr %t314, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t315 = load { i64, i64, i64, { i64, ptr } }, ptr %l120
  store { i64, i64, i64, { i64, ptr } } %t315, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  %t316 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t316, ptr %l124, !tbaa !24
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l125, !tbaa !29
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t318)
  store %"compiler/source:Span" %t320, ptr %l127
  br label %bb54
bb54:
  %t321 = load ptr, ptr %l125, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l127
  %t323 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s0, ptr %t321, %"compiler/source:Span" %t322)
  store { i64, ptr } %t323, ptr %l128
  br label %bb55
bb55:
  %t324 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t326 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t326, 1
  %t328 = extractvalue { i64, ptr } %t326, 0
  %t329 = add i64 %t325, %t328
  %t330 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t331 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t332 = add i64 %t329, %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t324, i64 %t325)
  %t334 = getelementptr i8, ptr %t333, i64 %t325
  call void @olang_textcopy(ptr %t334, ptr %t327, i64 %t328)
  %t335 = getelementptr i8, ptr %t334, i64 %t328
  call void @olang_textcopy(ptr %t335, ptr %t330, i64 %t331)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t333, 1
  %t338 = load i64, ptr %l124, !tbaa !24
  %t339 = insertvalue { i64, i64, i64, { i64, ptr } } undef, i64 %t338, 0
  %t340 = insertvalue { i64, i64, i64, { i64, ptr } } %t339, i64 -1, 1
  %t341 = insertvalue { i64, i64, i64, { i64, ptr } } %t340, i64 -1, 2
  %t343 = insertvalue { i64, i64, i64, { i64, ptr } } %t341, { i64, ptr } %t337, 3
  call void @__olang_scope_close(ptr %s0)
  store { i64, i64, i64, { i64, ptr } } %t343, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64, { i64, ptr } }, ptr %rv
  ret { i64, i64, i64, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l21 = alloca i64
  %l22 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb4
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 0
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/free:Free", ptr %t8, i32 0, i32 61
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:walker", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  %t17 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t10, i64 %t14)
  store i1 %t17, ptr %l10
  br label %bb3
bb3:
  %t18 = load i1, ptr %l10, !tbaa !21
  %t19 = xor i1 %t18, true
  store i1 %t19, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l4, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 53
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t32, i64 %t33)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36, ptr %l20
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l16, !tbaa !29
  %t38 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  %t39 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %t37, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t38)
  %t40 = extractvalue { i32, i64 } %t39, 1
  %t41 = extractvalue { i32, i64 } %t39, 0
  store i32 %t41, ptr %l22
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb10, label %ok.43
ok.43:
  store i64 %t40, ptr %l21
  br label %bb9
bb9:
  %t44 = load i64, ptr %l21, !tbaa !24
  store i64 %t44, ptr %l13, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i64, ptr %l13, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/free:leaf"
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca ptr
  %l34 = alloca i1
  %l43 = alloca i1
  %l47 = alloca { i64, ptr }
  %l49 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i1
  %l66 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca i64
  %l73 = alloca ptr
  %l76 = alloca i64
  %l78 = alloca i64
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l98 = alloca { i64, ptr }
  %l102 = alloca i64
  %l105 = alloca ptr
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca %"compiler/source:Span"
  %l116 = alloca ptr
  %l117 = alloca i1
  %l127 = alloca i64
  %l130 = alloca ptr
  %l131 = alloca i64
  %l132 = alloca i64
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca %"compiler/source:Span"
  %l139 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca i32
  %l154 = alloca { i64, ptr }
  %l157 = alloca ptr
  %l158 = alloca i64
  %l159 = alloca i64
  %l161 = alloca %"compiler/source:Span"
  %l162 = alloca %"compiler/source:Span"
  %l169 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l178 = alloca i32
  %l187 = alloca { i64, ptr }
  %l191 = alloca i64
  %l194 = alloca ptr
  %l196 = alloca i64
  %l197 = alloca i64
  %l199 = alloca %"compiler/source:Span"
  %l201 = alloca %"compiler/source:Span"
  %l205 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %t2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l3
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t8 = load ptr, ptr %l33, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l33, !tbaa !29
  %t12 = load i64, ptr %t11
  %t14 = icmp eq i64 %t12, 9
  store i1 %t14, ptr %l34, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l34, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l4
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t24, i32 0, i32 4
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l5, !tbaa !27
  br label %bb6
bb5:
  br label %bb56
bb6:
  %t28 = load i32, ptr %l4
  %t30 = trunc i64 30 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:walker", ptr %t33, i32 0, i32 29
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l43, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb9
bb9:
  %t40 = load i1, ptr %l43, !tbaa !21
  br i1 %t40, label %bb10, label %bb11
bb10:
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t41, ptr %l47, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t47 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v1, ptr %t45)
  store i64 %t47, ptr %l49
  br label %bb12
bb11:
  br label %bb55
bb12:
  %t48 = load i64, ptr %l49, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2edestroyOf(ptr %v0, ptr %t49, i64 %t50)
  store i64 %t53, ptr %l52
  br label %bb13
bb13:
  %t54 = load i64, ptr %l52, !tbaa !24
  store i64 %t54, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t59, i32 0, i32 2
  %t62 = load i1, ptr %t61, !tbaa !21
  store i1 %t62, ptr %l55, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l55, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:walker", ptr %t65, i32 0, i32 46
  %t68 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 %t68)
  br label %bb19
bb18:
  br label %bb28
bb19:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:walker", ptr %t71, i32 0, i32 47
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 12
  %t77 = load i64, ptr %t76, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t73, i64 %t77)
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/free:walker", ptr %t80, i32 0, i32 48
  store ptr %t82, ptr %l66, !tbaa !29
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 52
  %t87 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l69
  br label %bb21
bb21:
  %t88 = load i64, ptr %l69, !tbaa !24
  %t89 = icmp sgt i64 %t88, 0
  br i1 %t89, label %bb22, label %bb23
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/free:walker", ptr %t91, i32 0, i32 52
  store ptr %t93, ptr %l73, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:walker", ptr %t94, i32 0, i32 52
  %t98 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t96)
  store i64 %t98, ptr %l76
  br label %bb24
bb23:
  store i64 -1, ptr %l71, !tbaa !24
  br label %bb26
bb24:
  %t99 = load i64, ptr %l76, !tbaa !24
  %t100 = sub i64 %t99, 1
  %t101 = load ptr, ptr %l73, !tbaa !29
  %t103 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t101, i64 %t100)
  store i64 %t103, ptr %l78
  br label %bb25
bb25:
  %t104 = load i64, ptr %l78, !tbaa !24
  store i64 %t104, ptr %l71, !tbaa !24
  br label %bb26
bb26:
  %t105 = load ptr, ptr %l66, !tbaa !29
  %t106 = load i64, ptr %l71, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t105, i64 %t106)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t107 = load i64, ptr %l6, !tbaa !24
  %t109 = icmp sge i64 %t107, 0
  br i1 %t109, label %bb29, label %bb30
bb29:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t111, i32 0, i32 3
  %t114 = load i64, ptr %l6, !tbaa !24
  %t117 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t113, i64 %t114)
  store ptr %t117, ptr %l84
  br label %bb31
bb30:
  br label %bb54
bb31:
  %t118 = load ptr, ptr %l84, !tbaa !29
  store ptr %t118, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t119 = load ptr, ptr %l8, !tbaa !29
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t119, i64 %t120)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l89
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb34, label %ok.127
ok.127:
  store { i64, ptr } %t124, ptr %l88
  br label %bb33
bb33:
  %t128 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t128, ptr %l85, !tbaa !27
  br label %bb38
bb34:
  %t129 = load i32, ptr %l89, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_5c8710160ed2ee88_42fe4478e6ab17dc)
  unreachable
bb37:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb53
bb38:
  %t134 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t134, ptr %l10, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  store i64 %t137, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s7
  %t139 = load i64, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = icmp slt i64 %t139, %t140
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s7)
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t147 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t147, ptr %l98, !tbaa !27
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr i64, ptr %t151, i64 %t148
  %t153 = load i64, ptr %t152, !tbaa !34
  store i64 %t153, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t157 = call i64 @compiler_2ffree_2eokind(i64 %t155)
  store i64 %t157, ptr %l102
  br label %bb43
bb43:
  %t158 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t159 = load i64, ptr %l102, !tbaa !24
  %t161 = icmp eq i64 %t159, %t158
  br i1 %t161, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l105, !tbaa !29
  %t164 = load i64, ptr %l13, !tbaa !24
  %t166 = call i64 @compiler_2ffree_2eoval(i64 %t164)
  store i64 %t166, ptr %l107
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t167 = load i64, ptr @G_2ecompiler_2ffree_2eLDestroy, !tbaa !24
  store i64 %t167, ptr %l108, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l109
  %t169 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s8, i32 0, i32 0)
  store %"compiler/source:Span" %t169, ptr %l110
  br label %bb47
bb47:
  %t170 = load ptr, ptr %l105, !tbaa !29
  %t171 = load i64, ptr %l107, !tbaa !24
  %t172 = load i64, ptr %l108, !tbaa !24
  %t173 = load %"compiler/source:Span", ptr %l109
  %t174 = load %"compiler/source:Span", ptr %l110
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t170, i64 %t171, i64 %t172, %"compiler/source:Span" %t173, %"compiler/source:Span" %t174, i64 -1)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s7)
  br label %bb50
bb50:
  %t175 = load i64, ptr %l12, !tbaa !24
  %t177 = add i64 %t175, 1
  store i64 %t177, ptr %l12, !tbaa !24
  br label %bb39
bb51:
  %t179 = load i64, ptr %l9, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  %t183 = add i64 %t179, %t180
  store i64 %t183, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb52
bb52:
  br label %bb32
bb53:
  br label %bb54
bb54:
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb56:
  %t185 = load ptr, ptr %l2, !tbaa !29
  store ptr %t185, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t186 = load ptr, ptr %l116, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb57, label %bb58
bb57:
  %t189 = load ptr, ptr %l116, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 4
  store i1 %t192, ptr %l117, !tbaa !21
  br label %bb58
bb58:
  %t193 = load i1, ptr %l117, !tbaa !21
  br i1 %t193, label %bb59, label %bb60
bb59:
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t196, i32 0, i32 1
  %t198 = load i32, ptr %t197
  store i32 %t198, ptr %l14, !tbaa !23
  %t200 = load ptr, ptr %l2, !tbaa !29
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t200, i32 0, i32 1
  %t203 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t202, i32 0, i32 2
  %t204 = load ptr, ptr %t203
  store ptr %t204, ptr %l15, !tbaa !29
  br label %bb61
bb60:
  br label %bb88
bb61:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/free:walker", ptr %t206, i32 0, i32 0
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t210 = load ptr, ptr %l15, !tbaa !29
  %t213 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t209, ptr %t210)
  store i64 %t213, ptr %l127
  br label %bb62
bb62:
  %t214 = load i64, ptr %l127, !tbaa !24
  store i64 %t214, ptr %l16, !tbaa !24
  %t215 = load i64, ptr %l16, !tbaa !24
  %t217 = icmp sge i64 %t215, 0
  br i1 %t217, label %bb63, label %bb64
bb63:
  store %olang.scope zeroinitializer, ptr %s11
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l130, !tbaa !29
  %t220 = load i64, ptr %l16, !tbaa !24
  store i64 %t220, ptr %l131, !tbaa !24
  %t221 = load i64, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  store i64 %t221, ptr %l132, !tbaa !24
  %t222 = load ptr, ptr %l15, !tbaa !29
  %t224 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t222)
  store %"compiler/source:Span" %t224, ptr %l134
  br label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s13
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/free:walker", ptr %t225, i32 0, i32 0
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t229 = load i32, ptr %l14, !tbaa !23
  %t232 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t228, i32 %t229)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t232, ptr %l139
  br label %bb68
bb65:
  %t233 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 0, i32 0)
  store %"compiler/source:Span" %t233, ptr %l135
  br label %bb66
bb66:
  %t234 = load ptr, ptr %l130, !tbaa !29
  %t235 = load i64, ptr %l131, !tbaa !24
  %t236 = load i64, ptr %l132, !tbaa !24
  %t237 = load %"compiler/source:Span", ptr %l134
  %t238 = load %"compiler/source:Span", ptr %l135
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t234, i64 %t235, i64 %t236, %"compiler/source:Span" %t237, %"compiler/source:Span" %t238, i64 -1)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb87
bb68:
  %t239 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l139
  %t240 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t239, ptr %t240
  store ptr %t240, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb69
bb69:
  store %olang.scope zeroinitializer, ptr %s14
  %t242 = load ptr, ptr %l17, !tbaa !29
  %t243 = load i64, ptr %l18, !tbaa !24
  %t246 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %t242, i64 %t243)
  %t247 = extractvalue { i32, { i64, ptr } } %t246, 1
  %t248 = extractvalue { i32, { i64, ptr } } %t246, 0
  store i32 %t248, ptr %l145
  %t249 = icmp ne i32 %t248, 0
  br i1 %t249, label %bb71, label %ok.250
ok.250:
  store { i64, ptr } %t247, ptr %l144
  br label %bb70
bb70:
  %t251 = load { i64, ptr }, ptr %l144, !tbaa !27
  store { i64, ptr } %t251, ptr %l141, !tbaa !27
  br label %bb75
bb71:
  %t252 = load i32, ptr %l145, !tbaa !23
  %t253 = ashr i32 %t252, 16
  %t255 = icmp eq i32 %t253, 1
  br i1 %t255, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_4b8c217179c46859_da1f305a1bc3b10d)
  unreachable
bb74:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s14)
  br label %bb86
bb75:
  %t257 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t257, ptr %l19, !tbaa !27
  %t258 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 0
  store i64 %t260, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s15
  %t262 = load i64, ptr %l21, !tbaa !24
  %t263 = load i64, ptr %l20, !tbaa !24
  %t266 = icmp slt i64 %t262, %t263
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s15)
  br label %bb84
bb78:
  br label %bb79
bb79:
  %t270 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t270, ptr %l154, !tbaa !27
  %t271 = load i64, ptr %l21, !tbaa !24
  %t273 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr %"compiler/free:leaf", ptr %t274, i64 %t271
  %t276 = load %"compiler/free:leaf", ptr %t275
  store %"compiler/free:leaf" %t276, ptr %l22
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l157, !tbaa !29
  %t279 = getelementptr %"compiler/free:leaf", ptr %l22, i32 0, i32 1
  %t280 = load i64, ptr %t279, !tbaa !24
  store i64 %t280, ptr %l158, !tbaa !24
  %t281 = load i64, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  store i64 %t281, ptr %l159, !tbaa !24
  %t282 = load ptr, ptr %l15, !tbaa !29
  %t284 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v1, ptr %t282)
  store %"compiler/source:Span" %t284, ptr %l161
  br label %bb80
bb80:
  %t285 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s15, i32 0, i32 0)
  store %"compiler/source:Span" %t285, ptr %l162
  br label %bb81
bb81:
  %t286 = load ptr, ptr %l157, !tbaa !29
  %t287 = load i64, ptr %l158, !tbaa !24
  %t288 = load i64, ptr %l159, !tbaa !24
  %t289 = load %"compiler/source:Span", ptr %l161
  %t290 = load %"compiler/source:Span", ptr %l162
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t286, i64 %t287, i64 %t288, %"compiler/source:Span" %t289, %"compiler/source:Span" %t290, i64 -1)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s15)
  br label %bb83
bb83:
  %t291 = load i64, ptr %l21, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l21, !tbaa !24
  br label %bb76
bb84:
  %t295 = load i64, ptr %l18, !tbaa !24
  %t296 = load i64, ptr %l20, !tbaa !24
  %t299 = add i64 %t295, %t296
  store i64 %t299, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb85
bb85:
  br label %bb69
bb86:
  call void @__olang_scope_close(ptr %s13)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb88:
  br i1 true, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_8eca167e18f35462_967477b580f85776)
  unreachable
bb93:
  %t301 = load ptr, ptr %l2, !tbaa !29
  %t303 = call ptr @compiler_2ffree_2ecallOf(ptr %v1, ptr %t301)
  store ptr %t303, ptr %l169
  br label %bb94
bb94:
  %t304 = load ptr, ptr %l169, !tbaa !29
  store ptr %t304, ptr %l23, !tbaa !29
  %t305 = load ptr, ptr %l23, !tbaa !29
  %t307 = icmp eq ptr %t305, null
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb95, label %bb96
bb95:
  store ptr %l3, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb97
bb96:
  br label %bb121
bb97:
  store %olang.scope zeroinitializer, ptr %s20
  %t312 = load ptr, ptr %l24, !tbaa !29
  %t313 = load i64, ptr %l25, !tbaa !24
  %t316 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t312, i64 %t313)
  %t317 = extractvalue { i32, { i64, ptr } } %t316, 1
  %t318 = extractvalue { i32, { i64, ptr } } %t316, 0
  store i32 %t318, ptr %l178
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb99, label %ok.320
ok.320:
  store { i64, ptr } %t317, ptr %l177
  br label %bb98
bb98:
  %t321 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t321, ptr %l174, !tbaa !27
  br label %bb103
bb99:
  %t322 = load i32, ptr %l178, !tbaa !23
  %t323 = ashr i32 %t322, 16
  %t325 = icmp eq i32 %t323, 1
  br i1 %t325, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_2aee3a5952843263_7eebd62eaf5d5017)
  unreachable
bb102:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s20)
  br label %bb120
bb103:
  %t327 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t327, ptr %l26, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t328, 0
  store i64 %t330, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s21
  %t332 = load i64, ptr %l28, !tbaa !24
  %t333 = load i64, ptr %l27, !tbaa !24
  %t336 = icmp slt i64 %t332, %t333
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s21)
  br label %bb118
bb106:
  br label %bb107
bb107:
  %t340 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t340, ptr %l187, !tbaa !27
  %t341 = load i64, ptr %l28, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr i64, ptr %t344, i64 %t341
  %t346 = load i64, ptr %t345, !tbaa !34
  store i64 %t346, ptr %l29, !tbaa !24
  %t348 = load i64, ptr %l29, !tbaa !24
  %t350 = call i64 @compiler_2ffree_2eokind(i64 %t348)
  store i64 %t350, ptr %l191
  br label %bb108
bb108:
  %t351 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t352 = load i64, ptr %l191, !tbaa !24
  %t354 = icmp eq i64 %t352, %t351
  br i1 %t354, label %bb109, label %bb110
bb109:
  %t356 = load ptr, ptr %l0, !tbaa !29
  store ptr %t356, ptr %l194, !tbaa !29
  %t357 = load i64, ptr %l29, !tbaa !24
  %t359 = call i64 @compiler_2ffree_2eoval(i64 %t357)
  store i64 %t359, ptr %l196
  br label %bb111
bb110:
  br label %bb116
bb111:
  %t360 = load i64, ptr @G_2ecompiler_2ffree_2eLDrop, !tbaa !24
  store i64 %t360, ptr %l197, !tbaa !24
  %t361 = load ptr, ptr %l2, !tbaa !29
  %t363 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t361)
  store %"compiler/source:Span" %t363, ptr %l199
  br label %bb112
bb112:
  %t364 = load ptr, ptr %l23, !tbaa !29
  %t366 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t364)
  store %"compiler/source:Span" %t366, ptr %l201
  br label %bb113
bb113:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr %"compiler/free:walker", ptr %t367, i32 0, i32 0
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t371 = load ptr, ptr %l23, !tbaa !29
  %t374 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t370, ptr %t371)
  store i64 %t374, ptr %l205
  br label %bb114
bb114:
  %t375 = load ptr, ptr %l194, !tbaa !29
  %t376 = load i64, ptr %l196, !tbaa !24
  %t377 = load i64, ptr %l197, !tbaa !24
  %t378 = load %"compiler/source:Span", ptr %l199
  %t379 = load %"compiler/source:Span", ptr %l201
  %t380 = load i64, ptr %l205, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t375, i64 %t376, i64 %t377, %"compiler/source:Span" %t378, %"compiler/source:Span" %t379, i64 %t380)
  br label %bb115
bb115:
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s21)
  br label %bb117
bb117:
  %t381 = load i64, ptr %l28, !tbaa !24
  %t383 = add i64 %t381, 1
  store i64 %t383, ptr %l28, !tbaa !24
  br label %bb104
bb118:
  %t385 = load i64, ptr %l25, !tbaa !24
  %t386 = load i64, ptr %l27, !tbaa !24
  %t389 = add i64 %t385, %t386
  store i64 %t389, ptr %l25, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb119
bb119:
  br label %bb97
bb120:
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i64
  %l68 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i64
  %l81 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 16
  %t12 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l19
  br label %bb4
bb4:
  %t13 = load i64, ptr %l19, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l26, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t41 = load i64, ptr %l23, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 16
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l47
  br label %bb15
bb15:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l47, !tbaa !24
  %t70 = icmp sle i64 %t68, %t67
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load i64, ptr %l1, !tbaa !24
  store i64 %t72, ptr %l51, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 17
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l55
  br label %bb18
bb17:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb19
bb18:
  %t80 = load i64, ptr %l51, !tbaa !24
  %t81 = load i64, ptr %l55, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  store i1 %t82, ptr %l50, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l50, !tbaa !21
  store i1 %t84, ptr %l9, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 18
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l60
  br label %bb20
bb20:
  %t92 = load i64, ptr %l1, !tbaa !24
  %t93 = load i64, ptr %l60, !tbaa !24
  %t95 = icmp sle i64 %t93, %t92
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %l64, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:walker", ptr %t98, i32 0, i32 19
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l68
  br label %bb23
bb22:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb24
bb23:
  %t105 = load i64, ptr %l64, !tbaa !24
  %t106 = load i64, ptr %l68, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  store i1 %t107, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l63, !tbaa !21
  store i1 %t109, ptr %l10, !tbaa !21
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/free:walker", ptr %t110, i32 0, i32 16
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l73
  br label %bb25
bb25:
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr %l73, !tbaa !24
  %t120 = icmp sle i64 %t118, %t117
  br i1 %t120, label %bb26, label %bb27
bb26:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l77, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 17
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l81
  br label %bb28
bb27:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb29
bb28:
  %t130 = load i64, ptr %l77, !tbaa !24
  %t131 = load i64, ptr %l81, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l76, !tbaa !21
  br label %bb29
bb29:
  %t134 = load i1, ptr %l76, !tbaa !21
  store i1 %t134, ptr %l11, !tbaa !21
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t135, i32 0, i32 18
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l86
  br label %bb30
bb30:
  %t142 = load i64, ptr %l2, !tbaa !24
  %t143 = load i64, ptr %l86, !tbaa !24
  %t145 = icmp sle i64 %t143, %t142
  br i1 %t145, label %bb31, label %bb32
bb31:
  %t147 = load i64, ptr %l2, !tbaa !24
  store i64 %t147, ptr %l90, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/free:walker", ptr %t148, i32 0, i32 19
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l94
  br label %bb33
bb32:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb34
bb33:
  %t155 = load i64, ptr %l90, !tbaa !24
  %t156 = load i64, ptr %l94, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  store i1 %t157, ptr %l89, !tbaa !21
  br label %bb34
bb34:
  %t159 = load i1, ptr %l89, !tbaa !21
  store i1 %t159, ptr %l12, !tbaa !21
  %t160 = load i1, ptr %l9, !tbaa !21
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load i1, ptr %l12, !tbaa !21
  store i1 %t162, ptr %l97, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb37
bb37:
  %t164 = load i1, ptr %l97, !tbaa !21
  br i1 %t164, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb43
bb39:
  %t165 = load i1, ptr %l10, !tbaa !21
  br i1 %t165, label %bb40, label %bb41
bb40:
  %t167 = load i1, ptr %l11, !tbaa !21
  store i1 %t167, ptr %l101, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t169 = load i1, ptr %l101, !tbaa !21
  store i1 %t169, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t170 = load i1, ptr %l99, !tbaa !21
  br i1 %t170, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s3)
  br label %bb47
bb47:
  %t172 = load i64, ptr %l7, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l7, !tbaa !24
  br label %bb11
bb48:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i1
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i1
  %l79 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i64
  %l89 = alloca i64
  %l91 = alloca i1
  %l94 = alloca i1
  %l95 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l2, !tbaa !24
  br label %bb60
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t21 = load ptr, ptr %l19, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l20, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t39 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l27
  br label %bb12
bb12:
  %t40 = load i64, ptr %l27, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t42 = load ptr, ptr %l28, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = load i64, ptr %t45
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l29, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l29, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l37
  br label %bb19
bb19:
  %t64 = load i64, ptr %l37, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t66 = load ptr, ptr %l38, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l38, !tbaa !29
  %t70 = load i64, ptr %t69
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l39, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l39, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l47
  br label %bb26
bb26:
  %t88 = load i64, ptr %l47, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
bb27:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %l48, !tbaa !29
  %t94 = load i64, ptr %t93
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l49, !tbaa !21
  br label %bb29
bb29:
  %t97 = load i1, ptr %l49, !tbaa !21
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l7, !tbaa !29
  br label %bb32
bb31:
  br label %bb55
bb32:
  %t104 = load ptr, ptr %l7, !tbaa !29
  store ptr %t104, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t105 = load ptr, ptr %l54, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb33, label %bb34
bb33:
  %t108 = load ptr, ptr %l54, !tbaa !29
  %t109 = load i64, ptr %t108
  %t111 = icmp eq i64 %t109, 2
  store i1 %t111, ptr %l55, !tbaa !21
  br label %bb34
bb34:
  %t112 = load i1, ptr %l55, !tbaa !21
  br i1 %t112, label %bb35, label %bb36
bb35:
  %t113 = load ptr, ptr %l7, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l8, !tbaa !29
  br label %bb37
bb36:
  br label %bb49
bb37:
  %t119 = load ptr, ptr %l8, !tbaa !29
  store ptr %t119, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t120 = load ptr, ptr %l60, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l60, !tbaa !29
  %t124 = load i64, ptr %t123
  %t126 = icmp eq i64 %t124, 0
  store i1 %t126, ptr %l61, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l61, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t130, i32 0, i32 2
  %t132 = load i32, ptr %t131
  store i32 %t132, ptr %l9, !tbaa !23
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t134 = load i32, ptr %l9, !tbaa !23
  %t136 = sext i32 %t134 to i64
  store i64 %t136, ptr %l2, !tbaa !24
  br label %bb48
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb47
bb46:
  store i64 -1, ptr %rv
  br label %ret
bb47:
  call void @__olang_check_failed(ptr @olang_loc_e32699ce7a94654a_1a46213a714ace46)
  unreachable
bb48:
  br label %bb54
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i64 -1, ptr %rv
  br label %ret
bb53:
  call void @__olang_check_failed(ptr @olang_loc_9bcfcd4682c2cf8b_e11249f2fcc24427)
  unreachable
bb54:
  br label %bb60
bb55:
  br i1 true, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  store i64 -1, ptr %rv
  br label %ret
bb59:
  call void @__olang_check_failed(ptr @olang_loc_d00dfbb4bbbc7050_caf5ecf8a62b36ac)
  unreachable
bb60:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:walker", ptr %t141, i32 0, i32 6
  %t144 = load i64, ptr %l2, !tbaa !24
  %t147 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t143, i64 %t144)
  store i1 %t147, ptr %l74
  br label %bb61
bb61:
  %t148 = load i1, ptr %l74, !tbaa !21
  br i1 %t148, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb65
bb63:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 7
  %t152 = load i64, ptr %l2, !tbaa !24
  %t155 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t151, i64 %t152)
  store i1 %t155, ptr %l79
  br label %bb64
bb64:
  %t156 = load i1, ptr %l79, !tbaa !21
  store i1 %t156, ptr %l75, !tbaa !21
  br label %bb65
bb65:
  %t157 = load i1, ptr %l75, !tbaa !21
  br i1 %t157, label %bb66, label %bb67
bb66:
  store i64 -1, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 0
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/free:Free", ptr %t162, i32 0, i32 47
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:walker", ptr %t165, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  %t171 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H96e9eb9990b7b2982627078c49255e88(ptr %v0, ptr %v0, ptr %t164, i64 %t168)
  store ptr %t171, ptr %l86
  br label %bb69
bb69:
  %t172 = load ptr, ptr %l86, !tbaa !29
  store ptr %t172, ptr %l10, !tbaa !29
  %t173 = load i64, ptr %l2, !tbaa !24
  store i64 %t173, ptr %l87, !tbaa !24
  %t174 = load ptr, ptr %l10, !tbaa !29
  %t176 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l89
  br label %bb70
bb70:
  %t177 = load i64, ptr %l87, !tbaa !24
  %t178 = load i64, ptr %l89, !tbaa !24
  %t179 = icmp slt i64 %t177, %t178
  br i1 %t179, label %bb71, label %bb72
bb71:
  %t181 = load ptr, ptr %l10, !tbaa !29
  %t182 = load i64, ptr %l2, !tbaa !24
  %t185 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t181, i64 %t182)
  store i1 %t185, ptr %l94
  br label %bb73
bb72:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb74
bb73:
  %t186 = load i1, ptr %l94, !tbaa !21
  store i1 %t186, ptr %l91, !tbaa !21
  br label %bb74
bb74:
  %t187 = load i1, ptr %l91, !tbaa !21
  br i1 %t187, label %bb75, label %bb76
bb75:
  %t188 = load i64, ptr %l2, !tbaa !24
  store i64 %t188, ptr %l95, !tbaa !24
  br label %bb77
bb76:
  store i64 -1, ptr %l95, !tbaa !24
  br label %bb77
bb77:
  %t190 = load i64, ptr %l95, !tbaa !24
  store i64 %t190, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l64 = alloca i1
  %l69 = alloca ptr
  %l72 = alloca i64
  %l74 = alloca ptr
  %l75 = alloca i64
  %l77 = alloca i64
  %l79 = alloca ptr
  %l81 = alloca i64
  %l83 = alloca %"compiler/source:Span"
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca i64
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca i64
  %l91 = alloca i1
  %l93 = alloca i1
  %l94 = alloca %"compiler/free:letGo"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb15
bb3:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 25
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:walker", ptr %t20, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t19, i64 %t23)
  store i1 %t26, ptr %l19
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i1, ptr %l19, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t33, i64 %t37)
  store ptr %t40, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb9:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t44 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t42, i64 %t41)
  store i1 %t44, ptr %l28
  br label %bb10
bb10:
  %t45 = load i1, ptr %l28, !tbaa !21
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t46 = load i1, ptr %l21, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t47 = load ptr, ptr %l6, !tbaa !29
  %t49 = getelementptr %"compiler/free:Free", ptr %t47, i32 0, i32 30
  store i1 true, ptr %t49, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/free:walker", ptr %t50, i32 0, i32 29
  %t53 = load i64, ptr %t52, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 36
  %t60 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t59, i64 %t60)
  br label %bb19
bb19:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 37
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 12
  %t69 = load i64, ptr %t68, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 %t69)
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:walker", ptr %t72, i32 0, i32 38
  %t75 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t74, i64 %t75)
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/free:walker", ptr %t78, i32 0, i32 39
  %t81 = load %"compiler/source:Span", ptr %l3
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t80, %"compiler/source:Span" %t81)
  br label %bb22
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:walker", ptr %t84, i32 0, i32 40
  %t87 = load %"compiler/source:Span", ptr %l4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t86, %"compiler/source:Span" %t87)
  br label %bb23
bb23:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:walker", ptr %t90, i32 0, i32 41
  %t93 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t92, i64 %t93)
  br label %bb24
bb24:
  %t96 = load i64, ptr %l2, !tbaa !24
  %t97 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  %t100 = icmp eq i64 %t96, %t97
  br i1 %t100, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb31
bb26:
  %t102 = load i64, ptr %l2, !tbaa !24
  %t103 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t106 = icmp eq i64 %t102, %t103
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l6, !tbaa !29
  %t110 = getelementptr %"compiler/free:Free", ptr %t108, i32 0, i32 18
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t111, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  %t117 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t110, i64 %t114)
  store i1 %t117, ptr %l64
  br label %bb29
bb28:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb30
bb29:
  %t118 = load i1, ptr %l64, !tbaa !21
  %t119 = xor i1 %t118, true
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb30
bb30:
  %t121 = load i1, ptr %l59, !tbaa !21
  store i1 %t121, ptr %l55, !tbaa !21
  br label %bb31
bb31:
  %t122 = load i1, ptr %l55, !tbaa !21
  br i1 %t122, label %bb32, label %bb33
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 42
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t125, i64 -1)
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb35:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/free:walker", ptr %t127, i32 0, i32 42
  store ptr %t129, ptr %l69, !tbaa !29
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr %"compiler/free:Free", ptr %t130, i32 0, i32 35
  %t134 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t132)
  store i64 %t134, ptr %l72
  br label %bb36
bb36:
  %t135 = load ptr, ptr %l69, !tbaa !29
  %t136 = load i64, ptr %l72, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t135, i64 %t136)
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l6, !tbaa !29
  %t139 = getelementptr %"compiler/free:Free", ptr %t137, i32 0, i32 35
  store ptr %t139, ptr %l74, !tbaa !29
  %t140 = load i64, ptr %l1, !tbaa !24
  store i64 %t140, ptr %l75, !tbaa !24
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:walker", ptr %t141, i32 0, i32 1
  %t144 = load i64, ptr %t143, !tbaa !24
  store i64 %t144, ptr %l77, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t145)
  store ptr %t147, ptr %l79
  br label %bb38
bb38:
  %t148 = load ptr, ptr %l79, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Body", ptr %t148, i32 0, i32 3
  %t151 = load i64, ptr %t150, !tbaa !24
  store i64 %t151, ptr %l81, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/free:walker", ptr %t152, i32 0, i32 33
  %t155 = load %"compiler/source:Span", ptr %t154
  store %"compiler/source:Span" %t155, ptr %l83
  %t156 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t156, ptr %l84
  %t157 = load i64, ptr %l2, !tbaa !24
  store i64 %t157, ptr %l85, !tbaa !24
  %t158 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t158, ptr %l86
  %t159 = load i64, ptr %l5, !tbaa !24
  store i64 %t159, ptr %l87, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/free:walker", ptr %t160, i32 0, i32 23
  %t163 = load i64, ptr %t162, !tbaa !24
  %t165 = icmp sgt i64 %t163, 0
  br i1 %t165, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb42
bb40:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erunsAgain(ptr %v0, ptr %t167)
  store i1 %t169, ptr %l93
  br label %bb41
bb41:
  %t170 = load i1, ptr %l93, !tbaa !21
  store i1 %t170, ptr %l91, !tbaa !21
  br label %bb42
bb42:
  %t171 = load i64, ptr %l75, !tbaa !24
  %t172 = load i64, ptr %l77, !tbaa !24
  %t173 = load i64, ptr %l81, !tbaa !24
  %t174 = load %"compiler/source:Span", ptr %l83
  %t175 = load %"compiler/source:Span", ptr %l84
  %t176 = load i64, ptr %l85, !tbaa !24
  %t177 = load %"compiler/source:Span", ptr %l86
  %t178 = load i64, ptr %l87, !tbaa !24
  %t179 = load i1, ptr %l91, !tbaa !21
  %t180 = call %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %s0, i64 %t171, i64 %t172, i64 %t173, %"compiler/source:Span" %t174, %"compiler/source:Span" %t175, i64 %t176, %"compiler/source:Span" %t177, i64 %t178, i1 %t179)
  store %"compiler/free:letGo" %t180, ptr %l94
  br label %bb43
bb43:
  %t181 = load ptr, ptr %l74, !tbaa !29
  %t182 = load %"compiler/free:letGo", ptr %l94
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2ePush_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t181, %"compiler/free:letGo" %t182)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 25
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t23 = load i1, ptr %l14, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 25
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t28, i64 %t32, i1 true)
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 30
  store i1 true, ptr %t37, !tbaa !21
  br label %bb7
bb7:
  br label %ret
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l21, !tbaa !29
  %t39 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l24
  %t44 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %a2)
  store %"compiler/source:Span" %t44, ptr %l26
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = load i64, ptr %l23, !tbaa !24
  %t49 = load %"compiler/source:Span", ptr %l24
  %t50 = load %"compiler/source:Span", ptr %l26
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t46, i64 %t47, i64 %t48, %"compiler/source:Span" %t49, %"compiler/source:Span" %t50, i64 %a3)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i64
  %l38 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t8 = sext i32 %t6 to i64
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t14)
  store ptr %t16, ptr %l11
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t17 = load i32, ptr %l1, !tbaa !23
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t18, i32 %t17)
  store i1 %t20, ptr %l13
  br label %bb4
bb4:
  %t21 = load i1, ptr %l13, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 5
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb7
bb7:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t30 = icmp sle i64 %t28, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t36, i64 0)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  br label %bb6
bb13:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 5
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = icmp eq i64 %t45, 0
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 5
  store ptr %t50, ptr %l28, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t52)
  store ptr %t54, ptr %l31
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t55 = load i32, ptr %l1, !tbaa !23
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t58 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t56, i32 %t55)
  store i1 %t58, ptr %l33
  br label %bb18
bb18:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  store i64 2, ptr %l34, !tbaa !24
  br label %bb21
bb20:
  store i64 1, ptr %l34, !tbaa !24
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61, i64 %t62)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/free:Free", ptr %t63, i32 0, i32 5
  %t66 = load i64, ptr %l3, !tbaa !24
  %t69 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  store i64 %t69, ptr %l38
  br label %bb24
bb24:
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = icmp eq i64 %t70, 2
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopUse(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i1
  %l63 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l80 = alloca { i64, ptr }
  %l83 = alloca i64
  %l87 = alloca i64
  %l89 = alloca i1
  %l93 = alloca i64
  %l97 = alloca i64
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l4, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l6, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l26, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l26, !tbaa !24
  store i64 %t33, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l8, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb49
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l4, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l9, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 14
  %t56 = load i64, ptr %l9, !tbaa !24
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l47
  br label %bb12
bb12:
  %t60 = load i64, ptr %l47, !tbaa !24
  store i64 %t60, ptr %l10, !tbaa !24
  %t61 = load i64, ptr %l10, !tbaa !24
  %t62 = load i64, ptr %l2, !tbaa !24
  %t65 = icmp slt i64 %t61, %t62
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load i64, ptr %l2, !tbaa !24
  store i64 %t67, ptr %l52, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 15
  %t71 = load i64, ptr %l9, !tbaa !24
  %t74 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t70, i64 %t71)
  store i64 %t74, ptr %l56
  br label %bb15
bb14:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb16
bb15:
  %t75 = load i64, ptr %l52, !tbaa !24
  %t76 = load i64, ptr %l56, !tbaa !24
  %t77 = icmp sle i64 %t75, %t76
  store i1 %t77, ptr %l51, !tbaa !21
  br label %bb16
bb16:
  %t79 = load i1, ptr %l51, !tbaa !21
  %t80 = xor i1 %t79, true
  br i1 %t80, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb20
bb18:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 20
  %t88 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t84, i64 %a1)
  store i64 %t88, ptr %l63
  br label %bb19
bb19:
  %t89 = load i64, ptr %l10, !tbaa !24
  %t90 = load i64, ptr %l63, !tbaa !24
  %t92 = icmp sgt i64 %t90, %t89
  store i1 %t92, ptr %l59, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l59, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb22:
  br label %bb23
bb23:
  store ptr %a3, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t97, i64 %t98)
  %t102 = extractvalue { i32, { i64, ptr } } %t101, 1
  %t103 = extractvalue { i32, { i64, ptr } } %t101, 0
  store i32 %t103, ptr %l71
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb26, label %ok.105
ok.105:
  store { i64, ptr } %t102, ptr %l70
  br label %bb25
bb25:
  %t106 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t106, ptr %l67, !tbaa !27
  br label %bb30
bb26:
  %t107 = load i32, ptr %l71, !tbaa !23
  %t108 = ashr i32 %t107, 16
  %t110 = icmp eq i32 %t108, 1
  br i1 %t110, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_44d31ac3b091972d_4fc8cc490260e559)
  unreachable
bb29:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb47
bb30:
  %t112 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t112, ptr %l13, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t117 = load i64, ptr %l15, !tbaa !24
  %t118 = load i64, ptr %l14, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb33:
  br label %bb34
bb34:
  %t125 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t125, ptr %l80, !tbaa !27
  %t126 = load i64, ptr %l15, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr i64, ptr %t129, i64 %t126
  %t131 = load i64, ptr %t130, !tbaa !34
  store i64 %t131, ptr %l16, !tbaa !24
  %t133 = load i64, ptr %l10, !tbaa !24
  store i64 %t133, ptr %l83, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 25
  %t137 = load i64, ptr %l16, !tbaa !24
  %t140 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l87
  br label %bb35
bb35:
  %t141 = load i64, ptr %l83, !tbaa !24
  %t142 = load i64, ptr %l87, !tbaa !24
  %t143 = icmp slt i64 %t141, %t142
  br i1 %t143, label %bb36, label %bb37
bb36:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:walker", ptr %t145, i32 0, i32 25
  %t148 = load i64, ptr %l16, !tbaa !24
  %t151 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t147, i64 %t148)
  store i64 %t151, ptr %l93
  br label %bb38
bb37:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb40
bb38:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/free:walker", ptr %t152, i32 0, i32 15
  %t155 = load i64, ptr %l9, !tbaa !24
  %t158 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t154, i64 %t155)
  store i64 %t158, ptr %l97
  br label %bb39
bb39:
  %t159 = load i64, ptr %l93, !tbaa !24
  %t160 = load i64, ptr %l97, !tbaa !24
  %t161 = icmp sle i64 %t159, %t160
  store i1 %t161, ptr %l89, !tbaa !21
  br label %bb40
bb40:
  %t163 = load i1, ptr %l89, !tbaa !21
  br i1 %t163, label %bb41, label %bb42
bb41:
  %t164 = load i64, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  store i64 %t164, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  %t166 = load i64, ptr %l15, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l15, !tbaa !24
  br label %bb31
bb45:
  %t170 = load i64, ptr %l12, !tbaa !24
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = add i64 %t170, %t171
  store i64 %t174, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb46:
  br label %bb24
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb48:
  %t176 = load i64, ptr %l8, !tbaa !24
  %t178 = add i64 %t176, 1
  store i64 %t178, ptr %l8, !tbaa !24
  br label %bb8
bb49:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca { i64, { i64, ptr } }
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i1
  %l43 = alloca ptr
  %l44 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca i64
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca i64
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l70 = alloca i1
  %l80 = alloca ptr
  %l81 = alloca i1
  %l98 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l109 = alloca i64
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l120 = alloca i64
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca { i64, { i64, ptr } }
  %l128 = alloca { i64, ptr }
  %l130 = alloca i64
  %l132 = alloca i64
  %l133 = alloca { i64, ptr }
  %l138 = alloca i1
  %l140 = alloca ptr
  %l144 = alloca i64
  %l147 = alloca i64
  %l150 = alloca i1
  %l154 = alloca ptr
  %l159 = alloca i1
  %l163 = alloca i64
  %l173 = alloca ptr
  %l175 = alloca %"compiler/source:Span"
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l179 = alloca i64
  %l184 = alloca i1
  %l187 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l190 = alloca i64
  %l192 = alloca i64
  %l193 = alloca { i64, ptr }
  %l197 = alloca i1
  %l202 = alloca i1
  %l205 = alloca { i64, ptr }
  %l206 = alloca { i64, ptr }
  %l208 = alloca i64
  %l210 = alloca i64
  %l211 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l224 = alloca %"compiler/free:store"
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l30
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l30, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  store i64 -1, ptr %l8, !tbaa !24
  store i64 -1, ptr %l9, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d69, i32 0, i32 1) }, ptr %l34, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t16, ptr %l35, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l36, !tbaa !24
  %t19 = load i64, ptr %l36, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l37, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l36, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t30, ptr %l10, !tbaa !27
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t32 = load ptr, ptr %l38, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb2, label %bb3
bb2:
  %t35 = load ptr, ptr %l38, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l39, !tbaa !21
  br label %bb3
bb3:
  %t39 = load i1, ptr %l39, !tbaa !21
  br i1 %t39, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  br label %bb98
bb7:
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t43 = load ptr, ptr %l43, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l43, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l44, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l44, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t51 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  br label %bb98
bb13:
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t54 = load ptr, ptr %l48, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l48, !tbaa !29
  %t58 = load i64, ptr %t57
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l49, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l49, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l11, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t69 = load ptr, ptr %l11, !tbaa !29
  %t72 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i64 %t72, ptr %l56
  br label %bb19
bb19:
  %t73 = load i64, ptr %l56, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t80 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  store i64 %t82, ptr %l8, !tbaa !24
  br label %bb25
bb21:
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d70, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t84, ptr %l63, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l65, !tbaa !24
  %t90 = load i64, ptr %l65, !tbaa !24
  %t91 = icmp eq i64 %t86, %t90
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t93 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l65, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  br label %bb24
bb23:
  %t99 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l67, !tbaa !24
  %t101 = load i64, ptr %l67, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l68, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l67, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t112, ptr %l10, !tbaa !27
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb98
bb26:
  %t113 = load ptr, ptr %l2, !tbaa !29
  store ptr %t113, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t114 = load ptr, ptr %l69, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l69, !tbaa !29
  %t118 = load i64, ptr %t117
  %t120 = icmp eq i64 %t118, 17
  store i1 %t120, ptr %l70, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l70, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l13, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l3
  %t132 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t128, i64 %t129, ptr %t130, %"compiler/source:Span" %t131, i1 %t132)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l80, !tbaa !29
  store i1 false, ptr %l81, !tbaa !21
  %t139 = load ptr, ptr %l80, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load ptr, ptr %l80, !tbaa !29
  %t143 = load i64, ptr %t142
  %t145 = icmp eq i64 %t143, 14
  store i1 %t145, ptr %l81, !tbaa !21
  br label %bb35
bb35:
  %t146 = load i1, ptr %l81, !tbaa !21
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l14, !tbaa !29
  br label %bb38
bb37:
  br label %bb58
bb38:
  %t153 = load ptr, ptr %l14, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Try", ptr %t153, i32 0, i32 0
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = icmp eq ptr %t156, null
  %t160 = xor i1 %t158, true
  store i1 %t160, ptr %l15, !tbaa !21
  %t162 = load ptr, ptr %l14, !tbaa !29
  %t164 = getelementptr %"compiler/typed:Try", ptr %t162, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t167 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 0
  store i64 %t169, ptr %l18, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t171 = load i64, ptr %l17, !tbaa !24
  %t172 = load i64, ptr %l18, !tbaa !24
  %t175 = icmp slt i64 %t171, %t172
  %t177 = xor i1 %t175, true
  br i1 %t177, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb41:
  br label %bb42
bb42:
  %t179 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t179, ptr %l98, !tbaa !27
  %t180 = load i64, ptr %l17, !tbaa !24
  %t182 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr ptr, ptr %t183, i64 %t180
  %t185 = load ptr, ptr %t184, !tbaa !39
  %t189 = getelementptr %"compiler/typed:Clause", ptr %t185, i32 0, i32 4
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb43, label %bb44
bb43:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb45
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb46
bb46:
  %t196 = load i64, ptr %l17, !tbaa !24
  %t198 = add i64 %t196, 1
  store i64 %t198, ptr %l17, !tbaa !24
  br label %bb39
bb47:
  %t200 = load i1, ptr %l15, !tbaa !21
  br i1 %t200, label %bb48, label %bb49
bb48:
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l108, !tbaa !29
  %t203 = load i64, ptr %l1, !tbaa !24
  store i64 %t203, ptr %l109, !tbaa !24
  %t204 = load ptr, ptr %l14, !tbaa !29
  %t206 = getelementptr %"compiler/typed:Try", ptr %t204, i32 0, i32 0
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = icmp eq ptr %t207, null
  br i1 %t209, label %bb50, label %bb51
bb49:
  br label %bb54
bb50:
  call void @__olang_check_failed(ptr @olang_loc_7676aaa4af173342_5bef0e3278c42ba6)
  unreachable
bb51:
  br label %bb52
bb52:
  %t211 = load ptr, ptr %l14, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Try", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load %"compiler/source:Span", ptr %l3
  %t216 = load i1, ptr %l4, !tbaa !21
  %t217 = load ptr, ptr %l108, !tbaa !29
  %t218 = load i64, ptr %l109, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t217, i64 %t218, ptr %t214, %"compiler/source:Span" %t215, i1 %t216)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb54:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l117, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t222, ptr %l118, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l120, !tbaa !24
  %t228 = load i64, ptr %l120, !tbaa !24
  %t229 = icmp eq i64 %t224, %t228
  br i1 %t229, label %bb55, label %bb56
bb55:
  %t231 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l120, !tbaa !24
  %t236 = mul i64 %t235, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %t234, i64 %t236, i1 false)
  br label %bb57
bb56:
  %t237 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  store i64 %t238, ptr %l122, !tbaa !24
  %t239 = load i64, ptr %l122, !tbaa !24
  %t240 = mul i64 %t239, 1
  %t241 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t240)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l123, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = load i64, ptr %l122, !tbaa !24
  %t249 = mul i64 %t248, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t245, ptr %t247, i64 %t249, i1 false)
  %t250 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t250, ptr %l10, !tbaa !27
  br label %bb57
bb57:
  br label %bb98
bb58:
  br i1 true, label %bb59, label %bb60
bb59:
  br label %bb61
bb60:
  br label %bb97
bb61:
  store %olang.scope zeroinitializer, ptr %s13
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t252 = load ptr, ptr %l2, !tbaa !29
  %t255 = call { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %s13, ptr %t251, ptr %t252)
  store { i64, { i64, ptr } } %t255, ptr %l126
  br label %bb62
bb62:
  %t256 = load { i64, { i64, ptr } }, ptr %l126
  store { i64, { i64, ptr } } %t256, ptr %l20
  %t257 = getelementptr { i64, { i64, ptr } }, ptr %l20, i32 0, i32 0
  %t258 = load i64, ptr %t257, !tbaa !24
  store i64 %t258, ptr %l9, !tbaa !24
  %t260 = getelementptr { i64, { i64, ptr } }, ptr %l20, i32 0, i32 1
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  store { i64, ptr } %t261, ptr %l128, !tbaa !27
  %t262 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 0
  %t264 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l130, !tbaa !24
  %t267 = load i64, ptr %l130, !tbaa !24
  %t268 = icmp eq i64 %t263, %t267
  br i1 %t268, label %bb63, label %bb64
bb63:
  %t270 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = load i64, ptr %l130, !tbaa !24
  %t275 = mul i64 %t274, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t271, ptr %t273, i64 %t275, i1 false)
  br label %bb65
bb64:
  %t276 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t277 = extractvalue { i64, ptr } %t276, 0
  store i64 %t277, ptr %l132, !tbaa !24
  %t278 = load i64, ptr %l132, !tbaa !24
  %t279 = mul i64 %t278, 1
  %t280 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t279)
  %t281 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  store { i64, ptr } %t282, ptr %l133, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = load i64, ptr %l132, !tbaa !24
  %t288 = mul i64 %t287, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t284, ptr %t286, i64 %t288, i1 false)
  %t289 = load { i64, ptr }, ptr %l133, !tbaa !27
  store { i64, ptr } %t289, ptr %l10, !tbaa !27
  br label %bb65
bb65:
  %t290 = load i64, ptr %l9, !tbaa !24
  %t292 = icmp sge i64 %t290, 0
  br i1 %t292, label %bb66, label %bb67
bb66:
  %t294 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t294, ptr %l7, !tbaa !24
  br label %bb96
bb67:
  store %olang.scope zeroinitializer, ptr %s15
  %t296 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t298 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s15, { i64, ptr } %t296, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d72, i32 0, i32 1) })
  store i1 %t298, ptr %l138
  br label %bb68
bb68:
  %t299 = load i1, ptr %l138, !tbaa !21
  br i1 %t299, label %bb69, label %bb70
bb69:
  %t300 = load ptr, ptr %l2, !tbaa !29
  %t302 = call ptr @compiler_2ffree_2ecallOf(ptr %v1, ptr %t300)
  store ptr %t302, ptr %l140
  br label %bb71
bb70:
  br label %bb95
bb71:
  %t303 = load ptr, ptr %l140, !tbaa !29
  store ptr %t303, ptr %l21, !tbaa !29
  %t304 = load ptr, ptr %l21, !tbaa !29
  %t306 = icmp eq ptr %t304, null
  %t308 = xor i1 %t306, true
  br i1 %t308, label %bb72, label %bb73
bb72:
  %t310 = load ptr, ptr %l5, !tbaa !29
  %t311 = load ptr, ptr %l21, !tbaa !29
  %t314 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %t310, ptr %t311)
  store i64 %t314, ptr %l147
  br label %bb74
bb73:
  store i64 -1, ptr %l144, !tbaa !24
  br label %bb75
bb74:
  %t315 = load i64, ptr %l147, !tbaa !24
  store i64 %t315, ptr %l144, !tbaa !24
  br label %bb75
bb75:
  %t316 = load i64, ptr %l144, !tbaa !24
  store i64 %t316, ptr %l22, !tbaa !24
  %t317 = load i64, ptr %l22, !tbaa !24
  %t319 = icmp sge i64 %t317, 0
  br i1 %t319, label %bb76, label %bb77
bb76:
  %t321 = load ptr, ptr %l5, !tbaa !29
  %t323 = getelementptr %"compiler/free:Free", ptr %t321, i32 0, i32 1
  %t324 = load i64, ptr %l22, !tbaa !24
  %t327 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t323, i64 %t324)
  store ptr %t327, ptr %l154
  br label %bb78
bb77:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb79
bb78:
  %t328 = load ptr, ptr %l154, !tbaa !29
  %t330 = getelementptr %"compiler/typed:Body", ptr %t328, i32 0, i32 11
  %t331 = load ptr, ptr %t330, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  %t335 = xor i1 %t333, true
  store i1 %t335, ptr %l150, !tbaa !21
  br label %bb79
bb79:
  %t337 = load i1, ptr %l150, !tbaa !21
  br i1 %t337, label %bb80, label %bb81
bb80:
  %t338 = load ptr, ptr %l5, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 26
  %t341 = load i64, ptr %l22, !tbaa !24
  %t344 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t340, i64 %t341)
  store i64 %t344, ptr %l163
  br label %bb82
bb81:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb83
bb82:
  %t345 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t346 = load i64, ptr %l1, !tbaa !24
  %t349 = add i64 %t345, %t346
  %t350 = load i64, ptr %l163, !tbaa !24
  %t352 = icmp eq i64 %t350, %t349
  store i1 %t352, ptr %l159, !tbaa !21
  br label %bb83
bb83:
  %t354 = load i1, ptr %l159, !tbaa !21
  br i1 %t354, label %bb84, label %bb85
bb84:
  %t355 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t355, ptr %l7, !tbaa !24
  %t357 = load i64, ptr %l1, !tbaa !24
  store i64 %t357, ptr %l8, !tbaa !24
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t359 = load i64, ptr %l7, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t363 = icmp eq i64 %t359, %t360
  br i1 %t363, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s18
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l173, !tbaa !29
  %t366 = load ptr, ptr %l2, !tbaa !29
  %t368 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t366)
  store %"compiler/source:Span" %t368, ptr %l175
  br label %bb89
bb88:
  br label %bb94
bb89:
  %t369 = load ptr, ptr %l173, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l175
  %t371 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s18, ptr %t369, %"compiler/source:Span" %t370)
  store { i64, ptr } %t371, ptr %l176
  br label %bb90
bb90:
  %t372 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t373 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t374 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = extractvalue { i64, ptr } %t374, 0
  %t377 = add i64 %t373, %t376
  %t378 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t381 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t380)
  call void @olang_textcopy(ptr %t381, ptr %t372, i64 %t373)
  %t382 = getelementptr i8, ptr %t381, i64 %t373
  call void @olang_textcopy(ptr %t382, ptr %t375, i64 %t376)
  %t383 = getelementptr i8, ptr %t382, i64 %t376
  call void @olang_textcopy(ptr %t383, ptr %t378, i64 %t379)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t381, 1
  store { i64, ptr } %t385, ptr %l177, !tbaa !27
  %t386 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t387 = extractvalue { i64, ptr } %t386, 0
  %t388 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t388, 0
  store i64 %t389, ptr %l179, !tbaa !24
  %t391 = load i64, ptr %l179, !tbaa !24
  %t392 = icmp eq i64 %t387, %t391
  br i1 %t392, label %bb91, label %bb92
bb91:
  %t394 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !27
  %t396 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t397 = load ptr, ptr %t396, !tbaa !27
  %t398 = load i64, ptr %l179, !tbaa !24
  %t399 = mul i64 %t398, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t395, ptr %t397, i64 %t399, i1 false)
  br label %bb93
bb92:
  %t400 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t400, ptr %l10, !tbaa !27
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s18)
  br label %bb94
bb94:
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s15)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s13)
  br label %bb98
bb97:
  call void @__olang_check_failed(ptr @olang_loc_1665755e987b0d60_2375c09fda7e834)
  unreachable
bb98:
  %t401 = load i64, ptr %l7, !tbaa !24
  %t402 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t405 = icmp eq i64 %t401, %t402
  br i1 %t405, label %bb99, label %bb100
bb99:
  %t407 = load i1, ptr %l4, !tbaa !21
  store i1 %t407, ptr %l184, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l184, !tbaa !21
  br label %bb101
bb101:
  %t409 = load i1, ptr %l184, !tbaa !21
  br i1 %t409, label %bb102, label %bb103
bb102:
  %t410 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t410, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d75, i32 0, i32 1) }, ptr %l187, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l187, !tbaa !27
  store { i64, ptr } %t412, ptr %l188, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t413, 0
  %t415 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t415, 0
  store i64 %t416, ptr %l190, !tbaa !24
  %t418 = load i64, ptr %l190, !tbaa !24
  %t419 = icmp eq i64 %t414, %t418
  br i1 %t419, label %bb104, label %bb105
bb103:
  br label %bb107
bb104:
  %t421 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = load i64, ptr %l190, !tbaa !24
  %t426 = mul i64 %t425, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t422, ptr %t424, i64 %t426, i1 false)
  br label %bb106
bb105:
  %t427 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t427, 0
  store i64 %t428, ptr %l192, !tbaa !24
  %t429 = load i64, ptr %l192, !tbaa !24
  %t430 = mul i64 %t429, 1
  %t431 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t430)
  %t432 = insertvalue { i64, ptr } undef, i64 %t429, 0
  %t433 = insertvalue { i64, ptr } %t432, ptr %t431, 1
  store { i64, ptr } %t433, ptr %l193, !tbaa !27
  %t434 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t437 = load ptr, ptr %t436, !tbaa !27
  %t438 = load i64, ptr %l192, !tbaa !24
  %t439 = mul i64 %t438, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t435, ptr %t437, i64 %t439, i1 false)
  %t440 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t440, ptr %l10, !tbaa !27
  br label %bb106
bb106:
  br label %bb107
bb107:
  %t441 = load i64, ptr %l7, !tbaa !24
  %t442 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t445 = icmp eq i64 %t441, %t442
  br i1 %t445, label %bb108, label %bb109
bb108:
  %t447 = load ptr, ptr %l5, !tbaa !29
  %t449 = getelementptr %"compiler/free:Free", ptr %t447, i32 0, i32 17
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/free:walker", ptr %t450, i32 0, i32 1
  %t453 = load i64, ptr %t452, !tbaa !24
  %t456 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t449, i64 %t453)
  store i1 %t456, ptr %l202
  br label %bb110
bb109:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb111
bb110:
  %t457 = load i1, ptr %l202, !tbaa !21
  %t458 = xor i1 %t457, true
  store i1 %t458, ptr %l197, !tbaa !21
  br label %bb111
bb111:
  %t460 = load i1, ptr %l197, !tbaa !21
  br i1 %t460, label %bb112, label %bb113
bb112:
  %t461 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t461, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l205, !tbaa !27
  %t463 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t463, ptr %l206, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  %t466 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t467 = extractvalue { i64, ptr } %t466, 0
  store i64 %t467, ptr %l208, !tbaa !24
  %t469 = load i64, ptr %l208, !tbaa !24
  %t470 = icmp eq i64 %t465, %t469
  br i1 %t470, label %bb114, label %bb115
bb113:
  br label %bb117
bb114:
  %t472 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !27
  %t474 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = load i64, ptr %l208, !tbaa !24
  %t477 = mul i64 %t476, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t473, ptr %t475, i64 %t477, i1 false)
  br label %bb116
bb115:
  %t478 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t479 = extractvalue { i64, ptr } %t478, 0
  store i64 %t479, ptr %l210, !tbaa !24
  %t480 = load i64, ptr %l210, !tbaa !24
  %t481 = mul i64 %t480, 1
  %t482 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t481)
  %t483 = insertvalue { i64, ptr } undef, i64 %t480, 0
  %t484 = insertvalue { i64, ptr } %t483, ptr %t482, 1
  store { i64, ptr } %t484, ptr %l211, !tbaa !27
  %t485 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t488 = load ptr, ptr %t487, !tbaa !27
  %t489 = load i64, ptr %l210, !tbaa !24
  %t490 = mul i64 %t489, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t486, ptr %t488, i64 %t490, i1 false)
  %t491 = load { i64, ptr }, ptr %l211, !tbaa !27
  store { i64, ptr } %t491, ptr %l10, !tbaa !27
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t492 = load ptr, ptr %l5, !tbaa !29
  %t494 = getelementptr %"compiler/free:Free", ptr %t492, i32 0, i32 34
  store ptr %t494, ptr %l213, !tbaa !29
  %t495 = load i64, ptr %l1, !tbaa !24
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/free:walker", ptr %t496, i32 0, i32 1
  %t499 = load i64, ptr %t498, !tbaa !24
  %t500 = load i64, ptr %l6, !tbaa !24
  %t501 = load %"compiler/source:Span", ptr %l3
  %t502 = load i64, ptr %l7, !tbaa !24
  %t503 = load i64, ptr %l8, !tbaa !24
  %t504 = load i64, ptr %l9, !tbaa !24
  %t505 = load ptr, ptr %l2, !tbaa !29
  %t515 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t495, i64 %t499, i64 %t500, %"compiler/source:Span" %t501, i64 %t502, i64 %t503, i64 %t504, ptr %t505, ptr null)
  store %"compiler/free:store" %t515, ptr %l224
  br label %bb118
bb118:
  %t516 = load ptr, ptr %l213, !tbaa !29
  %t517 = load %"compiler/free:store", ptr %l224
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t516, %"compiler/free:store" %t517)
  br label %bb119
bb119:
  %t518 = load i64, ptr %l7, !tbaa !24
  %t519 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t522 = icmp eq i64 %t518, %t519
  br i1 %t522, label %bb120, label %bb121
bb120:
  %t524 = load i64, ptr %l6, !tbaa !24
  store i64 %t524, ptr %l23, !tbaa !24
  %t526 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t526, ptr %l24
  %t528 = load ptr, ptr %l5, !tbaa !29
  %t530 = getelementptr %"compiler/free:Free", ptr %t528, i32 0, i32 42
  %t531 = load i64, ptr %t530, !tbaa !24
  %t533 = icmp sge i64 %t531, 0
  br i1 %t533, label %bb122, label %bb123
bb121:
  br label %bb126
bb122:
  %t535 = load ptr, ptr %l5, !tbaa !29
  %t537 = getelementptr %"compiler/free:Free", ptr %t535, i32 0, i32 43
  %t538 = load i64, ptr %t537, !tbaa !24
  %t540 = load ptr, ptr %l5, !tbaa !29
  %t542 = getelementptr %"compiler/free:Free", ptr %t540, i32 0, i32 44
  %t543 = load %"compiler/source:Span", ptr %t542
  store i64 %t538, ptr %l23, !tbaa !24
  store %"compiler/source:Span" %t543, ptr %l24
  %t549 = load ptr, ptr %l5, !tbaa !29
  %t551 = getelementptr %"compiler/free:Free", ptr %t549, i32 0, i32 42
  store i64 -1, ptr %t551, !tbaa !24
  br label %bb124
bb123:
  br label %bb124
bb124:
  %t552 = load ptr, ptr %l5, !tbaa !29
  %t553 = load i64, ptr %l1, !tbaa !24
  %t554 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t555 = load i64, ptr %l23, !tbaa !24
  %t556 = load %"compiler/source:Span", ptr %l24
  %t557 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s0, ptr %t552, i64 %t553, i64 %t554, i64 %t555, %"compiler/source:Span" %t556, { i64, ptr } %t557)
  br label %bb125
bb125:
  br label %bb126
bb126:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca i64
  %l61 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l141 = alloca i1
  %l145 = alloca i64
  %l151 = alloca i64
  %l155 = alloca i1
  %l159 = alloca i1
  %l161 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l171 = alloca i1
  %l172 = alloca i1
  %l179 = alloca i1
  %l184 = alloca ptr
  %l186 = alloca i1
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 43
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l29
  br label %bb1
bb1:
  %t11 = load i64, ptr %l29, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l36, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l36, !tbaa !24
  store i64 %t38, ptr %l33, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l33, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 43
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l57
  br label %bb12
bb12:
  %t65 = load i64, ptr %l57, !tbaa !24
  store i64 %t65, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 45
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l61
  br label %bb13
bb13:
  %t73 = load i64, ptr %l61, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 22
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l65
  br label %bb14
bb14:
  %t81 = load i1, ptr %l65, !tbaa !21
  store i1 %t81, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 14
  %t86 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l68
  br label %bb15
bb15:
  %t87 = load i64, ptr %l68, !tbaa !24
  store i64 %t87, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb16, label %bb17
bb16:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb18:
  %t98 = load i64, ptr %l13, !tbaa !24
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l14, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l14, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l75, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb20
bb20:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t115 = load i64, ptr %l72, !tbaa !24
  store i64 %t115, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t116 = load i64, ptr %l16, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l16, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l17, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 14
  %t137 = load i64, ptr %l17, !tbaa !24
  %t140 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l96
  br label %bb26
bb26:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l96, !tbaa !24
  %t144 = icmp slt i64 %t142, %t141
  br i1 %t144, label %bb27, label %bb28
bb27:
  %t146 = load i64, ptr %l9, !tbaa !24
  store i64 %t146, ptr %l100, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:walker", ptr %t147, i32 0, i32 15
  %t150 = load i64, ptr %l17, !tbaa !24
  %t153 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l104
  br label %bb29
bb28:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb30
bb29:
  %t154 = load i64, ptr %l100, !tbaa !24
  %t155 = load i64, ptr %l104, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  store i1 %t156, ptr %l99, !tbaa !21
  br label %bb30
bb30:
  %t158 = load i1, ptr %l99, !tbaa !21
  br i1 %t158, label %bb31, label %bb32
bb31:
  %t159 = load i1, ptr %l11, !tbaa !21
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l106, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t163 = load i1, ptr %l106, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb37:
  %t164 = load i64, ptr %l16, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l16, !tbaa !24
  br label %bb22
bb38:
  store i64 0, ptr %l18, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:walker", ptr %t168, i32 0, i32 43
  %t172 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l113
  br label %bb39
bb39:
  %t173 = load i64, ptr %l113, !tbaa !24
  store i64 %t173, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l18, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t180 = load i64, ptr %l20, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb45
bb42:
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l20, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l20, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l120, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb44
bb44:
  %t200 = load i64, ptr %l120, !tbaa !24
  store i64 %t200, ptr %l117, !tbaa !24
  br label %bb45
bb45:
  %t201 = load i64, ptr %l117, !tbaa !24
  store i64 %t201, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s8
  %t202 = load i64, ptr %l22, !tbaa !24
  %t203 = load i64, ptr %l21, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s8)
  br label %bb80
bb48:
  br label %bb49
bb49:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l22, !tbaa !24
  %t212 = load i64, ptr %l20, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l23, !tbaa !24
  %t220 = load i64, ptr %l23, !tbaa !24
  %t221 = load i64, ptr %l7, !tbaa !24
  %t224 = icmp eq i64 %t220, %t221
  br i1 %t224, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb53
bb51:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 43
  %t229 = load i64, ptr %l23, !tbaa !24
  %t232 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l145
  br label %bb52
bb52:
  %t233 = load i64, ptr %l8, !tbaa !24
  %t234 = load i64, ptr %l145, !tbaa !24
  %t236 = icmp ne i64 %t234, %t233
  store i1 %t236, ptr %l141, !tbaa !21
  br label %bb53
bb53:
  %t238 = load i1, ptr %l141, !tbaa !21
  br i1 %t238, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s8)
  br label %bb79
bb55:
  br label %bb56
bb56:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:walker", ptr %t239, i32 0, i32 45
  %t242 = load i64, ptr %l23, !tbaa !24
  %t245 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l151
  br label %bb57
bb57:
  %t246 = load i64, ptr %l151, !tbaa !24
  store i64 %t246, ptr %l24, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l9, !tbaa !24
  %t249 = load i64, ptr %l24, !tbaa !24
  %t253 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %t247, i64 %t248, i64 %t249)
  store i1 %t253, ptr %l155
  br label %bb58
bb58:
  %t254 = load i1, ptr %l155, !tbaa !21
  br i1 %t254, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s8)
  br label %bb79
bb60:
  br label %bb61
bb61:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l9, !tbaa !24
  %t257 = load i64, ptr %l24, !tbaa !24
  %t261 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %t255, i64 %t256, i64 %t257)
  store i1 %t261, ptr %l159
  br label %bb62
bb62:
  %t262 = load i1, ptr %l159, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb63, label %bb64
bb63:
  %t265 = load i1, ptr %l11, !tbaa !21
  br i1 %t265, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb75
bb65:
  %t267 = load i64, ptr %l24, !tbaa !24
  %t268 = load i64, ptr %l9, !tbaa !24
  %t271 = icmp sgt i64 %t267, %t268
  store i1 %t271, ptr %l163, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb67
bb67:
  %t273 = load i1, ptr %l163, !tbaa !21
  br i1 %t273, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb74
bb69:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/free:walker", ptr %t274, i32 0, i32 22
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t276, i64 %t277)
  store i1 %t280, ptr %l171
  br label %bb70
bb70:
  %t281 = load i1, ptr %l171, !tbaa !21
  br i1 %t281, label %bb71, label %bb72
bb71:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t283 = load i64, ptr %l24, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  store i1 %t286, ptr %l172, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb73
bb73:
  %t288 = load i1, ptr %l172, !tbaa !21
  store i1 %t288, ptr %l167, !tbaa !21
  br label %bb74
bb74:
  %t289 = load i1, ptr %l167, !tbaa !21
  store i1 %t289, ptr %l161, !tbaa !21
  br label %bb75
bb75:
  %t290 = load i1, ptr %l161, !tbaa !21
  br i1 %t290, label %bb76, label %bb77
bb76:
  call void @__olang_scope_close(ptr %s8)
  br label %bb79
bb77:
  br label %bb78
bb78:
  store i1 true, ptr %l10, !tbaa !21
  call void @__olang_scope_close(ptr %s8)
  br label %bb79
bb79:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l22, !tbaa !24
  br label %bb46
bb80:
  %t295 = load i1, ptr %l10, !tbaa !21
  br i1 %t295, label %bb81, label %bb82
bb81:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr %"compiler/free:Free", ptr %t297, i32 0, i32 23
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:walker", ptr %t300, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  %t306 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t299, i64 %t303)
  store ptr %t306, ptr %l184
  br label %bb83
bb82:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb85
bb83:
  %t307 = load i64, ptr %l8, !tbaa !24
  %t308 = load ptr, ptr %l184, !tbaa !29
  %t310 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t308, i64 %t307)
  store i1 %t310, ptr %l186
  br label %bb84
bb84:
  %t311 = load i1, ptr %l186, !tbaa !21
  store i1 %t311, ptr %l179, !tbaa !21
  br label %bb85
bb85:
  %t312 = load i1, ptr %l179, !tbaa !21
  br i1 %t312, label %bb86, label %bb87
bb86:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr %"compiler/free:Free", ptr %t313, i32 0, i32 30
  store i1 true, ptr %t315, !tbaa !21
  br label %bb88
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb89:
  %t316 = load i64, ptr %l6, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l6, !tbaa !24
  br label %bb8
bb90:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t41)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l23
  br label %bb13
bb13:
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t45, ptr %lp4
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  %t47 = load ptr, ptr %lp4
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %t47
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t48, ptr %t52)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %lp4
  %t57 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t56
  call void @__olang_scope_close(ptr %s2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t63 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t59, ptr %t60)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l31
  br label %bb19
bb19:
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_71c754545de4040c_468b95bb5168a5f8)
  unreachable
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l16, !tbaa !24
  store i64 %t33, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l13, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t51, i1 false)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb8
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 11
  store i64 0, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 12
  store i64 0, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:walker", ptr %t69, i32 0, i32 13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t71)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 14
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t75)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 22
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t79)
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t83)
  br label %bb18
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 16
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t87)
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %t89, i32 0, i32 17
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t91)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 18
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t95)
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/free:walker", ptr %t97, i32 0, i32 19
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t99)
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t103)
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t107)
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:walker", ptr %t109, i32 0, i32 26
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t111)
  br label %bb25
bb25:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t113, i32 0, i32 27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t115)
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t119)
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t123)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 36
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t127)
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t131)
  br label %bb30
bb30:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 38
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t135)
  br label %bb31
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 39
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t139)
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:walker", ptr %t141, i32 0, i32 40
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t143)
  br label %bb33
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:walker", ptr %t145, i32 0, i32 41
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t147)
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 42
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t151)
  br label %bb35
bb35:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/free:walker", ptr %t153, i32 0, i32 43
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t155)
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:walker", ptr %t157, i32 0, i32 44
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t159)
  br label %bb37
bb37:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:walker", ptr %t161, i32 0, i32 45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t163)
  br label %bb38
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:walker", ptr %t165, i32 0, i32 46
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t167)
  br label %bb39
bb39:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 47
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t171)
  br label %bb40
bb40:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/free:walker", ptr %t173, i32 0, i32 48
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t175)
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 49
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t179)
  br label %bb42
bb42:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 50
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t183)
  br label %bb43
bb43:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t185, i32 0, i32 51
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t187)
  br label %bb44
bb44:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/free:walker", ptr %t189, i32 0, i32 52
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t191)
  br label %bb45
bb45:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/free:walker", ptr %t193, i32 0, i32 53
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t195)
  br label %bb46
bb46:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/free:walker", ptr %t197, i32 0, i32 54
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t199)
  br label %bb47
bb47:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/free:walker", ptr %t201, i32 0, i32 55
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t203)
  br label %bb48
bb48:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/free:walker", ptr %t205, i32 0, i32 56
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t207)
  br label %bb49
bb49:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/free:walker", ptr %t209, i32 0, i32 57
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t211)
  br label %bb50
bb50:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca i64
  %l32 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t9 = load i64, ptr %l4, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l16
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l15
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  br label %bb7
bb3:
  %t18 = load i32, ptr %l16, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3495f832c6af5d35_e0a5ccc226d89761)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb7:
  %t23 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l7, !tbaa !24
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb10:
  br label %bb11
bb11:
  %t36 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t36, ptr %l25, !tbaa !27
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i64, ptr %t40, i64 %t37
  %t42 = load i64, ptr %t41, !tbaa !34
  store i64 %t42, ptr %l8, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t46 = call i64 @compiler_2ffree_2eokind(i64 %t44)
  store i64 %t46, ptr %l29
  br label %bb12
bb12:
  %t47 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t48 = load i64, ptr %l29, !tbaa !24
  %t50 = icmp eq i64 %t48, %t47
  br i1 %t50, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb21
bb14:
  %t52 = load i64, ptr %l8, !tbaa !24
  %t54 = call i64 @compiler_2ffree_2eokind(i64 %t52)
  store i64 %t54, ptr %l34
  br label %bb15
bb15:
  %t55 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t56 = load i64, ptr %l34, !tbaa !24
  %t58 = icmp eq i64 %t56, %t55
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l38, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = call i64 @compiler_2ffree_2eoval(i64 %t61)
  store i64 %t63, ptr %l40
  br label %bb18
bb17:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb20
bb18:
  %t64 = load ptr, ptr %l38, !tbaa !29
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t64, i64 %t65)
  store i1 %t66, ptr %l41
  br label %bb19
bb19:
  %t67 = load i1, ptr %l41, !tbaa !21
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l37, !tbaa !21
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb21
bb21:
  %t69 = load i1, ptr %l32, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb23:
  br label %bb24
bb24:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 20
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 1
  %t76 = load i64, ptr %t75, !tbaa !24
  %t79 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t72, i64 %t76)
  store ptr %t79, ptr %l46
  br label %bb25
bb25:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t83 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t81, i64 %t80)
  store i1 %t83, ptr %l48
  br label %bb26
bb26:
  %t84 = load i1, ptr %l48, !tbaa !21
  br i1 %t84, label %bb27, label %bb28
bb27:
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 30
  store i1 true, ptr %t87, !tbaa !21
  br label %bb29
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb8
bb31:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = add i64 %t92, %t93
  store i64 %t96, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb32:
  br label %bb1
bb33:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb26
bb6:
  %t26 = load ptr, ptr %l4, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l22
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l26
  br label %bb15
bb14:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb16
bb15:
  %t46 = load i1, ptr %l26, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_311feee871305b59_d38294057dde4ced)
  unreachable
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb28
bb28:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb29, label %bb30
bb29:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %t69)
  store ptr %t71, ptr %l38
  br label %bb32
bb32:
  %t72 = load ptr, ptr %l38, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store ptr null, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_421add8d063ee188_aab923ea260c413c)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i64
  %l77 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t11)
  store i32 %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l15
  br label %bb3
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %l18, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i32, ptr %l20, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l21, !tbaa !21
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb46
bb16:
  %t47 = load ptr, ptr %l5, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = load i64, ptr %t51
  %t54 = icmp eq i64 %t52, 0
  store i1 %t54, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l31, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t58, i32 0, i32 2
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l6, !tbaa !23
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t62 = load i32, ptr %l6, !tbaa !23
  %t64 = sext i32 %t62 to i64
  store i64 %t64, ptr %l37, !tbaa !24
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 45
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l42
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t75)
  store i64 %t76, ptr %l43
  br label %bb23
bb23:
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load i64, ptr %l43, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 45
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:walker", ptr %t84, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t90 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t83, i64 %t87)
  store ptr %t90, ptr %l50
  br label %bb26
bb25:
  %t91 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t91, ptr %l45, !tbaa !24
  br label %bb28
bb26:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i32, ptr %l6, !tbaa !23
  %t96 = sext i32 %t94 to i64
  %t99 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t96)
  store i64 %t99, ptr %l54
  br label %bb27
bb27:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l45, !tbaa !24
  br label %bb28
bb28:
  %t101 = load i64, ptr %l45, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb45
bb29:
  %t102 = load ptr, ptr %l5, !tbaa !29
  store ptr %t102, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t103 = load ptr, ptr %l56, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l56, !tbaa !29
  %t107 = load i64, ptr %t106
  %t109 = icmp eq i64 %t107, 3
  store i1 %t109, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l57, !tbaa !21
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb40
bb34:
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = call i1 @compiler_2ffree_2epureBase(ptr %v1, ptr %t117)
  store i1 %t119, ptr %l63
  br label %bb35
bb35:
  %t120 = load i1, ptr %l63, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb36, label %bb37
bb36:
  store i64 -1, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t128 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i64 %t128, ptr %l68
  br label %bb39
bb39:
  %t129 = load i64, ptr %l68, !tbaa !24
  store i64 %t129, ptr %l4, !tbaa !24
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i64 -1, ptr %rv
  br label %ret
bb44:
  call void @__olang_check_failed(ptr @olang_loc_34bfc259355dec67_8a2d14d061fee643)
  unreachable
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_806a74b5c91de186_4e306eb4964e9ec2)
  unreachable
bb51:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb52, label %bb53
bb52:
  store i64 -1, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t137 = load i64, ptr %l4, !tbaa !24
  %t138 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t141 = icmp sge i64 %t137, %t138
  br i1 %t141, label %bb55, label %bb56
bb55:
  %t143 = load i64, ptr %l4, !tbaa !24
  %t144 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t147 = sub i64 %t143, %t144
  store i64 %t147, ptr %l77, !tbaa !24
  br label %bb57
bb56:
  %t149 = load i64, ptr %l4, !tbaa !24
  store i64 %t149, ptr %l77, !tbaa !24
  br label %bb57
bb57:
  %t151 = load i64, ptr %l77, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erunsAgain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca { i64, ptr }
  %l17 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t7, ptr %l1
  %t9 = load { i64, [2 x i64] }, ptr %l1
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 6
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 5
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb14
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/free:walker", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 1
  %t26 = load i64, ptr %t25, !tbaa !24
  %t29 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s2, ptr %t22, i64 %t26)
  store { i64, ptr } %t29, ptr %l15
  br label %bb11
bb11:
  %t30 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  %t32 = extractvalue { i64, ptr } %t30, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t38 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t36, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t38, ptr %l17
  br label %bb12
bb12:
  %t39 = load i1, ptr %l17, !tbaa !21
  %t40 = xor i1 %t39, true
  store i1 %t40, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_350c73b6578d6328_239abab62451b64c)
  unreachable
bb14:
  %t42 = load i1, ptr %l6, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l17 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l42 = alloca { i64, ptr }
  %l46 = alloca i64
  %l49 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca i1
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 8
  %t8 = load i32, ptr %t7, !tbaa !23
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t4, i32 %t8, i64 %a1)
  store i64 %t13, ptr %l17
  br label %bb1
bb1:
  %t14 = load i64, ptr %l17, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %s1, ptr %t19, i64 %t20, ptr %a2, ptr %t22, %"compiler/source:Span" %a4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d78, i32 0, i32 1) }, i1 false)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb32
bb8:
  store %olang.scope zeroinitializer, ptr %s4
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t39 = load i64, ptr %l7, !tbaa !24
  %t42 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v2, ptr %t38, i64 %t39)
  %t43 = extractvalue { i32, { i64, ptr } } %t42, 1
  %t44 = extractvalue { i32, { i64, ptr } } %t42, 0
  store i32 %t44, ptr %l33
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb10, label %ok.46
ok.46:
  store { i64, ptr } %t43, ptr %l32
  br label %bb9
bb9:
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  br label %bb14
bb10:
  %t48 = load i32, ptr %l33, !tbaa !23
  %t49 = ashr i32 %t48, 16
  %t51 = icmp eq i32 %t49, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_2a94798a60b7293_3a863c891acd45e7)
  unreachable
bb13:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb14:
  %t53 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t53, ptr %l8, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t58 = load i64, ptr %l10, !tbaa !24
  %t59 = load i64, ptr %l9, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb17:
  br label %bb18
bb18:
  %t66 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t66, ptr %l42, !tbaa !27
  %t67 = load i64, ptr %l10, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr i64, ptr %t70, i64 %t67
  %t72 = load i64, ptr %t71, !tbaa !34
  store i64 %t72, ptr %l11, !tbaa !24
  %t74 = load i64, ptr %l11, !tbaa !24
  %t76 = call i64 @compiler_2ffree_2eokind(i64 %t74)
  store i64 %t76, ptr %l46
  br label %bb19
bb19:
  %t77 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t78 = load i64, ptr %l46, !tbaa !24
  %t80 = icmp ne i64 %t78, %t77
  br i1 %t80, label %bb20, label %bb21
bb20:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 0
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/free:Free", ptr %t85, i32 0, i32 20
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/free:walker", ptr %t88, i32 0, i32 1
  %t91 = load i64, ptr %t90, !tbaa !24
  %t94 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t87, i64 %t91)
  store ptr %t94, ptr %l55
  br label %bb22
bb21:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb24
bb22:
  %t95 = load i64, ptr %l11, !tbaa !24
  %t96 = load ptr, ptr %l55, !tbaa !29
  %t98 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t96, i64 %t95)
  store i1 %t98, ptr %l57
  br label %bb23
bb23:
  %t99 = load i1, ptr %l57, !tbaa !21
  store i1 %t99, ptr %l49, !tbaa !21
  br label %bb24
bb24:
  %t100 = load i1, ptr %l49, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = getelementptr %"compiler/free:Free", ptr %t104, i32 0, i32 30
  store i1 true, ptr %t106, !tbaa !21
  br label %bb27
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l10, !tbaa !24
  br label %bb15
bb29:
  %t111 = load i64, ptr %l7, !tbaa !24
  %t112 = load i64, ptr %l9, !tbaa !24
  %t115 = add i64 %t111, %t112
  store i64 %t115, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  br label %bb8
bb31:
  br label %bb32
bb32:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t2, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s0, ptr %t10, ptr %t11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l11
  br label %bb1
bb1:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l5
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 29
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = sub i64 %t19, 1
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 29
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t25, i64 %a1, ptr %t27, ptr %l5, %"compiler/source:Span" %a3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) }, i1 %a4, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l17 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 24
  %t11 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t10, i64 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 12
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t16, i64 %t20)
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 26
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t25, %"compiler/source:Span" %a2)
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 51
  store ptr %t31, ptr %l17, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 52
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t34)
  store i64 %t36, ptr %l20
  br label %bb7
bb7:
  %t37 = load i64, ptr %l20, !tbaa !24
  %t38 = icmp sgt i64 %t37, 0
  br i1 %t38, label %bb8, label %bb9
bb8:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:walker", ptr %t40, i32 0, i32 52
  store ptr %t42, ptr %l24, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:walker", ptr %t43, i32 0, i32 52
  %t47 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l27
  br label %bb10
bb9:
  store i64 -1, ptr %l22, !tbaa !24
  br label %bb12
bb10:
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = sub i64 %t48, 1
  %t50 = load ptr, ptr %l24, !tbaa !29
  %t52 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t50, i64 %t49)
  store i64 %t52, ptr %l29
  br label %bb11
bb11:
  %t53 = load i64, ptr %l29, !tbaa !24
  store i64 %t53, ptr %l22, !tbaa !24
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l17, !tbaa !29
  %t55 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t54, i64 %t55)
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:walker", ptr %t56, i32 0, i32 28
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = icmp sgt i64 %t59, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 27
  %t66 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2ffree_2ecompiler_2ffree_3awalker_2euseSpAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l38 = alloca i64
  %l44 = alloca %"compiler/source:Span"
  %l48 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 25
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l4, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l7, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 25
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t55, i64 %t56)
  store i64 %t59, ptr %l38
  br label %bb12
bb12:
  %t61 = load i64, ptr %l38, !tbaa !24
  %t63 = icmp eq i64 %t61, %a1
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:walker", ptr %t65, i32 0, i32 26
  %t68 = load i64, ptr %l7, !tbaa !24
  %t71 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t67, i64 %t68)
  store %"compiler/source:Span" %t71, ptr %l44
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t72 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t72, ptr %rv
  br label %ret
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t73 = load i64, ptr %l6, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l6, !tbaa !24
  br label %bb8
bb18:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t77)
  store ptr %t79, ptr %l48
  br label %bb19
bb19:
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t82 = getelementptr %"compiler/typed:Body", ptr %t80, i32 0, i32 4
  %t83 = load %"compiler/source:Span", ptr %t82
  store %"compiler/source:Span" %t83, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i1
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca i1
  %l43 = alloca ptr
  %l45 = alloca i64
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i64, ptr %l3, !tbaa !24
  %t22 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, { i64, ptr } } %t22, 1
  %t24 = extractvalue { i32, { i64, ptr } } %t22, 0
  store i32 %t24, ptr %l21
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb9, label %ok.26
ok.26:
  store { i64, ptr } %t23, ptr %l20
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  br label %bb13
bb9:
  %t28 = load i32, ptr %l21, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_7309f54021366b21_bf19c41763566c5)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb13:
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t33, ptr %l4, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load i64, ptr %l5, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb16:
  br label %bb17
bb17:
  %t46 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t46, ptr %l30, !tbaa !27
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr i64, ptr %t50, i64 %t47
  %t52 = load i64, ptr %t51, !tbaa !34
  store i64 %t52, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t56 = call i64 @compiler_2ffree_2eokind(i64 %t54)
  store i64 %t56, ptr %l34
  br label %bb18
bb18:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l8, !tbaa !24
  %t58 = load i64, ptr %l8, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t62 = icmp eq i64 %t58, %t59
  br i1 %t62, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb21
bb20:
  %t64 = load i64, ptr %l8, !tbaa !24
  %t65 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t68 = icmp eq i64 %t64, %t65
  store i1 %t68, ptr %l38, !tbaa !21
  br label %bb21
bb21:
  %t70 = load i1, ptr %l38, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:walker", ptr %t71, i32 0, i32 34
  store ptr %t73, ptr %l43, !tbaa !29
  %t74 = load i64, ptr %l7, !tbaa !24
  %t76 = call i64 @compiler_2ffree_2eoval(i64 %t74)
  store i64 %t76, ptr %l45
  br label %bb24
bb23:
  br label %bb27
bb24:
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t78 = load i64, ptr %l45, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t77, i64 %t78)
  br label %bb25
bb25:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 35
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 12
  %t85 = load i64, ptr %t84, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t81, i64 %t85)
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t90 = add i64 %t88, 1
  store i64 %t90, ptr %l6, !tbaa !24
  br label %bb14
bb29:
  %t92 = load i64, ptr %l3, !tbaa !24
  %t93 = load i64, ptr %l5, !tbaa !24
  %t96 = add i64 %t92, %t93
  store i64 %t96, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  br label %bb7
bb31:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca ptr
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca ptr
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l129 = alloca ptr
  %l130 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l132 = alloca ptr
  %l133 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l138 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i32
  %l152 = alloca { i64, ptr }
  %l156 = alloca i64
  %l159 = alloca i1
  %l161 = alloca i64
  %l166 = alloca ptr
  %l168 = alloca i64
  %l178 = alloca i64
  %l182 = alloca i64
  %l185 = alloca i64
  %l203 = alloca ptr
  %l207 = alloca i64
  %l208 = alloca ptr
  %l212 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l215 = alloca i64
  %l219 = alloca i64
  %l222 = alloca i64
  %l242 = alloca ptr
  %l243 = alloca i64
  %l245 = alloca i1
  %l249 = alloca i1
  %l257 = alloca i64
  %l263 = alloca i64
  %l267 = alloca i64
  %l270 = alloca i64
  %l291 = alloca i64
  %l292 = alloca i64
  %l302 = alloca i64
  %l305 = alloca i64
  %l323 = alloca i64
  %l333 = alloca i64
  %l339 = alloca i64
  %l345 = alloca i64
  %l349 = alloca i64
  %l352 = alloca i64
  %l373 = alloca i64
  %l378 = alloca i64
  %l382 = alloca i64
  %l383 = alloca i64
  %l390 = alloca i64
  %l394 = alloca i64
  %l397 = alloca i64
  %l418 = alloca i64
  %l422 = alloca i64
  %l426 = alloca i64
  %l429 = alloca i1
  %l430 = alloca i64
  %l433 = alloca i64
  %l435 = alloca i1
  %l439 = alloca i64
  %l445 = alloca i64
  %l449 = alloca i1
  %l453 = alloca i1
  %l457 = alloca i1
  %l469 = alloca i64
  %l472 = alloca i64
  %l494 = alloca i1
  %l498 = alloca i1
  %l502 = alloca i64
  %l505 = alloca i1
  %l508 = alloca i1
  %l509 = alloca ptr
  %l510 = alloca i64
  %l512 = alloca i64
  %l516 = alloca %"compiler/source:Span"
  %l517 = alloca ptr
  %l519 = alloca i64
  %l523 = alloca %"compiler/source:Span"
  %l524 = alloca { i64, ptr }
  %l531 = alloca { i64, ptr }
  %l534 = alloca { i64, ptr }
  %l535 = alloca i32
  %l544 = alloca { i64, ptr }
  %l549 = alloca ptr
  %l550 = alloca { i64, ptr }
  %l553 = alloca { i64, ptr }
  %l554 = alloca i32
  %l563 = alloca { i64, ptr }
  %l568 = alloca i1
  %l572 = alloca i1
  %l576 = alloca i64
  %l579 = alloca i1
  %l582 = alloca i1
  %l591 = alloca ptr
  %l592 = alloca i64
  %l593 = alloca i64
  %l596 = alloca ptr
  %l597 = alloca i64
  %l603 = alloca ptr
  %l607 = alloca %"compiler/typed:Local"
  %l609 = alloca { i64, ptr }
  %l613 = alloca ptr
  %l615 = alloca i64
  %l619 = alloca %"compiler/typed:Local"
  %l622 = alloca i64
  %l626 = alloca ptr
  %l628 = alloca i64
  %l632 = alloca %"compiler/source:Span"
  %l635 = alloca i64
  %l642 = alloca i1
  %l643 = alloca ptr
  %l645 = alloca i64
  %l649 = alloca %"compiler/source:Span"
  %l650 = alloca { i64, ptr }
  %l651 = alloca i64
  %l653 = alloca i1
  %l655 = alloca i1
  %l657 = alloca { i64, ptr }
  %l658 = alloca i1
  %l660 = alloca { i64, ptr }
  %l664 = alloca { i64, ptr }
  %l666 = alloca i64
  %l668 = alloca { i64, ptr }
  %l669 = alloca { i64, ptr }
  %l671 = alloca i64
  %l673 = alloca i64
  %l674 = alloca { i64, ptr }
  %l675 = alloca { i64, ptr }
  %l676 = alloca { i64, ptr }
  %l677 = alloca i64
  %l678 = alloca { i64, ptr }
  %l682 = alloca ptr
  %l684 = alloca i64
  %l688 = alloca %"compiler/source:Span"
  %l689 = alloca { i64, ptr }
  %l692 = alloca { i64, ptr }
  %l694 = alloca i64
  %l699 = alloca ptr
  %l701 = alloca i64
  %l705 = alloca %"compiler/source:Span"
  %l706 = alloca { i64, ptr }
  %l707 = alloca i64
  %l710 = alloca { i64, ptr }
  %l712 = alloca { i64, ptr }
  %l714 = alloca i64
  %l718 = alloca { i64, ptr }
  %l720 = alloca i64
  %l724 = alloca ptr
  %l725 = alloca { i64, ptr }
  %l728 = alloca { i64, ptr }
  %l729 = alloca i32
  %l738 = alloca { i64, ptr }
  %l743 = alloca i1
  %l747 = alloca i1
  %l751 = alloca i64
  %l754 = alloca i1
  %l757 = alloca i1
  %l759 = alloca ptr
  %l760 = alloca i64
  %l762 = alloca i64
  %l766 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s49 = alloca %olang.scope
  %s52 = alloca %olang.scope
  %s57 = alloca %olang.scope
  %s58 = alloca %olang.scope
  %s59 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l99
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l99, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l100
  br label %bb2
bb2:
  %t11 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l3
  %t12 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l101
  br label %bb3
bb3:
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 3
  %t18 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l104
  br label %bb4
bb4:
  %t19 = load i64, ptr %l104, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l111, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l111, !tbaa !24
  store i64 %t46, ptr %l108, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l108, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l10, !tbaa !24
  store ptr %l3, ptr %l129, !tbaa !29
  %t66 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l130
  br label %bb15
bb15:
  %t67 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l130
  %t68 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %t68
  %t69 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %s0, ptr %s0, ptr %t69, ptr %t68)
  br label %bb16
bb16:
  store ptr %l4, ptr %l132, !tbaa !29
  %t71 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l133
  br label %bb17
bb17:
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l133
  %t73 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %t73
  %t74 = load ptr, ptr %l132, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %s0, ptr %s0, ptr %t74, ptr %t73)
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 3
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l138
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l138, !tbaa !29
  store ptr %t83, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t84 = load ptr, ptr %l11, !tbaa !29
  %t85 = load i64, ptr %l12, !tbaa !24
  %t88 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t84, i64 %t85)
  %t89 = extractvalue { i32, { i64, ptr } } %t88, 1
  %t90 = extractvalue { i32, { i64, ptr } } %t88, 0
  store i32 %t90, ptr %l143
  %t91 = icmp ne i32 %t90, 0
  br i1 %t91, label %bb22, label %ok.92
ok.92:
  store { i64, ptr } %t89, ptr %l142
  br label %bb21
bb21:
  %t93 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t93, ptr %l139, !tbaa !27
  br label %bb26
bb22:
  %t94 = load i32, ptr %l143, !tbaa !23
  %t95 = ashr i32 %t94, 16
  %t97 = icmp eq i32 %t95, 1
  br i1 %t97, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_8c0c33fee9f1510c_8a29d4fc33338c88)
  unreachable
bb25:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb45
bb26:
  %t99 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t99, ptr %l13, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load i64, ptr %l15, !tbaa !24
  %t105 = load i64, ptr %l14, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb29:
  br label %bb30
bb30:
  %t112 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t112, ptr %l152, !tbaa !27
  %t113 = load i64, ptr %l15, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i64, ptr %t116, i64 %t113
  %t118 = load i64, ptr %t117, !tbaa !34
  store i64 %t118, ptr %l16, !tbaa !24
  %t120 = load i64, ptr %l16, !tbaa !24
  %t122 = call i64 @compiler_2ffree_2eokind(i64 %t120)
  store i64 %t122, ptr %l156
  br label %bb31
bb31:
  %t123 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t124 = load i64, ptr %l156, !tbaa !24
  %t126 = icmp eq i64 %t124, %t123
  br i1 %t126, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l159, !tbaa !21
  br label %bb35
bb33:
  %t128 = load i64, ptr %l16, !tbaa !24
  %t130 = call i64 @compiler_2ffree_2eokind(i64 %t128)
  store i64 %t130, ptr %l161
  br label %bb34
bb34:
  %t131 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t132 = load i64, ptr %l161, !tbaa !24
  %t134 = icmp eq i64 %t132, %t131
  store i1 %t134, ptr %l159, !tbaa !21
  br label %bb35
bb35:
  %t136 = load i1, ptr %l159, !tbaa !21
  br i1 %t136, label %bb36, label %bb37
bb36:
  %t137 = load i64, ptr %l10, !tbaa !24
  %t140 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %s0, ptr %s0, ptr %l3, i64 %t137)
  store ptr %t140, ptr %l166
  br label %bb38
bb37:
  br label %bb41
bb38:
  %t141 = load i64, ptr %l16, !tbaa !24
  %t143 = call i64 @compiler_2ffree_2eoval(i64 %t141)
  store i64 %t143, ptr %l168
  br label %bb39
bb39:
  %t144 = load ptr, ptr %l166, !tbaa !29
  %t145 = load i64, ptr %l168, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t144, i64 %t145)
  br label %bb40
bb40:
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  br label %bb42
bb42:
  %t146 = load i64, ptr %l15, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l15, !tbaa !24
  br label %bb27
bb43:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = add i64 %t150, %t151
  store i64 %t154, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb44
bb44:
  br label %bb20
bb45:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb46:
  %t156 = load i64, ptr %l9, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l9, !tbaa !24
  br label %bb11
bb47:
  store i64 0, ptr %l17, !tbaa !24
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/free:walker", ptr %t160, i32 0, i32 24
  %t164 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t162)
  store i64 %t164, ptr %l178
  br label %bb48
bb48:
  %t165 = load i64, ptr %l178, !tbaa !24
  store i64 %t165, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t166 = load i64, ptr %l18, !tbaa !24
  %t167 = load i64, ptr %l17, !tbaa !24
  %t170 = icmp sgt i64 %t166, %t167
  br i1 %t170, label %bb49, label %bb50
bb49:
  %t172 = load i64, ptr %l19, !tbaa !24
  %t174 = icmp sgt i64 %t172, 0
  br i1 %t174, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb54
bb51:
  %t176 = load i64, ptr %l18, !tbaa !24
  %t177 = load i64, ptr %l17, !tbaa !24
  %t180 = sub i64 %t176, %t177
  %t181 = load i64, ptr %l19, !tbaa !24
  %t184 = add i64 %t180, %t181
  %t186 = sub i64 %t184, 1
  %t187 = load i64, ptr %l19, !tbaa !24
  %t190 = sdiv i64 %t186, %t187
  store i64 %t190, ptr %l185, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb53
bb53:
  %t192 = load i64, ptr %l185, !tbaa !24
  store i64 %t192, ptr %l182, !tbaa !24
  br label %bb54
bb54:
  %t193 = load i64, ptr %l182, !tbaa !24
  store i64 %t193, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t194 = load i64, ptr %l21, !tbaa !24
  %t195 = load i64, ptr %l20, !tbaa !24
  %t198 = icmp slt i64 %t194, %t195
  %t200 = xor i1 %t198, true
  br i1 %t200, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb57:
  br label %bb58
bb58:
  %t202 = load i64, ptr %l17, !tbaa !24
  %t203 = load i64, ptr %l21, !tbaa !24
  %t204 = load i64, ptr %l19, !tbaa !24
  %t207 = mul i64 %t203, %t204
  %t210 = add i64 %t202, %t207
  store i64 %t210, ptr %l22, !tbaa !24
  store ptr %l4, ptr %l203, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/free:walker", ptr %t212, i32 0, i32 24
  %t215 = load i64, ptr %l22, !tbaa !24
  %t218 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t214, i64 %t215)
  store i64 %t218, ptr %l207
  br label %bb59
bb59:
  %t219 = load ptr, ptr %l203, !tbaa !29
  %t220 = load i64, ptr %l207, !tbaa !24
  %t221 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %s0, ptr %s0, ptr %t219, i64 %t220)
  store ptr %t221, ptr %l208
  br label %bb60
bb60:
  %t222 = load i64, ptr %l22, !tbaa !24
  %t223 = load ptr, ptr %l208, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t223, i64 %t222)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s10)
  br label %bb62
bb62:
  %t225 = load i64, ptr %l21, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l21, !tbaa !24
  br label %bb55
bb63:
  %t229 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t229, ptr %l212
  br label %bb64
bb64:
  %t230 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l212
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t230, ptr %l23
  store i64 0, ptr %l24, !tbaa !24
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/free:walker", ptr %t231, i32 0, i32 3
  %t235 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %t233)
  store i64 %t235, ptr %l215
  br label %bb65
bb65:
  %t236 = load i64, ptr %l215, !tbaa !24
  store i64 %t236, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t237 = load i64, ptr %l25, !tbaa !24
  %t238 = load i64, ptr %l24, !tbaa !24
  %t241 = icmp sgt i64 %t237, %t238
  br i1 %t241, label %bb66, label %bb67
bb66:
  %t243 = load i64, ptr %l26, !tbaa !24
  %t245 = icmp sgt i64 %t243, 0
  br i1 %t245, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l219, !tbaa !24
  br label %bb71
bb68:
  %t247 = load i64, ptr %l25, !tbaa !24
  %t248 = load i64, ptr %l24, !tbaa !24
  %t251 = sub i64 %t247, %t248
  %t252 = load i64, ptr %l26, !tbaa !24
  %t255 = add i64 %t251, %t252
  %t257 = sub i64 %t255, 1
  %t258 = load i64, ptr %l26, !tbaa !24
  %t261 = sdiv i64 %t257, %t258
  store i64 %t261, ptr %l222, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l222, !tbaa !24
  br label %bb70
bb70:
  %t263 = load i64, ptr %l222, !tbaa !24
  store i64 %t263, ptr %l219, !tbaa !24
  br label %bb71
bb71:
  %t264 = load i64, ptr %l219, !tbaa !24
  store i64 %t264, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s13
  %t265 = load i64, ptr %l28, !tbaa !24
  %t266 = load i64, ptr %l27, !tbaa !24
  %t269 = icmp slt i64 %t265, %t266
  %t271 = xor i1 %t269, true
  br i1 %t271, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s13)
  br label %bb87
bb74:
  br label %bb75
bb75:
  %t273 = load i64, ptr %l24, !tbaa !24
  %t274 = load i64, ptr %l28, !tbaa !24
  %t275 = load i64, ptr %l26, !tbaa !24
  %t278 = mul i64 %t274, %t275
  %t281 = add i64 %t273, %t278
  store i64 %t281, ptr %l29, !tbaa !24
  %t283 = load i64, ptr %l29, !tbaa !24
  %t286 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %s0, ptr %s0, ptr %l3, i64 %t283)
  store ptr %t286, ptr %l242
  br label %bb76
bb76:
  %t287 = load ptr, ptr %l242, !tbaa !29
  %t288 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t287)
  store i64 %t288, ptr %l243
  br label %bb77
bb77:
  %t289 = load i64, ptr %l243, !tbaa !24
  %t290 = icmp sgt i64 %t289, 0
  br i1 %t290, label %bb78, label %bb79
bb78:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr %"compiler/free:walker", ptr %t292, i32 0, i32 6
  %t295 = load i64, ptr %l29, !tbaa !24
  %t298 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t294, i64 %t295)
  store i1 %t298, ptr %l249
  br label %bb80
bb79:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb81
bb80:
  %t299 = load i1, ptr %l249, !tbaa !21
  %t300 = xor i1 %t299, true
  store i1 %t300, ptr %l245, !tbaa !21
  br label %bb81
bb81:
  %t302 = load i1, ptr %l245, !tbaa !21
  br i1 %t302, label %bb82, label %bb83
bb82:
  %t303 = load i64, ptr %l29, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l23, i64 %t303)
  br label %bb84
bb83:
  br label %bb85
bb84:
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s13)
  br label %bb86
bb86:
  %t306 = load i64, ptr %l28, !tbaa !24
  %t308 = add i64 %t306, 1
  store i64 %t308, ptr %l28, !tbaa !24
  br label %bb72
bb87:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/free:walker", ptr %t310, i32 0, i32 11
  %t313 = load i64, ptr %t312, !tbaa !24
  %t315 = add i64 %t313, 2
  store i64 %t315, ptr %l257, !tbaa !24
  %t316 = load i64, ptr %l257, !tbaa !24
  %t317 = icmp sge i64 %t316, 0
  br i1 %t317, label %bb88, label %bb89
bb88:
  %t319 = load i64, ptr %l257, !tbaa !24
  %t320 = icmp sle i64 %t319, 1152921504606846975
  br i1 %t320, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_de370d56f621a286_665adcb3259bb65a)
  unreachable
bb90:
  %t322 = load i64, ptr %l257, !tbaa !24
  %t323 = mul i64 %t322, 8
  %t324 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t323)
  %t325 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  store { i64, ptr } %t326, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/free:walker", ptr %t328, i32 0, i32 34
  %t332 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t330)
  store i64 %t332, ptr %l263
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_de370d56f621a286_665adcb3259bb65a)
  unreachable
bb92:
  %t333 = load i64, ptr %l263, !tbaa !24
  store i64 %t333, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t334 = load i64, ptr %l32, !tbaa !24
  %t335 = load i64, ptr %l31, !tbaa !24
  %t338 = icmp sgt i64 %t334, %t335
  br i1 %t338, label %bb93, label %bb94
bb93:
  %t340 = load i64, ptr %l33, !tbaa !24
  %t342 = icmp sgt i64 %t340, 0
  br i1 %t342, label %bb95, label %bb96
bb94:
  store i64 0, ptr %l267, !tbaa !24
  br label %bb98
bb95:
  %t344 = load i64, ptr %l32, !tbaa !24
  %t345 = load i64, ptr %l31, !tbaa !24
  %t348 = sub i64 %t344, %t345
  %t349 = load i64, ptr %l33, !tbaa !24
  %t352 = add i64 %t348, %t349
  %t354 = sub i64 %t352, 1
  %t355 = load i64, ptr %l33, !tbaa !24
  %t358 = sdiv i64 %t354, %t355
  store i64 %t358, ptr %l270, !tbaa !24
  br label %bb97
bb96:
  store i64 0, ptr %l270, !tbaa !24
  br label %bb97
bb97:
  %t360 = load i64, ptr %l270, !tbaa !24
  store i64 %t360, ptr %l267, !tbaa !24
  br label %bb98
bb98:
  %t361 = load i64, ptr %l267, !tbaa !24
  store i64 %t361, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb99
bb99:
  store %olang.scope zeroinitializer, ptr %s17
  %t362 = load i64, ptr %l35, !tbaa !24
  %t363 = load i64, ptr %l34, !tbaa !24
  %t366 = icmp slt i64 %t362, %t363
  %t368 = xor i1 %t366, true
  br i1 %t368, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s17)
  br label %bb105
bb101:
  br label %bb102
bb102:
  %t370 = load i64, ptr %l31, !tbaa !24
  %t371 = load i64, ptr %l35, !tbaa !24
  %t372 = load i64, ptr %l33, !tbaa !24
  %t375 = mul i64 %t371, %t372
  %t378 = add i64 %t370, %t375
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/free:walker", ptr %t380, i32 0, i32 35
  %t386 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t382, i64 %t378)
  store i64 %t386, ptr %l291
  br label %bb103
bb103:
  %t387 = load i64, ptr %l291, !tbaa !24
  %t388 = add i64 %t387, 1
  store i64 %t388, ptr %l292, !tbaa !24
  %t389 = load i64, ptr %l292, !tbaa !24
  %t390 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr i64, ptr %t391, i64 %t389
  %t393 = load i64, ptr %t392, !tbaa !34
  %t395 = add i64 %t393, 1
  %t397 = load i64, ptr %l292, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr i64, ptr %t399, i64 %t397
  store i64 %t395, ptr %t400, !tbaa !34
  call void @__olang_scope_close(ptr %s17)
  br label %bb104
bb104:
  %t401 = load i64, ptr %l35, !tbaa !24
  %t403 = add i64 %t401, 1
  store i64 %t403, ptr %l35, !tbaa !24
  br label %bb99
bb105:
  store i64 1, ptr %l37, !tbaa !24
  %t405 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t407 = extractvalue { i64, ptr } %t405, 0
  store i64 %t407, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t409 = load i64, ptr %l38, !tbaa !24
  %t410 = load i64, ptr %l37, !tbaa !24
  %t413 = icmp sgt i64 %t409, %t410
  br i1 %t413, label %bb106, label %bb107
bb106:
  %t415 = load i64, ptr %l39, !tbaa !24
  %t417 = icmp sgt i64 %t415, 0
  br i1 %t417, label %bb108, label %bb109
bb107:
  store i64 0, ptr %l302, !tbaa !24
  br label %bb111
bb108:
  %t419 = load i64, ptr %l38, !tbaa !24
  %t420 = load i64, ptr %l37, !tbaa !24
  %t423 = sub i64 %t419, %t420
  %t424 = load i64, ptr %l39, !tbaa !24
  %t427 = add i64 %t423, %t424
  %t429 = sub i64 %t427, 1
  %t430 = load i64, ptr %l39, !tbaa !24
  %t433 = sdiv i64 %t429, %t430
  store i64 %t433, ptr %l305, !tbaa !24
  br label %bb110
bb109:
  store i64 0, ptr %l305, !tbaa !24
  br label %bb110
bb110:
  %t435 = load i64, ptr %l305, !tbaa !24
  store i64 %t435, ptr %l302, !tbaa !24
  br label %bb111
bb111:
  %t436 = load i64, ptr %l302, !tbaa !24
  store i64 %t436, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb112
bb112:
  store %olang.scope zeroinitializer, ptr %s20
  %t437 = load i64, ptr %l41, !tbaa !24
  %t438 = load i64, ptr %l40, !tbaa !24
  %t441 = icmp slt i64 %t437, %t438
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s20)
  br label %bb117
bb114:
  br label %bb115
bb115:
  %t445 = load i64, ptr %l37, !tbaa !24
  %t446 = load i64, ptr %l41, !tbaa !24
  %t447 = load i64, ptr %l39, !tbaa !24
  %t450 = mul i64 %t446, %t447
  %t453 = add i64 %t445, %t450
  store i64 %t453, ptr %l42, !tbaa !24
  %t455 = load i64, ptr %l42, !tbaa !24
  store i64 %t455, ptr %l323, !tbaa !24
  %t456 = load i64, ptr %l323, !tbaa !24
  %t457 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t458 = load ptr, ptr %t457, !tbaa !27
  %t459 = getelementptr i64, ptr %t458, i64 %t456
  %t460 = load i64, ptr %t459, !tbaa !34
  %t461 = load i64, ptr %l42, !tbaa !24
  %t463 = sub i64 %t461, 1
  %t465 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr i64, ptr %t466, i64 %t463
  %t468 = load i64, ptr %t467, !tbaa !34
  %t471 = add i64 %t460, %t468
  %t473 = load i64, ptr %l323, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr i64, ptr %t475, i64 %t473
  store i64 %t471, ptr %t476, !tbaa !34
  call void @__olang_scope_close(ptr %s20)
  br label %bb116
bb116:
  %t477 = load i64, ptr %l41, !tbaa !24
  %t479 = add i64 %t477, 1
  store i64 %t479, ptr %l41, !tbaa !24
  br label %bb112
bb117:
  %t481 = load ptr, ptr %l0, !tbaa !29
  %t483 = getelementptr %"compiler/free:walker", ptr %t481, i32 0, i32 34
  %t485 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t483)
  store i64 %t485, ptr %l333
  br label %bb118
bb118:
  %t486 = load i64, ptr %l333, !tbaa !24
  %t487 = icmp sge i64 %t486, 0
  br i1 %t487, label %bb119, label %bb120
bb119:
  %t489 = load i64, ptr %l333, !tbaa !24
  %t490 = icmp sle i64 %t489, 1152921504606846975
  br i1 %t490, label %bb121, label %bb122
bb120:
  call void @__olang_check_failed(ptr @olang_loc_61a66e32b2a4c4a5_788650647dbfbbd9)
  unreachable
bb121:
  %t492 = load i64, ptr %l333, !tbaa !24
  %t493 = mul i64 %t492, 8
  %t494 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t493)
  %t495 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t494, 1
  store { i64, ptr } %t496, ptr %l43, !tbaa !27
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = getelementptr %"compiler/free:walker", ptr %t498, i32 0, i32 11
  %t501 = load i64, ptr %t500, !tbaa !24
  %t503 = add i64 %t501, 1
  store i64 %t503, ptr %l339, !tbaa !24
  %t504 = load i64, ptr %l339, !tbaa !24
  %t505 = icmp sge i64 %t504, 0
  br i1 %t505, label %bb123, label %bb124
bb122:
  call void @__olang_check_failed(ptr @olang_loc_61a66e32b2a4c4a5_788650647dbfbbd9)
  unreachable
bb123:
  %t507 = load i64, ptr %l339, !tbaa !24
  %t508 = icmp sle i64 %t507, 1152921504606846975
  br i1 %t508, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_4d2004aee1a8ca38_5ea03f23f1e608cc)
  unreachable
bb125:
  %t510 = load i64, ptr %l339, !tbaa !24
  %t511 = mul i64 %t510, 8
  %t512 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t511)
  %t513 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t512, 1
  store { i64, ptr } %t514, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/free:walker", ptr %t516, i32 0, i32 34
  %t520 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t518)
  store i64 %t520, ptr %l345
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_4d2004aee1a8ca38_5ea03f23f1e608cc)
  unreachable
bb127:
  %t521 = load i64, ptr %l345, !tbaa !24
  store i64 %t521, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t522 = load i64, ptr %l46, !tbaa !24
  %t523 = load i64, ptr %l45, !tbaa !24
  %t526 = icmp sgt i64 %t522, %t523
  br i1 %t526, label %bb128, label %bb129
bb128:
  %t528 = load i64, ptr %l47, !tbaa !24
  %t530 = icmp sgt i64 %t528, 0
  br i1 %t530, label %bb130, label %bb131
bb129:
  store i64 0, ptr %l349, !tbaa !24
  br label %bb133
bb130:
  %t532 = load i64, ptr %l46, !tbaa !24
  %t533 = load i64, ptr %l45, !tbaa !24
  %t536 = sub i64 %t532, %t533
  %t537 = load i64, ptr %l47, !tbaa !24
  %t540 = add i64 %t536, %t537
  %t542 = sub i64 %t540, 1
  %t543 = load i64, ptr %l47, !tbaa !24
  %t546 = sdiv i64 %t542, %t543
  store i64 %t546, ptr %l352, !tbaa !24
  br label %bb132
bb131:
  store i64 0, ptr %l352, !tbaa !24
  br label %bb132
bb132:
  %t548 = load i64, ptr %l352, !tbaa !24
  store i64 %t548, ptr %l349, !tbaa !24
  br label %bb133
bb133:
  %t549 = load i64, ptr %l349, !tbaa !24
  store i64 %t549, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb134
bb134:
  store %olang.scope zeroinitializer, ptr %s23
  %t550 = load i64, ptr %l49, !tbaa !24
  %t551 = load i64, ptr %l48, !tbaa !24
  %t554 = icmp slt i64 %t550, %t551
  %t556 = xor i1 %t554, true
  br i1 %t556, label %bb135, label %bb136
bb135:
  call void @__olang_scope_close(ptr %s23)
  br label %bb141
bb136:
  br label %bb137
bb137:
  %t558 = load i64, ptr %l45, !tbaa !24
  %t559 = load i64, ptr %l49, !tbaa !24
  %t560 = load i64, ptr %l47, !tbaa !24
  %t563 = mul i64 %t559, %t560
  %t566 = add i64 %t558, %t563
  store i64 %t566, ptr %l50, !tbaa !24
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t570 = getelementptr %"compiler/free:walker", ptr %t568, i32 0, i32 35
  %t571 = load i64, ptr %l50, !tbaa !24
  %t574 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t570, i64 %t571)
  store i64 %t574, ptr %l373
  br label %bb138
bb138:
  %t575 = load i64, ptr %l373, !tbaa !24
  store i64 %t575, ptr %l51, !tbaa !24
  %t576 = load i64, ptr %l51, !tbaa !24
  %t578 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = getelementptr i64, ptr %t579, i64 %t576
  %t581 = load i64, ptr %t580, !tbaa !34
  %t582 = load i64, ptr %l51, !tbaa !24
  %t584 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !27
  %t586 = getelementptr i64, ptr %t585, i64 %t582
  %t587 = load i64, ptr %t586, !tbaa !34
  %t590 = add i64 %t581, %t587
  store i64 %t590, ptr %l378, !tbaa !24
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t593 = getelementptr %"compiler/free:walker", ptr %t591, i32 0, i32 34
  %t594 = load i64, ptr %l50, !tbaa !24
  %t597 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t593, i64 %t594)
  store i64 %t597, ptr %l382
  br label %bb139
bb139:
  %t598 = load i64, ptr %l382, !tbaa !24
  %t599 = load i64, ptr %l378, !tbaa !24
  %t600 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t601 = load ptr, ptr %t600, !tbaa !27
  %t602 = getelementptr i64, ptr %t601, i64 %t599
  store i64 %t598, ptr %t602, !tbaa !34
  %t603 = load i64, ptr %l51, !tbaa !24
  store i64 %t603, ptr %l383, !tbaa !24
  %t604 = load i64, ptr %l383, !tbaa !24
  %t605 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t606 = load ptr, ptr %t605, !tbaa !27
  %t607 = getelementptr i64, ptr %t606, i64 %t604
  %t608 = load i64, ptr %t607, !tbaa !34
  %t610 = add i64 %t608, 1
  %t612 = load i64, ptr %l383, !tbaa !24
  %t613 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr i64, ptr %t614, i64 %t612
  store i64 %t610, ptr %t615, !tbaa !34
  call void @__olang_scope_close(ptr %s23)
  br label %bb140
bb140:
  %t616 = load i64, ptr %l49, !tbaa !24
  %t618 = add i64 %t616, 1
  store i64 %t618, ptr %l49, !tbaa !24
  br label %bb134
bb141:
  store i64 0, ptr %l52, !tbaa !24
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t622 = getelementptr %"compiler/free:walker", ptr %t620, i32 0, i32 36
  %t624 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t622)
  store i64 %t624, ptr %l390
  br label %bb142
bb142:
  %t625 = load i64, ptr %l390, !tbaa !24
  store i64 %t625, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t626 = load i64, ptr %l53, !tbaa !24
  %t627 = load i64, ptr %l52, !tbaa !24
  %t630 = icmp sgt i64 %t626, %t627
  br i1 %t630, label %bb143, label %bb144
bb143:
  %t632 = load i64, ptr %l54, !tbaa !24
  %t634 = icmp sgt i64 %t632, 0
  br i1 %t634, label %bb145, label %bb146
bb144:
  store i64 0, ptr %l394, !tbaa !24
  br label %bb148
bb145:
  %t636 = load i64, ptr %l53, !tbaa !24
  %t637 = load i64, ptr %l52, !tbaa !24
  %t640 = sub i64 %t636, %t637
  %t641 = load i64, ptr %l54, !tbaa !24
  %t644 = add i64 %t640, %t641
  %t646 = sub i64 %t644, 1
  %t647 = load i64, ptr %l54, !tbaa !24
  %t650 = sdiv i64 %t646, %t647
  store i64 %t650, ptr %l397, !tbaa !24
  br label %bb147
bb146:
  store i64 0, ptr %l397, !tbaa !24
  br label %bb147
bb147:
  %t652 = load i64, ptr %l397, !tbaa !24
  store i64 %t652, ptr %l394, !tbaa !24
  br label %bb148
bb148:
  %t653 = load i64, ptr %l394, !tbaa !24
  store i64 %t653, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb149
bb149:
  store %olang.scope zeroinitializer, ptr %s26
  %t654 = load i64, ptr %l56, !tbaa !24
  %t655 = load i64, ptr %l55, !tbaa !24
  %t658 = icmp slt i64 %t654, %t655
  %t660 = xor i1 %t658, true
  br i1 %t660, label %bb150, label %bb151
bb150:
  call void @__olang_scope_close(ptr %s26)
  br label %bb345
bb151:
  br label %bb152
bb152:
  %t662 = load i64, ptr %l52, !tbaa !24
  %t663 = load i64, ptr %l56, !tbaa !24
  %t664 = load i64, ptr %l54, !tbaa !24
  %t667 = mul i64 %t663, %t664
  %t670 = add i64 %t662, %t667
  store i64 %t670, ptr %l57, !tbaa !24
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t674 = getelementptr %"compiler/free:walker", ptr %t672, i32 0, i32 36
  %t675 = load i64, ptr %l57, !tbaa !24
  %t678 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t674, i64 %t675)
  store i64 %t678, ptr %l418
  br label %bb153
bb153:
  %t679 = load i64, ptr %l418, !tbaa !24
  store i64 %t679, ptr %l58, !tbaa !24
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/free:walker", ptr %t680, i32 0, i32 37
  %t683 = load i64, ptr %l57, !tbaa !24
  %t686 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t682, i64 %t683)
  store i64 %t686, ptr %l422
  br label %bb154
bb154:
  %t687 = load i64, ptr %l422, !tbaa !24
  store i64 %t687, ptr %l59, !tbaa !24
  %t688 = load ptr, ptr %l0, !tbaa !29
  %t690 = getelementptr %"compiler/free:walker", ptr %t688, i32 0, i32 38
  %t691 = load i64, ptr %l57, !tbaa !24
  %t694 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t690, i64 %t691)
  store i64 %t694, ptr %l426
  br label %bb155
bb155:
  %t695 = load i64, ptr %l426, !tbaa !24
  store i64 %t695, ptr %l60, !tbaa !24
  %t696 = load i64, ptr %l58, !tbaa !24
  %t698 = icmp sge i64 %t696, 0
  br i1 %t698, label %bb156, label %bb157
bb156:
  %t700 = load i64, ptr %l58, !tbaa !24
  store i64 %t700, ptr %l430, !tbaa !24
  %t701 = load ptr, ptr %l1, !tbaa !29
  %t703 = getelementptr %"compiler/free:Free", ptr %t701, i32 0, i32 36
  %t705 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t703)
  store i64 %t705, ptr %l433
  br label %bb158
bb157:
  store i1 false, ptr %l429, !tbaa !21
  br label %bb163
bb158:
  %t706 = load i64, ptr %l430, !tbaa !24
  %t707 = load i64, ptr %l433, !tbaa !24
  %t708 = icmp sge i64 %t706, %t707
  br i1 %t708, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l435, !tbaa !21
  br label %bb162
bb160:
  %t710 = load ptr, ptr %l1, !tbaa !29
  %t712 = getelementptr %"compiler/free:Free", ptr %t710, i32 0, i32 36
  %t713 = load i64, ptr %l58, !tbaa !24
  %t716 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t712, i64 %t713)
  store i64 %t716, ptr %l439
  br label %bb161
bb161:
  %t717 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t718 = load i64, ptr %l439, !tbaa !24
  %t720 = icmp ne i64 %t718, %t717
  store i1 %t720, ptr %l435, !tbaa !21
  br label %bb162
bb162:
  %t722 = load i1, ptr %l435, !tbaa !21
  store i1 %t722, ptr %l429, !tbaa !21
  br label %bb163
bb163:
  %t723 = load i1, ptr %l429, !tbaa !21
  br i1 %t723, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s26)
  br label %bb344
bb165:
  br label %bb166
bb166:
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = getelementptr %"compiler/free:walker", ptr %t724, i32 0, i32 42
  %t727 = load i64, ptr %l57, !tbaa !24
  %t730 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t726, i64 %t727)
  store i64 %t730, ptr %l445
  br label %bb167
bb167:
  %t731 = load i64, ptr %l445, !tbaa !24
  store i64 %t731, ptr %l61, !tbaa !24
  %t732 = load i64, ptr %l60, !tbaa !24
  %t733 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  %t736 = icmp ne i64 %t732, %t733
  br i1 %t736, label %bb168, label %bb169
bb168:
  %t738 = load i64, ptr %l60, !tbaa !24
  %t739 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  %t742 = icmp ne i64 %t738, %t739
  store i1 %t742, ptr %l449, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l449, !tbaa !21
  br label %bb170
bb170:
  %t744 = load i1, ptr %l449, !tbaa !21
  br i1 %t744, label %bb171, label %bb172
bb171:
  %t745 = load i64, ptr %l60, !tbaa !24
  %t746 = load i64, ptr @G_2ecompiler_2ffree_2eLDestroy, !tbaa !24
  %t749 = icmp ne i64 %t745, %t746
  store i1 %t749, ptr %l453, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l453, !tbaa !21
  br label %bb173
bb173:
  %t751 = load i1, ptr %l453, !tbaa !21
  br i1 %t751, label %bb174, label %bb175
bb174:
  %t752 = load i64, ptr %l60, !tbaa !24
  %t753 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  %t756 = icmp ne i64 %t752, %t753
  store i1 %t756, ptr %l457, !tbaa !21
  br label %bb176
bb175:
  store i1 false, ptr %l457, !tbaa !21
  br label %bb176
bb176:
  %t758 = load i1, ptr %l457, !tbaa !21
  br i1 %t758, label %bb177, label %bb178
bb177:
  %t759 = load i64, ptr %l59, !tbaa !24
  %t761 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = getelementptr i64, ptr %t762, i64 %t759
  %t764 = load i64, ptr %t763, !tbaa !34
  store i64 %t764, ptr %l62, !tbaa !24
  %t766 = load i64, ptr %l59, !tbaa !24
  %t768 = add i64 %t766, 1
  %t770 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t771 = load ptr, ptr %t770, !tbaa !27
  %t772 = getelementptr i64, ptr %t771, i64 %t768
  %t773 = load i64, ptr %t772, !tbaa !34
  store i64 %t773, ptr %l63, !tbaa !24
  store i64 1, ptr %l64, !tbaa !24
  %t775 = load i64, ptr %l63, !tbaa !24
  %t776 = load i64, ptr %l62, !tbaa !24
  %t779 = icmp sgt i64 %t775, %t776
  br i1 %t779, label %bb179, label %bb180
bb178:
  br label %bb209
bb179:
  %t781 = load i64, ptr %l64, !tbaa !24
  %t783 = icmp sgt i64 %t781, 0
  br i1 %t783, label %bb181, label %bb182
bb180:
  store i64 0, ptr %l469, !tbaa !24
  br label %bb184
bb181:
  %t785 = load i64, ptr %l63, !tbaa !24
  %t786 = load i64, ptr %l62, !tbaa !24
  %t789 = sub i64 %t785, %t786
  %t790 = load i64, ptr %l64, !tbaa !24
  %t793 = add i64 %t789, %t790
  %t795 = sub i64 %t793, 1
  %t796 = load i64, ptr %l64, !tbaa !24
  %t799 = sdiv i64 %t795, %t796
  store i64 %t799, ptr %l472, !tbaa !24
  br label %bb183
bb182:
  store i64 0, ptr %l472, !tbaa !24
  br label %bb183
bb183:
  %t801 = load i64, ptr %l472, !tbaa !24
  store i64 %t801, ptr %l469, !tbaa !24
  br label %bb184
bb184:
  %t802 = load i64, ptr %l469, !tbaa !24
  store i64 %t802, ptr %l65, !tbaa !24
  store i64 0, ptr %l66, !tbaa !24
  br label %bb185
bb185:
  store %olang.scope zeroinitializer, ptr %s30
  %t803 = load i64, ptr %l66, !tbaa !24
  %t804 = load i64, ptr %l65, !tbaa !24
  %t807 = icmp slt i64 %t803, %t804
  %t809 = xor i1 %t807, true
  br i1 %t809, label %bb186, label %bb187
bb186:
  call void @__olang_scope_close(ptr %s30)
  br label %bb208
bb187:
  br label %bb188
bb188:
  %t811 = load i64, ptr %l62, !tbaa !24
  %t812 = load i64, ptr %l66, !tbaa !24
  %t813 = load i64, ptr %l64, !tbaa !24
  %t816 = mul i64 %t812, %t813
  %t819 = add i64 %t811, %t816
  %t823 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t824 = load ptr, ptr %t823, !tbaa !27
  %t825 = getelementptr i64, ptr %t824, i64 %t819
  %t826 = load i64, ptr %t825, !tbaa !34
  store i64 %t826, ptr %l68, !tbaa !24
  %t828 = load i64, ptr %l58, !tbaa !24
  %t830 = icmp sge i64 %t828, 0
  br i1 %t830, label %bb189, label %bb190
bb189:
  %t832 = load i64, ptr %l68, !tbaa !24
  %t833 = load i64, ptr %l58, !tbaa !24
  %t836 = icmp ne i64 %t832, %t833
  store i1 %t836, ptr %l494, !tbaa !21
  br label %bb191
bb190:
  store i1 false, ptr %l494, !tbaa !21
  br label %bb191
bb191:
  %t838 = load i1, ptr %l494, !tbaa !21
  br i1 %t838, label %bb192, label %bb193
bb192:
  store i1 true, ptr %l498, !tbaa !21
  br label %bb195
bb193:
  %t839 = load ptr, ptr %l1, !tbaa !29
  %t841 = getelementptr %"compiler/free:Free", ptr %t839, i32 0, i32 36
  %t842 = load i64, ptr %l68, !tbaa !24
  %t845 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t841, i64 %t842)
  store i64 %t845, ptr %l502
  br label %bb194
bb194:
  %t846 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t847 = load i64, ptr %l502, !tbaa !24
  %t849 = icmp ne i64 %t847, %t846
  store i1 %t849, ptr %l498, !tbaa !21
  br label %bb195
bb195:
  %t851 = load i1, ptr %l498, !tbaa !21
  br i1 %t851, label %bb196, label %bb197
bb196:
  store i1 true, ptr %l505, !tbaa !21
  br label %bb199
bb197:
  %t852 = load ptr, ptr %l1, !tbaa !29
  %t853 = load i64, ptr %l68, !tbaa !24
  %t856 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t852, i64 %t853)
  store i1 %t856, ptr %l508
  br label %bb198
bb198:
  %t857 = load i1, ptr %l508, !tbaa !21
  store i1 %t857, ptr %l505, !tbaa !21
  br label %bb199
bb199:
  %t858 = load i1, ptr %l505, !tbaa !21
  br i1 %t858, label %bb200, label %bb201
bb200:
  call void @__olang_scope_close(ptr %s30)
  br label %bb207
bb201:
  br label %bb202
bb202:
  %t859 = load ptr, ptr %l1, !tbaa !29
  store ptr %t859, ptr %l509, !tbaa !29
  %t860 = load i64, ptr %l68, !tbaa !24
  store i64 %t860, ptr %l510, !tbaa !24
  %t861 = load ptr, ptr %l2, !tbaa !29
  %t863 = getelementptr %"compiler/typed:Body", ptr %t861, i32 0, i32 3
  %t864 = load i64, ptr %t863, !tbaa !24
  store i64 %t864, ptr %l512, !tbaa !24
  %t865 = load ptr, ptr %l0, !tbaa !29
  %t867 = getelementptr %"compiler/free:walker", ptr %t865, i32 0, i32 39
  %t868 = load i64, ptr %l57, !tbaa !24
  %t871 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t867, i64 %t868)
  store %"compiler/source:Span" %t871, ptr %l516
  br label %bb203
bb203:
  %t872 = load ptr, ptr %l1, !tbaa !29
  store ptr %t872, ptr %l517, !tbaa !29
  %t873 = load ptr, ptr %l2, !tbaa !29
  %t875 = getelementptr %"compiler/typed:Body", ptr %t873, i32 0, i32 3
  %t876 = load i64, ptr %t875, !tbaa !24
  store i64 %t876, ptr %l519, !tbaa !24
  %t877 = load ptr, ptr %l0, !tbaa !29
  %t879 = getelementptr %"compiler/free:walker", ptr %t877, i32 0, i32 39
  %t880 = load i64, ptr %l57, !tbaa !24
  %t883 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t879, i64 %t880)
  store %"compiler/source:Span" %t883, ptr %l523
  br label %bb204
bb204:
  %t884 = load ptr, ptr %l517, !tbaa !29
  %t885 = load i64, ptr %l519, !tbaa !24
  %t886 = load %"compiler/source:Span", ptr %l523
  %t887 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s30, ptr %t884, i64 %t885, %"compiler/source:Span" %t886)
  store { i64, ptr } %t887, ptr %l524
  br label %bb205
bb205:
  %t888 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t889 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t890 = load { i64, ptr }, ptr %l524, !tbaa !27
  %t891 = extractvalue { i64, ptr } %t890, 1
  %t892 = extractvalue { i64, ptr } %t890, 0
  %t893 = add i64 %t889, %t892
  %t894 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t895 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t896 = add i64 %t893, %t895
  %t897 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t896)
  call void @olang_textcopy(ptr %t897, ptr %t888, i64 %t889)
  %t898 = getelementptr i8, ptr %t897, i64 %t889
  call void @olang_textcopy(ptr %t898, ptr %t891, i64 %t892)
  %t899 = getelementptr i8, ptr %t898, i64 %t892
  call void @olang_textcopy(ptr %t899, ptr %t894, i64 %t895)
  %t900 = insertvalue { i64, ptr } undef, i64 %t896, 0
  %t901 = insertvalue { i64, ptr } %t900, ptr %t897, 1
  %t903 = extractvalue { i64, ptr } %t901, 0
  %t904 = extractvalue { i64, ptr } %t901, 1
  %t905 = mul i64 %t903, 1
  %t906 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t905)
  call void @llvm.memcpy.p0.p0.i64(ptr %t906, ptr %t904, i64 %t905, i1 false)
  %t907 = insertvalue { i64, ptr } undef, i64 %t903, 0
  %t908 = insertvalue { i64, ptr } %t907, ptr %t906, 1
  %t909 = load i64, ptr %l61, !tbaa !24
  %t910 = load ptr, ptr %l509, !tbaa !29
  %t911 = load i64, ptr %l510, !tbaa !24
  %t912 = load i64, ptr %l512, !tbaa !24
  %t913 = load %"compiler/source:Span", ptr %l516
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %s30, ptr %t910, i64 %t911, i64 %t912, %"compiler/source:Span" %t913, { i64, ptr } %t908, i64 %t909)
  br label %bb206
bb206:
  call void @__olang_scope_close(ptr %s30)
  br label %bb207
bb207:
  %t916 = load i64, ptr %l66, !tbaa !24
  %t918 = add i64 %t916, 1
  store i64 %t918, ptr %l66, !tbaa !24
  br label %bb185
bb208:
  br label %bb209
bb209:
  store ptr %l23, ptr %l69, !tbaa !29
  store i64 0, ptr %l70, !tbaa !24
  br label %bb210
bb210:
  store %olang.scope zeroinitializer, ptr %s35
  %t921 = load ptr, ptr %l69, !tbaa !29
  %t922 = load i64, ptr %l70, !tbaa !24
  %t925 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t921, i64 %t922)
  %t926 = extractvalue { i32, { i64, ptr } } %t925, 1
  %t927 = extractvalue { i32, { i64, ptr } } %t925, 0
  store i32 %t927, ptr %l535
  %t928 = icmp ne i32 %t927, 0
  br i1 %t928, label %bb212, label %ok.929
ok.929:
  store { i64, ptr } %t926, ptr %l534
  br label %bb211
bb211:
  %t930 = load { i64, ptr }, ptr %l534, !tbaa !27
  store { i64, ptr } %t930, ptr %l531, !tbaa !27
  br label %bb216
bb212:
  %t931 = load i32, ptr %l535, !tbaa !23
  %t932 = ashr i32 %t931, 16
  %t934 = icmp eq i32 %t932, 1
  br i1 %t934, label %bb213, label %bb214
bb213:
  br label %bb215
bb214:
  call void @__olang_check_failed(ptr @olang_loc_be06d4fe1f669970_91dc6d2622a64d44)
  unreachable
bb215:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s35)
  br label %bb343
bb216:
  %t936 = load { i64, ptr }, ptr %l531, !tbaa !27
  store { i64, ptr } %t936, ptr %l71, !tbaa !27
  %t937 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t939 = extractvalue { i64, ptr } %t937, 0
  store i64 %t939, ptr %l72, !tbaa !24
  store i64 0, ptr %l73, !tbaa !24
  br label %bb217
bb217:
  store %olang.scope zeroinitializer, ptr %s36
  %t941 = load i64, ptr %l73, !tbaa !24
  %t942 = load i64, ptr %l72, !tbaa !24
  %t945 = icmp slt i64 %t941, %t942
  %t947 = xor i1 %t945, true
  br i1 %t947, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s36)
  br label %bb341
bb219:
  br label %bb220
bb220:
  %t949 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t949, ptr %l544, !tbaa !27
  %t950 = load i64, ptr %l73, !tbaa !24
  %t952 = getelementptr { i64, ptr }, ptr %l544, i32 0, i32 1
  %t953 = load ptr, ptr %t952, !tbaa !27
  %t954 = getelementptr i64, ptr %t953, i64 %t950
  %t955 = load i64, ptr %t954, !tbaa !34
  store i64 %t955, ptr %l74, !tbaa !24
  store i1 false, ptr %l75, !tbaa !21
  %t957 = load i64, ptr %l74, !tbaa !24
  %t960 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %s0, ptr %s0, ptr %l3, i64 %t957)
  store ptr %t960, ptr %l549
  br label %bb221
bb221:
  %t961 = load ptr, ptr %l549, !tbaa !29
  store ptr %t961, ptr %l76, !tbaa !29
  store i64 0, ptr %l77, !tbaa !24
  br label %bb222
bb222:
  store %olang.scope zeroinitializer, ptr %s38
  %t962 = load ptr, ptr %l76, !tbaa !29
  %t963 = load i64, ptr %l77, !tbaa !24
  %t966 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t962, i64 %t963)
  %t967 = extractvalue { i32, { i64, ptr } } %t966, 1
  %t968 = extractvalue { i32, { i64, ptr } } %t966, 0
  store i32 %t968, ptr %l554
  %t969 = icmp ne i32 %t968, 0
  br i1 %t969, label %bb224, label %ok.970
ok.970:
  store { i64, ptr } %t967, ptr %l553
  br label %bb223
bb223:
  %t971 = load { i64, ptr }, ptr %l553, !tbaa !27
  store { i64, ptr } %t971, ptr %l550, !tbaa !27
  br label %bb228
bb224:
  %t972 = load i32, ptr %l554, !tbaa !23
  %t973 = ashr i32 %t972, 16
  %t975 = icmp eq i32 %t973, 1
  br i1 %t975, label %bb225, label %bb226
bb225:
  br label %bb227
bb226:
  call void @__olang_check_failed(ptr @olang_loc_bc199299ca123d01_d246cbf06301dc35)
  unreachable
bb227:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s38)
  br label %bb250
bb228:
  %t977 = load { i64, ptr }, ptr %l550, !tbaa !27
  store { i64, ptr } %t977, ptr %l78, !tbaa !27
  %t978 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t980 = extractvalue { i64, ptr } %t978, 0
  store i64 %t980, ptr %l79, !tbaa !24
  store i64 0, ptr %l80, !tbaa !24
  br label %bb229
bb229:
  store %olang.scope zeroinitializer, ptr %s39
  %t982 = load i64, ptr %l80, !tbaa !24
  %t983 = load i64, ptr %l79, !tbaa !24
  %t986 = icmp slt i64 %t982, %t983
  %t988 = xor i1 %t986, true
  br i1 %t988, label %bb230, label %bb231
bb230:
  call void @__olang_scope_close(ptr %s39)
  br label %bb248
bb231:
  br label %bb232
bb232:
  %t990 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t990, ptr %l563, !tbaa !27
  %t991 = load i64, ptr %l80, !tbaa !24
  %t993 = getelementptr { i64, ptr }, ptr %l563, i32 0, i32 1
  %t994 = load ptr, ptr %t993, !tbaa !27
  %t995 = getelementptr i64, ptr %t994, i64 %t991
  %t996 = load i64, ptr %t995, !tbaa !34
  store i64 %t996, ptr %l81, !tbaa !24
  %t998 = load i64, ptr %l58, !tbaa !24
  %t1000 = icmp slt i64 %t998, 0
  br i1 %t1000, label %bb233, label %bb234
bb233:
  store i1 true, ptr %l568, !tbaa !21
  br label %bb235
bb234:
  %t1002 = load i64, ptr %l81, !tbaa !24
  %t1003 = load i64, ptr %l58, !tbaa !24
  %t1006 = icmp eq i64 %t1002, %t1003
  store i1 %t1006, ptr %l568, !tbaa !21
  br label %bb235
bb235:
  %t1008 = load i1, ptr %l568, !tbaa !21
  br i1 %t1008, label %bb236, label %bb237
bb236:
  %t1009 = load ptr, ptr %l1, !tbaa !29
  %t1011 = getelementptr %"compiler/free:Free", ptr %t1009, i32 0, i32 36
  %t1012 = load i64, ptr %l81, !tbaa !24
  %t1015 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t1011, i64 %t1012)
  store i64 %t1015, ptr %l576
  br label %bb238
bb237:
  store i1 false, ptr %l572, !tbaa !21
  br label %bb239
bb238:
  %t1016 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t1017 = load i64, ptr %l576, !tbaa !24
  %t1019 = icmp eq i64 %t1017, %t1016
  store i1 %t1019, ptr %l572, !tbaa !21
  br label %bb239
bb239:
  %t1021 = load i1, ptr %l572, !tbaa !21
  br i1 %t1021, label %bb240, label %bb241
bb240:
  %t1022 = load ptr, ptr %l1, !tbaa !29
  %t1023 = load i64, ptr %l81, !tbaa !24
  %t1026 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t1022, i64 %t1023)
  store i1 %t1026, ptr %l582
  br label %bb242
bb241:
  store i1 false, ptr %l579, !tbaa !21
  br label %bb243
bb242:
  %t1027 = load i1, ptr %l582, !tbaa !21
  %t1028 = xor i1 %t1027, true
  store i1 %t1028, ptr %l579, !tbaa !21
  br label %bb243
bb243:
  %t1030 = load i1, ptr %l579, !tbaa !21
  br i1 %t1030, label %bb244, label %bb245
bb244:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb246
bb245:
  br label %bb246
bb246:
  call void @__olang_scope_close(ptr %s39)
  br label %bb247
bb247:
  %t1031 = load i64, ptr %l80, !tbaa !24
  %t1033 = add i64 %t1031, 1
  store i64 %t1033, ptr %l80, !tbaa !24
  br label %bb229
bb248:
  %t1035 = load i64, ptr %l77, !tbaa !24
  %t1036 = load i64, ptr %l79, !tbaa !24
  %t1039 = add i64 %t1035, %t1036
  store i64 %t1039, ptr %l77, !tbaa !24
  call void @__olang_scope_close(ptr %s38)
  br label %bb249
bb249:
  br label %bb222
bb250:
  %t1041 = load i1, ptr %l75, !tbaa !21
  %t1043 = xor i1 %t1041, true
  br i1 %t1043, label %bb251, label %bb252
bb251:
  call void @__olang_scope_close(ptr %s36)
  br label %bb340
bb252:
  br label %bb253
bb253:
  %t1045 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1045, ptr %l591, !tbaa !29
  %t1046 = load i64, ptr %l74, !tbaa !24
  store i64 %t1046, ptr %l592, !tbaa !24
  %t1047 = load i64, ptr %l59, !tbaa !24
  store i64 %t1047, ptr %l593, !tbaa !24
  %t1048 = load i64, ptr %l74, !tbaa !24
  %t1051 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %s0, ptr %s0, ptr %l4, i64 %t1048)
  store ptr %t1051, ptr %l596
  br label %bb254
bb254:
  %t1052 = load ptr, ptr %l591, !tbaa !29
  %t1053 = load i64, ptr %l592, !tbaa !24
  %t1054 = load i64, ptr %l593, !tbaa !24
  %t1055 = load ptr, ptr %l596, !tbaa !29
  %t1056 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %s0, ptr %t1052, i64 %t1053, i64 %t1054, ptr %t1055)
  store i64 %t1056, ptr %l597
  br label %bb255
bb255:
  %t1057 = load i64, ptr %l597, !tbaa !24
  store i64 %t1057, ptr %l82, !tbaa !24
  %t1058 = load i64, ptr %l82, !tbaa !24
  %t1060 = icmp slt i64 %t1058, 0
  br i1 %t1060, label %bb256, label %bb257
bb256:
  call void @__olang_scope_close(ptr %s36)
  br label %bb340
bb257:
  br label %bb258
bb258:
  %t1062 = load ptr, ptr %l1, !tbaa !29
  %t1064 = getelementptr %"compiler/free:Free", ptr %t1062, i32 0, i32 0
  %t1065 = load ptr, ptr %t1064, !tbaa !29
  %t1067 = getelementptr %"compiler/generic:Program", ptr %t1065, i32 0, i32 0
  %t1068 = load ptr, ptr %t1067, !tbaa !29
  %t1070 = getelementptr %"compiler/load:Loader", ptr %t1068, i32 0, i32 3
  %t1071 = load ptr, ptr %t1070, !tbaa !29
  store ptr %t1071, ptr %l603, !tbaa !29
  %t1072 = load ptr, ptr %l2, !tbaa !29
  %t1074 = getelementptr %"compiler/typed:Body", ptr %t1072, i32 0, i32 7
  %t1075 = load i64, ptr %l74, !tbaa !24
  %t1078 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t1074, i64 %t1075)
  store %"compiler/typed:Local" %t1078, ptr %l607
  br label %bb259
bb259:
  %t1079 = getelementptr %"compiler/typed:Local", ptr %l607, i32 0, i32 0
  %t1080 = load i32, ptr %t1079, !tbaa !23
  %t1081 = load ptr, ptr %l603, !tbaa !29
  %t1083 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t1081, i32 %t1080)
  store { i64, ptr } %t1083, ptr %l609
  br label %bb260
bb260:
  %t1084 = load { i64, ptr }, ptr %l609, !tbaa !27
  store { i64, ptr } %t1084, ptr %l83, !tbaa !27
  %t1085 = load ptr, ptr %l1, !tbaa !29
  %t1087 = getelementptr %"compiler/free:Free", ptr %t1085, i32 0, i32 0
  %t1088 = load ptr, ptr %t1087, !tbaa !29
  %t1090 = getelementptr %"compiler/generic:Program", ptr %t1088, i32 0, i32 0
  %t1091 = load ptr, ptr %t1090, !tbaa !29
  %t1093 = getelementptr %"compiler/load:Loader", ptr %t1091, i32 0, i32 4
  %t1094 = load ptr, ptr %t1093, !tbaa !29
  store ptr %t1094, ptr %l613, !tbaa !29
  %t1095 = load ptr, ptr %l2, !tbaa !29
  %t1097 = getelementptr %"compiler/typed:Body", ptr %t1095, i32 0, i32 3
  %t1098 = load i64, ptr %t1097, !tbaa !24
  store i64 %t1098, ptr %l615, !tbaa !24
  %t1099 = load ptr, ptr %l2, !tbaa !29
  %t1101 = getelementptr %"compiler/typed:Body", ptr %t1099, i32 0, i32 7
  %t1102 = load i64, ptr %l74, !tbaa !24
  %t1105 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t1101, i64 %t1102)
  store %"compiler/typed:Local" %t1105, ptr %l619
  br label %bb261
bb261:
  %t1106 = getelementptr %"compiler/typed:Local", ptr %l619, i32 0, i32 1
  %t1107 = getelementptr %"compiler/source:Span", ptr %t1106, i32 0, i32 0
  %t1108 = load i32, ptr %t1107, !tbaa !23
  %t1110 = sext i32 %t1108 to i64
  %t1111 = load ptr, ptr %l613, !tbaa !29
  %t1112 = load i64, ptr %l615, !tbaa !24
  %t1114 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t1111, i64 %t1112, i64 %t1110)
  store i64 %t1114, ptr %l622
  br label %bb262
bb262:
  %t1115 = load i64, ptr %l622, !tbaa !24
  store i64 %t1115, ptr %l84, !tbaa !24
  %t1116 = load ptr, ptr %l1, !tbaa !29
  %t1118 = getelementptr %"compiler/free:Free", ptr %t1116, i32 0, i32 0
  %t1119 = load ptr, ptr %t1118, !tbaa !29
  %t1121 = getelementptr %"compiler/generic:Program", ptr %t1119, i32 0, i32 0
  %t1122 = load ptr, ptr %t1121, !tbaa !29
  %t1124 = getelementptr %"compiler/load:Loader", ptr %t1122, i32 0, i32 4
  %t1125 = load ptr, ptr %t1124, !tbaa !29
  store ptr %t1125, ptr %l626, !tbaa !29
  %t1126 = load ptr, ptr %l2, !tbaa !29
  %t1128 = getelementptr %"compiler/typed:Body", ptr %t1126, i32 0, i32 3
  %t1129 = load i64, ptr %t1128, !tbaa !24
  store i64 %t1129, ptr %l628, !tbaa !24
  %t1130 = load ptr, ptr %l0, !tbaa !29
  %t1132 = getelementptr %"compiler/free:walker", ptr %t1130, i32 0, i32 39
  %t1133 = load i64, ptr %l57, !tbaa !24
  %t1136 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1132, i64 %t1133)
  store %"compiler/source:Span" %t1136, ptr %l632
  br label %bb263
bb263:
  %t1137 = getelementptr %"compiler/source:Span", ptr %l632, i32 0, i32 0
  %t1138 = load i32, ptr %t1137, !tbaa !23
  %t1140 = sext i32 %t1138 to i64
  %t1141 = load ptr, ptr %l626, !tbaa !29
  %t1142 = load i64, ptr %l628, !tbaa !24
  %t1144 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t1141, i64 %t1142, i64 %t1140)
  store i64 %t1144, ptr %l635
  br label %bb264
bb264:
  %t1145 = load i64, ptr %l635, !tbaa !24
  store i64 %t1145, ptr %l85, !tbaa !24
  %t1146 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1147 = load i64, ptr %l84, !tbaa !24
  %t1148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t1149 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t1151 = extractvalue { i64, ptr } %t1146, 1
  %t1152 = extractvalue { i64, ptr } %t1146, 0
  %t1153 = add i64 %t1149, %t1152
  %t1154 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 1
  %t1155 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d83, i32 0, i32 1) }, 0
  %t1156 = add i64 %t1153, %t1155
  %t1158 = call i64 @__olang_fmt_i64(ptr null, i64 %t1147)
  %t1159 = add i64 %t1156, %t1158
  %t1160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 1
  %t1161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, 0
  %t1162 = add i64 %t1159, %t1161
  %t1163 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1162)
  call void @olang_textcopy(ptr %t1163, ptr %t1148, i64 %t1149)
  %t1164 = getelementptr i8, ptr %t1163, i64 %t1149
  call void @olang_textcopy(ptr %t1164, ptr %t1151, i64 %t1152)
  %t1165 = getelementptr i8, ptr %t1164, i64 %t1152
  call void @olang_textcopy(ptr %t1165, ptr %t1154, i64 %t1155)
  %t1166 = getelementptr i8, ptr %t1165, i64 %t1155
  %t1167 = call i64 @__olang_fmt_i64(ptr %t1166, i64 %t1147)
  %t1168 = getelementptr i8, ptr %t1166, i64 %t1158
  call void @olang_textcopy(ptr %t1168, ptr %t1160, i64 %t1161)
  %t1169 = insertvalue { i64, ptr } undef, i64 %t1162, 0
  %t1170 = insertvalue { i64, ptr } %t1169, ptr %t1163, 1
  store { i64, ptr } %t1170, ptr %l86, !tbaa !27
  %t1172 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1173 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t1174 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t1176 = extractvalue { i64, ptr } %t1172, 1
  %t1177 = extractvalue { i64, ptr } %t1172, 0
  %t1178 = add i64 %t1174, %t1177
  %t1179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t1180 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t1181 = add i64 %t1178, %t1180
  %t1182 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1181)
  call void @olang_textcopy(ptr %t1182, ptr %t1173, i64 %t1174)
  %t1183 = getelementptr i8, ptr %t1182, i64 %t1174
  call void @olang_textcopy(ptr %t1183, ptr %t1176, i64 %t1177)
  %t1184 = getelementptr i8, ptr %t1183, i64 %t1177
  call void @olang_textcopy(ptr %t1184, ptr %t1179, i64 %t1180)
  %t1185 = insertvalue { i64, ptr } undef, i64 %t1181, 0
  %t1186 = insertvalue { i64, ptr } %t1185, ptr %t1182, 1
  store { i64, ptr } %t1186, ptr %l87, !tbaa !27
  %t1188 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t1190 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s36, { i64, ptr } %t1188, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t1190, ptr %l642
  br label %bb265
bb265:
  %t1191 = load i1, ptr %l642, !tbaa !21
  br i1 %t1191, label %bb266, label %bb267
bb266:
  store %olang.scope zeroinitializer, ptr %s46
  %t1192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1192, ptr %l643, !tbaa !29
  %t1193 = load ptr, ptr %l2, !tbaa !29
  %t1195 = getelementptr %"compiler/typed:Body", ptr %t1193, i32 0, i32 3
  %t1196 = load i64, ptr %t1195, !tbaa !24
  store i64 %t1196, ptr %l645, !tbaa !24
  %t1197 = load ptr, ptr %l0, !tbaa !29
  %t1199 = getelementptr %"compiler/free:walker", ptr %t1197, i32 0, i32 21
  %t1200 = load i64, ptr %l74, !tbaa !24
  %t1203 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1199, i64 %t1200)
  store %"compiler/source:Span" %t1203, ptr %l649
  br label %bb268
bb267:
  br label %bb284
bb268:
  %t1204 = load ptr, ptr %l643, !tbaa !29
  %t1205 = load i64, ptr %l645, !tbaa !24
  %t1206 = load %"compiler/source:Span", ptr %l649
  %t1207 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s46, ptr %t1204, i64 %t1205, %"compiler/source:Span" %t1206)
  store { i64, ptr } %t1207, ptr %l650
  br label %bb269
bb269:
  %t1208 = load { i64, ptr }, ptr %l650, !tbaa !27
  store { i64, ptr } %t1208, ptr %l88, !tbaa !27
  %t1209 = load i64, ptr %l84, !tbaa !24
  store i64 %t1209, ptr %l651, !tbaa !24
  %t1210 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t1212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s46, ptr %s46, { i64, ptr } %t1210, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d88, i32 0, i32 1) })
  store i1 %t1212, ptr %l653
  br label %bb270
bb270:
  %t1213 = load i1, ptr %l653, !tbaa !21
  %t1214 = xor i1 %t1213, true
  br i1 %t1214, label %bb271, label %bb272
bb271:
  %t1216 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d89, i32 0, i32 1) }, ptr %l657, !tbaa !27
  %t1218 = load { i64, ptr }, ptr %l657, !tbaa !27
  %t1219 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s46, ptr %s46, { i64, ptr } %t1216, { i64, ptr } %t1218)
  store i1 %t1219, ptr %l658
  br label %bb273
bb272:
  store i1 false, ptr %l655, !tbaa !21
  br label %bb274
bb273:
  %t1220 = load i1, ptr %l658, !tbaa !21
  %t1221 = xor i1 %t1220, true
  store i1 %t1221, ptr %l655, !tbaa !21
  br label %bb274
bb274:
  %t1223 = load i1, ptr %l655, !tbaa !21
  br i1 %t1223, label %bb275, label %bb276
bb275:
  %t1224 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t1225 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t1226 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t1228 = extractvalue { i64, ptr } %t1224, 1
  %t1229 = extractvalue { i64, ptr } %t1224, 0
  %t1230 = add i64 %t1226, %t1229
  %t1231 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t1232 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t1233 = add i64 %t1230, %t1232
  %t1234 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1233)
  call void @olang_textcopy(ptr %t1234, ptr %t1225, i64 %t1226)
  %t1235 = getelementptr i8, ptr %t1234, i64 %t1226
  call void @olang_textcopy(ptr %t1235, ptr %t1228, i64 %t1229)
  %t1236 = getelementptr i8, ptr %t1235, i64 %t1229
  call void @olang_textcopy(ptr %t1236, ptr %t1231, i64 %t1232)
  %t1237 = insertvalue { i64, ptr } undef, i64 %t1233, 0
  %t1238 = insertvalue { i64, ptr } %t1237, ptr %t1234, 1
  %t1240 = extractvalue { i64, ptr } %t1238, 0
  %t1241 = extractvalue { i64, ptr } %t1238, 1
  %t1242 = mul i64 %t1240, 1
  %t1243 = call ptr @__olang_scope_alloc(ptr %s46, i64 %t1242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1243, ptr %t1241, i64 %t1242, i1 false)
  %t1244 = insertvalue { i64, ptr } undef, i64 %t1240, 0
  %t1245 = insertvalue { i64, ptr } %t1244, ptr %t1243, 1
  store { i64, ptr } %t1245, ptr %l660, !tbaa !27
  br label %bb277
bb276:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l660, !tbaa !27
  br label %bb277
bb277:
  %t1247 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t1248 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t1249 = load i64, ptr %l651, !tbaa !24
  %t1250 = call i64 @__olang_fmt_i64(ptr null, i64 %t1249)
  %t1251 = add i64 %t1248, %t1250
  %t1252 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t1253 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t1254 = add i64 %t1251, %t1253
  %t1255 = load { i64, ptr }, ptr %l660, !tbaa !27
  %t1256 = extractvalue { i64, ptr } %t1255, 1
  %t1257 = extractvalue { i64, ptr } %t1255, 0
  %t1258 = add i64 %t1254, %t1257
  %t1259 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1258)
  call void @olang_textcopy(ptr %t1259, ptr %t1247, i64 %t1248)
  %t1260 = getelementptr i8, ptr %t1259, i64 %t1248
  %t1261 = call i64 @__olang_fmt_i64(ptr %t1260, i64 %t1249)
  %t1262 = getelementptr i8, ptr %t1260, i64 %t1250
  call void @olang_textcopy(ptr %t1262, ptr %t1252, i64 %t1253)
  %t1263 = getelementptr i8, ptr %t1262, i64 %t1253
  call void @olang_textcopy(ptr %t1263, ptr %t1256, i64 %t1257)
  %t1264 = insertvalue { i64, ptr } undef, i64 %t1258, 0
  %t1265 = insertvalue { i64, ptr } %t1264, ptr %t1259, 1
  store { i64, ptr } %t1265, ptr %l664, !tbaa !27
  %t1266 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t1267 = extractvalue { i64, ptr } %t1266, 0
  %t1268 = load { i64, ptr }, ptr %l664, !tbaa !27
  %t1269 = extractvalue { i64, ptr } %t1268, 0
  store i64 %t1269, ptr %l666, !tbaa !24
  %t1271 = load i64, ptr %l666, !tbaa !24
  %t1272 = icmp eq i64 %t1267, %t1271
  br i1 %t1272, label %bb278, label %bb279
bb278:
  %t1274 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t1275 = load ptr, ptr %t1274, !tbaa !27
  %t1276 = getelementptr { i64, ptr }, ptr %l664, i32 0, i32 1
  %t1277 = load ptr, ptr %t1276, !tbaa !27
  %t1278 = load i64, ptr %l666, !tbaa !24
  %t1279 = mul i64 %t1278, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1275, ptr %t1277, i64 %t1279, i1 false)
  br label %bb280
bb279:
  %t1280 = load { i64, ptr }, ptr %l664, !tbaa !27
  store { i64, ptr } %t1280, ptr %l86, !tbaa !27
  br label %bb280
bb280:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l668, !tbaa !27
  %t1281 = load { i64, ptr }, ptr %l668, !tbaa !27
  store { i64, ptr } %t1281, ptr %l669, !tbaa !27
  %t1282 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1283 = extractvalue { i64, ptr } %t1282, 0
  %t1284 = load { i64, ptr }, ptr %l669, !tbaa !27
  %t1285 = extractvalue { i64, ptr } %t1284, 0
  store i64 %t1285, ptr %l671, !tbaa !24
  %t1287 = load i64, ptr %l671, !tbaa !24
  %t1288 = icmp eq i64 %t1283, %t1287
  br i1 %t1288, label %bb281, label %bb282
bb281:
  %t1290 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t1291 = load ptr, ptr %t1290, !tbaa !27
  %t1292 = getelementptr { i64, ptr }, ptr %l669, i32 0, i32 1
  %t1293 = load ptr, ptr %t1292, !tbaa !27
  %t1294 = load i64, ptr %l671, !tbaa !24
  %t1295 = mul i64 %t1294, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1291, ptr %t1293, i64 %t1295, i1 false)
  br label %bb283
bb282:
  %t1296 = load { i64, ptr }, ptr %l669, !tbaa !27
  %t1297 = extractvalue { i64, ptr } %t1296, 0
  store i64 %t1297, ptr %l673, !tbaa !24
  %t1298 = load i64, ptr %l673, !tbaa !24
  %t1299 = mul i64 %t1298, 1
  %t1300 = call ptr @__olang_scope_alloc_zeroed(ptr %s36, i64 %t1299)
  %t1301 = insertvalue { i64, ptr } undef, i64 %t1298, 0
  %t1302 = insertvalue { i64, ptr } %t1301, ptr %t1300, 1
  store { i64, ptr } %t1302, ptr %l674, !tbaa !27
  %t1303 = getelementptr { i64, ptr }, ptr %l674, i32 0, i32 1
  %t1304 = load ptr, ptr %t1303, !tbaa !27
  %t1305 = getelementptr { i64, ptr }, ptr %l669, i32 0, i32 1
  %t1306 = load ptr, ptr %t1305, !tbaa !27
  %t1307 = load i64, ptr %l673, !tbaa !24
  %t1308 = mul i64 %t1307, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1304, ptr %t1306, i64 %t1308, i1 false)
  %t1309 = load { i64, ptr }, ptr %l674, !tbaa !27
  store { i64, ptr } %t1309, ptr %l87, !tbaa !27
  br label %bb283
bb283:
  call void @__olang_scope_close(ptr %s46)
  br label %bb284
bb284:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) }, ptr %l675, !tbaa !27
  %t1310 = load { i64, ptr }, ptr %l675, !tbaa !27
  store { i64, ptr } %t1310, ptr %l676, !tbaa !27
  %t1311 = load { i64, ptr }, ptr %l676, !tbaa !27
  %t1312 = extractvalue { i64, ptr } %t1311, 0
  store i64 %t1312, ptr %l677, !tbaa !24
  %t1313 = load i64, ptr %l677, !tbaa !24
  %t1314 = mul i64 %t1313, 1
  %t1315 = call ptr @__olang_scope_alloc_zeroed(ptr %s36, i64 %t1314)
  %t1316 = insertvalue { i64, ptr } undef, i64 %t1313, 0
  %t1317 = insertvalue { i64, ptr } %t1316, ptr %t1315, 1
  store { i64, ptr } %t1317, ptr %l678, !tbaa !27
  %t1318 = getelementptr { i64, ptr }, ptr %l678, i32 0, i32 1
  %t1319 = load ptr, ptr %t1318, !tbaa !27
  %t1320 = getelementptr { i64, ptr }, ptr %l676, i32 0, i32 1
  %t1321 = load ptr, ptr %t1320, !tbaa !27
  %t1322 = load i64, ptr %l677, !tbaa !24
  %t1323 = mul i64 %t1322, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1319, ptr %t1321, i64 %t1323, i1 false)
  %t1324 = load { i64, ptr }, ptr %l678, !tbaa !27
  store { i64, ptr } %t1324, ptr %l89, !tbaa !27
  %t1325 = load i64, ptr %l60, !tbaa !24
  %t1326 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  %t1329 = icmp eq i64 %t1325, %t1326
  br i1 %t1329, label %bb285, label %bb286
bb285:
  store %olang.scope zeroinitializer, ptr %s49
  %t1331 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1331, ptr %l682, !tbaa !29
  %t1332 = load ptr, ptr %l2, !tbaa !29
  %t1334 = getelementptr %"compiler/typed:Body", ptr %t1332, i32 0, i32 3
  %t1335 = load i64, ptr %t1334, !tbaa !24
  store i64 %t1335, ptr %l684, !tbaa !24
  %t1336 = load ptr, ptr %l0, !tbaa !29
  %t1338 = getelementptr %"compiler/free:walker", ptr %t1336, i32 0, i32 39
  %t1339 = load i64, ptr %l57, !tbaa !24
  %t1342 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1338, i64 %t1339)
  store %"compiler/source:Span" %t1342, ptr %l688
  br label %bb287
bb286:
  %t1343 = load i64, ptr %l60, !tbaa !24
  %t1344 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t1347 = icmp eq i64 %t1343, %t1344
  br i1 %t1347, label %bb292, label %bb293
bb287:
  %t1349 = load ptr, ptr %l682, !tbaa !29
  %t1350 = load i64, ptr %l684, !tbaa !24
  %t1351 = load %"compiler/source:Span", ptr %l688
  %t1352 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s49, ptr %t1349, i64 %t1350, %"compiler/source:Span" %t1351)
  store { i64, ptr } %t1352, ptr %l689
  br label %bb288
bb288:
  %t1353 = load i64, ptr %l85, !tbaa !24
  %t1354 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1355 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t1356 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t1357 = load { i64, ptr }, ptr %l689, !tbaa !27
  %t1358 = extractvalue { i64, ptr } %t1357, 1
  %t1359 = extractvalue { i64, ptr } %t1357, 0
  %t1360 = add i64 %t1356, %t1359
  %t1361 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t1362 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t1363 = add i64 %t1360, %t1362
  %t1365 = call i64 @__olang_fmt_i64(ptr null, i64 %t1353)
  %t1366 = add i64 %t1363, %t1365
  %t1367 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t1368 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t1369 = add i64 %t1366, %t1368
  %t1371 = extractvalue { i64, ptr } %t1354, 1
  %t1372 = extractvalue { i64, ptr } %t1354, 0
  %t1373 = add i64 %t1369, %t1372
  %t1374 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t1375 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t1376 = add i64 %t1373, %t1375
  %t1377 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1376)
  call void @olang_textcopy(ptr %t1377, ptr %t1355, i64 %t1356)
  %t1378 = getelementptr i8, ptr %t1377, i64 %t1356
  call void @olang_textcopy(ptr %t1378, ptr %t1358, i64 %t1359)
  %t1379 = getelementptr i8, ptr %t1378, i64 %t1359
  call void @olang_textcopy(ptr %t1379, ptr %t1361, i64 %t1362)
  %t1380 = getelementptr i8, ptr %t1379, i64 %t1362
  %t1381 = call i64 @__olang_fmt_i64(ptr %t1380, i64 %t1353)
  %t1382 = getelementptr i8, ptr %t1380, i64 %t1365
  call void @olang_textcopy(ptr %t1382, ptr %t1367, i64 %t1368)
  %t1383 = getelementptr i8, ptr %t1382, i64 %t1368
  call void @olang_textcopy(ptr %t1383, ptr %t1371, i64 %t1372)
  %t1384 = getelementptr i8, ptr %t1383, i64 %t1372
  call void @olang_textcopy(ptr %t1384, ptr %t1374, i64 %t1375)
  %t1385 = insertvalue { i64, ptr } undef, i64 %t1376, 0
  %t1386 = insertvalue { i64, ptr } %t1385, ptr %t1377, 1
  store { i64, ptr } %t1386, ptr %l692, !tbaa !27
  %t1387 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t1388 = extractvalue { i64, ptr } %t1387, 0
  %t1389 = load { i64, ptr }, ptr %l692, !tbaa !27
  %t1390 = extractvalue { i64, ptr } %t1389, 0
  store i64 %t1390, ptr %l694, !tbaa !24
  %t1392 = load i64, ptr %l694, !tbaa !24
  %t1393 = icmp eq i64 %t1388, %t1392
  br i1 %t1393, label %bb289, label %bb290
bb289:
  %t1395 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t1396 = load ptr, ptr %t1395, !tbaa !27
  %t1397 = getelementptr { i64, ptr }, ptr %l692, i32 0, i32 1
  %t1398 = load ptr, ptr %t1397, !tbaa !27
  %t1399 = load i64, ptr %l694, !tbaa !24
  %t1400 = mul i64 %t1399, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1396, ptr %t1398, i64 %t1400, i1 false)
  br label %bb291
bb290:
  %t1401 = load { i64, ptr }, ptr %l692, !tbaa !27
  store { i64, ptr } %t1401, ptr %l89, !tbaa !27
  br label %bb291
bb291:
  call void @__olang_scope_close(ptr %s49)
  br label %bb304
bb292:
  store %olang.scope zeroinitializer, ptr %s52
  %t1402 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1402, ptr %l699, !tbaa !29
  %t1403 = load ptr, ptr %l2, !tbaa !29
  %t1405 = getelementptr %"compiler/typed:Body", ptr %t1403, i32 0, i32 3
  %t1406 = load i64, ptr %t1405, !tbaa !24
  store i64 %t1406, ptr %l701, !tbaa !24
  %t1407 = load ptr, ptr %l0, !tbaa !29
  %t1409 = getelementptr %"compiler/free:walker", ptr %t1407, i32 0, i32 39
  %t1410 = load i64, ptr %l57, !tbaa !24
  %t1413 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1409, i64 %t1410)
  store %"compiler/source:Span" %t1413, ptr %l705
  br label %bb294
bb293:
  %t1414 = load i64, ptr %l85, !tbaa !24
  %t1415 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1416 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t1417 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t1419 = call i64 @__olang_fmt_i64(ptr null, i64 %t1414)
  %t1420 = add i64 %t1417, %t1419
  %t1421 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t1422 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t1423 = add i64 %t1420, %t1422
  %t1425 = extractvalue { i64, ptr } %t1415, 1
  %t1426 = extractvalue { i64, ptr } %t1415, 0
  %t1427 = add i64 %t1423, %t1426
  %t1428 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t1429 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t1430 = add i64 %t1427, %t1429
  %t1431 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1430)
  call void @olang_textcopy(ptr %t1431, ptr %t1416, i64 %t1417)
  %t1432 = getelementptr i8, ptr %t1431, i64 %t1417
  %t1433 = call i64 @__olang_fmt_i64(ptr %t1432, i64 %t1414)
  %t1434 = getelementptr i8, ptr %t1432, i64 %t1419
  call void @olang_textcopy(ptr %t1434, ptr %t1421, i64 %t1422)
  %t1435 = getelementptr i8, ptr %t1434, i64 %t1422
  call void @olang_textcopy(ptr %t1435, ptr %t1425, i64 %t1426)
  %t1436 = getelementptr i8, ptr %t1435, i64 %t1426
  call void @olang_textcopy(ptr %t1436, ptr %t1428, i64 %t1429)
  %t1437 = insertvalue { i64, ptr } undef, i64 %t1430, 0
  %t1438 = insertvalue { i64, ptr } %t1437, ptr %t1431, 1
  store { i64, ptr } %t1438, ptr %l718, !tbaa !27
  %t1439 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t1440 = extractvalue { i64, ptr } %t1439, 0
  %t1441 = load { i64, ptr }, ptr %l718, !tbaa !27
  %t1442 = extractvalue { i64, ptr } %t1441, 0
  store i64 %t1442, ptr %l720, !tbaa !24
  %t1444 = load i64, ptr %l720, !tbaa !24
  %t1445 = icmp eq i64 %t1440, %t1444
  br i1 %t1445, label %bb300, label %bb301
bb294:
  %t1447 = load ptr, ptr %l699, !tbaa !29
  %t1448 = load i64, ptr %l701, !tbaa !24
  %t1449 = load %"compiler/source:Span", ptr %l705
  %t1450 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s52, ptr %t1447, i64 %t1448, %"compiler/source:Span" %t1449)
  store { i64, ptr } %t1450, ptr %l706
  br label %bb295
bb295:
  %t1451 = load i64, ptr %l85, !tbaa !24
  store i64 %t1451, ptr %l707, !tbaa !24
  %t1452 = load ptr, ptr %l0, !tbaa !29
  %t1453 = load i64, ptr %l58, !tbaa !24
  %t1456 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %s52, ptr %t1452, i64 %t1453)
  store { i64, ptr } %t1456, ptr %l710
  br label %bb296
bb296:
  %t1457 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t1458 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t1459 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t1460 = load { i64, ptr }, ptr %l706, !tbaa !27
  %t1461 = extractvalue { i64, ptr } %t1460, 1
  %t1462 = extractvalue { i64, ptr } %t1460, 0
  %t1463 = add i64 %t1459, %t1462
  %t1464 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t1465 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t1466 = add i64 %t1463, %t1465
  %t1467 = load i64, ptr %l707, !tbaa !24
  %t1468 = call i64 @__olang_fmt_i64(ptr null, i64 %t1467)
  %t1469 = add i64 %t1466, %t1468
  %t1470 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t1471 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t1472 = add i64 %t1469, %t1471
  %t1473 = load { i64, ptr }, ptr %l710, !tbaa !27
  %t1474 = extractvalue { i64, ptr } %t1473, 1
  %t1475 = extractvalue { i64, ptr } %t1473, 0
  %t1476 = add i64 %t1472, %t1475
  %t1477 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, 1
  %t1478 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d107, i32 0, i32 1) }, 0
  %t1479 = add i64 %t1476, %t1478
  %t1481 = extractvalue { i64, ptr } %t1457, 1
  %t1482 = extractvalue { i64, ptr } %t1457, 0
  %t1483 = add i64 %t1479, %t1482
  %t1484 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d108, i32 0, i32 1) }, 1
  %t1485 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d108, i32 0, i32 1) }, 0
  %t1486 = add i64 %t1483, %t1485
  %t1487 = call ptr @__olang_scope_alloc(ptr %s36, i64 %t1486)
  call void @olang_textcopy(ptr %t1487, ptr %t1458, i64 %t1459)
  %t1488 = getelementptr i8, ptr %t1487, i64 %t1459
  call void @olang_textcopy(ptr %t1488, ptr %t1461, i64 %t1462)
  %t1489 = getelementptr i8, ptr %t1488, i64 %t1462
  call void @olang_textcopy(ptr %t1489, ptr %t1464, i64 %t1465)
  %t1490 = getelementptr i8, ptr %t1489, i64 %t1465
  %t1491 = call i64 @__olang_fmt_i64(ptr %t1490, i64 %t1467)
  %t1492 = getelementptr i8, ptr %t1490, i64 %t1468
  call void @olang_textcopy(ptr %t1492, ptr %t1470, i64 %t1471)
  %t1493 = getelementptr i8, ptr %t1492, i64 %t1471
  call void @olang_textcopy(ptr %t1493, ptr %t1474, i64 %t1475)
  %t1494 = getelementptr i8, ptr %t1493, i64 %t1475
  call void @olang_textcopy(ptr %t1494, ptr %t1477, i64 %t1478)
  %t1495 = getelementptr i8, ptr %t1494, i64 %t1478
  call void @olang_textcopy(ptr %t1495, ptr %t1481, i64 %t1482)
  %t1496 = getelementptr i8, ptr %t1495, i64 %t1482
  call void @olang_textcopy(ptr %t1496, ptr %t1484, i64 %t1485)
  %t1497 = insertvalue { i64, ptr } undef, i64 %t1486, 0
  %t1498 = insertvalue { i64, ptr } %t1497, ptr %t1487, 1
  store { i64, ptr } %t1498, ptr %l712, !tbaa !27
  %t1499 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t1500 = extractvalue { i64, ptr } %t1499, 0
  %t1501 = load { i64, ptr }, ptr %l712, !tbaa !27
  %t1502 = extractvalue { i64, ptr } %t1501, 0
  store i64 %t1502, ptr %l714, !tbaa !24
  %t1504 = load i64, ptr %l714, !tbaa !24
  %t1505 = icmp eq i64 %t1500, %t1504
  br i1 %t1505, label %bb297, label %bb298
bb297:
  %t1507 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t1508 = load ptr, ptr %t1507, !tbaa !27
  %t1509 = getelementptr { i64, ptr }, ptr %l712, i32 0, i32 1
  %t1510 = load ptr, ptr %t1509, !tbaa !27
  %t1511 = load i64, ptr %l714, !tbaa !24
  %t1512 = mul i64 %t1511, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1508, ptr %t1510, i64 %t1512, i1 false)
  br label %bb299
bb298:
  %t1513 = load { i64, ptr }, ptr %l712, !tbaa !27
  store { i64, ptr } %t1513, ptr %l89, !tbaa !27
  br label %bb299
bb299:
  call void @__olang_scope_close(ptr %s52)
  br label %bb303
bb300:
  %t1514 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t1515 = load ptr, ptr %t1514, !tbaa !27
  %t1516 = getelementptr { i64, ptr }, ptr %l718, i32 0, i32 1
  %t1517 = load ptr, ptr %t1516, !tbaa !27
  %t1518 = load i64, ptr %l720, !tbaa !24
  %t1519 = mul i64 %t1518, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1515, ptr %t1517, i64 %t1519, i1 false)
  br label %bb302
bb301:
  %t1520 = load { i64, ptr }, ptr %l718, !tbaa !27
  store { i64, ptr } %t1520, ptr %l89, !tbaa !27
  br label %bb302
bb302:
  br label %bb303
bb303:
  br label %bb304
bb304:
  %t1521 = load i64, ptr %l74, !tbaa !24
  %t1524 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %s0, ptr %s0, ptr %l3, i64 %t1521)
  store ptr %t1524, ptr %l724
  br label %bb305
bb305:
  %t1525 = load ptr, ptr %l724, !tbaa !29
  store ptr %t1525, ptr %l90, !tbaa !29
  store i64 0, ptr %l91, !tbaa !24
  br label %bb306
bb306:
  store %olang.scope zeroinitializer, ptr %s57
  %t1526 = load ptr, ptr %l90, !tbaa !29
  %t1527 = load i64, ptr %l91, !tbaa !24
  %t1530 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t1526, i64 %t1527)
  %t1531 = extractvalue { i32, { i64, ptr } } %t1530, 1
  %t1532 = extractvalue { i32, { i64, ptr } } %t1530, 0
  store i32 %t1532, ptr %l729
  %t1533 = icmp ne i32 %t1532, 0
  br i1 %t1533, label %bb308, label %ok.1534
ok.1534:
  store { i64, ptr } %t1531, ptr %l728
  br label %bb307
bb307:
  %t1535 = load { i64, ptr }, ptr %l728, !tbaa !27
  store { i64, ptr } %t1535, ptr %l725, !tbaa !27
  br label %bb312
bb308:
  %t1536 = load i32, ptr %l729, !tbaa !23
  %t1537 = ashr i32 %t1536, 16
  %t1539 = icmp eq i32 %t1537, 1
  br i1 %t1539, label %bb309, label %bb310
bb309:
  br label %bb311
bb310:
  call void @__olang_check_failed(ptr @olang_loc_7635bc67c3b310ea_9408068343213e7e)
  unreachable
bb311:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s57)
  br label %bb336
bb312:
  %t1541 = load { i64, ptr }, ptr %l725, !tbaa !27
  store { i64, ptr } %t1541, ptr %l92, !tbaa !27
  %t1542 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t1544 = extractvalue { i64, ptr } %t1542, 0
  store i64 %t1544, ptr %l93, !tbaa !24
  store i64 0, ptr %l94, !tbaa !24
  br label %bb313
bb313:
  store %olang.scope zeroinitializer, ptr %s58
  %t1546 = load i64, ptr %l94, !tbaa !24
  %t1547 = load i64, ptr %l93, !tbaa !24
  %t1550 = icmp slt i64 %t1546, %t1547
  %t1552 = xor i1 %t1550, true
  br i1 %t1552, label %bb314, label %bb315
bb314:
  call void @__olang_scope_close(ptr %s58)
  br label %bb334
bb315:
  br label %bb316
bb316:
  %t1554 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t1554, ptr %l738, !tbaa !27
  %t1555 = load i64, ptr %l94, !tbaa !24
  %t1557 = getelementptr { i64, ptr }, ptr %l738, i32 0, i32 1
  %t1558 = load ptr, ptr %t1557, !tbaa !27
  %t1559 = getelementptr i64, ptr %t1558, i64 %t1555
  %t1560 = load i64, ptr %t1559, !tbaa !34
  store i64 %t1560, ptr %l95, !tbaa !24
  %t1562 = load i64, ptr %l58, !tbaa !24
  %t1564 = icmp slt i64 %t1562, 0
  br i1 %t1564, label %bb317, label %bb318
bb317:
  store i1 true, ptr %l743, !tbaa !21
  br label %bb319
bb318:
  %t1566 = load i64, ptr %l95, !tbaa !24
  %t1567 = load i64, ptr %l58, !tbaa !24
  %t1570 = icmp eq i64 %t1566, %t1567
  store i1 %t1570, ptr %l743, !tbaa !21
  br label %bb319
bb319:
  %t1572 = load i1, ptr %l743, !tbaa !21
  br i1 %t1572, label %bb320, label %bb321
bb320:
  %t1573 = load ptr, ptr %l1, !tbaa !29
  %t1575 = getelementptr %"compiler/free:Free", ptr %t1573, i32 0, i32 36
  %t1576 = load i64, ptr %l95, !tbaa !24
  %t1579 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t1575, i64 %t1576)
  store i64 %t1579, ptr %l751
  br label %bb322
bb321:
  store i1 false, ptr %l747, !tbaa !21
  br label %bb323
bb322:
  %t1580 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t1581 = load i64, ptr %l751, !tbaa !24
  %t1583 = icmp eq i64 %t1581, %t1580
  store i1 %t1583, ptr %l747, !tbaa !21
  br label %bb323
bb323:
  %t1585 = load i1, ptr %l747, !tbaa !21
  br i1 %t1585, label %bb324, label %bb325
bb324:
  %t1586 = load ptr, ptr %l1, !tbaa !29
  %t1587 = load i64, ptr %l95, !tbaa !24
  %t1590 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %t1586, i64 %t1587)
  store i1 %t1590, ptr %l757
  br label %bb326
bb325:
  store i1 false, ptr %l754, !tbaa !21
  br label %bb327
bb326:
  %t1591 = load i1, ptr %l757, !tbaa !21
  %t1592 = xor i1 %t1591, true
  store i1 %t1592, ptr %l754, !tbaa !21
  br label %bb327
bb327:
  %t1594 = load i1, ptr %l754, !tbaa !21
  br i1 %t1594, label %bb328, label %bb329
bb328:
  store %olang.scope zeroinitializer, ptr %s59
  %t1595 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1595, ptr %l759, !tbaa !29
  %t1596 = load i64, ptr %l95, !tbaa !24
  store i64 %t1596, ptr %l760, !tbaa !24
  %t1597 = load ptr, ptr %l2, !tbaa !29
  %t1599 = getelementptr %"compiler/typed:Body", ptr %t1597, i32 0, i32 3
  %t1600 = load i64, ptr %t1599, !tbaa !24
  store i64 %t1600, ptr %l762, !tbaa !24
  %t1601 = load ptr, ptr %l0, !tbaa !29
  %t1603 = getelementptr %"compiler/free:walker", ptr %t1601, i32 0, i32 26
  %t1604 = load i64, ptr %l82, !tbaa !24
  %t1607 = call %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1603, i64 %t1604)
  store %"compiler/source:Span" %t1607, ptr %l766
  br label %bb330
bb329:
  br label %bb332
bb330:
  %t1608 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t1609 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t1611 = extractvalue { i64, ptr } %t1608, 1
  %t1612 = extractvalue { i64, ptr } %t1608, 0
  %t1613 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t1614 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t1615 = add i64 %t1612, %t1614
  %t1617 = extractvalue { i64, ptr } %t1609, 1
  %t1618 = extractvalue { i64, ptr } %t1609, 0
  %t1619 = add i64 %t1615, %t1618
  %t1620 = call ptr @__olang_scope_alloc(ptr %s59, i64 %t1619)
  call void @olang_textcopy(ptr %t1620, ptr %t1611, i64 %t1612)
  %t1621 = getelementptr i8, ptr %t1620, i64 %t1612
  call void @olang_textcopy(ptr %t1621, ptr %t1613, i64 %t1614)
  %t1622 = getelementptr i8, ptr %t1621, i64 %t1614
  call void @olang_textcopy(ptr %t1622, ptr %t1617, i64 %t1618)
  %t1623 = insertvalue { i64, ptr } undef, i64 %t1619, 0
  %t1624 = insertvalue { i64, ptr } %t1623, ptr %t1620, 1
  %t1626 = extractvalue { i64, ptr } %t1624, 0
  %t1627 = extractvalue { i64, ptr } %t1624, 1
  %t1628 = mul i64 %t1626, 1
  %t1629 = call ptr @__olang_scope_alloc(ptr %s59, i64 %t1628)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1629, ptr %t1627, i64 %t1628, i1 false)
  %t1630 = insertvalue { i64, ptr } undef, i64 %t1626, 0
  %t1631 = insertvalue { i64, ptr } %t1630, ptr %t1629, 1
  %t1632 = load i64, ptr %l61, !tbaa !24
  %t1633 = load ptr, ptr %l759, !tbaa !29
  %t1634 = load i64, ptr %l760, !tbaa !24
  %t1635 = load i64, ptr %l762, !tbaa !24
  %t1636 = load %"compiler/source:Span", ptr %l766
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %s59, ptr %t1633, i64 %t1634, i64 %t1635, %"compiler/source:Span" %t1636, { i64, ptr } %t1631, i64 %t1632)
  br label %bb331
bb331:
  call void @__olang_scope_close(ptr %s59)
  br label %bb332
bb332:
  call void @__olang_scope_close(ptr %s58)
  br label %bb333
bb333:
  %t1639 = load i64, ptr %l94, !tbaa !24
  %t1641 = add i64 %t1639, 1
  store i64 %t1641, ptr %l94, !tbaa !24
  br label %bb313
bb334:
  %t1643 = load i64, ptr %l91, !tbaa !24
  %t1644 = load i64, ptr %l93, !tbaa !24
  %t1647 = add i64 %t1643, %t1644
  store i64 %t1647, ptr %l91, !tbaa !24
  call void @__olang_scope_close(ptr %s57)
  br label %bb335
bb335:
  br label %bb306
bb336:
  %t1649 = load i64, ptr %l58, !tbaa !24
  %t1651 = icmp sge i64 %t1649, 0
  br i1 %t1651, label %bb337, label %bb338
bb337:
  call void @__olang_scope_close(ptr %s36)
  call void @__olang_scope_close(ptr %s35)
  br label %bb343
bb338:
  br label %bb339
bb339:
  call void @__olang_scope_close(ptr %s36)
  br label %bb340
bb340:
  %t1653 = load i64, ptr %l73, !tbaa !24
  %t1655 = add i64 %t1653, 1
  store i64 %t1655, ptr %l73, !tbaa !24
  br label %bb217
bb341:
  %t1657 = load i64, ptr %l70, !tbaa !24
  %t1658 = load i64, ptr %l72, !tbaa !24
  %t1661 = add i64 %t1657, %t1658
  store i64 %t1661, ptr %l70, !tbaa !24
  call void @__olang_scope_close(ptr %s35)
  br label %bb342
bb342:
  br label %bb210
bb343:
  call void @__olang_scope_close(ptr %s26)
  br label %bb344
bb344:
  %t1663 = load i64, ptr %l56, !tbaa !24
  %t1665 = add i64 %t1663, 1
  store i64 %t1665, ptr %l56, !tbaa !24
  br label %bb149
bb345:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ectorCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_546be3fdfb2e7861_5a4791e17fa5075d)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  br label %bb32
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %t34)
  store ptr %t36, ptr %l21
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l21, !tbaa !29
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb32
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %t56)
  store ptr %t58, ptr %l30
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l30, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  br label %bb32
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l31, !tbaa !29
  %t65 = load i64, ptr %t64
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Payload", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %t78)
  store ptr %t80, ptr %l39
  br label %bb26
bb26:
  %t81 = load ptr, ptr %l39, !tbaa !29
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_5891e56eddc46c99_f944b0e713971375)
  unreachable
bb32:
  %t82 = load ptr, ptr %l5, !tbaa !29
  store ptr %t82, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l56 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i1
  %l123 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i1
  %l150 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca i1
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i1
  %l196 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l219 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca i1
  %l230 = alloca ptr
  %l246 = alloca ptr
  %l255 = alloca ptr
  %l256 = alloca ptr
  %l257 = alloca i1
  %l264 = alloca ptr
  %s4 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t2 = load ptr, ptr %l35, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l35, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l36, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb31
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 3
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = icmp eq i64 %t21, %t22
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l56, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t53, i64 %t56)
  store ptr %t59, ptr %l61
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l61, !tbaa !29
  store ptr %t60, ptr %l7, !tbaa !29
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l7, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  store ptr %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb9
bb18:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Call", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l8, !tbaa !29
  %t79 = load ptr, ptr %l8, !tbaa !29
  store ptr %t79, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t80 = load ptr, ptr %l71, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb19, label %bb20
bb19:
  %t83 = load ptr, ptr %l71, !tbaa !29
  %t84 = load i64, ptr %t83
  %t86 = icmp eq i64 %t84, 2
  store i1 %t86, ptr %l72, !tbaa !21
  br label %bb20
bb20:
  %t87 = load i1, ptr %l72, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { ptr }, ptr %t90, i32 0, i32 0
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l9, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t94 = load ptr, ptr %l9, !tbaa !29
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t94, i64 %t95)
  store ptr %t98, ptr %l79
  br label %bb24
bb24:
  %t99 = load ptr, ptr %l79, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_16263ed1acd4aa7e_23dcb8f717a142b2)
  unreachable
bb30:
  store ptr null, ptr %rv
  br label %ret
bb31:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t102 = load ptr, ptr %l81, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t105 = load ptr, ptr %l81, !tbaa !29
  %t106 = load i64, ptr %t105
  %t108 = icmp eq i64 %t106, 5
  store i1 %t108, ptr %l82, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l82, !tbaa !21
  br i1 %t109, label %bb34, label %bb35
bb34:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l10, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t116 = load ptr, ptr %l10, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Promote", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l1, !tbaa !24
  %t123 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t119, i64 %t120)
  store ptr %t123, ptr %l90
  br label %bb37
bb37:
  %t124 = load ptr, ptr %l90, !tbaa !29
  store ptr %t124, ptr %rv
  br label %ret
bb38:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t126 = load ptr, ptr %l91, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = load ptr, ptr %l91, !tbaa !29
  %t130 = load i64, ptr %t129
  %t132 = icmp eq i64 %t130, 2
  store i1 %t132, ptr %l92, !tbaa !21
  br label %bb40
bb40:
  %t133 = load i1, ptr %l92, !tbaa !21
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t141 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l99
  br label %bb44
bb44:
  %t145 = load ptr, ptr %l99, !tbaa !29
  store ptr %t145, ptr %rv
  br label %ret
bb45:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t147 = load ptr, ptr %l100, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb46, label %bb47
bb46:
  %t150 = load ptr, ptr %l100, !tbaa !29
  %t151 = load i64, ptr %t150
  %t153 = icmp eq i64 %t151, 3
  store i1 %t153, ptr %l101, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l101, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr { i64, [5 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l12, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t161 = load ptr, ptr %l12, !tbaa !29
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %t161, i64 %t162)
  store ptr %t165, ptr %l108
  br label %bb51
bb51:
  %t166 = load ptr, ptr %l108, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb52:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t168 = load ptr, ptr %l109, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t171 = load ptr, ptr %l109, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 7
  store i1 %t174, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t175 = load i1, ptr %l110, !tbaa !21
  br i1 %t175, label %bb55, label %bb56
bb55:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l13, !tbaa !29
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t182 = load ptr, ptr %l13, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Make", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l16, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s14
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s14)
  br label %bb67
bb60:
  br label %bb61
bb61:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t199, ptr %l123, !tbaa !27
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr ptr, ptr %t203, i64 %t200
  %t205 = load ptr, ptr %t204, !tbaa !39
  %t208 = load i64, ptr %l1, !tbaa !24
  %t211 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t205, i64 %t208)
  store ptr %t211, ptr %l128
  br label %bb62
bb62:
  %t212 = load ptr, ptr %l128, !tbaa !29
  store ptr %t212, ptr %l18, !tbaa !29
  %t213 = load ptr, ptr %l18, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb63, label %bb64
bb63:
  %t219 = load ptr, ptr %l18, !tbaa !29
  call void @__olang_scope_close(ptr %s14)
  store ptr %t219, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s14)
  br label %bb66
bb66:
  %t222 = load i64, ptr %l15, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l15, !tbaa !24
  br label %bb58
bb67:
  store ptr null, ptr %rv
  br label %ret
bb68:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t228 = load ptr, ptr %l137, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb69, label %bb70
bb69:
  %t231 = load ptr, ptr %l137, !tbaa !29
  %t232 = load i64, ptr %t231
  %t234 = icmp eq i64 %t232, 9
  store i1 %t234, ptr %l138, !tbaa !21
  br label %bb70
bb70:
  %t235 = load i1, ptr %l138, !tbaa !21
  br i1 %t235, label %bb71, label %bb72
bb71:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t238, i32 0, i32 4
  %t240 = load { i64, ptr }, ptr %t239
  store { i64, ptr } %t240, ptr %l19, !tbaa !27
  br label %bb73
bb72:
  br label %bb84
bb73:
  %t242 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t242, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l22, !tbaa !24
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s19
  %t248 = load i64, ptr %l21, !tbaa !24
  %t249 = load i64, ptr %l22, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb75, label %bb76
bb75:
  call void @__olang_scope_close(ptr %s19)
  br label %bb83
bb76:
  br label %bb77
bb77:
  %t256 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t256, ptr %l150, !tbaa !27
  %t257 = load i64, ptr %l21, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 %t257
  %t262 = load ptr, ptr %t261, !tbaa !39
  %t265 = load i64, ptr %l1, !tbaa !24
  %t268 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t262, i64 %t265)
  store ptr %t268, ptr %l155
  br label %bb78
bb78:
  %t269 = load ptr, ptr %l155, !tbaa !29
  store ptr %t269, ptr %l24, !tbaa !29
  %t270 = load ptr, ptr %l24, !tbaa !29
  %t272 = icmp eq ptr %t270, null
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb79, label %bb80
bb79:
  %t276 = load ptr, ptr %l24, !tbaa !29
  call void @__olang_scope_close(ptr %s19)
  store ptr %t276, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s19)
  br label %bb82
bb82:
  %t279 = load i64, ptr %l21, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l21, !tbaa !24
  br label %bb74
bb83:
  store ptr null, ptr %rv
  br label %ret
bb84:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t285 = load ptr, ptr %l164, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb85, label %bb86
bb85:
  %t288 = load ptr, ptr %l164, !tbaa !29
  %t289 = load i64, ptr %t288
  %t291 = icmp eq i64 %t289, 14
  store i1 %t291, ptr %l165, !tbaa !21
  br label %bb86
bb86:
  %t292 = load i1, ptr %l165, !tbaa !21
  br i1 %t292, label %bb87, label %bb88
bb87:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr { i64, [5 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t295, i32 0, i32 2
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l25, !tbaa !29
  br label %bb89
bb88:
  br label %bb97
bb89:
  %t299 = load ptr, ptr %l25, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Try", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb90, label %bb91
bb90:
  %t308 = load ptr, ptr %l25, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Try", ptr %t308, i32 0, i32 0
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  br i1 %t313, label %bb92, label %bb93
bb91:
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_ea2e0f0d6ffcb248_fe73fa1c8e55849c)
  unreachable
bb93:
  br label %bb94
bb94:
  %t315 = load ptr, ptr %l25, !tbaa !29
  %t317 = getelementptr %"compiler/typed:Try", ptr %t315, i32 0, i32 0
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load i64, ptr %l1, !tbaa !24
  %t322 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t318, i64 %t319)
  store ptr %t322, ptr %l180
  br label %bb95
bb95:
  %t323 = load ptr, ptr %l180, !tbaa !29
  store ptr %t323, ptr %rv
  br label %ret
bb96:
  store ptr null, ptr %rv
  br label %ret
bb97:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t326 = load ptr, ptr %l182, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb98, label %bb99
bb98:
  %t329 = load ptr, ptr %l182, !tbaa !29
  %t330 = load i64, ptr %t329
  %t332 = icmp eq i64 %t330, 12
  store i1 %t332, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t333 = load i1, ptr %l183, !tbaa !21
  br i1 %t333, label %bb100, label %bb101
bb100:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t336, i32 0, i32 2
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l26, !tbaa !29
  br label %bb102
bb101:
  br label %bb120
bb102:
  %t340 = load ptr, ptr %l26, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Seq", ptr %t340, i32 0, i32 0
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  store { i64, ptr } %t343, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t345 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  store i64 %t347, ptr %l29, !tbaa !24
  br label %bb103
bb103:
  store %olang.scope zeroinitializer, ptr %s26
  %t349 = load i64, ptr %l28, !tbaa !24
  %t350 = load i64, ptr %l29, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb104, label %bb105
bb104:
  call void @__olang_scope_close(ptr %s26)
  br label %bb112
bb105:
  br label %bb106
bb106:
  %t357 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t357, ptr %l196, !tbaa !27
  %t358 = load i64, ptr %l28, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr ptr, ptr %t361, i64 %t358
  %t363 = load ptr, ptr %t362, !tbaa !39
  %t366 = load i64, ptr %l1, !tbaa !24
  %t369 = call ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %t363, i64 %t366)
  store ptr %t369, ptr %l201
  br label %bb107
bb107:
  %t370 = load ptr, ptr %l201, !tbaa !29
  store ptr %t370, ptr %l31, !tbaa !29
  %t371 = load ptr, ptr %l31, !tbaa !29
  %t373 = icmp eq ptr %t371, null
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb108, label %bb109
bb108:
  %t377 = load ptr, ptr %l31, !tbaa !29
  call void @__olang_scope_close(ptr %s26)
  store ptr %t377, ptr %rv
  br label %ret
bb109:
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s26)
  br label %bb111
bb111:
  %t380 = load i64, ptr %l28, !tbaa !24
  %t382 = add i64 %t380, 1
  store i64 %t382, ptr %l28, !tbaa !24
  br label %bb103
bb112:
  %t384 = load ptr, ptr %l26, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Seq", ptr %t384, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = icmp eq ptr %t387, null
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb113, label %bb114
bb113:
  %t393 = load ptr, ptr %l26, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Seq", ptr %t393, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb115, label %bb116
bb114:
  br label %bb119
bb115:
  call void @__olang_check_failed(ptr @olang_loc_6e2453cb19a4d71d_88f1503d6cec0391)
  unreachable
bb116:
  br label %bb117
bb117:
  %t400 = load ptr, ptr %l26, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Seq", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t404 = load i64, ptr %l1, !tbaa !24
  %t407 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t403, i64 %t404)
  store ptr %t407, ptr %l219
  br label %bb118
bb118:
  %t408 = load ptr, ptr %l219, !tbaa !29
  store ptr %t408, ptr %rv
  br label %ret
bb119:
  store ptr null, ptr %rv
  br label %ret
bb120:
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t411 = load ptr, ptr %l221, !tbaa !29
  %t412 = icmp ne ptr %t411, null
  br i1 %t412, label %bb121, label %bb122
bb121:
  %t414 = load ptr, ptr %l221, !tbaa !29
  %t415 = load i64, ptr %t414
  %t417 = icmp eq i64 %t415, 11
  store i1 %t417, ptr %l222, !tbaa !21
  br label %bb122
bb122:
  %t418 = load i1, ptr %l222, !tbaa !21
  br i1 %t418, label %bb123, label %bb124
bb123:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t421, i32 0, i32 2
  %t423 = load ptr, ptr %t422
  store ptr %t423, ptr %l32, !tbaa !29
  br label %bb125
bb124:
  br label %bb141
bb125:
  %t425 = load ptr, ptr %l32, !tbaa !29
  %t427 = getelementptr %"compiler/typed:Cond", ptr %t425, i32 0, i32 0
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t429 = load i64, ptr %l1, !tbaa !24
  %t432 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t428, i64 %t429)
  store ptr %t432, ptr %l230
  br label %bb126
bb126:
  %t433 = load ptr, ptr %l230, !tbaa !29
  store ptr %t433, ptr %l33, !tbaa !29
  %t434 = load ptr, ptr %l33, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb127, label %bb128
bb127:
  %t440 = load ptr, ptr %l33, !tbaa !29
  store ptr %t440, ptr %rv
  br label %ret
bb128:
  br label %bb129
bb129:
  %t443 = load ptr, ptr %l32, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Cond", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = icmp eq ptr %t446, null
  %t450 = xor i1 %t448, true
  br i1 %t450, label %bb130, label %bb131
bb130:
  %t452 = load ptr, ptr %l32, !tbaa !29
  %t454 = getelementptr %"compiler/typed:Cond", ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = icmp eq ptr %t455, null
  br i1 %t457, label %bb132, label %bb133
bb131:
  br label %bb139
bb132:
  call void @__olang_check_failed(ptr @olang_loc_a8e684701cb727b6_7b41502ddc5bea8a)
  unreachable
bb133:
  br label %bb134
bb134:
  %t459 = load ptr, ptr %l32, !tbaa !29
  %t461 = getelementptr %"compiler/typed:Cond", ptr %t459, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !29
  %t463 = load i64, ptr %l1, !tbaa !24
  %t466 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t462, i64 %t463)
  store ptr %t466, ptr %l246
  br label %bb135
bb135:
  %t467 = load ptr, ptr %l246, !tbaa !29
  store ptr %t467, ptr %l33, !tbaa !29
  %t468 = load ptr, ptr %l33, !tbaa !29
  %t470 = icmp eq ptr %t468, null
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb136, label %bb137
bb136:
  %t474 = load ptr, ptr %l33, !tbaa !29
  store ptr %t474, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  br label %bb139
bb139:
  %t477 = load ptr, ptr %l32, !tbaa !29
  %t479 = getelementptr %"compiler/typed:Cond", ptr %t477, i32 0, i32 2
  %t480 = load ptr, ptr %t479, !tbaa !29
  %t481 = load i64, ptr %l1, !tbaa !24
  %t484 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t480, i64 %t481)
  store ptr %t484, ptr %l255
  br label %bb140
bb140:
  %t485 = load ptr, ptr %l255, !tbaa !29
  store ptr %t485, ptr %rv
  br label %ret
bb141:
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t487 = load ptr, ptr %l256, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb142, label %bb143
bb142:
  %t490 = load ptr, ptr %l256, !tbaa !29
  %t491 = load i64, ptr %t490
  %t493 = icmp eq i64 %t491, 17
  store i1 %t493, ptr %l257, !tbaa !21
  br label %bb143
bb143:
  %t494 = load i1, ptr %l257, !tbaa !21
  br i1 %t494, label %bb144, label %bb145
bb144:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t497, i32 0, i32 2
  %t499 = load ptr, ptr %t498
  store ptr %t499, ptr %l34, !tbaa !29
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t501 = load ptr, ptr %l34, !tbaa !29
  %t502 = load i64, ptr %l1, !tbaa !24
  %t505 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %t501, i64 %t502)
  store ptr %t505, ptr %l264
  br label %bb147
bb147:
  %t506 = load ptr, ptr %l264, !tbaa !29
  store ptr %t506, ptr %rv
  br label %ret
bb148:
  br i1 true, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  store ptr null, ptr %rv
  br label %ret
bb152:
  call void @__olang_check_failed(ptr @olang_loc_3e8b13b2a7075e62_22250d1a20f2250e)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l20 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t30 = call ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %t24, i64 %a1)
  store ptr %t30, ptr %l20
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l20, !tbaa !29
  store ptr %t31, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s2)
  store ptr %t38, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2eleavesFunction(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 7
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t24 = load i64, ptr %t23
  %t26 = icmp eq i64 %t24, 9
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 true, ptr %l1, !tbaa !21
  br label %bb19
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 false, ptr %l1, !tbaa !21
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_83047756a0f84ae3_95aa60b35b875f1f)
  unreachable
bb19:
  %t28 = load i1, ptr %l1, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2enewWalker(ptr %v0, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca %"compiler/free:walker"
  %l81 = alloca ptr
  %l84 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i64
  %l121 = alloca i64
  %l124 = alloca i64
  %l129 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l143 = alloca i64
  %l147 = alloca i64
  %l150 = alloca i64
  %l171 = alloca i32
  %l180 = alloca ptr
  %l183 = alloca i64
  %l184 = alloca i1
  %l190 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l204 = alloca i64
  %l207 = alloca i64
  %l225 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l235 = alloca i64
  %l238 = alloca i64
  %l259 = alloca ptr
  %l260 = alloca { i64, ptr }
  %l263 = alloca i1
  %l277 = alloca i64
  %l281 = alloca i64
  %l284 = alloca i64
  %l303 = alloca ptr
  %l307 = alloca i32
  %s3 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca ptr
  %t12 = alloca %"compiler/free:walker", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 6
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l44, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2ffree_3awalker_2ector(ptr %t12, ptr %v0, ptr %v0, ptr %t9, i64 %t10, i1 %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t12, i64 464, i1 false)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 464, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %l48, i64 464, i1 false)
  %t18 = load ptr, ptr %l44, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t18, i32 0, i32 6
  store ptr %t16, ptr %t19, !tbaa !29
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ce893683105a8b06_84bedcfad8df0b4a)
  unreachable
bb6:
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 6
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l3, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 1
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i1, ptr %l2, !tbaa !21
  %t41 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 2
  store i1 %t38, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/free:walker", ptr %t42, i32 0, i32 5
  store i1 false, ptr %t44, !tbaa !21
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t47)
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t51)
  br label %bb9
bb9:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 8
  store i32 %t54, ptr %t57, !tbaa !23
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eCl_H0a9e00411db21d32682611ff4a2aedde(ptr %v0, ptr %t60)
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t64)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H2607a290a254b1368332c2620bcac78c(ptr %v0, ptr %t68)
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 23
  store i64 0, ptr %t72, !tbaa !24
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 28
  store i64 0, ptr %t75, !tbaa !24
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 29
  store i64 0, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 30
  store i64 -1, ptr %t81, !tbaa !24
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 31
  store i64 -1, ptr %t84, !tbaa !24
  %t85 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t85)
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %l1, !tbaa !24
  %t93 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l81
  br label %bb14
bb14:
  %t94 = load ptr, ptr %l81, !tbaa !29
  store ptr %t94, ptr %l4, !tbaa !29
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Body", ptr %t95, i32 0, i32 7
  %t99 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l84
  br label %bb15
bb15:
  %t100 = load i64, ptr %l84, !tbaa !24
  store i64 %t100, ptr %l5, !tbaa !24
  %t101 = load ptr, ptr %l3, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 3
  %t104 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hd29545d6ce80f0b71db83a570b969f39(ptr %v0, ptr %t103, i64 %t104)
  br label %bb16
bb16:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/free:walker", ptr %t107, i32 0, i32 20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t109)
  br label %bb17
bb17:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/free:walker", ptr %t111, i32 0, i32 21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t113)
  br label %bb18
bb18:
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t117 = getelementptr %"compiler/free:walker", ptr %t115, i32 0, i32 4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t117)
  br label %bb19
bb19:
  store i64 0, ptr %l6, !tbaa !24
  %t119 = load i64, ptr %l5, !tbaa !24
  store i64 %t119, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  %t125 = icmp sgt i64 %t121, %t122
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t127 = load i64, ptr %l8, !tbaa !24
  %t129 = icmp sgt i64 %t127, 0
  br i1 %t129, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb25
bb22:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = sub i64 %t131, %t132
  %t136 = load i64, ptr %l8, !tbaa !24
  %t139 = add i64 %t135, %t136
  %t141 = sub i64 %t139, 1
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = sdiv i64 %t141, %t142
  store i64 %t145, ptr %l101, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb24
bb24:
  %t147 = load i64, ptr %l101, !tbaa !24
  store i64 %t147, ptr %l98, !tbaa !24
  br label %bb25
bb25:
  %t148 = load i64, ptr %l98, !tbaa !24
  store i64 %t148, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s3
  %t149 = load i64, ptr %l10, !tbaa !24
  %t150 = load i64, ptr %l9, !tbaa !24
  %t153 = icmp slt i64 %t149, %t150
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb28:
  br label %bb29
bb29:
  %t157 = load i64, ptr %l6, !tbaa !24
  %t158 = load i64, ptr %l10, !tbaa !24
  %t159 = load i64, ptr %l8, !tbaa !24
  %t162 = mul i64 %t158, %t159
  %t165 = add i64 %t157, %t162
  store i64 %t165, ptr %l11, !tbaa !24
  %t167 = load ptr, ptr %l3, !tbaa !29
  %t169 = getelementptr %"compiler/free:walker", ptr %t167, i32 0, i32 4
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t169, i1 false)
  br label %bb30
bb30:
  %t171 = load i64, ptr %l11, !tbaa !24
  store i64 %t171, ptr %l121, !tbaa !24
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/free:walker", ptr %t172, i32 0, i32 3
  %t176 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %t174)
  store i64 %t176, ptr %l124
  br label %bb31
bb31:
  %t177 = load i64, ptr %l121, !tbaa !24
  %t178 = load i64, ptr %l124, !tbaa !24
  %t179 = icmp slt i64 %t177, %t178
  br i1 %t179, label %bb32, label %bb33
bb32:
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 3
  %t184 = load i64, ptr %l11, !tbaa !24
  %t187 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t183, i64 %t184)
  store ptr %t187, ptr %l129
  br label %bb34
bb33:
  %t188 = load ptr, ptr %l3, !tbaa !29
  %t190 = getelementptr %"compiler/free:walker", ptr %t188, i32 0, i32 3
  store ptr %t190, ptr %l131, !tbaa !29
  %t191 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t191, ptr %l132
  br label %bb36
bb34:
  %t192 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t192)
  br label %bb35
bb35:
  br label %bb38
bb36:
  %t193 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l132
  %t194 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t193, ptr %t194
  %t195 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v0, ptr %t195, ptr %t194)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t197 = load ptr, ptr %l3, !tbaa !29
  %t199 = getelementptr %"compiler/free:walker", ptr %t197, i32 0, i32 20
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t199, i64 0)
  br label %bb39
bb39:
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t203 = getelementptr %"compiler/free:walker", ptr %t201, i32 0, i32 21
  store ptr %t203, ptr %l137, !tbaa !29
  %t204 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t204, ptr %l138
  br label %bb40
bb40:
  %t205 = load ptr, ptr %l137, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l138
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t205, %"compiler/source:Span" %t206)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb42:
  %t207 = load i64, ptr %l10, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l10, !tbaa !24
  br label %bb26
bb43:
  store i64 0, ptr %l12, !tbaa !24
  %t211 = load ptr, ptr %l4, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Body", ptr %t211, i32 0, i32 5
  %t215 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t213)
  store i64 %t215, ptr %l143
  br label %bb44
bb44:
  %t216 = load i64, ptr %l143, !tbaa !24
  store i64 %t216, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t217 = load i64, ptr %l13, !tbaa !24
  %t218 = load i64, ptr %l12, !tbaa !24
  %t221 = icmp sgt i64 %t217, %t218
  br i1 %t221, label %bb45, label %bb46
bb45:
  %t223 = load i64, ptr %l14, !tbaa !24
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb47, label %bb48
bb46:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb50
bb47:
  %t227 = load i64, ptr %l13, !tbaa !24
  %t228 = load i64, ptr %l12, !tbaa !24
  %t231 = sub i64 %t227, %t228
  %t232 = load i64, ptr %l14, !tbaa !24
  %t235 = add i64 %t231, %t232
  %t237 = sub i64 %t235, 1
  %t238 = load i64, ptr %l14, !tbaa !24
  %t241 = sdiv i64 %t237, %t238
  store i64 %t241, ptr %l150, !tbaa !24
  br label %bb49
bb48:
  store i64 0, ptr %l150, !tbaa !24
  br label %bb49
bb49:
  %t243 = load i64, ptr %l150, !tbaa !24
  store i64 %t243, ptr %l147, !tbaa !24
  br label %bb50
bb50:
  %t244 = load i64, ptr %l147, !tbaa !24
  store i64 %t244, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s8
  %t245 = load i64, ptr %l16, !tbaa !24
  %t246 = load i64, ptr %l15, !tbaa !24
  %t249 = icmp slt i64 %t245, %t246
  %t251 = xor i1 %t249, true
  br i1 %t251, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb53:
  br label %bb54
bb54:
  %t253 = load i64, ptr %l12, !tbaa !24
  %t254 = load i64, ptr %l16, !tbaa !24
  %t255 = load i64, ptr %l14, !tbaa !24
  %t258 = mul i64 %t254, %t255
  %t261 = add i64 %t253, %t258
  store i64 %t261, ptr %l17, !tbaa !24
  %t263 = load ptr, ptr %l4, !tbaa !29
  %t265 = getelementptr %"compiler/typed:Body", ptr %t263, i32 0, i32 5
  %t266 = load i64, ptr %l17, !tbaa !24
  %t269 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t265, i64 %t266)
  store i32 %t269, ptr %l171
  br label %bb55
bb55:
  %t270 = load i32, ptr %l171, !tbaa !23
  %t271 = sext i32 %t270 to i64
  store i64 %t271, ptr %l18, !tbaa !24
  %t273 = load ptr, ptr %l3, !tbaa !29
  %t275 = getelementptr %"compiler/free:walker", ptr %t273, i32 0, i32 6
  %t276 = load i64, ptr %l18, !tbaa !24
  %t277 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t275, i64 %t276, i64 %t277)
  br label %bb56
bb56:
  %t281 = load ptr, ptr %l3, !tbaa !29
  %t283 = getelementptr %"compiler/free:walker", ptr %t281, i32 0, i32 3
  %t284 = load i64, ptr %l18, !tbaa !24
  %t287 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t283, i64 %t284)
  store ptr %t287, ptr %l180
  br label %bb57
bb57:
  %t288 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t292 = call i64 @compiler_2ffree_2eorig(i64 %t288, i64 %t289)
  store i64 %t292, ptr %l183
  br label %bb58
bb58:
  %t293 = load ptr, ptr %l180, !tbaa !29
  %t294 = load i64, ptr %l183, !tbaa !24
  %t295 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t293, i64 %t294)
  store i1 %t295, ptr %l184
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb60:
  %t296 = load i64, ptr %l16, !tbaa !24
  %t298 = add i64 %t296, 1
  store i64 %t298, ptr %l16, !tbaa !24
  br label %bb51
bb61:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:Free", ptr %t300, i32 0, i32 50
  %t303 = load i64, ptr %l1, !tbaa !24
  %t306 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t302, i64 %t303)
  store { i64, ptr } %t306, ptr %l190
  br label %bb62
bb62:
  %t307 = load { i64, ptr }, ptr %l190, !tbaa !27
  store { i64, ptr } %t307, ptr %l19, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = load i64, ptr %l5, !tbaa !24
  %t313 = add i64 %t311, 1
  %t316 = icmp eq i64 %t310, %t313
  br i1 %t316, label %bb63, label %bb64
bb63:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/free:Free", ptr %t318, i32 0, i32 49
  %t321 = load i64, ptr %l1, !tbaa !24
  %t324 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t320, i64 %t321)
  store { i64, ptr } %t324, ptr %l199
  br label %bb65
bb64:
  br label %bb92
bb65:
  %t325 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t325, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l5, !tbaa !24
  store i64 %t326, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t328 = load i64, ptr %l22, !tbaa !24
  %t329 = load i64, ptr %l21, !tbaa !24
  %t332 = icmp sgt i64 %t328, %t329
  br i1 %t332, label %bb66, label %bb67
bb66:
  %t334 = load i64, ptr %l23, !tbaa !24
  %t336 = icmp sgt i64 %t334, 0
  br i1 %t336, label %bb68, label %bb69
bb67:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb71
bb68:
  %t338 = load i64, ptr %l22, !tbaa !24
  %t339 = load i64, ptr %l21, !tbaa !24
  %t342 = sub i64 %t338, %t339
  %t343 = load i64, ptr %l23, !tbaa !24
  %t346 = add i64 %t342, %t343
  %t348 = sub i64 %t346, 1
  %t349 = load i64, ptr %l23, !tbaa !24
  %t352 = sdiv i64 %t348, %t349
  store i64 %t352, ptr %l207, !tbaa !24
  br label %bb70
bb69:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb70
bb70:
  %t354 = load i64, ptr %l207, !tbaa !24
  store i64 %t354, ptr %l204, !tbaa !24
  br label %bb71
bb71:
  %t355 = load i64, ptr %l204, !tbaa !24
  store i64 %t355, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t356 = load i64, ptr %l25, !tbaa !24
  %t357 = load i64, ptr %l24, !tbaa !24
  %t360 = icmp slt i64 %t356, %t357
  %t362 = xor i1 %t360, true
  br i1 %t362, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s12)
  br label %bb91
bb74:
  br label %bb75
bb75:
  %t364 = load i64, ptr %l21, !tbaa !24
  %t365 = load i64, ptr %l25, !tbaa !24
  %t366 = load i64, ptr %l23, !tbaa !24
  %t369 = mul i64 %t365, %t366
  %t372 = add i64 %t364, %t369
  store i64 %t372, ptr %l26, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t374, ptr %l225, !tbaa !27
  %t375 = load i64, ptr %l26, !tbaa !24
  %t377 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !27
  %t379 = getelementptr i64, ptr %t378, i64 %t375
  %t380 = load i64, ptr %t379, !tbaa !34
  store i64 %t380, ptr %l27, !tbaa !24
  %t382 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t382, ptr %l228, !tbaa !27
  %t383 = load i64, ptr %l26, !tbaa !24
  %t385 = add i64 %t383, 1
  %t387 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr i64, ptr %t388, i64 %t385
  %t390 = load i64, ptr %t389, !tbaa !34
  store i64 %t390, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t392 = load i64, ptr %l28, !tbaa !24
  %t393 = load i64, ptr %l27, !tbaa !24
  %t396 = icmp sgt i64 %t392, %t393
  br i1 %t396, label %bb76, label %bb77
bb76:
  %t398 = load i64, ptr %l29, !tbaa !24
  %t400 = icmp sgt i64 %t398, 0
  br i1 %t400, label %bb78, label %bb79
bb77:
  store i64 0, ptr %l235, !tbaa !24
  br label %bb81
bb78:
  %t402 = load i64, ptr %l28, !tbaa !24
  %t403 = load i64, ptr %l27, !tbaa !24
  %t406 = sub i64 %t402, %t403
  %t407 = load i64, ptr %l29, !tbaa !24
  %t410 = add i64 %t406, %t407
  %t412 = sub i64 %t410, 1
  %t413 = load i64, ptr %l29, !tbaa !24
  %t416 = sdiv i64 %t412, %t413
  store i64 %t416, ptr %l238, !tbaa !24
  br label %bb80
bb79:
  store i64 0, ptr %l238, !tbaa !24
  br label %bb80
bb80:
  %t418 = load i64, ptr %l238, !tbaa !24
  store i64 %t418, ptr %l235, !tbaa !24
  br label %bb81
bb81:
  %t419 = load i64, ptr %l235, !tbaa !24
  store i64 %t419, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb82
bb82:
  store %olang.scope zeroinitializer, ptr %s14
  %t420 = load i64, ptr %l31, !tbaa !24
  %t421 = load i64, ptr %l30, !tbaa !24
  %t424 = icmp slt i64 %t420, %t421
  %t426 = xor i1 %t424, true
  br i1 %t426, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb84:
  br label %bb85
bb85:
  %t428 = load i64, ptr %l27, !tbaa !24
  %t429 = load i64, ptr %l31, !tbaa !24
  %t430 = load i64, ptr %l29, !tbaa !24
  %t433 = mul i64 %t429, %t430
  %t436 = add i64 %t428, %t433
  store i64 %t436, ptr %l32, !tbaa !24
  %t438 = load ptr, ptr %l3, !tbaa !29
  %t440 = getelementptr %"compiler/free:walker", ptr %t438, i32 0, i32 3
  %t441 = load i64, ptr %l26, !tbaa !24
  %t444 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v0, ptr %t440, i64 %t441)
  store ptr %t444, ptr %l259
  br label %bb86
bb86:
  %t445 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t445, ptr %l260, !tbaa !27
  %t446 = load i64, ptr %l32, !tbaa !24
  %t448 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr i64, ptr %t449, i64 %t446
  %t451 = load i64, ptr %t450, !tbaa !34
  %t452 = load ptr, ptr %l259, !tbaa !29
  %t454 = call i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t452, i64 %t451)
  store i1 %t454, ptr %l263
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s14)
  br label %bb88
bb88:
  %t455 = load i64, ptr %l31, !tbaa !24
  %t457 = add i64 %t455, 1
  store i64 %t457, ptr %l31, !tbaa !24
  br label %bb82
bb89:
  call void @__olang_scope_close(ptr %s12)
  br label %bb90
bb90:
  %t459 = load i64, ptr %l25, !tbaa !24
  %t461 = add i64 %t459, 1
  store i64 %t461, ptr %l25, !tbaa !24
  br label %bb72
bb91:
  br label %bb92
bb92:
  %t463 = load ptr, ptr %l4, !tbaa !29
  %t465 = getelementptr %"compiler/typed:Body", ptr %t463, i32 0, i32 1
  %t466 = load { i64, [2 x i64] }, ptr %t465
  store { i64, [2 x i64] } %t466, ptr %l33
  %t468 = load { i64, [2 x i64] }, ptr %l33
  %t470 = extractvalue { i64, [2 x i64] } %t468, 0
  %t471 = icmp eq i64 %t470, 1
  br i1 %t471, label %bb93, label %bb94
bb93:
  %t473 = getelementptr { i64, [2 x i64] }, ptr %l33, i32 0, i32 1
  %t474 = getelementptr { i32, i32 }, ptr %t473, i32 0, i32 0
  %t475 = load i32, ptr %t474
  store i32 %t475, ptr %l34, !tbaa !23
  br label %bb95
bb94:
  br label %bb111
bb95:
  %t477 = load ptr, ptr %l3, !tbaa !29
  %t478 = load i32, ptr %l34, !tbaa !23
  %t481 = getelementptr %"compiler/free:walker", ptr %t477, i32 0, i32 8
  store i32 %t478, ptr %t481, !tbaa !23
  store i64 0, ptr %l35, !tbaa !24
  %t482 = load ptr, ptr %l4, !tbaa !29
  %t484 = getelementptr %"compiler/typed:Body", ptr %t482, i32 0, i32 10
  %t486 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t484)
  store i64 %t486, ptr %l277
  br label %bb96
bb96:
  %t487 = load i64, ptr %l277, !tbaa !24
  store i64 %t487, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t488 = load i64, ptr %l36, !tbaa !24
  %t489 = load i64, ptr %l35, !tbaa !24
  %t492 = icmp sgt i64 %t488, %t489
  br i1 %t492, label %bb97, label %bb98
bb97:
  %t494 = load i64, ptr %l37, !tbaa !24
  %t496 = icmp sgt i64 %t494, 0
  br i1 %t496, label %bb99, label %bb100
bb98:
  store i64 0, ptr %l281, !tbaa !24
  br label %bb102
bb99:
  %t498 = load i64, ptr %l36, !tbaa !24
  %t499 = load i64, ptr %l35, !tbaa !24
  %t502 = sub i64 %t498, %t499
  %t503 = load i64, ptr %l37, !tbaa !24
  %t506 = add i64 %t502, %t503
  %t508 = sub i64 %t506, 1
  %t509 = load i64, ptr %l37, !tbaa !24
  %t512 = sdiv i64 %t508, %t509
  store i64 %t512, ptr %l284, !tbaa !24
  br label %bb101
bb100:
  store i64 0, ptr %l284, !tbaa !24
  br label %bb101
bb101:
  %t514 = load i64, ptr %l284, !tbaa !24
  store i64 %t514, ptr %l281, !tbaa !24
  br label %bb102
bb102:
  %t515 = load i64, ptr %l281, !tbaa !24
  store i64 %t515, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb103
bb103:
  store %olang.scope zeroinitializer, ptr %s19
  %t516 = load i64, ptr %l39, !tbaa !24
  %t517 = load i64, ptr %l38, !tbaa !24
  %t520 = icmp slt i64 %t516, %t517
  %t522 = xor i1 %t520, true
  br i1 %t522, label %bb104, label %bb105
bb104:
  call void @__olang_scope_close(ptr %s19)
  br label %bb110
bb105:
  br label %bb106
bb106:
  %t524 = load i64, ptr %l35, !tbaa !24
  %t525 = load i64, ptr %l39, !tbaa !24
  %t526 = load i64, ptr %l37, !tbaa !24
  %t529 = mul i64 %t525, %t526
  %t532 = add i64 %t524, %t529
  store i64 %t532, ptr %l40, !tbaa !24
  %t534 = load ptr, ptr %l3, !tbaa !29
  %t536 = getelementptr %"compiler/free:walker", ptr %t534, i32 0, i32 7
  store ptr %t536, ptr %l303, !tbaa !29
  %t537 = load ptr, ptr %l4, !tbaa !29
  %t539 = getelementptr %"compiler/typed:Body", ptr %t537, i32 0, i32 10
  %t540 = load i64, ptr %l40, !tbaa !24
  %t543 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t539, i64 %t540)
  store i32 %t543, ptr %l307
  br label %bb107
bb107:
  %t544 = load i32, ptr %l307, !tbaa !23
  %t545 = sext i32 %t544 to i64
  %t546 = load i64, ptr %l40, !tbaa !24
  %t547 = load ptr, ptr %l303, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t547, i64 %t545, i64 %t546)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s19)
  br label %bb109
bb109:
  %t550 = load i64, ptr %l39, !tbaa !24
  %t552 = add i64 %t550, 1
  store i64 %t552, ptr %l39, !tbaa !24
  br label %bb103
bb110:
  br label %bb116
bb111:
  br i1 true, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_check_failed(ptr @olang_loc_1b38cdd871e6a94_bc3035ea47e7c9d8)
  unreachable
bb116:
  %t554 = load ptr, ptr %l3, !tbaa !29
  store ptr %t554, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2eokind(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = ashr i64 %a0, 40
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb37
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t41 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i1 %t41, ptr %l24
  br label %bb13
bb13:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l6, !tbaa !21
  br label %bb37
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %t47
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t61)
  store i1 %t63, ptr %l33
  br label %bb20
bb20:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Elem", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i1 %t72, ptr %l38
  br label %bb23
bb22:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb24
bb23:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l34, !tbaa !21
  store i1 %t74, ptr %l6, !tbaa !21
  br label %bb37
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = load i64, ptr %t79
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Payload", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t97 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t97, ptr %l48
  br label %bb31
bb31:
  %t98 = load i1, ptr %l48, !tbaa !21
  store i1 %t98, ptr %l6, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_40628693553637f3_9a0aaf33c7b3625f)
  unreachable
bb37:
  %t99 = load i1, ptr %l6, !tbaa !21
  store i1 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb36
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb36
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb31
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  store ptr %t44, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = load i64, ptr %t48
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l25, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = call i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %t59)
  store i1 %t61, ptr %l31
  br label %bb24
bb24:
  %t62 = load i1, ptr %l31, !tbaa !21
  store i1 %t62, ptr %l23, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_73267d5e0cab398e_8c6ff0bab5f15012)
  unreachable
bb30:
  %t63 = load i1, ptr %l23, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a4448d4b24e169cf_c9af2cff75b97a13)
  unreachable
bb36:
  %t64 = load i1, ptr %l4, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_3awalker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca i1
  %l9 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca i32
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l21 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l39 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l45 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l57 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l58 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l59 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l64 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l65 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l69 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l80 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l81 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l82 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l85 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l90 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l91 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l92 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l93 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l94 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l95 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l96 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l97 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l98 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l99 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l100 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l101 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l103 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l104 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l105 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l106 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l107 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l108 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l109 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l110 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"compiler/free:walker"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  store i1 %a2, ptr %l5, !tbaa !21
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l64
  br label %bb1
bb1:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l64
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l6
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l65
  br label %bb2
bb2:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l7
  store i1 false, ptr %l8, !tbaa !21
  %t11 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l66
  br label %bb3
bb3:
  %t12 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l9
  %t13 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l67
  br label %bb4
bb4:
  %t14 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l10
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t15, ptr %l11, !tbaa !23
  %t17 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l69
  br label %bb5
bb5:
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l12
  %t19 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, ptr %l70
  br label %bb6
bb6:
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l71
  br label %bb7
bb7:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l16
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l72
  br label %bb8
bb8:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l17
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l73
  br label %bb9
bb9:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l73
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l18
  %t27 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l74
  br label %bb10
bb10:
  %t28 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t28, ptr %l19
  %t29 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, ptr %l75
  br label %bb11
bb11:
  %t30 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t30, ptr %l20
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l76
  br label %bb12
bb12:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l21
  %t33 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t33, ptr %l77
  br label %bb13
bb13:
  %t34 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l22
  %t35 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l78
  br label %bb14
bb14:
  %t36 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t36, ptr %l23
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l79
  br label %bb15
bb15:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l24
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l80
  br label %bb16
bb16:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l80
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l25
  store i64 0, ptr %l26, !tbaa !24
  %t41 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l81
  br label %bb17
bb17:
  %t42 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l81
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t42, ptr %l27
  %t43 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l82
  br label %bb18
bb18:
  %t44 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l82
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l28
  %t45 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t45, ptr %l83
  br label %bb19
bb19:
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l29
  %t47 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l84
  br label %bb20
bb20:
  %t48 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l84
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t48, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  store i64 -1, ptr %l33, !tbaa !24
  store i64 -1, ptr %l34, !tbaa !24
  %t49 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l85
  br label %bb21
bb21:
  %t50 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l85
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l35
  %t51 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 0, i32 0)
  store %"compiler/source:Span" %t51, ptr %l86
  br label %bb22
bb22:
  %t52 = load %"compiler/source:Span", ptr %l86
  store %"compiler/source:Span" %t52, ptr %l36
  %t53 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l87
  br label %bb23
bb23:
  %t54 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t54, ptr %l37
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l88
  br label %bb24
bb24:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l38
  %t57 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t57, ptr %l89
  br label %bb25
bb25:
  %t58 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l89
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l39
  %t59 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l90
  br label %bb26
bb26:
  %t60 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l90
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t60, ptr %l40
  %t61 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t61, ptr %l91
  br label %bb27
bb27:
  %t62 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l91
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %l41
  %t63 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t63, ptr %l92
  br label %bb28
bb28:
  %t64 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l92
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t64, ptr %l42
  %t65 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t65, ptr %l93
  br label %bb29
bb29:
  %t66 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l93
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l43
  %t67 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l94
  br label %bb30
bb30:
  %t68 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l94
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t68, ptr %l44
  %t69 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l95
  br label %bb31
bb31:
  %t70 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l95
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l45
  %t71 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l96
  br label %bb32
bb32:
  %t72 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l96
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t72, ptr %l46
  %t73 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t73, ptr %l97
  br label %bb33
bb33:
  %t74 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l97
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t74, ptr %l47
  %t75 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t75, ptr %l98
  br label %bb34
bb34:
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l98
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l48
  %t77 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t77, ptr %l99
  br label %bb35
bb35:
  %t78 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t78, ptr %l49
  %t79 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l100
  br label %bb36
bb36:
  %t80 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l100
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t80, ptr %l50
  %t81 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l101
  br label %bb37
bb37:
  %t82 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l101
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l51
  %t83 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l102
  br label %bb38
bb38:
  %t84 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l102
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t84, ptr %l52
  %t85 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l103
  br label %bb39
bb39:
  %t86 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l103
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %l53
  %t87 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t87, ptr %l104
  br label %bb40
bb40:
  %t88 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l104
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %l54
  %t89 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t89, ptr %l105
  br label %bb41
bb41:
  %t90 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t90, ptr %l55
  %t91 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t91, ptr %l106
  br label %bb42
bb42:
  %t92 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l106
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t92, ptr %l56
  %t93 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t93, ptr %l107
  br label %bb43
bb43:
  %t94 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %l57
  %t95 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t95, ptr %l108
  br label %bb44
bb44:
  %t96 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l108
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t96, ptr %l58
  %t97 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %l109
  br label %bb45
bb45:
  %t98 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l109
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t98, ptr %l59
  %t99 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l110
  br label %bb46
bb46:
  %t100 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l110
  %t101 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 0
  %t102 = load ptr, ptr %l3, !tbaa !29
  store ptr %t102, ptr %t101, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 1
  %t104 = load i64, ptr %l4, !tbaa !24
  store i64 %t104, ptr %t103, !tbaa !24
  %t105 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 2
  %t106 = load i1, ptr %l5, !tbaa !21
  store i1 %t106, ptr %t105, !tbaa !21
  %t107 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 3
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %t107
  %t109 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 4
  %t110 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t109
  %t111 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 5
  %t112 = load i1, ptr %l8, !tbaa !21
  store i1 %t112, ptr %t111, !tbaa !21
  %t113 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 6
  %t114 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t114, ptr %t113
  %t115 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 7
  %t116 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t116, ptr %t115
  %t117 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 8
  %t118 = load i32, ptr %l11, !tbaa !23
  store i32 %t118, ptr %t117, !tbaa !23
  %t119 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 9
  %t120 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %t119
  %t121 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 10
  %t122 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t122, ptr %t121
  %t123 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 11
  %t124 = load i64, ptr %l14, !tbaa !24
  store i64 %t124, ptr %t123, !tbaa !24
  %t125 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 12
  %t126 = load i64, ptr %l15, !tbaa !24
  store i64 %t126, ptr %t125, !tbaa !24
  %t127 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 13
  %t128 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t128, ptr %t127
  %t129 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 14
  %t130 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l17
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t130, ptr %t129
  %t131 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 15
  %t132 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l18
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %t131
  %t133 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 16
  %t134 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t134, ptr %t133
  %t135 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 17
  %t136 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t136, ptr %t135
  %t137 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 18
  %t138 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %t137
  %t139 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 19
  %t140 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %t139
  %t141 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 20
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 21
  %t144 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %t143
  %t145 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 22
  %t146 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t146, ptr %t145
  %t147 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 23
  %t148 = load i64, ptr %l26, !tbaa !24
  store i64 %t148, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 24
  %t150 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t150, ptr %t149
  %t151 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 25
  %t152 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t152, ptr %t151
  %t153 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 26
  %t154 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t154, ptr %t153
  %t155 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 27
  %t156 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %t155
  %t157 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 28
  %t158 = load i64, ptr %l31, !tbaa !24
  store i64 %t158, ptr %t157, !tbaa !24
  %t159 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 29
  %t160 = load i64, ptr %l32, !tbaa !24
  store i64 %t160, ptr %t159, !tbaa !24
  %t161 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 30
  %t162 = load i64, ptr %l33, !tbaa !24
  store i64 %t162, ptr %t161, !tbaa !24
  %t163 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 31
  %t164 = load i64, ptr %l34, !tbaa !24
  store i64 %t164, ptr %t163, !tbaa !24
  %t165 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 32
  %t166 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t166, ptr %t165
  %t167 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 33
  %t168 = load %"compiler/source:Span", ptr %l36
  store %"compiler/source:Span" %t168, ptr %t167
  %t169 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 34
  %t170 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %t169
  %t171 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 35
  %t172 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l38
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t172, ptr %t171
  %t173 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 36
  %t174 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l39
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %t173
  %t175 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 37
  %t176 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %t175
  %t177 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 38
  %t178 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t178, ptr %t177
  %t179 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 39
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %t179
  %t181 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 40
  %t182 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l43
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t182, ptr %t181
  %t183 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 41
  %t184 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t184, ptr %t183
  %t185 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 42
  %t186 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t186, ptr %t185
  %t187 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 43
  %t188 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %t187
  %t189 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 44
  %t190 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l47
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t190, ptr %t189
  %t191 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 45
  %t192 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t192, ptr %t191
  %t193 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 46
  %t194 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %t193
  %t195 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 47
  %t196 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l50
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t196, ptr %t195
  %t197 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 48
  %t198 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t198, ptr %t197
  %t199 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 49
  %t200 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l52
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t200, ptr %t199
  %t201 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 50
  %t202 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t202, ptr %t201
  %t203 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 51
  %t204 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t204, ptr %t203
  %t205 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 52
  %t206 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t206, ptr %t205
  %t207 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 53
  %t208 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l56
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t208, ptr %t207
  %t209 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 54
  %t210 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l57
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t210, ptr %t209
  %t211 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 55
  %t212 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l58
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t212, ptr %t211
  %t213 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 56
  %t214 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l59
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t214, ptr %t213
  %t215 = getelementptr %"compiler/free:walker", ptr %l111, i32 0, i32 57
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t100, ptr %t215
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l111, i64 464, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" handle" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"place " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" sole " }>, align 8
@.c6 = private unnamed_addr constant [5 x i8] c"true\00"
@.c7 = private unnamed_addr constant [6 x i8] c"false\00"
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" lets " }>, align 8
@.d9 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" stores " }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" why " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d12 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"store place " }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" body " }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" kind " }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d18 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"letgo place " }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" body " }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" kind " }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"body " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d26 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" stored " }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eRender_2emut_20std_2fprelude_2flist_3aList_3cI64_3e_26(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %a0, !tbaa !29
  store ptr %t2, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = icmp ne ptr %t3, null
  br i1 %t4, label %bb1, label %bb3
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sge i64 %t6, 8
  br i1 %t7, label %bb4, label %bb5
bb2:
  br label %ret
bb3:
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb2
bb4:
  %t11 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb2
bb5:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t13, 1
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr @__olang_prog_scope
  %t18 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eStr_3cI64_3e(ptr %t16, ptr %s1, ptr %t15)
  store { i64, ptr } %t18, ptr %l7
  br label %bb6
bb6:
  %t19 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  call void @__olang_sb_put(ptr %v0, ptr %t20, i64 %t21)
  call void @__olang_scope_close(ptr %s1)
  br label %bb2
ret:
  ret void
}

@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" esc " }>, align 8
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" multi " }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" res " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_sb_done(ptr)
@.d31 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tasks " }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" hidden " }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"its elements" }>, align 8
@.d37 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"a task can reach it: nothing is freed early where a program has tasks" }>, align 8
@.d38 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"C may call an export fn from a thread of its own: nothing is freed early where a program has one" }>, align 8
@.d39 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"a destructor, Str, Eq or Hash lets go of it where no call is written" }>, align 8
@.d40 = private constant <{ i64, [144 x i8] }> <{ i64 0, [144 x i8] c"its new value may hold an instance whose destructor is still to run (O16), which a let-go would run early: build that instance outside the value" }>, align 8
@.d41 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"a value built into what it holds may hold an instance whose destructor is still to run (O16)" }>, align 8
@.d42 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"a call building into what it holds may register an instance whose destructor is still to run (O16)" }>, align 8
@.d43 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"its new value cannot be built in a region of its own here" }>, align 8
@.d44 = private constant <{ i64, [135 x i8] }> <{ i64 0, [135 x i8] c"what it holds has a destructor still to run when it lets go (O15): take each value out ('Take', 'Pop', 'TakeAt') and Destroy() it (C9b)" }>, align 8
@.d45 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"its new value is moved out of a place that keeps" }>, align 8
@.d46 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"its value is moved out of a place whose values have no destructor" }>, align 8
@.d47 = private constant <{ i64, [127 x i8] }> <{ i64 0, [127 x i8] c"a value taken out of a collection is destroyed only in code compiled with the program it is in - the program's own module (B3i)" }>, align 8
@.d48 = private constant <{ i64, [75 x i8] }> <{ i64 0, [75 x i8] c"it is taken out of a collection whose values are not each held only there: " }>, align 8
@.d49 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"its value is constant data, which no Destroy() can end" }>, align 8
@.d50 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"it is given no instance built for it here" }>, align 8
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb10
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 ]
bb3:
  br label %bb10
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb7, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb8, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb9, label %bb1
bb7:
  br label %bb3
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  %t46 = load i1, ptr %l2, !tbaa !21
  store i1 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d54 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d55 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tree" }>, align 8
@.d56 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d57 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"its value cannot be built in a region of its own here" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d59 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"' is a match's binding, a second name for what the match reads" }>, align 8
@.d60 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d61 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"'; give it new storage - a constructor call, '$...', 'Clone()'" }>, align 8
@.d62 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"its value may be a try's default, not built for it" }>, align 8
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"its value is existing storage: '" }>, align 8
@.d68 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"' - give it an instance of its own: a constructor call, or a call whose result is built" }>, align 8
@.d69 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d70 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"its new value is moved out of another place" }>, align 8
@.d71 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"its new value has a default" }>, align 8
@.d72 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d73 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d74 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"'; give it new storage - a constructor call, '$...', 'Clone()'" }>, align 8
@.d75 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"its new value is kept in another place too" }>, align 8
@.d76 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"its new value is built in a module compiled on its own" }>, align 8
@.d77 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
@.d78 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d80 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a value of it read in this statement is in use when '" }>, align 8
@.d81 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"' lets go of it; read what you need first" }>, align 8
@.d82 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d83 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d85 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" from '" }>, align 8
@.d86 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d89 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d90 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", '" }>, align 8
@.d91 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'," }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"what the loop on line " }>, align 8
@.d94 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" walks" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"after '" }>, align 8
@.d98 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
@.d99 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"), where the generator's caller may let go of it; read what you need" }>, align 8
@.d100 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" before the yield" }>, align 8
@.d101 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"after it lets go of it (line " }>, align 8
@.d102 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"); read what you need" }>, align 8
@.d103 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" before" }>, align 8
@.d104 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"after '" }>, align 8
@.d105 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
@.d106 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"), which " }>, align 8
@.d107 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"; read what you need" }>, align 8
@.d108 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" before the call" }>, align 8
@.d109 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is used here, " }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cBool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d110 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d111 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
@G_2ecompiler_2ffree_2eLDrop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLVacate = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eMovBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRView = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSOk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecalleeBody(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eRunFrom_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bd50611d1e2a0638_e097f182a5e2b38c = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2eRunFrom_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_c2d5333a05d32c09_964b2d9d99056abd = external constant [0 x i8]
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/free:reason" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c15d1cb682121452_ddf973d5edb43126 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_af0f3c7979dc9853_f8576f39d689087 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_Ha6bcf4d517e3d7b46809e1dbf938da91(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H68b172a457d32a9e162e965ccea2aab6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2eRunFrom_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b6badb915820fc29_a28e19f30b26ee8d = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3a516a19293feeda_7f77204653e04cce = external constant [0 x i8]
@olang_loc_f6ef9e24276337f6_9f5fd13826c6ac8a = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_77e2c420ac7907a9_804235f2ad53d = external constant [0 x i8]
@olang_loc_13d43c3a12e7be33_d312cf328348084f = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDestroy(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b10cc208e99f9718_d49c9c08520d6614 = external constant [0 x i8]
@olang_loc_1c3c578240008a_e9f41163a0859586 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorStore_3e_2eRunF_Hfb62abbaadc4bc18a4ac1ddebfb1ceda(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_427e00c4471cf70e_a3ac6b2261c0f5b2 = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aorCall_3e_2eRunFrom_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_739c10b15f53274f_734afabb36dc9f33 = external constant [0 x i8]
@olang_loc_7525dd872e188514_1083808a0d947818 = external constant [0 x i8]
@olang_loc_4ad9b6421067a286_9f369779125df38a = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@olang_loc_ead41433cbf9310a_52e529e4fec80746 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@olang_loc_28957fcf5fdf754b_19b1529d8a3f7d27 = external constant [0 x i8]
@olang_loc_970b795e64a6e941_bb6c860f435c1735 = external constant [0 x i8]
@olang_loc_83b66f45861ca9b0_7b02274503008844 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3, i32 %a4, i1 %a5)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eSetAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
@olang_loc_abb447fb014369ff_ca54bae4e013147b = external constant [0 x i8]
@olang_loc_b390d81e3df133fe_1bb65207cb7ceffa = external constant [0 x i8]
@olang_loc_f1cf9d8b5dd1d1b5_4d41c45ca418d191 = external constant [0 x i8]
@olang_loc_7bd178b281ab108b_bca5961225cfb287 = external constant [0 x i8]
@olang_loc_54a8cb88ede7d99c_f1d49282556d5568 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_df2621a9cc7e5891_c8dc80a57ad57a3d = external constant [0 x i8]
@olang_loc_d176219a3bee3f8a_90c874c8f8700e56 = external constant [0 x i8]
@olang_loc_3832ed25f787c577_46d12f44adcfa45b = external constant [0 x i8]
@olang_loc_78b7d87e61167558_7d12aa6674d4d96c = external constant [0 x i8]
@olang_loc_5c0fdc79e2d66a14_68e7480db742a728 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_5c44d6b41b035ab1_55f561a861d07b6d = external constant [0 x i8]
@olang_loc_3bfd4abaed3d7178_ecedd42d9535955c = external constant [0 x i8]
declare i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %a0)
declare ptr @compiler_2ffree_2ecallOf(ptr %v0, ptr %a0)
declare %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8)
@olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRemovalNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bdafa441ac13699b_f5af7a3548cb73f = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_6cb79447255537d7_e828faabaec907d3 = external constant [0 x i8]
@olang_loc_59b1cf5f5f6723c1_2bbad9bd6a5cb915 = external constant [0 x i8]
@olang_loc_68d66244454596f9_ea33ff3f8eb363fd = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i1 %a5, i1 %a6)
@olang_loc_24949bfdf5bb746b_61a8afba06ee945f = external constant [0 x i8]
@olang_loc_a27303051a78a613_6e77afe7cfa56447 = external constant [0 x i8]
@olang_loc_963836c0f8071dfd_af84cd38f37029b9 = external constant [0 x i8]
@olang_loc_e84a97658b0243cc_8016afdefcf039e8 = external constant [0 x i8]
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [1 x i64] } %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eplaceMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2etryMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_2f86b0bb9e05ec4_6260055ddf2cdd10 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2elocalName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_304dd9f782c5c299_7aedab6f7faf5da5 = external constant [0 x i8]
@olang_loc_ceff65db82d42b72_bd0ee798a65f80fe = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1c2ece56a8f93bb3_9a04e0623a4a84af = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_bcb566df5976d573_60ca408bac10c90f = external constant [0 x i8]
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eoval(i64 %a0)
declare i1 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237 = external constant [0 x i8]
declare i1 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClone_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_7f12d3772dd0a929_45b952e679e83a85 = external constant [0 x i8]
@olang_loc_fd03f9e0e77d658_c5fe745f2729a3d4 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eSFail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_ecfdd571afc7fb57_85e5c41b21451123 = external constant [0 x i8]
declare { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_5c8710160ed2ee88_42fe4478e6ab17dc = external constant [0 x i8]
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLDestroy = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eSpan(ptr %v0, ptr %a0)
@olang_loc_4b8c217179c46859_da1f305a1bc3b10d = external constant [0 x i8]
@olang_loc_8eca167e18f35462_967477b580f85776 = external constant [0 x i8]
@olang_loc_2aee3a5952843263_7eebd62eaf5d5017 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0)
@olang_loc_e32699ce7a94654a_1a46213a714ace46 = external constant [0 x i8]
@olang_loc_9bcfcd4682c2cf8b_e11249f2fcc24427 = external constant [0 x i8]
@olang_loc_d00dfbb4bbbc7050_caf5ecf8a62b36ac = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H96e9eb9990b7b2982627078c49255e88(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ffree_2eLYield = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, %"compiler/source:Span" %a6, i64 %a7, i1 %a8)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ffree_3aletGo_3e_2ePush_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1)
@G_2ecompiler_2ffree_2eAnyPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_44d31ac3b091972d_4fc8cc490260e559 = external constant [0 x i8]
@olang_loc_7676aaa4af173342_5bef0e3278c42ba6 = external constant [0 x i8]
@olang_loc_1665755e987b0d60_2375c09fda7e834 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_71c754545de4040c_468b95bb5168a5f8 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@olang_loc_3495f832c6af5d35_e0a5ccc226d89761 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_311feee871305b59_d38294057dde4ced = external constant [0 x i8]
@olang_loc_421add8d063ee188_aab923ea260c413c = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_34bfc259355dec67_8a2d14d061fee643 = external constant [0 x i8]
@olang_loc_806a74b5c91de186_4e306eb4964e9ec2 = external constant [0 x i8]
@olang_loc_350c73b6578d6328_239abab62451b64c = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6)
@olang_loc_2a94798a60b7293_3a863c891acd45e7 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7)
declare %"compiler/source:Span" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7309f54021366b21_bf19c41763566c5 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_He8628b0a6160e3784b3615fe3f392582(ptr %v0, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hf6bbcd606af6c869015b58a6b615b2ae(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8c0c33fee9f1510c_8a29d4fc33338c88 = external constant [0 x i8]
@olang_loc_de370d56f621a286_665adcb3259bb65a = external constant [0 x i8]
@olang_loc_61a66e32b2a4c4a5_788650647dbfbbd9 = external constant [0 x i8]
@olang_loc_4d2004aee1a8ca38_5ea03f23f1e608cc = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5)
@olang_loc_be06d4fe1f669970_91dc6d2622a64d44 = external constant [0 x i8]
@olang_loc_bc199299ca123d01_d246cbf06301dc35 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_7635bc67c3b310ea_9408068343213e7e = external constant [0 x i8]
@olang_loc_546be3fdfb2e7861_5a4791e17fa5075d = external constant [0 x i8]
@olang_loc_5891e56eddc46c99_f944b0e713971375 = external constant [0 x i8]
@olang_loc_16263ed1acd4aa7e_23dcb8f717a142b2 = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ea2e0f0d6ffcb248_fe73fa1c8e55849c = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6e2453cb19a4d71d_88f1503d6cec0391 = external constant [0 x i8]
@olang_loc_a8e684701cb727b6_7b41502ddc5bea8a = external constant [0 x i8]
@olang_loc_3e8b13b2a7075e62_22250d1a20f2250e = external constant [0 x i8]
@olang_loc_83047756a0f84ae3_95aa60b35b875f1f = external constant [0 x i8]
@olang_loc_ce893683105a8b06_84bedcfad8df0b4a = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2eCl_H0a9e00411db21d32682611ff4a2aedde(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_H2607a290a254b1368332c2620bcac78c(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3_Hd29545d6ce80f0b71db83a570b969f39(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_1b38cdd871e6a94_bc3035ea47e7c9d8 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %a0)
@olang_loc_40628693553637f3_9a0aaf33c7b3625f = external constant [0 x i8]
@olang_loc_73267d5e0cab398e_8c6ff0bab5f15012 = external constant [0 x i8]
@olang_loc_a4448d4b24e169cf_c9af2cff75b97a13 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eStr_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cmut_20std_2fprelude_2flist_3aList_3cI64_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aPlace_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
