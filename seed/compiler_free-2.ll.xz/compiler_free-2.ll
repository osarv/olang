; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fnRecs", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, { i64, [2 x i64] }, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i1, i64, %"compiler/source:Span", i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i1, i1, i1, i1, i64, i1, i1, i64, i1, i1, i1, i1, i64, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/free:mustW" = type { ptr, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/free:retire" = type { i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDroppedMove(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l16 = alloca ptr
  %l24 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 65
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %a1)
  store i64 %t11, ptr %l9
  br label %bb4
bb4:
  %t12 = load i64, ptr %l9, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t13, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb8
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l16
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  store i1 %t29, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l12, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 32
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t35, i64 %t36)
  store i64 %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load i64, ptr %l24, !tbaa !24
  store i64 %t40, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l3, !tbaa !24
  %t42 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t56 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t48, i64 %t53)
  store i1 %t56, ptr %l33
  br label %bb16
bb16:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t62 = sub i64 %t58, %t59
  store i64 %t62, ptr %l34, !tbaa !24
  br label %bb19
bb18:
  store i64 -1, ptr %l34, !tbaa !24
  br label %bb19
bb19:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eDump(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/free:letGo"
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca %"compiler/free:store"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/free:store"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca %"compiler/free:letGo"
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca %"std/prelude/text:StringBuilder"
  %l32 = alloca ptr
  %l35 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l62 = alloca i64
  %l64 = alloca i64
  %l69 = alloca %"compiler/free:letGo"
  %l79 = alloca i64
  %l81 = alloca i64
  %l86 = alloca %"compiler/free:store"
  %l99 = alloca { i64, ptr }
  %l106 = alloca { ptr, ptr }
  %l110 = alloca i32
  %l111 = alloca { i64, ptr }
  %l112 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %l125 = alloca i64
  %l129 = alloca i1
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i64
  %l135 = alloca i64
  %l139 = alloca i64
  %l143 = alloca %"compiler/free:reason"
  %l151 = alloca i64
  %l153 = alloca i64
  %l158 = alloca %"compiler/free:store"
  %l159 = alloca ptr
  %l160 = alloca i64
  %l161 = alloca i64
  %l162 = alloca i64
  %l163 = alloca i64
  %l171 = alloca { i64, ptr }
  %l178 = alloca i64
  %l180 = alloca i64
  %l185 = alloca %"compiler/free:letGo"
  %l186 = alloca ptr
  %l187 = alloca i64
  %l188 = alloca i64
  %l189 = alloca i64
  %l197 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l207 = alloca i64
  %l211 = alloca i64
  %l214 = alloca i64
  %l235 = alloca ptr
  %l236 = alloca i64
  %l238 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i64
  %l245 = alloca i1
  %l249 = alloca ptr
  %l250 = alloca i64
  %l252 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca i64
  %l259 = alloca ptr
  %l260 = alloca i64
  %l263 = alloca { i64, ptr }
  %l267 = alloca ptr
  %l271 = alloca ptr
  %l275 = alloca ptr
  %l279 = alloca ptr
  %l283 = alloca ptr
  %l289 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.builder
  %s25room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l30
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l30
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t3)
  store ptr %t5, ptr %l32
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l32, !tbaa !29
  store ptr %t6, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 8
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l35
  br label %bb3
bb3:
  %t12 = load i64, ptr %l35, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb9
bb6:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l42, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb8
bb8:
  %t39 = load i64, ptr %l42, !tbaa !24
  store i64 %t39, ptr %l39, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l39, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb56
bb12:
  br label %bb13
bb13:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 43
  store ptr %t61, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l11, !tbaa !24
  store i64 %t63, ptr %l62, !tbaa !24
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t64)
  store i64 %t66, ptr %l64
  br label %bb15
bb15:
  %t67 = load i64, ptr %l62, !tbaa !24
  %t68 = load i64, ptr %l64, !tbaa !24
  %t69 = icmp slt i64 %t67, %t68
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l10, !tbaa !29
  %t74 = load i64, ptr %l11, !tbaa !24
  %t77 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/free:letGo" %t77, ptr %l69
  br label %bb19
bb19:
  %t78 = load %"compiler/free:letGo", ptr %l69
  store %"compiler/free:letGo" %t78, ptr %l12
  %t79 = getelementptr %"compiler/free:letGo", ptr %l12, i32 0, i32 0
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = icmp eq i64 %t80, %t81
  br i1 %t84, label %bb20, label %bb21
bb20:
  %t86 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t86, 1
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l11, !tbaa !24
  br label %bb14
bb24:
  store i64 0, ptr %l13, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:Free", ptr %t94, i32 0, i32 42
  store ptr %t96, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb25
bb25:
  %t98 = load i64, ptr %l15, !tbaa !24
  store i64 %t98, ptr %l79, !tbaa !24
  %t99 = load ptr, ptr %l14, !tbaa !29
  %t101 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t99)
  store i64 %t101, ptr %l81
  br label %bb26
bb26:
  %t102 = load i64, ptr %l79, !tbaa !24
  %t103 = load i64, ptr %l81, !tbaa !24
  %t104 = icmp slt i64 %t102, %t103
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb27, label %bb28
bb27:
  br label %bb35
bb28:
  br label %bb29
bb29:
  %t108 = load ptr, ptr %l14, !tbaa !29
  %t109 = load i64, ptr %l15, !tbaa !24
  %t112 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store %"compiler/free:store" %t112, ptr %l86
  br label %bb30
bb30:
  %t113 = load %"compiler/free:store", ptr %l86
  store %"compiler/free:store" %t113, ptr %l16
  %t114 = getelementptr %"compiler/free:store", ptr %l16, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = icmp eq i64 %t115, %t116
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = add i64 %t121, 1
  store i64 %t123, ptr %l13, !tbaa !24
  br label %bb33
bb32:
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l15, !tbaa !24
  br label %bb25
bb35:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:Free", ptr %t129, i32 0, i32 2
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/scope:Scoper", ptr %t132, i32 0, i32 5
  %t135 = load { ptr, ptr }, ptr %t134
  %t137 = extractvalue { ptr, ptr } %t135, 0
  %t138 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t139 = icmp eq ptr %t137, %t138
  %t140 = extractvalue { ptr, ptr } %t135, 1
  %t141 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t142 = icmp eq ptr %t140, %t141
  %t143 = and i1 %t139, %t142
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb36, label %bb37
bb36:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:Free", ptr %t147, i32 0, i32 2
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/scope:Scoper", ptr %t150, i32 0, i32 5
  %t153 = load { ptr, ptr }, ptr %t152
  %t155 = extractvalue { ptr, ptr } %t153, 0
  %t156 = extractvalue { ptr, ptr } zeroinitializer, 0
  %t157 = icmp eq ptr %t155, %t156
  %t158 = extractvalue { ptr, ptr } %t153, 1
  %t159 = extractvalue { ptr, ptr } zeroinitializer, 1
  %t160 = icmp eq ptr %t158, %t159
  %t161 = and i1 %t157, %t160
  br i1 %t161, label %bb38, label %bb39
bb37:
  %t163 = load ptr, ptr %l2, !tbaa !29
  store ptr %t163, ptr %l112, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/free:Free", ptr %t164, i32 0, i32 8
  %t167 = load i64, ptr %l8, !tbaa !24
  %t170 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t166, i64 %t167)
  store i32 %t170, ptr %l116
  br label %bb43
bb38:
  call void @__olang_check_failed(ptr @olang_loc_8f29d0df7ac0b0b1_5a3f673e10b5ae55)
  unreachable
bb39:
  br label %bb40
bb40:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/free:Free", ptr %t171, i32 0, i32 2
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/scope:Scoper", ptr %t174, i32 0, i32 5
  %t177 = load { ptr, ptr }, ptr %t176
  store { ptr, ptr } %t177, ptr %l106
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:Free", ptr %t178, i32 0, i32 8
  %t181 = load i64, ptr %l8, !tbaa !24
  %t184 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t180, i64 %t181)
  store i32 %t184, ptr %l110
  br label %bb41
bb41:
  %t185 = load { ptr, ptr }, ptr %l106
  %t186 = extractvalue { ptr, ptr } %t185, 0
  %t187 = extractvalue { ptr, ptr } %t185, 1
  %t188 = load i32, ptr %l110, !tbaa !23
  %t189 = call { i64, ptr } %t186(ptr %t187, ptr %s2, i32 %t188)
  store { i64, ptr } %t189, ptr %l111
  br label %bb42
bb42:
  %t190 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t190, ptr %l99, !tbaa !27
  br label %bb45
bb43:
  %t191 = load ptr, ptr %l112, !tbaa !29
  %t192 = load i32, ptr %l116, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t191, i32 %t192)
  store { i64, ptr } %t193, ptr %l117
  br label %bb44
bb44:
  %t194 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 1
  %t196 = extractvalue { i64, ptr } %t194, 0
  %t197 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t196)
  call void @olang_textcopy(ptr %t197, ptr %t195, i64 %t196)
  %t198 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  store { i64, ptr } %t199, ptr %l99, !tbaa !27
  br label %bb45
bb45:
  %t201 = load { i64, ptr }, ptr %l99, !tbaa !27
  store ptr %l1, ptr %l119, !tbaa !29
  %t202 = load i64, ptr %l8, !tbaa !24
  store i64 %t202, ptr %l120, !tbaa !24
  store { i64, ptr } %t201, ptr %l121, !tbaa !27
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/free:Free", ptr %t204, i32 0, i32 9
  %t207 = load i64, ptr %l8, !tbaa !24
  %t210 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t206, i64 %t207)
  store i64 %t210, ptr %l125
  br label %bb46
bb46:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/free:Free", ptr %t211, i32 0, i32 10
  %t214 = load i64, ptr %l8, !tbaa !24
  %t217 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t213, i64 %t214)
  store i1 %t217, ptr %l129
  br label %bb47
bb47:
  %t218 = load i1, ptr %l129, !tbaa !21
  br i1 %t218, label %bb48, label %bb49
bb48:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l130, !tbaa !27
  br label %bb50
bb49:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l130, !tbaa !27
  br label %bb50
bb50:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load i64, ptr %l8, !tbaa !24
  %t223 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t219, i64 %t220)
  store i1 %t223, ptr %l133
  br label %bb51
bb51:
  %t224 = load i64, ptr %l9, !tbaa !24
  store i64 %t224, ptr %l134, !tbaa !24
  %t225 = load i64, ptr %l13, !tbaa !24
  store i64 %t225, ptr %l135, !tbaa !24
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:Free", ptr %t226, i32 0, i32 44
  %t229 = load i64, ptr %l8, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l139
  br label %bb52
bb52:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/free:Free", ptr %t233, i32 0, i32 46
  %t236 = load i64, ptr %l8, !tbaa !24
  %t239 = call %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t235, i64 %t236)
  store %"compiler/free:reason" %t239, ptr %l143
  br label %bb53
bb53:
  %t240 = getelementptr %"compiler/free:reason", ptr %l143, i32 0, i32 3
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t242 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t243 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t244 = load i64, ptr %l120, !tbaa !24
  %t245 = call i64 @__olang_fmt_i64(ptr null, i64 %t244)
  %t246 = add i64 %t243, %t245
  %t247 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t250 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = load i64, ptr %l125, !tbaa !24
  %t258 = call i64 @__olang_fmt_i64(ptr null, i64 %t257)
  %t259 = add i64 %t256, %t258
  %t260 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = add i64 %t259, %t262
  %t264 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t265 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t266 = add i64 %t263, %t265
  %t267 = load i1, ptr %l133, !tbaa !21
  %t268 = select i1 %t267, ptr @.c6, ptr @.c7
  %t269 = select i1 %t267, i64 4, i64 5
  %t270 = add i64 %t266, %t269
  %t271 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t272 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t273 = add i64 %t270, %t272
  %t274 = load i64, ptr %l134, !tbaa !24
  %t275 = call i64 @__olang_fmt_i64(ptr null, i64 %t274)
  %t276 = add i64 %t273, %t275
  %t277 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t278 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t279 = add i64 %t276, %t278
  %t280 = load i64, ptr %l135, !tbaa !24
  %t281 = call i64 @__olang_fmt_i64(ptr null, i64 %t280)
  %t282 = add i64 %t279, %t281
  %t283 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = load i64, ptr %l139, !tbaa !24
  %t287 = call i64 @__olang_fmt_i64(ptr null, i64 %t286)
  %t288 = add i64 %t285, %t287
  %t289 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t290 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t291 = add i64 %t288, %t290
  %t293 = extractvalue { i64, ptr } %t241, 1
  %t294 = extractvalue { i64, ptr } %t241, 0
  %t295 = add i64 %t291, %t294
  %t296 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t297 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t298 = add i64 %t295, %t297
  %t299 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t298)
  call void @olang_textcopy(ptr %t299, ptr %t242, i64 %t243)
  %t300 = getelementptr i8, ptr %t299, i64 %t243
  %t301 = call i64 @__olang_fmt_i64(ptr %t300, i64 %t244)
  %t302 = getelementptr i8, ptr %t300, i64 %t245
  call void @olang_textcopy(ptr %t302, ptr %t247, i64 %t248)
  %t303 = getelementptr i8, ptr %t302, i64 %t248
  call void @olang_textcopy(ptr %t303, ptr %t251, i64 %t252)
  %t304 = getelementptr i8, ptr %t303, i64 %t252
  call void @olang_textcopy(ptr %t304, ptr %t254, i64 %t255)
  %t305 = getelementptr i8, ptr %t304, i64 %t255
  %t306 = call i64 @__olang_fmt_i64(ptr %t305, i64 %t257)
  %t307 = getelementptr i8, ptr %t305, i64 %t258
  call void @olang_textcopy(ptr %t307, ptr %t261, i64 %t262)
  %t308 = getelementptr i8, ptr %t307, i64 %t262
  call void @olang_textcopy(ptr %t308, ptr %t264, i64 %t265)
  %t309 = getelementptr i8, ptr %t308, i64 %t265
  call void @olang_textcopy(ptr %t309, ptr %t268, i64 %t269)
  %t310 = getelementptr i8, ptr %t309, i64 %t269
  call void @olang_textcopy(ptr %t310, ptr %t271, i64 %t272)
  %t311 = getelementptr i8, ptr %t310, i64 %t272
  %t312 = call i64 @__olang_fmt_i64(ptr %t311, i64 %t274)
  %t313 = getelementptr i8, ptr %t311, i64 %t275
  call void @olang_textcopy(ptr %t313, ptr %t277, i64 %t278)
  %t314 = getelementptr i8, ptr %t313, i64 %t278
  %t315 = call i64 @__olang_fmt_i64(ptr %t314, i64 %t280)
  %t316 = getelementptr i8, ptr %t314, i64 %t281
  call void @olang_textcopy(ptr %t316, ptr %t283, i64 %t284)
  %t317 = getelementptr i8, ptr %t316, i64 %t284
  %t318 = call i64 @__olang_fmt_i64(ptr %t317, i64 %t286)
  %t319 = getelementptr i8, ptr %t317, i64 %t287
  call void @olang_textcopy(ptr %t319, ptr %t289, i64 %t290)
  %t320 = getelementptr i8, ptr %t319, i64 %t290
  call void @olang_textcopy(ptr %t320, ptr %t293, i64 %t294)
  %t321 = getelementptr i8, ptr %t320, i64 %t294
  call void @olang_textcopy(ptr %t321, ptr %t296, i64 %t297)
  %t322 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t299, 1
  %t325 = extractvalue { i64, ptr } %t323, 0
  %t326 = extractvalue { i64, ptr } %t323, 1
  %t327 = mul i64 %t325, 1
  %t328 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t327)
  call void @llvm.memcpy.p0.p0.i64(ptr %t328, ptr %t326, i64 %t327, i1 false)
  %t329 = insertvalue { i64, ptr } undef, i64 %t325, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  %t331 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t331, { i64, ptr } %t330)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s2)
  br label %bb55
bb55:
  %t333 = load i64, ptr %l7, !tbaa !24
  %t335 = add i64 %t333, 1
  store i64 %t335, ptr %l7, !tbaa !24
  br label %bb10
bb56:
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = getelementptr %"compiler/free:Free", ptr %t337, i32 0, i32 42
  store ptr %t339, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s15
  %t341 = load i64, ptr %l19, !tbaa !24
  store i64 %t341, ptr %l151, !tbaa !24
  %t342 = load ptr, ptr %l18, !tbaa !29
  %t344 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t342)
  store i64 %t344, ptr %l153
  br label %bb58
bb58:
  %t345 = load i64, ptr %l151, !tbaa !24
  %t346 = load i64, ptr %l153, !tbaa !24
  %t347 = icmp slt i64 %t345, %t346
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s15)
  br label %bb66
bb60:
  br label %bb61
bb61:
  %t351 = load ptr, ptr %l18, !tbaa !29
  %t352 = load i64, ptr %l19, !tbaa !24
  %t355 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t351, i64 %t352)
  store %"compiler/free:store" %t355, ptr %l158
  br label %bb62
bb62:
  %t356 = load %"compiler/free:store", ptr %l158
  store %"compiler/free:store" %t356, ptr %l20
  store ptr %l1, ptr %l159, !tbaa !29
  %t357 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 0
  %t358 = load i64, ptr %t357, !tbaa !24
  store i64 %t358, ptr %l160, !tbaa !24
  %t359 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 1
  %t360 = load i64, ptr %t359, !tbaa !24
  store i64 %t360, ptr %l161, !tbaa !24
  %t361 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 4
  %t362 = load i64, ptr %t361, !tbaa !24
  store i64 %t362, ptr %l162, !tbaa !24
  %t363 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 6
  %t364 = load i64, ptr %t363, !tbaa !24
  store i64 %t364, ptr %l163, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/free:Free", ptr %t365, i32 0, i32 0
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t370 = getelementptr %"compiler/generic:Program", ptr %t368, i32 0, i32 0
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t373 = getelementptr %"compiler/load:Loader", ptr %t371, i32 0, i32 4
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t375 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 2
  %t376 = load i64, ptr %t375, !tbaa !24
  %t377 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 3
  %t378 = getelementptr %"compiler/source:Span", ptr %t377, i32 0, i32 0
  %t379 = load i32, ptr %t378, !tbaa !23
  %t381 = sext i32 %t379 to i64
  %t385 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s15, ptr %t374, i64 %t376, i64 %t381)
  store { i64, ptr } %t385, ptr %l171
  br label %bb63
bb63:
  %t386 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t387 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t388 = load i64, ptr %l160, !tbaa !24
  %t389 = call i64 @__olang_fmt_i64(ptr null, i64 %t388)
  %t390 = add i64 %t387, %t389
  %t391 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t392 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t393 = add i64 %t390, %t392
  %t394 = load i64, ptr %l161, !tbaa !24
  %t395 = call i64 @__olang_fmt_i64(ptr null, i64 %t394)
  %t396 = add i64 %t393, %t395
  %t397 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t398 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t399 = add i64 %t396, %t398
  %t400 = load i64, ptr %l162, !tbaa !24
  %t401 = call i64 @__olang_fmt_i64(ptr null, i64 %t400)
  %t402 = add i64 %t399, %t401
  %t403 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t405 = add i64 %t402, %t404
  %t406 = load i64, ptr %l163, !tbaa !24
  %t407 = call i64 @__olang_fmt_i64(ptr null, i64 %t406)
  %t408 = add i64 %t405, %t407
  %t409 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t410 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t411 = add i64 %t408, %t410
  %t412 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t413 = extractvalue { i64, ptr } %t412, 1
  %t414 = extractvalue { i64, ptr } %t412, 0
  %t415 = add i64 %t411, %t414
  %t416 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t417 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t418 = add i64 %t415, %t417
  %t419 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t418)
  call void @olang_textcopy(ptr %t419, ptr %t386, i64 %t387)
  %t420 = getelementptr i8, ptr %t419, i64 %t387
  %t421 = call i64 @__olang_fmt_i64(ptr %t420, i64 %t388)
  %t422 = getelementptr i8, ptr %t420, i64 %t389
  call void @olang_textcopy(ptr %t422, ptr %t391, i64 %t392)
  %t423 = getelementptr i8, ptr %t422, i64 %t392
  %t424 = call i64 @__olang_fmt_i64(ptr %t423, i64 %t394)
  %t425 = getelementptr i8, ptr %t423, i64 %t395
  call void @olang_textcopy(ptr %t425, ptr %t397, i64 %t398)
  %t426 = getelementptr i8, ptr %t425, i64 %t398
  %t427 = call i64 @__olang_fmt_i64(ptr %t426, i64 %t400)
  %t428 = getelementptr i8, ptr %t426, i64 %t401
  call void @olang_textcopy(ptr %t428, ptr %t403, i64 %t404)
  %t429 = getelementptr i8, ptr %t428, i64 %t404
  %t430 = call i64 @__olang_fmt_i64(ptr %t429, i64 %t406)
  %t431 = getelementptr i8, ptr %t429, i64 %t407
  call void @olang_textcopy(ptr %t431, ptr %t409, i64 %t410)
  %t432 = getelementptr i8, ptr %t431, i64 %t410
  call void @olang_textcopy(ptr %t432, ptr %t413, i64 %t414)
  %t433 = getelementptr i8, ptr %t432, i64 %t414
  call void @olang_textcopy(ptr %t433, ptr %t416, i64 %t417)
  %t434 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t419, 1
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } %t435, 1
  %t439 = mul i64 %t437, 1
  %t440 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t440, ptr %t438, i64 %t439, i1 false)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  %t443 = load ptr, ptr %l159, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s15, ptr %t443, { i64, ptr } %t442)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s15)
  br label %bb65
bb65:
  %t445 = load i64, ptr %l19, !tbaa !24
  %t447 = add i64 %t445, 1
  store i64 %t447, ptr %l19, !tbaa !24
  br label %bb57
bb66:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/free:Free", ptr %t449, i32 0, i32 43
  store ptr %t451, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s19
  %t453 = load i64, ptr %l22, !tbaa !24
  store i64 %t453, ptr %l178, !tbaa !24
  %t454 = load ptr, ptr %l21, !tbaa !29
  %t456 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t454)
  store i64 %t456, ptr %l180
  br label %bb68
bb68:
  %t457 = load i64, ptr %l178, !tbaa !24
  %t458 = load i64, ptr %l180, !tbaa !24
  %t459 = icmp slt i64 %t457, %t458
  %t461 = xor i1 %t459, true
  br i1 %t461, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s19)
  br label %bb77
bb70:
  br label %bb71
bb71:
  %t463 = load ptr, ptr %l21, !tbaa !29
  %t464 = load i64, ptr %l22, !tbaa !24
  %t467 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t463, i64 %t464)
  store %"compiler/free:letGo" %t467, ptr %l185
  br label %bb72
bb72:
  %t468 = load %"compiler/free:letGo", ptr %l185
  store %"compiler/free:letGo" %t468, ptr %l23
  store ptr %l1, ptr %l186, !tbaa !29
  %t469 = getelementptr %"compiler/free:letGo", ptr %l23, i32 0, i32 0
  %t470 = load i64, ptr %t469, !tbaa !24
  store i64 %t470, ptr %l187, !tbaa !24
  %t471 = getelementptr %"compiler/free:letGo", ptr %l23, i32 0, i32 1
  %t472 = load i64, ptr %t471, !tbaa !24
  store i64 %t472, ptr %l188, !tbaa !24
  %t473 = getelementptr %"compiler/free:letGo", ptr %l23, i32 0, i32 5
  %t474 = load i64, ptr %t473, !tbaa !24
  store i64 %t474, ptr %l189, !tbaa !24
  %t475 = load ptr, ptr %l0, !tbaa !29
  %t477 = getelementptr %"compiler/free:Free", ptr %t475, i32 0, i32 0
  %t478 = load ptr, ptr %t477, !tbaa !29
  %t480 = getelementptr %"compiler/generic:Program", ptr %t478, i32 0, i32 0
  %t481 = load ptr, ptr %t480, !tbaa !29
  %t483 = getelementptr %"compiler/load:Loader", ptr %t481, i32 0, i32 4
  %t484 = load ptr, ptr %t483, !tbaa !29
  %t485 = getelementptr %"compiler/free:letGo", ptr %l23, i32 0, i32 2
  %t486 = load i64, ptr %t485, !tbaa !24
  %t487 = getelementptr %"compiler/free:letGo", ptr %l23, i32 0, i32 4
  %t488 = getelementptr %"compiler/source:Span", ptr %t487, i32 0, i32 0
  %t489 = load i32, ptr %t488, !tbaa !23
  %t491 = sext i32 %t489 to i64
  %t495 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s19, ptr %t484, i64 %t486, i64 %t491)
  store { i64, ptr } %t495, ptr %l197
  br label %bb73
bb73:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t497 = load %"compiler/free:letGo", ptr %l23
  %t500 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %s19, ptr %t496, %"compiler/free:letGo" %t497)
  store { i64, ptr } %t500, ptr %l200
  br label %bb74
bb74:
  %t501 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t502 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t503 = load i64, ptr %l187, !tbaa !24
  %t504 = call i64 @__olang_fmt_i64(ptr null, i64 %t503)
  %t505 = add i64 %t502, %t504
  %t506 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t507 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t508 = add i64 %t505, %t507
  %t509 = load i64, ptr %l188, !tbaa !24
  %t510 = call i64 @__olang_fmt_i64(ptr null, i64 %t509)
  %t511 = add i64 %t508, %t510
  %t512 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t513 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t514 = add i64 %t511, %t513
  %t515 = load i64, ptr %l189, !tbaa !24
  %t516 = call i64 @__olang_fmt_i64(ptr null, i64 %t515)
  %t517 = add i64 %t514, %t516
  %t518 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t519 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t520 = add i64 %t517, %t519
  %t521 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t521, 1
  %t523 = extractvalue { i64, ptr } %t521, 0
  %t524 = add i64 %t520, %t523
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t527 = add i64 %t524, %t526
  %t528 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t529 = extractvalue { i64, ptr } %t528, 1
  %t530 = extractvalue { i64, ptr } %t528, 0
  %t531 = add i64 %t527, %t530
  %t532 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t533 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t534 = add i64 %t531, %t533
  %t535 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t534)
  call void @olang_textcopy(ptr %t535, ptr %t501, i64 %t502)
  %t536 = getelementptr i8, ptr %t535, i64 %t502
  %t537 = call i64 @__olang_fmt_i64(ptr %t536, i64 %t503)
  %t538 = getelementptr i8, ptr %t536, i64 %t504
  call void @olang_textcopy(ptr %t538, ptr %t506, i64 %t507)
  %t539 = getelementptr i8, ptr %t538, i64 %t507
  %t540 = call i64 @__olang_fmt_i64(ptr %t539, i64 %t509)
  %t541 = getelementptr i8, ptr %t539, i64 %t510
  call void @olang_textcopy(ptr %t541, ptr %t512, i64 %t513)
  %t542 = getelementptr i8, ptr %t541, i64 %t513
  %t543 = call i64 @__olang_fmt_i64(ptr %t542, i64 %t515)
  %t544 = getelementptr i8, ptr %t542, i64 %t516
  call void @olang_textcopy(ptr %t544, ptr %t518, i64 %t519)
  %t545 = getelementptr i8, ptr %t544, i64 %t519
  call void @olang_textcopy(ptr %t545, ptr %t522, i64 %t523)
  %t546 = getelementptr i8, ptr %t545, i64 %t523
  call void @olang_textcopy(ptr %t546, ptr %t525, i64 %t526)
  %t547 = getelementptr i8, ptr %t546, i64 %t526
  call void @olang_textcopy(ptr %t547, ptr %t529, i64 %t530)
  %t548 = getelementptr i8, ptr %t547, i64 %t530
  call void @olang_textcopy(ptr %t548, ptr %t532, i64 %t533)
  %t549 = insertvalue { i64, ptr } undef, i64 %t534, 0
  %t550 = insertvalue { i64, ptr } %t549, ptr %t535, 1
  %t552 = extractvalue { i64, ptr } %t550, 0
  %t553 = extractvalue { i64, ptr } %t550, 1
  %t554 = mul i64 %t552, 1
  %t555 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t554)
  call void @llvm.memcpy.p0.p0.i64(ptr %t555, ptr %t553, i64 %t554, i1 false)
  %t556 = insertvalue { i64, ptr } undef, i64 %t552, 0
  %t557 = insertvalue { i64, ptr } %t556, ptr %t555, 1
  %t558 = load ptr, ptr %l186, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s19, ptr %t558, { i64, ptr } %t557)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s19)
  br label %bb76
bb76:
  %t560 = load i64, ptr %l22, !tbaa !24
  %t562 = add i64 %t560, 1
  store i64 %t562, ptr %l22, !tbaa !24
  br label %bb67
bb77:
  store i64 0, ptr %l24, !tbaa !24
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t566 = getelementptr %"compiler/free:Free", ptr %t564, i32 0, i32 1
  %t568 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t566)
  store i64 %t568, ptr %l207
  br label %bb78
bb78:
  %t569 = load i64, ptr %l207, !tbaa !24
  store i64 %t569, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t570 = load i64, ptr %l25, !tbaa !24
  %t571 = load i64, ptr %l24, !tbaa !24
  %t574 = icmp sgt i64 %t570, %t571
  br i1 %t574, label %bb79, label %bb80
bb79:
  %t576 = load i64, ptr %l26, !tbaa !24
  %t578 = icmp sgt i64 %t576, 0
  br i1 %t578, label %bb81, label %bb82
bb80:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb84
bb81:
  %t580 = load i64, ptr %l25, !tbaa !24
  %t581 = load i64, ptr %l24, !tbaa !24
  %t584 = sub i64 %t580, %t581
  %t585 = load i64, ptr %l26, !tbaa !24
  %t588 = add i64 %t584, %t585
  %t590 = sub i64 %t588, 1
  %t591 = load i64, ptr %l26, !tbaa !24
  %t594 = sdiv i64 %t590, %t591
  store i64 %t594, ptr %l214, !tbaa !24
  br label %bb83
bb82:
  store i64 0, ptr %l214, !tbaa !24
  br label %bb83
bb83:
  %t596 = load i64, ptr %l214, !tbaa !24
  store i64 %t596, ptr %l211, !tbaa !24
  br label %bb84
bb84:
  %t597 = load i64, ptr %l211, !tbaa !24
  store i64 %t597, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s23
  %t598 = load i64, ptr %l28, !tbaa !24
  %t599 = load i64, ptr %l27, !tbaa !24
  %t602 = icmp slt i64 %t598, %t599
  %t604 = xor i1 %t602, true
  br i1 %t604, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s23)
  br label %bb122
bb87:
  br label %bb88
bb88:
  %t606 = load i64, ptr %l24, !tbaa !24
  %t607 = load i64, ptr %l28, !tbaa !24
  %t608 = load i64, ptr %l26, !tbaa !24
  %t611 = mul i64 %t607, %t608
  %t614 = add i64 %t606, %t611
  store i64 %t614, ptr %l29, !tbaa !24
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/free:Free", ptr %t616, i32 0, i32 25
  %t619 = load i64, ptr %l29, !tbaa !24
  %t622 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t618, i64 %t619)
  store ptr %t622, ptr %l235
  br label %bb89
bb89:
  %t623 = load ptr, ptr %l235, !tbaa !29
  %t624 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t623)
  store i64 %t624, ptr %l236
  br label %bb90
bb90:
  %t625 = load i64, ptr %l236, !tbaa !24
  %t626 = icmp eq i64 %t625, 0
  br i1 %t626, label %bb91, label %bb92
bb91:
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t630 = getelementptr %"compiler/free:Free", ptr %t628, i32 0, i32 26
  %t631 = load i64, ptr %l29, !tbaa !24
  %t634 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t630, i64 %t631)
  store ptr %t634, ptr %l242
  br label %bb93
bb92:
  store i1 false, ptr %l238, !tbaa !21
  br label %bb95
bb93:
  %t635 = load ptr, ptr %l242, !tbaa !29
  %t636 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t635)
  store i64 %t636, ptr %l243
  br label %bb94
bb94:
  %t637 = load i64, ptr %l243, !tbaa !24
  %t638 = icmp eq i64 %t637, 0
  store i1 %t638, ptr %l238, !tbaa !21
  br label %bb95
bb95:
  %t640 = load i1, ptr %l238, !tbaa !21
  br i1 %t640, label %bb96, label %bb97
bb96:
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = getelementptr %"compiler/free:Free", ptr %t641, i32 0, i32 28
  %t644 = load i64, ptr %l29, !tbaa !24
  %t647 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t643, i64 %t644)
  store ptr %t647, ptr %l249
  br label %bb98
bb97:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb100
bb98:
  %t648 = load ptr, ptr %l249, !tbaa !29
  %t649 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t648)
  store i64 %t649, ptr %l250
  br label %bb99
bb99:
  %t650 = load i64, ptr %l250, !tbaa !24
  %t651 = icmp eq i64 %t650, 0
  store i1 %t651, ptr %l245, !tbaa !21
  br label %bb100
bb100:
  %t653 = load i1, ptr %l245, !tbaa !21
  br i1 %t653, label %bb101, label %bb102
bb101:
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/free:Free", ptr %t654, i32 0, i32 29
  %t657 = load i64, ptr %l29, !tbaa !24
  %t660 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t656, i64 %t657)
  store ptr %t660, ptr %l256
  br label %bb103
bb102:
  store i1 false, ptr %l252, !tbaa !21
  br label %bb105
bb103:
  %t661 = load ptr, ptr %l256, !tbaa !29
  %t662 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t661)
  store i64 %t662, ptr %l257
  br label %bb104
bb104:
  %t663 = load i64, ptr %l257, !tbaa !24
  %t664 = icmp eq i64 %t663, 0
  store i1 %t664, ptr %l252, !tbaa !21
  br label %bb105
bb105:
  %t666 = load i1, ptr %l252, !tbaa !21
  br i1 %t666, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s23)
  br label %bb121
bb107:
  br label %bb108
bb108:
  store ptr %l1, ptr %l259, !tbaa !29
  %t667 = load i64, ptr %l29, !tbaa !24
  store i64 %t667, ptr %l260, !tbaa !24
  %t668 = load ptr, ptr %l0, !tbaa !29
  %t669 = load i64, ptr %l29, !tbaa !24
  %t672 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s23, ptr %t668, i64 %t669)
  store { i64, ptr } %t672, ptr %l263
  br label %bb109
bb109:
  %t673 = load ptr, ptr %l0, !tbaa !29
  %t675 = getelementptr %"compiler/free:Free", ptr %t673, i32 0, i32 25
  %t676 = load i64, ptr %l29, !tbaa !24
  %t679 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t675, i64 %t676)
  store ptr %t679, ptr %l267
  br label %bb110
bb110:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/free:Free", ptr %t680, i32 0, i32 26
  %t683 = load i64, ptr %l29, !tbaa !24
  %t686 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t682, i64 %t683)
  store ptr %t686, ptr %l271
  br label %bb111
bb111:
  %t687 = load ptr, ptr %l0, !tbaa !29
  %t689 = getelementptr %"compiler/free:Free", ptr %t687, i32 0, i32 28
  %t690 = load i64, ptr %l29, !tbaa !24
  %t693 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t689, i64 %t690)
  store ptr %t693, ptr %l275
  br label %bb112
bb112:
  %t694 = load ptr, ptr %l0, !tbaa !29
  %t696 = getelementptr %"compiler/free:Free", ptr %t694, i32 0, i32 29
  %t697 = load i64, ptr %l29, !tbaa !24
  %t700 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t696, i64 %t697)
  store ptr %t700, ptr %l279
  br label %bb113
bb113:
  %t701 = load ptr, ptr %l0, !tbaa !29
  %t703 = getelementptr %"compiler/free:Free", ptr %t701, i32 0, i32 24
  %t704 = load i64, ptr %l29, !tbaa !24
  %t707 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t703, i64 %t704)
  store ptr %t707, ptr %l283
  br label %bb114
bb114:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s25
  store ptr %s25room, ptr %s25
  %t708 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t709 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t708, i64 %t709)
  %t710 = load i64, ptr %l260, !tbaa !24
  %t711 = call ptr @__olang_sb_room(ptr %s25, i64 24)
  %t712 = call i64 @__olang_fmt_i64(ptr %t711, i64 %t710)
  call void @__olang_sb_add(ptr %s25, i64 %t712)
  %t713 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t714 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t713, i64 %t714)
  %t715 = load { i64, ptr }, ptr %l263, !tbaa !27
  %t716 = extractvalue { i64, ptr } %t715, 1
  %t717 = extractvalue { i64, ptr } %t715, 0
  call void @__olang_sb_put(ptr %s25, ptr %t716, i64 %t717)
  %t718 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t719 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t718, i64 %t719)
  call void @olang_2emir_2eHelperKind_2eRender_2emut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26(ptr %s25, ptr %l267, i64 0)
  br label %bb115
bb115:
  %t721 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t722 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t721, i64 %t722)
  call void @olang_2emir_2eHelperKind_2eRender_2emut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26(ptr %s25, ptr %l271, i64 0)
  br label %bb116
bb116:
  %t724 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t725 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t724, i64 %t725)
  call void @olang_2emir_2eHelperKind_2eRender_2emut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26(ptr %s25, ptr %l275, i64 0)
  br label %bb117
bb117:
  %t727 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t728 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t727, i64 %t728)
  call void @olang_2emir_2eHelperKind_2eRender_2emut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26(ptr %s25, ptr %l279, i64 0)
  br label %bb118
bb118:
  %t730 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t731 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t730, i64 %t731)
  call void @olang_2emir_2eHelperKind_2eRender_2emut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26(ptr %s25, ptr %l283, i64 0)
  br label %bb119
bb119:
  %t733 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t734 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t733, i64 %t734)
  %t735 = load ptr, ptr %s25
  %t736 = getelementptr %olang.builder, ptr %s25, i32 0, i32 1
  %t737 = load i64, ptr %t736
  %t738 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t737)
  call void @olang_textcopy(ptr %t738, ptr %t735, i64 %t737)
  %t739 = insertvalue { i64, ptr } undef, i64 %t737, 0
  %t740 = insertvalue { i64, ptr } %t739, ptr %t738, 1
  store { i64, ptr } %t740, ptr %l289, !tbaa !27
  %t741 = getelementptr %olang.builder, ptr %s25, i32 0, i32 3
  %t742 = load ptr, ptr %t741
  %t743 = icmp ne ptr %t742, null
  br i1 %t743, label %sbgrew.744, label %sbdone.745
sbgrew.744:
  call void @__olang_sb_done(ptr %s25)
  br label %sbdone.745
sbdone.745:
  %t746 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t747 = extractvalue { i64, ptr } %t746, 0
  %t748 = extractvalue { i64, ptr } %t746, 1
  %t749 = mul i64 %t747, 1
  %t750 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t749)
  call void @llvm.memcpy.p0.p0.i64(ptr %t750, ptr %t748, i64 %t749, i1 false)
  %t751 = insertvalue { i64, ptr } undef, i64 %t747, 0
  %t752 = insertvalue { i64, ptr } %t751, ptr %t750, 1
  %t753 = load ptr, ptr %l259, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s23, ptr %t753, { i64, ptr } %t752)
  br label %bb120
bb120:
  call void @__olang_scope_close(ptr %s23)
  br label %bb121
bb121:
  %t755 = load i64, ptr %l28, !tbaa !24
  %t757 = add i64 %t755, 1
  store i64 %t757, ptr %l28, !tbaa !24
  br label %bb85
bb122:
  %t759 = load ptr, ptr %l0, !tbaa !29
  %t761 = getelementptr %"compiler/free:Free", ptr %t759, i32 0, i32 37
  %t762 = load i1, ptr %t761, !tbaa !21
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = getelementptr %"compiler/free:Free", ptr %t763, i32 0, i32 40
  %t766 = load i1, ptr %t765, !tbaa !21
  %t767 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t768 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t770 = select i1 %t762, ptr @.c6, ptr @.c7
  %t771 = select i1 %t762, i64 4, i64 5
  %t772 = add i64 %t768, %t771
  %t773 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t774 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t775 = add i64 %t772, %t774
  %t777 = select i1 %t766, ptr @.c6, ptr @.c7
  %t778 = select i1 %t766, i64 4, i64 5
  %t779 = add i64 %t775, %t778
  %t780 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t781 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t782 = add i64 %t779, %t781
  %t783 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t782)
  call void @olang_textcopy(ptr %t783, ptr %t767, i64 %t768)
  %t784 = getelementptr i8, ptr %t783, i64 %t768
  call void @olang_textcopy(ptr %t784, ptr %t770, i64 %t771)
  %t785 = getelementptr i8, ptr %t784, i64 %t771
  call void @olang_textcopy(ptr %t785, ptr %t773, i64 %t774)
  %t786 = getelementptr i8, ptr %t785, i64 %t774
  call void @olang_textcopy(ptr %t786, ptr %t777, i64 %t778)
  %t787 = getelementptr i8, ptr %t786, i64 %t778
  call void @olang_textcopy(ptr %t787, ptr %t780, i64 %t781)
  %t788 = insertvalue { i64, ptr } undef, i64 %t782, 0
  %t789 = insertvalue { i64, ptr } %t788, ptr %t783, 1
  %t791 = extractvalue { i64, ptr } %t789, 0
  %t792 = extractvalue { i64, ptr } %t789, 1
  %t793 = mul i64 %t791, 1
  %t794 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t793)
  call void @llvm.memcpy.p0.p0.i64(ptr %t794, ptr %t792, i64 %t793, i1 false)
  %t795 = insertvalue { i64, ptr } undef, i64 %t791, 0
  %t796 = insertvalue { i64, ptr } %t795, ptr %t794, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l1, { i64, ptr } %t796)
  br label %bb123
bb123:
  %t800 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t800, ptr %l301
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s0)
  %t801 = load { i64, ptr }, ptr %l301, !tbaa !27
  store { i64, ptr } %t801, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFreshCtorAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l4 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 62
  store ptr %t3, ptr %l4, !tbaa !29
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %a1, i64 %a2)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i1, ptr %l8, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSoleLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:leaf"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca i64
  %l17 = alloca i64
  %l22 = alloca %"compiler/free:leaf"
  %l24 = alloca %"compiler/free:leaf"
  %l27 = alloca i1
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 65
  %t8 = load i1, ptr %t7, !tbaa !21
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp2
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t15, i32 %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l13
  br label %bb5
bb5:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t21 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  store ptr %t21, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %t24)
  store i64 %t26, ptr %l17
  br label %bb7
bb7:
  %t27 = load i64, ptr %l15, !tbaa !24
  %t28 = load i64, ptr %l17, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %s2, ptr %t33, i64 %t34)
  store %"compiler/free:leaf" %t37, ptr %l22
  br label %bb11
bb11:
  %t39 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s3, ptr %l22)
  store %"compiler/free:leaf" %t39, ptr %l24
  br label %bb12
bb12:
  %t40 = load %"compiler/free:leaf", ptr %l24
  store %"compiler/free:leaf" %t40, ptr %l5
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:leaf", ptr %l5, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %t41, i64 %t43)
  store i1 %t46, ptr %l27
  br label %bb13
bb13:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load ptr, ptr %lp2
  %t49 = load %"compiler/free:leaf", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s4, ptr %t48, %"compiler/free:leaf" %t49)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb6
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t56 = load ptr, ptr %lp2
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t5, i32 %t4)
  store i1 %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l9
  br label %bb5
bb4:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t15 = load i1, ptr %l6, !tbaa !21
  store i1 %t15, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load i32, ptr %l3, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebefore(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1, %"compiler/free:letGo" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca %"compiler/free:letGo"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  store %"compiler/free:letGo" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = icmp ne i64 %t2, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t15 = icmp slt i64 %t10, %t12
  store i1 %t15, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t17 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 3
  %t18 = getelementptr %"compiler/source:Span", ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = getelementptr %"compiler/free:letGo", ptr %l2, i32 0, i32 3
  %t21 = getelementptr %"compiler/source:Span", ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21, !tbaa !23
  %t25 = icmp slt i32 %t19, %t22
  store i1 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l7 = alloca ptr
  %l18 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 1
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l7, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  store ptr null, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Body", ptr %t17, i32 0, i32 11
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3a516a19293feeda_7f77204653e04cce)
  unreachable
bb6:
  br label %bb7
bb7:
  %t24 = load ptr, ptr %l3, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 11
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t31 = call ptr @compiler_2ffree_2efindCallBlock(ptr %v1, ptr %v1, ptr %t27, i64 %a2)
  store ptr %t31, ptr %l18
  br label %bb8
bb8:
  %t32 = load ptr, ptr %l18, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecollection(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/free:letGo" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/free:letGo"
  %lp7 = alloca ptr
  %lp8 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"compiler/free:letGo"
  %l22 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l37 = alloca i1
  %l41 = alloca { i64, ptr }
  %l43 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 43
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l13
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb29
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/free:letGo" %t19, ptr %l18
  br label %bb6
bb6:
  %t20 = load %"compiler/free:letGo", ptr %l18
  store %"compiler/free:letGo" %t20, ptr %l6
  %t21 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = icmp eq i64 %t22, %a1
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t33 = icmp eq i64 %t29, %a2
  store i1 %t33, ptr %l22, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l22, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t36 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  %t41 = icmp ne i64 %t37, %t38
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 7
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  store i1 %t47, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l30, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 22
  %t53 = getelementptr %"compiler/free:letGo", ptr %l6, i32 0, i32 7
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t54)
  store i1 %t57, ptr %l37
  br label %bb18
bb17:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  %t58 = load i1, ptr %l37, !tbaa !21
  %t59 = xor i1 %t58, true
  store i1 %t59, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/free:letGo", ptr %l6
  %t66 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %t62, %"compiler/free:letGo" %t63)
  store { i64, ptr } %t66, ptr %l41
  br label %bb22
bb21:
  br label %bb27
bb22:
  %t67 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t67, ptr %lp7
  %t68 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t69 = load ptr, ptr %lp7
  store { i64, ptr } %t68, ptr %t69, !tbaa !27
  %t70 = load ptr, ptr %lp7
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s3, { i64, ptr } %t71, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t73, ptr %l43
  br label %bb23
bb23:
  %t74 = load i1, ptr %l43, !tbaa !21
  %t75 = xor i1 %t74, true
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load ptr, ptr %lp7
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t80 = load i64, ptr %l5, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb1
bb29:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t88 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %t84, %"compiler/free:letGo" %a3)
  store { i64, ptr } %t88, ptr %l50
  br label %bb30
bb30:
  %t89 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t89, ptr %lp8
  %t90 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t91 = load ptr, ptr %lp8
  store { i64, ptr } %t90, ptr %t91, !tbaa !27
  %t92 = load ptr, ptr %lp8
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t95 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t93, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t95, ptr %l52
  br label %bb31
bb31:
  %t96 = load i1, ptr %l52, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %lp8
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  store { i64, ptr } %t100, ptr %l54, !tbaa !27
  br label %bb34
bb33:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d37, i32 0, i32 1) }, ptr %l56, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t102, ptr %l54, !tbaa !27
  br label %bb34
bb34:
  %t104 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l58, !tbaa !24
  %t106 = load i64, ptr %l58, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l59, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l58, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t117, ptr %l54, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t118 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t118, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/free:letGo"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/free:store"
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca %"compiler/free:orStore"
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca %"compiler/free:orCall"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca %"compiler/free:store"
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca %"compiler/free:store"
  %l57 = alloca i64
  %l62 = alloca i64
  %l65 = alloca i64
  %l87 = alloca i64
  %l92 = alloca i64
  %l94 = alloca i64
  %l99 = alloca %"compiler/free:letGo"
  %l103 = alloca i1
  %l106 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l115 = alloca i1
  %l119 = alloca i1
  %l128 = alloca i64
  %l131 = alloca i64
  %l151 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca %"compiler/source:Span"
  %l157 = alloca i64
  %l159 = alloca ptr
  %l160 = alloca i64
  %l161 = alloca i64
  %l162 = alloca %"compiler/source:Span"
  %l165 = alloca i1
  %l169 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i64
  %l172 = alloca i64
  %l173 = alloca %"compiler/source:Span"
  %l178 = alloca i64
  %l180 = alloca i64
  %l185 = alloca %"compiler/free:store"
  %l189 = alloca i1
  %l193 = alloca i1
  %l195 = alloca i1
  %l196 = alloca ptr
  %l200 = alloca i1
  %l210 = alloca i64
  %l212 = alloca i64
  %l217 = alloca %"compiler/free:orStore"
  %l221 = alloca i1
  %l223 = alloca i1
  %l226 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i64
  %l229 = alloca i64
  %l230 = alloca %"compiler/source:Span"
  %l235 = alloca i64
  %l237 = alloca i64
  %l242 = alloca %"compiler/free:orCall"
  %l246 = alloca i1
  %l248 = alloca i1
  %l252 = alloca ptr
  %l256 = alloca i1
  %l260 = alloca i1
  %l261 = alloca ptr
  %l262 = alloca i64
  %l263 = alloca i64
  %l264 = alloca %"compiler/source:Span"
  %l269 = alloca i64
  %l271 = alloca i64
  %l276 = alloca %"compiler/free:store"
  %l280 = alloca i1
  %l283 = alloca i1
  %l285 = alloca i1
  %l286 = alloca ptr
  %l290 = alloca i64
  %l303 = alloca i64
  %l306 = alloca i64
  %l327 = alloca i1
  %l328 = alloca ptr
  %l329 = alloca i64
  %l330 = alloca i64
  %l331 = alloca %"compiler/source:Span"
  %l338 = alloca i64
  %l341 = alloca i64
  %l360 = alloca ptr
  %l361 = alloca i64
  %l364 = alloca i1
  %l368 = alloca i64
  %l377 = alloca i64
  %l380 = alloca i64
  %l401 = alloca i1
  %l403 = alloca i1
  %l407 = alloca i1
  %l409 = alloca ptr
  %l413 = alloca i32
  %l414 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l416 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l418 = alloca i64
  %l420 = alloca i64
  %l425 = alloca i64
  %l429 = alloca i1
  %l430 = alloca i1
  %l434 = alloca i1
  %l438 = alloca ptr
  %l439 = alloca i64
  %l440 = alloca i64
  %l441 = alloca %"compiler/source:Span"
  %l448 = alloca i64
  %l450 = alloca i64
  %l455 = alloca %"compiler/free:store"
  %l459 = alloca i1
  %l463 = alloca i1
  %l464 = alloca i1
  %l468 = alloca i1
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s40 = alloca %olang.scope
  %s42 = alloca %olang.scope
  %s48 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 8
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l57
  br label %bb1
bb1:
  %t6 = load i64, ptr %l57, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l65, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l65, !tbaa !24
  store i64 %t35, ptr %l62, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l62, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 49
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t57, i1 false)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t63 = load i64, ptr %l1, !tbaa !24
  store i64 %t63, ptr %l87, !tbaa !24
  %t64 = load i64, ptr %l87, !tbaa !24
  %t65 = icmp sge i64 %t64, 0
  br i1 %t65, label %bb15, label %bb16
bb15:
  %t67 = load i64, ptr %l87, !tbaa !24
  %t68 = mul i64 %t67, 1
  %t69 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l8, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:Free", ptr %t73, i32 0, i32 43
  store ptr %t75, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_77e2c420ac7907a9_804235f2ad53d)
  unreachable
bb17:
  %t77 = load i64, ptr %l10, !tbaa !24
  store i64 %t77, ptr %l92, !tbaa !24
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l94
  br label %bb18
bb18:
  %t81 = load i64, ptr %l92, !tbaa !24
  %t82 = load i64, ptr %l94, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb19, label %bb20
bb19:
  br label %bb41
bb20:
  br label %bb21
bb21:
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t87, i64 %t88)
  store %"compiler/free:letGo" %t91, ptr %l99
  br label %bb22
bb22:
  %t92 = load %"compiler/free:letGo", ptr %l99
  store %"compiler/free:letGo" %t92, ptr %l11
  %t93 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 5
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t98 = icmp ne i64 %t94, %t95
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 0
  %t101 = load i64, ptr %t100, !tbaa !24
  %t103 = icmp sge i64 %t101, 0
  store i1 %t103, ptr %l103, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb25
bb25:
  %t105 = load i1, ptr %l103, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 21
  %t109 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 1
  %t110 = load i64, ptr %t109, !tbaa !24
  %t113 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t108, i64 %t110)
  store i1 %t113, ptr %l110
  br label %bb28
bb27:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb29
bb28:
  %t114 = load i1, ptr %l110, !tbaa !21
  store i1 %t114, ptr %l106, !tbaa !21
  br label %bb29
bb29:
  %t115 = load i1, ptr %l106, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t116 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 5
  %t117 = load i64, ptr %t116, !tbaa !24
  %t118 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  %t121 = icmp eq i64 %t117, %t118
  br i1 %t121, label %bb32, label %bb33
bb31:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb36
bb32:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:Free", ptr %t123, i32 0, i32 23
  %t126 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 1
  %t127 = load i64, ptr %t126, !tbaa !24
  %t130 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t125, i64 %t127)
  store i1 %t130, ptr %l119
  br label %bb34
bb33:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb35
bb34:
  %t131 = load i1, ptr %l119, !tbaa !21
  store i1 %t131, ptr %l115, !tbaa !21
  br label %bb35
bb35:
  %t132 = load i1, ptr %l115, !tbaa !21
  %t133 = xor i1 %t132, true
  store i1 %t133, ptr %l111, !tbaa !21
  br label %bb36
bb36:
  %t135 = load i1, ptr %l111, !tbaa !21
  br i1 %t135, label %bb37, label %bb38
bb37:
  %t136 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 0
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i1, ptr %t140, i64 %t137
  store i1 true, ptr %t141, !tbaa !31
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t142 = load i64, ptr %l10, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l10, !tbaa !24
  br label %bb17
bb41:
  store i64 0, ptr %l12, !tbaa !24
  %t146 = load i64, ptr %l1, !tbaa !24
  store i64 %t146, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t149 = load i64, ptr %l12, !tbaa !24
  %t152 = icmp sgt i64 %t148, %t149
  br i1 %t152, label %bb42, label %bb43
bb42:
  %t154 = load i64, ptr %l14, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l128, !tbaa !24
  br label %bb47
bb44:
  %t158 = load i64, ptr %l13, !tbaa !24
  %t159 = load i64, ptr %l12, !tbaa !24
  %t162 = sub i64 %t158, %t159
  %t163 = load i64, ptr %l14, !tbaa !24
  %t166 = add i64 %t162, %t163
  %t168 = sub i64 %t166, 1
  %t169 = load i64, ptr %l14, !tbaa !24
  %t172 = sdiv i64 %t168, %t169
  store i64 %t172, ptr %l131, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb46
bb46:
  %t174 = load i64, ptr %l131, !tbaa !24
  store i64 %t174, ptr %l128, !tbaa !24
  br label %bb47
bb47:
  %t175 = load i64, ptr %l128, !tbaa !24
  store i64 %t175, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb48
bb48:
  %t176 = load i64, ptr %l16, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = icmp slt i64 %t176, %t177
  %t182 = xor i1 %t180, true
  br i1 %t182, label %bb49, label %bb50
bb49:
  br label %bb73
bb50:
  br label %bb51
bb51:
  %t184 = load i64, ptr %l12, !tbaa !24
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l14, !tbaa !24
  %t189 = mul i64 %t185, %t186
  %t192 = add i64 %t184, %t189
  store i64 %t192, ptr %l17, !tbaa !24
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/free:Free", ptr %t194, i32 0, i32 37
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t199 = load ptr, ptr %l0, !tbaa !29
  store ptr %t199, ptr %l151, !tbaa !29
  %t200 = load i64, ptr %l17, !tbaa !24
  store i64 %t200, ptr %l152, !tbaa !24
  %t201 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t201, ptr %l153, !tbaa !24
  %t202 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s10, i32 0, i32 0)
  store %"compiler/source:Span" %t202, ptr %l154
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t203 = load ptr, ptr %l151, !tbaa !29
  %t204 = load i64, ptr %l152, !tbaa !24
  %t205 = load i64, ptr %l153, !tbaa !24
  %t206 = load %"compiler/source:Span", ptr %l154
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s10, ptr %t203, i64 %t204, i64 %t205, i64 -1, %"compiler/source:Span" %t206, { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s10)
  br label %bb56
bb56:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/free:Free", ptr %t207, i32 0, i32 35
  %t211 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t209)
  store i64 %t211, ptr %l157
  br label %bb57
bb57:
  %t212 = load i64, ptr %l157, !tbaa !24
  %t213 = icmp sgt i64 %t212, 0
  br i1 %t213, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l159, !tbaa !29
  %t216 = load i64, ptr %l17, !tbaa !24
  store i64 %t216, ptr %l160, !tbaa !24
  %t217 = load i64, ptr @G_2ecompiler_2ffree_2eRTask, !tbaa !24
  store i64 %t217, ptr %l161, !tbaa !24
  %t218 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 0, i32 0)
  store %"compiler/source:Span" %t218, ptr %l162
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t219 = load ptr, ptr %l159, !tbaa !29
  %t220 = load i64, ptr %l160, !tbaa !24
  %t221 = load i64, ptr %l161, !tbaa !24
  %t222 = load %"compiler/source:Span", ptr %l162
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s11, ptr %t219, i64 %t220, i64 %t221, i64 -1, %"compiler/source:Span" %t222, { i64, ptr } { i64 130, ptr getelementptr inbounds (<{ i64, [130 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/free:Free", ptr %t223, i32 0, i32 40
  %t226 = load i1, ptr %t225, !tbaa !21
  br i1 %t226, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l165, !tbaa !21
  br label %bb66
bb64:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/free:Free", ptr %t228, i32 0, i32 41
  %t231 = load i64, ptr %l17, !tbaa !24
  %t234 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t230, i64 %t231)
  store i1 %t234, ptr %l169
  br label %bb65
bb65:
  %t235 = load i1, ptr %l169, !tbaa !21
  store i1 %t235, ptr %l165, !tbaa !21
  br label %bb66
bb66:
  %t236 = load i1, ptr %l165, !tbaa !21
  br i1 %t236, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s12
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l170, !tbaa !29
  %t238 = load i64, ptr %l17, !tbaa !24
  store i64 %t238, ptr %l171, !tbaa !24
  %t239 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t239, ptr %l172, !tbaa !24
  %t240 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 0, i32 0)
  store %"compiler/source:Span" %t240, ptr %l173
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t241 = load ptr, ptr %l170, !tbaa !29
  %t242 = load i64, ptr %l171, !tbaa !24
  %t243 = load i64, ptr %l172, !tbaa !24
  %t244 = load %"compiler/source:Span", ptr %l173
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s12, ptr %t241, i64 %t242, i64 %t243, i64 -1, %"compiler/source:Span" %t244, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s12)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t245 = load i64, ptr %l16, !tbaa !24
  %t247 = add i64 %t245, 1
  store i64 %t247, ptr %l16, !tbaa !24
  br label %bb48
bb73:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = getelementptr %"compiler/free:Free", ptr %t249, i32 0, i32 42
  store ptr %t251, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb74
bb74:
  %t253 = load i64, ptr %l19, !tbaa !24
  store i64 %t253, ptr %l178, !tbaa !24
  %t254 = load ptr, ptr %l18, !tbaa !29
  %t256 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t254)
  store i64 %t256, ptr %l180
  br label %bb75
bb75:
  %t257 = load i64, ptr %l178, !tbaa !24
  %t258 = load i64, ptr %l180, !tbaa !24
  %t259 = icmp slt i64 %t257, %t258
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb76, label %bb77
bb76:
  br label %bb96
bb77:
  br label %bb78
bb78:
  %t263 = load ptr, ptr %l18, !tbaa !29
  %t264 = load i64, ptr %l19, !tbaa !24
  %t267 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t263, i64 %t264)
  store %"compiler/free:store" %t267, ptr %l185
  br label %bb79
bb79:
  %t268 = load %"compiler/free:store", ptr %l185
  store %"compiler/free:store" %t268, ptr %l20
  %t269 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 4
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t274 = icmp eq i64 %t270, %t271
  br i1 %t274, label %bb80, label %bb81
bb80:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/free:Free", ptr %t276, i32 0, i32 63
  %t279 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 0
  %t280 = load i64, ptr %t279, !tbaa !24
  %t283 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t278, i64 %t280)
  store i1 %t283, ptr %l193
  br label %bb82
bb81:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb83
bb82:
  %t284 = load i1, ptr %l193, !tbaa !21
  %t285 = xor i1 %t284, true
  store i1 %t285, ptr %l189, !tbaa !21
  br label %bb83
bb83:
  %t287 = load i1, ptr %l189, !tbaa !21
  br i1 %t287, label %bb84, label %bb85
bb84:
  %t288 = load ptr, ptr %l0, !tbaa !29
  store ptr %t288, ptr %l196, !tbaa !29
  %t289 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 7
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = icmp eq ptr %t290, null
  br i1 %t292, label %bb86, label %bb87
bb85:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb90
bb86:
  call void @__olang_check_failed(ptr @olang_loc_834ee64634399a9c_46784e5d37862958)
  unreachable
bb87:
  br label %bb88
bb88:
  %t294 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 7
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t296 = load ptr, ptr %l196, !tbaa !29
  %t298 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t296, ptr %t295)
  store i1 %t298, ptr %l200
  br label %bb89
bb89:
  %t299 = load i1, ptr %l200, !tbaa !21
  store i1 %t299, ptr %l195, !tbaa !21
  br label %bb90
bb90:
  %t300 = load i1, ptr %l195, !tbaa !21
  br i1 %t300, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s16
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 0
  %t303 = load i64, ptr %t302, !tbaa !24
  %t304 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  %t305 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 2
  %t306 = load i64, ptr %t305, !tbaa !24
  %t307 = getelementptr %"compiler/free:store", ptr %l20, i32 0, i32 3
  %t308 = load %"compiler/source:Span", ptr %t307
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s16, ptr %t301, i64 %t303, i64 %t304, i64 %t306, %"compiler/source:Span" %t308, { i64, ptr } { i64 144, ptr getelementptr inbounds (<{ i64, [144 x i8] }>, ptr @.d41, i32 0, i32 1) })
  br label %bb93
bb92:
  br label %bb94
bb93:
  call void @__olang_scope_close(ptr %s16)
  br label %bb94
bb94:
  br label %bb95
bb95:
  %t314 = load i64, ptr %l19, !tbaa !24
  %t316 = add i64 %t314, 1
  store i64 %t316, ptr %l19, !tbaa !24
  br label %bb74
bb96:
  %t318 = load ptr, ptr %l0, !tbaa !29
  %t320 = getelementptr %"compiler/free:Free", ptr %t318, i32 0, i32 48
  store ptr %t320, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb97
bb97:
  %t322 = load i64, ptr %l22, !tbaa !24
  store i64 %t322, ptr %l210, !tbaa !24
  %t323 = load ptr, ptr %l21, !tbaa !29
  %t325 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %t323)
  store i64 %t325, ptr %l212
  br label %bb98
bb98:
  %t326 = load i64, ptr %l210, !tbaa !24
  %t327 = load i64, ptr %l212, !tbaa !24
  %t328 = icmp slt i64 %t326, %t327
  %t330 = xor i1 %t328, true
  br i1 %t330, label %bb99, label %bb100
bb99:
  br label %bb114
bb100:
  br label %bb101
bb101:
  %t332 = load ptr, ptr %l21, !tbaa !29
  %t333 = load i64, ptr %l22, !tbaa !24
  %t336 = call %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t332, i64 %t333)
  store %"compiler/free:orStore" %t336, ptr %l217
  br label %bb102
bb102:
  %t337 = load %"compiler/free:orStore", ptr %l217
  store %"compiler/free:orStore" %t337, ptr %l23
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/free:Free", ptr %t338, i32 0, i32 63
  %t341 = getelementptr %"compiler/free:orStore", ptr %l23, i32 0, i32 1
  %t342 = load i64, ptr %t341, !tbaa !24
  %t345 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t340, i64 %t342)
  store i1 %t345, ptr %l221
  br label %bb103
bb103:
  %t346 = load i1, ptr %l221, !tbaa !21
  %t347 = xor i1 %t346, true
  br i1 %t347, label %bb104, label %bb105
bb104:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/free:orStore", ptr %l23, i32 0, i32 2
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t354 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t349, ptr %t351)
  store i1 %t354, ptr %l226
  br label %bb106
bb105:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb107
bb106:
  %t355 = load i1, ptr %l226, !tbaa !21
  store i1 %t355, ptr %l223, !tbaa !21
  br label %bb107
bb107:
  %t356 = load i1, ptr %l223, !tbaa !21
  br i1 %t356, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s20
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l227, !tbaa !29
  %t358 = getelementptr %"compiler/free:orStore", ptr %l23, i32 0, i32 1
  %t359 = load i64, ptr %t358, !tbaa !24
  store i64 %t359, ptr %l228, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t360, ptr %l229, !tbaa !24
  %t361 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s20, i32 0, i32 0)
  store %"compiler/source:Span" %t361, ptr %l230
  br label %bb110
bb109:
  br label %bb112
bb110:
  %t362 = load ptr, ptr %l227, !tbaa !29
  %t363 = load i64, ptr %l228, !tbaa !24
  %t364 = load i64, ptr %l229, !tbaa !24
  %t365 = load %"compiler/source:Span", ptr %l230
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s20, ptr %t362, i64 %t363, i64 %t364, i64 -1, %"compiler/source:Span" %t365, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s20)
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t366 = load i64, ptr %l22, !tbaa !24
  %t368 = add i64 %t366, 1
  store i64 %t368, ptr %l22, !tbaa !24
  br label %bb97
bb114:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/free:Free", ptr %t370, i32 0, i32 47
  store ptr %t372, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb115
bb115:
  %t374 = load i64, ptr %l25, !tbaa !24
  store i64 %t374, ptr %l235, !tbaa !24
  %t375 = load ptr, ptr %l24, !tbaa !29
  %t377 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t375)
  store i64 %t377, ptr %l237
  br label %bb116
bb116:
  %t378 = load i64, ptr %l235, !tbaa !24
  %t379 = load i64, ptr %l237, !tbaa !24
  %t380 = icmp slt i64 %t378, %t379
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb117, label %bb118
bb117:
  br label %bb136
bb118:
  br label %bb119
bb119:
  %t384 = load ptr, ptr %l24, !tbaa !29
  %t385 = load i64, ptr %l25, !tbaa !24
  %t388 = call %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t384, i64 %t385)
  store %"compiler/free:orCall" %t388, ptr %l242
  br label %bb120
bb120:
  %t389 = load %"compiler/free:orCall", ptr %l242
  store %"compiler/free:orCall" %t389, ptr %l26
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/free:Free", ptr %t390, i32 0, i32 63
  %t393 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 4
  %t394 = load i64, ptr %t393, !tbaa !24
  %t397 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t392, i64 %t394)
  store i1 %t397, ptr %l246
  br label %bb121
bb121:
  %t398 = load i1, ptr %l246, !tbaa !21
  %t399 = xor i1 %t398, true
  br i1 %t399, label %bb122, label %bb123
bb122:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/free:Free", ptr %t401, i32 0, i32 1
  %t404 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 2
  %t405 = load i64, ptr %t404, !tbaa !24
  %t408 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t403, i64 %t405)
  store ptr %t408, ptr %l252
  br label %bb124
bb123:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb129
bb124:
  %t409 = load ptr, ptr %l252, !tbaa !29
  %t411 = getelementptr %"compiler/typed:Body", ptr %t409, i32 0, i32 11
  %t412 = load ptr, ptr %t411, !tbaa !29
  %t414 = icmp eq ptr %t412, null
  br i1 %t414, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l256, !tbaa !21
  br label %bb128
bb126:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/free:Free", ptr %t416, i32 0, i32 34
  %t419 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 2
  %t420 = load i64, ptr %t419, !tbaa !24
  %t423 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t418, i64 %t420)
  store i1 %t423, ptr %l260
  br label %bb127
bb127:
  %t424 = load i1, ptr %l260, !tbaa !21
  store i1 %t424, ptr %l256, !tbaa !21
  br label %bb128
bb128:
  %t425 = load i1, ptr %l256, !tbaa !21
  store i1 %t425, ptr %l248, !tbaa !21
  br label %bb129
bb129:
  %t426 = load i1, ptr %l248, !tbaa !21
  br i1 %t426, label %bb130, label %bb131
bb130:
  store %olang.scope zeroinitializer, ptr %s24
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l261, !tbaa !29
  %t428 = getelementptr %"compiler/free:orCall", ptr %l26, i32 0, i32 4
  %t429 = load i64, ptr %t428, !tbaa !24
  store i64 %t429, ptr %l262, !tbaa !24
  %t430 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t430, ptr %l263, !tbaa !24
  %t431 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s24, i32 0, i32 0)
  store %"compiler/source:Span" %t431, ptr %l264
  br label %bb132
bb131:
  br label %bb134
bb132:
  %t432 = load ptr, ptr %l261, !tbaa !29
  %t433 = load i64, ptr %l262, !tbaa !24
  %t434 = load i64, ptr %l263, !tbaa !24
  %t435 = load %"compiler/source:Span", ptr %l264
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s24, ptr %t432, i64 %t433, i64 %t434, i64 -1, %"compiler/source:Span" %t435, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d43, i32 0, i32 1) })
  br label %bb133
bb133:
  call void @__olang_scope_close(ptr %s24)
  br label %bb134
bb134:
  br label %bb135
bb135:
  %t436 = load i64, ptr %l25, !tbaa !24
  %t438 = add i64 %t436, 1
  store i64 %t438, ptr %l25, !tbaa !24
  br label %bb115
bb136:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/free:Free", ptr %t440, i32 0, i32 42
  store ptr %t442, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb137
bb137:
  %t444 = load i64, ptr %l28, !tbaa !24
  store i64 %t444, ptr %l269, !tbaa !24
  %t445 = load ptr, ptr %l27, !tbaa !29
  %t447 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t445)
  store i64 %t447, ptr %l271
  br label %bb138
bb138:
  %t448 = load i64, ptr %l269, !tbaa !24
  %t449 = load i64, ptr %l271, !tbaa !24
  %t450 = icmp slt i64 %t448, %t449
  %t452 = xor i1 %t450, true
  br i1 %t452, label %bb139, label %bb140
bb139:
  br label %bb159
bb140:
  br label %bb141
bb141:
  %t454 = load ptr, ptr %l27, !tbaa !29
  %t455 = load i64, ptr %l28, !tbaa !24
  %t458 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t454, i64 %t455)
  store %"compiler/free:store" %t458, ptr %l276
  br label %bb142
bb142:
  %t459 = load %"compiler/free:store", ptr %l276
  store %"compiler/free:store" %t459, ptr %l29
  %t460 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 4
  %t461 = load i64, ptr %t460, !tbaa !24
  %t462 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t465 = icmp eq i64 %t461, %t462
  br i1 %t465, label %bb143, label %bb144
bb143:
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load %"compiler/free:store", ptr %l29
  %t471 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v0, ptr %t467, %"compiler/free:store" %t468)
  store i1 %t471, ptr %l283
  br label %bb145
bb144:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb153
bb145:
  %t472 = load i1, ptr %l283, !tbaa !21
  %t473 = xor i1 %t472, true
  br i1 %t473, label %bb146, label %bb147
bb146:
  store i1 true, ptr %l285, !tbaa !21
  br label %bb152
bb147:
  %t475 = load ptr, ptr %l0, !tbaa !29
  store ptr %t475, ptr %l286, !tbaa !29
  %t476 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 7
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t479 = icmp eq ptr %t477, null
  br i1 %t479, label %bb148, label %bb149
bb148:
  call void @__olang_check_failed(ptr @olang_loc_dcc3c6712d01991_ec14a6947a12b86d)
  unreachable
bb149:
  br label %bb150
bb150:
  %t481 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 7
  %t482 = load ptr, ptr %t481, !tbaa !29
  %t483 = load ptr, ptr %l286, !tbaa !29
  %t485 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t483, ptr %t482)
  store i64 %t485, ptr %l290
  br label %bb151
bb151:
  %t486 = load i64, ptr %l290, !tbaa !24
  %t487 = icmp slt i64 %t486, 0
  store i1 %t487, ptr %l285, !tbaa !21
  br label %bb152
bb152:
  %t489 = load i1, ptr %l285, !tbaa !21
  store i1 %t489, ptr %l280, !tbaa !21
  br label %bb153
bb153:
  %t490 = load i1, ptr %l280, !tbaa !21
  br i1 %t490, label %bb154, label %bb155
bb154:
  store %olang.scope zeroinitializer, ptr %s28
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 0
  %t493 = load i64, ptr %t492, !tbaa !24
  %t494 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t495 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 2
  %t496 = load i64, ptr %t495, !tbaa !24
  %t497 = getelementptr %"compiler/free:store", ptr %l29, i32 0, i32 3
  %t498 = load %"compiler/source:Span", ptr %t497
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s28, ptr %t491, i64 %t493, i64 %t494, i64 %t496, %"compiler/source:Span" %t498, { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d44, i32 0, i32 1) })
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_scope_close(ptr %s28)
  br label %bb157
bb157:
  br label %bb158
bb158:
  %t504 = load i64, ptr %l28, !tbaa !24
  %t506 = add i64 %t504, 1
  store i64 %t506, ptr %l28, !tbaa !24
  br label %bb137
bb159:
  store i64 0, ptr %l30, !tbaa !24
  %t508 = load i64, ptr %l1, !tbaa !24
  store i64 %t508, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t510 = load i64, ptr %l31, !tbaa !24
  %t511 = load i64, ptr %l30, !tbaa !24
  %t514 = icmp sgt i64 %t510, %t511
  br i1 %t514, label %bb160, label %bb161
bb160:
  %t516 = load i64, ptr %l32, !tbaa !24
  %t518 = icmp sgt i64 %t516, 0
  br i1 %t518, label %bb162, label %bb163
bb161:
  store i64 0, ptr %l303, !tbaa !24
  br label %bb165
bb162:
  %t520 = load i64, ptr %l31, !tbaa !24
  %t521 = load i64, ptr %l30, !tbaa !24
  %t524 = sub i64 %t520, %t521
  %t525 = load i64, ptr %l32, !tbaa !24
  %t528 = add i64 %t524, %t525
  %t530 = sub i64 %t528, 1
  %t531 = load i64, ptr %l32, !tbaa !24
  %t534 = sdiv i64 %t530, %t531
  store i64 %t534, ptr %l306, !tbaa !24
  br label %bb164
bb163:
  store i64 0, ptr %l306, !tbaa !24
  br label %bb164
bb164:
  %t536 = load i64, ptr %l306, !tbaa !24
  store i64 %t536, ptr %l303, !tbaa !24
  br label %bb165
bb165:
  %t537 = load i64, ptr %l303, !tbaa !24
  store i64 %t537, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb166
bb166:
  %t538 = load i64, ptr %l34, !tbaa !24
  %t539 = load i64, ptr %l33, !tbaa !24
  %t542 = icmp slt i64 %t538, %t539
  %t544 = xor i1 %t542, true
  br i1 %t544, label %bb167, label %bb168
bb167:
  br label %bb177
bb168:
  br label %bb169
bb169:
  %t546 = load i64, ptr %l30, !tbaa !24
  %t547 = load i64, ptr %l34, !tbaa !24
  %t548 = load i64, ptr %l32, !tbaa !24
  %t551 = mul i64 %t547, %t548
  %t554 = add i64 %t546, %t551
  store i64 %t554, ptr %l35, !tbaa !24
  %t556 = load ptr, ptr %l0, !tbaa !29
  %t558 = getelementptr %"compiler/free:Free", ptr %t556, i32 0, i32 63
  %t559 = load i64, ptr %l35, !tbaa !24
  %t562 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t558, i64 %t559)
  store i1 %t562, ptr %l327
  br label %bb170
bb170:
  %t563 = load i1, ptr %l327, !tbaa !21
  br i1 %t563, label %bb171, label %bb172
bb171:
  store %olang.scope zeroinitializer, ptr %s32
  %t564 = load ptr, ptr %l0, !tbaa !29
  store ptr %t564, ptr %l328, !tbaa !29
  %t565 = load i64, ptr %l35, !tbaa !24
  store i64 %t565, ptr %l329, !tbaa !24
  %t566 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t566, ptr %l330, !tbaa !24
  %t567 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s32, i32 0, i32 0)
  store %"compiler/source:Span" %t567, ptr %l331
  br label %bb173
bb172:
  br label %bb175
bb173:
  %t568 = load ptr, ptr %l328, !tbaa !29
  %t569 = load i64, ptr %l329, !tbaa !24
  %t570 = load i64, ptr %l330, !tbaa !24
  %t571 = load %"compiler/source:Span", ptr %l331
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s32, ptr %t568, i64 %t569, i64 %t570, i64 -1, %"compiler/source:Span" %t571, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d45, i32 0, i32 1) })
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s32)
  br label %bb175
bb175:
  br label %bb176
bb176:
  %t572 = load i64, ptr %l34, !tbaa !24
  %t574 = add i64 %t572, 1
  store i64 %t574, ptr %l34, !tbaa !24
  br label %bb166
bb177:
  store i64 0, ptr %l36, !tbaa !24
  %t576 = load i64, ptr %l1, !tbaa !24
  store i64 %t576, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t578 = load i64, ptr %l37, !tbaa !24
  %t579 = load i64, ptr %l36, !tbaa !24
  %t582 = icmp sgt i64 %t578, %t579
  br i1 %t582, label %bb178, label %bb179
bb178:
  %t584 = load i64, ptr %l38, !tbaa !24
  %t586 = icmp sgt i64 %t584, 0
  br i1 %t586, label %bb180, label %bb181
bb179:
  store i64 0, ptr %l338, !tbaa !24
  br label %bb183
bb180:
  %t588 = load i64, ptr %l37, !tbaa !24
  %t589 = load i64, ptr %l36, !tbaa !24
  %t592 = sub i64 %t588, %t589
  %t593 = load i64, ptr %l38, !tbaa !24
  %t596 = add i64 %t592, %t593
  %t598 = sub i64 %t596, 1
  %t599 = load i64, ptr %l38, !tbaa !24
  %t602 = sdiv i64 %t598, %t599
  store i64 %t602, ptr %l341, !tbaa !24
  br label %bb182
bb181:
  store i64 0, ptr %l341, !tbaa !24
  br label %bb182
bb182:
  %t604 = load i64, ptr %l341, !tbaa !24
  store i64 %t604, ptr %l338, !tbaa !24
  br label %bb183
bb183:
  %t605 = load i64, ptr %l338, !tbaa !24
  store i64 %t605, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb184
bb184:
  %t606 = load i64, ptr %l40, !tbaa !24
  %t607 = load i64, ptr %l39, !tbaa !24
  %t610 = icmp slt i64 %t606, %t607
  %t612 = xor i1 %t610, true
  br i1 %t612, label %bb185, label %bb186
bb185:
  br label %bb194
bb186:
  br label %bb187
bb187:
  %t614 = load i64, ptr %l36, !tbaa !24
  %t615 = load i64, ptr %l40, !tbaa !24
  %t616 = load i64, ptr %l38, !tbaa !24
  %t619 = mul i64 %t615, %t616
  %t622 = add i64 %t614, %t619
  store i64 %t622, ptr %l41, !tbaa !24
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = getelementptr %"compiler/free:Free", ptr %t624, i32 0, i32 49
  store ptr %t626, ptr %l360, !tbaa !29
  %t627 = load i64, ptr %l41, !tbaa !24
  store i64 %t627, ptr %l361, !tbaa !24
  %t628 = load i64, ptr %l41, !tbaa !24
  %t630 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t631 = load ptr, ptr %t630, !tbaa !27
  %t632 = getelementptr i1, ptr %t631, i64 %t628
  %t633 = load i1, ptr %t632, !tbaa !31
  br i1 %t633, label %bb188, label %bb189
bb188:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/free:Free", ptr %t635, i32 0, i32 44
  %t638 = load i64, ptr %l41, !tbaa !24
  %t641 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t637, i64 %t638)
  store i64 %t641, ptr %l368
  br label %bb190
bb189:
  store i1 false, ptr %l364, !tbaa !21
  br label %bb191
bb190:
  %t642 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t643 = load i64, ptr %l368, !tbaa !24
  %t645 = icmp eq i64 %t643, %t642
  store i1 %t645, ptr %l364, !tbaa !21
  br label %bb191
bb191:
  %t647 = load ptr, ptr %l360, !tbaa !29
  %t648 = load i64, ptr %l361, !tbaa !24
  %t649 = load i1, ptr %l364, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t647, i64 %t648, i1 %t649)
  br label %bb192
bb192:
  br label %bb193
bb193:
  %t650 = load i64, ptr %l40, !tbaa !24
  %t652 = add i64 %t650, 1
  store i64 %t652, ptr %l40, !tbaa !24
  br label %bb184
bb194:
  store i64 0, ptr %l42, !tbaa !24
  %t654 = load i64, ptr %l1, !tbaa !24
  store i64 %t654, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t656 = load i64, ptr %l43, !tbaa !24
  %t657 = load i64, ptr %l42, !tbaa !24
  %t660 = icmp sgt i64 %t656, %t657
  br i1 %t660, label %bb195, label %bb196
bb195:
  %t662 = load i64, ptr %l44, !tbaa !24
  %t664 = icmp sgt i64 %t662, 0
  br i1 %t664, label %bb197, label %bb198
bb196:
  store i64 0, ptr %l377, !tbaa !24
  br label %bb200
bb197:
  %t666 = load i64, ptr %l43, !tbaa !24
  %t667 = load i64, ptr %l42, !tbaa !24
  %t670 = sub i64 %t666, %t667
  %t671 = load i64, ptr %l44, !tbaa !24
  %t674 = add i64 %t670, %t671
  %t676 = sub i64 %t674, 1
  %t677 = load i64, ptr %l44, !tbaa !24
  %t680 = sdiv i64 %t676, %t677
  store i64 %t680, ptr %l380, !tbaa !24
  br label %bb199
bb198:
  store i64 0, ptr %l380, !tbaa !24
  br label %bb199
bb199:
  %t682 = load i64, ptr %l380, !tbaa !24
  store i64 %t682, ptr %l377, !tbaa !24
  br label %bb200
bb200:
  %t683 = load i64, ptr %l377, !tbaa !24
  store i64 %t683, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb201
bb201:
  %t684 = load i64, ptr %l46, !tbaa !24
  %t685 = load i64, ptr %l45, !tbaa !24
  %t688 = icmp slt i64 %t684, %t685
  %t690 = xor i1 %t688, true
  br i1 %t690, label %bb202, label %bb203
bb202:
  br label %bb236
bb203:
  br label %bb204
bb204:
  %t692 = load i64, ptr %l42, !tbaa !24
  %t693 = load i64, ptr %l46, !tbaa !24
  %t694 = load i64, ptr %l44, !tbaa !24
  %t697 = mul i64 %t693, %t694
  %t700 = add i64 %t692, %t697
  store i64 %t700, ptr %l47, !tbaa !24
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t704 = getelementptr %"compiler/free:Free", ptr %t702, i32 0, i32 49
  %t705 = load i64, ptr %l47, !tbaa !24
  %t708 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t704, i64 %t705)
  store i1 %t708, ptr %l401
  br label %bb205
bb205:
  %t709 = load i1, ptr %l401, !tbaa !21
  %t710 = xor i1 %t709, true
  br i1 %t710, label %bb206, label %bb207
bb206:
  store i1 true, ptr %l403, !tbaa !21
  br label %bb209
bb207:
  %t712 = load ptr, ptr %l0, !tbaa !29
  %t714 = getelementptr %"compiler/free:Free", ptr %t712, i32 0, i32 11
  %t715 = load i64, ptr %l47, !tbaa !24
  %t718 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t714, i64 %t715)
  store i1 %t718, ptr %l407
  br label %bb208
bb208:
  %t719 = load i1, ptr %l407, !tbaa !21
  %t720 = xor i1 %t719, true
  store i1 %t720, ptr %l403, !tbaa !21
  br label %bb209
bb209:
  %t722 = load i1, ptr %l403, !tbaa !21
  br i1 %t722, label %bb210, label %bb211
bb210:
  br label %bb235
bb211:
  br label %bb212
bb212:
  store %olang.scope zeroinitializer, ptr %s40
  %t723 = load ptr, ptr %l0, !tbaa !29
  store ptr %t723, ptr %l409, !tbaa !29
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = getelementptr %"compiler/free:Free", ptr %t724, i32 0, i32 14
  %t727 = load i64, ptr %l47, !tbaa !24
  %t730 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t726, i64 %t727)
  store i32 %t730, ptr %l413
  br label %bb213
bb213:
  %t731 = load ptr, ptr %l409, !tbaa !29
  %t732 = load i32, ptr %l413, !tbaa !23
  %t733 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s40, ptr %t731, i32 %t732)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t733, ptr %l414
  br label %bb214
bb214:
  %t735 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s40, ptr %l414)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t735, ptr %l416
  br label %bb215
bb215:
  %t736 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l416
  %t737 = call ptr @__olang_scope_alloc_a(ptr %s40, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t736, ptr %t737
  store ptr %t737, ptr %l48, !tbaa !29
  store i64 0, ptr %l49, !tbaa !24
  br label %bb216
bb216:
  %t739 = load i64, ptr %l49, !tbaa !24
  store i64 %t739, ptr %l418, !tbaa !24
  %t740 = load ptr, ptr %l48, !tbaa !29
  %t742 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s40, ptr %t740)
  store i64 %t742, ptr %l420
  br label %bb217
bb217:
  %t743 = load i64, ptr %l418, !tbaa !24
  %t744 = load i64, ptr %l420, !tbaa !24
  %t745 = icmp slt i64 %t743, %t744
  %t747 = xor i1 %t745, true
  br i1 %t747, label %bb218, label %bb219
bb218:
  br label %bb234
bb219:
  br label %bb220
bb220:
  %t749 = load ptr, ptr %l48, !tbaa !29
  %t750 = load i64, ptr %l49, !tbaa !24
  %t753 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s40, ptr %t749, i64 %t750)
  store i64 %t753, ptr %l425
  br label %bb221
bb221:
  %t754 = load i64, ptr %l425, !tbaa !24
  store i64 %t754, ptr %l50, !tbaa !24
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t757 = getelementptr %"compiler/free:Free", ptr %t755, i32 0, i32 12
  %t758 = load i64, ptr %l50, !tbaa !24
  %t761 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t757, i64 %t758)
  store i1 %t761, ptr %l429
  br label %bb222
bb222:
  %t762 = load i1, ptr %l429, !tbaa !21
  br i1 %t762, label %bb223, label %bb224
bb223:
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = getelementptr %"compiler/free:Free", ptr %t763, i32 0, i32 49
  %t766 = load i64, ptr %l50, !tbaa !24
  %t769 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t765, i64 %t766)
  store i1 %t769, ptr %l434
  br label %bb225
bb224:
  store i1 false, ptr %l430, !tbaa !21
  br label %bb226
bb225:
  %t770 = load i1, ptr %l434, !tbaa !21
  store i1 %t770, ptr %l430, !tbaa !21
  br label %bb226
bb226:
  %t771 = load i1, ptr %l430, !tbaa !21
  br i1 %t771, label %bb227, label %bb228
bb227:
  store %olang.scope zeroinitializer, ptr %s42
  %t772 = load ptr, ptr %l0, !tbaa !29
  %t774 = getelementptr %"compiler/free:Free", ptr %t772, i32 0, i32 49
  %t775 = load i64, ptr %l50, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t774, i64 %t775, i1 false)
  br label %bb229
bb228:
  br label %bb232
bb229:
  %t778 = load ptr, ptr %l0, !tbaa !29
  store ptr %t778, ptr %l438, !tbaa !29
  %t779 = load i64, ptr %l50, !tbaa !24
  store i64 %t779, ptr %l439, !tbaa !24
  %t780 = load i64, ptr @G_2ecompiler_2ffree_2eRCopied, !tbaa !24
  store i64 %t780, ptr %l440, !tbaa !24
  %t781 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s42, i32 0, i32 0)
  store %"compiler/source:Span" %t781, ptr %l441
  br label %bb230
bb230:
  %t782 = load ptr, ptr %l438, !tbaa !29
  %t783 = load i64, ptr %l439, !tbaa !24
  %t784 = load i64, ptr %l440, !tbaa !24
  %t785 = load %"compiler/source:Span", ptr %l441
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s42, ptr %t782, i64 %t783, i64 %t784, i64 -1, %"compiler/source:Span" %t785, { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb231
bb231:
  call void @__olang_scope_close(ptr %s42)
  br label %bb232
bb232:
  br label %bb233
bb233:
  %t786 = load i64, ptr %l49, !tbaa !24
  %t788 = add i64 %t786, 1
  store i64 %t788, ptr %l49, !tbaa !24
  br label %bb216
bb234:
  call void @__olang_scope_close(ptr %s40)
  br label %bb235
bb235:
  %t790 = load i64, ptr %l46, !tbaa !24
  %t792 = add i64 %t790, 1
  store i64 %t792, ptr %l46, !tbaa !24
  br label %bb201
bb236:
  br label %bb237
bb237:
  store i1 false, ptr %l51, !tbaa !21
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/free:Free", ptr %t794, i32 0, i32 42
  store ptr %t796, ptr %l52, !tbaa !29
  store i64 0, ptr %l53, !tbaa !24
  br label %bb238
bb238:
  %t798 = load i64, ptr %l53, !tbaa !24
  store i64 %t798, ptr %l448, !tbaa !24
  %t799 = load ptr, ptr %l52, !tbaa !29
  %t801 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t799)
  store i64 %t801, ptr %l450
  br label %bb239
bb239:
  %t802 = load i64, ptr %l448, !tbaa !24
  %t803 = load i64, ptr %l450, !tbaa !24
  %t804 = icmp slt i64 %t802, %t803
  %t806 = xor i1 %t804, true
  br i1 %t806, label %bb240, label %bb241
bb240:
  br label %bb258
bb241:
  br label %bb242
bb242:
  %t808 = load ptr, ptr %l52, !tbaa !29
  %t809 = load i64, ptr %l53, !tbaa !24
  %t812 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t808, i64 %t809)
  store %"compiler/free:store" %t812, ptr %l455
  br label %bb243
bb243:
  %t813 = load %"compiler/free:store", ptr %l455
  store %"compiler/free:store" %t813, ptr %l54
  %t814 = getelementptr %"compiler/free:store", ptr %l54, i32 0, i32 4
  %t815 = load i64, ptr %t814, !tbaa !24
  %t816 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t819 = icmp eq i64 %t815, %t816
  br i1 %t819, label %bb244, label %bb245
bb244:
  %t821 = load ptr, ptr %l0, !tbaa !29
  %t823 = getelementptr %"compiler/free:Free", ptr %t821, i32 0, i32 49
  %t824 = getelementptr %"compiler/free:store", ptr %l54, i32 0, i32 0
  %t825 = load i64, ptr %t824, !tbaa !24
  %t828 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t823, i64 %t825)
  store i1 %t828, ptr %l463
  br label %bb246
bb245:
  store i1 false, ptr %l459, !tbaa !21
  br label %bb247
bb246:
  %t829 = load i1, ptr %l463, !tbaa !21
  store i1 %t829, ptr %l459, !tbaa !21
  br label %bb247
bb247:
  %t830 = load i1, ptr %l459, !tbaa !21
  br i1 %t830, label %bb248, label %bb249
bb248:
  %t831 = load ptr, ptr %l0, !tbaa !29
  %t833 = getelementptr %"compiler/free:Free", ptr %t831, i32 0, i32 49
  %t834 = getelementptr %"compiler/free:store", ptr %l54, i32 0, i32 5
  %t835 = load i64, ptr %t834, !tbaa !24
  %t838 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t833, i64 %t835)
  store i1 %t838, ptr %l468
  br label %bb250
bb249:
  store i1 false, ptr %l464, !tbaa !21
  br label %bb251
bb250:
  %t839 = load i1, ptr %l468, !tbaa !21
  %t840 = xor i1 %t839, true
  store i1 %t840, ptr %l464, !tbaa !21
  br label %bb251
bb251:
  %t842 = load i1, ptr %l464, !tbaa !21
  br i1 %t842, label %bb252, label %bb253
bb252:
  store %olang.scope zeroinitializer, ptr %s48
  %t843 = load ptr, ptr %l0, !tbaa !29
  %t845 = getelementptr %"compiler/free:Free", ptr %t843, i32 0, i32 49
  %t846 = getelementptr %"compiler/free:store", ptr %l54, i32 0, i32 0
  %t847 = load i64, ptr %t846, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t845, i64 %t847, i1 false)
  br label %bb254
bb253:
  br label %bb256
bb254:
  %t850 = load ptr, ptr %l0, !tbaa !29
  %t851 = getelementptr %"compiler/free:store", ptr %l54, i32 0, i32 0
  %t852 = load i64, ptr %t851, !tbaa !24
  %t853 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t854 = getelementptr %"compiler/free:store", ptr %l54, i32 0, i32 2
  %t855 = load i64, ptr %t854, !tbaa !24
  %t856 = getelementptr %"compiler/free:store", ptr %l54, i32 0, i32 3
  %t857 = load %"compiler/source:Span", ptr %t856
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s48, ptr %t850, i64 %t852, i64 %t853, i64 %t855, %"compiler/source:Span" %t857, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb255
bb255:
  store i1 true, ptr %l51, !tbaa !21
  call void @__olang_scope_close(ptr %s48)
  br label %bb256
bb256:
  br label %bb257
bb257:
  %t863 = load i64, ptr %l53, !tbaa !24
  %t865 = add i64 %t863, 1
  store i64 %t865, ptr %l53, !tbaa !24
  br label %bb238
bb258:
  %t867 = load i1, ptr %l51, !tbaa !21
  %t869 = xor i1 %t867, true
  br i1 %t869, label %bb259, label %bb260
bb259:
  br label %bb263
bb260:
  br label %bb261
bb261:
  br label %bb262
bb262:
  br label %bb237
bb263:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l5 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i1
  %l12 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l19 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i32, ptr %l8, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  store ptr %t17, ptr %l12, !tbaa !29
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t25, ptr %l16
  br label %bb7
bb7:
  %t26 = load i32, ptr %l16, !tbaa !23
  store i32 %t26, ptr %l3, !tbaa !23
  br label %bb8
bb8:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t28 = load i32, ptr %l3, !tbaa !23
  %t31 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t27, i32 %t28)
  store i1 %t31, ptr %l19
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca ptr
  %l46 = alloca i1
  %l59 = alloca { i64, ptr }
  %l66 = alloca ptr
  %l67 = alloca i1
  %l76 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i1
  %l119 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l136 = alloca ptr
  %l137 = alloca i1
  %l150 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l182 = alloca ptr
  %l203 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i1
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t2 = load ptr, ptr %l30, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 4
  store i1 %t8, ptr %l31, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l31, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t26 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t22, ptr %t23)
  store i64 %t26, ptr %l40
  br label %bb6
bb6:
  %t27 = load i64, ptr %l40, !tbaa !24
  %t28 = icmp slt i64 %t27, 0
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l2, !tbaa !23
  %t34 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t30, i32 %t31)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l44
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb131
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t36 = load ptr, ptr %l45, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l45, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 6
  store i1 %t42, ptr %l46, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l46, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb24
bb16:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Call", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t67, ptr %l59, !tbaa !27
  %t68 = load i64, ptr %l6, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr ptr, ptr %t71, i64 %t68
  %t73 = load ptr, ptr %t72, !tbaa !39
  %t75 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t75, ptr %t73)
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l6, !tbaa !24
  br label %bb17
bb23:
  br label %bb131
bb24:
  %t83 = load ptr, ptr %l1, !tbaa !29
  store ptr %t83, ptr %l66, !tbaa !29
  store i1 false, ptr %l67, !tbaa !21
  %t84 = load ptr, ptr %l66, !tbaa !29
  %t85 = icmp ne ptr %t84, null
  br i1 %t85, label %bb25, label %bb26
bb25:
  %t87 = load ptr, ptr %l66, !tbaa !29
  %t88 = load i64, ptr %t87, !range !{i64 0, i64 18}
  %t90 = icmp eq i64 %t88, 14
  store i1 %t90, ptr %l67, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l67, !tbaa !21
  br i1 %t91, label %bb27, label %bb28
bb27:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr { i64, [5 x i64] }, ptr %t92, i32 0, i32 1
  %t95 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t94, i32 0, i32 2
  %t96 = load ptr, ptr %t95
  store ptr %t96, ptr %l9, !tbaa !29
  br label %bb29
bb28:
  br label %bb50
bb29:
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Try", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = icmp eq ptr %t101, null
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb30, label %bb31
bb30:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l76, !tbaa !29
  %t108 = load ptr, ptr %l9, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Try", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = icmp eq ptr %t111, null
  br i1 %t113, label %bb32, label %bb33
bb31:
  br label %bb36
bb32:
  call void @__olang_check_failed(ptr @olang_loc_7bd178b281ab108b_bca5961225cfb287)
  unreachable
bb33:
  br label %bb34
bb34:
  %t115 = load ptr, ptr %l9, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Try", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load ptr, ptr %l76, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t119, ptr %t118)
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t121 = load ptr, ptr %l9, !tbaa !29
  %t123 = getelementptr %"compiler/typed:Try", ptr %t121, i32 0, i32 1
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  store i64 %t128, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb38, label %bb39
bb38:
  br label %bb49
bb39:
  br label %bb40
bb40:
  %t138 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t138, ptr %l90, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr ptr, ptr %t142, i64 %t139
  %t144 = load ptr, ptr %t143, !tbaa !39
  store ptr %t144, ptr %l13, !tbaa !29
  %t146 = load ptr, ptr %l13, !tbaa !29
  %t148 = getelementptr %"compiler/typed:Clause", ptr %t146, i32 0, i32 3
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t151 = icmp eq ptr %t149, null
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb41, label %bb42
bb41:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l97, !tbaa !29
  %t156 = load ptr, ptr %l13, !tbaa !29
  %t158 = getelementptr %"compiler/typed:Clause", ptr %t156, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = icmp eq ptr %t159, null
  br i1 %t161, label %bb43, label %bb44
bb42:
  br label %bb47
bb43:
  call void @__olang_check_failed(ptr @olang_loc_54a8cb88ede7d99c_f1d49282556d5568)
  unreachable
bb44:
  br label %bb45
bb45:
  %t163 = load ptr, ptr %l13, !tbaa !29
  %t165 = getelementptr %"compiler/typed:Clause", ptr %t163, i32 0, i32 3
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t167 = load ptr, ptr %l97, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t167, ptr %t166)
  br label %bb46
bb46:
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = add i64 %t169, 1
  store i64 %t171, ptr %l11, !tbaa !24
  br label %bb37
bb49:
  br label %bb131
bb50:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l105, !tbaa !29
  store i1 false, ptr %l106, !tbaa !21
  %t174 = load ptr, ptr %l105, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb51, label %bb52
bb51:
  %t177 = load ptr, ptr %l105, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 18}
  %t180 = icmp eq i64 %t178, 12
  store i1 %t180, ptr %l106, !tbaa !21
  br label %bb52
bb52:
  %t181 = load i1, ptr %l106, !tbaa !21
  br i1 %t181, label %bb53, label %bb54
bb53:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l14, !tbaa !29
  br label %bb55
bb54:
  br label %bb70
bb55:
  %t188 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/typed:Seq", ptr %t188, i32 0, i32 0
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t193 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t193, 0
  store i64 %t195, ptr %l17, !tbaa !24
  br label %bb56
bb56:
  %t197 = load i64, ptr %l16, !tbaa !24
  %t198 = load i64, ptr %l17, !tbaa !24
  %t201 = icmp slt i64 %t197, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t205 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t205, ptr %l119, !tbaa !27
  %t206 = load i64, ptr %l16, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr ptr, ptr %t209, i64 %t206
  %t211 = load ptr, ptr %t210, !tbaa !39
  %t213 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %t213, ptr %t211)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t217 = load i64, ptr %l16, !tbaa !24
  %t219 = add i64 %t217, 1
  store i64 %t219, ptr %l16, !tbaa !24
  br label %bb56
bb62:
  %t221 = load ptr, ptr %l14, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Seq", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb63, label %bb64
bb63:
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l130, !tbaa !29
  %t231 = load ptr, ptr %l14, !tbaa !29
  %t233 = getelementptr %"compiler/typed:Seq", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = icmp eq ptr %t234, null
  br i1 %t236, label %bb65, label %bb66
bb64:
  br label %bb69
bb65:
  call void @__olang_check_failed(ptr @olang_loc_df2621a9cc7e5891_c8dc80a57ad57a3d)
  unreachable
bb66:
  br label %bb67
bb67:
  %t238 = load ptr, ptr %l14, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Seq", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t242, ptr %t241)
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb131
bb70:
  %t244 = load ptr, ptr %l1, !tbaa !29
  store ptr %t244, ptr %l136, !tbaa !29
  store i1 false, ptr %l137, !tbaa !21
  %t245 = load ptr, ptr %l136, !tbaa !29
  %t246 = icmp ne ptr %t245, null
  br i1 %t246, label %bb71, label %bb72
bb71:
  %t248 = load ptr, ptr %l136, !tbaa !29
  %t249 = load i64, ptr %t248, !range !{i64 0, i64 18}
  %t251 = icmp eq i64 %t249, 13
  store i1 %t251, ptr %l137, !tbaa !21
  br label %bb72
bb72:
  %t252 = load i1, ptr %l137, !tbaa !21
  br i1 %t252, label %bb73, label %bb74
bb73:
  %t253 = load ptr, ptr %l1, !tbaa !29
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t253, i32 0, i32 1
  %t256 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t255, i32 0, i32 2
  %t257 = load ptr, ptr %t256
  store ptr %t257, ptr %l19, !tbaa !29
  br label %bb75
bb74:
  br label %bb119
bb75:
  %t259 = load ptr, ptr %l19, !tbaa !29
  %t261 = getelementptr %"compiler/typed:Match", ptr %t259, i32 0, i32 0
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !27
  store { i64, ptr } %t262, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t264 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t264, 0
  store i64 %t266, ptr %l22, !tbaa !24
  br label %bb76
bb76:
  %t268 = load i64, ptr %l21, !tbaa !24
  %t269 = load i64, ptr %l22, !tbaa !24
  %t272 = icmp slt i64 %t268, %t269
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb77, label %bb78
bb77:
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t276 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t276, ptr %l150, !tbaa !27
  %t277 = load i64, ptr %l21, !tbaa !24
  %t279 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr ptr, ptr %t280, i64 %t277
  %t282 = load ptr, ptr %t281, !tbaa !39
  %t284 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %t284, ptr %t282)
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t288 = load i64, ptr %l21, !tbaa !24
  %t290 = add i64 %t288, 1
  store i64 %t290, ptr %l21, !tbaa !24
  br label %bb76
bb82:
  %t292 = load ptr, ptr %l19, !tbaa !29
  %t294 = getelementptr %"compiler/typed:Match", ptr %t292, i32 0, i32 1
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !27
  store { i64, ptr } %t295, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t297 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t297, 0
  store i64 %t299, ptr %l26, !tbaa !24
  br label %bb83
bb83:
  %t301 = load i64, ptr %l25, !tbaa !24
  %t302 = load i64, ptr %l26, !tbaa !24
  %t305 = icmp slt i64 %t301, %t302
  %t307 = xor i1 %t305, true
  br i1 %t307, label %bb84, label %bb85
bb84:
  br label %bb102
bb85:
  br label %bb86
bb86:
  %t309 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t309, ptr %l165, !tbaa !27
  %t310 = load i64, ptr %l25, !tbaa !24
  %t312 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr ptr, ptr %t313, i64 %t310
  %t315 = load ptr, ptr %t314, !tbaa !39
  store ptr %t315, ptr %l27, !tbaa !29
  %t317 = load ptr, ptr %l27, !tbaa !29
  %t319 = getelementptr %"compiler/typed:Arm", ptr %t317, i32 0, i32 3
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb87, label %bb88
bb87:
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l172, !tbaa !29
  %t327 = load ptr, ptr %l27, !tbaa !29
  %t329 = getelementptr %"compiler/typed:Arm", ptr %t327, i32 0, i32 3
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t332 = icmp eq ptr %t330, null
  br i1 %t332, label %bb89, label %bb90
bb88:
  br label %bb93
bb89:
  call void @__olang_check_failed(ptr @olang_loc_d176219a3bee3f8a_90c874c8f8700e56)
  unreachable
bb90:
  br label %bb91
bb91:
  %t334 = load ptr, ptr %l27, !tbaa !29
  %t336 = getelementptr %"compiler/typed:Arm", ptr %t334, i32 0, i32 3
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t338 = load ptr, ptr %l172, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t338, ptr %t337)
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t340 = load ptr, ptr %l27, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Arm", ptr %t340, i32 0, i32 4
  %t343 = load ptr, ptr %t342, !tbaa !29
  %t345 = icmp eq ptr %t343, null
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb94, label %bb95
bb94:
  %t349 = load ptr, ptr %l0, !tbaa !29
  store ptr %t349, ptr %l182, !tbaa !29
  %t350 = load ptr, ptr %l27, !tbaa !29
  %t352 = getelementptr %"compiler/typed:Arm", ptr %t350, i32 0, i32 4
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = icmp eq ptr %t353, null
  br i1 %t355, label %bb96, label %bb97
bb95:
  br label %bb100
bb96:
  call void @__olang_check_failed(ptr @olang_loc_3832ed25f787c577_46d12f44adcfa45b)
  unreachable
bb97:
  br label %bb98
bb98:
  %t357 = load ptr, ptr %l27, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Arm", ptr %t357, i32 0, i32 4
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t361 = load ptr, ptr %l182, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t361, ptr %t360)
  br label %bb99
bb99:
  br label %bb100
bb100:
  br label %bb101
bb101:
  %t363 = load i64, ptr %l25, !tbaa !24
  %t365 = add i64 %t363, 1
  store i64 %t365, ptr %l25, !tbaa !24
  br label %bb83
bb102:
  %t367 = load ptr, ptr %l19, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Match", ptr %t367, i32 0, i32 2
  %t370 = load ptr, ptr %t369, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  %t374 = xor i1 %t372, true
  br i1 %t374, label %bb103, label %bb104
bb103:
  %t376 = load ptr, ptr %l19, !tbaa !29
  %t378 = getelementptr %"compiler/typed:Match", ptr %t376, i32 0, i32 2
  %t379 = load ptr, ptr %t378, !tbaa !29
  %t381 = icmp eq ptr %t379, null
  br i1 %t381, label %bb105, label %bb106
bb104:
  br label %bb118
bb105:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb106:
  br label %bb107
bb107:
  %t383 = load ptr, ptr %l19, !tbaa !29
  %t385 = getelementptr %"compiler/typed:Match", ptr %t383, i32 0, i32 2
  %t386 = load ptr, ptr %t385, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Arm", ptr %t386, i32 0, i32 3
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = icmp eq ptr %t390, null
  %t394 = xor i1 %t392, true
  br i1 %t394, label %bb108, label %bb109
bb108:
  %t396 = load ptr, ptr %l0, !tbaa !29
  store ptr %t396, ptr %l203, !tbaa !29
  %t397 = load ptr, ptr %l19, !tbaa !29
  %t399 = getelementptr %"compiler/typed:Match", ptr %t397, i32 0, i32 2
  %t400 = load ptr, ptr %t399, !tbaa !29
  %t402 = icmp eq ptr %t400, null
  br i1 %t402, label %bb110, label %bb111
bb109:
  br label %bb117
bb110:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb111:
  br label %bb112
bb112:
  %t404 = load ptr, ptr %l19, !tbaa !29
  %t406 = getelementptr %"compiler/typed:Match", ptr %t404, i32 0, i32 2
  %t407 = load ptr, ptr %t406, !tbaa !29
  %t410 = getelementptr %"compiler/typed:Arm", ptr %t407, i32 0, i32 3
  %t411 = load ptr, ptr %t410, !tbaa !29
  store ptr %t411, ptr %l28, !tbaa !29
  %t413 = load ptr, ptr %l28, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb113, label %bb114
bb113:
  call void @__olang_check_failed(ptr @olang_loc_78b7d87e61167558_7d12aa6674d4d96c)
  unreachable
bb114:
  br label %bb115
bb115:
  %t417 = load ptr, ptr %l28, !tbaa !29
  %t418 = load ptr, ptr %l203, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t418, ptr %t417)
  br label %bb116
bb116:
  br label %bb117
bb117:
  br label %bb118
bb118:
  br label %bb131
bb119:
  %t420 = load ptr, ptr %l1, !tbaa !29
  store ptr %t420, ptr %l214, !tbaa !29
  store i1 false, ptr %l215, !tbaa !21
  %t421 = load ptr, ptr %l214, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb120, label %bb121
bb120:
  %t424 = load ptr, ptr %l214, !tbaa !29
  %t425 = load i64, ptr %t424, !range !{i64 0, i64 18}
  %t427 = icmp eq i64 %t425, 8
  store i1 %t427, ptr %l215, !tbaa !21
  br label %bb121
bb121:
  %t428 = load i1, ptr %l215, !tbaa !21
  br i1 %t428, label %bb122, label %bb123
bb122:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t431, i32 0, i32 2
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l29, !tbaa !29
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load ptr, ptr %l29, !tbaa !29
  %t438 = getelementptr %"compiler/typed:Collect", ptr %t436, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t435, ptr %t439)
  br label %bb125
bb125:
  br label %bb131
bb126:
  br i1 true, label %bb127, label %bb128
bb127:
  br label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_check_failed(ptr @olang_loc_5c0fdc79e2d66a14_68e7480db742a728)
  unreachable
bb131:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l33 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t5, i32 %a1)
  store i32 %t9, ptr %l9
  br label %bb2
bb2:
  %t10 = load i32, ptr %l9, !tbaa !23
  store i32 %t10, ptr %l3, !tbaa !23
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l3, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l12
  br label %bb3
bb3:
  %t16 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t18 = trunc i64 18 to i32
  %t19 = icmp eq i32 %t16, %t18
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb7
bb5:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb9:
  %t32 = load ptr, ptr %l2, !tbaa !29
  store ptr %t32, ptr %l22, !tbaa !29
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l25
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l22, !tbaa !29
  %t39 = load i32, ptr %l25, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t40, ptr %l26
  br label %bb11
bb11:
  %t41 = load i32, ptr %l26, !range !{i32 0, i32 6}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l33
  br label %bb16
bb16:
  %t55 = load i1, ptr %l33, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t57 = load ptr, ptr %l2, !tbaa !29
  store ptr %t57, ptr %l35, !tbaa !29
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t59 = load i32, ptr %l3, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l38
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t64 = load i32, ptr %l38, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t63, i32 %t64)
  store { i64, ptr } %t65, ptr %l39
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t66, ptr %l4, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp eq i64 %t69, 1
  br i1 %t71, label %bb22, label %bb23
bb22:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t74 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t74, ptr %l45, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr i32, ptr %t76, i64 0
  %t78 = load i32, ptr %t77, !tbaa !33
  %t81 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t73, i32 %t78)
  store i1 %t81, ptr %l47
  br label %bb24
bb23:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  %t82 = load i1, ptr %l47, !tbaa !21
  store i1 %t82, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t83 = load i1, ptr %l43, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDtor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 1
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store ptr %t23, ptr %l15
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Body", ptr %t24, i32 0, i32 1
  %t27 = load { i64, [2 x i64] }, ptr %t26
  %t31 = extractvalue { i64, [2 x i64] } %t27, 0
  %t32 = icmp eq i64 %t31, 3
  br i1 %t32, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_9eead29ed0644a31_3adf6a8ef4d2d8d5)
  unreachable
bb17:
  %t34 = load i1, ptr %l18, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisOwnLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 9
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 9
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp eq i64 %t23, -3
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store ptr %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  store { i64, [2 x i64] } %t15, ptr %l3
  %t17 = load { i64, [2 x i64] }, ptr %l3
  %t19 = extractvalue { i64, [2 x i64] } %t17, 0
  %t20 = icmp eq i64 %t19, 3
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t23 = getelementptr { i32 }, ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 68
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l4, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l21
  br label %bb6
bb6:
  %t34 = load i32, ptr %l21, !tbaa !23
  %t35 = sext i32 %t34 to i64
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t37, i64 %t35, i64 %t36)
  br label %bb7
bb7:
  br label %bb33
bb8:
  %t40 = load { i64, [2 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 1
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb28
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 1
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store ptr %t52, ptr %l30
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t57, i32 %t56)
  store { i64, ptr } %t59, ptr %l33
  br label %bb13
bb13:
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp eq i64 %t63, 1
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 0
  %t71 = load i32, ptr %t70, !tbaa !33
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t67, i32 %t71)
  store i1 %t74, ptr %l40
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t75 = load i1, ptr %l40, !tbaa !21
  store i1 %t75, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l37, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 0
  %t82 = load i32, ptr %t81, !tbaa !33
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t78, i32 %t82)
  store i32 %t85, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb20:
  %t86 = load ptr, ptr %l42, !tbaa !29
  %t87 = load i32, ptr %l45, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l46
  br label %bb21
bb21:
  %t89 = load i1, ptr %l46, !tbaa !21
  store i1 %t89, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t90 = load i1, ptr %l41, !tbaa !21
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l47, !tbaa !29
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 0
  %t96 = load i32, ptr %t95, !tbaa !33
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t92, i32 %t96)
  store i32 %t99, ptr %l50
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %t100, i32 %t101)
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_4e10a6e17fa9b999_b873e8c9bb06b2fd)
  unreachable
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l64 = alloca i1
  %l72 = alloca { i64, [1 x i64] }
  %l74 = alloca { i64, [1 x i64] }
  %l76 = alloca i1
  %l77 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca i64
  %l85 = alloca i1
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, [1 x i64] }
  %l94 = alloca { i64, [1 x i64] }
  %l96 = alloca i1
  %l98 = alloca i64
  %l106 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l25
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l25, !tbaa !29
  store ptr %t18, ptr %l6, !tbaa !29
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = load i64, ptr %l26, !tbaa !24
  %t22 = shl i64 1, %t21
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load i64, ptr %l10, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l10, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l37, !tbaa !24
  store i64 %t57, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l34, !tbaa !24
  store i64 %t58, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l12, !tbaa !24
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb43
bb16:
  br label %bb17
bb17:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l13, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l13, !tbaa !24
  %t83 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t77, i64 %t78, i64 %t79)
  store i64 %t83, ptr %l58
  br label %bb18
bb18:
  %t84 = load i64, ptr %l58, !tbaa !24
  store i64 %t84, ptr %l14, !tbaa !24
  %t85 = load i64, ptr %l14, !tbaa !24
  %t87 = icmp slt i64 %t85, 0
  br i1 %t87, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  %t89 = load i64, ptr %l14, !tbaa !24
  %t91 = icmp sge i64 %t89, 63
  store i1 %t91, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l61, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb24
bb23:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t95 = load i64, ptr %l5, !tbaa !24
  %t98 = icmp eq i64 %t94, %t95
  store i1 %t98, ptr %l64, !tbaa !21
  br label %bb24
bb24:
  %t100 = load i1, ptr %l64, !tbaa !21
  br i1 %t100, label %bb25, label %bb26
bb25:
  br label %bb42
bb26:
  br label %bb27
bb27:
  %t101 = load ptr, ptr %l6, !tbaa !29
  %t102 = load ptr, ptr %l2, !tbaa !29
  %t104 = getelementptr %"compiler/typed:Call", ptr %t102, i32 0, i32 2
  %t105 = load i32, ptr %t104, !tbaa !23
  %t106 = load i64, ptr %l14, !tbaa !24
  %t110 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t101, i32 %t105, i64 %t106)
  store { i64, [1 x i64] } %t110, ptr %l72
  br label %bb28
bb28:
  %t111 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t111, ptr %l74
  %t114 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l72, ptr %l74)
  store i1 %t114, ptr %l76
  br label %bb29
bb29:
  %t115 = load i1, ptr %l76, !tbaa !21
  br i1 %t115, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l2, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Call", ptr %t117, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l80, !tbaa !27
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t129 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t116, ptr %t126)
  store i64 %t129, ptr %l83
  br label %bb32
bb31:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb33
bb32:
  %t130 = load i64, ptr %l83, !tbaa !24
  %t131 = icmp sge i64 %t130, 0
  store i1 %t131, ptr %l77, !tbaa !21
  br label %bb33
bb33:
  %t133 = load i1, ptr %l77, !tbaa !21
  br i1 %t133, label %bb34, label %bb35
bb34:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t138 = getelementptr %"compiler/typed:Call", ptr %t136, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l89, !tbaa !27
  %t140 = load i64, ptr %l13, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr ptr, ptr %t143, i64 %t140
  %t145 = load ptr, ptr %t144, !tbaa !39
  %t149 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t134, i64 %t135, ptr %t145)
  store { i64, [1 x i64] } %t149, ptr %l92
  br label %bb36
bb35:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb38
bb36:
  %t150 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t150, ptr %l94
  %t153 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l92, ptr %l94)
  store i1 %t153, ptr %l96
  br label %bb37
bb37:
  %t154 = load i1, ptr %l96, !tbaa !21
  store i1 %t154, ptr %l85, !tbaa !21
  br label %bb38
bb38:
  %t155 = load i1, ptr %l85, !tbaa !21
  br i1 %t155, label %bb39, label %bb40
bb39:
  %t156 = load i64, ptr %l7, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  store i64 %t157, ptr %l98, !tbaa !24
  %t158 = load i64, ptr %l98, !tbaa !24
  %t159 = load i64, ptr %l98, !tbaa !24
  %t160 = shl i64 1, %t159
  %t163 = or i64 %t156, %t160
  store i64 %t163, ptr %l7, !tbaa !24
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t165 = load i64, ptr %l12, !tbaa !24
  %t167 = add i64 %t165, 1
  store i64 %t167, ptr %l12, !tbaa !24
  br label %bb14
bb43:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:Free", ptr %t169, i32 0, i32 2
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load i64, ptr %l3, !tbaa !24
  %t176 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t172, i64 %t173)
  store { i64, ptr } %t176, ptr %l106
  br label %bb44
bb44:
  %t177 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i64, ptr %l7, !tbaa !24
  %t184 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t178, { i64, ptr } %t177, i64 %t180)
  store i1 %t184, ptr %l110
  br label %bb45
bb45:
  %t185 = load i1, ptr %l110, !tbaa !21
  br i1 %t185, label %bb46, label %bb47
bb46:
  %t186 = load i64, ptr %l7, !tbaa !24
  store i64 %t186, ptr %l111, !tbaa !24
  br label %bb48
bb47:
  store i64 -1, ptr %l111, !tbaa !24
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t188 = load i64, ptr %l111, !tbaa !24
  store i64 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca i1
  %l71 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t11 = load ptr, ptr %l12, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 1
  store i1 %t17, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l13, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb13
bb8:
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb9, label %bb10
bb9:
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 7
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb54
bb14:
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb15, label %bb16
bb15:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 8}
  %t35 = icmp eq i64 %t33, 2
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb17, label %bb18
bb17:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t47 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t43, ptr %t44)
  store i1 %t47, ptr %l28
  br label %bb20
bb20:
  %t48 = load i1, ptr %l28, !tbaa !21
  store i1 %t48, ptr %l7, !tbaa !21
  br label %bb54
bb21:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb22, label %bb23
bb22:
  %t53 = load ptr, ptr %l29, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 8}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l30, !tbaa !21
  br label %bb23
bb23:
  %t57 = load i1, ptr %l30, !tbaa !21
  br i1 %t57, label %bb24, label %bb25
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t60, i32 0, i32 2
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store i1 %t68, ptr %l37
  br label %bb27
bb27:
  %t69 = load i1, ptr %l37, !tbaa !21
  store i1 %t69, ptr %l7, !tbaa !21
  br label %bb54
bb28:
  %t70 = load ptr, ptr %l1, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb29, label %bb30
bb29:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 8}
  %t77 = icmp eq i64 %t75, 4
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb30
bb30:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb31, label %bb32
bb31:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr { i64, [4 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t81, i32 0, i32 2
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb39
bb33:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/typed:Elem", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t92 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t85, ptr %t89)
  store i1 %t92, ptr %l47
  br label %bb34
bb34:
  %t93 = load i1, ptr %l47, !tbaa !21
  br i1 %t93, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb38
bb36:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load ptr, ptr %l4, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Elem", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t101 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t94, ptr %t98)
  store i1 %t101, ptr %l52
  br label %bb37
bb37:
  %t102 = load i1, ptr %l52, !tbaa !21
  store i1 %t102, ptr %l48, !tbaa !21
  br label %bb38
bb38:
  %t103 = load i1, ptr %l48, !tbaa !21
  store i1 %t103, ptr %l7, !tbaa !21
  br label %bb54
bb39:
  %t104 = load ptr, ptr %l1, !tbaa !29
  store ptr %t104, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t105 = load ptr, ptr %l53, !tbaa !29
  %t106 = icmp ne ptr %t105, null
  br i1 %t106, label %bb40, label %bb41
bb40:
  %t108 = load ptr, ptr %l53, !tbaa !29
  %t109 = load i64, ptr %t108, !range !{i64 0, i64 8}
  %t111 = icmp eq i64 %t109, 5
  store i1 %t111, ptr %l54, !tbaa !21
  br label %bb41
bb41:
  %t112 = load i1, ptr %l54, !tbaa !21
  br i1 %t112, label %bb42, label %bb43
bb42:
  %t113 = load ptr, ptr %l1, !tbaa !29
  %t115 = getelementptr { i64, [4 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l5, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load ptr, ptr %l5, !tbaa !29
  %t122 = getelementptr %"compiler/typed:Payload", ptr %t120, i32 0, i32 0
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t126 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t119, ptr %t123)
  store i1 %t126, ptr %l62
  br label %bb45
bb45:
  %t127 = load i1, ptr %l62, !tbaa !21
  store i1 %t127, ptr %l7, !tbaa !21
  br label %bb54
bb46:
  %t128 = load ptr, ptr %l1, !tbaa !29
  store ptr %t128, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t129 = load ptr, ptr %l63, !tbaa !29
  %t130 = icmp ne ptr %t129, null
  br i1 %t130, label %bb47, label %bb48
bb47:
  %t132 = load ptr, ptr %l63, !tbaa !29
  %t133 = load i64, ptr %t132, !range !{i64 0, i64 8}
  %t135 = icmp eq i64 %t133, 6
  store i1 %t135, ptr %l64, !tbaa !21
  br label %bb48
bb48:
  %t136 = load i1, ptr %l64, !tbaa !21
  br i1 %t136, label %bb49, label %bb50
bb49:
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr { i64, [4 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t139, i32 0, i32 2
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l6, !tbaa !29
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t147 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t143, ptr %t144)
  store i1 %t147, ptr %l71
  br label %bb52
bb52:
  %t148 = load i1, ptr %l71, !tbaa !21
  store i1 %t148, ptr %l7, !tbaa !21
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_a4118a366f7ca1d5_524409770a0878b9)
  unreachable
bb54:
  %t149 = load i1, ptr %l7, !tbaa !21
  store i1 %t149, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceName(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 4
  %t5 = load %"compiler/source:Span", ptr %t4
  %t9 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %t3, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t18, i32 0, i32 3
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb6
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l14, !tbaa !29
  %t28 = load i32, ptr %l16, !tbaa !23
  %t30 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t27, i32 %t28, i64 %t26)
  store i64 %t30, ptr %l18
  br label %bb7
bb7:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  br label %bb22
bb8:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l19, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 8}
  %t39 = icmp eq i64 %t37, 4
  store i1 %t39, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t40 = load i1, ptr %l20, !tbaa !21
  br i1 %t40, label %bb11, label %bb12
bb11:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [4 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t47 = load ptr, ptr %l0, !tbaa !29
  store ptr %t47, ptr %l25, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t52)
  store i32 %t54, ptr %l29
  br label %bb14
bb14:
  %t55 = load ptr, ptr %l26, !tbaa !29
  %t56 = load i32, ptr %l29, !tbaa !23
  %t57 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t57, ptr %l30
  br label %bb15
bb15:
  %t58 = load ptr, ptr %l25, !tbaa !29
  %t59 = load i32, ptr %l30, !tbaa !23
  %t60 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t58, i32 %t59, i64 -1)
  store i64 %t60, ptr %l31
  br label %bb16
bb16:
  %t61 = load i64, ptr %l31, !tbaa !24
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_5c44d6b41b035ab1_55f561a861d07b6d)
  unreachable
bb22:
  %t62 = load i64, ptr %l5, !tbaa !24
  store i64 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:store"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l13 = alloca { i64, [1 x i64] }
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l45 = alloca %"compiler/free:store"
  %l46 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l55 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i64
  %l68 = alloca { i64, [1 x i64] }
  %l71 = alloca i64
  %l73 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:store" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t2 = load ptr, ptr %t1, !tbaa !29
  %t4 = icmp eq ptr %t2, null
  br i1 %t4, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_3bfd4abaed3d7178_ecedd42d9535955c)
  unreachable
bb2:
  br label %bb3
bb3:
  %t6 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 7
  %t7 = load ptr, ptr %t6, !tbaa !29
  store ptr %t7, ptr %l2, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t16 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t9, i64 %t11, ptr %t12)
  store { i64, [1 x i64] } %t16, ptr %l13
  br label %bb4
bb4:
  %t17 = load { i64, [1 x i64] }, ptr %l13
  %t18 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t17)
  store i1 %t18, ptr %l14
  br label %bb5
bb5:
  %t19 = load i1, ptr %l14, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t26 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t23)
  store ptr %t26, ptr %l19
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l19, !tbaa !29
  store ptr %t27, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l2, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 18}
  %t35 = icmp eq i64 %t33, 5
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Promote", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = call ptr @compiler_2ffree_2ectorCall(ptr %v1, ptr %s0, ptr %t46)
  store ptr %t48, ptr %l28
  br label %bb15
bb15:
  %t49 = load ptr, ptr %l28, !tbaa !29
  store ptr %t49, ptr %l3, !tbaa !29
  br label %bb35
bb16:
  %t50 = load ptr, ptr %l2, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t51 = load ptr, ptr %l29, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l29, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 18}
  %t57 = icmp eq i64 %t55, 17
  store i1 %t57, ptr %l30, !tbaa !21
  br label %bb18
bb18:
  %t58 = load i1, ptr %l30, !tbaa !21
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l2, !tbaa !29
  %t61 = getelementptr { i64, [5 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l5, !tbaa !29
  br label %bb21
bb20:
  br label %bb24
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l35, !tbaa !29
  %t66 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 2
  %t71 = load i64, ptr %t70, !tbaa !24
  %t72 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 3
  %t73 = load %"compiler/source:Span", ptr %t72
  %t74 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 4
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 5
  %t77 = load i64, ptr %t76, !tbaa !24
  %t78 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 6
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t90 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %s3, ptr %s3, i64 %t67, i64 %t69, i64 %t71, %"compiler/source:Span" %t73, i64 %t75, i64 %t77, i64 %t79, ptr %t80, ptr null)
  store %"compiler/free:store" %t90, ptr %l45
  br label %bb22
bb22:
  %t91 = load ptr, ptr %l35, !tbaa !29
  %t92 = load %"compiler/free:store", ptr %l45
  %t93 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %s3, ptr %t91, %"compiler/free:store" %t92)
  store i1 %t93, ptr %l46
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i1, ptr %l46, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
bb24:
  %t95 = load ptr, ptr %l2, !tbaa !29
  store ptr %t95, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t96 = load ptr, ptr %l47, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t99 = load ptr, ptr %l47, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 6
  store i1 %t102, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t103 = load i1, ptr %l48, !tbaa !21
  br i1 %t103, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb34:
  call void @__olang_check_failed(ptr @olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572)
  unreachable
bb35:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t107 = icmp eq ptr %t105, null
  br i1 %t107, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t110 = load ptr, ptr %l3, !tbaa !29
  store ptr %t110, ptr %l55, !tbaa !29
  %t111 = load ptr, ptr %l55, !tbaa !29
  %t112 = call ptr @__olang_scope_of(ptr %t111, ptr null)
  %t113 = ptrtoint ptr %t112 to i64
  %t115 = inttoptr i64 %t113 to ptr
  %t116 = load ptr, ptr %l55, !tbaa !29
  %t117 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %t115, ptr %t116)
  store i64 %t117, ptr %l57
  br label %bb39
bb39:
  %t118 = load i64, ptr %l57, !tbaa !24
  store i64 %t118, ptr %l6, !tbaa !24
  %t119 = load i64, ptr %l6, !tbaa !24
  %t121 = icmp slt i64 %t119, 0
  br i1 %t121, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l61, !tbaa !29
  %t125 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t126 = load i64, ptr %t125, !tbaa !24
  store i64 %t126, ptr %l62, !tbaa !24
  %t127 = load ptr, ptr %l3, !tbaa !29
  store ptr %t127, ptr %l63, !tbaa !29
  %t128 = load i64, ptr %l6, !tbaa !24
  store i64 %t128, ptr %l64, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/free:store", ptr %l1, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t136 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t129, i64 %t131, ptr %t132)
  store { i64, [1 x i64] } %t136, ptr %l68
  br label %bb43
bb43:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l6, !tbaa !24
  %t141 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l71
  br label %bb44
bb44:
  %t142 = load ptr, ptr %l63, !tbaa !29
  %t143 = call ptr @__olang_scope_of(ptr %t142, ptr null)
  %t144 = ptrtoint ptr %t143 to i64
  %t146 = inttoptr i64 %t144 to ptr
  %t147 = load ptr, ptr %l61, !tbaa !29
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = load ptr, ptr %l63, !tbaa !29
  %t150 = load i64, ptr %l64, !tbaa !24
  %t151 = load { i64, [1 x i64] }, ptr %l68
  %t152 = load i64, ptr %l71, !tbaa !24
  %t153 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %t146, ptr %t147, i64 %t148, ptr %t149, i64 %t150, { i64, [1 x i64] } %t151, i64 %t152)
  store i64 %t153, ptr %l73
  br label %bb45
bb45:
  %t154 = load i64, ptr %l73, !tbaa !24
  %t155 = icmp sge i64 %t154, 0
  call void @__olang_scope_close(ptr %s0)
  store i1 %t155, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2erecvOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l1 = alloca %"compiler/free:letGo"
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 2
  %t3 = load i64, ptr %t2, !tbaa !24
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 6
  %t5 = load %"compiler/source:Span", ptr %t4
  %t9 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %t3, %"compiler/source:Span" %t5)
  store { i64, ptr } %t9, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l7 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca i32
  %l25 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i64
  %l35 = alloca i64
  %l40 = alloca i32
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 66
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 69
  store ptr %t8, ptr %l9, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l11
  br label %bb3
bb2:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb6
bb3:
  %t12 = load i32, ptr %l1, !tbaa !23
  %t13 = load ptr, ptr %l11, !tbaa !29
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t13, i32 %t12)
  store i32 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load i32, ptr %l13, !tbaa !23
  %t17 = sext i32 %t16 to i64
  %t18 = load ptr, ptr %l9, !tbaa !29
  %t20 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t18, i64 %t17)
  store i1 %t20, ptr %l15
  br label %bb5
bb5:
  %t21 = load i1, ptr %l15, !tbaa !21
  %t22 = xor i1 %t21, true
  store i1 %t22, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l7, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t25)
  store ptr %t27, ptr %l18
  br label %bb9
bb8:
  br label %bb17
bb9:
  %t28 = load i32, ptr %l1, !tbaa !23
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s1, ptr %t29, i32 %t28)
  store { i64, ptr } %t31, ptr %l20
  br label %bb10
bb10:
  %t32 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t37 = add i64 %t33, %t36
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t32, i64 %t33)
  %t42 = getelementptr i8, ptr %t41, i64 %t33
  call void @olang_textcopy(ptr %t42, ptr %t35, i64 %t36)
  %t43 = getelementptr i8, ptr %t42, i64 %t36
  call void @olang_textcopy(ptr %t43, ptr %t38, i64 %t39)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t41, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t54 = call i32 @std_2fio_2ePrintErr(ptr %s1, { i64, ptr } %t52)
  store i32 %t54, ptr %l23
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb12, label %ok.56, !prof !99
ok.56:
  br label %bb11
bb11:
  br label %bb16
bb12:
  %t57 = load i32, ptr %l23, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l25, !tbaa !21
  %t61 = load i32, ptr %l23, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t66)
  store ptr %t68, ptr %l29
  br label %bb18
bb18:
  %t69 = load i32, ptr %l1, !tbaa !23
  %t70 = load ptr, ptr %l29, !tbaa !29
  %t72 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eValueParts(ptr %v0, ptr %s4, ptr %t70, i32 %t69)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l31
  br label %bb19
bb19:
  %t73 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  %t74 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %t74
  store ptr %t74, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb20
bb20:
  %t76 = load i64, ptr %l3, !tbaa !24
  store i64 %t76, ptr %l33, !tbaa !24
  %t77 = load ptr, ptr %l2, !tbaa !29
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s4, ptr %t77)
  store i64 %t79, ptr %l35
  br label %bb21
bb21:
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = load i64, ptr %l35, !tbaa !24
  %t82 = icmp slt i64 %t80, %t81
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  br label %bb28
bb23:
  br label %bb24
bb24:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load i64, ptr %l3, !tbaa !24
  %t90 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s4, ptr %t86, i64 %t87)
  store i32 %t90, ptr %l40
  br label %bb25
bb25:
  %t91 = load i32, ptr %l40, !tbaa !23
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:Free", ptr %t92, i32 0, i32 69
  %t97 = sext i32 %t91 to i64
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t94, i64 %t97, i1 true)
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t100 = load i64, ptr %l3, !tbaa !24
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l3, !tbaa !24
  br label %bb20
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eshown(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:letGo"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l10 = alloca i1
  %l23 = alloca i1
  %l27 = alloca { i64, ptr }
  %l40 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:letGo" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 22
  %t4 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t3, i64 %t5)
  store i1 %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load i1, ptr %l10, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 5
  %t14 = load i64, ptr %t13, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t18 = icmp ne i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 22
  %t30 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t31 = load i64, ptr %t30, !tbaa !24
  %t34 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t29, i64 %t31)
  store i1 %t34, ptr %l23
  br label %bb11
bb11:
  %t35 = load i1, ptr %l23, !tbaa !21
  br i1 %t35, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:letGo", ptr %l1, i32 0, i32 7
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s0, ptr %t37, i64 %t39)
  store { i64, ptr } %t42, ptr %l27
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t43, ptr %l2, !tbaa !27
  store ptr @G_2ecompiler_2ffree_2eRemovalNames, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t45 = load ptr, ptr %l3
  store i64 9, ptr %l5, !tbaa !24
  br label %bb16
bb16:
  %t48 = load i64, ptr %l4, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l3
  %t57 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr [9 x { i64, ptr }], ptr %t56, i64 0, i64 %t57
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = load ptr, ptr @__olang_prog_scope
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t65, ptr %s0, { i64, ptr } %t61, { i64, ptr } %t64)
  store i1 %t68, ptr %l40
  br label %bb20
bb20:
  %t69 = load i1, ptr %l40, !tbaa !21
  br i1 %t69, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb16
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l76 = alloca i1
  %l82 = alloca i1
  %l83 = alloca ptr
  %l91 = alloca i1
  %l93 = alloca ptr
  %l94 = alloca i1
  %l104 = alloca i1
  %l109 = alloca i1
  %l113 = alloca i1
  %l115 = alloca ptr
  %l116 = alloca i1
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb100
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l5, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 17}
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l24, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l24, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr { i64, [3 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l6, !tbaa !29
  br label %bb17
bb8:
  %t38 = load ptr, ptr %l5, !tbaa !29
  store ptr %t38, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l29, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 17}
  %t45 = icmp eq i64 %t43, 2
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb10
bb10:
  %t46 = load i1, ptr %l30, !tbaa !21
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t49 = getelementptr { i64, [3 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l6, !tbaa !29
  br label %bb17
bb12:
  %t53 = load ptr, ptr %l5, !tbaa !29
  store ptr %t53, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t54 = load ptr, ptr %l35, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load ptr, ptr %l35, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 17}
  %t60 = icmp eq i64 %t58, 15
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l5, !tbaa !29
  %t64 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", ptr }, ptr %t64, i32 0, i32 1
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l6, !tbaa !29
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l6, !tbaa !29
  %t72 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i1 %t72, ptr %l43
  br label %bb18
bb18:
  %t73 = load i1, ptr %l43, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb98
bb22:
  %t75 = load ptr, ptr %l5, !tbaa !29
  store ptr %t75, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t76 = load ptr, ptr %l45, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb23, label %bb24
bb23:
  %t79 = load ptr, ptr %l45, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 17}
  %t82 = icmp eq i64 %t80, 1
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t84 = load ptr, ptr %l5, !tbaa !29
  %t86 = getelementptr { i64, [3 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t86, i32 0, i32 1
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l7, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr { i64, [3 x i64] }, ptr %t90, i32 0, i32 1
  %t93 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t92, i32 0, i32 2
  %t94 = load ptr, ptr %t93
  store ptr %t94, ptr %l8, !tbaa !29
  br label %bb27
bb26:
  br label %bb36
bb27:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t100 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceMayRegister(ptr %v0, ptr %v1, ptr %t96, ptr %t97)
  store i1 %t100, ptr %l55
  br label %bb28
bb28:
  %t101 = load i1, ptr %l55, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb32
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t106 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  store i1 %t106, ptr %l59
  br label %bb31
bb31:
  %t107 = load i1, ptr %l59, !tbaa !21
  store i1 %t107, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l56, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb98
bb36:
  %t110 = load ptr, ptr %l5, !tbaa !29
  store ptr %t110, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t111 = load ptr, ptr %l61, !tbaa !29
  %t112 = icmp ne ptr %t111, null
  br i1 %t112, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l61, !tbaa !29
  %t115 = load i64, ptr %t114, !range !{i64 0, i64 17}
  %t117 = icmp eq i64 %t115, 3
  store i1 %t117, ptr %l62, !tbaa !21
  br label %bb38
bb38:
  %t118 = load i1, ptr %l62, !tbaa !21
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t121 = getelementptr { i64, [3 x i64] }, ptr %t119, i32 0, i32 1
  %t122 = getelementptr { %"compiler/source:Span", ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122
  store ptr %t123, ptr %l9, !tbaa !29
  br label %bb41
bb40:
  br label %bb60
bb41:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l9, !tbaa !29
  %t128 = getelementptr %"compiler/typed:If", ptr %t126, i32 0, i32 0
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t132 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %t125, ptr %t129)
  store i1 %t132, ptr %l70
  br label %bb42
bb42:
  %t133 = load i1, ptr %l70, !tbaa !21
  br i1 %t133, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb46
bb44:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %l9, !tbaa !29
  %t137 = getelementptr %"compiler/typed:If", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Block", ptr %t138, i32 0, i32 1
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  %t144 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t134, { i64, ptr } %t141)
  store i1 %t144, ptr %l76
  br label %bb45
bb45:
  %t145 = load i1, ptr %l76, !tbaa !21
  store i1 %t145, ptr %l71, !tbaa !21
  br label %bb46
bb46:
  %t146 = load i1, ptr %l71, !tbaa !21
  br i1 %t146, label %bb47, label %bb48
bb47:
  store i1 true, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  %t148 = load ptr, ptr %l9, !tbaa !29
  %t150 = getelementptr %"compiler/typed:If", ptr %t148, i32 0, i32 2
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  %t155 = xor i1 %t153, true
  br i1 %t155, label %bb50, label %bb51
bb50:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l83, !tbaa !29
  %t158 = load ptr, ptr %l9, !tbaa !29
  %t160 = getelementptr %"compiler/typed:If", ptr %t158, i32 0, i32 2
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb52, label %bb53
bb51:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb56
bb52:
  call void @__olang_check_failed(ptr @olang_loc_b71f5ffe7a4b5626_fc1be7c1ddcacd52)
  unreachable
bb53:
  br label %bb54
bb54:
  %t165 = load ptr, ptr %l9, !tbaa !29
  %t167 = getelementptr %"compiler/typed:If", ptr %t165, i32 0, i32 2
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Block", ptr %t168, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  %t173 = load ptr, ptr %l83, !tbaa !29
  %t175 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t173, { i64, ptr } %t172)
  store i1 %t175, ptr %l91
  br label %bb55
bb55:
  %t176 = load i1, ptr %l91, !tbaa !21
  store i1 %t176, ptr %l82, !tbaa !21
  br label %bb56
bb56:
  %t177 = load i1, ptr %l82, !tbaa !21
  br i1 %t177, label %bb57, label %bb58
bb57:
  store i1 true, ptr %rv
  br label %ret
bb58:
  br label %bb59
bb59:
  br label %bb98
bb60:
  %t179 = load ptr, ptr %l5, !tbaa !29
  store ptr %t179, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t180 = load ptr, ptr %l93, !tbaa !29
  %t181 = icmp ne ptr %t180, null
  br i1 %t181, label %bb61, label %bb62
bb61:
  %t183 = load ptr, ptr %l93, !tbaa !29
  %t184 = load i64, ptr %t183, !range !{i64 0, i64 17}
  %t186 = icmp eq i64 %t184, 4
  store i1 %t186, ptr %l94, !tbaa !21
  br label %bb62
bb62:
  %t187 = load i1, ptr %l94, !tbaa !21
  br i1 %t187, label %bb63, label %bb64
bb63:
  %t188 = load ptr, ptr %l5, !tbaa !29
  %t190 = getelementptr { i64, [3 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t190, i32 0, i32 1
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l10, !tbaa !29
  %t194 = load ptr, ptr %l5, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t196, i32 0, i32 2
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l11, !tbaa !29
  br label %bb65
bb64:
  br label %bb77
bb65:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load ptr, ptr %l10, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Block", ptr %t201, i32 0, i32 1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t207 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t200, { i64, ptr } %t204)
  store i1 %t207, ptr %l104
  br label %bb66
bb66:
  %t208 = load i1, ptr %l104, !tbaa !21
  br i1 %t208, label %bb67, label %bb68
bb67:
  store i1 true, ptr %rv
  br label %ret
bb68:
  br label %bb69
bb69:
  %t210 = load ptr, ptr %l11, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb70, label %bb71
bb70:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = load ptr, ptr %l11, !tbaa !29
  %t219 = getelementptr %"compiler/typed:Block", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t223 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t216, { i64, ptr } %t220)
  store i1 %t223, ptr %l113
  br label %bb72
bb71:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb73
bb72:
  %t224 = load i1, ptr %l113, !tbaa !21
  store i1 %t224, ptr %l109, !tbaa !21
  br label %bb73
bb73:
  %t225 = load i1, ptr %l109, !tbaa !21
  br i1 %t225, label %bb74, label %bb75
bb74:
  store i1 true, ptr %rv
  br label %ret
bb75:
  br label %bb76
bb76:
  br label %bb98
bb77:
  %t227 = load ptr, ptr %l5, !tbaa !29
  store ptr %t227, ptr %l115, !tbaa !29
  store i1 false, ptr %l116, !tbaa !21
  %t228 = load ptr, ptr %l115, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb78, label %bb79
bb78:
  %t231 = load ptr, ptr %l115, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 17}
  %t234 = icmp eq i64 %t232, 11
  store i1 %t234, ptr %l116, !tbaa !21
  br label %bb79
bb79:
  %t235 = load i1, ptr %l116, !tbaa !21
  br i1 %t235, label %bb80, label %bb81
bb80:
  %t236 = load ptr, ptr %l5, !tbaa !29
  %t238 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", ptr }, ptr %t238, i32 0, i32 1
  %t240 = load ptr, ptr %t239
  store ptr %t240, ptr %l12, !tbaa !29
  br label %bb82
bb81:
  br label %bb87
bb82:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load ptr, ptr %l12, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Block", ptr %t243, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t249 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2estmtsMayRegister(ptr %v0, ptr %v1, ptr %t242, { i64, ptr } %t246)
  store i1 %t249, ptr %l124
  br label %bb83
bb83:
  %t250 = load i1, ptr %l124, !tbaa !21
  br i1 %t250, label %bb84, label %bb85
bb84:
  store i1 true, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  br label %bb98
bb87:
  %t252 = load ptr, ptr %l5, !tbaa !29
  store ptr %t252, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t253 = load ptr, ptr %l126, !tbaa !29
  %t254 = icmp ne ptr %t253, null
  br i1 %t254, label %bb88, label %bb89
bb88:
  %t256 = load ptr, ptr %l126, !tbaa !29
  %t257 = load i64, ptr %t256, !range !{i64 0, i64 17}
  %t259 = icmp eq i64 %t257, 5
  store i1 %t259, ptr %l127, !tbaa !21
  br label %bb89
bb89:
  %t260 = load i1, ptr %l127, !tbaa !21
  br i1 %t260, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb98
bb93:
  br i1 true, label %bb94, label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb97
bb96:
  store i1 true, ptr %rv
  br label %ret
bb97:
  call void @__olang_check_failed(ptr @olang_loc_80901eaab4a643b4_757281eb5f4291b0)
  unreachable
bb98:
  br label %bb99
bb99:
  %t262 = load i64, ptr %l3, !tbaa !24
  %t264 = add i64 %t262, 1
  store i64 %t264, ptr %l3, !tbaa !24
  br label %bb1
bb100:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l24 = alloca i1
  %l29 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t5, ptr %l9, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l10, !tbaa !24
  %t8 = load i64, ptr %l10, !tbaa !24
  %t9 = mul i64 %t8, 1
  %t10 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = mul i64 %t17, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %t16, i64 %t18, i1 false)
  %t19 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t19, ptr %l9, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t23 = getelementptr %"compiler/free:Free", ptr %a0, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 0
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/load:Loader", ptr %t27, i32 0, i32 4
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store { i64, ptr } %t34, ptr %l17
  br label %bb4
bb4:
  %t35 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t35, ptr %l3, !tbaa !27
  %t36 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t39 = sext i32 %t37 to i64
  store i64 %t39, ptr %l4, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  store i64 %t44, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb7
bb6:
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  %t56 = icmp sgt i64 %t50, %t53
  store i1 %t56, ptr %l24, !tbaa !21
  br label %bb7
bb7:
  %t58 = load i1, ptr %l24, !tbaa !21
  br i1 %t58, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb10
bb9:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp sge i64 %t59, %t60
  store i1 %t63, ptr %l29, !tbaa !21
  br label %bb10
bb10:
  %t65 = load i1, ptr %l29, !tbaa !21
  br i1 %t65, label %bb11, label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t66, ptr %l34, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l35, !tbaa !24
  %t69 = load i64, ptr %l35, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l36, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t80, ptr %l34, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t81, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t82 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t82, ptr %l37, !tbaa !27
  %t83 = load i64, ptr %l4, !tbaa !24
  store i64 %t83, ptr %l38, !tbaa !24
  %t84 = load i64, ptr %l5, !tbaa !24
  store i64 %t84, ptr %l39, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l40, !tbaa !24
  %t87 = load i64, ptr %l38, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t90 = load i64, ptr %l38, !tbaa !24
  %t91 = load i64, ptr %l39, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bdafa441ac13699b_f5af7a3548cb73f)
  unreachable
bb16:
  %t94 = load i64, ptr %l39, !tbaa !24
  %t95 = load i64, ptr %l40, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_bdafa441ac13699b_f5af7a3548cb73f)
  unreachable
bb18:
  %t98 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l38, !tbaa !24
  %t101 = load i64, ptr %l39, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = extractvalue { i64, ptr } %t105, 0
  %t109 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t108)
  call void @olang_textcopy(ptr %t109, ptr %t107, i64 %t108)
  %t110 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  store { i64, ptr } %t111, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bdafa441ac13699b_f5af7a3548cb73f)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb32
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t17, i64 %t18)
  store i64 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i64, ptr %l16, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = call i64 @compiler_2ffree_2eokind(i64 %t23)
  store i64 %t25, ptr %l18
  br label %bb8
bb8:
  %t26 = load i64, ptr %l18, !tbaa !24
  store i64 %t26, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l6, !tbaa !24
  %t28 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t31 = icmp eq i64 %t27, %t28
  br i1 %t31, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb11
bb10:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t37 = icmp eq i64 %t33, %t34
  store i1 %t37, ptr %l22, !tbaa !21
  br label %bb11
bb11:
  %t39 = load i1, ptr %l22, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l27, !tbaa !29
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @compiler_2ffree_2eoval(i64 %t41)
  store i64 %t43, ptr %l29
  br label %bb14
bb13:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb21
bb14:
  %t44 = load ptr, ptr %l27, !tbaa !29
  %t45 = load i64, ptr %l29, !tbaa !24
  %t46 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t44, i64 %t45)
  store i1 %t46, ptr %l30
  br label %bb15
bb15:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb20
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 12
  store ptr %t50, ptr %l33, !tbaa !29
  %t51 = load i64, ptr %l5, !tbaa !24
  %t53 = call i64 @compiler_2ffree_2eoval(i64 %t51)
  store i64 %t53, ptr %l35
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t55 = load i64, ptr %l35, !tbaa !24
  %t56 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t54, i64 %t55)
  store i1 %t56, ptr %l36
  br label %bb19
bb19:
  %t57 = load i1, ptr %l36, !tbaa !21
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l31, !tbaa !21
  store i1 %t58, ptr %l26, !tbaa !21
  br label %bb21
bb21:
  %t59 = load i1, ptr %l26, !tbaa !21
  br i1 %t59, label %bb22, label %bb23
bb22:
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t60 = load ptr, ptr %lp2
  store ptr %t60, ptr %l37, !tbaa !29
  %t61 = load i64, ptr %l6, !tbaa !24
  %t62 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t65 = icmp eq i64 %t61, %t62
  br i1 %t65, label %bb25, label %bb26
bb25:
  %t67 = load i64, ptr @G_2ecompiler_2ffree_2eOParC, !tbaa !24
  store i64 %t67, ptr %l42, !tbaa !24
  %t68 = load i64, ptr %l5, !tbaa !24
  %t70 = call i64 @compiler_2ffree_2eoval(i64 %t68)
  store i64 %t70, ptr %l44
  br label %bb27
bb26:
  %t71 = load i64, ptr %l5, !tbaa !24
  store i64 %t71, ptr %l41, !tbaa !24
  br label %bb29
bb27:
  %t73 = load i64, ptr %l42, !tbaa !24
  %t74 = load i64, ptr %l44, !tbaa !24
  %t75 = call i64 @compiler_2ffree_2eorig(i64 %t73, i64 %t74)
  store i64 %t75, ptr %l45
  br label %bb28
bb28:
  %t76 = load i64, ptr %l45, !tbaa !24
  store i64 %t76, ptr %l41, !tbaa !24
  br label %bb29
bb29:
  %t77 = load ptr, ptr %l37, !tbaa !29
  %t78 = load i64, ptr %l41, !tbaa !24
  %t79 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t77, i64 %t78)
  store i64 %t79, ptr %l47
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t80 = load i64, ptr %l4, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l4, !tbaa !24
  br label %bb2
bb32:
  %t84 = load ptr, ptr %lp2
  %t85 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [1 x i64] }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i64
  %l58 = alloca i64
  %l61 = alloca i1
  %l68 = alloca { i64, [1 x i64] }
  %l70 = alloca { i64, [1 x i64] }
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, [1 x i64] }
  %l82 = alloca { i64, [1 x i64] }
  %l84 = alloca i1
  %l86 = alloca i64
  %l94 = alloca { i64, ptr }
  %l98 = alloca i1
  %l100 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [1 x i64] } %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp sge i64 %t5, 63
  store i1 %t7, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l18, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 3
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l25
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l25, !tbaa !29
  store ptr %t18, ptr %l6, !tbaa !29
  %t19 = load i64, ptr %l5, !tbaa !24
  store i64 %t19, ptr %l26, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = load i64, ptr %l26, !tbaa !24
  %t22 = shl i64 1, %t21
  store i64 %t22, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/typed:Call", ptr %t24, i32 0, i32 1
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t31 = load i64, ptr %l9, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load i64, ptr %l10, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb13
bb10:
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = load i64, ptr %l8, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l10, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l37, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb12
bb12:
  %t57 = load i64, ptr %l37, !tbaa !24
  store i64 %t57, ptr %l34, !tbaa !24
  br label %bb13
bb13:
  %t58 = load i64, ptr %l34, !tbaa !24
  store i64 %t58, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb14
bb14:
  %t59 = load i64, ptr %l12, !tbaa !24
  %t60 = load i64, ptr %l11, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb36
bb16:
  br label %bb17
bb17:
  %t67 = load i64, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l12, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l13, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l3, !tbaa !24
  %t79 = load i64, ptr %l13, !tbaa !24
  %t83 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t77, i64 %t78, i64 %t79)
  store i64 %t83, ptr %l58
  br label %bb18
bb18:
  %t84 = load i64, ptr %l58, !tbaa !24
  store i64 %t84, ptr %l14, !tbaa !24
  %t85 = load i64, ptr %l14, !tbaa !24
  %t87 = icmp slt i64 %t85, 0
  br i1 %t87, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l61, !tbaa !21
  br label %bb21
bb20:
  %t89 = load i64, ptr %l14, !tbaa !24
  %t91 = icmp sge i64 %t89, 63
  store i1 %t91, ptr %l61, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l61, !tbaa !21
  br i1 %t93, label %bb22, label %bb23
bb22:
  br label %bb35
bb23:
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l6, !tbaa !29
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/typed:Call", ptr %t95, i32 0, i32 2
  %t98 = load i32, ptr %t97, !tbaa !23
  %t99 = load i64, ptr %l14, !tbaa !24
  %t103 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t94, i32 %t98, i64 %t99)
  store { i64, [1 x i64] } %t103, ptr %l68
  br label %bb25
bb25:
  %t104 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t104, ptr %l70
  %t107 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l68, ptr %l70)
  store i1 %t107, ptr %l72
  br label %bb26
bb26:
  %t108 = load i1, ptr %l72, !tbaa !21
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i64, ptr %l1, !tbaa !24
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Call", ptr %t111, i32 0, i32 1
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  store { i64, ptr } %t114, ptr %l77, !tbaa !27
  %t115 = load i64, ptr %l13, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr ptr, ptr %t118, i64 %t115
  %t120 = load ptr, ptr %t119, !tbaa !39
  %t124 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %t109, i64 %t110, ptr %t120)
  store { i64, [1 x i64] } %t124, ptr %l80
  br label %bb29
bb28:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb31
bb29:
  %t125 = load { i64, [1 x i64] }, ptr %l4
  store { i64, [1 x i64] } %t125, ptr %l82
  %t128 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l80, ptr %l82)
  store i1 %t128, ptr %l84
  br label %bb30
bb30:
  %t129 = load i1, ptr %l84, !tbaa !21
  store i1 %t129, ptr %l73, !tbaa !21
  br label %bb31
bb31:
  %t130 = load i1, ptr %l73, !tbaa !21
  br i1 %t130, label %bb32, label %bb33
bb32:
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load i64, ptr %l14, !tbaa !24
  store i64 %t132, ptr %l86, !tbaa !24
  %t133 = load i64, ptr %l86, !tbaa !24
  %t134 = load i64, ptr %l86, !tbaa !24
  %t135 = shl i64 1, %t134
  %t138 = or i64 %t131, %t135
  store i64 %t138, ptr %l7, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t140 = load i64, ptr %l12, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l12, !tbaa !24
  br label %bb14
bb36:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/free:Free", ptr %t144, i32 0, i32 2
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load i64, ptr %l3, !tbaa !24
  %t151 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %s0, ptr %t147, i64 %t148)
  store { i64, ptr } %t151, ptr %l94
  br label %bb37
bb37:
  %t152 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t152, ptr %l15, !tbaa !27
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t155 = load i64, ptr %l7, !tbaa !24
  %t159 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t153, { i64, ptr } %t154, i64 %t155)
  store i1 %t159, ptr %l98
  br label %bb38
bb38:
  %t160 = load i1, ptr %l98, !tbaa !21
  br i1 %t160, label %bb39, label %bb40
bb39:
  %t161 = load i64, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t161, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t163 = load i64, ptr %l5, !tbaa !24
  store i64 %t163, ptr %l100, !tbaa !24
  %t164 = load i64, ptr %l100, !tbaa !24
  %t165 = load i64, ptr %l100, !tbaa !24
  %t166 = shl i64 1, %t165
  store i64 %t166, ptr %l7, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t170 = load i64, ptr %l7, !tbaa !24
  %t174 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %s0, ptr %t168, { i64, ptr } %t169, i64 %t170)
  store i1 %t174, ptr %l105
  br label %bb42
bb42:
  %t175 = load i1, ptr %l105, !tbaa !21
  br i1 %t175, label %bb43, label %bb44
bb43:
  %t176 = load i64, ptr %l7, !tbaa !24
  store i64 %t176, ptr %l106, !tbaa !24
  br label %bb45
bb44:
  store i64 -1, ptr %l106, !tbaa !24
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t178 = load i64, ptr %l106, !tbaa !24
  store i64 %t178, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l13, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i1, ptr %l16, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t13, ptr %l19, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l20, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = mul i64 %t25, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %t24, i64 %t26, i1 false)
  %t27 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t27, ptr %l19, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l23, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l26
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l27
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i32, ptr %l27, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l28
  br label %bb8
bb8:
  %t42 = load i32, ptr %l28, !tbaa !23
  store i32 %t42, ptr %l3, !tbaa !23
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l31
  br label %bb9
bb9:
  %t48 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t50 = trunc i64 18 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb13
bb11:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load i1, ptr %l38, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l35, !tbaa !21
  br label %bb13
bb13:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb18
bb15:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l41, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l44
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i32, ptr %l44, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l45
  br label %bb17
bb17:
  %t73 = load i32, ptr %l45, !range !{i32 0, i32 6}
  %t75 = trunc i64 1 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l51, !tbaa !24
  %t84 = load i64, ptr %l51, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l52, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l51, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l53, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l56
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l53, !tbaa !29
  %t104 = load i32, ptr %l56, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l57
  br label %bb23
bb23:
  %t106 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t106, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l6, !tbaa !24
  br label %bb24
bb24:
  %t111 = load i64, ptr %l5, !tbaa !24
  %t112 = load i64, ptr %l6, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb25, label %bb26
bb25:
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t119, ptr %l64, !tbaa !27
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t127 = load ptr, ptr %l2, !tbaa !29
  store ptr %t127, ptr %l67, !tbaa !29
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t128, i32 %t125)
  store i32 %t132, ptr %l70
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l67, !tbaa !29
  %t134 = load i32, ptr %l70, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l71
  br label %bb29
bb29:
  %t136 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t136, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l10, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb31, label %bb32
bb31:
  br label %bb45
bb32:
  br label %bb33
bb33:
  %t149 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t149, ptr %l78, !tbaa !27
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  store i32 %t155, ptr %l11, !tbaa !23
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t158 = load i32, ptr %l11, !tbaa !23
  %t161 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t161, ptr %l83
  br label %bb34
bb34:
  %t162 = load i1, ptr %l83, !tbaa !21
  br i1 %t162, label %bb35, label %bb36
bb35:
  %t163 = load ptr, ptr %l2, !tbaa !29
  store ptr %t163, ptr %l85, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l86, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t166 = load i32, ptr %l11, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l89
  br label %bb37
bb36:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb40
bb37:
  %t170 = load ptr, ptr %l86, !tbaa !29
  %t171 = load i32, ptr %l89, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t172, ptr %l90
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l85, !tbaa !29
  %t174 = load i32, ptr %l90, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t175, ptr %l91
  br label %bb39
bb39:
  %t176 = load i32, ptr %l3, !tbaa !23
  %t177 = load i32, ptr %l91, !tbaa !23
  %t179 = icmp eq i32 %t177, %t176
  store i1 %t179, ptr %l84, !tbaa !21
  br label %bb40
bb40:
  %t181 = load i1, ptr %l84, !tbaa !21
  br i1 %t181, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t182, ptr %l95, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l96, !tbaa !24
  %t185 = load i64, ptr %l96, !tbaa !24
  %t186 = mul i64 %t185, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t186)
  %t188 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l97, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l96, !tbaa !24
  %t195 = mul i64 %t194, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t191, ptr %t193, i64 %t195, i1 false)
  %t196 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t196, ptr %l95, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t197, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t198 = load i64, ptr %l9, !tbaa !24
  %t200 = add i64 %t198, 1
  store i64 %t200, ptr %l9, !tbaa !24
  br label %bb30
bb45:
  br label %bb46
bb46:
  %t202 = load i64, ptr %l5, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l5, !tbaa !24
  br label %bb24
bb47:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %l102, !tbaa !27
  %t206 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t206, ptr %l103, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  store i64 %t208, ptr %l104, !tbaa !24
  %t209 = load i64, ptr %l104, !tbaa !24
  %t210 = mul i64 %t209, 1
  %t211 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t210)
  %t212 = insertvalue { i64, ptr } undef, i64 %t209, 0
  %t213 = insertvalue { i64, ptr } %t212, ptr %t211, 1
  store { i64, ptr } %t213, ptr %l105, !tbaa !27
  %t214 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = load i64, ptr %l104, !tbaa !24
  %t219 = mul i64 %t218, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t215, ptr %t217, i64 %t219, i1 false)
  %t220 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t220, ptr %l103, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t221, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l57 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = load i64, ptr %l18, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = load i32, ptr %l3, !tbaa !23
  %t29 = sext i32 %t27 to i64
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t29)
  store i64 %t32, ptr %l24
  br label %bb9
bb8:
  %t33 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t33, ptr %l20, !tbaa !24
  br label %bb10
bb9:
  %t35 = load i64, ptr %l24, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  br label %bb10
bb10:
  %t36 = load i64, ptr %l20, !tbaa !24
  store i64 %t36, ptr %l8, !tbaa !24
  br label %bb44
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  store ptr %t37, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %t41, !range !{i64 0, i64 8}
  %t44 = icmp eq i64 %t42, 3
  store i1 %t44, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t45 = load i1, ptr %l27, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t48 = getelementptr { i64, [4 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l4, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t58 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t52, ptr %t53, ptr %t54)
  store i64 %t58, ptr %l35
  br label %bb17
bb17:
  %t59 = load i64, ptr %l35, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  br label %bb44
bb18:
  %t60 = load ptr, ptr %l2, !tbaa !29
  store ptr %t60, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 8}
  %t67 = icmp eq i64 %t65, 4
  store i1 %t67, ptr %l37, !tbaa !21
  br label %bb20
bb20:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load ptr, ptr %l5, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Elem", ptr %t77, i32 0, i32 0
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t84 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t75, ptr %t76, ptr %t80)
  store i64 %t84, ptr %l46
  br label %bb24
bb24:
  %t85 = load i64, ptr %l46, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb44
bb25:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t87 = load ptr, ptr %l47, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t90 = load ptr, ptr %l47, !tbaa !29
  %t91 = load i64, ptr %t90, !range !{i64 0, i64 8}
  %t93 = icmp eq i64 %t91, 5
  store i1 %t93, ptr %l48, !tbaa !21
  br label %bb27
bb27:
  %t94 = load i1, ptr %l48, !tbaa !21
  br i1 %t94, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l6, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Payload", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t110 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinPl(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  store i64 %t110, ptr %l57
  br label %bb31
bb31:
  %t111 = load i64, ptr %l57, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb44
bb32:
  %t112 = load ptr, ptr %l2, !tbaa !29
  store ptr %t112, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t113 = load ptr, ptr %l58, !tbaa !29
  %t114 = icmp ne ptr %t113, null
  br i1 %t114, label %bb33, label %bb34
bb33:
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load i64, ptr %t116, !range !{i64 0, i64 8}
  %t119 = icmp eq i64 %t117, 2
  store i1 %t119, ptr %l59, !tbaa !21
  br label %bb34
bb34:
  %t120 = load i1, ptr %l59, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t123 = getelementptr { i64, [4 x i64] }, ptr %t121, i32 0, i32 1
  %t124 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t123, i32 0, i32 2
  %t125 = load ptr, ptr %t124
  store ptr %t125, ptr %l7, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load ptr, ptr %l7, !tbaa !29
  %t133 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t127, ptr %t128, ptr %t129)
  store i64 %t133, ptr %l67
  br label %bb38
bb38:
  %t134 = load i64, ptr %l67, !tbaa !24
  store i64 %t134, ptr %l8, !tbaa !24
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t135 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t135, ptr %l8, !tbaa !24
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6cb79447255537d7_e828faabaec907d3)
  unreachable
bb44:
  %t137 = load i64, ptr %l8, !tbaa !24
  store i64 %t137, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewritePlans(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/free:store"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca %"compiler/free:orStore"
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, [1 x i64] }
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca %"compiler/free:orCall"
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca { i64, [1 x i64] }
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca %"compiler/free:store"
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l69 = alloca i64
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l84 = alloca { i64, [1 x i64] }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca %"compiler/free:orStore"
  %l115 = alloca i1
  %l119 = alloca i64
  %l125 = alloca ptr
  %l129 = alloca { i64, [1 x i64] }
  %l131 = alloca i1
  %l133 = alloca i1
  %l135 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l180 = alloca i64
  %l182 = alloca i64
  %l187 = alloca %"compiler/free:orCall"
  %l191 = alloca i1
  %l196 = alloca ptr
  %l198 = alloca { i64, ptr }
  %l205 = alloca i64
  %l214 = alloca { i64, [1 x i64] }
  %l216 = alloca i1
  %l221 = alloca ptr
  %l230 = alloca i64
  %l234 = alloca { i64, ptr }
  %l237 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l248 = alloca i64
  %l251 = alloca i64
  %l270 = alloca i64
  %l287 = alloca i64
  %l290 = alloca i64
  %l311 = alloca i64
  %l314 = alloca i1
  %l317 = alloca i1
  %l319 = alloca i64
  %l323 = alloca i1
  %l328 = alloca { i64, ptr }
  %l333 = alloca i64
  %l336 = alloca i1
  %l338 = alloca { i64, ptr }
  %l343 = alloca { i64, ptr }
  %t545 = alloca { i64, [1 x i64] }, align 8
  %t691 = alloca { i64, [1 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 42
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l42, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l44
  br label %bb2
bb2:
  %t9 = load i64, ptr %l42, !tbaa !24
  %t10 = load i64, ptr %l44, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb35
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/free:store" %t19, ptr %l49
  br label %bb6
bb6:
  %t20 = load %"compiler/free:store", ptr %l49
  store %"compiler/free:store" %t20, ptr %l3
  %t21 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t26 = icmp ne i64 %t22, %t23
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb34
bb8:
  br label %bb9
bb9:
  %t28 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 49
  %t37 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t33, i64 %t29)
  store i1 %t37, ptr %l57
  br label %bb10
bb10:
  %t38 = load i1, ptr %l57, !tbaa !21
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 21
  %t42 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t41, i64 %t43)
  store i1 %t46, ptr %l62
  br label %bb13
bb12:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb14
bb13:
  %t47 = load i1, ptr %l62, !tbaa !21
  store i1 %t47, ptr %l58, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l58, !tbaa !21
  %t49 = xor i1 %t48, true
  br i1 %t49, label %bb15, label %bb16
bb15:
  br label %bb34
bb16:
  br label %bb17
bb17:
  %t51 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 7
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = icmp eq ptr %t52, null
  br i1 %t54, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_b0d58e2b07420cd2_669637d27520b416)
  unreachable
bb19:
  br label %bb20
bb20:
  %t56 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 7
  %t57 = load ptr, ptr %t56, !tbaa !29
  store ptr %t57, ptr %l5, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t63 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t59, ptr %t60)
  store i64 %t63, ptr %l69
  br label %bb21
bb21:
  %t64 = load i64, ptr %l69, !tbaa !24
  store i64 %t64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l6, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  br i1 %t67, label %bb22, label %bb23
bb22:
  br label %bb34
bb23:
  br label %bb24
bb24:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:Free", ptr %t69, i32 0, i32 3
  %t72 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t76 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t71, i64 %t73)
  store ptr %t76, ptr %l75
  br label %bb25
bb25:
  %t77 = load ptr, ptr %l75, !tbaa !29
  store ptr %t77, ptr %l7, !tbaa !29
  %t78 = load ptr, ptr %l7, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Plan", ptr %t78, i32 0, i32 5
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l77, !tbaa !27
  %t82 = load i64, ptr %l6, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t82
  %t87 = load i64, ptr %t86, !tbaa !34
  %t89 = icmp ne i64 %t87, 0
  br i1 %t89, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  %t94 = load ptr, ptr %l5, !tbaa !29
  %t98 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t91, i64 %t93, ptr %t94)
  store { i64, [1 x i64] } %t98, ptr %l84
  br label %bb29
bb29:
  %t99 = load { i64, [1 x i64] }, ptr %l84
  store { i64, [1 x i64] } %t99, ptr %l8
  %t100 = load { i64, [1 x i64] }, ptr %l8
  %t102 = extractvalue { i64, [1 x i64] } %t100, 0
  %t103 = icmp eq i64 %t102, 7
  br i1 %t103, label %bb30, label %bb31
bb30:
  %t105 = getelementptr { i64, [1 x i64] }, ptr %l8, i32 0, i32 1
  %t106 = getelementptr { i64 }, ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %t106
  store i64 %t107, ptr %l9, !tbaa !24
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t109 = load ptr, ptr %l7, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Plan", ptr %t109, i32 0, i32 5
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l89, !tbaa !27
  %t113 = load i64, ptr %l6, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i64, ptr %t116, i64 %t113
  store i64 1, ptr %t117, !tbaa !34
  %t118 = load ptr, ptr %l7, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Plan", ptr %t118, i32 0, i32 6
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l92, !tbaa !27
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load { i64, [1 x i64] }, ptr %l8
  %t126 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, [1 x i64] }, ptr %t127, i64 %t122
  store { i64, [1 x i64] } %t123, ptr %t128
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/free:store", ptr %l3, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  %t132 = load ptr, ptr %l5, !tbaa !29
  %t133 = load i64, ptr %l6, !tbaa !24
  %t134 = load { i64, [1 x i64] }, ptr %l8
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t129, i64 %t131, ptr %t132, i64 %t133, { i64, [1 x i64] } %t134, i1 true, i1 false)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t140 = load i64, ptr %l2, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l2, !tbaa !24
  br label %bb1
bb35:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/free:Free", ptr %t144, i32 0, i32 48
  store ptr %t146, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb36
bb36:
  %t148 = load i64, ptr %l11, !tbaa !24
  store i64 %t148, ptr %l104, !tbaa !24
  %t149 = load ptr, ptr %l10, !tbaa !29
  %t151 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %t149)
  store i64 %t151, ptr %l106
  br label %bb37
bb37:
  %t152 = load i64, ptr %l104, !tbaa !24
  %t153 = load i64, ptr %l106, !tbaa !24
  %t154 = icmp slt i64 %t152, %t153
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb38, label %bb39
bb38:
  br label %bb70
bb39:
  br label %bb40
bb40:
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t159 = load i64, ptr %l11, !tbaa !24
  %t162 = call %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t158, i64 %t159)
  store %"compiler/free:orStore" %t162, ptr %l111
  br label %bb41
bb41:
  %t163 = load %"compiler/free:orStore", ptr %l111
  store %"compiler/free:orStore" %t163, ptr %l12
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/free:Free", ptr %t164, i32 0, i32 49
  %t167 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  %t171 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t166, i64 %t168)
  store i1 %t171, ptr %l115
  br label %bb42
bb42:
  %t172 = load i1, ptr %l115, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb43, label %bb44
bb43:
  br label %bb69
bb44:
  br label %bb45
bb45:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 2
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t180 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t175, ptr %t177)
  store i64 %t180, ptr %l119
  br label %bb46
bb46:
  %t181 = load i64, ptr %l119, !tbaa !24
  store i64 %t181, ptr %l13, !tbaa !24
  %t182 = load i64, ptr %l13, !tbaa !24
  %t184 = icmp slt i64 %t182, 0
  br i1 %t184, label %bb47, label %bb48
bb47:
  br label %bb69
bb48:
  br label %bb49
bb49:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/free:Free", ptr %t186, i32 0, i32 3
  %t189 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 0
  %t190 = load i64, ptr %t189, !tbaa !24
  %t193 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t188, i64 %t190)
  store ptr %t193, ptr %l125
  br label %bb50
bb50:
  %t194 = load ptr, ptr %l125, !tbaa !29
  store ptr %t194, ptr %l14, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 0
  %t197 = load i64, ptr %t196, !tbaa !24
  %t198 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 2
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t203 = call { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t195, i64 %t197, ptr %t199)
  store { i64, [1 x i64] } %t203, ptr %l129
  br label %bb51
bb51:
  %t204 = load { i64, [1 x i64] }, ptr %l129
  store { i64, [1 x i64] } %t204, ptr %l15
  %t205 = load { i64, [1 x i64] }, ptr %l15
  %t207 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t205)
  store i1 %t207, ptr %l131
  br label %bb52
bb52:
  %t208 = load i1, ptr %l131, !tbaa !21
  %t209 = xor i1 %t208, true
  br i1 %t209, label %bb53, label %bb54
bb53:
  %t211 = load ptr, ptr %l14, !tbaa !29
  %t213 = getelementptr %"compiler/typed:Plan", ptr %t211, i32 0, i32 5
  %t214 = load { i64, ptr }, ptr %t213, !tbaa !27
  store { i64, ptr } %t214, ptr %l135, !tbaa !27
  %t215 = load i64, ptr %l13, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr i64, ptr %t218, i64 %t215
  %t220 = load i64, ptr %t219, !tbaa !34
  %t222 = icmp eq i64 %t220, 0
  store i1 %t222, ptr %l133, !tbaa !21
  br label %bb55
bb54:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb55
bb55:
  %t224 = load i1, ptr %l133, !tbaa !21
  br i1 %t224, label %bb56, label %bb57
bb56:
  br label %bb69
bb57:
  br label %bb58
bb58:
  %t225 = load ptr, ptr %l14, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Plan", ptr %t225, i32 0, i32 5
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l140, !tbaa !27
  %t229 = load i64, ptr %l13, !tbaa !24
  %t231 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i64, ptr %t232, i64 %t229
  %t234 = load i64, ptr %t233, !tbaa !34
  %t236 = icmp eq i64 %t234, 1
  br i1 %t236, label %bb59, label %bb60
bb59:
  %t238 = load ptr, ptr %l14, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Plan", ptr %t238, i32 0, i32 7
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  store { i64, ptr } %t241, ptr %l145, !tbaa !27
  %t242 = load i64, ptr %l13, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr ptr, ptr %t245, i64 %t242
  %t247 = load ptr, ptr %t246, !tbaa !39
  %t249 = icmp eq ptr %t247, null
  br i1 %t249, label %bb61, label %bb62
bb60:
  br label %bb64
bb61:
  %t251 = load ptr, ptr %l14, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Plan", ptr %t251, i32 0, i32 7
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l150, !tbaa !27
  %t255 = load i64, ptr %l13, !tbaa !24
  %t256 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 3
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t261 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t255
  store ptr %t257, ptr %t263, !tbaa !39
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %bb69
bb64:
  %t264 = load ptr, ptr %l14, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Plan", ptr %t264, i32 0, i32 5
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  store { i64, ptr } %t267, ptr %l155, !tbaa !27
  %t268 = load i64, ptr %l13, !tbaa !24
  %t270 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !27
  %t272 = getelementptr i64, ptr %t271, i64 %t268
  %t273 = load i64, ptr %t272, !tbaa !34
  %t275 = icmp ne i64 %t273, 0
  br i1 %t275, label %bb65, label %bb66
bb65:
  br label %bb69
bb66:
  br label %bb67
bb67:
  %t277 = load ptr, ptr %l14, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Plan", ptr %t277, i32 0, i32 5
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l160, !tbaa !27
  %t281 = load i64, ptr %l13, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i64, ptr %t284, i64 %t281
  store i64 2, ptr %t285, !tbaa !34
  %t286 = load ptr, ptr %l14, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Plan", ptr %t286, i32 0, i32 6
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  store { i64, ptr } %t289, ptr %l163, !tbaa !27
  %t290 = load i64, ptr %l13, !tbaa !24
  %t291 = load { i64, [1 x i64] }, ptr %l15
  %t294 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t295 = load ptr, ptr %t294, !tbaa !27
  %t296 = getelementptr { i64, [1 x i64] }, ptr %t295, i64 %t290
  store { i64, [1 x i64] } %t291, ptr %t296
  %t297 = load ptr, ptr %l14, !tbaa !29
  %t299 = getelementptr %"compiler/typed:Plan", ptr %t297, i32 0, i32 7
  %t300 = load { i64, ptr }, ptr %t299, !tbaa !27
  store { i64, ptr } %t300, ptr %l167, !tbaa !27
  %t301 = load i64, ptr %l13, !tbaa !24
  %t302 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 3
  %t303 = load ptr, ptr %t302, !tbaa !29
  %t307 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr ptr, ptr %t308, i64 %t301
  store ptr %t303, ptr %t309, !tbaa !39
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 0
  %t312 = load i64, ptr %t311, !tbaa !24
  %t313 = getelementptr %"compiler/free:orStore", ptr %l12, i32 0, i32 2
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t315 = load i64, ptr %l13, !tbaa !24
  %t316 = load { i64, [1 x i64] }, ptr %l15
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t310, i64 %t312, ptr %t314, i64 %t315, { i64, [1 x i64] } %t316, i1 true, i1 false)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t322 = load i64, ptr %l11, !tbaa !24
  %t324 = add i64 %t322, 1
  store i64 %t324, ptr %l11, !tbaa !24
  br label %bb36
bb70:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/free:Free", ptr %t326, i32 0, i32 47
  store ptr %t328, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb71
bb71:
  %t330 = load i64, ptr %l17, !tbaa !24
  store i64 %t330, ptr %l180, !tbaa !24
  %t331 = load ptr, ptr %l16, !tbaa !29
  %t333 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t331)
  store i64 %t333, ptr %l182
  br label %bb72
bb72:
  %t334 = load i64, ptr %l180, !tbaa !24
  %t335 = load i64, ptr %l182, !tbaa !24
  %t336 = icmp slt i64 %t334, %t335
  %t338 = xor i1 %t336, true
  br i1 %t338, label %bb73, label %bb74
bb73:
  br label %bb152
bb74:
  br label %bb75
bb75:
  %t340 = load ptr, ptr %l16, !tbaa !29
  %t341 = load i64, ptr %l17, !tbaa !24
  %t344 = call %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t340, i64 %t341)
  store %"compiler/free:orCall" %t344, ptr %l187
  br label %bb76
bb76:
  %t345 = load %"compiler/free:orCall", ptr %l187
  store %"compiler/free:orCall" %t345, ptr %l18
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/free:Free", ptr %t346, i32 0, i32 49
  %t349 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 4
  %t350 = load i64, ptr %t349, !tbaa !24
  %t353 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t348, i64 %t350)
  store i1 %t353, ptr %l191
  br label %bb77
bb77:
  %t354 = load i1, ptr %l191, !tbaa !21
  %t355 = xor i1 %t354, true
  br i1 %t355, label %bb78, label %bb79
bb78:
  br label %bb151
bb79:
  br label %bb80
bb80:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/free:Free", ptr %t357, i32 0, i32 3
  %t360 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 0
  %t361 = load i64, ptr %t360, !tbaa !24
  %t364 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t359, i64 %t361)
  store ptr %t364, ptr %l196
  br label %bb81
bb81:
  %t365 = load ptr, ptr %l196, !tbaa !29
  store ptr %t365, ptr %l19, !tbaa !29
  %t366 = load ptr, ptr %l19, !tbaa !29
  %t368 = getelementptr %"compiler/typed:Plan", ptr %t366, i32 0, i32 5
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !27
  store { i64, ptr } %t369, ptr %l198, !tbaa !27
  %t370 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 1
  %t371 = load i64, ptr %t370, !tbaa !24
  %t373 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr i64, ptr %t374, i64 %t371
  %t376 = load i64, ptr %t375, !tbaa !34
  %t378 = icmp ne i64 %t376, 0
  br i1 %t378, label %bb82, label %bb83
bb82:
  br label %bb151
bb83:
  br label %bb84
bb84:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t381 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 2
  %t382 = load i64, ptr %t381, !tbaa !24
  %t383 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 3
  %t384 = load i64, ptr %t383, !tbaa !24
  %t388 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t380, i64 %t382, i64 %t384)
  store i64 %t388, ptr %l205
  br label %bb85
bb85:
  %t389 = load i64, ptr %l205, !tbaa !24
  store i64 %t389, ptr %l20, !tbaa !24
  %t390 = load i64, ptr %l20, !tbaa !24
  %t392 = icmp slt i64 %t390, 0
  br i1 %t392, label %bb86, label %bb87
bb86:
  br label %bb151
bb87:
  br label %bb88
bb88:
  %t394 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 1
  %t395 = load i64, ptr %t394, !tbaa !24
  %t397 = trunc i64 %t395 to i32
  store i32 %t397, ptr %l21, !tbaa !23
  %t400 = load ptr, ptr %l19, !tbaa !29
  %t401 = load i32, ptr %l21, !tbaa !23
  %t402 = load i64, ptr %l20, !tbaa !24
  %t406 = call { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t400, i32 %t401, i64 %t402)
  store { i64, [1 x i64] } %t406, ptr %l214
  br label %bb89
bb89:
  %t407 = load { i64, [1 x i64] }, ptr %l214
  store { i64, [1 x i64] } %t407, ptr %l22
  %t408 = load { i64, [1 x i64] }, ptr %l22
  %t410 = call i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %t408)
  store i1 %t410, ptr %l216
  br label %bb90
bb90:
  %t411 = load i1, ptr %l216, !tbaa !21
  %t412 = xor i1 %t411, true
  br i1 %t412, label %bb91, label %bb92
bb91:
  br label %bb151
bb92:
  br label %bb93
bb93:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 0
  %t416 = load i64, ptr %t415, !tbaa !24
  %t417 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 1
  %t418 = load i64, ptr %t417, !tbaa !24
  %t422 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v0, ptr %t414, i64 %t416, i64 %t418)
  store ptr %t422, ptr %l221
  br label %bb94
bb94:
  %t423 = load ptr, ptr %l221, !tbaa !29
  store ptr %t423, ptr %l23, !tbaa !29
  %t424 = load ptr, ptr %l23, !tbaa !29
  %t426 = icmp eq ptr %t424, null
  br i1 %t426, label %bb95, label %bb96
bb95:
  br label %bb151
bb96:
  br label %bb97
bb97:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 0
  %t430 = load i64, ptr %t429, !tbaa !24
  %t431 = load ptr, ptr %l23, !tbaa !29
  %t432 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 2
  %t433 = load i64, ptr %t432, !tbaa !24
  %t434 = load { i64, [1 x i64] }, ptr %l22
  %t435 = load i64, ptr %l20, !tbaa !24
  %t442 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t428, i64 %t430, ptr %t431, i64 %t433, { i64, [1 x i64] } %t434, i64 %t435)
  store i64 %t442, ptr %l230
  br label %bb98
bb98:
  %t443 = load i64, ptr %l230, !tbaa !24
  store i64 %t443, ptr %l24, !tbaa !24
  %t444 = load i64, ptr %l24, !tbaa !24
  %t446 = icmp slt i64 %t444, 0
  br i1 %t446, label %bb99, label %bb100
bb99:
  br label %bb151
bb100:
  br label %bb101
bb101:
  %t448 = load ptr, ptr %l19, !tbaa !29
  %t450 = getelementptr %"compiler/typed:Plan", ptr %t448, i32 0, i32 5
  %t451 = load { i64, ptr }, ptr %t450, !tbaa !27
  store { i64, ptr } %t451, ptr %l234, !tbaa !27
  %t452 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 1
  %t453 = load i64, ptr %t452, !tbaa !24
  %t455 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !27
  %t457 = getelementptr i64, ptr %t456, i64 %t453
  store i64 2, ptr %t457, !tbaa !34
  %t458 = load ptr, ptr %l19, !tbaa !29
  %t460 = getelementptr %"compiler/typed:Plan", ptr %t458, i32 0, i32 6
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !27
  store { i64, ptr } %t461, ptr %l237, !tbaa !27
  %t462 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 1
  %t463 = load i64, ptr %t462, !tbaa !24
  %t464 = load { i64, [1 x i64] }, ptr %l22
  %t467 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr { i64, [1 x i64] }, ptr %t468, i64 %t463
  store { i64, [1 x i64] } %t464, ptr %t469
  %t470 = load ptr, ptr %l19, !tbaa !29
  %t472 = getelementptr %"compiler/typed:Plan", ptr %t470, i32 0, i32 7
  %t473 = load { i64, ptr }, ptr %t472, !tbaa !27
  store { i64, ptr } %t473, ptr %l241, !tbaa !27
  %t474 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 1
  %t475 = load i64, ptr %t474, !tbaa !24
  %t476 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 5
  %t477 = load ptr, ptr %t476, !tbaa !29
  %t481 = getelementptr { i64, ptr }, ptr %l241, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = getelementptr ptr, ptr %t482, i64 %t475
  store ptr %t477, ptr %t483, !tbaa !39
  store i64 0, ptr %l25, !tbaa !24
  store i64 63, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t484 = load i64, ptr %l26, !tbaa !24
  %t485 = load i64, ptr %l25, !tbaa !24
  %t488 = icmp sgt i64 %t484, %t485
  br i1 %t488, label %bb102, label %bb103
bb102:
  %t490 = load i64, ptr %l27, !tbaa !24
  %t492 = icmp sgt i64 %t490, 0
  br i1 %t492, label %bb104, label %bb105
bb103:
  store i64 0, ptr %l248, !tbaa !24
  br label %bb107
bb104:
  %t494 = load i64, ptr %l26, !tbaa !24
  %t495 = load i64, ptr %l25, !tbaa !24
  %t498 = sub i64 %t494, %t495
  %t499 = load i64, ptr %l27, !tbaa !24
  %t502 = add i64 %t498, %t499
  %t504 = sub i64 %t502, 1
  %t505 = load i64, ptr %l27, !tbaa !24
  %t508 = sdiv i64 %t504, %t505
  store i64 %t508, ptr %l251, !tbaa !24
  br label %bb106
bb105:
  store i64 0, ptr %l251, !tbaa !24
  br label %bb106
bb106:
  %t510 = load i64, ptr %l251, !tbaa !24
  store i64 %t510, ptr %l248, !tbaa !24
  br label %bb107
bb107:
  %t511 = load i64, ptr %l248, !tbaa !24
  store i64 %t511, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb108
bb108:
  %t512 = load i64, ptr %l29, !tbaa !24
  %t513 = load i64, ptr %l28, !tbaa !24
  %t516 = icmp slt i64 %t512, %t513
  %t518 = xor i1 %t516, true
  br i1 %t518, label %bb109, label %bb110
bb109:
  br label %bb117
bb110:
  br label %bb111
bb111:
  %t520 = load i64, ptr %l25, !tbaa !24
  %t521 = load i64, ptr %l29, !tbaa !24
  %t522 = load i64, ptr %l27, !tbaa !24
  %t525 = mul i64 %t521, %t522
  %t528 = add i64 %t520, %t525
  store i64 %t528, ptr %l30, !tbaa !24
  %t530 = load i64, ptr %l24, !tbaa !24
  %t531 = load i64, ptr %l30, !tbaa !24
  store i64 %t531, ptr %l270, !tbaa !24
  %t532 = load i64, ptr %l270, !tbaa !24
  %t533 = load i64, ptr %l270, !tbaa !24
  %t534 = shl i64 1, %t533
  %t537 = and i64 %t530, %t534
  %t539 = icmp ne i64 %t537, 0
  br i1 %t539, label %bb112, label %bb113
bb112:
  %t541 = load ptr, ptr %l19, !tbaa !29
  %t542 = load i32, ptr %l21, !tbaa !23
  %t543 = load i64, ptr %l30, !tbaa !24
  %t544 = load i32, ptr %l21, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t545
  %t546 = getelementptr { i64, [1 x i64] }, ptr %t545, i32 0, i32 0
  store i64 4, ptr %t546
  %t548 = insertvalue { i32 } undef, i32 %t544, 0
  %t549 = getelementptr { i64, [1 x i64] }, ptr %t545, i32 0, i32 1
  store { i32 } %t548, ptr %t549
  %t550 = load { i64, [1 x i64] }, ptr %t545
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %t541, i32 %t542, i64 %t543, { i64, [1 x i64] } %t550)
  br label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb115
bb115:
  br label %bb116
bb116:
  %t555 = load i64, ptr %l29, !tbaa !24
  %t557 = add i64 %t555, 1
  store i64 %t557, ptr %l29, !tbaa !24
  br label %bb108
bb117:
  store i64 0, ptr %l31, !tbaa !24
  %t559 = load ptr, ptr %l23, !tbaa !29
  %t561 = getelementptr %"compiler/typed:Call", ptr %t559, i32 0, i32 1
  %t562 = load { i64, ptr }, ptr %t561, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t562, 0
  store i64 %t564, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t566 = load i64, ptr %l32, !tbaa !24
  %t567 = load i64, ptr %l31, !tbaa !24
  %t570 = icmp sgt i64 %t566, %t567
  br i1 %t570, label %bb118, label %bb119
bb118:
  %t572 = load i64, ptr %l33, !tbaa !24
  %t574 = icmp sgt i64 %t572, 0
  br i1 %t574, label %bb120, label %bb121
bb119:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb123
bb120:
  %t576 = load i64, ptr %l32, !tbaa !24
  %t577 = load i64, ptr %l31, !tbaa !24
  %t580 = sub i64 %t576, %t577
  %t581 = load i64, ptr %l33, !tbaa !24
  %t584 = add i64 %t580, %t581
  %t586 = sub i64 %t584, 1
  %t587 = load i64, ptr %l33, !tbaa !24
  %t590 = sdiv i64 %t586, %t587
  store i64 %t590, ptr %l290, !tbaa !24
  br label %bb122
bb121:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb122
bb122:
  %t592 = load i64, ptr %l290, !tbaa !24
  store i64 %t592, ptr %l287, !tbaa !24
  br label %bb123
bb123:
  %t593 = load i64, ptr %l287, !tbaa !24
  store i64 %t593, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb124
bb124:
  %t594 = load i64, ptr %l35, !tbaa !24
  %t595 = load i64, ptr %l34, !tbaa !24
  %t598 = icmp slt i64 %t594, %t595
  %t600 = xor i1 %t598, true
  br i1 %t600, label %bb125, label %bb126
bb125:
  br label %bb150
bb126:
  br label %bb127
bb127:
  %t602 = load i64, ptr %l31, !tbaa !24
  %t603 = load i64, ptr %l35, !tbaa !24
  %t604 = load i64, ptr %l33, !tbaa !24
  %t607 = mul i64 %t603, %t604
  %t610 = add i64 %t602, %t607
  store i64 %t610, ptr %l36, !tbaa !24
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 2
  %t614 = load i64, ptr %t613, !tbaa !24
  %t615 = load i64, ptr %l36, !tbaa !24
  %t619 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t612, i64 %t614, i64 %t615)
  store i64 %t619, ptr %l311
  br label %bb128
bb128:
  %t620 = load i64, ptr %l311, !tbaa !24
  store i64 %t620, ptr %l37, !tbaa !24
  %t621 = load i64, ptr %l37, !tbaa !24
  %t623 = icmp slt i64 %t621, 0
  br i1 %t623, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l314, !tbaa !21
  br label %bb131
bb130:
  %t625 = load i64, ptr %l37, !tbaa !24
  %t627 = icmp sge i64 %t625, 63
  store i1 %t627, ptr %l314, !tbaa !21
  br label %bb131
bb131:
  %t629 = load i1, ptr %l314, !tbaa !21
  br i1 %t629, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l317, !tbaa !21
  br label %bb134
bb133:
  %t630 = load i64, ptr %l24, !tbaa !24
  %t631 = load i64, ptr %l37, !tbaa !24
  store i64 %t631, ptr %l319, !tbaa !24
  %t632 = load i64, ptr %l319, !tbaa !24
  %t633 = load i64, ptr %l319, !tbaa !24
  %t634 = shl i64 1, %t633
  %t637 = and i64 %t630, %t634
  %t639 = icmp eq i64 %t637, 0
  store i1 %t639, ptr %l317, !tbaa !21
  br label %bb134
bb134:
  %t641 = load i1, ptr %l317, !tbaa !21
  br i1 %t641, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l323, !tbaa !21
  br label %bb137
bb136:
  %t642 = load i64, ptr %l36, !tbaa !24
  %t643 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 3
  %t644 = load i64, ptr %t643, !tbaa !24
  %t647 = icmp eq i64 %t642, %t644
  store i1 %t647, ptr %l323, !tbaa !21
  br label %bb137
bb137:
  %t649 = load i1, ptr %l323, !tbaa !21
  br i1 %t649, label %bb138, label %bb139
bb138:
  br label %bb149
bb139:
  br label %bb140
bb140:
  %t650 = load ptr, ptr %l23, !tbaa !29
  %t652 = getelementptr %"compiler/typed:Call", ptr %t650, i32 0, i32 1
  %t653 = load { i64, ptr }, ptr %t652, !tbaa !27
  store { i64, ptr } %t653, ptr %l328, !tbaa !27
  %t654 = load i64, ptr %l36, !tbaa !24
  %t656 = getelementptr { i64, ptr }, ptr %l328, i32 0, i32 1
  %t657 = load ptr, ptr %t656, !tbaa !27
  %t658 = getelementptr ptr, ptr %t657, i64 %t654
  %t659 = load ptr, ptr %t658, !tbaa !39
  store ptr %t659, ptr %l38, !tbaa !29
  %t661 = load ptr, ptr %l0, !tbaa !29
  %t662 = load ptr, ptr %l38, !tbaa !29
  %t665 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t661, ptr %t662)
  store i64 %t665, ptr %l333
  br label %bb141
bb141:
  %t666 = load i64, ptr %l333, !tbaa !24
  store i64 %t666, ptr %l39, !tbaa !24
  %t667 = load i64, ptr %l39, !tbaa !24
  %t669 = icmp sge i64 %t667, 0
  br i1 %t669, label %bb142, label %bb143
bb142:
  %t671 = load ptr, ptr %l19, !tbaa !29
  %t673 = getelementptr %"compiler/typed:Plan", ptr %t671, i32 0, i32 5
  %t674 = load { i64, ptr }, ptr %t673, !tbaa !27
  store { i64, ptr } %t674, ptr %l338, !tbaa !27
  %t675 = load i64, ptr %l39, !tbaa !24
  %t677 = getelementptr { i64, ptr }, ptr %l338, i32 0, i32 1
  %t678 = load ptr, ptr %t677, !tbaa !27
  %t679 = getelementptr i64, ptr %t678, i64 %t675
  %t680 = load i64, ptr %t679, !tbaa !34
  %t682 = icmp eq i64 %t680, 1
  store i1 %t682, ptr %l336, !tbaa !21
  br label %bb144
bb143:
  store i1 false, ptr %l336, !tbaa !21
  br label %bb144
bb144:
  %t684 = load i1, ptr %l336, !tbaa !21
  br i1 %t684, label %bb145, label %bb146
bb145:
  %t685 = load ptr, ptr %l19, !tbaa !29
  %t687 = getelementptr %"compiler/typed:Plan", ptr %t685, i32 0, i32 6
  %t688 = load { i64, ptr }, ptr %t687, !tbaa !27
  store { i64, ptr } %t688, ptr %l343, !tbaa !27
  %t689 = load i64, ptr %l39, !tbaa !24
  %t690 = load i32, ptr %l21, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t691
  %t692 = getelementptr { i64, [1 x i64] }, ptr %t691, i32 0, i32 0
  store i64 4, ptr %t692
  %t694 = insertvalue { i32 } undef, i32 %t690, 0
  %t695 = getelementptr { i64, [1 x i64] }, ptr %t691, i32 0, i32 1
  store { i32 } %t694, ptr %t695
  %t696 = load { i64, [1 x i64] }, ptr %t691
  %t699 = getelementptr { i64, ptr }, ptr %l343, i32 0, i32 1
  %t700 = load ptr, ptr %t699, !tbaa !27
  %t701 = getelementptr { i64, [1 x i64] }, ptr %t700, i64 %t689
  store { i64, [1 x i64] } %t696, ptr %t701
  br label %bb148
bb146:
  %t702 = load ptr, ptr %l0, !tbaa !29
  %t703 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 0
  %t704 = load i64, ptr %t703, !tbaa !24
  %t705 = load ptr, ptr %l38, !tbaa !29
  %t706 = getelementptr %"compiler/free:orCall", ptr %l18, i32 0, i32 1
  %t707 = load i64, ptr %t706, !tbaa !24
  %t708 = load { i64, [1 x i64] }, ptr %l22
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v0, ptr %t702, i64 %t704, ptr %t705, i64 %t707, { i64, [1 x i64] } %t708, i1 false, i1 false)
  br label %bb147
bb147:
  br label %bb148
bb148:
  br label %bb149
bb149:
  %t714 = load i64, ptr %l35, !tbaa !24
  %t716 = add i64 %t714, 1
  store i64 %t716, ptr %l35, !tbaa !24
  br label %bb124
bb150:
  br label %bb151
bb151:
  %t718 = load i64, ptr %l17, !tbaa !24
  %t720 = add i64 %t718, 1
  store i64 %t720, ptr %l17, !tbaa !24
  br label %bb71
bb152:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2ebinds(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Alt", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb8
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:mustW", ptr %t26, i32 0, i32 4
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Bind", ptr %t29, i32 0, i32 0
  %t32 = load i32, ptr %t31, !tbaa !23
  %t34 = sext i32 %t32 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t34)
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:mustW", ptr %t37, i32 0, i32 5
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Bind", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t39, ptr %t43)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l3, !tbaa !24
  br label %bb1
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3amustW_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a1, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %t24)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l3, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca i1
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i64
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:mustW", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t7 = load ptr, ptr %l13, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t15 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  store i64 %t15, ptr %l12, !tbaa !24
  br label %bb61
bb6:
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t18 = load ptr, ptr %l18, !tbaa !29
  %t19 = icmp ne ptr %t18, null
  br i1 %t19, label %bb7, label %bb8
bb7:
  %t21 = load ptr, ptr %l18, !tbaa !29
  %t22 = load i64, ptr %t21, !range !{i64 0, i64 18}
  %t24 = icmp eq i64 %t22, 2
  store i1 %t24, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l3, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t36 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eplaceMust(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i64 %t36, ptr %l26
  br label %bb12
bb12:
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l12, !tbaa !24
  br label %bb61
bb13:
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t39 = load ptr, ptr %l27, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l27, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 18}
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l28, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l1, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  br label %bb18
bb17:
  br label %bb24
bb18:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t54 = load ptr, ptr %l4, !tbaa !29
  %t57 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t53, ptr %t54)
  store i64 %t57, ptr %l35
  br label %bb19
bb19:
  %t58 = load i64, ptr %l35, !tbaa !24
  %t59 = icmp sge i64 %t58, 0
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t61 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  store i64 %t61, ptr %l38, !tbaa !24
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t66 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t62, ptr %t63)
  store i64 %t66, ptr %l41
  br label %bb22
bb21:
  %t67 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t67, ptr %l37, !tbaa !24
  br label %bb23
bb22:
  %t69 = load i64, ptr %l38, !tbaa !24
  %t70 = load i64, ptr %l41, !tbaa !24
  %t71 = add i64 %t69, %t70
  store i64 %t71, ptr %l37, !tbaa !24
  br label %bb23
bb23:
  %t73 = load i64, ptr %l37, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb61
bb24:
  %t74 = load ptr, ptr %l1, !tbaa !29
  store ptr %t74, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t75 = load ptr, ptr %l44, !tbaa !29
  %t76 = icmp ne ptr %t75, null
  br i1 %t76, label %bb25, label %bb26
bb25:
  %t78 = load ptr, ptr %l44, !tbaa !29
  %t79 = load i64, ptr %t78, !range !{i64 0, i64 18}
  %t81 = icmp eq i64 %t79, 6
  store i1 %t81, ptr %l45, !tbaa !21
  br label %bb26
bb26:
  %t82 = load i1, ptr %l45, !tbaa !21
  br i1 %t82, label %bb27, label %bb28
bb27:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [5 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l5, !tbaa !29
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t93 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %t89, ptr %t90)
  store i64 %t93, ptr %l52
  br label %bb30
bb30:
  %t94 = load i64, ptr %l52, !tbaa !24
  store i64 %t94, ptr %l12, !tbaa !24
  br label %bb61
bb31:
  %t95 = load ptr, ptr %l1, !tbaa !29
  store ptr %t95, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t96 = load ptr, ptr %l53, !tbaa !29
  %t97 = icmp ne ptr %t96, null
  br i1 %t97, label %bb32, label %bb33
bb32:
  %t99 = load ptr, ptr %l53, !tbaa !29
  %t100 = load i64, ptr %t99, !range !{i64 0, i64 18}
  %t102 = icmp eq i64 %t100, 14
  store i1 %t102, ptr %l54, !tbaa !21
  br label %bb33
bb33:
  %t103 = load i1, ptr %l54, !tbaa !21
  br i1 %t103, label %bb34, label %bb35
bb34:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr { i64, [5 x i64] }, ptr %t104, i32 0, i32 1
  %t107 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t106, i32 0, i32 2
  %t108 = load ptr, ptr %t107
  store ptr %t108, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l6, !tbaa !29
  %t114 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2etryMust(ptr %v0, ptr %v1, ptr %t110, ptr %t111)
  store i64 %t114, ptr %l61
  br label %bb37
bb37:
  %t115 = load i64, ptr %l61, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  br label %bb61
bb38:
  %t116 = load ptr, ptr %l1, !tbaa !29
  store ptr %t116, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t117 = load ptr, ptr %l62, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb39, label %bb40
bb39:
  %t120 = load ptr, ptr %l62, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 18}
  %t123 = icmp eq i64 %t121, 17
  store i1 %t123, ptr %l63, !tbaa !21
  br label %bb40
bb40:
  %t124 = load i1, ptr %l63, !tbaa !21
  br i1 %t124, label %bb41, label %bb42
bb41:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr { i64, [5 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t127, i32 0, i32 2
  %t129 = load ptr, ptr %t128
  store ptr %t129, ptr %l7, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load ptr, ptr %l7, !tbaa !29
  %t135 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t131, ptr %t132)
  store i64 %t135, ptr %l70
  br label %bb44
bb44:
  %t136 = load i64, ptr %l70, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  br label %bb61
bb45:
  %t137 = load ptr, ptr %l1, !tbaa !29
  store ptr %t137, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t138 = load ptr, ptr %l71, !tbaa !29
  %t139 = icmp ne ptr %t138, null
  br i1 %t139, label %bb46, label %bb47
bb46:
  %t141 = load ptr, ptr %l71, !tbaa !29
  %t142 = load i64, ptr %t141, !range !{i64 0, i64 18}
  %t144 = icmp eq i64 %t142, 9
  store i1 %t144, ptr %l72, !tbaa !21
  br label %bb47
bb47:
  %t145 = load i1, ptr %l72, !tbaa !21
  br i1 %t145, label %bb48, label %bb49
bb48:
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t148 = getelementptr { i64, [5 x i64] }, ptr %t146, i32 0, i32 1
  %t149 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t148, i32 0, i32 2
  %t150 = load i32, ptr %t149, !range !{i32 0, i32 52}
  store i32 %t150, ptr %l8
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t154, i32 0, i32 4
  %t156 = load { i64, ptr }, ptr %t155
  store { i64, ptr } %t156, ptr %l9, !tbaa !27
  br label %bb50
bb49:
  br label %bb56
bb50:
  %t158 = load i32, ptr %l8, !range !{i32 0, i32 52}
  %t159 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t162 = call i1 @compiler_2ffree_2eisConversion(ptr %v1, i32 %t158, { i64, ptr } %t159)
  store i1 %t162, ptr %l81
  br label %bb51
bb51:
  %t163 = load i1, ptr %l81, !tbaa !21
  br i1 %t163, label %bb52, label %bb53
bb52:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t165, ptr %l84, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr ptr, ptr %t167, i64 0
  %t169 = load ptr, ptr %t168, !tbaa !39
  %t172 = call i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eexprMust(ptr %v0, ptr %v1, ptr %t164, ptr %t169)
  store i64 %t172, ptr %l86
  br label %bb54
bb53:
  %t173 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t173, ptr %l82, !tbaa !24
  br label %bb55
bb54:
  %t175 = load i64, ptr %l86, !tbaa !24
  store i64 %t175, ptr %l82, !tbaa !24
  br label %bb55
bb55:
  %t176 = load i64, ptr %l82, !tbaa !24
  store i64 %t176, ptr %l12, !tbaa !24
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  %t177 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t177, ptr %l12, !tbaa !24
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_2f86b0bb9e05ec4_6260055ddf2cdd10)
  unreachable
bb61:
  %t179 = load i64, ptr %l12, !tbaa !24
  store i64 %t179, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efreshLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i1
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l43 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i1, ptr %l11, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i1 false, ptr %l2, !tbaa !21
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:mustW", ptr %t8, i32 0, i32 4
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l15
  br label %bb5
bb5:
  %t13 = load i64, ptr %l15, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb11
bb8:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb10
bb10:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb11
bb11:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:mustW", ptr %t60, i32 0, i32 4
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l43
  br label %bb16
bb16:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  %t70 = icmp ne i64 %t68, %t67
  br i1 %t70, label %bb17, label %bb18
bb17:
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l46, !tbaa !29
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:mustW", ptr %t73, i32 0, i32 5
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t75, i64 %t76)
  store ptr %t79, ptr %l50
  br label %bb20
bb20:
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t82 = call i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v0, ptr %t80, ptr %t81, i64 1)
  store i1 %t82, ptr %l51
  br label %bb21
bb21:
  %t83 = load i1, ptr %l51, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  store i1 true, ptr %l2, !tbaa !21
  br label %bb25
bb25:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb12
bb26:
  %t91 = load i1, ptr %l2, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/free:walker", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/generic:Program", ptr %t7, i32 0, i32 2
  store ptr %t9, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca { i64, ptr }
  %l26 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l41 = alloca i64
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca ptr
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l66 = alloca ptr
  %l76 = alloca ptr
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l11
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = getelementptr %"compiler/typed:Alt", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t30, ptr %t34)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l26
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l6, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Alt", ptr %t38, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t55, ptr %l35, !tbaa !27
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l10, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l38, !tbaa !29
  %t64 = load ptr, ptr %l10, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Bind", ptr %t64, i32 0, i32 0
  %t67 = load i32, ptr %t66, !tbaa !23
  %t69 = sext i32 %t67 to i64
  store i64 %t69, ptr %l41, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l10, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Bind", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s4, ptr %t70, ptr %t74)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l45
  br label %bb11
bb11:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  %t79 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %t79
  %t80 = load ptr, ptr %l38, !tbaa !29
  %t81 = load i64, ptr %l41, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %s4, ptr %t80, i64 %t81, ptr %t79)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb13:
  %t83 = load i64, ptr %l8, !tbaa !24
  %t85 = add i64 %t83, 1
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb7
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t87 = load i64, ptr %l4, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l4, !tbaa !24
  br label %bb2
bb16:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/typed:Arm", ptr %t91, i32 0, i32 2
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = icmp eq ptr %t94, null
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s7
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l55, !tbaa !29
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Arm", ptr %t101, i32 0, i32 2
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb19, label %bb20
bb18:
  br label %bb23
bb19:
  call void @__olang_check_failed(ptr @olang_loc_304dd9f782c5c299_7aedab6f7faf5da5)
  unreachable
bb20:
  br label %bb21
bb21:
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Arm", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t112, ptr %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l61
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/typed:Arm", ptr %t115, i32 0, i32 3
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = icmp eq ptr %t118, null
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb24, label %bb25
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l66, !tbaa !29
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Arm", ptr %t125, i32 0, i32 3
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  br i1 %t130, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  call void @__olang_check_failed(ptr @olang_loc_ceff65db82d42b72_bd0ee798a65f80fe)
  unreachable
bb27:
  br label %bb28
bb28:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = getelementptr %"compiler/typed:Arm", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t136 = load ptr, ptr %l66, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t136, ptr %t135)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Arm", ptr %t138, i32 0, i32 4
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = icmp eq ptr %t141, null
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb31, label %bb32
bb31:
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l76, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr %"compiler/typed:Arm", ptr %t148, i32 0, i32 4
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb33, label %bb34
bb32:
  br label %bb37
bb33:
  call void @__olang_check_failed(ptr @olang_loc_1c2ece56a8f93bb3_9a04e0623a4a84af)
  unreachable
bb34:
  br label %bb35
bb35:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr %"compiler/typed:Arm", ptr %t155, i32 0, i32 4
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load ptr, ptr %l76, !tbaa !29
  %t161 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t159, ptr %t158)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l82
  br label %bb36
bb36:
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  %t163 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %t163
  br label %bb37
bb37:
  %t164 = load ptr, ptr %lp2
  %t165 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t164
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t165, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %lp4 = alloca ptr
  %l9 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t4, ptr %t7)
  store i64 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t14 = icmp sge i64 %t11, 0
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l13, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t18)
  store i32 %t20, ptr %l15
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = load ptr, ptr %l13, !tbaa !29
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t21, ptr %t22, i32 %t23)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l16
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t30 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t26, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l19
  br label %bb7
bb7:
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t31, ptr %lp4
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t33 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t33
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load ptr, ptr %lp4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t34, ptr %t35)
  br label %bb8
bb8:
  %t38 = load ptr, ptr %lp4
  %t39 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecaptured(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t8 = load ptr, ptr %lp3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load ptr, ptr %lp3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v2, ptr %s0, ptr %t9, ptr %t10, %"compiler/source:Span" %a1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d56, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %lp3
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyInto(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, i32 %a2, ptr %a3, ptr %a4, %"compiler/source:Span" %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"compiler/free:leaf"
  %l26 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i1
  %l51 = alloca ptr
  %l56 = alloca i1
  %l57 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca i64
  %l67 = alloca i1
  %l68 = alloca ptr
  %l72 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l85 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l90 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i1
  %l97 = alloca i64
  %l99 = alloca i1
  %l102 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca ptr
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l137 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca ptr
  %l144 = alloca i64
  %l146 = alloca i64
  %l151 = alloca i64
  %l158 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l174 = alloca i1
  %l179 = alloca i64
  %l181 = alloca i64
  %l186 = alloca %"compiler/free:leaf"
  %l188 = alloca %"compiler/free:leaf"
  %l190 = alloca ptr
  %l191 = alloca i64
  %l193 = alloca i64
  %l195 = alloca ptr
  %l202 = alloca %"compiler/free:store"
  %l203 = alloca ptr
  %l204 = alloca i64
  %l205 = alloca i64
  %l207 = alloca ptr
  %l209 = alloca i64
  %l210 = alloca %"compiler/source:Span"
  %l211 = alloca ptr
  %l213 = alloca %"compiler/source:Span"
  %l214 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l7, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l26
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l26, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v1, ptr %v4, ptr %t16, ptr %t17, ptr %t18, %"compiler/source:Span" %t19)
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %rv
  br label %ret
bb5:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t31 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v2, ptr %t28)
  store ptr %t31, ptr %l38
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l38, !tbaa !29
  store ptr %t32, ptr %l9, !tbaa !29
  %t33 = load ptr, ptr %l9, !tbaa !29
  %t35 = icmp eq ptr %t33, null
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  %t39 = load ptr, ptr %l9, !tbaa !29
  %t41 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t39)
  store i64 %t41, ptr %l44
  br label %bb9
bb8:
  store i64 -1, ptr %l42, !tbaa !24
  br label %bb10
bb9:
  %t42 = load i64, ptr %l44, !tbaa !24
  store i64 %t42, ptr %l42, !tbaa !24
  br label %bb10
bb10:
  %t43 = load i64, ptr %l42, !tbaa !24
  store i64 %t43, ptr %l10, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t46 = icmp sge i64 %t44, 0
  br i1 %t46, label %bb11, label %bb12
bb11:
  %t48 = load ptr, ptr %l7, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 1
  %t51 = load i64, ptr %l10, !tbaa !24
  %t54 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t50, i64 %t51)
  store ptr %t54, ptr %l51
  br label %bb13
bb12:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb14
bb13:
  %t55 = load ptr, ptr %l51, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Body", ptr %t55, i32 0, i32 11
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  store i1 %t62, ptr %l47, !tbaa !21
  br label %bb14
bb14:
  %t64 = load i1, ptr %l47, !tbaa !21
  br i1 %t64, label %bb15, label %bb16
bb15:
  %t65 = load ptr, ptr %l8, !tbaa !29
  store ptr %t65, ptr %l57, !tbaa !29
  %t66 = load ptr, ptr %l7, !tbaa !29
  %t68 = getelementptr %"compiler/free:Free", ptr %t66, i32 0, i32 1
  %t69 = load i64, ptr %l10, !tbaa !24
  %t72 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t68, i64 %t69)
  store ptr %t72, ptr %l61
  br label %bb17
bb16:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb19
bb17:
  %t73 = load ptr, ptr %l61, !tbaa !29
  %t75 = getelementptr %"compiler/typed:Body", ptr %t73, i32 0, i32 2
  %t76 = load i32, ptr %t75, !tbaa !23
  %t77 = load ptr, ptr %l57, !tbaa !29
  %t79 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t77, i32 %t76)
  store i64 %t79, ptr %l64
  br label %bb18
bb18:
  %t80 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t81 = load i64, ptr %l64, !tbaa !24
  %t83 = icmp eq i64 %t81, %t80
  store i1 %t83, ptr %l56, !tbaa !21
  br label %bb19
bb19:
  %t85 = load i1, ptr %l56, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t86 = load ptr, ptr %l8, !tbaa !29
  store ptr %t86, ptr %l68, !tbaa !29
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 1
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t89, i64 %t90)
  store ptr %t93, ptr %l72
  br label %bb22
bb21:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb24
bb22:
  %t94 = load ptr, ptr %l72, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = load ptr, ptr %l68, !tbaa !29
  %t100 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t98, i32 %t97)
  store { i64, ptr } %t100, ptr %l75
  br label %bb23
bb23:
  %t101 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t104 = icmp eq i64 %t102, 1
  store i1 %t104, ptr %l67, !tbaa !21
  br label %bb24
bb24:
  %t106 = load i1, ptr %l67, !tbaa !21
  br i1 %t106, label %bb25, label %bb26
bb25:
  %t107 = load ptr, ptr %l8, !tbaa !29
  store ptr %t107, ptr %l79, !tbaa !29
  %t108 = load ptr, ptr %l8, !tbaa !29
  store ptr %t108, ptr %l80, !tbaa !29
  %t109 = load ptr, ptr %l8, !tbaa !29
  store ptr %t109, ptr %l81, !tbaa !29
  %t110 = load ptr, ptr %l7, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 1
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l85
  br label %bb27
bb26:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb32
bb27:
  %t117 = load ptr, ptr %l85, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 2
  %t120 = load i32, ptr %t119, !tbaa !23
  %t121 = load ptr, ptr %l81, !tbaa !29
  %t123 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s0, ptr %t121, i32 %t120)
  store { i64, ptr } %t123, ptr %l88
  br label %bb28
bb28:
  %t124 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i32, ptr %t125, i64 0
  %t127 = load i32, ptr %t126, !tbaa !33
  %t128 = load ptr, ptr %l80, !tbaa !29
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t128, i32 %t127)
  store i32 %t130, ptr %l90
  br label %bb29
bb29:
  %t131 = load ptr, ptr %l8, !tbaa !29
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t131, i32 %a2)
  store i32 %t135, ptr %l93
  br label %bb30
bb30:
  %t136 = load ptr, ptr %l79, !tbaa !29
  %t137 = load i32, ptr %l90, !tbaa !23
  %t138 = load i32, ptr %l93, !tbaa !23
  %t139 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t136, i32 %t137, i32 %t138)
  store i1 %t139, ptr %l94
  br label %bb31
bb31:
  %t140 = load i1, ptr %l94, !tbaa !21
  store i1 %t140, ptr %l78, !tbaa !21
  br label %bb32
bb32:
  %t141 = load i1, ptr %l78, !tbaa !21
  br i1 %t141, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s2
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t142, i64 %t143)
  store i64 %t146, ptr %l97
  br label %bb35
bb34:
  br label %bb74
bb35:
  %t147 = load i64, ptr %l97, !tbaa !24
  %t148 = icmp ne i64 %t147, 0
  br i1 %t148, label %bb36, label %bb37
bb36:
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb38, label %bb39
bb37:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb43
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb39:
  br label %bb40
bb40:
  %t154 = load ptr, ptr %l9, !tbaa !29
  store ptr %t154, ptr %l102, !tbaa !29
  %t155 = load ptr, ptr %l7, !tbaa !29
  %t156 = load i64, ptr %l10, !tbaa !24
  %t159 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %t155, i64 %t156)
  store i64 %t159, ptr %l105
  br label %bb41
bb41:
  %t160 = load ptr, ptr %l102, !tbaa !29
  %t161 = load i64, ptr %l105, !tbaa !24
  %t162 = call i1 @compiler_2ftyped_2eViewsMoved(ptr %v2, ptr %t160, i64 %t161)
  store i1 %t162, ptr %l106
  br label %bb42
bb42:
  %t163 = load i1, ptr %l106, !tbaa !21
  %t164 = xor i1 %t163, true
  store i1 %t164, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t166 = load i1, ptr %l99, !tbaa !21
  br i1 %t166, label %bb44, label %bb45
bb44:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l108, !tbaa !29
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l109, !tbaa !29
  %t169 = load ptr, ptr %l9, !tbaa !29
  %t171 = icmp eq ptr %t169, null
  br i1 %t171, label %bb46, label %bb47
bb45:
  br label %bb50
bb46:
  call void @__olang_check_failed(ptr @olang_loc_3ed6c54977104fdc_6fa493e2929cd018)
  unreachable
bb47:
  br label %bb48
bb48:
  %t173 = load ptr, ptr %l9, !tbaa !29
  %t174 = load ptr, ptr %l3, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l5
  %t176 = load ptr, ptr %l108, !tbaa !29
  %t177 = load ptr, ptr %l109, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t176, ptr %t177, ptr %t173, ptr %t174, %"compiler/source:Span" %t175)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t181 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t181, ptr %l115
  br label %bb51
bb51:
  %t182 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 32, i64 8)
  store ptr %t182, ptr %lp11
  %t183 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  %t184 = load ptr, ptr %lp11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t183, ptr %t184
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l116, !tbaa !29
  %t186 = load ptr, ptr %l116, !tbaa !29
  %t187 = getelementptr %"compiler/free:walker", ptr %t186, i32 0, i32 29
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = add i64 %t188, 1
  %t192 = load ptr, ptr %l116, !tbaa !29
  %t193 = getelementptr %"compiler/free:walker", ptr %t192, i32 0, i32 29
  store i64 %t190, ptr %t193, !tbaa !24
  %t194 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t194, ptr %l119
  br label %bb52
bb52:
  %t195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195, ptr %l12
  %t196 = load ptr, ptr %l9, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb53, label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237)
  unreachable
bb54:
  br label %bb55
bb55:
  %t200 = load ptr, ptr %l9, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Call", ptr %t200, i32 0, i32 1
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  store { i64, ptr } %t204, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l15, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s5
  %t210 = load i64, ptr %l14, !tbaa !24
  %t211 = load i64, ptr %l15, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s5)
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t218 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t218, ptr %l131, !tbaa !27
  %t219 = load i64, ptr %l14, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr ptr, ptr %t222, i64 %t219
  %t224 = load ptr, ptr %t223, !tbaa !39
  store ptr %l12, ptr %l134, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t230 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v2, ptr %s5, ptr %t226, ptr %t224)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %l137
  br label %bb60
bb60:
  %t231 = load ptr, ptr %l134, !tbaa !29
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l137
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %s2, ptr %s5, ptr %t231, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s5)
  br label %bb62
bb62:
  %t233 = load i64, ptr %l14, !tbaa !24
  %t235 = add i64 %t233, 1
  store i64 %t235, ptr %l14, !tbaa !24
  br label %bb56
bb63:
  %t237 = load ptr, ptr %l7, !tbaa !29
  %t239 = getelementptr %"compiler/free:Free", ptr %t237, i32 0, i32 24
  %t240 = load i64, ptr %l10, !tbaa !24
  %t243 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t239, i64 %t240)
  store ptr %t243, ptr %l143
  br label %bb64
bb64:
  %t244 = load ptr, ptr %l143, !tbaa !29
  store ptr %t244, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb65
bb65:
  %t245 = load i64, ptr %l18, !tbaa !24
  store i64 %t245, ptr %l144, !tbaa !24
  %t246 = load ptr, ptr %l17, !tbaa !29
  %t248 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t246)
  store i64 %t248, ptr %l146
  br label %bb66
bb66:
  %t249 = load i64, ptr %l144, !tbaa !24
  %t250 = load i64, ptr %l146, !tbaa !24
  %t251 = icmp slt i64 %t249, %t250
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb67, label %bb68
bb67:
  br label %bb73
bb68:
  br label %bb69
bb69:
  %t255 = load ptr, ptr %l17, !tbaa !29
  %t256 = load i64, ptr %l18, !tbaa !24
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t255, i64 %t256)
  store i64 %t259, ptr %l151
  br label %bb70
bb70:
  %t260 = load i64, ptr %l151, !tbaa !24
  %t261 = load ptr, ptr %l7, !tbaa !29
  %t263 = load ptr, ptr %lp11
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %s2, ptr %v5, ptr %t261, i64 %t260, ptr %l12, ptr %t263)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t268 = load i64, ptr %l18, !tbaa !24
  %t270 = add i64 %t268, 1
  store i64 %t270, ptr %l18, !tbaa !24
  br label %bb65
bb73:
  %t272 = load ptr, ptr %l0, !tbaa !29
  store ptr %t272, ptr %l158, !tbaa !29
  %t273 = load ptr, ptr %l158, !tbaa !29
  %t274 = getelementptr %"compiler/free:walker", ptr %t273, i32 0, i32 29
  %t275 = load i64, ptr %t274, !tbaa !24
  %t277 = sub i64 %t275, 1
  %t279 = load ptr, ptr %l158, !tbaa !29
  %t280 = getelementptr %"compiler/free:walker", ptr %t279, i32 0, i32 29
  store i64 %t277, ptr %t280, !tbaa !24
  %t281 = load ptr, ptr %lp11
  %t282 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t281
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t282, ptr %rv
  br label %ret
bb74:
  %t284 = load ptr, ptr %l3, !tbaa !29
  store ptr %t284, ptr %l162, !tbaa !29
  store i1 false, ptr %l163, !tbaa !21
  %t285 = load ptr, ptr %l162, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb75, label %bb76
bb75:
  %t288 = load ptr, ptr %l162, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 18}
  %t291 = icmp eq i64 %t289, 0
  store i1 %t291, ptr %l163, !tbaa !21
  br label %bb76
bb76:
  %t292 = load i1, ptr %l163, !tbaa !21
  br i1 %t292, label %bb77, label %bb78
bb77:
  br label %bb83
bb78:
  %t293 = load ptr, ptr %l3, !tbaa !29
  store ptr %t293, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t294 = load ptr, ptr %l166, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb79, label %bb80
bb79:
  %t297 = load ptr, ptr %l166, !tbaa !29
  %t298 = load i64, ptr %t297, !range !{i64 0, i64 18}
  %t300 = icmp eq i64 %t298, 1
  store i1 %t300, ptr %l167, !tbaa !21
  br label %bb80
bb80:
  %t301 = load i1, ptr %l167, !tbaa !21
  br i1 %t301, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t302 = load ptr, ptr %l4, !tbaa !29
  %t304 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t302
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t304, ptr %rv
  br label %ret
bb84:
  br i1 true, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_check_failed(ptr @olang_loc_7f12d3772dd0a929_45b952e679e83a85)
  unreachable
bb89:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/free:walker", ptr %t306, i32 0, i32 2
  %t309 = load i1, ptr %t308, !tbaa !21
  br i1 %t309, label %bb90, label %bb91
bb90:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/free:walker", ptr %t311, i32 0, i32 29
  %t314 = load i64, ptr %t313, !tbaa !24
  %t316 = icmp eq i64 %t314, 0
  store i1 %t316, ptr %l174, !tbaa !21
  br label %bb92
bb91:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb92
bb92:
  %t318 = load i1, ptr %l174, !tbaa !21
  br i1 %t318, label %bb93, label %bb94
bb93:
  %t319 = load ptr, ptr %l1, !tbaa !29
  store ptr %t319, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb95
bb94:
  br label %bb111
bb95:
  store %olang.scope zeroinitializer, ptr %s14
  %t321 = load i64, ptr %l21, !tbaa !24
  store i64 %t321, ptr %l179, !tbaa !24
  %t322 = load ptr, ptr %l20, !tbaa !29
  %t324 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t322)
  store i64 %t324, ptr %l181
  br label %bb96
bb96:
  %t325 = load i64, ptr %l179, !tbaa !24
  %t326 = load i64, ptr %l181, !tbaa !24
  %t327 = icmp slt i64 %t325, %t326
  %t329 = xor i1 %t327, true
  br i1 %t329, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s14)
  br label %bb110
bb98:
  br label %bb99
bb99:
  %t331 = load ptr, ptr %l20, !tbaa !29
  %t332 = load i64, ptr %l21, !tbaa !24
  %t335 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t331, i64 %t332)
  store %"compiler/free:leaf" %t335, ptr %l186
  br label %bb100
bb100:
  %t337 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s14, ptr %l186)
  store %"compiler/free:leaf" %t337, ptr %l188
  br label %bb101
bb101:
  %t338 = load %"compiler/free:leaf", ptr %l188
  store %"compiler/free:leaf" %t338, ptr %l22
  %t339 = load ptr, ptr %l7, !tbaa !29
  %t341 = getelementptr %"compiler/free:Free", ptr %t339, i32 0, i32 42
  store ptr %t341, ptr %l190, !tbaa !29
  %t342 = getelementptr %"compiler/free:leaf", ptr %l22, i32 0, i32 1
  %t343 = load i64, ptr %t342, !tbaa !24
  store i64 %t343, ptr %l191, !tbaa !24
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t346 = getelementptr %"compiler/free:walker", ptr %t344, i32 0, i32 1
  %t347 = load i64, ptr %t346, !tbaa !24
  store i64 %t347, ptr %l193, !tbaa !24
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t348)
  store ptr %t350, ptr %l195
  br label %bb102
bb102:
  %t351 = load ptr, ptr %l195, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Body", ptr %t351, i32 0, i32 3
  %t354 = load i64, ptr %t353, !tbaa !24
  %t355 = load %"compiler/source:Span", ptr %l5
  %t356 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t357 = load ptr, ptr %l3, !tbaa !29
  %t359 = load i64, ptr %l191, !tbaa !24
  %t360 = load i64, ptr %l193, !tbaa !24
  %t365 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t359, i64 %t360, i64 %t354, %"compiler/source:Span" %t355, i64 %t356, i64 -1, i64 -1, ptr %t357, ptr null)
  store %"compiler/free:store" %t365, ptr %l202
  br label %bb103
bb103:
  %t366 = load ptr, ptr %l190, !tbaa !29
  %t367 = load %"compiler/free:store", ptr %l202
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t366, %"compiler/free:store" %t367)
  br label %bb104
bb104:
  %t368 = load ptr, ptr %l7, !tbaa !29
  store ptr %t368, ptr %l203, !tbaa !29
  %t369 = getelementptr %"compiler/free:leaf", ptr %l22, i32 0, i32 1
  %t370 = load i64, ptr %t369, !tbaa !24
  store i64 %t370, ptr %l204, !tbaa !24
  %t371 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t371, ptr %l205, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t372)
  store ptr %t374, ptr %l207
  br label %bb105
bb105:
  %t375 = load ptr, ptr %l207, !tbaa !29
  %t377 = getelementptr %"compiler/typed:Body", ptr %t375, i32 0, i32 3
  %t378 = load i64, ptr %t377, !tbaa !24
  store i64 %t378, ptr %l209, !tbaa !24
  %t379 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t379, ptr %l210
  %t380 = load ptr, ptr %l0, !tbaa !29
  store ptr %t380, ptr %l211, !tbaa !29
  %t381 = load ptr, ptr %l3, !tbaa !29
  %t383 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t381)
  store %"compiler/source:Span" %t383, ptr %l213
  br label %bb106
bb106:
  %t384 = load ptr, ptr %l211, !tbaa !29
  %t385 = load %"compiler/source:Span", ptr %l213
  %t386 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s14, ptr %t384, %"compiler/source:Span" %t385)
  store { i64, ptr } %t386, ptr %l214
  br label %bb107
bb107:
  %t387 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t389 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = add i64 %t388, %t391
  %t393 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t394 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t395 = add i64 %t392, %t394
  %t396 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t395)
  call void @olang_textcopy(ptr %t396, ptr %t387, i64 %t388)
  %t397 = getelementptr i8, ptr %t396, i64 %t388
  call void @olang_textcopy(ptr %t397, ptr %t390, i64 %t391)
  %t398 = getelementptr i8, ptr %t397, i64 %t391
  call void @olang_textcopy(ptr %t398, ptr %t393, i64 %t394)
  %t399 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t396, 1
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t403 = extractvalue { i64, ptr } %t400, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  %t408 = load ptr, ptr %l203, !tbaa !29
  %t409 = load i64, ptr %l204, !tbaa !24
  %t410 = load i64, ptr %l205, !tbaa !24
  %t411 = load i64, ptr %l209, !tbaa !24
  %t412 = load %"compiler/source:Span", ptr %l210
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s14, ptr %t408, i64 %t409, i64 %t410, i64 %t411, %"compiler/source:Span" %t412, { i64, ptr } %t407)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s14)
  br label %bb109
bb109:
  %t414 = load i64, ptr %l21, !tbaa !24
  %t416 = add i64 %t414, 1
  store i64 %t416, ptr %l21, !tbaa !24
  br label %bb95
bb110:
  br label %bb111
bb111:
  %t418 = load ptr, ptr %l4, !tbaa !29
  %t420 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t418
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t420, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyLeaves(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:leaf"
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/free:leaf"
  %l14 = alloca i64
  %l20 = alloca i1
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca %"compiler/free:leaf"
  %l35 = alloca %"compiler/free:leaf"
  %l38 = alloca i1
  %l39 = alloca i1
  %l43 = alloca i1
  %l49 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i1
  %l56 = alloca i1
  %l61 = alloca i1
  %l63 = alloca i64
  %l65 = alloca i64
  %l70 = alloca %"compiler/free:leaf"
  %l72 = alloca %"compiler/free:leaf"
  %l76 = alloca i1
  %l78 = alloca ptr
  %l79 = alloca i64
  %l81 = alloca i64
  %l83 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca %"compiler/source:Span"
  %l88 = alloca i64
  %l92 = alloca i64
  %l96 = alloca %"compiler/free:store"
  %l99 = alloca ptr
  %l100 = alloca i64
  %l101 = alloca i64
  %l103 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca %"compiler/source:Span"
  %l107 = alloca ptr
  %l109 = alloca %"compiler/source:Span"
  %l110 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca i64
  %l117 = alloca i64
  %l119 = alloca ptr
  %l126 = alloca %"compiler/free:store"
  %l127 = alloca ptr
  %l128 = alloca i64
  %l129 = alloca i64
  %l131 = alloca ptr
  %l133 = alloca i64
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca ptr
  %l137 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 29
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  store i1 %t18, ptr %l20, !tbaa !21
  br label %bb3
bb3:
  %t20 = load i1, ptr %l20, !tbaa !21
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l24
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l5
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l7, !tbaa !24
  store i64 %t25, ptr %l26, !tbaa !24
  %t26 = load ptr, ptr %l6, !tbaa !29
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t26)
  store i64 %t28, ptr %l28
  br label %bb9
bb9:
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = load i64, ptr %l28, !tbaa !24
  %t31 = icmp slt i64 %t29, %t30
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb11:
  br label %bb12
bb12:
  %t35 = load ptr, ptr %l6, !tbaa !29
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t35, i64 %t36)
  store %"compiler/free:leaf" %t39, ptr %l33
  br label %bb13
bb13:
  %t41 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s3, ptr %l33)
  store %"compiler/free:leaf" %t41, ptr %l35
  br label %bb14
bb14:
  %t42 = load %"compiler/free:leaf", ptr %l35
  store %"compiler/free:leaf" %t42, ptr %l8
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t45 = load i64, ptr %t44, !tbaa !24
  %t48 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t43, i64 %t45)
  store i1 %t48, ptr %l38
  br label %bb15
bb15:
  %t49 = load i1, ptr %l38, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb19
bb17:
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 12
  %t53 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t54 = load i64, ptr %t53, !tbaa !24
  %t57 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t52, i64 %t54)
  store i1 %t57, ptr %l43
  br label %bb18
bb18:
  %t58 = load i1, ptr %l43, !tbaa !21
  store i1 %t58, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t59 = load i1, ptr %l39, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = getelementptr %"compiler/free:leaf", ptr %l8, i32 0, i32 1
  %t61 = load i64, ptr %t60, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l5, i64 %t61)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t64 = load i64, ptr %l7, !tbaa !24
  %t66 = add i64 %t64, 1
  store i64 %t66, ptr %l7, !tbaa !24
  br label %bb8
bb25:
  %t68 = load ptr, ptr %l2, !tbaa !29
  %t70 = call i64 @compiler_2ffree_2eownCopySite(ptr %v2, ptr %t68)
  store i64 %t70, ptr %l49
  br label %bb26
bb26:
  %t71 = load i64, ptr %l49, !tbaa !24
  store i64 %t71, ptr %l9, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l5)
  store i64 %t73, ptr %l51
  br label %bb27
bb27:
  %t74 = load i64, ptr %l51, !tbaa !24
  %t75 = icmp eq i64 %t74, 1
  br i1 %t75, label %bb28, label %bb29
bb28:
  %t77 = load i64, ptr %l9, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  store i1 %t79, ptr %l53, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb30
bb30:
  %t81 = load i1, ptr %l53, !tbaa !21
  br i1 %t81, label %bb31, label %bb32
bb31:
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t84 = getelementptr %"compiler/free:Free", ptr %t82, i32 0, i32 21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 1
  %t88 = load i64, ptr %t87, !tbaa !24
  %t91 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t84, i64 %t88)
  store i1 %t91, ptr %l61
  br label %bb33
bb32:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb34
bb33:
  %t92 = load i1, ptr %l61, !tbaa !21
  store i1 %t92, ptr %l56, !tbaa !21
  br label %bb34
bb34:
  %t93 = load i1, ptr %l56, !tbaa !21
  store i1 %t93, ptr %l10, !tbaa !21
  %t94 = load ptr, ptr %l1, !tbaa !29
  store ptr %t94, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t96 = load i64, ptr %l12, !tbaa !24
  store i64 %t96, ptr %l63, !tbaa !24
  %t97 = load ptr, ptr %l11, !tbaa !29
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %t97)
  store i64 %t99, ptr %l65
  br label %bb36
bb36:
  %t100 = load i64, ptr %l63, !tbaa !24
  %t101 = load i64, ptr %l65, !tbaa !24
  %t102 = icmp slt i64 %t100, %t101
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb37, label %bb38
bb37:
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb38:
  br label %bb39
bb39:
  %t106 = load ptr, ptr %l11, !tbaa !29
  %t107 = load i64, ptr %l12, !tbaa !24
  %t110 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %v1, ptr %t106, i64 %t107)
  store %"compiler/free:leaf" %t110, ptr %l70
  br label %bb40
bb40:
  %t112 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s7, ptr %l70)
  store %"compiler/free:leaf" %t112, ptr %l72
  br label %bb41
bb41:
  %t113 = load %"compiler/free:leaf", ptr %l72
  store %"compiler/free:leaf" %t113, ptr %l13
  %t114 = getelementptr %"compiler/free:leaf", ptr %l13, i32 0, i32 1
  %t115 = load i64, ptr %t114, !tbaa !24
  store i64 %t115, ptr %l14, !tbaa !24
  %t117 = load i64, ptr %l14, !tbaa !24
  %t120 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l5, i64 %t117)
  store i1 %t120, ptr %l76
  br label %bb42
bb42:
  %t121 = load i1, ptr %l76, !tbaa !21
  br i1 %t121, label %bb43, label %bb44
bb43:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/free:Free", ptr %t122, i32 0, i32 42
  store ptr %t124, ptr %l78, !tbaa !29
  %t125 = load i64, ptr %l14, !tbaa !24
  store i64 %t125, ptr %l79, !tbaa !24
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 1
  %t129 = load i64, ptr %t128, !tbaa !24
  store i64 %t129, ptr %l81, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t130)
  store ptr %t132, ptr %l83
  br label %bb45
bb44:
  br label %bb61
bb45:
  %t133 = load ptr, ptr %l83, !tbaa !29
  %t135 = getelementptr %"compiler/typed:Body", ptr %t133, i32 0, i32 3
  %t136 = load i64, ptr %t135, !tbaa !24
  store i64 %t136, ptr %l85, !tbaa !24
  %t137 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t137, ptr %l86
  %t138 = load i1, ptr %l10, !tbaa !21
  br i1 %t138, label %bb46, label %bb47
bb46:
  %t140 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t140, ptr %l88, !tbaa !24
  br label %bb48
bb47:
  %t142 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t142, ptr %l88, !tbaa !24
  br label %bb48
bb48:
  %t144 = load i1, ptr %l10, !tbaa !21
  br i1 %t144, label %bb49, label %bb50
bb49:
  %t146 = load i64, ptr %l9, !tbaa !24
  store i64 %t146, ptr %l92, !tbaa !24
  br label %bb51
bb50:
  store i64 -1, ptr %l92, !tbaa !24
  br label %bb51
bb51:
  %t148 = load ptr, ptr %l2, !tbaa !29
  %t150 = load i64, ptr %l79, !tbaa !24
  %t151 = load i64, ptr %l81, !tbaa !24
  %t152 = load i64, ptr %l85, !tbaa !24
  %t153 = load %"compiler/source:Span", ptr %l86
  %t154 = load i64, ptr %l88, !tbaa !24
  %t155 = load i64, ptr %l92, !tbaa !24
  %t157 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t150, i64 %t151, i64 %t152, %"compiler/source:Span" %t153, i64 %t154, i64 -1, i64 %t155, ptr %t148, ptr null)
  store %"compiler/free:store" %t157, ptr %l96
  br label %bb52
bb52:
  %t158 = load ptr, ptr %l78, !tbaa !29
  %t159 = load %"compiler/free:store", ptr %l96
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t158, %"compiler/free:store" %t159)
  br label %bb53
bb53:
  %t160 = load i1, ptr %l10, !tbaa !21
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t164 = load ptr, ptr %l4, !tbaa !29
  store ptr %t164, ptr %l99, !tbaa !29
  %t165 = load i64, ptr %l14, !tbaa !24
  store i64 %t165, ptr %l100, !tbaa !24
  %t166 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t166, ptr %l101, !tbaa !24
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t167)
  store ptr %t169, ptr %l103
  br label %bb56
bb55:
  br label %bb60
bb56:
  %t170 = load ptr, ptr %l103, !tbaa !29
  %t172 = getelementptr %"compiler/typed:Body", ptr %t170, i32 0, i32 3
  %t173 = load i64, ptr %t172, !tbaa !24
  store i64 %t173, ptr %l105, !tbaa !24
  %t174 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t174, ptr %l106
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l107, !tbaa !29
  %t176 = load ptr, ptr %l2, !tbaa !29
  %t178 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t176)
  store %"compiler/source:Span" %t178, ptr %l109
  br label %bb57
bb57:
  %t179 = load ptr, ptr %l107, !tbaa !29
  %t180 = load %"compiler/source:Span", ptr %l109
  %t181 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s9, ptr %t179, %"compiler/source:Span" %t180)
  store { i64, ptr } %t181, ptr %l110
  br label %bb58
bb58:
  %t182 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 51, ptr getelementptr inbounds (<{ i64, [51 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t184 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 1
  %t186 = extractvalue { i64, ptr } %t184, 0
  %t187 = add i64 %t183, %t186
  %t188 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t191 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t182, i64 %t183)
  %t192 = getelementptr i8, ptr %t191, i64 %t183
  call void @olang_textcopy(ptr %t192, ptr %t185, i64 %t186)
  %t193 = getelementptr i8, ptr %t192, i64 %t186
  call void @olang_textcopy(ptr %t193, ptr %t188, i64 %t189)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t191, 1
  %t197 = extractvalue { i64, ptr } %t195, 0
  %t198 = extractvalue { i64, ptr } %t195, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  %t203 = load ptr, ptr %l99, !tbaa !29
  %t204 = load i64, ptr %l100, !tbaa !24
  %t205 = load i64, ptr %l101, !tbaa !24
  %t206 = load i64, ptr %l105, !tbaa !24
  %t207 = load %"compiler/source:Span", ptr %l106
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s9, ptr %t203, i64 %t204, i64 %t205, i64 %t206, %"compiler/source:Span" %t207, { i64, ptr } %t202)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb61:
  %t209 = load ptr, ptr %l4, !tbaa !29
  %t211 = getelementptr %"compiler/free:Free", ptr %t209, i32 0, i32 42
  store ptr %t211, ptr %l114, !tbaa !29
  %t212 = load i64, ptr %l14, !tbaa !24
  store i64 %t212, ptr %l115, !tbaa !24
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/free:walker", ptr %t213, i32 0, i32 1
  %t216 = load i64, ptr %t215, !tbaa !24
  store i64 %t216, ptr %l117, !tbaa !24
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t217)
  store ptr %t219, ptr %l119
  br label %bb62
bb62:
  %t220 = load ptr, ptr %l119, !tbaa !29
  %t222 = getelementptr %"compiler/typed:Body", ptr %t220, i32 0, i32 3
  %t223 = load i64, ptr %t222, !tbaa !24
  %t224 = load %"compiler/source:Span", ptr %l3
  %t225 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t226 = load ptr, ptr %l2, !tbaa !29
  %t228 = load i64, ptr %l115, !tbaa !24
  %t229 = load i64, ptr %l117, !tbaa !24
  %t234 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v2, ptr %v0, ptr %v0, i64 %t228, i64 %t229, i64 %t223, %"compiler/source:Span" %t224, i64 %t225, i64 -1, i64 -1, ptr %t226, ptr null)
  store %"compiler/free:store" %t234, ptr %l126
  br label %bb63
bb63:
  %t235 = load ptr, ptr %l114, !tbaa !29
  %t236 = load %"compiler/free:store", ptr %l126
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t235, %"compiler/free:store" %t236)
  br label %bb64
bb64:
  %t237 = load ptr, ptr %l4, !tbaa !29
  store ptr %t237, ptr %l127, !tbaa !29
  %t238 = load i64, ptr %l14, !tbaa !24
  store i64 %t238, ptr %l128, !tbaa !24
  %t239 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t239, ptr %l129, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t240)
  store ptr %t242, ptr %l131
  br label %bb65
bb65:
  %t243 = load ptr, ptr %l131, !tbaa !29
  %t245 = getelementptr %"compiler/typed:Body", ptr %t243, i32 0, i32 3
  %t246 = load i64, ptr %t245, !tbaa !24
  store i64 %t246, ptr %l133, !tbaa !24
  %t247 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t247, ptr %l134
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l135, !tbaa !29
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t251 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v2, ptr %t249)
  store %"compiler/source:Span" %t251, ptr %l137
  br label %bb66
bb66:
  %t252 = load ptr, ptr %l135, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l137
  %t254 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s7, ptr %t252, %"compiler/source:Span" %t253)
  store { i64, ptr } %t254, ptr %l138
  br label %bb67
bb67:
  %t255 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 50, ptr getelementptr inbounds (<{ i64, [50 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t257 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t255, i64 %t256)
  %t265 = getelementptr i8, ptr %t264, i64 %t256
  call void @olang_textcopy(ptr %t265, ptr %t258, i64 %t259)
  %t266 = getelementptr i8, ptr %t265, i64 %t259
  call void @olang_textcopy(ptr %t266, ptr %t261, i64 %t262)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t264, 1
  %t270 = extractvalue { i64, ptr } %t268, 0
  %t271 = extractvalue { i64, ptr } %t268, 1
  %t272 = mul i64 %t270, 1
  %t273 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t272)
  call void @llvm.memcpy.p0.p0.i64(ptr %t273, ptr %t271, i64 %t272, i1 false)
  %t274 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr %t273, 1
  %t276 = load ptr, ptr %l127, !tbaa !29
  %t277 = load i64, ptr %l128, !tbaa !24
  %t278 = load i64, ptr %l129, !tbaa !24
  %t279 = load i64, ptr %l133, !tbaa !24
  %t280 = load %"compiler/source:Span", ptr %l134
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s7, ptr %t276, i64 %t277, i64 %t278, i64 %t279, %"compiler/source:Span" %t280, { i64, ptr } %t275)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s7)
  br label %bb69
bb69:
  %t282 = load i64, ptr %l12, !tbaa !24
  %t284 = add i64 %t282, 1
  store i64 %t284, ptr %l12, !tbaa !24
  br label %bb35
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecopyStored(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca i64
  %l18 = alloca i1
  %l20 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l29 = alloca i64
  %l34 = alloca i64
  %l37 = alloca i1
  %l41 = alloca i1
  %l44 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i32
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 4
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store ptr null, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4638628f5b2e3f80_2351d26d56dc1634)
  unreachable
bb15:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:walker", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i64 %t27, ptr %l16
  br label %bb16
bb16:
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = icmp sge i64 %t28, 0
  br i1 %t29, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb22
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/free:walker", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l20, !tbaa !29
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t35)
  store i32 %t37, ptr %l22
  br label %bb19
bb19:
  %t38 = load ptr, ptr %l20, !tbaa !29
  %t39 = load i32, ptr %l22, !tbaa !23
  %t40 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t38, i32 %t39)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l23
  br label %bb20
bb20:
  %t42 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l23)
  store i64 %t42, ptr %l25
  br label %bb21
bb21:
  %t43 = load i64, ptr %l25, !tbaa !24
  %t44 = icmp eq i64 %t43, 0
  store i1 %t44, ptr %l18, !tbaa !21
  br label %bb22
bb22:
  %t46 = load i1, ptr %l18, !tbaa !21
  br i1 %t46, label %bb23, label %bb24
bb23:
  store ptr null, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = call i64 @compiler_2ffree_2eownCopySite(ptr %v2, ptr %t48)
  store i64 %t50, ptr %l29
  br label %bb26
bb26:
  %t51 = load i64, ptr %l29, !tbaa !24
  %t52 = icmp sge i64 %t51, 0
  br i1 %t52, label %bb27, label %bb28
bb27:
  %t54 = load ptr, ptr %l2, !tbaa !29
  store ptr %t54, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v2, ptr %t57)
  store i64 %t59, ptr %l34
  br label %bb30
bb30:
  %t60 = load i64, ptr %l34, !tbaa !24
  store i64 %t60, ptr %l3, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = icmp slt i64 %t61, 0
  br i1 %t63, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb34
bb32:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:walker", ptr %t65, i32 0, i32 33
  %t68 = load i64, ptr %l3, !tbaa !24
  %t71 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %t67, i64 %t68)
  store i1 %t71, ptr %l41
  br label %bb33
bb33:
  %t72 = load i1, ptr %l41, !tbaa !21
  %t73 = xor i1 %t72, true
  store i1 %t73, ptr %l37, !tbaa !21
  br label %bb34
bb34:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb35, label %bb36
bb35:
  store ptr null, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 33
  %t80 = load i64, ptr %l3, !tbaa !24
  %t83 = call { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v3, ptr %t79, i64 %t80)
  %t84 = extractvalue { i32, ptr } %t83, 1
  %t85 = extractvalue { i32, ptr } %t83, 0
  store i32 %t85, ptr %l49
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb39, label %ok.87, !prof !99
ok.87:
  store ptr %t84, ptr %l48
  br label %bb38
bb38:
  %t88 = load ptr, ptr %l48, !tbaa !29
  store ptr %t88, ptr %l44, !tbaa !29
  br label %bb42
bb39:
  %t89 = load i32, ptr %l49, !tbaa !23
  %t90 = icmp eq i32 %t89, 65536
  br i1 %t90, label %bb40, label %bb41
bb40:
  call void @__olang_bang_failed_plain(ptr @olang_loc_95c175a58ff05fe9_ec975816cf48fd1d)
  unreachable
bb41:
  call void @__olang_bang_failed_plain(ptr @olang_loc_c3a39e1a8321cbe9_14cb6b0bd5f3e345)
  unreachable
bb42:
  %t92 = load ptr, ptr %l44, !tbaa !29
  store ptr %t92, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCalls(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t7 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %a2)
  store i32 %t7, ptr %l8
  br label %bb2
bb2:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l10
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l13
  br label %bb3
bb3:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l17
  br label %bb6
bb5:
  %t22 = load i32, ptr %l4, !tbaa !23
  store i32 %t22, ptr %l14, !tbaa !23
  br label %bb7
bb6:
  %t24 = load i32, ptr %l17, !tbaa !23
  store i32 %t24, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l9, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l10
  %t27 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %t25, %"compiler/source:Span" %t26, i32 %t27)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i32
  %l43 = alloca ptr
  %l46 = alloca i64
  %l50 = alloca i1
  %l54 = alloca i1
  %l59 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l15, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eValueParts(ptr %v0, ptr %s1, ptr %t9, i32 %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l18
  br label %bb2
bb2:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  %t16 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  store ptr %t16, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l20, !tbaa !24
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s1, ptr %t19)
  store i64 %t21, ptr %l22
  br label %bb4
bb4:
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = load i64, ptr %l22, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  br label %bb50
bb6:
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s1, ptr %t28, i64 %t29)
  store i32 %t32, ptr %l27
  br label %bb8
bb8:
  %t33 = load i32, ptr %l27, !tbaa !23
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 68
  %t39 = sext i32 %t33 to i64
  %t42 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t36, i64 %t39)
  %t43 = extractvalue { i32, i64 } %t42, 1
  %t44 = extractvalue { i32, i64 } %t42, 0
  store i32 %t44, ptr %l34
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb10, label %ok.46, !prof !99
ok.46:
  store i64 %t43, ptr %l33
  br label %bb9
bb9:
  %t47 = load i64, ptr %l33, !tbaa !24
  store i64 %t47, ptr %l28, !tbaa !24
  br label %bb12
bb10:
  br label %bb11
bb11:
  store i64 -1, ptr %l28, !tbaa !24
  br label %bb12
bb12:
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb13:
  br label %bb49
bb14:
  br label %bb15
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 2
  %t56 = load i1, ptr %t55, !tbaa !21
  %t58 = xor i1 %t56, true
  br i1 %t58, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/free:Free", ptr %t60, i32 0, i32 56
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l43
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:walker", ptr %t67, i32 0, i32 1
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load ptr, ptr %l43, !tbaa !29
  %t73 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t71, i64 %t70)
  store i64 %t73, ptr %l46
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 31
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l50
  br label %bb21
bb21:
  %t81 = load i1, ptr %l50, !tbaa !21
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 2
  %t85 = load i1, ptr %t84, !tbaa !21
  %t87 = xor i1 %t85, true
  br i1 %t87, label %bb24, label %bb25
bb23:
  br label %bb37
bb24:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 31
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  %t98 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t91, i64 %t95)
  store i1 %t98, ptr %l59
  br label %bb26
bb25:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb27
bb26:
  %t99 = load i1, ptr %l59, !tbaa !21
  %t100 = xor i1 %t99, true
  store i1 %t100, ptr %l54, !tbaa !21
  br label %bb27
bb27:
  %t102 = load i1, ptr %l54, !tbaa !21
  br i1 %t102, label %bb28, label %bb29
bb28:
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t105 = getelementptr %"compiler/free:Free", ptr %t103, i32 0, i32 31
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:walker", ptr %t106, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t105, i64 %t109, i1 true)
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t114 = getelementptr %"compiler/free:Free", ptr %t112, i32 0, i32 36
  store i1 true, ptr %t114, !tbaa !21
  br label %bb31
bb31:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/free:walker", ptr %t115, i32 0, i32 2
  %t118 = load i1, ptr %t117, !tbaa !21
  br i1 %t118, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l68, !tbaa !29
  %t121 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t121, ptr %l69, !tbaa !24
  %t122 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t122, ptr %l70, !tbaa !24
  %t123 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t123, ptr %l71
  %t124 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 0, i32 0)
  store %"compiler/source:Span" %t124, ptr %l72
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t125 = load i64, ptr %l8, !tbaa !24
  %t126 = load ptr, ptr %l68, !tbaa !29
  %t127 = load i64, ptr %l69, !tbaa !24
  %t128 = load i64, ptr %l70, !tbaa !24
  %t129 = load %"compiler/source:Span", ptr %l71
  %t130 = load %"compiler/source:Span", ptr %l72
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t126, i64 %t127, i64 %t128, %"compiler/source:Span" %t129, %"compiler/source:Span" %t130, i64 %t125)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  br label %bb49
bb37:
  %t132 = load ptr, ptr %l3, !tbaa !29
  %t134 = getelementptr %"compiler/free:Free", ptr %t132, i32 0, i32 30
  %t135 = load i64, ptr %l8, !tbaa !24
  %t138 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t134, i64 %t135)
  store ptr %t138, ptr %l77
  br label %bb38
bb38:
  %t139 = load ptr, ptr %l77, !tbaa !29
  store ptr %t139, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t140 = load i64, ptr %l10, !tbaa !24
  store i64 %t140, ptr %l78, !tbaa !24
  %t141 = load ptr, ptr %l9, !tbaa !29
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t141)
  store i64 %t143, ptr %l80
  br label %bb40
bb40:
  %t144 = load i64, ptr %l78, !tbaa !24
  %t145 = load i64, ptr %l80, !tbaa !24
  %t146 = icmp slt i64 %t144, %t145
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s9)
  br label %bb48
bb42:
  br label %bb43
bb43:
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t151 = load i64, ptr %l10, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l85
  br label %bb44
bb44:
  %t155 = load i64, ptr %l85, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  store ptr %t156, ptr %l86, !tbaa !29
  store i64 %t155, ptr %l87, !tbaa !24
  %t158 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t158, ptr %l88, !tbaa !24
  %t159 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t159, ptr %l89
  %t160 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s9, i32 0, i32 0)
  store %"compiler/source:Span" %t160, ptr %l90
  br label %bb45
bb45:
  %t161 = load i64, ptr %l8, !tbaa !24
  %t162 = load ptr, ptr %l86, !tbaa !29
  %t163 = load i64, ptr %l87, !tbaa !24
  %t164 = load i64, ptr %l88, !tbaa !24
  %t165 = load %"compiler/source:Span", ptr %l89
  %t166 = load %"compiler/source:Span", ptr %l90
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t162, i64 %t163, i64 %t164, %"compiler/source:Span" %t165, %"compiler/source:Span" %t166, i64 %t161)
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb47:
  %t168 = load i64, ptr %l10, !tbaa !24
  %t170 = add i64 %t168, 1
  store i64 %t170, ptr %l10, !tbaa !24
  br label %bb39
bb48:
  br label %bb49
bb49:
  %t172 = load i64, ptr %l6, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l6, !tbaa !24
  br label %bb3
bb50:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eeval(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/free:leaf"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i1
  %l32 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca %"compiler/source:Span"
  %l40 = alloca %"compiler/source:Span"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca i64
  %l48 = alloca i64
  %l53 = alloca %"compiler/free:leaf"
  %l55 = alloca %"compiler/free:leaf"
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca %"compiler/source:Span"
  %l66 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca i64
  %l80 = alloca i64
  %l83 = alloca ptr
  %l85 = alloca i64
  %l86 = alloca i64
  %l88 = alloca %"compiler/source:Span"
  %l90 = alloca %"compiler/source:Span"
  %l92 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s0, ptr %t1, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l16
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t8 = load ptr, ptr %l17, !tbaa !29
  %t9 = icmp ne ptr %t8, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l17, !tbaa !29
  %t12 = load i64, ptr %t11, !range !{i64 0, i64 18}
  %t14 = icmp eq i64 %t12, 9
  store i1 %t14, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l18, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t17 = load ptr, ptr %l21, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb8, label %bb9
bb8:
  %t20 = load ptr, ptr %l21, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t24 = load i1, ptr %l22, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l4, !tbaa !23
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb33
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t44 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t40, ptr %t41)
  store i64 %t44, ptr %l32
  br label %bb13
bb13:
  %t45 = load i64, ptr %l32, !tbaa !24
  store i64 %t45, ptr %l6, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l35, !tbaa !29
  %t51 = load i64, ptr %l6, !tbaa !24
  store i64 %t51, ptr %l36, !tbaa !24
  %t52 = load i64, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  store i64 %t52, ptr %l37, !tbaa !24
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l39
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:walker", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t60 = load i32, ptr %l4, !tbaa !23
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s5, ptr %t59, i32 %t60)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l44
  br label %bb19
bb16:
  %t64 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t64, ptr %l40
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l35, !tbaa !29
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = load i64, ptr %l37, !tbaa !24
  %t68 = load %"compiler/source:Span", ptr %l39
  %t69 = load %"compiler/source:Span", ptr %l40
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t65, i64 %t66, i64 %t67, %"compiler/source:Span" %t68, %"compiler/source:Span" %t69, i64 -1)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb19:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t71 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  store ptr %t71, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t73 = load i64, ptr %l8, !tbaa !24
  store i64 %t73, ptr %l46, !tbaa !24
  %t74 = load ptr, ptr %l7, !tbaa !29
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s5, ptr %t74)
  store i64 %t76, ptr %l48
  br label %bb21
bb21:
  %t77 = load i64, ptr %l46, !tbaa !24
  %t78 = load i64, ptr %l48, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb23:
  br label %bb24
bb24:
  %t83 = load ptr, ptr %l7, !tbaa !29
  %t84 = load i64, ptr %l8, !tbaa !24
  %t87 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s5, ptr %s5, ptr %t83, i64 %t84)
  store %"compiler/free:leaf" %t87, ptr %l53
  br label %bb25
bb25:
  %t89 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s6, ptr %l53)
  store %"compiler/free:leaf" %t89, ptr %l55
  br label %bb26
bb26:
  %t90 = load %"compiler/free:leaf", ptr %l55
  store %"compiler/free:leaf" %t90, ptr %l9
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l56, !tbaa !29
  %t92 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = load i64, ptr @G_2ecompiler_2ffree_2eLVacate, !tbaa !24
  store i64 %t94, ptr %l58, !tbaa !24
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t97 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t95)
  store %"compiler/source:Span" %t97, ptr %l60
  br label %bb27
bb27:
  %t98 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 0, i32 0)
  store %"compiler/source:Span" %t98, ptr %l61
  br label %bb28
bb28:
  %t99 = load ptr, ptr %l56, !tbaa !29
  %t100 = load i64, ptr %l57, !tbaa !24
  %t101 = load i64, ptr %l58, !tbaa !24
  %t102 = load %"compiler/source:Span", ptr %l60
  %t103 = load %"compiler/source:Span", ptr %l61
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t99, i64 %t100, i64 %t101, %"compiler/source:Span" %t102, %"compiler/source:Span" %t103, i64 -1)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb30:
  %t104 = load i64, ptr %l8, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l8, !tbaa !24
  br label %bb20
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_5c8710160ed2ee88_42fe4478e6ab17dc)
  unreachable
bb38:
  %t108 = load ptr, ptr %l2, !tbaa !29
  %t111 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t108)
  store ptr %t111, ptr %l66
  br label %bb39
bb39:
  %t112 = load ptr, ptr %l66, !tbaa !29
  store ptr %t112, ptr %l10, !tbaa !29
  %t113 = load ptr, ptr %l10, !tbaa !29
  %t115 = icmp eq ptr %t113, null
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb40, label %bb41
bb40:
  store ptr %l3, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb42
bb41:
  br label %bb59
bb42:
  %t120 = load i64, ptr %l12, !tbaa !24
  store i64 %t120, ptr %l71, !tbaa !24
  %t121 = load ptr, ptr %l11, !tbaa !29
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t121)
  store i64 %t123, ptr %l73
  br label %bb43
bb43:
  %t124 = load i64, ptr %l71, !tbaa !24
  %t125 = load i64, ptr %l73, !tbaa !24
  %t126 = icmp slt i64 %t124, %t125
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb44, label %bb45
bb44:
  br label %bb58
bb45:
  br label %bb46
bb46:
  %t130 = load ptr, ptr %l11, !tbaa !29
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t130, i64 %t131)
  store i64 %t134, ptr %l78
  br label %bb47
bb47:
  %t135 = load i64, ptr %l78, !tbaa !24
  store i64 %t135, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l13, !tbaa !24
  %t138 = call i64 @compiler_2ffree_2eokind(i64 %t136)
  store i64 %t138, ptr %l80
  br label %bb48
bb48:
  %t139 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t140 = load i64, ptr %l80, !tbaa !24
  %t142 = icmp eq i64 %t140, %t139
  br i1 %t142, label %bb49, label %bb50
bb49:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l83, !tbaa !29
  %t145 = load i64, ptr %l13, !tbaa !24
  %t147 = call i64 @compiler_2ffree_2eoval(i64 %t145)
  store i64 %t147, ptr %l85
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t148 = load i64, ptr @G_2ecompiler_2ffree_2eLDrop, !tbaa !24
  store i64 %t148, ptr %l86, !tbaa !24
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t149)
  store %"compiler/source:Span" %t151, ptr %l88
  br label %bb52
bb52:
  %t152 = load ptr, ptr %l10, !tbaa !29
  %t154 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t152)
  store %"compiler/source:Span" %t154, ptr %l90
  br label %bb53
bb53:
  %t155 = load ptr, ptr %l10, !tbaa !29
  %t157 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t155)
  store i64 %t157, ptr %l92
  br label %bb54
bb54:
  %t158 = load ptr, ptr %l83, !tbaa !29
  %t159 = load i64, ptr %l85, !tbaa !24
  %t160 = load i64, ptr %l86, !tbaa !24
  %t161 = load %"compiler/source:Span", ptr %l88
  %t162 = load %"compiler/source:Span", ptr %l90
  %t163 = load i64, ptr %l92, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t158, i64 %t159, i64 %t160, %"compiler/source:Span" %t161, %"compiler/source:Span" %t162, i64 %t163)
  br label %bb55
bb55:
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t164 = load i64, ptr %l12, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l12, !tbaa !24
  br label %bb42
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l19 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i1
  %l64 = alloca i64
  %l68 = alloca i64
  %l73 = alloca i64
  %l76 = alloca i1
  %l77 = alloca i64
  %l81 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i1
  %l99 = alloca i1
  %l101 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 16
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l19
  br label %bb4
bb4:
  %t13 = load i64, ptr %l19, !tbaa !24
  store i64 %t13, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l3, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t40 = load i64, ptr %l26, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t41 = load i64, ptr %l23, !tbaa !24
  store i64 %t41, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb12, label %bb13
bb12:
  br label %bb48
bb13:
  br label %bb14
bb14:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l8, !tbaa !24
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/free:walker", ptr %t60, i32 0, i32 16
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t66, ptr %l47
  br label %bb15
bb15:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t68 = load i64, ptr %l47, !tbaa !24
  %t70 = icmp sle i64 %t68, %t67
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = load i64, ptr %l1, !tbaa !24
  store i64 %t72, ptr %l51, !tbaa !24
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 17
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t75, i64 %t76)
  store i64 %t79, ptr %l55
  br label %bb18
bb17:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb19
bb18:
  %t80 = load i64, ptr %l51, !tbaa !24
  %t81 = load i64, ptr %l55, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  store i1 %t82, ptr %l50, !tbaa !21
  br label %bb19
bb19:
  %t84 = load i1, ptr %l50, !tbaa !21
  store i1 %t84, ptr %l9, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 18
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t87, i64 %t88)
  store i64 %t91, ptr %l60
  br label %bb20
bb20:
  %t92 = load i64, ptr %l1, !tbaa !24
  %t93 = load i64, ptr %l60, !tbaa !24
  %t95 = icmp sle i64 %t93, %t92
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %l64, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/free:walker", ptr %t98, i32 0, i32 19
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t100, i64 %t101)
  store i64 %t104, ptr %l68
  br label %bb23
bb22:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb24
bb23:
  %t105 = load i64, ptr %l64, !tbaa !24
  %t106 = load i64, ptr %l68, !tbaa !24
  %t107 = icmp sle i64 %t105, %t106
  store i1 %t107, ptr %l63, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l63, !tbaa !21
  store i1 %t109, ptr %l10, !tbaa !21
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/free:walker", ptr %t110, i32 0, i32 16
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l73
  br label %bb25
bb25:
  %t117 = load i64, ptr %l2, !tbaa !24
  %t118 = load i64, ptr %l73, !tbaa !24
  %t120 = icmp sle i64 %t118, %t117
  br i1 %t120, label %bb26, label %bb27
bb26:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l77, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:walker", ptr %t123, i32 0, i32 17
  %t126 = load i64, ptr %l8, !tbaa !24
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t125, i64 %t126)
  store i64 %t129, ptr %l81
  br label %bb28
bb27:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb29
bb28:
  %t130 = load i64, ptr %l77, !tbaa !24
  %t131 = load i64, ptr %l81, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  store i1 %t132, ptr %l76, !tbaa !21
  br label %bb29
bb29:
  %t134 = load i1, ptr %l76, !tbaa !21
  store i1 %t134, ptr %l11, !tbaa !21
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t135, i32 0, i32 18
  %t138 = load i64, ptr %l8, !tbaa !24
  %t141 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t137, i64 %t138)
  store i64 %t141, ptr %l86
  br label %bb30
bb30:
  %t142 = load i64, ptr %l2, !tbaa !24
  %t143 = load i64, ptr %l86, !tbaa !24
  %t145 = icmp sle i64 %t143, %t142
  br i1 %t145, label %bb31, label %bb32
bb31:
  %t147 = load i64, ptr %l2, !tbaa !24
  store i64 %t147, ptr %l90, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/free:walker", ptr %t148, i32 0, i32 19
  %t151 = load i64, ptr %l8, !tbaa !24
  %t154 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t150, i64 %t151)
  store i64 %t154, ptr %l94
  br label %bb33
bb32:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb34
bb33:
  %t155 = load i64, ptr %l90, !tbaa !24
  %t156 = load i64, ptr %l94, !tbaa !24
  %t157 = icmp sle i64 %t155, %t156
  store i1 %t157, ptr %l89, !tbaa !21
  br label %bb34
bb34:
  %t159 = load i1, ptr %l89, !tbaa !21
  store i1 %t159, ptr %l12, !tbaa !21
  %t160 = load i1, ptr %l9, !tbaa !21
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load i1, ptr %l12, !tbaa !21
  store i1 %t162, ptr %l97, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb37
bb37:
  %t164 = load i1, ptr %l97, !tbaa !21
  br i1 %t164, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb43
bb39:
  %t165 = load i1, ptr %l10, !tbaa !21
  br i1 %t165, label %bb40, label %bb41
bb40:
  %t167 = load i1, ptr %l11, !tbaa !21
  store i1 %t167, ptr %l101, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb42
bb42:
  %t169 = load i1, ptr %l101, !tbaa !21
  store i1 %t169, ptr %l99, !tbaa !21
  br label %bb43
bb43:
  %t170 = load i1, ptr %l99, !tbaa !21
  br i1 %t170, label %bb44, label %bb45
bb44:
  store i1 true, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t172 = load i64, ptr %l7, !tbaa !24
  %t174 = add i64 %t172, 1
  store i64 %t174, ptr %l7, !tbaa !24
  br label %bb11
bb48:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca i1
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i1
  %l50 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca i64
  %l95 = alloca i1
  %l98 = alloca i1
  %l99 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 -1, ptr %l2, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l3, !tbaa !23
  %t18 = sext i32 %t16 to i64
  store i64 %t18, ptr %l2, !tbaa !24
  br label %bb54
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t24 = load ptr, ptr %l17, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 8}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l4, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t39 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store i64 %t39, ptr %l25
  br label %bb12
bb12:
  %t40 = load i64, ptr %l25, !tbaa !24
  store i64 %t40, ptr %rv
  br label %ret
bb13:
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t43 = icmp ne ptr %t42, null
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = load i64, ptr %t45, !range !{i64 0, i64 8}
  %t48 = icmp eq i64 %t46, 4
  store i1 %t48, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l27, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr { i64, [4 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l5, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l5, !tbaa !29
  %t59 = getelementptr %"compiler/typed:Elem", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t63 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t56, ptr %t60)
  store i64 %t63, ptr %l35
  br label %bb19
bb19:
  %t64 = load i64, ptr %l35, !tbaa !24
  store i64 %t64, ptr %rv
  br label %ret
bb20:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t66 = load ptr, ptr %l36, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l36, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 8}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l37, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l6, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l6, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Payload", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t87 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshRoot(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  store i64 %t87, ptr %l45
  br label %bb26
bb26:
  %t88 = load i64, ptr %l45, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
bb27:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb28, label %bb29
bb28:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 8}
  %t96 = icmp eq i64 %t94, 2
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb29
bb29:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb30, label %bb31
bb30:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t100, i32 0, i32 2
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb32, label %bb33
bb31:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb39
bb32:
  %t106 = load ptr, ptr %l52, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 18}
  %t109 = icmp eq i64 %t107, 2
  store i1 %t109, ptr %l53, !tbaa !21
  br label %bb33
bb33:
  %t110 = load i1, ptr %l53, !tbaa !21
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  %t117 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t117, i32 0, i32 2
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t120 = load ptr, ptr %l59, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb36, label %bb37
bb35:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb38
bb36:
  %t123 = load ptr, ptr %l59, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 8}
  %t126 = icmp eq i64 %t124, 0
  store i1 %t126, ptr %l60, !tbaa !21
  br label %bb37
bb37:
  %t127 = load i1, ptr %l60, !tbaa !21
  store i1 %t127, ptr %l56, !tbaa !21
  br label %bb38
bb38:
  %t128 = load i1, ptr %l56, !tbaa !21
  store i1 %t128, ptr %l50, !tbaa !21
  br label %bb39
bb39:
  %t129 = load i1, ptr %l50, !tbaa !21
  br i1 %t129, label %bb40, label %bb41
bb40:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  %t140 = getelementptr { i64, [4 x i64] }, ptr %t138, i32 0, i32 1
  %t141 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t140, i32 0, i32 2
  %t142 = load i32, ptr %t141
  store i32 %t142, ptr %l7, !tbaa !23
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t144 = load i32, ptr %l7, !tbaa !23
  %t146 = sext i32 %t144 to i64
  store i64 %t146, ptr %l2, !tbaa !24
  br label %bb54
bb43:
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t149 = load ptr, ptr %l69, !tbaa !29
  %t150 = icmp ne ptr %t149, null
  br i1 %t150, label %bb44, label %bb45
bb44:
  %t152 = load ptr, ptr %l69, !tbaa !29
  %t153 = load i64, ptr %t152, !range !{i64 0, i64 8}
  %t155 = icmp eq i64 %t153, 2
  store i1 %t155, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  %t156 = load i1, ptr %l70, !tbaa !21
  br i1 %t156, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  store i64 -1, ptr %rv
  br label %ret
bb53:
  call void @__olang_check_failed(ptr @olang_loc_e32699ce7a94654a_1a46213a714ace46)
  unreachable
bb54:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 6
  %t162 = load i64, ptr %l2, !tbaa !24
  %t165 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l78
  br label %bb55
bb55:
  %t166 = load i1, ptr %l78, !tbaa !21
  br i1 %t166, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb59
bb57:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:walker", ptr %t167, i32 0, i32 7
  %t170 = load i64, ptr %l2, !tbaa !24
  %t173 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t169, i64 %t170)
  store i1 %t173, ptr %l83
  br label %bb58
bb58:
  %t174 = load i1, ptr %l83, !tbaa !21
  store i1 %t174, ptr %l79, !tbaa !21
  br label %bb59
bb59:
  %t175 = load i1, ptr %l79, !tbaa !21
  br i1 %t175, label %bb60, label %bb61
bb60:
  store i64 -1, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 0
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t182 = getelementptr %"compiler/free:Free", ptr %t180, i32 0, i32 55
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:walker", ptr %t183, i32 0, i32 1
  %t186 = load i64, ptr %t185, !tbaa !24
  %t189 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_Ha64a825bb0b4fc6c7596ac96329c2853(ptr %v0, ptr %v0, ptr %t182, i64 %t186)
  store ptr %t189, ptr %l90
  br label %bb63
bb63:
  %t190 = load ptr, ptr %l90, !tbaa !29
  store ptr %t190, ptr %l8, !tbaa !29
  %t191 = load i64, ptr %l2, !tbaa !24
  store i64 %t191, ptr %l91, !tbaa !24
  %t192 = load ptr, ptr %l8, !tbaa !29
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l93
  br label %bb64
bb64:
  %t195 = load i64, ptr %l91, !tbaa !24
  %t196 = load i64, ptr %l93, !tbaa !24
  %t197 = icmp slt i64 %t195, %t196
  br i1 %t197, label %bb65, label %bb66
bb65:
  %t199 = load ptr, ptr %l8, !tbaa !29
  %t200 = load i64, ptr %l2, !tbaa !24
  %t203 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t199, i64 %t200)
  store i1 %t203, ptr %l98
  br label %bb67
bb66:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb68
bb67:
  %t204 = load i1, ptr %l98, !tbaa !21
  store i1 %t204, ptr %l95, !tbaa !21
  br label %bb68
bb68:
  %t205 = load i1, ptr %l95, !tbaa !21
  br i1 %t205, label %bb69, label %bb70
bb69:
  %t206 = load i64, ptr %l2, !tbaa !24
  store i64 %t206, ptr %l99, !tbaa !24
  br label %bb71
bb70:
  store i64 -1, ptr %l99, !tbaa !24
  br label %bb71
bb71:
  %t208 = load i64, ptr %l99, !tbaa !24
  store i64 %t208, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca i64
  %l42 = alloca ptr
  %l46 = alloca i1
  %l49 = alloca i64
  %l51 = alloca i64
  %l53 = alloca ptr
  %l56 = alloca i64
  %l58 = alloca i64
  %l74 = alloca i1
  %l78 = alloca i1
  %l83 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca i64
  %l96 = alloca i64
  %l98 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca %"compiler/source:Span"
  %l104 = alloca i64
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca i64
  %l110 = alloca i1
  %l112 = alloca i1
  %l113 = alloca %"compiler/free:letGo"
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb2:
  br label %bb15
bb3:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 31
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:walker", ptr %t20, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  %t26 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t19, i64 %t23)
  store i1 %t26, ptr %l19
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb6
bb5:
  %t27 = load i1, ptr %l19, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t31 = load ptr, ptr %l6, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 30
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  %t40 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t33, i64 %t37)
  store ptr %t40, ptr %l26
  br label %bb9
bb8:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb9:
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load ptr, ptr %l26, !tbaa !29
  %t44 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t42, i64 %t41)
  store i64 %t44, ptr %l28
  br label %bb10
bb10:
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = icmp sgt i64 %t45, 0
  store i1 %t46, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t48 = load i1, ptr %l21, !tbaa !21
  br i1 %t48, label %bb12, label %bb13
bb12:
  %t49 = load ptr, ptr %l6, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 36
  store i1 true, ptr %t51, !tbaa !21
  br label %bb14
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 29
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp sgt i64 %t55, 0
  br i1 %t57, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  br label %bb18
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t59, i32 0, i32 44
  %t62 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  br label %bb19
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:walker", ptr %t65, i32 0, i32 45
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 12
  %t71 = load i64, ptr %t70, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t67, i64 %t71)
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 36
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load i64, ptr %l2, !tbaa !24
  %t78 = load i64, ptr @G_2ecompiler_2ffree_2eLHeld, !tbaa !24
  %t81 = icmp eq i64 %t77, %t78
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 54
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l49
  br label %bb23
bb22:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb24
bb23:
  %t88 = load i64, ptr %l49, !tbaa !24
  %t89 = icmp sgt i64 %t88, 0
  store i1 %t89, ptr %l46, !tbaa !21
  br label %bb24
bb24:
  %t91 = load i1, ptr %l46, !tbaa !21
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:walker", ptr %t92, i32 0, i32 54
  store ptr %t94, ptr %l53, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/free:walker", ptr %t95, i32 0, i32 54
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t97)
  store i64 %t99, ptr %l56
  br label %bb27
bb26:
  store i64 -1, ptr %l51, !tbaa !24
  br label %bb29
bb27:
  %t100 = load i64, ptr %l56, !tbaa !24
  %t101 = sub i64 %t100, 1
  %t102 = load ptr, ptr %l53, !tbaa !29
  %t104 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t102, i64 %t101)
  store i64 %t104, ptr %l58
  br label %bb28
bb28:
  %t105 = load i64, ptr %l58, !tbaa !24
  store i64 %t105, ptr %l51, !tbaa !24
  br label %bb29
bb29:
  %t106 = load ptr, ptr %l42, !tbaa !29
  %t107 = load i64, ptr %l51, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t106, i64 %t107)
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:walker", ptr %t108, i32 0, i32 46
  %t111 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t110, i64 %t111)
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/free:walker", ptr %t114, i32 0, i32 47
  %t117 = load %"compiler/source:Span", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t116, %"compiler/source:Span" %t117)
  br label %bb32
bb32:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/free:walker", ptr %t120, i32 0, i32 48
  %t123 = load %"compiler/source:Span", ptr %l4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t122, %"compiler/source:Span" %t123)
  br label %bb33
bb33:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/free:walker", ptr %t126, i32 0, i32 49
  %t129 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t128, i64 %t129)
  br label %bb34
bb34:
  %t132 = load i64, ptr %l2, !tbaa !24
  %t133 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  %t136 = icmp eq i64 %t132, %t133
  br i1 %t136, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb41
bb36:
  %t138 = load i64, ptr %l2, !tbaa !24
  %t139 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t142 = icmp eq i64 %t138, %t139
  br i1 %t142, label %bb37, label %bb38
bb37:
  %t144 = load ptr, ptr %l6, !tbaa !29
  %t146 = getelementptr %"compiler/free:Free", ptr %t144, i32 0, i32 22
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:walker", ptr %t147, i32 0, i32 1
  %t150 = load i64, ptr %t149, !tbaa !24
  %t153 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t146, i64 %t150)
  store i1 %t153, ptr %l83
  br label %bb39
bb38:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb40
bb39:
  %t154 = load i1, ptr %l83, !tbaa !21
  %t155 = xor i1 %t154, true
  store i1 %t155, ptr %l78, !tbaa !21
  br label %bb40
bb40:
  %t157 = load i1, ptr %l78, !tbaa !21
  store i1 %t157, ptr %l74, !tbaa !21
  br label %bb41
bb41:
  %t158 = load i1, ptr %l74, !tbaa !21
  br i1 %t158, label %bb42, label %bb43
bb42:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:walker", ptr %t159, i32 0, i32 50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t161, i64 -1)
  br label %bb44
bb43:
  br label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/free:walker", ptr %t163, i32 0, i32 50
  store ptr %t165, ptr %l88, !tbaa !29
  %t166 = load ptr, ptr %l6, !tbaa !29
  %t168 = getelementptr %"compiler/free:Free", ptr %t166, i32 0, i32 43
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t168)
  store i64 %t170, ptr %l91
  br label %bb46
bb46:
  %t171 = load ptr, ptr %l88, !tbaa !29
  %t172 = load i64, ptr %l91, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  br label %bb47
bb47:
  %t173 = load ptr, ptr %l6, !tbaa !29
  %t175 = getelementptr %"compiler/free:Free", ptr %t173, i32 0, i32 43
  store ptr %t175, ptr %l93, !tbaa !29
  %t176 = load i64, ptr %l1, !tbaa !24
  store i64 %t176, ptr %l94, !tbaa !24
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 1
  %t180 = load i64, ptr %t179, !tbaa !24
  store i64 %t180, ptr %l96, !tbaa !24
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t181)
  store ptr %t183, ptr %l98
  br label %bb48
bb48:
  %t184 = load ptr, ptr %l98, !tbaa !29
  %t186 = getelementptr %"compiler/typed:Body", ptr %t184, i32 0, i32 3
  %t187 = load i64, ptr %t186, !tbaa !24
  store i64 %t187, ptr %l100, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:walker", ptr %t188, i32 0, i32 41
  %t191 = load %"compiler/source:Span", ptr %t190
  store %"compiler/source:Span" %t191, ptr %l102
  %t192 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t192, ptr %l103
  %t193 = load i64, ptr %l2, !tbaa !24
  store i64 %t193, ptr %l104, !tbaa !24
  %t194 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t194, ptr %l105
  %t195 = load i64, ptr %l5, !tbaa !24
  store i64 %t195, ptr %l106, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/free:walker", ptr %t196, i32 0, i32 23
  %t199 = load i64, ptr %t198, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb52
bb50:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erunsAgain(ptr %v0, ptr %t203)
  store i1 %t205, ptr %l112
  br label %bb51
bb51:
  %t206 = load i1, ptr %l112, !tbaa !21
  store i1 %t206, ptr %l110, !tbaa !21
  br label %bb52
bb52:
  %t207 = load i64, ptr %l94, !tbaa !24
  %t208 = load i64, ptr %l96, !tbaa !24
  %t209 = load i64, ptr %l100, !tbaa !24
  %t210 = load %"compiler/source:Span", ptr %l102
  %t211 = load %"compiler/source:Span", ptr %l103
  %t212 = load i64, ptr %l104, !tbaa !24
  %t213 = load %"compiler/source:Span", ptr %l105
  %t214 = load i64, ptr %l106, !tbaa !24
  %t215 = load i1, ptr %l110, !tbaa !21
  %t216 = call %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %s0, i64 %t207, i64 %t208, i64 %t209, %"compiler/source:Span" %t210, %"compiler/source:Span" %t211, i64 %t212, %"compiler/source:Span" %t213, i64 %t214, i1 %t215)
  store %"compiler/free:letGo" %t216, ptr %l113
  br label %bb53
bb53:
  %t217 = load ptr, ptr %l93, !tbaa !29
  %t218 = load %"compiler/free:letGo", ptr %l113
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2ePush_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t217, %"compiler/free:letGo" %t218)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 2
  %t9 = load i1, ptr %t8, !tbaa !21
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 31
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t15, i64 %t19)
  store i1 %t22, ptr %l14
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t23 = load i1, ptr %l14, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 31
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t28, i64 %t32, i1 true)
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/free:Free", ptr %t35, i32 0, i32 36
  store i1 true, ptr %t37, !tbaa !21
  br label %bb7
bb7:
  br label %ret
bb8:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l21, !tbaa !29
  %t39 = load i64, ptr @G_2ecompiler_2ffree_2eAnyPlace, !tbaa !24
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t40, ptr %l23, !tbaa !24
  store %"compiler/source:Span" %a1, ptr %l24
  %t44 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %a2)
  store %"compiler/source:Span" %t44, ptr %l26
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l21, !tbaa !29
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = load i64, ptr %l23, !tbaa !24
  %t49 = load %"compiler/source:Span", ptr %l24
  %t50 = load %"compiler/source:Span", ptr %l26
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t46, i64 %t47, i64 %t48, %"compiler/source:Span" %t49, %"compiler/source:Span" %t50, i64 %a3)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l11 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i64
  %l25 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i64
  %l38 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t8 = sext i32 %t6 to i64
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb1, label %bb2
bb1:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t14)
  store ptr %t16, ptr %l11
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t17 = load i32, ptr %l1, !tbaa !23
  %t18 = load ptr, ptr %l11, !tbaa !29
  %t20 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t18, i32 %t17)
  store i1 %t20, ptr %l13
  br label %bb4
bb4:
  %t21 = load i1, ptr %l13, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 5
  %t26 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l16
  br label %bb7
bb7:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l16, !tbaa !24
  %t30 = icmp sle i64 %t28, %t27
  %t32 = xor i1 %t30, true
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t36, i64 0)
  br label %bb11
bb11:
  br label %bb12
bb12:
  br label %bb6
bb13:
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 5
  %t41 = load i64, ptr %l3, !tbaa !24
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l25
  br label %bb14
bb14:
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = icmp eq i64 %t45, 0
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/free:Free", ptr %t48, i32 0, i32 5
  store ptr %t50, ptr %l28, !tbaa !29
  %t51 = load i64, ptr %l3, !tbaa !24
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t52)
  store ptr %t54, ptr %l31
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t55 = load i32, ptr %l1, !tbaa !23
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t58 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t56, i32 %t55)
  store i1 %t58, ptr %l33
  br label %bb18
bb18:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  store i64 2, ptr %l34, !tbaa !24
  br label %bb21
bb20:
  store i64 1, ptr %l34, !tbaa !24
  br label %bb21
bb21:
  %t60 = load ptr, ptr %l28, !tbaa !29
  %t61 = load i64, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61, i64 %t62)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t63 = load ptr, ptr %l2, !tbaa !29
  %t65 = getelementptr %"compiler/free:Free", ptr %t63, i32 0, i32 5
  %t66 = load i64, ptr %l3, !tbaa !24
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  store i64 %t69, ptr %l38
  br label %bb24
bb24:
  %t70 = load i64, ptr %l38, !tbaa !24
  %t71 = icmp eq i64 %t70, 2
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca { i64, { i64, ptr } }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l31 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca ptr
  %l45 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i64
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca i64
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca i1
  %l118 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l129 = alloca i64
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l140 = alloca i64
  %l142 = alloca i64
  %l143 = alloca { i64, ptr }
  %l146 = alloca { i64, { i64, ptr } }
  %l148 = alloca { i64, ptr }
  %l150 = alloca i64
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l158 = alloca i1
  %l161 = alloca ptr
  %l165 = alloca i64
  %l167 = alloca i64
  %l170 = alloca i1
  %l174 = alloca ptr
  %l179 = alloca i1
  %l183 = alloca i64
  %l193 = alloca ptr
  %l195 = alloca %"compiler/source:Span"
  %l196 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l199 = alloca i64
  %l204 = alloca i1
  %l208 = alloca i1
  %l209 = alloca i1
  %l212 = alloca i1
  %l214 = alloca i1
  %l216 = alloca i1
  %l219 = alloca ptr
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l225 = alloca i64
  %l230 = alloca i1
  %l233 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca i64
  %l238 = alloca i64
  %l239 = alloca { i64, ptr }
  %l243 = alloca i1
  %l248 = alloca i1
  %l251 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l254 = alloca i64
  %l256 = alloca i64
  %l257 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l270 = alloca %"compiler/free:store"
  %s0 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l31
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l31, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 3
  %t12 = load i64, ptr %t11, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  store i64 -1, ptr %l8, !tbaa !24
  store i64 -1, ptr %l9, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %l35, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t16, ptr %l36, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l37, !tbaa !24
  %t19 = load i64, ptr %l37, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l38, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l37, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t30, ptr %l10, !tbaa !27
  %t31 = load ptr, ptr %l2, !tbaa !29
  store ptr %t31, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t32 = load ptr, ptr %l39, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb2, label %bb3
bb2:
  %t35 = load ptr, ptr %l39, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 0
  store i1 %t38, ptr %l40, !tbaa !21
  br label %bb3
bb3:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  br label %bb111
bb7:
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l44, !tbaa !29
  store i1 false, ptr %l45, !tbaa !21
  %t43 = load ptr, ptr %l44, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb8, label %bb9
bb8:
  %t46 = load ptr, ptr %l44, !tbaa !29
  %t47 = load i64, ptr %t46, !range !{i64 0, i64 18}
  %t49 = icmp eq i64 %t47, 1
  store i1 %t49, ptr %l45, !tbaa !21
  br label %bb9
bb9:
  %t50 = load i1, ptr %l45, !tbaa !21
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t51 = load i64, ptr @G_2ecompiler_2ffree_2eSOk, !tbaa !24
  store i64 %t51, ptr %l7, !tbaa !24
  br label %bb111
bb13:
  %t53 = load ptr, ptr %l2, !tbaa !29
  store ptr %t53, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t54 = load ptr, ptr %l49, !tbaa !29
  %t55 = icmp ne ptr %t54, null
  br i1 %t55, label %bb14, label %bb15
bb14:
  %t57 = load ptr, ptr %l49, !tbaa !29
  %t58 = load i64, ptr %t57, !range !{i64 0, i64 18}
  %t60 = icmp eq i64 %t58, 4
  store i1 %t60, ptr %l50, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l50, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr { i64, [5 x i64] }, ptr %t62, i32 0, i32 1
  %t65 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t64, i32 0, i32 2
  %t66 = load ptr, ptr %t65
  store ptr %t66, ptr %l11, !tbaa !29
  br label %bb18
bb17:
  br label %bb26
bb18:
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t69 = load ptr, ptr %l11, !tbaa !29
  %t72 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i64 %t72, ptr %l57
  br label %bb19
bb19:
  %t73 = load i64, ptr %l57, !tbaa !24
  store i64 %t73, ptr %l12, !tbaa !24
  %t74 = load i64, ptr %l12, !tbaa !24
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = icmp eq i64 %t74, %t75
  br i1 %t78, label %bb20, label %bb21
bb20:
  %t80 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l12, !tbaa !24
  store i64 %t82, ptr %l8, !tbaa !24
  br label %bb25
bb21:
  store { i64, ptr } { i64 43, ptr getelementptr inbounds (<{ i64, [43 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %l63, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t84, ptr %l64, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l66, !tbaa !24
  %t90 = load i64, ptr %l66, !tbaa !24
  %t91 = icmp eq i64 %t86, %t90
  br i1 %t91, label %bb22, label %bb23
bb22:
  %t93 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = load i64, ptr %l66, !tbaa !24
  %t98 = mul i64 %t97, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %t96, i64 %t98, i1 false)
  br label %bb24
bb23:
  %t99 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  store i64 %t100, ptr %l68, !tbaa !24
  %t101 = load i64, ptr %l68, !tbaa !24
  %t102 = mul i64 %t101, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  %t104 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  store { i64, ptr } %t105, ptr %l69, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = load i64, ptr %l68, !tbaa !24
  %t111 = mul i64 %t110, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t107, ptr %t109, i64 %t111, i1 false)
  %t112 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t112, ptr %l10, !tbaa !27
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb111
bb26:
  %t113 = load ptr, ptr %l2, !tbaa !29
  store ptr %t113, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t114 = load ptr, ptr %l70, !tbaa !29
  %t115 = icmp ne ptr %t114, null
  br i1 %t115, label %bb27, label %bb28
bb27:
  %t117 = load ptr, ptr %l70, !tbaa !29
  %t118 = load i64, ptr %t117, !range !{i64 0, i64 18}
  %t120 = icmp eq i64 %t118, 17
  store i1 %t120, ptr %l71, !tbaa !21
  br label %bb28
bb28:
  %t121 = load i1, ptr %l71, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t124, i32 0, i32 2
  %t126 = load ptr, ptr %t125
  store ptr %t126, ptr %l13, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  %t130 = load ptr, ptr %l13, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l3
  %t132 = load i1, ptr %l4, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t128, i64 %t129, ptr %t130, %"compiler/source:Span" %t131, i1 %t132)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb33:
  %t138 = load ptr, ptr %l2, !tbaa !29
  store ptr %t138, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t139 = load ptr, ptr %l81, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb34, label %bb35
bb34:
  %t142 = load ptr, ptr %l81, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 18}
  %t145 = icmp eq i64 %t143, 12
  store i1 %t145, ptr %l82, !tbaa !21
  br label %bb35
bb35:
  %t146 = load i1, ptr %l82, !tbaa !21
  br i1 %t146, label %bb36, label %bb37
bb36:
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l14, !tbaa !29
  br label %bb38
bb37:
  br label %bb46
bb38:
  %t153 = load ptr, ptr %l14, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Seq", ptr %t153, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t158 = icmp eq ptr %t156, null
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb39, label %bb40
bb39:
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l91, !tbaa !29
  %t163 = load i64, ptr %l1, !tbaa !24
  store i64 %t163, ptr %l92, !tbaa !24
  %t164 = load ptr, ptr %l14, !tbaa !29
  %t166 = getelementptr %"compiler/typed:Seq", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  br i1 %t169, label %bb41, label %bb42
bb40:
  br label %bb45
bb41:
  call void @__olang_check_failed(ptr @olang_loc_7676aaa4af173342_5bef0e3278c42ba6)
  unreachable
bb42:
  br label %bb43
bb43:
  %t171 = load ptr, ptr %l14, !tbaa !29
  %t173 = getelementptr %"compiler/typed:Seq", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l3
  %t176 = load i1, ptr %l4, !tbaa !21
  %t177 = load ptr, ptr %l91, !tbaa !29
  %t178 = load i64, ptr %l92, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t177, i64 %t178, ptr %t174, %"compiler/source:Span" %t175, i1 %t176)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb111
bb46:
  %t182 = load ptr, ptr %l2, !tbaa !29
  store ptr %t182, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t183 = load ptr, ptr %l100, !tbaa !29
  %t184 = icmp ne ptr %t183, null
  br i1 %t184, label %bb47, label %bb48
bb47:
  %t186 = load ptr, ptr %l100, !tbaa !29
  %t187 = load i64, ptr %t186, !range !{i64 0, i64 18}
  %t189 = icmp eq i64 %t187, 14
  store i1 %t189, ptr %l101, !tbaa !21
  br label %bb48
bb48:
  %t190 = load i1, ptr %l101, !tbaa !21
  br i1 %t190, label %bb49, label %bb50
bb49:
  %t191 = load ptr, ptr %l2, !tbaa !29
  %t193 = getelementptr { i64, [5 x i64] }, ptr %t191, i32 0, i32 1
  %t194 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t193, i32 0, i32 2
  %t195 = load ptr, ptr %t194
  store ptr %t195, ptr %l15, !tbaa !29
  br label %bb51
bb50:
  br label %bb71
bb51:
  %t197 = load ptr, ptr %l15, !tbaa !29
  %t199 = getelementptr %"compiler/typed:Try", ptr %t197, i32 0, i32 0
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = icmp eq ptr %t200, null
  %t204 = xor i1 %t202, true
  store i1 %t204, ptr %l16, !tbaa !21
  %t206 = load ptr, ptr %l15, !tbaa !29
  %t208 = getelementptr %"compiler/typed:Try", ptr %t206, i32 0, i32 1
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t211 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t211, 0
  store i64 %t213, ptr %l19, !tbaa !24
  br label %bb52
bb52:
  %t215 = load i64, ptr %l18, !tbaa !24
  %t216 = load i64, ptr %l19, !tbaa !24
  %t219 = icmp slt i64 %t215, %t216
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb53, label %bb54
bb53:
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t223 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t223, ptr %l118, !tbaa !27
  %t224 = load i64, ptr %l18, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr ptr, ptr %t227, i64 %t224
  %t229 = load ptr, ptr %t228, !tbaa !39
  %t233 = getelementptr %"compiler/typed:Clause", ptr %t229, i32 0, i32 4
  %t234 = load { i64, ptr }, ptr %t233, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t234, 0
  %t238 = icmp sgt i64 %t236, 0
  br i1 %t238, label %bb56, label %bb57
bb56:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb58
bb57:
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t240 = load i64, ptr %l18, !tbaa !24
  %t242 = add i64 %t240, 1
  store i64 %t242, ptr %l18, !tbaa !24
  br label %bb52
bb60:
  %t244 = load i1, ptr %l16, !tbaa !21
  br i1 %t244, label %bb61, label %bb62
bb61:
  %t246 = load ptr, ptr %l0, !tbaa !29
  store ptr %t246, ptr %l128, !tbaa !29
  %t247 = load i64, ptr %l1, !tbaa !24
  store i64 %t247, ptr %l129, !tbaa !24
  %t248 = load ptr, ptr %l15, !tbaa !29
  %t250 = getelementptr %"compiler/typed:Try", ptr %t248, i32 0, i32 0
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = icmp eq ptr %t251, null
  br i1 %t253, label %bb63, label %bb64
bb62:
  br label %bb67
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a47d70a6f4791f29_9aa1d88f57dbf58d)
  unreachable
bb64:
  br label %bb65
bb65:
  %t255 = load ptr, ptr %l15, !tbaa !29
  %t257 = getelementptr %"compiler/typed:Try", ptr %t255, i32 0, i32 0
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l3
  %t260 = load i1, ptr %l4, !tbaa !21
  %t261 = load ptr, ptr %l128, !tbaa !29
  %t262 = load i64, ptr %l129, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %t261, i64 %t262, ptr %t258, %"compiler/source:Span" %t259, i1 %t260)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb67:
  store { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d65, i32 0, i32 1) }, ptr %l137, !tbaa !27
  %t266 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t266, ptr %l138, !tbaa !27
  %t267 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 0
  %t269 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l140, !tbaa !24
  %t272 = load i64, ptr %l140, !tbaa !24
  %t273 = icmp eq i64 %t268, %t272
  br i1 %t273, label %bb68, label %bb69
bb68:
  %t275 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = load i64, ptr %l140, !tbaa !24
  %t280 = mul i64 %t279, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %t278, i64 %t280, i1 false)
  br label %bb70
bb69:
  %t281 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t281, 0
  store i64 %t282, ptr %l142, !tbaa !24
  %t283 = load i64, ptr %l142, !tbaa !24
  %t284 = mul i64 %t283, 1
  %t285 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t284)
  %t286 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l143, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = load i64, ptr %l142, !tbaa !24
  %t293 = mul i64 %t292, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t289, ptr %t291, i64 %t293, i1 false)
  %t294 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t294, ptr %l10, !tbaa !27
  br label %bb70
bb70:
  br label %bb111
bb71:
  br i1 true, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb110
bb74:
  store %olang.scope zeroinitializer, ptr %s15
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l2, !tbaa !29
  %t299 = call { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %s15, ptr %t295, ptr %t296)
  store { i64, { i64, ptr } } %t299, ptr %l146
  br label %bb75
bb75:
  %t300 = load { i64, { i64, ptr } }, ptr %l146
  store { i64, { i64, ptr } } %t300, ptr %l21
  %t301 = getelementptr { i64, { i64, ptr } }, ptr %l21, i32 0, i32 0
  %t302 = load i64, ptr %t301, !tbaa !24
  store i64 %t302, ptr %l9, !tbaa !24
  %t304 = getelementptr { i64, { i64, ptr } }, ptr %l21, i32 0, i32 1
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  store { i64, ptr } %t305, ptr %l148, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t307 = extractvalue { i64, ptr } %t306, 0
  %t308 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  store i64 %t309, ptr %l150, !tbaa !24
  %t311 = load i64, ptr %l150, !tbaa !24
  %t312 = icmp eq i64 %t307, %t311
  br i1 %t312, label %bb76, label %bb77
bb76:
  %t314 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = load i64, ptr %l150, !tbaa !24
  %t319 = mul i64 %t318, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t315, ptr %t317, i64 %t319, i1 false)
  br label %bb78
bb77:
  %t320 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  store i64 %t321, ptr %l152, !tbaa !24
  %t322 = load i64, ptr %l152, !tbaa !24
  %t323 = mul i64 %t322, 1
  %t324 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t323)
  %t325 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  store { i64, ptr } %t326, ptr %l153, !tbaa !27
  %t327 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = load i64, ptr %l152, !tbaa !24
  %t332 = mul i64 %t331, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t328, ptr %t330, i64 %t332, i1 false)
  %t333 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t333, ptr %l10, !tbaa !27
  br label %bb78
bb78:
  %t334 = load i64, ptr %l9, !tbaa !24
  %t336 = icmp sge i64 %t334, 0
  br i1 %t336, label %bb79, label %bb80
bb79:
  %t338 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  store i64 %t338, ptr %l7, !tbaa !24
  br label %bb109
bb80:
  store %olang.scope zeroinitializer, ptr %s17
  %t340 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t342 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s17, { i64, ptr } %t340, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t342, ptr %l158
  br label %bb81
bb81:
  %t343 = load i1, ptr %l158, !tbaa !21
  br i1 %t343, label %bb82, label %bb83
bb82:
  %t344 = load ptr, ptr %l2, !tbaa !29
  %t347 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t344)
  store ptr %t347, ptr %l161
  br label %bb84
bb83:
  br label %bb108
bb84:
  %t348 = load ptr, ptr %l161, !tbaa !29
  store ptr %t348, ptr %l22, !tbaa !29
  %t349 = load ptr, ptr %l22, !tbaa !29
  %t351 = icmp eq ptr %t349, null
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb85, label %bb86
bb85:
  %t355 = load ptr, ptr %l22, !tbaa !29
  %t357 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t355)
  store i64 %t357, ptr %l167
  br label %bb87
bb86:
  store i64 -1, ptr %l165, !tbaa !24
  br label %bb88
bb87:
  %t358 = load i64, ptr %l167, !tbaa !24
  store i64 %t358, ptr %l165, !tbaa !24
  br label %bb88
bb88:
  %t359 = load i64, ptr %l165, !tbaa !24
  store i64 %t359, ptr %l23, !tbaa !24
  %t360 = load i64, ptr %l23, !tbaa !24
  %t362 = icmp sge i64 %t360, 0
  br i1 %t362, label %bb89, label %bb90
bb89:
  %t364 = load ptr, ptr %l5, !tbaa !29
  %t366 = getelementptr %"compiler/free:Free", ptr %t364, i32 0, i32 1
  %t367 = load i64, ptr %l23, !tbaa !24
  %t370 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t366, i64 %t367)
  store ptr %t370, ptr %l174
  br label %bb91
bb90:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb92
bb91:
  %t371 = load ptr, ptr %l174, !tbaa !29
  %t373 = getelementptr %"compiler/typed:Body", ptr %t371, i32 0, i32 11
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = icmp eq ptr %t374, null
  %t378 = xor i1 %t376, true
  store i1 %t378, ptr %l170, !tbaa !21
  br label %bb92
bb92:
  %t380 = load i1, ptr %l170, !tbaa !21
  br i1 %t380, label %bb93, label %bb94
bb93:
  %t381 = load ptr, ptr %l5, !tbaa !29
  %t383 = getelementptr %"compiler/free:Free", ptr %t381, i32 0, i32 32
  %t384 = load i64, ptr %l23, !tbaa !24
  %t387 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t383, i64 %t384)
  store i64 %t387, ptr %l183
  br label %bb95
bb94:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb96
bb95:
  %t388 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t389 = load i64, ptr %l1, !tbaa !24
  %t392 = add i64 %t388, %t389
  %t393 = load i64, ptr %l183, !tbaa !24
  %t395 = icmp eq i64 %t393, %t392
  store i1 %t395, ptr %l179, !tbaa !21
  br label %bb96
bb96:
  %t397 = load i1, ptr %l179, !tbaa !21
  br i1 %t397, label %bb97, label %bb98
bb97:
  %t398 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  store i64 %t398, ptr %l7, !tbaa !24
  %t400 = load i64, ptr %l1, !tbaa !24
  store i64 %t400, ptr %l8, !tbaa !24
  br label %bb99
bb98:
  br label %bb99
bb99:
  %t402 = load i64, ptr %l7, !tbaa !24
  %t403 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t406 = icmp eq i64 %t402, %t403
  br i1 %t406, label %bb100, label %bb101
bb100:
  store %olang.scope zeroinitializer, ptr %s20
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l193, !tbaa !29
  %t409 = load ptr, ptr %l2, !tbaa !29
  %t411 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t409)
  store %"compiler/source:Span" %t411, ptr %l195
  br label %bb102
bb101:
  br label %bb107
bb102:
  %t412 = load ptr, ptr %l193, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l195
  %t414 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s20, ptr %t412, %"compiler/source:Span" %t413)
  store { i64, ptr } %t414, ptr %l196
  br label %bb103
bb103:
  %t415 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t416 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t417 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 1
  %t419 = extractvalue { i64, ptr } %t417, 0
  %t420 = add i64 %t416, %t419
  %t421 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t422 = extractvalue { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t423 = add i64 %t420, %t422
  %t424 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t423)
  call void @olang_textcopy(ptr %t424, ptr %t415, i64 %t416)
  %t425 = getelementptr i8, ptr %t424, i64 %t416
  call void @olang_textcopy(ptr %t425, ptr %t418, i64 %t419)
  %t426 = getelementptr i8, ptr %t425, i64 %t419
  call void @olang_textcopy(ptr %t426, ptr %t421, i64 %t422)
  %t427 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t428 = insertvalue { i64, ptr } %t427, ptr %t424, 1
  store { i64, ptr } %t428, ptr %l197, !tbaa !27
  %t429 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t429, 0
  %t431 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 0
  store i64 %t432, ptr %l199, !tbaa !24
  %t434 = load i64, ptr %l199, !tbaa !24
  %t435 = icmp eq i64 %t430, %t434
  br i1 %t435, label %bb104, label %bb105
bb104:
  %t437 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t438 = load ptr, ptr %t437, !tbaa !27
  %t439 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = load i64, ptr %l199, !tbaa !24
  %t442 = mul i64 %t441, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t438, ptr %t440, i64 %t442, i1 false)
  br label %bb106
bb105:
  %t443 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t443, ptr %l10, !tbaa !27
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s20)
  br label %bb107
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s15)
  br label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_c3165b793781225b_53a43f46ee99ca6f)
  unreachable
bb111:
  %t444 = load i64, ptr %l7, !tbaa !24
  %t445 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t448 = icmp eq i64 %t444, %t445
  br i1 %t448, label %bb112, label %bb113
bb112:
  %t450 = load ptr, ptr %l5, !tbaa !29
  %t452 = getelementptr %"compiler/free:Free", ptr %t450, i32 0, i32 12
  %t453 = load i64, ptr %l1, !tbaa !24
  %t456 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t452, i64 %t453)
  store i1 %t456, ptr %l208
  br label %bb114
bb113:
  store i1 false, ptr %l204, !tbaa !21
  br label %bb115
bb114:
  %t457 = load i1, ptr %l208, !tbaa !21
  store i1 %t457, ptr %l204, !tbaa !21
  br label %bb115
bb115:
  %t458 = load i1, ptr %l204, !tbaa !21
  br i1 %t458, label %bb116, label %bb117
bb116:
  %t459 = load ptr, ptr %l5, !tbaa !29
  %t460 = load i64, ptr %l1, !tbaa !24
  %t463 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainElems(ptr %v0, ptr %t459, i64 %t460)
  store i1 %t463, ptr %l212
  br label %bb118
bb117:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb119
bb118:
  %t464 = load i1, ptr %l212, !tbaa !21
  %t465 = xor i1 %t464, true
  store i1 %t465, ptr %l209, !tbaa !21
  br label %bb119
bb119:
  %t467 = load i1, ptr %l209, !tbaa !21
  br i1 %t467, label %bb120, label %bb121
bb120:
  %t468 = load ptr, ptr %l2, !tbaa !29
  %t470 = call i1 @compiler_2ffree_2emovesOnly(ptr %v1, ptr %t468)
  store i1 %t470, ptr %l216
  br label %bb122
bb121:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb123
bb122:
  %t471 = load i1, ptr %l216, !tbaa !21
  %t472 = xor i1 %t471, true
  store i1 %t472, ptr %l214, !tbaa !21
  br label %bb123
bb123:
  %t474 = load i1, ptr %l214, !tbaa !21
  br i1 %t474, label %bb124, label %bb125
bb124:
  store %olang.scope zeroinitializer, ptr %s22
  %t475 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t475, ptr %l7, !tbaa !24
  %t477 = load ptr, ptr %l0, !tbaa !29
  store ptr %t477, ptr %l219, !tbaa !29
  %t478 = load ptr, ptr %l2, !tbaa !29
  %t480 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t478)
  store %"compiler/source:Span" %t480, ptr %l221
  br label %bb126
bb125:
  br label %bb131
bb126:
  %t481 = load ptr, ptr %l219, !tbaa !29
  %t482 = load %"compiler/source:Span", ptr %l221
  %t483 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s22, ptr %t481, %"compiler/source:Span" %t482)
  store { i64, ptr } %t483, ptr %l222
  br label %bb127
bb127:
  %t484 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t486 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t487 = extractvalue { i64, ptr } %t486, 1
  %t488 = extractvalue { i64, ptr } %t486, 0
  %t489 = add i64 %t485, %t488
  %t490 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t491 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t492 = add i64 %t489, %t491
  %t493 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t492)
  call void @olang_textcopy(ptr %t493, ptr %t484, i64 %t485)
  %t494 = getelementptr i8, ptr %t493, i64 %t485
  call void @olang_textcopy(ptr %t494, ptr %t487, i64 %t488)
  %t495 = getelementptr i8, ptr %t494, i64 %t488
  call void @olang_textcopy(ptr %t495, ptr %t490, i64 %t491)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t493, 1
  store { i64, ptr } %t497, ptr %l223, !tbaa !27
  %t498 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 0
  %t500 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t501 = extractvalue { i64, ptr } %t500, 0
  store i64 %t501, ptr %l225, !tbaa !24
  %t503 = load i64, ptr %l225, !tbaa !24
  %t504 = icmp eq i64 %t499, %t503
  br i1 %t504, label %bb128, label %bb129
bb128:
  %t506 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr { i64, ptr }, ptr %l223, i32 0, i32 1
  %t509 = load ptr, ptr %t508, !tbaa !27
  %t510 = load i64, ptr %l225, !tbaa !24
  %t511 = mul i64 %t510, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t507, ptr %t509, i64 %t511, i1 false)
  br label %bb130
bb129:
  %t512 = load { i64, ptr }, ptr %l223, !tbaa !27
  store { i64, ptr } %t512, ptr %l10, !tbaa !27
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s22)
  br label %bb131
bb131:
  %t513 = load i64, ptr %l7, !tbaa !24
  %t514 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t517 = icmp eq i64 %t513, %t514
  br i1 %t517, label %bb132, label %bb133
bb132:
  %t519 = load i1, ptr %l4, !tbaa !21
  store i1 %t519, ptr %l230, !tbaa !21
  br label %bb134
bb133:
  store i1 false, ptr %l230, !tbaa !21
  br label %bb134
bb134:
  %t521 = load i1, ptr %l230, !tbaa !21
  br i1 %t521, label %bb135, label %bb136
bb135:
  %t522 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t522, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l233, !tbaa !27
  %t524 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t524, ptr %l234, !tbaa !27
  %t525 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t525, 0
  %t527 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t527, 0
  store i64 %t528, ptr %l236, !tbaa !24
  %t530 = load i64, ptr %l236, !tbaa !24
  %t531 = icmp eq i64 %t526, %t530
  br i1 %t531, label %bb137, label %bb138
bb136:
  br label %bb140
bb137:
  %t533 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !27
  %t535 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = load i64, ptr %l236, !tbaa !24
  %t538 = mul i64 %t537, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t534, ptr %t536, i64 %t538, i1 false)
  br label %bb139
bb138:
  %t539 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t539, 0
  store i64 %t540, ptr %l238, !tbaa !24
  %t541 = load i64, ptr %l238, !tbaa !24
  %t542 = mul i64 %t541, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t542)
  %t544 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  store { i64, ptr } %t545, ptr %l239, !tbaa !27
  %t546 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t547 = load ptr, ptr %t546, !tbaa !27
  %t548 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t549 = load ptr, ptr %t548, !tbaa !27
  %t550 = load i64, ptr %l238, !tbaa !24
  %t551 = mul i64 %t550, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t547, ptr %t549, i64 %t551, i1 false)
  %t552 = load { i64, ptr }, ptr %l239, !tbaa !27
  store { i64, ptr } %t552, ptr %l10, !tbaa !27
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t553 = load i64, ptr %l7, !tbaa !24
  %t554 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t557 = icmp eq i64 %t553, %t554
  br i1 %t557, label %bb141, label %bb142
bb141:
  %t559 = load ptr, ptr %l5, !tbaa !29
  %t561 = getelementptr %"compiler/free:Free", ptr %t559, i32 0, i32 21
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/free:walker", ptr %t562, i32 0, i32 1
  %t565 = load i64, ptr %t564, !tbaa !24
  %t568 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t561, i64 %t565)
  store i1 %t568, ptr %l248
  br label %bb143
bb142:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb144
bb143:
  %t569 = load i1, ptr %l248, !tbaa !21
  %t570 = xor i1 %t569, true
  store i1 %t570, ptr %l243, !tbaa !21
  br label %bb144
bb144:
  %t572 = load i1, ptr %l243, !tbaa !21
  br i1 %t572, label %bb145, label %bb146
bb145:
  %t573 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  store i64 %t573, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l251, !tbaa !27
  %t575 = load { i64, ptr }, ptr %l251, !tbaa !27
  store { i64, ptr } %t575, ptr %l252, !tbaa !27
  %t576 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t577 = extractvalue { i64, ptr } %t576, 0
  %t578 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t578, 0
  store i64 %t579, ptr %l254, !tbaa !24
  %t581 = load i64, ptr %l254, !tbaa !24
  %t582 = icmp eq i64 %t577, %t581
  br i1 %t582, label %bb147, label %bb148
bb146:
  br label %bb150
bb147:
  %t584 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !27
  %t586 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t587 = load ptr, ptr %t586, !tbaa !27
  %t588 = load i64, ptr %l254, !tbaa !24
  %t589 = mul i64 %t588, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t585, ptr %t587, i64 %t589, i1 false)
  br label %bb149
bb148:
  %t590 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t591 = extractvalue { i64, ptr } %t590, 0
  store i64 %t591, ptr %l256, !tbaa !24
  %t592 = load i64, ptr %l256, !tbaa !24
  %t593 = mul i64 %t592, 1
  %t594 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t593)
  %t595 = insertvalue { i64, ptr } undef, i64 %t592, 0
  %t596 = insertvalue { i64, ptr } %t595, ptr %t594, 1
  store { i64, ptr } %t596, ptr %l257, !tbaa !27
  %t597 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t598 = load ptr, ptr %t597, !tbaa !27
  %t599 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t600 = load ptr, ptr %t599, !tbaa !27
  %t601 = load i64, ptr %l256, !tbaa !24
  %t602 = mul i64 %t601, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t598, ptr %t600, i64 %t602, i1 false)
  %t603 = load { i64, ptr }, ptr %l257, !tbaa !27
  store { i64, ptr } %t603, ptr %l10, !tbaa !27
  br label %bb149
bb149:
  br label %bb150
bb150:
  %t604 = load ptr, ptr %l5, !tbaa !29
  %t606 = getelementptr %"compiler/free:Free", ptr %t604, i32 0, i32 42
  store ptr %t606, ptr %l259, !tbaa !29
  %t607 = load i64, ptr %l1, !tbaa !24
  %t608 = load ptr, ptr %l0, !tbaa !29
  %t610 = getelementptr %"compiler/free:walker", ptr %t608, i32 0, i32 1
  %t611 = load i64, ptr %t610, !tbaa !24
  %t612 = load i64, ptr %l6, !tbaa !24
  %t613 = load %"compiler/source:Span", ptr %l3
  %t614 = load i64, ptr %l7, !tbaa !24
  %t615 = load i64, ptr %l8, !tbaa !24
  %t616 = load i64, ptr %l9, !tbaa !24
  %t617 = load ptr, ptr %l2, !tbaa !29
  %t627 = call %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v1, ptr %v0, ptr %v0, i64 %t607, i64 %t611, i64 %t612, %"compiler/source:Span" %t613, i64 %t614, i64 %t615, i64 %t616, ptr %t617, ptr null)
  store %"compiler/free:store" %t627, ptr %l270
  br label %bb151
bb151:
  %t628 = load ptr, ptr %l259, !tbaa !29
  %t629 = load %"compiler/free:store", ptr %l270
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t628, %"compiler/free:store" %t629)
  br label %bb152
bb152:
  %t630 = load i64, ptr %l7, !tbaa !24
  %t631 = load i64, ptr @G_2ecompiler_2ffree_2eSFail, !tbaa !24
  %t634 = icmp eq i64 %t630, %t631
  br i1 %t634, label %bb153, label %bb154
bb153:
  %t636 = load i64, ptr %l6, !tbaa !24
  store i64 %t636, ptr %l24, !tbaa !24
  %t638 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t638, ptr %l25
  %t640 = load ptr, ptr %l5, !tbaa !29
  %t642 = getelementptr %"compiler/free:Free", ptr %t640, i32 0, i32 50
  %t643 = load i64, ptr %t642, !tbaa !24
  %t645 = icmp sge i64 %t643, 0
  br i1 %t645, label %bb155, label %bb156
bb154:
  br label %bb159
bb155:
  %t647 = load ptr, ptr %l5, !tbaa !29
  %t649 = getelementptr %"compiler/free:Free", ptr %t647, i32 0, i32 51
  %t650 = load i64, ptr %t649, !tbaa !24
  %t652 = load ptr, ptr %l5, !tbaa !29
  %t654 = getelementptr %"compiler/free:Free", ptr %t652, i32 0, i32 52
  %t655 = load %"compiler/source:Span", ptr %t654
  store i64 %t650, ptr %l24, !tbaa !24
  store %"compiler/source:Span" %t655, ptr %l25
  %t661 = load ptr, ptr %l5, !tbaa !29
  %t663 = getelementptr %"compiler/free:Free", ptr %t661, i32 0, i32 50
  store i64 -1, ptr %t663, !tbaa !24
  br label %bb157
bb156:
  br label %bb157
bb157:
  %t664 = load ptr, ptr %l5, !tbaa !29
  %t665 = load i64, ptr %l1, !tbaa !24
  %t666 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t667 = load i64, ptr %l24, !tbaa !24
  %t668 = load %"compiler/source:Span", ptr %l25
  %t669 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %s0, ptr %t664, i64 %t665, i64 %t666, i64 %t667, %"compiler/source:Span" %t668, { i64, ptr } %t669)
  br label %bb158
bb158:
  br label %bb159
bb159:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l19 = alloca i1
  %l29 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i32
  %l38 = alloca i1
  %l40 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i1
  %l71 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i32
  %l78 = alloca ptr
  %l79 = alloca i1
  %l86 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l11, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb35
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Seq", ptr %t16, i32 0, i32 2
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb8
bb7:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Seq", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  store i1 %t28, ptr %l19, !tbaa !21
  br label %bb8
bb8:
  %t30 = load i1, ptr %l19, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Seq", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = icmp eq ptr %t35, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_a02d4e2a18cd3a61_9c6a7f96807aa8b5)
  unreachable
bb13:
  br label %bb14
bb14:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Seq", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l3, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:walker", ptr %t44, i32 0, i32 6
  store ptr %t46, ptr %l31, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v1, ptr %t47)
  store i64 %t49, ptr %l33
  br label %bb15
bb15:
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t51 = load i64, ptr %l33, !tbaa !24
  %t52 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t50, i64 %t51)
  %t53 = extractvalue { i32, i64 } %t52, 1
  %t54 = extractvalue { i32, i64 } %t52, 0
  store i32 %t54, ptr %l35
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb17, label %ok.56, !prof !99
ok.56:
  store i64 %t53, ptr %l34
  br label %bb16
bb16:
  %t57 = load i64, ptr %l34, !tbaa !24
  store i64 %t57, ptr %l29, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  store i64 -1, ptr %l29, !tbaa !24
  br label %bb19
bb19:
  %t58 = load i64, ptr %l29, !tbaa !24
  store i64 %t58, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = icmp slt i64 %t59, 0
  br i1 %t61, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb25
bb21:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l40
  br label %bb22
bb22:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t66)
  store i32 %t68, ptr %l42
  br label %bb23
bb23:
  %t69 = load ptr, ptr %l40, !tbaa !29
  %t70 = load i32, ptr %l42, !tbaa !23
  %t71 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t69, i32 %t70)
  store i1 %t71, ptr %l43
  br label %bb24
bb24:
  %t72 = load i1, ptr %l43, !tbaa !21
  store i1 %t72, ptr %l38, !tbaa !21
  br label %bb25
bb25:
  %t73 = load i1, ptr %l38, !tbaa !21
  br i1 %t73, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb31
bb27:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t74)
  store ptr %t76, ptr %l46
  br label %bb28
bb28:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t77)
  store i32 %t79, ptr %l48
  br label %bb29
bb29:
  %t80 = load ptr, ptr %l46, !tbaa !29
  %t81 = load i32, ptr %l48, !tbaa !23
  %t82 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %t80, i32 %t81)
  store i1 %t82, ptr %l49
  br label %bb30
bb30:
  %t83 = load i1, ptr %l49, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l44, !tbaa !21
  br label %bb31
bb31:
  %t86 = load i1, ptr %l44, !tbaa !21
  br i1 %t86, label %bb32, label %bb33
bb32:
  store i64 -1, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t88 = load i64, ptr %l4, !tbaa !24
  store i64 %t88, ptr %rv
  br label %ret
bb35:
  %t90 = load ptr, ptr %l1, !tbaa !29
  store ptr %t90, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t91 = load ptr, ptr %l53, !tbaa !29
  %t92 = icmp ne ptr %t91, null
  br i1 %t92, label %bb36, label %bb37
bb36:
  %t94 = load ptr, ptr %l53, !tbaa !29
  %t95 = load i64, ptr %t94, !range !{i64 0, i64 18}
  %t97 = icmp eq i64 %t95, 2
  store i1 %t97, ptr %l54, !tbaa !21
  br label %bb37
bb37:
  %t98 = load i1, ptr %l54, !tbaa !21
  br i1 %t98, label %bb38, label %bb39
bb38:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t101, i32 0, i32 2
  %t103 = load ptr, ptr %t102
  store ptr %t103, ptr %l5, !tbaa !29
  br label %bb40
bb39:
  br label %bb50
bb40:
  %t105 = load ptr, ptr %l5, !tbaa !29
  store ptr %t105, ptr %l59, !tbaa !29
  store i1 false, ptr %l60, !tbaa !21
  %t106 = load ptr, ptr %l59, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb41, label %bb42
bb41:
  %t109 = load ptr, ptr %l59, !tbaa !29
  %t110 = load i64, ptr %t109, !range !{i64 0, i64 8}
  %t112 = icmp eq i64 %t110, 0
  store i1 %t112, ptr %l60, !tbaa !21
  br label %bb42
bb42:
  %t113 = load i1, ptr %l60, !tbaa !21
  %t114 = xor i1 %t113, true
  br i1 %t114, label %bb43, label %bb44
bb43:
  store i64 -1, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t119, i32 0, i32 0
  %t121 = load %"compiler/source:Span", ptr %t120
  store %"compiler/source:Span" %t121, ptr %l6
  %t123 = load ptr, ptr %l5, !tbaa !29
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t125, i32 0, i32 1
  %t127 = load i32, ptr %t126
  store i32 %t127, ptr %l7, !tbaa !23
  %t129 = load ptr, ptr %l5, !tbaa !29
  %t131 = getelementptr { i64, [4 x i64] }, ptr %t129, i32 0, i32 1
  %t132 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t131, i32 0, i32 2
  %t133 = load i32, ptr %t132
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/free:walker", ptr %t135, i32 0, i32 39
  %t140 = sext i32 %t133 to i64
  %t143 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t137, i64 %t140)
  %t144 = extractvalue { i32, i64 } %t143, 1
  %t145 = extractvalue { i32, i64 } %t143, 0
  store i32 %t145, ptr %l77
  %t146 = icmp ne i32 %t145, 0
  br i1 %t146, label %bb47, label %ok.147, !prof !99
ok.147:
  store i64 %t144, ptr %l76
  br label %bb46
bb46:
  %t148 = load i64, ptr %l76, !tbaa !24
  store i64 %t148, ptr %l71, !tbaa !24
  br label %bb49
bb47:
  br label %bb48
bb48:
  store i64 -1, ptr %l71, !tbaa !24
  br label %bb49
bb49:
  %t149 = load i64, ptr %l71, !tbaa !24
  store i64 %t149, ptr %rv
  br label %ret
bb50:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l78, !tbaa !29
  store i1 false, ptr %l79, !tbaa !21
  %t151 = load ptr, ptr %l78, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb51, label %bb52
bb51:
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t155 = load i64, ptr %t154, !range !{i64 0, i64 18}
  %t157 = icmp eq i64 %t155, 17
  store i1 %t157, ptr %l79, !tbaa !21
  br label %bb52
bb52:
  %t158 = load i1, ptr %l79, !tbaa !21
  br i1 %t158, label %bb53, label %bb54
bb53:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t161, i32 0, i32 2
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l9, !tbaa !29
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t169 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emovedPar(ptr %v0, ptr %v1, ptr %t165, ptr %t166)
  store i64 %t169, ptr %l86
  br label %bb56
bb56:
  %t170 = load i64, ptr %l86, !tbaa !24
  store i64 %t170, ptr %rv
  br label %ret
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store i64 -1, ptr %rv
  br label %ret
bb61:
  call void @__olang_check_failed(ptr @olang_loc_720a25314e6ed839_22eb7101f62f811d)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eparamPaths(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca i64
  %l61 = alloca i64
  %l65 = alloca i1
  %l68 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i64
  %l104 = alloca i64
  %l106 = alloca i1
  %l113 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l141 = alloca i1
  %l145 = alloca i64
  %l151 = alloca i64
  %l155 = alloca i1
  %l159 = alloca i1
  %l161 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l171 = alloca i1
  %l172 = alloca i1
  %l179 = alloca i1
  %l184 = alloca ptr
  %l186 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:walker", ptr %t6, i32 0, i32 51
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l29
  br label %bb1
bb1:
  %t11 = load i64, ptr %l29, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sgt i64 %t12, %t13
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i64, ptr %l4, !tbaa !24
  %t20 = icmp sgt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb7
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = sub i64 %t22, %t23
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = add i64 %t26, %t27
  %t32 = sub i64 %t30, 1
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sdiv i64 %t32, %t33
  store i64 %t36, ptr %l36, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb6
bb6:
  %t38 = load i64, ptr %l36, !tbaa !24
  store i64 %t38, ptr %l33, !tbaa !24
  br label %bb7
bb7:
  %t39 = load i64, ptr %l33, !tbaa !24
  store i64 %t39, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp slt i64 %t40, %t41
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb9, label %bb10
bb9:
  br label %bb90
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  %t53 = mul i64 %t49, %t50
  %t56 = add i64 %t48, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 51
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l57
  br label %bb12
bb12:
  %t65 = load i64, ptr %l57, !tbaa !24
  store i64 %t65, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 53
  %t69 = load i64, ptr %l7, !tbaa !24
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t68, i64 %t69)
  store i64 %t72, ptr %l61
  br label %bb13
bb13:
  %t73 = load i64, ptr %l61, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 22
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l65
  br label %bb14
bb14:
  %t81 = load i1, ptr %l65, !tbaa !21
  store i1 %t81, ptr %l11, !tbaa !21
  store i64 0, ptr %l12, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 14
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l68
  br label %bb15
bb15:
  %t87 = load i64, ptr %l68, !tbaa !24
  store i64 %t87, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t88 = load i64, ptr %l13, !tbaa !24
  %t89 = load i64, ptr %l12, !tbaa !24
  %t92 = icmp sgt i64 %t88, %t89
  br i1 %t92, label %bb16, label %bb17
bb16:
  %t94 = load i64, ptr %l14, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb21
bb18:
  %t98 = load i64, ptr %l13, !tbaa !24
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = sub i64 %t98, %t99
  %t103 = load i64, ptr %l14, !tbaa !24
  %t106 = add i64 %t102, %t103
  %t108 = sub i64 %t106, 1
  %t109 = load i64, ptr %l14, !tbaa !24
  %t112 = sdiv i64 %t108, %t109
  store i64 %t112, ptr %l75, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb20
bb20:
  %t114 = load i64, ptr %l75, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  br label %bb21
bb21:
  %t115 = load i64, ptr %l72, !tbaa !24
  store i64 %t115, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb22
bb22:
  %t116 = load i64, ptr %l16, !tbaa !24
  %t117 = load i64, ptr %l15, !tbaa !24
  %t120 = icmp slt i64 %t116, %t117
  %t122 = xor i1 %t120, true
  br i1 %t122, label %bb23, label %bb24
bb23:
  br label %bb38
bb24:
  br label %bb25
bb25:
  %t124 = load i64, ptr %l12, !tbaa !24
  %t125 = load i64, ptr %l16, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = mul i64 %t125, %t126
  %t132 = add i64 %t124, %t129
  store i64 %t132, ptr %l17, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 14
  %t137 = load i64, ptr %l17, !tbaa !24
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l96
  br label %bb26
bb26:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l96, !tbaa !24
  %t144 = icmp slt i64 %t142, %t141
  br i1 %t144, label %bb27, label %bb28
bb27:
  %t146 = load i64, ptr %l9, !tbaa !24
  store i64 %t146, ptr %l100, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/free:walker", ptr %t147, i32 0, i32 15
  %t150 = load i64, ptr %l17, !tbaa !24
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t149, i64 %t150)
  store i64 %t153, ptr %l104
  br label %bb29
bb28:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb30
bb29:
  %t154 = load i64, ptr %l100, !tbaa !24
  %t155 = load i64, ptr %l104, !tbaa !24
  %t156 = icmp sle i64 %t154, %t155
  store i1 %t156, ptr %l99, !tbaa !21
  br label %bb30
bb30:
  %t158 = load i1, ptr %l99, !tbaa !21
  br i1 %t158, label %bb31, label %bb32
bb31:
  %t159 = load i1, ptr %l11, !tbaa !21
  %t161 = xor i1 %t159, true
  store i1 %t161, ptr %l106, !tbaa !21
  br label %bb33
bb32:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb33
bb33:
  %t163 = load i1, ptr %l106, !tbaa !21
  br i1 %t163, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb36
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t164 = load i64, ptr %l16, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l16, !tbaa !24
  br label %bb22
bb38:
  store i64 0, ptr %l18, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:walker", ptr %t168, i32 0, i32 51
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l113
  br label %bb39
bb39:
  %t173 = load i64, ptr %l113, !tbaa !24
  store i64 %t173, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t174 = load i64, ptr %l19, !tbaa !24
  %t175 = load i64, ptr %l18, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb40, label %bb41
bb40:
  %t180 = load i64, ptr %l20, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb42, label %bb43
bb41:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb45
bb42:
  %t184 = load i64, ptr %l19, !tbaa !24
  %t185 = load i64, ptr %l18, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l20, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l20, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l120, !tbaa !24
  br label %bb44
bb43:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb44
bb44:
  %t200 = load i64, ptr %l120, !tbaa !24
  store i64 %t200, ptr %l117, !tbaa !24
  br label %bb45
bb45:
  %t201 = load i64, ptr %l117, !tbaa !24
  store i64 %t201, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb46
bb46:
  %t202 = load i64, ptr %l22, !tbaa !24
  %t203 = load i64, ptr %l21, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb47, label %bb48
bb47:
  br label %bb80
bb48:
  br label %bb49
bb49:
  %t210 = load i64, ptr %l18, !tbaa !24
  %t211 = load i64, ptr %l22, !tbaa !24
  %t212 = load i64, ptr %l20, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l23, !tbaa !24
  %t220 = load i64, ptr %l23, !tbaa !24
  %t221 = load i64, ptr %l7, !tbaa !24
  %t224 = icmp eq i64 %t220, %t221
  br i1 %t224, label %bb50, label %bb51
bb50:
  store i1 true, ptr %l141, !tbaa !21
  br label %bb53
bb51:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/free:walker", ptr %t226, i32 0, i32 51
  %t229 = load i64, ptr %l23, !tbaa !24
  %t232 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t228, i64 %t229)
  store i64 %t232, ptr %l145
  br label %bb52
bb52:
  %t233 = load i64, ptr %l8, !tbaa !24
  %t234 = load i64, ptr %l145, !tbaa !24
  %t236 = icmp ne i64 %t234, %t233
  store i1 %t236, ptr %l141, !tbaa !21
  br label %bb53
bb53:
  %t238 = load i1, ptr %l141, !tbaa !21
  br i1 %t238, label %bb54, label %bb55
bb54:
  br label %bb79
bb55:
  br label %bb56
bb56:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/free:walker", ptr %t239, i32 0, i32 53
  %t242 = load i64, ptr %l23, !tbaa !24
  %t245 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t241, i64 %t242)
  store i64 %t245, ptr %l151
  br label %bb57
bb57:
  %t246 = load i64, ptr %l151, !tbaa !24
  store i64 %t246, ptr %l24, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i64, ptr %l9, !tbaa !24
  %t249 = load i64, ptr %l24, !tbaa !24
  %t253 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexclusive(ptr %v0, ptr %t247, i64 %t248, i64 %t249)
  store i1 %t253, ptr %l155
  br label %bb58
bb58:
  %t254 = load i1, ptr %l155, !tbaa !21
  br i1 %t254, label %bb59, label %bb60
bb59:
  br label %bb79
bb60:
  br label %bb61
bb61:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t256 = load i64, ptr %l9, !tbaa !24
  %t257 = load i64, ptr %l24, !tbaa !24
  %t261 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %t255, i64 %t256, i64 %t257)
  store i1 %t261, ptr %l159
  br label %bb62
bb62:
  %t262 = load i1, ptr %l159, !tbaa !21
  %t263 = xor i1 %t262, true
  br i1 %t263, label %bb63, label %bb64
bb63:
  %t265 = load i1, ptr %l11, !tbaa !21
  br i1 %t265, label %bb65, label %bb66
bb64:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb75
bb65:
  %t267 = load i64, ptr %l24, !tbaa !24
  %t268 = load i64, ptr %l9, !tbaa !24
  %t271 = icmp sgt i64 %t267, %t268
  store i1 %t271, ptr %l163, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l163, !tbaa !21
  br label %bb67
bb67:
  %t273 = load i1, ptr %l163, !tbaa !21
  br i1 %t273, label %bb68, label %bb69
bb68:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb74
bb69:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/free:walker", ptr %t274, i32 0, i32 22
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t276, i64 %t277)
  store i1 %t280, ptr %l171
  br label %bb70
bb70:
  %t281 = load i1, ptr %l171, !tbaa !21
  br i1 %t281, label %bb71, label %bb72
bb71:
  %t282 = load i64, ptr %l9, !tbaa !24
  %t283 = load i64, ptr %l24, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  store i1 %t286, ptr %l172, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb73
bb73:
  %t288 = load i1, ptr %l172, !tbaa !21
  store i1 %t288, ptr %l167, !tbaa !21
  br label %bb74
bb74:
  %t289 = load i1, ptr %l167, !tbaa !21
  store i1 %t289, ptr %l161, !tbaa !21
  br label %bb75
bb75:
  %t290 = load i1, ptr %l161, !tbaa !21
  br i1 %t290, label %bb76, label %bb77
bb76:
  br label %bb79
bb77:
  br label %bb78
bb78:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb79
bb79:
  %t291 = load i64, ptr %l22, !tbaa !24
  %t293 = add i64 %t291, 1
  store i64 %t293, ptr %l22, !tbaa !24
  br label %bb46
bb80:
  %t295 = load i1, ptr %l10, !tbaa !21
  br i1 %t295, label %bb81, label %bb82
bb81:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t299 = getelementptr %"compiler/free:Free", ptr %t297, i32 0, i32 28
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = getelementptr %"compiler/free:walker", ptr %t300, i32 0, i32 1
  %t303 = load i64, ptr %t302, !tbaa !24
  %t306 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t299, i64 %t303)
  store ptr %t306, ptr %l184
  br label %bb83
bb82:
  store i1 false, ptr %l179, !tbaa !21
  br label %bb85
bb83:
  %t307 = load i64, ptr %l8, !tbaa !24
  %t308 = load ptr, ptr %l184, !tbaa !29
  %t310 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t308, i64 %t307)
  store i64 %t310, ptr %l186
  br label %bb84
bb84:
  %t311 = load i64, ptr %l186, !tbaa !24
  %t312 = icmp sgt i64 %t311, 0
  store i1 %t312, ptr %l179, !tbaa !21
  br label %bb85
bb85:
  %t314 = load i1, ptr %l179, !tbaa !21
  br i1 %t314, label %bb86, label %bb87
bb86:
  %t315 = load ptr, ptr %l1, !tbaa !29
  %t317 = getelementptr %"compiler/free:Free", ptr %t315, i32 0, i32 36
  store i1 true, ptr %t317, !tbaa !21
  br label %bb88
bb87:
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t318 = load i64, ptr %l6, !tbaa !24
  %t320 = add i64 %t318, 1
  store i64 %t320, ptr %l6, !tbaa !24
  br label %bb8
bb90:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t41)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l23
  br label %bb13
bb13:
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t45, ptr %lp4
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t47 = load ptr, ptr %lp4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %t47
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/typed:Elem", ptr %t49, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t55 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t48, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l27
  br label %bb14
bb14:
  %t56 = load ptr, ptr %lp4
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t56
  call void @__olang_scope_close(ptr %s2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t59, ptr %t60)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l31
  br label %bb19
bb19:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_71c754545de4040c_468b95bb5168a5f8)
  unreachable
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 4
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l16, !tbaa !24
  store i64 %t33, ptr %l13, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l13, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t55, i64 %t51, i1 false)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l5, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l5, !tbaa !24
  br label %bb8
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 11
  store i64 0, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 12
  store i64 0, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:walker", ptr %t69, i32 0, i32 13
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t71)
  br label %bb15
bb15:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 14
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t75)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 22
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t79)
  br label %bb17
bb17:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 15
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t83)
  br label %bb18
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 16
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t87)
  br label %bb19
bb19:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %t89, i32 0, i32 17
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t91)
  br label %bb20
bb20:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 18
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t95)
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/free:walker", ptr %t97, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t99)
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:walker", ptr %t101, i32 0, i32 24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t103)
  br label %bb23
bb23:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:walker", ptr %t105, i32 0, i32 25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t107)
  br label %bb24
bb24:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:walker", ptr %t109, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t111)
  br label %bb25
bb25:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/free:walker", ptr %t113, i32 0, i32 27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t115)
  br label %bb26
bb26:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 42
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t119)
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 43
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t123)
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 44
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t127)
  br label %bb29
bb29:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t131)
  br label %bb30
bb30:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:walker", ptr %t133, i32 0, i32 46
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t135)
  br label %bb31
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:walker", ptr %t137, i32 0, i32 47
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t139)
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/free:walker", ptr %t141, i32 0, i32 48
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t143)
  br label %bb33
bb33:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:walker", ptr %t145, i32 0, i32 49
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t147)
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:walker", ptr %t149, i32 0, i32 50
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t151)
  br label %bb35
bb35:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/free:walker", ptr %t153, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t155)
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:walker", ptr %t157, i32 0, i32 37
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hcb8ba31809995dcae45f5acc6cf39f88(ptr %v0, ptr %t159)
  br label %bb37
bb37:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:walker", ptr %t161, i32 0, i32 51
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t163)
  br label %bb38
bb38:
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/free:walker", ptr %t165, i32 0, i32 52
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t167)
  br label %bb39
bb39:
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 53
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t171)
  br label %bb40
bb40:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/free:walker", ptr %t173, i32 0, i32 54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t175)
  br label %bb41
bb41:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = getelementptr %"compiler/free:walker", ptr %t177, i32 0, i32 55
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t179)
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eresult(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i64
  %l18 = alloca i64
  %l25 = alloca ptr
  %l27 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l4, !tbaa !24
  store i64 %t8, ptr %l9, !tbaa !24
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l11, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l16
  br label %bb6
bb6:
  %t23 = load i64, ptr %l16, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  %t24 = load i64, ptr %l5, !tbaa !24
  %t26 = call i64 @compiler_2ffree_2eokind(i64 %t24)
  store i64 %t26, ptr %l18
  br label %bb7
bb7:
  %t27 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t28 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp eq i64 %t28, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t34, i64 %t38)
  store ptr %t41, ptr %l25
  br label %bb11
bb11:
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t45 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t43, i64 %t42)
  store i64 %t45, ptr %l27
  br label %bb12
bb12:
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = icmp sgt i64 %t46, 0
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 36
  store i1 true, ptr %t51, !tbaa !21
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l4, !tbaa !24
  %t54 = add i64 %t52, 1
  store i64 %t54, ptr %l4, !tbaa !24
  br label %bb1
bb17:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i1
  %l38 = alloca ptr
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l4, !tbaa !29
  br label %bb6
bb5:
  br label %bb26
bb6:
  %t26 = load ptr, ptr %l4, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 8}
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb20
bb11:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t39 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l22
  br label %bb12
bb12:
  %t40 = load i1, ptr %l22, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t41 = load ptr, ptr %l2, !tbaa !29
  %t42 = load i32, ptr %l3, !tbaa !23
  %t45 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t41, i32 %t42)
  store i1 %t45, ptr %l26
  br label %bb15
bb14:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb16
bb15:
  %t46 = load i1, ptr %l26, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t50 = load ptr, ptr %l1, !tbaa !29
  store ptr %t50, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_311feee871305b59_d38294057dde4ced)
  unreachable
bb25:
  store ptr null, ptr %rv
  br label %ret
bb26:
  %t54 = load ptr, ptr %l1, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb27, label %bb28
bb27:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 18}
  %t61 = icmp eq i64 %t59, 3
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb28
bb28:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb29, label %bb30
bb29:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr { i64, [5 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t65, i32 0, i32 2
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l5, !tbaa !29
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = call ptr @compiler_2ffree_2ederefRoot(ptr %v1, ptr %v2, ptr %t69)
  store ptr %t71, ptr %l38
  br label %bb32
bb32:
  %t72 = load ptr, ptr %l38, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  store ptr null, ptr %rv
  br label %ret
bb37:
  call void @__olang_check_failed(ptr @olang_loc_421add8d063ee188_aab923ea260c413c)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erootPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i1
  %l63 = alloca i1
  %l68 = alloca i64
  %l77 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l11, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = load ptr, ptr %l3, !tbaa !29
  store ptr %t10, ptr %l12, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t11)
  store i32 %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l15
  br label %bb3
bb3:
  %t17 = load i1, ptr %l15, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %l18, !tbaa !29
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l20
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i32, ptr %l20, !tbaa !23
  %t26 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %t24, i32 %t25)
  store i1 %t26, ptr %l21
  br label %bb7
bb7:
  %t27 = load i1, ptr %l21, !tbaa !21
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  store i64 -1, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb12, label %bb13
bb12:
  %t36 = load ptr, ptr %l24, !tbaa !29
  %t37 = load i64, ptr %t36, !range !{i64 0, i64 18}
  %t39 = icmp eq i64 %t37, 2
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l25, !tbaa !21
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t43, i32 0, i32 2
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l5, !tbaa !29
  br label %bb16
bb15:
  br label %bb46
bb16:
  %t47 = load ptr, ptr %l5, !tbaa !29
  store ptr %t47, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = icmp ne ptr %t48, null
  br i1 %t49, label %bb17, label %bb18
bb17:
  %t51 = load ptr, ptr %l30, !tbaa !29
  %t52 = load i64, ptr %t51, !range !{i64 0, i64 8}
  %t54 = icmp eq i64 %t52, 0
  store i1 %t54, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t55 = load i1, ptr %l31, !tbaa !21
  br i1 %t55, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = getelementptr { i64, [4 x i64] }, ptr %t56, i32 0, i32 1
  %t59 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t58, i32 0, i32 2
  %t60 = load i32, ptr %t59
  store i32 %t60, ptr %l6, !tbaa !23
  br label %bb21
bb20:
  br label %bb29
bb21:
  %t62 = load i32, ptr %l6, !tbaa !23
  %t64 = sext i32 %t62 to i64
  store i64 %t64, ptr %l37, !tbaa !24
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 53
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l42
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l42, !tbaa !29
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t75)
  store i64 %t76, ptr %l43
  br label %bb23
bb23:
  %t77 = load i64, ptr %l37, !tbaa !24
  %t78 = load i64, ptr %l43, !tbaa !24
  %t79 = icmp slt i64 %t77, %t78
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr %"compiler/free:Free", ptr %t81, i32 0, i32 53
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:walker", ptr %t84, i32 0, i32 1
  %t87 = load i64, ptr %t86, !tbaa !24
  %t90 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t83, i64 %t87)
  store ptr %t90, ptr %l50
  br label %bb26
bb25:
  %t91 = load i64, ptr @G_2ecompiler_2ffree_2eMustNone, !tbaa !24
  store i64 %t91, ptr %l45, !tbaa !24
  br label %bb28
bb26:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i32, ptr %l6, !tbaa !23
  %t96 = sext i32 %t94 to i64
  %t99 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t93, i64 %t96)
  store i64 %t99, ptr %l54
  br label %bb27
bb27:
  %t100 = load i64, ptr %l54, !tbaa !24
  store i64 %t100, ptr %l45, !tbaa !24
  br label %bb28
bb28:
  %t101 = load i64, ptr %l45, !tbaa !24
  store i64 %t101, ptr %l4, !tbaa !24
  br label %bb45
bb29:
  %t102 = load ptr, ptr %l5, !tbaa !29
  store ptr %t102, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t103 = load ptr, ptr %l56, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb30, label %bb31
bb30:
  %t106 = load ptr, ptr %l56, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 3
  store i1 %t109, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l57, !tbaa !21
  br i1 %t110, label %bb32, label %bb33
bb32:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t111, i32 0, i32 1
  %t114 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t113, i32 0, i32 2
  %t115 = load ptr, ptr %t114
  store ptr %t115, ptr %l7, !tbaa !29
  br label %bb34
bb33:
  br label %bb40
bb34:
  %t117 = load ptr, ptr %l7, !tbaa !29
  %t119 = call i1 @compiler_2ffree_2epureBase(ptr %v1, ptr %t117)
  store i1 %t119, ptr %l63
  br label %bb35
bb35:
  %t120 = load i1, ptr %l63, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb36, label %bb37
bb36:
  store i64 -1, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t128 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t124, ptr %t125)
  store i64 %t128, ptr %l68
  br label %bb39
bb39:
  %t129 = load i64, ptr %l68, !tbaa !24
  store i64 %t129, ptr %l4, !tbaa !24
  br label %bb45
bb40:
  br i1 true, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store i64 -1, ptr %rv
  br label %ret
bb44:
  call void @__olang_check_failed(ptr @olang_loc_34bfc259355dec67_8a2d14d061fee643)
  unreachable
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i64 -1, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_806a74b5c91de186_4e306eb4964e9ec2)
  unreachable
bb51:
  %t132 = load i64, ptr %l4, !tbaa !24
  %t134 = icmp slt i64 %t132, 0
  br i1 %t134, label %bb52, label %bb53
bb52:
  store i64 -1, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  %t137 = load i64, ptr %l4, !tbaa !24
  %t138 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t141 = icmp sge i64 %t137, %t138
  br i1 %t141, label %bb55, label %bb56
bb55:
  %t143 = load i64, ptr %l4, !tbaa !24
  %t144 = load i64, ptr @G_2ecompiler_2ffree_2eMovBase, !tbaa !24
  %t147 = sub i64 %t143, %t144
  store i64 %t147, ptr %l77, !tbaa !24
  br label %bb57
bb56:
  %t149 = load i64, ptr %l4, !tbaa !24
  store i64 %t149, ptr %l77, !tbaa !24
  br label %bb57
bb57:
  %t151 = load i64, ptr %l77, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2erunsAgain(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca i1
  %l17 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 1
  %t7 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t7, ptr %l1
  %t9 = load { i64, [2 x i64] }, ptr %l1
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 6
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  %t14 = load { i64, [2 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [2 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 5
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb18
bb7:
  %t19 = load { i64, [2 x i64] }, ptr %l1
  %t21 = extractvalue { i64, [2 x i64] } %t19, 0
  %t22 = icmp eq i64 %t21, 0
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t25 = getelementptr { i64 }, ptr %t24, i32 0, i32 0
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l2, !tbaa !24
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:walker", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 0
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l17, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 0
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = getelementptr %"compiler/free:Free", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l22
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsEntry(ptr %v0, ptr %t46, i64 %t47)
  store i1 %t48, ptr %l23
  br label %bb12
bb12:
  %t49 = load i1, ptr %l23, !tbaa !21
  %t50 = xor i1 %t49, true
  store i1 %t50, ptr %l7, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_350c73b6578d6328_239abab62451b64c)
  unreachable
bb18:
  %t52 = load i1, ptr %l7, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l14 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i1
  %l44 = alloca ptr
  %l46 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:walker", ptr %t5, i32 0, i32 8
  %t8 = load i32, ptr %t7, !tbaa !23
  %t13 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t4, i32 %t8, i64 %a1)
  store i64 %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load i64, ptr %l14, !tbaa !24
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sge i64 %t15, 0
  br i1 %t17, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i64, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %s1, ptr %t19, i64 %t20, ptr %a2, ptr %t22, %"compiler/source:Span" %a4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, i1 false)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 2
  %t32 = load i1, ptr %t31, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t36 = load ptr, ptr %l3, !tbaa !29
  store ptr %t36, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb7:
  br label %bb25
bb8:
  %t38 = load i64, ptr %l7, !tbaa !24
  store i64 %t38, ptr %l26, !tbaa !24
  %t39 = load ptr, ptr %l6, !tbaa !29
  %t41 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t39)
  store i64 %t41, ptr %l28
  br label %bb9
bb9:
  %t42 = load i64, ptr %l26, !tbaa !24
  %t43 = load i64, ptr %l28, !tbaa !24
  %t44 = icmp slt i64 %t42, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  br label %bb12
bb12:
  %t48 = load ptr, ptr %l6, !tbaa !29
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l33
  br label %bb13
bb13:
  %t53 = load i64, ptr %l33, !tbaa !24
  store i64 %t53, ptr %l8, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = call i64 @compiler_2ffree_2eokind(i64 %t54)
  store i64 %t56, ptr %l35
  br label %bb14
bb14:
  %t57 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t58 = load i64, ptr %l35, !tbaa !24
  %t60 = icmp ne i64 %t58, %t57
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t67, i64 %t71)
  store ptr %t74, ptr %l44
  br label %bb17
bb16:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb19
bb17:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load ptr, ptr %l44, !tbaa !29
  %t78 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t76, i64 %t75)
  store i64 %t78, ptr %l46
  br label %bb18
bb18:
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = icmp sgt i64 %t79, 0
  store i1 %t80, ptr %l38, !tbaa !21
  br label %bb19
bb19:
  %t82 = load i1, ptr %l38, !tbaa !21
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/free:Free", ptr %t86, i32 0, i32 36
  store i1 true, ptr %t88, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t89 = load i64, ptr %l7, !tbaa !24
  %t91 = add i64 %t89, 1
  store i64 %t91, ptr %l7, !tbaa !24
  br label %bb8
bb24:
  br label %bb25
bb25:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreOne(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca ptr
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t2, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s0, ptr %t10, ptr %t11)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l11
  br label %bb1
bb1:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l5
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 29
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = sub i64 %t19, 1
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 29
  store i64 %t21, ptr %t24, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %t25, i64 %a1, ptr %t27, ptr %l5, %"compiler/source:Span" %a3, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d74, i32 0, i32 1) }, i1 %a4, i1 false)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 29
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 24
  %t11 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t10, i64 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 25
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 12
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t16, i64 %t20)
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 26
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t25, %"compiler/source:Span" %a2)
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 28
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:walker", ptr %t36, i32 0, i32 27
  %t39 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i1
  %l18 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i1
  %l36 = alloca ptr
  %l38 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 29
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l9, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:walker", ptr %t16, i32 0, i32 38
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  store i1 %t21, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t27)
  store i64 %t29, ptr %l20
  br label %bb11
bb11:
  %t30 = load i64, ptr %l18, !tbaa !24
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = icmp slt i64 %t30, %t31
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb12, label %bb13
bb12:
  br label %bb27
bb13:
  br label %bb14
bb14:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t37 = load i64, ptr %l3, !tbaa !24
  %t40 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t36, i64 %t37)
  store i64 %t40, ptr %l25
  br label %bb15
bb15:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = call i64 @compiler_2ffree_2eokind(i64 %t42)
  store i64 %t44, ptr %l27
  br label %bb16
bb16:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t47 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t50 = icmp eq i64 %t46, %t47
  br i1 %t50, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t56 = icmp eq i64 %t52, %t53
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t58 = load i1, ptr %l31, !tbaa !21
  br i1 %t58, label %bb20, label %bb21
bb20:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/free:walker", ptr %t59, i32 0, i32 42
  store ptr %t61, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %l4, !tbaa !24
  %t64 = call i64 @compiler_2ffree_2eoval(i64 %t62)
  store i64 %t64, ptr %l38
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t65, i64 %t66)
  br label %bb23
bb23:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/free:walker", ptr %t67, i32 0, i32 43
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 12
  %t73 = load i64, ptr %t72, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t69, i64 %t73)
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t76 = load i64, ptr %l3, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l3, !tbaa !24
  br label %bb10
bb27:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviews(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l65 = alloca i64
  %l66 = alloca ptr
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l96 = alloca i64
  %l99 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca ptr
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca ptr
  %l127 = alloca i64
  %l129 = alloca i64
  %l134 = alloca i64
  %l136 = alloca i64
  %l139 = alloca i1
  %l141 = alloca i64
  %l146 = alloca ptr
  %l148 = alloca i64
  %l155 = alloca i64
  %l159 = alloca i64
  %l162 = alloca i64
  %l180 = alloca ptr
  %l184 = alloca i64
  %l185 = alloca ptr
  %l189 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l192 = alloca i64
  %l196 = alloca i64
  %l199 = alloca i64
  %l219 = alloca ptr
  %l220 = alloca i64
  %l222 = alloca i1
  %l226 = alloca i1
  %l234 = alloca i64
  %l240 = alloca i64
  %l244 = alloca i64
  %l247 = alloca i64
  %l268 = alloca i64
  %l269 = alloca i64
  %l279 = alloca i64
  %l282 = alloca i64
  %l300 = alloca i64
  %l310 = alloca i64
  %l316 = alloca i64
  %l322 = alloca i64
  %l326 = alloca i64
  %l329 = alloca i64
  %l350 = alloca i64
  %l355 = alloca i64
  %l359 = alloca i64
  %l360 = alloca i64
  %l367 = alloca i64
  %l371 = alloca i64
  %l374 = alloca i64
  %l395 = alloca i64
  %l399 = alloca i64
  %l403 = alloca i64
  %l407 = alloca i64
  %l409 = alloca i64
  %l411 = alloca ptr
  %l415 = alloca i64
  %l416 = alloca i64
  %l417 = alloca i32
  %l421 = alloca i1
  %l422 = alloca i64
  %l425 = alloca i64
  %l427 = alloca i1
  %l431 = alloca i64
  %l437 = alloca i64
  %l441 = alloca i1
  %l445 = alloca i1
  %l449 = alloca i1
  %l453 = alloca i1
  %l454 = alloca ptr
  %l458 = alloca i64
  %l459 = alloca i1
  %l469 = alloca i64
  %l472 = alloca i64
  %l494 = alloca i1
  %l498 = alloca i1
  %l502 = alloca i64
  %l505 = alloca ptr
  %l506 = alloca i64
  %l508 = alloca i64
  %l512 = alloca %"compiler/source:Span"
  %l513 = alloca ptr
  %l515 = alloca i64
  %l519 = alloca %"compiler/source:Span"
  %l520 = alloca { i64, ptr }
  %l527 = alloca i64
  %l529 = alloca i64
  %l534 = alloca i64
  %l537 = alloca ptr
  %l538 = alloca i64
  %l540 = alloca i64
  %l545 = alloca i64
  %l548 = alloca i1
  %l552 = alloca i1
  %l556 = alloca i64
  %l563 = alloca ptr
  %l564 = alloca i64
  %l565 = alloca i64
  %l568 = alloca ptr
  %l569 = alloca i64
  %l575 = alloca ptr
  %l579 = alloca %"compiler/typed:Local"
  %l581 = alloca { i64, ptr }
  %l585 = alloca ptr
  %l587 = alloca i64
  %l591 = alloca %"compiler/typed:Local"
  %l594 = alloca i64
  %l598 = alloca ptr
  %l600 = alloca i64
  %l604 = alloca %"compiler/source:Span"
  %l607 = alloca i64
  %l614 = alloca i1
  %l615 = alloca ptr
  %l617 = alloca i64
  %l621 = alloca %"compiler/source:Span"
  %l622 = alloca { i64, ptr }
  %l623 = alloca i64
  %l625 = alloca i1
  %l627 = alloca i1
  %l629 = alloca { i64, ptr }
  %l630 = alloca i1
  %l632 = alloca { i64, ptr }
  %l636 = alloca { i64, ptr }
  %l638 = alloca i64
  %l640 = alloca { i64, ptr }
  %l641 = alloca { i64, ptr }
  %l643 = alloca i64
  %l645 = alloca i64
  %l646 = alloca { i64, ptr }
  %l647 = alloca { i64, ptr }
  %l648 = alloca { i64, ptr }
  %l649 = alloca i64
  %l650 = alloca { i64, ptr }
  %l654 = alloca ptr
  %l656 = alloca i64
  %l660 = alloca %"compiler/source:Span"
  %l661 = alloca { i64, ptr }
  %l664 = alloca { i64, ptr }
  %l666 = alloca i64
  %l671 = alloca ptr
  %l673 = alloca i64
  %l677 = alloca %"compiler/source:Span"
  %l678 = alloca { i64, ptr }
  %l679 = alloca i64
  %l682 = alloca { i64, ptr }
  %l684 = alloca { i64, ptr }
  %l686 = alloca i64
  %l690 = alloca { i64, ptr }
  %l692 = alloca i64
  %l696 = alloca ptr
  %l697 = alloca i64
  %l699 = alloca i64
  %l704 = alloca i64
  %l707 = alloca i1
  %l711 = alloca i1
  %l715 = alloca i64
  %l718 = alloca ptr
  %l719 = alloca i64
  %l721 = alloca i64
  %l725 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s47 = alloca %olang.scope
  %s50 = alloca %olang.scope
  %s56 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l87
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l87, !tbaa !29
  store ptr %t9, ptr %l2, !tbaa !29
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l88
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l3
  %t12 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l89
  br label %bb3
bb3:
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 3
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l92
  br label %bb4
bb4:
  %t19 = load i64, ptr %l92, !tbaa !24
  store i64 %t19, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t20 = load i64, ptr %l6, !tbaa !24
  %t21 = load i64, ptr %l5, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l96, !tbaa !24
  br label %bb10
bb7:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l7, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l7, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l99, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb9
bb9:
  %t46 = load i64, ptr %l99, !tbaa !24
  store i64 %t46, ptr %l96, !tbaa !24
  br label %bb10
bb10:
  %t47 = load i64, ptr %l96, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l8, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  br label %bb40
bb13:
  br label %bb14
bb14:
  %t56 = load i64, ptr %l5, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l10, !tbaa !24
  store ptr %l3, ptr %l117, !tbaa !29
  %t66 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l118
  br label %bb15
bb15:
  %t67 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l118
  %t68 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %t68
  %t69 = load ptr, ptr %l117, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %s0, ptr %s0, ptr %t69, ptr %t68)
  br label %bb16
bb16:
  store ptr %l4, ptr %l120, !tbaa !29
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l121
  br label %bb17
bb17:
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121
  %t73 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %t73
  %t74 = load ptr, ptr %l120, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %s0, ptr %s0, ptr %t74, ptr %t73)
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 3
  %t79 = load i64, ptr %l10, !tbaa !24
  %t82 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t78, i64 %t79)
  store ptr %t82, ptr %l126
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l126, !tbaa !29
  store ptr %t83, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb20
bb20:
  %t84 = load i64, ptr %l12, !tbaa !24
  store i64 %t84, ptr %l127, !tbaa !24
  %t85 = load ptr, ptr %l11, !tbaa !29
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t85)
  store i64 %t87, ptr %l129
  br label %bb21
bb21:
  %t88 = load i64, ptr %l127, !tbaa !24
  %t89 = load i64, ptr %l129, !tbaa !24
  %t90 = icmp slt i64 %t88, %t89
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb22, label %bb23
bb22:
  br label %bb38
bb23:
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l11, !tbaa !29
  %t95 = load i64, ptr %l12, !tbaa !24
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t94, i64 %t95)
  store i64 %t98, ptr %l134
  br label %bb25
bb25:
  %t99 = load i64, ptr %l134, !tbaa !24
  store i64 %t99, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l13, !tbaa !24
  %t102 = call i64 @compiler_2ffree_2eokind(i64 %t100)
  store i64 %t102, ptr %l136
  br label %bb26
bb26:
  %t103 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t104 = load i64, ptr %l136, !tbaa !24
  %t106 = icmp eq i64 %t104, %t103
  br i1 %t106, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l139, !tbaa !21
  br label %bb30
bb28:
  %t108 = load i64, ptr %l13, !tbaa !24
  %t110 = call i64 @compiler_2ffree_2eokind(i64 %t108)
  store i64 %t110, ptr %l141
  br label %bb29
bb29:
  %t111 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t112 = load i64, ptr %l141, !tbaa !24
  %t114 = icmp eq i64 %t112, %t111
  store i1 %t114, ptr %l139, !tbaa !21
  br label %bb30
bb30:
  %t116 = load i1, ptr %l139, !tbaa !21
  br i1 %t116, label %bb31, label %bb32
bb31:
  %t117 = load i64, ptr %l10, !tbaa !24
  %t120 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %l3, i64 %t117)
  store ptr %t120, ptr %l146
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t121 = load i64, ptr %l13, !tbaa !24
  %t123 = call i64 @compiler_2ffree_2eoval(i64 %t121)
  store i64 %t123, ptr %l148
  br label %bb34
bb34:
  %t124 = load ptr, ptr %l146, !tbaa !29
  %t125 = load i64, ptr %l148, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t124, i64 %t125)
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t126 = load i64, ptr %l12, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l12, !tbaa !24
  br label %bb20
bb38:
  br label %bb39
bb39:
  %t130 = load i64, ptr %l9, !tbaa !24
  %t132 = add i64 %t130, 1
  store i64 %t132, ptr %l9, !tbaa !24
  br label %bb11
bb40:
  store i64 0, ptr %l14, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 24
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t136)
  store i64 %t138, ptr %l155
  br label %bb41
bb41:
  %t139 = load i64, ptr %l155, !tbaa !24
  store i64 %t139, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t140 = load i64, ptr %l15, !tbaa !24
  %t141 = load i64, ptr %l14, !tbaa !24
  %t144 = icmp sgt i64 %t140, %t141
  br i1 %t144, label %bb42, label %bb43
bb42:
  %t146 = load i64, ptr %l16, !tbaa !24
  %t148 = icmp sgt i64 %t146, 0
  br i1 %t148, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb47
bb44:
  %t150 = load i64, ptr %l15, !tbaa !24
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t155 = load i64, ptr %l16, !tbaa !24
  %t158 = add i64 %t154, %t155
  %t160 = sub i64 %t158, 1
  %t161 = load i64, ptr %l16, !tbaa !24
  %t164 = sdiv i64 %t160, %t161
  store i64 %t164, ptr %l162, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l162, !tbaa !24
  br label %bb46
bb46:
  %t166 = load i64, ptr %l162, !tbaa !24
  store i64 %t166, ptr %l159, !tbaa !24
  br label %bb47
bb47:
  %t167 = load i64, ptr %l159, !tbaa !24
  store i64 %t167, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb48
bb48:
  %t168 = load i64, ptr %l18, !tbaa !24
  %t169 = load i64, ptr %l17, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb49, label %bb50
bb49:
  br label %bb56
bb50:
  br label %bb51
bb51:
  %t176 = load i64, ptr %l14, !tbaa !24
  %t177 = load i64, ptr %l18, !tbaa !24
  %t178 = load i64, ptr %l16, !tbaa !24
  %t181 = mul i64 %t177, %t178
  %t184 = add i64 %t176, %t181
  store i64 %t184, ptr %l19, !tbaa !24
  store ptr %l4, ptr %l180, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/free:walker", ptr %t186, i32 0, i32 24
  %t189 = load i64, ptr %l19, !tbaa !24
  %t192 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t188, i64 %t189)
  store i64 %t192, ptr %l184
  br label %bb52
bb52:
  %t193 = load ptr, ptr %l180, !tbaa !29
  %t194 = load i64, ptr %l184, !tbaa !24
  %t195 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %t193, i64 %t194)
  store ptr %t195, ptr %l185
  br label %bb53
bb53:
  %t196 = load i64, ptr %l19, !tbaa !24
  %t197 = load ptr, ptr %l185, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t197, i64 %t196)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t199 = load i64, ptr %l18, !tbaa !24
  %t201 = add i64 %t199, 1
  store i64 %t201, ptr %l18, !tbaa !24
  br label %bb48
bb56:
  %t203 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t203, ptr %l189
  br label %bb57
bb57:
  %t204 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l189
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %l20
  store i64 0, ptr %l21, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/free:walker", ptr %t205, i32 0, i32 3
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t207)
  store i64 %t209, ptr %l192
  br label %bb58
bb58:
  %t210 = load i64, ptr %l192, !tbaa !24
  store i64 %t210, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t211 = load i64, ptr %l22, !tbaa !24
  %t212 = load i64, ptr %l21, !tbaa !24
  %t215 = icmp sgt i64 %t211, %t212
  br i1 %t215, label %bb59, label %bb60
bb59:
  %t217 = load i64, ptr %l23, !tbaa !24
  %t219 = icmp sgt i64 %t217, 0
  br i1 %t219, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb64
bb61:
  %t221 = load i64, ptr %l22, !tbaa !24
  %t222 = load i64, ptr %l21, !tbaa !24
  %t225 = sub i64 %t221, %t222
  %t226 = load i64, ptr %l23, !tbaa !24
  %t229 = add i64 %t225, %t226
  %t231 = sub i64 %t229, 1
  %t232 = load i64, ptr %l23, !tbaa !24
  %t235 = sdiv i64 %t231, %t232
  store i64 %t235, ptr %l199, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb63
bb63:
  %t237 = load i64, ptr %l199, !tbaa !24
  store i64 %t237, ptr %l196, !tbaa !24
  br label %bb64
bb64:
  %t238 = load i64, ptr %l196, !tbaa !24
  store i64 %t238, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb65
bb65:
  %t239 = load i64, ptr %l25, !tbaa !24
  %t240 = load i64, ptr %l24, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb66, label %bb67
bb66:
  br label %bb80
bb67:
  br label %bb68
bb68:
  %t247 = load i64, ptr %l21, !tbaa !24
  %t248 = load i64, ptr %l25, !tbaa !24
  %t249 = load i64, ptr %l23, !tbaa !24
  %t252 = mul i64 %t248, %t249
  %t255 = add i64 %t247, %t252
  store i64 %t255, ptr %l26, !tbaa !24
  %t257 = load i64, ptr %l26, !tbaa !24
  %t260 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %l3, i64 %t257)
  store ptr %t260, ptr %l219
  br label %bb69
bb69:
  %t261 = load ptr, ptr %l219, !tbaa !29
  %t262 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t261)
  store i64 %t262, ptr %l220
  br label %bb70
bb70:
  %t263 = load i64, ptr %l220, !tbaa !24
  %t264 = icmp sgt i64 %t263, 0
  br i1 %t264, label %bb71, label %bb72
bb71:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/free:walker", ptr %t266, i32 0, i32 6
  %t269 = load i64, ptr %l26, !tbaa !24
  %t272 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %t268, i64 %t269)
  store i1 %t272, ptr %l226
  br label %bb73
bb72:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb74
bb73:
  %t273 = load i1, ptr %l226, !tbaa !21
  %t274 = xor i1 %t273, true
  store i1 %t274, ptr %l222, !tbaa !21
  br label %bb74
bb74:
  %t276 = load i1, ptr %l222, !tbaa !21
  br i1 %t276, label %bb75, label %bb76
bb75:
  %t277 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l20, i64 %t277)
  br label %bb77
bb76:
  br label %bb78
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t280 = load i64, ptr %l25, !tbaa !24
  %t282 = add i64 %t280, 1
  store i64 %t282, ptr %l25, !tbaa !24
  br label %bb65
bb80:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/free:walker", ptr %t284, i32 0, i32 11
  %t287 = load i64, ptr %t286, !tbaa !24
  %t289 = add i64 %t287, 2
  store i64 %t289, ptr %l234, !tbaa !24
  %t290 = load i64, ptr %l234, !tbaa !24
  %t291 = icmp sge i64 %t290, 0
  br i1 %t291, label %bb81, label %bb82
bb81:
  %t293 = load i64, ptr %l234, !tbaa !24
  %t294 = icmp sle i64 %t293, 1152921504606846975
  br i1 %t294, label %bb83, label %bb84
bb82:
  call void @__olang_check_failed(ptr @olang_loc_2a6707270ca06c1b_81c43f034781ce2f)
  unreachable
bb83:
  %t296 = load i64, ptr %l234, !tbaa !24
  %t297 = mul i64 %t296, 8
  %t298 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t297)
  %t299 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  store { i64, ptr } %t300, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/free:walker", ptr %t302, i32 0, i32 42
  %t306 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t304)
  store i64 %t306, ptr %l240
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_2a6707270ca06c1b_81c43f034781ce2f)
  unreachable
bb85:
  %t307 = load i64, ptr %l240, !tbaa !24
  store i64 %t307, ptr %l29, !tbaa !24
  store i64 1, ptr %l30, !tbaa !24
  %t308 = load i64, ptr %l29, !tbaa !24
  %t309 = load i64, ptr %l28, !tbaa !24
  %t312 = icmp sgt i64 %t308, %t309
  br i1 %t312, label %bb86, label %bb87
bb86:
  %t314 = load i64, ptr %l30, !tbaa !24
  %t316 = icmp sgt i64 %t314, 0
  br i1 %t316, label %bb88, label %bb89
bb87:
  store i64 0, ptr %l244, !tbaa !24
  br label %bb91
bb88:
  %t318 = load i64, ptr %l29, !tbaa !24
  %t319 = load i64, ptr %l28, !tbaa !24
  %t322 = sub i64 %t318, %t319
  %t323 = load i64, ptr %l30, !tbaa !24
  %t326 = add i64 %t322, %t323
  %t328 = sub i64 %t326, 1
  %t329 = load i64, ptr %l30, !tbaa !24
  %t332 = sdiv i64 %t328, %t329
  store i64 %t332, ptr %l247, !tbaa !24
  br label %bb90
bb89:
  store i64 0, ptr %l247, !tbaa !24
  br label %bb90
bb90:
  %t334 = load i64, ptr %l247, !tbaa !24
  store i64 %t334, ptr %l244, !tbaa !24
  br label %bb91
bb91:
  %t335 = load i64, ptr %l244, !tbaa !24
  store i64 %t335, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  br label %bb92
bb92:
  %t336 = load i64, ptr %l32, !tbaa !24
  %t337 = load i64, ptr %l31, !tbaa !24
  %t340 = icmp slt i64 %t336, %t337
  %t342 = xor i1 %t340, true
  br i1 %t342, label %bb93, label %bb94
bb93:
  br label %bb98
bb94:
  br label %bb95
bb95:
  %t344 = load i64, ptr %l28, !tbaa !24
  %t345 = load i64, ptr %l32, !tbaa !24
  %t346 = load i64, ptr %l30, !tbaa !24
  %t349 = mul i64 %t345, %t346
  %t352 = add i64 %t344, %t349
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/free:walker", ptr %t354, i32 0, i32 43
  %t360 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t356, i64 %t352)
  store i64 %t360, ptr %l268
  br label %bb96
bb96:
  %t361 = load i64, ptr %l268, !tbaa !24
  %t362 = add i64 %t361, 1
  store i64 %t362, ptr %l269, !tbaa !24
  %t363 = load i64, ptr %l269, !tbaa !24
  %t364 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t365 = load ptr, ptr %t364, !tbaa !27
  %t366 = getelementptr i64, ptr %t365, i64 %t363
  %t367 = load i64, ptr %t366, !tbaa !34
  %t369 = add i64 %t367, 1
  %t371 = load i64, ptr %l269, !tbaa !24
  %t372 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr i64, ptr %t373, i64 %t371
  store i64 %t369, ptr %t374, !tbaa !34
  br label %bb97
bb97:
  %t375 = load i64, ptr %l32, !tbaa !24
  %t377 = add i64 %t375, 1
  store i64 %t377, ptr %l32, !tbaa !24
  br label %bb92
bb98:
  store i64 1, ptr %l34, !tbaa !24
  %t379 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t379, 0
  store i64 %t381, ptr %l35, !tbaa !24
  store i64 1, ptr %l36, !tbaa !24
  %t383 = load i64, ptr %l35, !tbaa !24
  %t384 = load i64, ptr %l34, !tbaa !24
  %t387 = icmp sgt i64 %t383, %t384
  br i1 %t387, label %bb99, label %bb100
bb99:
  %t389 = load i64, ptr %l36, !tbaa !24
  %t391 = icmp sgt i64 %t389, 0
  br i1 %t391, label %bb101, label %bb102
bb100:
  store i64 0, ptr %l279, !tbaa !24
  br label %bb104
bb101:
  %t393 = load i64, ptr %l35, !tbaa !24
  %t394 = load i64, ptr %l34, !tbaa !24
  %t397 = sub i64 %t393, %t394
  %t398 = load i64, ptr %l36, !tbaa !24
  %t401 = add i64 %t397, %t398
  %t403 = sub i64 %t401, 1
  %t404 = load i64, ptr %l36, !tbaa !24
  %t407 = sdiv i64 %t403, %t404
  store i64 %t407, ptr %l282, !tbaa !24
  br label %bb103
bb102:
  store i64 0, ptr %l282, !tbaa !24
  br label %bb103
bb103:
  %t409 = load i64, ptr %l282, !tbaa !24
  store i64 %t409, ptr %l279, !tbaa !24
  br label %bb104
bb104:
  %t410 = load i64, ptr %l279, !tbaa !24
  store i64 %t410, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb105
bb105:
  %t411 = load i64, ptr %l38, !tbaa !24
  %t412 = load i64, ptr %l37, !tbaa !24
  %t415 = icmp slt i64 %t411, %t412
  %t417 = xor i1 %t415, true
  br i1 %t417, label %bb106, label %bb107
bb106:
  br label %bb110
bb107:
  br label %bb108
bb108:
  %t419 = load i64, ptr %l34, !tbaa !24
  %t420 = load i64, ptr %l38, !tbaa !24
  %t421 = load i64, ptr %l36, !tbaa !24
  %t424 = mul i64 %t420, %t421
  %t427 = add i64 %t419, %t424
  store i64 %t427, ptr %l39, !tbaa !24
  %t429 = load i64, ptr %l39, !tbaa !24
  store i64 %t429, ptr %l300, !tbaa !24
  %t430 = load i64, ptr %l300, !tbaa !24
  %t431 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr i64, ptr %t432, i64 %t430
  %t434 = load i64, ptr %t433, !tbaa !34
  %t435 = load i64, ptr %l39, !tbaa !24
  %t437 = sub i64 %t435, 1
  %t439 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr i64, ptr %t440, i64 %t437
  %t442 = load i64, ptr %t441, !tbaa !34
  %t445 = add i64 %t434, %t442
  %t447 = load i64, ptr %l300, !tbaa !24
  %t448 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr i64, ptr %t449, i64 %t447
  store i64 %t445, ptr %t450, !tbaa !34
  br label %bb109
bb109:
  %t451 = load i64, ptr %l38, !tbaa !24
  %t453 = add i64 %t451, 1
  store i64 %t453, ptr %l38, !tbaa !24
  br label %bb105
bb110:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/free:walker", ptr %t455, i32 0, i32 42
  %t459 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t457)
  store i64 %t459, ptr %l310
  br label %bb111
bb111:
  %t460 = load i64, ptr %l310, !tbaa !24
  %t461 = icmp sge i64 %t460, 0
  br i1 %t461, label %bb112, label %bb113
bb112:
  %t463 = load i64, ptr %l310, !tbaa !24
  %t464 = icmp sle i64 %t463, 1152921504606846975
  br i1 %t464, label %bb114, label %bb115
bb113:
  call void @__olang_check_failed(ptr @olang_loc_de370d56f621a286_665adcb3259bb65a)
  unreachable
bb114:
  %t466 = load i64, ptr %l310, !tbaa !24
  %t467 = mul i64 %t466, 8
  %t468 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t467)
  %t469 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  store { i64, ptr } %t470, ptr %l40, !tbaa !27
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/free:walker", ptr %t472, i32 0, i32 11
  %t475 = load i64, ptr %t474, !tbaa !24
  %t477 = add i64 %t475, 1
  store i64 %t477, ptr %l316, !tbaa !24
  %t478 = load i64, ptr %l316, !tbaa !24
  %t479 = icmp sge i64 %t478, 0
  br i1 %t479, label %bb116, label %bb117
bb115:
  call void @__olang_check_failed(ptr @olang_loc_de370d56f621a286_665adcb3259bb65a)
  unreachable
bb116:
  %t481 = load i64, ptr %l316, !tbaa !24
  %t482 = icmp sle i64 %t481, 1152921504606846975
  br i1 %t482, label %bb118, label %bb119
bb117:
  call void @__olang_check_failed(ptr @olang_loc_61a66e32b2a4c4a5_788650647dbfbbd9)
  unreachable
bb118:
  %t484 = load i64, ptr %l316, !tbaa !24
  %t485 = mul i64 %t484, 8
  %t486 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t485)
  %t487 = insertvalue { i64, ptr } undef, i64 %t484, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t486, 1
  store { i64, ptr } %t488, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/free:walker", ptr %t490, i32 0, i32 42
  %t494 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t492)
  store i64 %t494, ptr %l322
  br label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_61a66e32b2a4c4a5_788650647dbfbbd9)
  unreachable
bb120:
  %t495 = load i64, ptr %l322, !tbaa !24
  store i64 %t495, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t496 = load i64, ptr %l43, !tbaa !24
  %t497 = load i64, ptr %l42, !tbaa !24
  %t500 = icmp sgt i64 %t496, %t497
  br i1 %t500, label %bb121, label %bb122
bb121:
  %t502 = load i64, ptr %l44, !tbaa !24
  %t504 = icmp sgt i64 %t502, 0
  br i1 %t504, label %bb123, label %bb124
bb122:
  store i64 0, ptr %l326, !tbaa !24
  br label %bb126
bb123:
  %t506 = load i64, ptr %l43, !tbaa !24
  %t507 = load i64, ptr %l42, !tbaa !24
  %t510 = sub i64 %t506, %t507
  %t511 = load i64, ptr %l44, !tbaa !24
  %t514 = add i64 %t510, %t511
  %t516 = sub i64 %t514, 1
  %t517 = load i64, ptr %l44, !tbaa !24
  %t520 = sdiv i64 %t516, %t517
  store i64 %t520, ptr %l329, !tbaa !24
  br label %bb125
bb124:
  store i64 0, ptr %l329, !tbaa !24
  br label %bb125
bb125:
  %t522 = load i64, ptr %l329, !tbaa !24
  store i64 %t522, ptr %l326, !tbaa !24
  br label %bb126
bb126:
  %t523 = load i64, ptr %l326, !tbaa !24
  store i64 %t523, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb127
bb127:
  %t524 = load i64, ptr %l46, !tbaa !24
  %t525 = load i64, ptr %l45, !tbaa !24
  %t528 = icmp slt i64 %t524, %t525
  %t530 = xor i1 %t528, true
  br i1 %t530, label %bb128, label %bb129
bb128:
  br label %bb134
bb129:
  br label %bb130
bb130:
  %t532 = load i64, ptr %l42, !tbaa !24
  %t533 = load i64, ptr %l46, !tbaa !24
  %t534 = load i64, ptr %l44, !tbaa !24
  %t537 = mul i64 %t533, %t534
  %t540 = add i64 %t532, %t537
  store i64 %t540, ptr %l47, !tbaa !24
  %t542 = load ptr, ptr %l0, !tbaa !29
  %t544 = getelementptr %"compiler/free:walker", ptr %t542, i32 0, i32 43
  %t545 = load i64, ptr %l47, !tbaa !24
  %t548 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t544, i64 %t545)
  store i64 %t548, ptr %l350
  br label %bb131
bb131:
  %t549 = load i64, ptr %l350, !tbaa !24
  store i64 %t549, ptr %l48, !tbaa !24
  %t550 = load i64, ptr %l48, !tbaa !24
  %t552 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t553 = load ptr, ptr %t552, !tbaa !27
  %t554 = getelementptr i64, ptr %t553, i64 %t550
  %t555 = load i64, ptr %t554, !tbaa !34
  %t556 = load i64, ptr %l48, !tbaa !24
  %t558 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t559 = load ptr, ptr %t558, !tbaa !27
  %t560 = getelementptr i64, ptr %t559, i64 %t556
  %t561 = load i64, ptr %t560, !tbaa !34
  %t564 = add i64 %t555, %t561
  store i64 %t564, ptr %l355, !tbaa !24
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = getelementptr %"compiler/free:walker", ptr %t565, i32 0, i32 42
  %t568 = load i64, ptr %l47, !tbaa !24
  %t571 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t567, i64 %t568)
  store i64 %t571, ptr %l359
  br label %bb132
bb132:
  %t572 = load i64, ptr %l359, !tbaa !24
  %t573 = load i64, ptr %l355, !tbaa !24
  %t574 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t575 = load ptr, ptr %t574, !tbaa !27
  %t576 = getelementptr i64, ptr %t575, i64 %t573
  store i64 %t572, ptr %t576, !tbaa !34
  %t577 = load i64, ptr %l48, !tbaa !24
  store i64 %t577, ptr %l360, !tbaa !24
  %t578 = load i64, ptr %l360, !tbaa !24
  %t579 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr i64, ptr %t580, i64 %t578
  %t582 = load i64, ptr %t581, !tbaa !34
  %t584 = add i64 %t582, 1
  %t586 = load i64, ptr %l360, !tbaa !24
  %t587 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !27
  %t589 = getelementptr i64, ptr %t588, i64 %t586
  store i64 %t584, ptr %t589, !tbaa !34
  br label %bb133
bb133:
  %t590 = load i64, ptr %l46, !tbaa !24
  %t592 = add i64 %t590, 1
  store i64 %t592, ptr %l46, !tbaa !24
  br label %bb127
bb134:
  store i64 0, ptr %l49, !tbaa !24
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t596 = getelementptr %"compiler/free:walker", ptr %t594, i32 0, i32 44
  %t598 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t596)
  store i64 %t598, ptr %l367
  br label %bb135
bb135:
  %t599 = load i64, ptr %l367, !tbaa !24
  store i64 %t599, ptr %l50, !tbaa !24
  store i64 1, ptr %l51, !tbaa !24
  %t600 = load i64, ptr %l50, !tbaa !24
  %t601 = load i64, ptr %l49, !tbaa !24
  %t604 = icmp sgt i64 %t600, %t601
  br i1 %t604, label %bb136, label %bb137
bb136:
  %t606 = load i64, ptr %l51, !tbaa !24
  %t608 = icmp sgt i64 %t606, 0
  br i1 %t608, label %bb138, label %bb139
bb137:
  store i64 0, ptr %l371, !tbaa !24
  br label %bb141
bb138:
  %t610 = load i64, ptr %l50, !tbaa !24
  %t611 = load i64, ptr %l49, !tbaa !24
  %t614 = sub i64 %t610, %t611
  %t615 = load i64, ptr %l51, !tbaa !24
  %t618 = add i64 %t614, %t615
  %t620 = sub i64 %t618, 1
  %t621 = load i64, ptr %l51, !tbaa !24
  %t624 = sdiv i64 %t620, %t621
  store i64 %t624, ptr %l374, !tbaa !24
  br label %bb140
bb139:
  store i64 0, ptr %l374, !tbaa !24
  br label %bb140
bb140:
  %t626 = load i64, ptr %l374, !tbaa !24
  store i64 %t626, ptr %l371, !tbaa !24
  br label %bb141
bb141:
  %t627 = load i64, ptr %l371, !tbaa !24
  store i64 %t627, ptr %l52, !tbaa !24
  store i64 0, ptr %l53, !tbaa !24
  br label %bb142
bb142:
  %t628 = load i64, ptr %l53, !tbaa !24
  %t629 = load i64, ptr %l52, !tbaa !24
  %t632 = icmp slt i64 %t628, %t629
  %t634 = xor i1 %t632, true
  br i1 %t634, label %bb143, label %bb144
bb143:
  br label %bb319
bb144:
  br label %bb145
bb145:
  %t636 = load i64, ptr %l49, !tbaa !24
  %t637 = load i64, ptr %l53, !tbaa !24
  %t638 = load i64, ptr %l51, !tbaa !24
  %t641 = mul i64 %t637, %t638
  %t644 = add i64 %t636, %t641
  store i64 %t644, ptr %l54, !tbaa !24
  %t646 = load ptr, ptr %l0, !tbaa !29
  %t648 = getelementptr %"compiler/free:walker", ptr %t646, i32 0, i32 44
  %t649 = load i64, ptr %l54, !tbaa !24
  %t652 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t648, i64 %t649)
  store i64 %t652, ptr %l395
  br label %bb146
bb146:
  %t653 = load i64, ptr %l395, !tbaa !24
  store i64 %t653, ptr %l55, !tbaa !24
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t656 = getelementptr %"compiler/free:walker", ptr %t654, i32 0, i32 45
  %t657 = load i64, ptr %l54, !tbaa !24
  %t660 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t656, i64 %t657)
  store i64 %t660, ptr %l399
  br label %bb147
bb147:
  %t661 = load i64, ptr %l399, !tbaa !24
  store i64 %t661, ptr %l56, !tbaa !24
  %t662 = load ptr, ptr %l0, !tbaa !29
  %t664 = getelementptr %"compiler/free:walker", ptr %t662, i32 0, i32 46
  %t665 = load i64, ptr %l54, !tbaa !24
  %t668 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t664, i64 %t665)
  store i64 %t668, ptr %l403
  br label %bb148
bb148:
  %t669 = load i64, ptr %l403, !tbaa !24
  store i64 %t669, ptr %l57, !tbaa !24
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t672 = getelementptr %"compiler/free:walker", ptr %t670, i32 0, i32 36
  %t673 = load i64, ptr %l54, !tbaa !24
  %t676 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t672, i64 %t673)
  store i64 %t676, ptr %l407
  br label %bb149
bb149:
  %t677 = load i64, ptr %l407, !tbaa !24
  %t678 = icmp sge i64 %t677, 0
  br i1 %t678, label %bb150, label %bb151
bb150:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/free:walker", ptr %t680, i32 0, i32 55
  store ptr %t682, ptr %l411, !tbaa !29
  %t683 = load ptr, ptr %l0, !tbaa !29
  %t685 = getelementptr %"compiler/free:walker", ptr %t683, i32 0, i32 36
  %t686 = load i64, ptr %l54, !tbaa !24
  %t689 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t685, i64 %t686)
  store i64 %t689, ptr %l415
  br label %bb152
bb151:
  br label %bb157
bb152:
  %t690 = load ptr, ptr %l411, !tbaa !29
  %t691 = load i64, ptr %l415, !tbaa !24
  %t692 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t690, i64 %t691)
  %t693 = extractvalue { i32, i64 } %t692, 1
  %t694 = extractvalue { i32, i64 } %t692, 0
  store i32 %t694, ptr %l417
  %t695 = icmp ne i32 %t694, 0
  br i1 %t695, label %bb154, label %ok.696, !prof !99
ok.696:
  store i64 %t693, ptr %l416
  br label %bb153
bb153:
  %t697 = load i64, ptr %l416, !tbaa !24
  store i64 %t697, ptr %l409, !tbaa !24
  br label %bb156
bb154:
  br label %bb155
bb155:
  %t698 = load i64, ptr %l56, !tbaa !24
  store i64 %t698, ptr %l409, !tbaa !24
  br label %bb156
bb156:
  %t700 = load i64, ptr %l409, !tbaa !24
  store i64 %t700, ptr %l56, !tbaa !24
  br label %bb157
bb157:
  %t701 = load i64, ptr %l55, !tbaa !24
  %t703 = icmp sge i64 %t701, 0
  br i1 %t703, label %bb158, label %bb159
bb158:
  %t705 = load i64, ptr %l55, !tbaa !24
  store i64 %t705, ptr %l422, !tbaa !24
  %t706 = load ptr, ptr %l1, !tbaa !29
  %t708 = getelementptr %"compiler/free:Free", ptr %t706, i32 0, i32 44
  %t710 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t708)
  store i64 %t710, ptr %l425
  br label %bb160
bb159:
  store i1 false, ptr %l421, !tbaa !21
  br label %bb165
bb160:
  %t711 = load i64, ptr %l422, !tbaa !24
  %t712 = load i64, ptr %l425, !tbaa !24
  %t713 = icmp sge i64 %t711, %t712
  br i1 %t713, label %bb161, label %bb162
bb161:
  store i1 true, ptr %l427, !tbaa !21
  br label %bb164
bb162:
  %t715 = load ptr, ptr %l1, !tbaa !29
  %t717 = getelementptr %"compiler/free:Free", ptr %t715, i32 0, i32 44
  %t718 = load i64, ptr %l55, !tbaa !24
  %t721 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t717, i64 %t718)
  store i64 %t721, ptr %l431
  br label %bb163
bb163:
  %t722 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t723 = load i64, ptr %l431, !tbaa !24
  %t725 = icmp ne i64 %t723, %t722
  store i1 %t725, ptr %l427, !tbaa !21
  br label %bb164
bb164:
  %t727 = load i1, ptr %l427, !tbaa !21
  store i1 %t727, ptr %l421, !tbaa !21
  br label %bb165
bb165:
  %t728 = load i1, ptr %l421, !tbaa !21
  br i1 %t728, label %bb166, label %bb167
bb166:
  br label %bb318
bb167:
  br label %bb168
bb168:
  %t729 = load ptr, ptr %l0, !tbaa !29
  %t731 = getelementptr %"compiler/free:walker", ptr %t729, i32 0, i32 50
  %t732 = load i64, ptr %l54, !tbaa !24
  %t735 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t731, i64 %t732)
  store i64 %t735, ptr %l437
  br label %bb169
bb169:
  %t736 = load i64, ptr %l437, !tbaa !24
  store i64 %t736, ptr %l58, !tbaa !24
  %t737 = load i64, ptr %l57, !tbaa !24
  %t738 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  %t741 = icmp ne i64 %t737, %t738
  br i1 %t741, label %bb170, label %bb171
bb170:
  %t743 = load i64, ptr %l57, !tbaa !24
  %t744 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  %t747 = icmp ne i64 %t743, %t744
  store i1 %t747, ptr %l441, !tbaa !21
  br label %bb172
bb171:
  store i1 false, ptr %l441, !tbaa !21
  br label %bb172
bb172:
  %t749 = load i1, ptr %l441, !tbaa !21
  br i1 %t749, label %bb173, label %bb174
bb173:
  %t750 = load i64, ptr %l57, !tbaa !24
  %t751 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  %t754 = icmp ne i64 %t750, %t751
  store i1 %t754, ptr %l445, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l445, !tbaa !21
  br label %bb175
bb175:
  %t756 = load i1, ptr %l445, !tbaa !21
  br i1 %t756, label %bb176, label %bb177
bb176:
  %t757 = load i64, ptr %l57, !tbaa !24
  %t758 = load i64, ptr @G_2ecompiler_2ffree_2eLHeld, !tbaa !24
  %t761 = icmp ne i64 %t757, %t758
  store i1 %t761, ptr %l449, !tbaa !21
  br label %bb178
bb177:
  store i1 false, ptr %l449, !tbaa !21
  br label %bb178
bb178:
  %t763 = load i1, ptr %l449, !tbaa !21
  br i1 %t763, label %bb179, label %bb180
bb179:
  %t764 = load ptr, ptr %l1, !tbaa !29
  store ptr %t764, ptr %l454, !tbaa !29
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t767 = getelementptr %"compiler/free:walker", ptr %t765, i32 0, i32 49
  %t768 = load i64, ptr %l54, !tbaa !24
  %t771 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t767, i64 %t768)
  store i64 %t771, ptr %l458
  br label %bb181
bb180:
  store i1 false, ptr %l453, !tbaa !21
  br label %bb183
bb181:
  %t772 = load ptr, ptr %l454, !tbaa !29
  %t773 = load i64, ptr %l458, !tbaa !24
  %t774 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eisDtor(ptr %v0, ptr %t772, i64 %t773)
  store i1 %t774, ptr %l459
  br label %bb182
bb182:
  %t775 = load i1, ptr %l459, !tbaa !21
  %t776 = xor i1 %t775, true
  store i1 %t776, ptr %l453, !tbaa !21
  br label %bb183
bb183:
  %t778 = load i1, ptr %l453, !tbaa !21
  br i1 %t778, label %bb184, label %bb185
bb184:
  %t779 = load i64, ptr %l56, !tbaa !24
  %t781 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t782 = load ptr, ptr %t781, !tbaa !27
  %t783 = getelementptr i64, ptr %t782, i64 %t779
  %t784 = load i64, ptr %t783, !tbaa !34
  store i64 %t784, ptr %l59, !tbaa !24
  %t786 = load i64, ptr %l56, !tbaa !24
  %t788 = add i64 %t786, 1
  %t790 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t791 = load ptr, ptr %t790, !tbaa !27
  %t792 = getelementptr i64, ptr %t791, i64 %t788
  %t793 = load i64, ptr %t792, !tbaa !34
  store i64 %t793, ptr %l60, !tbaa !24
  store i64 1, ptr %l61, !tbaa !24
  %t795 = load i64, ptr %l60, !tbaa !24
  %t796 = load i64, ptr %l59, !tbaa !24
  %t799 = icmp sgt i64 %t795, %t796
  br i1 %t799, label %bb186, label %bb187
bb185:
  br label %bb212
bb186:
  %t801 = load i64, ptr %l61, !tbaa !24
  %t803 = icmp sgt i64 %t801, 0
  br i1 %t803, label %bb188, label %bb189
bb187:
  store i64 0, ptr %l469, !tbaa !24
  br label %bb191
bb188:
  %t805 = load i64, ptr %l60, !tbaa !24
  %t806 = load i64, ptr %l59, !tbaa !24
  %t809 = sub i64 %t805, %t806
  %t810 = load i64, ptr %l61, !tbaa !24
  %t813 = add i64 %t809, %t810
  %t815 = sub i64 %t813, 1
  %t816 = load i64, ptr %l61, !tbaa !24
  %t819 = sdiv i64 %t815, %t816
  store i64 %t819, ptr %l472, !tbaa !24
  br label %bb190
bb189:
  store i64 0, ptr %l472, !tbaa !24
  br label %bb190
bb190:
  %t821 = load i64, ptr %l472, !tbaa !24
  store i64 %t821, ptr %l469, !tbaa !24
  br label %bb191
bb191:
  %t822 = load i64, ptr %l469, !tbaa !24
  store i64 %t822, ptr %l62, !tbaa !24
  store i64 0, ptr %l63, !tbaa !24
  br label %bb192
bb192:
  store %olang.scope zeroinitializer, ptr %s30
  %t823 = load i64, ptr %l63, !tbaa !24
  %t824 = load i64, ptr %l62, !tbaa !24
  %t827 = icmp slt i64 %t823, %t824
  %t829 = xor i1 %t827, true
  br i1 %t829, label %bb193, label %bb194
bb193:
  call void @__olang_scope_close(ptr %s30)
  br label %bb211
bb194:
  br label %bb195
bb195:
  %t831 = load i64, ptr %l59, !tbaa !24
  %t832 = load i64, ptr %l63, !tbaa !24
  %t833 = load i64, ptr %l61, !tbaa !24
  %t836 = mul i64 %t832, %t833
  %t839 = add i64 %t831, %t836
  %t843 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t844 = load ptr, ptr %t843, !tbaa !27
  %t845 = getelementptr i64, ptr %t844, i64 %t839
  %t846 = load i64, ptr %t845, !tbaa !34
  store i64 %t846, ptr %l65, !tbaa !24
  %t848 = load i64, ptr %l55, !tbaa !24
  %t850 = icmp sge i64 %t848, 0
  br i1 %t850, label %bb196, label %bb197
bb196:
  %t852 = load i64, ptr %l65, !tbaa !24
  %t853 = load i64, ptr %l55, !tbaa !24
  %t856 = icmp ne i64 %t852, %t853
  store i1 %t856, ptr %l494, !tbaa !21
  br label %bb198
bb197:
  store i1 false, ptr %l494, !tbaa !21
  br label %bb198
bb198:
  %t858 = load i1, ptr %l494, !tbaa !21
  br i1 %t858, label %bb199, label %bb200
bb199:
  store i1 true, ptr %l498, !tbaa !21
  br label %bb202
bb200:
  %t859 = load ptr, ptr %l1, !tbaa !29
  %t861 = getelementptr %"compiler/free:Free", ptr %t859, i32 0, i32 44
  %t862 = load i64, ptr %l65, !tbaa !24
  %t865 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t861, i64 %t862)
  store i64 %t865, ptr %l502
  br label %bb201
bb201:
  %t866 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t867 = load i64, ptr %l502, !tbaa !24
  %t869 = icmp ne i64 %t867, %t866
  store i1 %t869, ptr %l498, !tbaa !21
  br label %bb202
bb202:
  %t871 = load i1, ptr %l498, !tbaa !21
  br i1 %t871, label %bb203, label %bb204
bb203:
  call void @__olang_scope_close(ptr %s30)
  br label %bb210
bb204:
  br label %bb205
bb205:
  %t872 = load ptr, ptr %l1, !tbaa !29
  store ptr %t872, ptr %l505, !tbaa !29
  %t873 = load i64, ptr %l65, !tbaa !24
  store i64 %t873, ptr %l506, !tbaa !24
  %t874 = load ptr, ptr %l2, !tbaa !29
  %t876 = getelementptr %"compiler/typed:Body", ptr %t874, i32 0, i32 3
  %t877 = load i64, ptr %t876, !tbaa !24
  store i64 %t877, ptr %l508, !tbaa !24
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t880 = getelementptr %"compiler/free:walker", ptr %t878, i32 0, i32 47
  %t881 = load i64, ptr %l54, !tbaa !24
  %t884 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t880, i64 %t881)
  store %"compiler/source:Span" %t884, ptr %l512
  br label %bb206
bb206:
  %t885 = load ptr, ptr %l1, !tbaa !29
  store ptr %t885, ptr %l513, !tbaa !29
  %t886 = load ptr, ptr %l2, !tbaa !29
  %t888 = getelementptr %"compiler/typed:Body", ptr %t886, i32 0, i32 3
  %t889 = load i64, ptr %t888, !tbaa !24
  store i64 %t889, ptr %l515, !tbaa !24
  %t890 = load ptr, ptr %l0, !tbaa !29
  %t892 = getelementptr %"compiler/free:walker", ptr %t890, i32 0, i32 47
  %t893 = load i64, ptr %l54, !tbaa !24
  %t896 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t892, i64 %t893)
  store %"compiler/source:Span" %t896, ptr %l519
  br label %bb207
bb207:
  %t897 = load ptr, ptr %l513, !tbaa !29
  %t898 = load i64, ptr %l515, !tbaa !24
  %t899 = load %"compiler/source:Span", ptr %l519
  %t900 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s30, ptr %t897, i64 %t898, %"compiler/source:Span" %t899)
  store { i64, ptr } %t900, ptr %l520
  br label %bb208
bb208:
  %t901 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d75, i32 0, i32 1) }, 1
  %t902 = extractvalue { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d75, i32 0, i32 1) }, 0
  %t903 = load { i64, ptr }, ptr %l520, !tbaa !27
  %t904 = extractvalue { i64, ptr } %t903, 1
  %t905 = extractvalue { i64, ptr } %t903, 0
  %t906 = add i64 %t902, %t905
  %t907 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t908 = extractvalue { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t909 = add i64 %t906, %t908
  %t910 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t909)
  call void @olang_textcopy(ptr %t910, ptr %t901, i64 %t902)
  %t911 = getelementptr i8, ptr %t910, i64 %t902
  call void @olang_textcopy(ptr %t911, ptr %t904, i64 %t905)
  %t912 = getelementptr i8, ptr %t911, i64 %t905
  call void @olang_textcopy(ptr %t912, ptr %t907, i64 %t908)
  %t913 = insertvalue { i64, ptr } undef, i64 %t909, 0
  %t914 = insertvalue { i64, ptr } %t913, ptr %t910, 1
  %t916 = extractvalue { i64, ptr } %t914, 0
  %t917 = extractvalue { i64, ptr } %t914, 1
  %t918 = mul i64 %t916, 1
  %t919 = call ptr @__olang_scope_alloc(ptr %s30, i64 %t918)
  call void @llvm.memcpy.p0.p0.i64(ptr %t919, ptr %t917, i64 %t918, i1 false)
  %t920 = insertvalue { i64, ptr } undef, i64 %t916, 0
  %t921 = insertvalue { i64, ptr } %t920, ptr %t919, 1
  %t922 = load i64, ptr %l58, !tbaa !24
  %t923 = load ptr, ptr %l505, !tbaa !29
  %t924 = load i64, ptr %l506, !tbaa !24
  %t925 = load i64, ptr %l508, !tbaa !24
  %t926 = load %"compiler/source:Span", ptr %l512
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %s30, ptr %t923, i64 %t924, i64 %t925, %"compiler/source:Span" %t926, { i64, ptr } %t921, i64 %t922)
  br label %bb209
bb209:
  call void @__olang_scope_close(ptr %s30)
  br label %bb210
bb210:
  %t929 = load i64, ptr %l63, !tbaa !24
  %t931 = add i64 %t929, 1
  store i64 %t931, ptr %l63, !tbaa !24
  br label %bb192
bb211:
  br label %bb212
bb212:
  store ptr %l20, ptr %l66, !tbaa !29
  store i64 0, ptr %l67, !tbaa !24
  br label %bb213
bb213:
  store %olang.scope zeroinitializer, ptr %s35
  %t934 = load i64, ptr %l67, !tbaa !24
  store i64 %t934, ptr %l527, !tbaa !24
  %t935 = load ptr, ptr %l66, !tbaa !29
  %t937 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t935)
  store i64 %t937, ptr %l529
  br label %bb214
bb214:
  %t938 = load i64, ptr %l527, !tbaa !24
  %t939 = load i64, ptr %l529, !tbaa !24
  %t940 = icmp slt i64 %t938, %t939
  %t942 = xor i1 %t940, true
  br i1 %t942, label %bb215, label %bb216
bb215:
  call void @__olang_scope_close(ptr %s35)
  br label %bb317
bb216:
  br label %bb217
bb217:
  %t944 = load ptr, ptr %l66, !tbaa !29
  %t945 = load i64, ptr %l67, !tbaa !24
  %t948 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t944, i64 %t945)
  store i64 %t948, ptr %l534
  br label %bb218
bb218:
  %t949 = load i64, ptr %l534, !tbaa !24
  store i64 %t949, ptr %l68, !tbaa !24
  store i1 false, ptr %l69, !tbaa !21
  %t950 = load i64, ptr %l68, !tbaa !24
  %t953 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %l3, i64 %t950)
  store ptr %t953, ptr %l537
  br label %bb219
bb219:
  %t954 = load ptr, ptr %l537, !tbaa !29
  store ptr %t954, ptr %l70, !tbaa !29
  store i64 0, ptr %l71, !tbaa !24
  br label %bb220
bb220:
  %t955 = load i64, ptr %l71, !tbaa !24
  store i64 %t955, ptr %l538, !tbaa !24
  %t956 = load ptr, ptr %l70, !tbaa !29
  %t958 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t956)
  store i64 %t958, ptr %l540
  br label %bb221
bb221:
  %t959 = load i64, ptr %l538, !tbaa !24
  %t960 = load i64, ptr %l540, !tbaa !24
  %t961 = icmp slt i64 %t959, %t960
  %t963 = xor i1 %t961, true
  br i1 %t963, label %bb222, label %bb223
bb222:
  br label %bb237
bb223:
  br label %bb224
bb224:
  %t965 = load ptr, ptr %l70, !tbaa !29
  %t966 = load i64, ptr %l71, !tbaa !24
  %t969 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t965, i64 %t966)
  store i64 %t969, ptr %l545
  br label %bb225
bb225:
  %t970 = load i64, ptr %l545, !tbaa !24
  store i64 %t970, ptr %l72, !tbaa !24
  %t971 = load i64, ptr %l55, !tbaa !24
  %t973 = icmp slt i64 %t971, 0
  br i1 %t973, label %bb226, label %bb227
bb226:
  store i1 true, ptr %l548, !tbaa !21
  br label %bb228
bb227:
  %t975 = load i64, ptr %l72, !tbaa !24
  %t976 = load i64, ptr %l55, !tbaa !24
  %t979 = icmp eq i64 %t975, %t976
  store i1 %t979, ptr %l548, !tbaa !21
  br label %bb228
bb228:
  %t981 = load i1, ptr %l548, !tbaa !21
  br i1 %t981, label %bb229, label %bb230
bb229:
  %t982 = load ptr, ptr %l1, !tbaa !29
  %t984 = getelementptr %"compiler/free:Free", ptr %t982, i32 0, i32 44
  %t985 = load i64, ptr %l72, !tbaa !24
  %t988 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t984, i64 %t985)
  store i64 %t988, ptr %l556
  br label %bb231
bb230:
  store i1 false, ptr %l552, !tbaa !21
  br label %bb232
bb231:
  %t989 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t990 = load i64, ptr %l556, !tbaa !24
  %t992 = icmp eq i64 %t990, %t989
  store i1 %t992, ptr %l552, !tbaa !21
  br label %bb232
bb232:
  %t994 = load i1, ptr %l552, !tbaa !21
  br i1 %t994, label %bb233, label %bb234
bb233:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb235
bb234:
  br label %bb235
bb235:
  br label %bb236
bb236:
  %t995 = load i64, ptr %l71, !tbaa !24
  %t997 = add i64 %t995, 1
  store i64 %t997, ptr %l71, !tbaa !24
  br label %bb220
bb237:
  %t999 = load i1, ptr %l69, !tbaa !21
  %t1001 = xor i1 %t999, true
  br i1 %t1001, label %bb238, label %bb239
bb238:
  call void @__olang_scope_close(ptr %s35)
  br label %bb316
bb239:
  br label %bb240
bb240:
  %t1003 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1003, ptr %l563, !tbaa !29
  %t1004 = load i64, ptr %l68, !tbaa !24
  store i64 %t1004, ptr %l564, !tbaa !24
  %t1005 = load i64, ptr %l56, !tbaa !24
  store i64 %t1005, ptr %l565, !tbaa !24
  %t1006 = load i64, ptr %l68, !tbaa !24
  %t1009 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %l4, i64 %t1006)
  store ptr %t1009, ptr %l568
  br label %bb241
bb241:
  %t1010 = load ptr, ptr %l563, !tbaa !29
  %t1011 = load i64, ptr %l564, !tbaa !24
  %t1012 = load i64, ptr %l565, !tbaa !24
  %t1013 = load ptr, ptr %l568, !tbaa !29
  %t1014 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %s0, ptr %t1010, i64 %t1011, i64 %t1012, ptr %t1013)
  store i64 %t1014, ptr %l569
  br label %bb242
bb242:
  %t1015 = load i64, ptr %l569, !tbaa !24
  store i64 %t1015, ptr %l73, !tbaa !24
  %t1016 = load i64, ptr %l73, !tbaa !24
  %t1018 = icmp slt i64 %t1016, 0
  br i1 %t1018, label %bb243, label %bb244
bb243:
  call void @__olang_scope_close(ptr %s35)
  br label %bb316
bb244:
  br label %bb245
bb245:
  %t1020 = load ptr, ptr %l1, !tbaa !29
  %t1022 = getelementptr %"compiler/free:Free", ptr %t1020, i32 0, i32 0
  %t1023 = load ptr, ptr %t1022, !tbaa !29
  %t1025 = getelementptr %"compiler/generic:Program", ptr %t1023, i32 0, i32 0
  %t1026 = load ptr, ptr %t1025, !tbaa !29
  %t1028 = getelementptr %"compiler/load:Loader", ptr %t1026, i32 0, i32 3
  %t1029 = load ptr, ptr %t1028, !tbaa !29
  store ptr %t1029, ptr %l575, !tbaa !29
  %t1030 = load ptr, ptr %l2, !tbaa !29
  %t1032 = getelementptr %"compiler/typed:Body", ptr %t1030, i32 0, i32 7
  %t1033 = load i64, ptr %l68, !tbaa !24
  %t1036 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t1032, i64 %t1033)
  store %"compiler/typed:Local" %t1036, ptr %l579
  br label %bb246
bb246:
  %t1037 = getelementptr %"compiler/typed:Local", ptr %l579, i32 0, i32 0
  %t1038 = load i32, ptr %t1037, !tbaa !23
  %t1039 = load ptr, ptr %l575, !tbaa !29
  %t1041 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t1039, i32 %t1038)
  store { i64, ptr } %t1041, ptr %l581
  br label %bb247
bb247:
  %t1042 = load { i64, ptr }, ptr %l581, !tbaa !27
  store { i64, ptr } %t1042, ptr %l74, !tbaa !27
  %t1043 = load ptr, ptr %l1, !tbaa !29
  %t1045 = getelementptr %"compiler/free:Free", ptr %t1043, i32 0, i32 0
  %t1046 = load ptr, ptr %t1045, !tbaa !29
  %t1048 = getelementptr %"compiler/generic:Program", ptr %t1046, i32 0, i32 0
  %t1049 = load ptr, ptr %t1048, !tbaa !29
  %t1051 = getelementptr %"compiler/load:Loader", ptr %t1049, i32 0, i32 4
  %t1052 = load ptr, ptr %t1051, !tbaa !29
  store ptr %t1052, ptr %l585, !tbaa !29
  %t1053 = load ptr, ptr %l2, !tbaa !29
  %t1055 = getelementptr %"compiler/typed:Body", ptr %t1053, i32 0, i32 3
  %t1056 = load i64, ptr %t1055, !tbaa !24
  store i64 %t1056, ptr %l587, !tbaa !24
  %t1057 = load ptr, ptr %l2, !tbaa !29
  %t1059 = getelementptr %"compiler/typed:Body", ptr %t1057, i32 0, i32 7
  %t1060 = load i64, ptr %l68, !tbaa !24
  %t1063 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t1059, i64 %t1060)
  store %"compiler/typed:Local" %t1063, ptr %l591
  br label %bb248
bb248:
  %t1064 = getelementptr %"compiler/typed:Local", ptr %l591, i32 0, i32 1
  %t1065 = getelementptr %"compiler/source:Span", ptr %t1064, i32 0, i32 0
  %t1066 = load i32, ptr %t1065, !tbaa !23
  %t1068 = sext i32 %t1066 to i64
  %t1069 = load ptr, ptr %l585, !tbaa !29
  %t1070 = load i64, ptr %l587, !tbaa !24
  %t1072 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t1069, i64 %t1070, i64 %t1068)
  store i64 %t1072, ptr %l594
  br label %bb249
bb249:
  %t1073 = load i64, ptr %l594, !tbaa !24
  store i64 %t1073, ptr %l75, !tbaa !24
  %t1074 = load ptr, ptr %l1, !tbaa !29
  %t1076 = getelementptr %"compiler/free:Free", ptr %t1074, i32 0, i32 0
  %t1077 = load ptr, ptr %t1076, !tbaa !29
  %t1079 = getelementptr %"compiler/generic:Program", ptr %t1077, i32 0, i32 0
  %t1080 = load ptr, ptr %t1079, !tbaa !29
  %t1082 = getelementptr %"compiler/load:Loader", ptr %t1080, i32 0, i32 4
  %t1083 = load ptr, ptr %t1082, !tbaa !29
  store ptr %t1083, ptr %l598, !tbaa !29
  %t1084 = load ptr, ptr %l2, !tbaa !29
  %t1086 = getelementptr %"compiler/typed:Body", ptr %t1084, i32 0, i32 3
  %t1087 = load i64, ptr %t1086, !tbaa !24
  store i64 %t1087, ptr %l600, !tbaa !24
  %t1088 = load ptr, ptr %l0, !tbaa !29
  %t1090 = getelementptr %"compiler/free:walker", ptr %t1088, i32 0, i32 47
  %t1091 = load i64, ptr %l54, !tbaa !24
  %t1094 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1090, i64 %t1091)
  store %"compiler/source:Span" %t1094, ptr %l604
  br label %bb250
bb250:
  %t1095 = getelementptr %"compiler/source:Span", ptr %l604, i32 0, i32 0
  %t1096 = load i32, ptr %t1095, !tbaa !23
  %t1098 = sext i32 %t1096 to i64
  %t1099 = load ptr, ptr %l598, !tbaa !29
  %t1100 = load i64, ptr %l600, !tbaa !24
  %t1102 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %t1099, i64 %t1100, i64 %t1098)
  store i64 %t1102, ptr %l607
  br label %bb251
bb251:
  %t1103 = load i64, ptr %l607, !tbaa !24
  store i64 %t1103, ptr %l76, !tbaa !24
  %t1104 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1105 = load i64, ptr %l75, !tbaa !24
  %t1106 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t1107 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t1109 = extractvalue { i64, ptr } %t1104, 1
  %t1110 = extractvalue { i64, ptr } %t1104, 0
  %t1111 = add i64 %t1107, %t1110
  %t1112 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t1113 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t1114 = add i64 %t1111, %t1113
  %t1116 = call i64 @__olang_fmt_i64(ptr null, i64 %t1105)
  %t1117 = add i64 %t1114, %t1116
  %t1118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t1119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t1120 = add i64 %t1117, %t1119
  %t1121 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1120)
  call void @olang_textcopy(ptr %t1121, ptr %t1106, i64 %t1107)
  %t1122 = getelementptr i8, ptr %t1121, i64 %t1107
  call void @olang_textcopy(ptr %t1122, ptr %t1109, i64 %t1110)
  %t1123 = getelementptr i8, ptr %t1122, i64 %t1110
  call void @olang_textcopy(ptr %t1123, ptr %t1112, i64 %t1113)
  %t1124 = getelementptr i8, ptr %t1123, i64 %t1113
  %t1125 = call i64 @__olang_fmt_i64(ptr %t1124, i64 %t1105)
  %t1126 = getelementptr i8, ptr %t1124, i64 %t1116
  call void @olang_textcopy(ptr %t1126, ptr %t1118, i64 %t1119)
  %t1127 = insertvalue { i64, ptr } undef, i64 %t1120, 0
  %t1128 = insertvalue { i64, ptr } %t1127, ptr %t1121, 1
  store { i64, ptr } %t1128, ptr %l77, !tbaa !27
  %t1130 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1131 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t1132 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t1134 = extractvalue { i64, ptr } %t1130, 1
  %t1135 = extractvalue { i64, ptr } %t1130, 0
  %t1136 = add i64 %t1132, %t1135
  %t1137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 1
  %t1138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) }, 0
  %t1139 = add i64 %t1136, %t1138
  %t1140 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1139)
  call void @olang_textcopy(ptr %t1140, ptr %t1131, i64 %t1132)
  %t1141 = getelementptr i8, ptr %t1140, i64 %t1132
  call void @olang_textcopy(ptr %t1141, ptr %t1134, i64 %t1135)
  %t1142 = getelementptr i8, ptr %t1141, i64 %t1135
  call void @olang_textcopy(ptr %t1142, ptr %t1137, i64 %t1138)
  %t1143 = insertvalue { i64, ptr } undef, i64 %t1139, 0
  %t1144 = insertvalue { i64, ptr } %t1143, ptr %t1140, 1
  store { i64, ptr } %t1144, ptr %l78, !tbaa !27
  %t1146 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t1148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s35, { i64, ptr } %t1146, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d82, i32 0, i32 1) })
  store i1 %t1148, ptr %l614
  br label %bb252
bb252:
  %t1149 = load i1, ptr %l614, !tbaa !21
  br i1 %t1149, label %bb253, label %bb254
bb253:
  store %olang.scope zeroinitializer, ptr %s44
  %t1150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1150, ptr %l615, !tbaa !29
  %t1151 = load ptr, ptr %l2, !tbaa !29
  %t1153 = getelementptr %"compiler/typed:Body", ptr %t1151, i32 0, i32 3
  %t1154 = load i64, ptr %t1153, !tbaa !24
  store i64 %t1154, ptr %l617, !tbaa !24
  %t1155 = load ptr, ptr %l0, !tbaa !29
  %t1157 = getelementptr %"compiler/free:walker", ptr %t1155, i32 0, i32 21
  %t1158 = load i64, ptr %l68, !tbaa !24
  %t1161 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1157, i64 %t1158)
  store %"compiler/source:Span" %t1161, ptr %l621
  br label %bb255
bb254:
  br label %bb271
bb255:
  %t1162 = load ptr, ptr %l615, !tbaa !29
  %t1163 = load i64, ptr %l617, !tbaa !24
  %t1164 = load %"compiler/source:Span", ptr %l621
  %t1165 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s44, ptr %t1162, i64 %t1163, %"compiler/source:Span" %t1164)
  store { i64, ptr } %t1165, ptr %l622
  br label %bb256
bb256:
  %t1166 = load { i64, ptr }, ptr %l622, !tbaa !27
  store { i64, ptr } %t1166, ptr %l79, !tbaa !27
  %t1167 = load i64, ptr %l75, !tbaa !24
  store i64 %t1167, ptr %l623, !tbaa !24
  %t1168 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t1170 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s44, ptr %s44, { i64, ptr } %t1168, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t1170, ptr %l625
  br label %bb257
bb257:
  %t1171 = load i1, ptr %l625, !tbaa !21
  %t1172 = xor i1 %t1171, true
  br i1 %t1172, label %bb258, label %bb259
bb258:
  %t1174 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l629, !tbaa !27
  %t1176 = load { i64, ptr }, ptr %l629, !tbaa !27
  %t1177 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s44, ptr %s44, { i64, ptr } %t1174, { i64, ptr } %t1176)
  store i1 %t1177, ptr %l630
  br label %bb260
bb259:
  store i1 false, ptr %l627, !tbaa !21
  br label %bb261
bb260:
  %t1178 = load i1, ptr %l630, !tbaa !21
  %t1179 = xor i1 %t1178, true
  store i1 %t1179, ptr %l627, !tbaa !21
  br label %bb261
bb261:
  %t1181 = load i1, ptr %l627, !tbaa !21
  br i1 %t1181, label %bb262, label %bb263
bb262:
  %t1182 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t1183 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d85, i32 0, i32 1) }, 1
  %t1184 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d85, i32 0, i32 1) }, 0
  %t1186 = extractvalue { i64, ptr } %t1182, 1
  %t1187 = extractvalue { i64, ptr } %t1182, 0
  %t1188 = add i64 %t1184, %t1187
  %t1189 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 1
  %t1190 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d86, i32 0, i32 1) }, 0
  %t1191 = add i64 %t1188, %t1190
  %t1192 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1191)
  call void @olang_textcopy(ptr %t1192, ptr %t1183, i64 %t1184)
  %t1193 = getelementptr i8, ptr %t1192, i64 %t1184
  call void @olang_textcopy(ptr %t1193, ptr %t1186, i64 %t1187)
  %t1194 = getelementptr i8, ptr %t1193, i64 %t1187
  call void @olang_textcopy(ptr %t1194, ptr %t1189, i64 %t1190)
  %t1195 = insertvalue { i64, ptr } undef, i64 %t1191, 0
  %t1196 = insertvalue { i64, ptr } %t1195, ptr %t1192, 1
  %t1198 = extractvalue { i64, ptr } %t1196, 0
  %t1199 = extractvalue { i64, ptr } %t1196, 1
  %t1200 = mul i64 %t1198, 1
  %t1201 = call ptr @__olang_scope_alloc(ptr %s44, i64 %t1200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1201, ptr %t1199, i64 %t1200, i1 false)
  %t1202 = insertvalue { i64, ptr } undef, i64 %t1198, 0
  %t1203 = insertvalue { i64, ptr } %t1202, ptr %t1201, 1
  store { i64, ptr } %t1203, ptr %l632, !tbaa !27
  br label %bb264
bb263:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l632, !tbaa !27
  br label %bb264
bb264:
  %t1205 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t1206 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t1207 = load i64, ptr %l623, !tbaa !24
  %t1208 = call i64 @__olang_fmt_i64(ptr null, i64 %t1207)
  %t1209 = add i64 %t1206, %t1208
  %t1210 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d89, i32 0, i32 1) }, 1
  %t1211 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d89, i32 0, i32 1) }, 0
  %t1212 = add i64 %t1209, %t1211
  %t1213 = load { i64, ptr }, ptr %l632, !tbaa !27
  %t1214 = extractvalue { i64, ptr } %t1213, 1
  %t1215 = extractvalue { i64, ptr } %t1213, 0
  %t1216 = add i64 %t1212, %t1215
  %t1217 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1216)
  call void @olang_textcopy(ptr %t1217, ptr %t1205, i64 %t1206)
  %t1218 = getelementptr i8, ptr %t1217, i64 %t1206
  %t1219 = call i64 @__olang_fmt_i64(ptr %t1218, i64 %t1207)
  %t1220 = getelementptr i8, ptr %t1218, i64 %t1208
  call void @olang_textcopy(ptr %t1220, ptr %t1210, i64 %t1211)
  %t1221 = getelementptr i8, ptr %t1220, i64 %t1211
  call void @olang_textcopy(ptr %t1221, ptr %t1214, i64 %t1215)
  %t1222 = insertvalue { i64, ptr } undef, i64 %t1216, 0
  %t1223 = insertvalue { i64, ptr } %t1222, ptr %t1217, 1
  store { i64, ptr } %t1223, ptr %l636, !tbaa !27
  %t1224 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1225 = extractvalue { i64, ptr } %t1224, 0
  %t1226 = load { i64, ptr }, ptr %l636, !tbaa !27
  %t1227 = extractvalue { i64, ptr } %t1226, 0
  store i64 %t1227, ptr %l638, !tbaa !24
  %t1229 = load i64, ptr %l638, !tbaa !24
  %t1230 = icmp eq i64 %t1225, %t1229
  br i1 %t1230, label %bb265, label %bb266
bb265:
  %t1232 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t1233 = load ptr, ptr %t1232, !tbaa !27
  %t1234 = getelementptr { i64, ptr }, ptr %l636, i32 0, i32 1
  %t1235 = load ptr, ptr %t1234, !tbaa !27
  %t1236 = load i64, ptr %l638, !tbaa !24
  %t1237 = mul i64 %t1236, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1233, ptr %t1235, i64 %t1237, i1 false)
  br label %bb267
bb266:
  %t1238 = load { i64, ptr }, ptr %l636, !tbaa !27
  store { i64, ptr } %t1238, ptr %l77, !tbaa !27
  br label %bb267
bb267:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l640, !tbaa !27
  %t1239 = load { i64, ptr }, ptr %l640, !tbaa !27
  store { i64, ptr } %t1239, ptr %l641, !tbaa !27
  %t1240 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1241 = extractvalue { i64, ptr } %t1240, 0
  %t1242 = load { i64, ptr }, ptr %l641, !tbaa !27
  %t1243 = extractvalue { i64, ptr } %t1242, 0
  store i64 %t1243, ptr %l643, !tbaa !24
  %t1245 = load i64, ptr %l643, !tbaa !24
  %t1246 = icmp eq i64 %t1241, %t1245
  br i1 %t1246, label %bb268, label %bb269
bb268:
  %t1248 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t1249 = load ptr, ptr %t1248, !tbaa !27
  %t1250 = getelementptr { i64, ptr }, ptr %l641, i32 0, i32 1
  %t1251 = load ptr, ptr %t1250, !tbaa !27
  %t1252 = load i64, ptr %l643, !tbaa !24
  %t1253 = mul i64 %t1252, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1249, ptr %t1251, i64 %t1253, i1 false)
  br label %bb270
bb269:
  %t1254 = load { i64, ptr }, ptr %l641, !tbaa !27
  %t1255 = extractvalue { i64, ptr } %t1254, 0
  store i64 %t1255, ptr %l645, !tbaa !24
  %t1256 = load i64, ptr %l645, !tbaa !24
  %t1257 = mul i64 %t1256, 1
  %t1258 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1257)
  %t1259 = insertvalue { i64, ptr } undef, i64 %t1256, 0
  %t1260 = insertvalue { i64, ptr } %t1259, ptr %t1258, 1
  store { i64, ptr } %t1260, ptr %l646, !tbaa !27
  %t1261 = getelementptr { i64, ptr }, ptr %l646, i32 0, i32 1
  %t1262 = load ptr, ptr %t1261, !tbaa !27
  %t1263 = getelementptr { i64, ptr }, ptr %l641, i32 0, i32 1
  %t1264 = load ptr, ptr %t1263, !tbaa !27
  %t1265 = load i64, ptr %l645, !tbaa !24
  %t1266 = mul i64 %t1265, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1262, ptr %t1264, i64 %t1266, i1 false)
  %t1267 = load { i64, ptr }, ptr %l646, !tbaa !27
  store { i64, ptr } %t1267, ptr %l78, !tbaa !27
  br label %bb270
bb270:
  call void @__olang_scope_close(ptr %s44)
  br label %bb271
bb271:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l647, !tbaa !27
  %t1268 = load { i64, ptr }, ptr %l647, !tbaa !27
  store { i64, ptr } %t1268, ptr %l648, !tbaa !27
  %t1269 = load { i64, ptr }, ptr %l648, !tbaa !27
  %t1270 = extractvalue { i64, ptr } %t1269, 0
  store i64 %t1270, ptr %l649, !tbaa !24
  %t1271 = load i64, ptr %l649, !tbaa !24
  %t1272 = mul i64 %t1271, 1
  %t1273 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1272)
  %t1274 = insertvalue { i64, ptr } undef, i64 %t1271, 0
  %t1275 = insertvalue { i64, ptr } %t1274, ptr %t1273, 1
  store { i64, ptr } %t1275, ptr %l650, !tbaa !27
  %t1276 = getelementptr { i64, ptr }, ptr %l650, i32 0, i32 1
  %t1277 = load ptr, ptr %t1276, !tbaa !27
  %t1278 = getelementptr { i64, ptr }, ptr %l648, i32 0, i32 1
  %t1279 = load ptr, ptr %t1278, !tbaa !27
  %t1280 = load i64, ptr %l649, !tbaa !24
  %t1281 = mul i64 %t1280, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1277, ptr %t1279, i64 %t1281, i1 false)
  %t1282 = load { i64, ptr }, ptr %l650, !tbaa !27
  store { i64, ptr } %t1282, ptr %l80, !tbaa !27
  %t1283 = load i64, ptr %l57, !tbaa !24
  %t1284 = load i64, ptr @G_2ecompiler_2ffree_2eLYield, !tbaa !24
  %t1287 = icmp eq i64 %t1283, %t1284
  br i1 %t1287, label %bb272, label %bb273
bb272:
  store %olang.scope zeroinitializer, ptr %s47
  %t1289 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1289, ptr %l654, !tbaa !29
  %t1290 = load ptr, ptr %l2, !tbaa !29
  %t1292 = getelementptr %"compiler/typed:Body", ptr %t1290, i32 0, i32 3
  %t1293 = load i64, ptr %t1292, !tbaa !24
  store i64 %t1293, ptr %l656, !tbaa !24
  %t1294 = load ptr, ptr %l0, !tbaa !29
  %t1296 = getelementptr %"compiler/free:walker", ptr %t1294, i32 0, i32 47
  %t1297 = load i64, ptr %l54, !tbaa !24
  %t1300 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1296, i64 %t1297)
  store %"compiler/source:Span" %t1300, ptr %l660
  br label %bb274
bb273:
  %t1301 = load i64, ptr %l57, !tbaa !24
  %t1302 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t1305 = icmp eq i64 %t1301, %t1302
  br i1 %t1305, label %bb279, label %bb280
bb274:
  %t1307 = load ptr, ptr %l654, !tbaa !29
  %t1308 = load i64, ptr %l656, !tbaa !24
  %t1309 = load %"compiler/source:Span", ptr %l660
  %t1310 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s47, ptr %t1307, i64 %t1308, %"compiler/source:Span" %t1309)
  store { i64, ptr } %t1310, ptr %l661
  br label %bb275
bb275:
  %t1311 = load i64, ptr %l76, !tbaa !24
  %t1312 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1313 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t1314 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t1315 = load { i64, ptr }, ptr %l661, !tbaa !27
  %t1316 = extractvalue { i64, ptr } %t1315, 1
  %t1317 = extractvalue { i64, ptr } %t1315, 0
  %t1318 = add i64 %t1314, %t1317
  %t1319 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d93, i32 0, i32 1) }, 1
  %t1320 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d93, i32 0, i32 1) }, 0
  %t1321 = add i64 %t1318, %t1320
  %t1323 = call i64 @__olang_fmt_i64(ptr null, i64 %t1311)
  %t1324 = add i64 %t1321, %t1323
  %t1325 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d94, i32 0, i32 1) }, 1
  %t1326 = extractvalue { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d94, i32 0, i32 1) }, 0
  %t1327 = add i64 %t1324, %t1326
  %t1329 = extractvalue { i64, ptr } %t1312, 1
  %t1330 = extractvalue { i64, ptr } %t1312, 0
  %t1331 = add i64 %t1327, %t1330
  %t1332 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d95, i32 0, i32 1) }, 1
  %t1333 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d95, i32 0, i32 1) }, 0
  %t1334 = add i64 %t1331, %t1333
  %t1335 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1334)
  call void @olang_textcopy(ptr %t1335, ptr %t1313, i64 %t1314)
  %t1336 = getelementptr i8, ptr %t1335, i64 %t1314
  call void @olang_textcopy(ptr %t1336, ptr %t1316, i64 %t1317)
  %t1337 = getelementptr i8, ptr %t1336, i64 %t1317
  call void @olang_textcopy(ptr %t1337, ptr %t1319, i64 %t1320)
  %t1338 = getelementptr i8, ptr %t1337, i64 %t1320
  %t1339 = call i64 @__olang_fmt_i64(ptr %t1338, i64 %t1311)
  %t1340 = getelementptr i8, ptr %t1338, i64 %t1323
  call void @olang_textcopy(ptr %t1340, ptr %t1325, i64 %t1326)
  %t1341 = getelementptr i8, ptr %t1340, i64 %t1326
  call void @olang_textcopy(ptr %t1341, ptr %t1329, i64 %t1330)
  %t1342 = getelementptr i8, ptr %t1341, i64 %t1330
  call void @olang_textcopy(ptr %t1342, ptr %t1332, i64 %t1333)
  %t1343 = insertvalue { i64, ptr } undef, i64 %t1334, 0
  %t1344 = insertvalue { i64, ptr } %t1343, ptr %t1335, 1
  store { i64, ptr } %t1344, ptr %l664, !tbaa !27
  %t1345 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t1346 = extractvalue { i64, ptr } %t1345, 0
  %t1347 = load { i64, ptr }, ptr %l664, !tbaa !27
  %t1348 = extractvalue { i64, ptr } %t1347, 0
  store i64 %t1348, ptr %l666, !tbaa !24
  %t1350 = load i64, ptr %l666, !tbaa !24
  %t1351 = icmp eq i64 %t1346, %t1350
  br i1 %t1351, label %bb276, label %bb277
bb276:
  %t1353 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t1354 = load ptr, ptr %t1353, !tbaa !27
  %t1355 = getelementptr { i64, ptr }, ptr %l664, i32 0, i32 1
  %t1356 = load ptr, ptr %t1355, !tbaa !27
  %t1357 = load i64, ptr %l666, !tbaa !24
  %t1358 = mul i64 %t1357, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1354, ptr %t1356, i64 %t1358, i1 false)
  br label %bb278
bb277:
  %t1359 = load { i64, ptr }, ptr %l664, !tbaa !27
  store { i64, ptr } %t1359, ptr %l80, !tbaa !27
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s47)
  br label %bb291
bb279:
  store %olang.scope zeroinitializer, ptr %s50
  %t1360 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1360, ptr %l671, !tbaa !29
  %t1361 = load ptr, ptr %l2, !tbaa !29
  %t1363 = getelementptr %"compiler/typed:Body", ptr %t1361, i32 0, i32 3
  %t1364 = load i64, ptr %t1363, !tbaa !24
  store i64 %t1364, ptr %l673, !tbaa !24
  %t1365 = load ptr, ptr %l0, !tbaa !29
  %t1367 = getelementptr %"compiler/free:walker", ptr %t1365, i32 0, i32 47
  %t1368 = load i64, ptr %l54, !tbaa !24
  %t1371 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1367, i64 %t1368)
  store %"compiler/source:Span" %t1371, ptr %l677
  br label %bb281
bb280:
  %t1372 = load i64, ptr %l76, !tbaa !24
  %t1373 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1374 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t1375 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t1377 = call i64 @__olang_fmt_i64(ptr null, i64 %t1372)
  %t1378 = add i64 %t1375, %t1377
  %t1379 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t1380 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t1381 = add i64 %t1378, %t1380
  %t1383 = extractvalue { i64, ptr } %t1373, 1
  %t1384 = extractvalue { i64, ptr } %t1373, 0
  %t1385 = add i64 %t1381, %t1384
  %t1386 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t1387 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t1388 = add i64 %t1385, %t1387
  %t1389 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1388)
  call void @olang_textcopy(ptr %t1389, ptr %t1374, i64 %t1375)
  %t1390 = getelementptr i8, ptr %t1389, i64 %t1375
  %t1391 = call i64 @__olang_fmt_i64(ptr %t1390, i64 %t1372)
  %t1392 = getelementptr i8, ptr %t1390, i64 %t1377
  call void @olang_textcopy(ptr %t1392, ptr %t1379, i64 %t1380)
  %t1393 = getelementptr i8, ptr %t1392, i64 %t1380
  call void @olang_textcopy(ptr %t1393, ptr %t1383, i64 %t1384)
  %t1394 = getelementptr i8, ptr %t1393, i64 %t1384
  call void @olang_textcopy(ptr %t1394, ptr %t1386, i64 %t1387)
  %t1395 = insertvalue { i64, ptr } undef, i64 %t1388, 0
  %t1396 = insertvalue { i64, ptr } %t1395, ptr %t1389, 1
  store { i64, ptr } %t1396, ptr %l690, !tbaa !27
  %t1397 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t1398 = extractvalue { i64, ptr } %t1397, 0
  %t1399 = load { i64, ptr }, ptr %l690, !tbaa !27
  %t1400 = extractvalue { i64, ptr } %t1399, 0
  store i64 %t1400, ptr %l692, !tbaa !24
  %t1402 = load i64, ptr %l692, !tbaa !24
  %t1403 = icmp eq i64 %t1398, %t1402
  br i1 %t1403, label %bb287, label %bb288
bb281:
  %t1405 = load ptr, ptr %l671, !tbaa !29
  %t1406 = load i64, ptr %l673, !tbaa !24
  %t1407 = load %"compiler/source:Span", ptr %l677
  %t1408 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextOf(ptr %v0, ptr %s50, ptr %t1405, i64 %t1406, %"compiler/source:Span" %t1407)
  store { i64, ptr } %t1408, ptr %l678
  br label %bb282
bb282:
  %t1409 = load i64, ptr %l76, !tbaa !24
  store i64 %t1409, ptr %l679, !tbaa !24
  %t1410 = load ptr, ptr %l0, !tbaa !29
  %t1411 = load i64, ptr %l55, !tbaa !24
  %t1414 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %s50, ptr %t1410, i64 %t1411)
  store { i64, ptr } %t1414, ptr %l682
  br label %bb283
bb283:
  %t1415 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t1416 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t1417 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t1418 = load { i64, ptr }, ptr %l678, !tbaa !27
  %t1419 = extractvalue { i64, ptr } %t1418, 1
  %t1420 = extractvalue { i64, ptr } %t1418, 0
  %t1421 = add i64 %t1417, %t1420
  %t1422 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t1423 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t1424 = add i64 %t1421, %t1423
  %t1425 = load i64, ptr %l679, !tbaa !24
  %t1426 = call i64 @__olang_fmt_i64(ptr null, i64 %t1425)
  %t1427 = add i64 %t1424, %t1426
  %t1428 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d101, i32 0, i32 1) }, 1
  %t1429 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d101, i32 0, i32 1) }, 0
  %t1430 = add i64 %t1427, %t1429
  %t1431 = load { i64, ptr }, ptr %l682, !tbaa !27
  %t1432 = extractvalue { i64, ptr } %t1431, 1
  %t1433 = extractvalue { i64, ptr } %t1431, 0
  %t1434 = add i64 %t1430, %t1433
  %t1435 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d102, i32 0, i32 1) }, 1
  %t1436 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d102, i32 0, i32 1) }, 0
  %t1437 = add i64 %t1434, %t1436
  %t1439 = extractvalue { i64, ptr } %t1415, 1
  %t1440 = extractvalue { i64, ptr } %t1415, 0
  %t1441 = add i64 %t1437, %t1440
  %t1442 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d103, i32 0, i32 1) }, 1
  %t1443 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d103, i32 0, i32 1) }, 0
  %t1444 = add i64 %t1441, %t1443
  %t1445 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t1444)
  call void @olang_textcopy(ptr %t1445, ptr %t1416, i64 %t1417)
  %t1446 = getelementptr i8, ptr %t1445, i64 %t1417
  call void @olang_textcopy(ptr %t1446, ptr %t1419, i64 %t1420)
  %t1447 = getelementptr i8, ptr %t1446, i64 %t1420
  call void @olang_textcopy(ptr %t1447, ptr %t1422, i64 %t1423)
  %t1448 = getelementptr i8, ptr %t1447, i64 %t1423
  %t1449 = call i64 @__olang_fmt_i64(ptr %t1448, i64 %t1425)
  %t1450 = getelementptr i8, ptr %t1448, i64 %t1426
  call void @olang_textcopy(ptr %t1450, ptr %t1428, i64 %t1429)
  %t1451 = getelementptr i8, ptr %t1450, i64 %t1429
  call void @olang_textcopy(ptr %t1451, ptr %t1432, i64 %t1433)
  %t1452 = getelementptr i8, ptr %t1451, i64 %t1433
  call void @olang_textcopy(ptr %t1452, ptr %t1435, i64 %t1436)
  %t1453 = getelementptr i8, ptr %t1452, i64 %t1436
  call void @olang_textcopy(ptr %t1453, ptr %t1439, i64 %t1440)
  %t1454 = getelementptr i8, ptr %t1453, i64 %t1440
  call void @olang_textcopy(ptr %t1454, ptr %t1442, i64 %t1443)
  %t1455 = insertvalue { i64, ptr } undef, i64 %t1444, 0
  %t1456 = insertvalue { i64, ptr } %t1455, ptr %t1445, 1
  store { i64, ptr } %t1456, ptr %l684, !tbaa !27
  %t1457 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t1458 = extractvalue { i64, ptr } %t1457, 0
  %t1459 = load { i64, ptr }, ptr %l684, !tbaa !27
  %t1460 = extractvalue { i64, ptr } %t1459, 0
  store i64 %t1460, ptr %l686, !tbaa !24
  %t1462 = load i64, ptr %l686, !tbaa !24
  %t1463 = icmp eq i64 %t1458, %t1462
  br i1 %t1463, label %bb284, label %bb285
bb284:
  %t1465 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t1466 = load ptr, ptr %t1465, !tbaa !27
  %t1467 = getelementptr { i64, ptr }, ptr %l684, i32 0, i32 1
  %t1468 = load ptr, ptr %t1467, !tbaa !27
  %t1469 = load i64, ptr %l686, !tbaa !24
  %t1470 = mul i64 %t1469, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1466, ptr %t1468, i64 %t1470, i1 false)
  br label %bb286
bb285:
  %t1471 = load { i64, ptr }, ptr %l684, !tbaa !27
  store { i64, ptr } %t1471, ptr %l80, !tbaa !27
  br label %bb286
bb286:
  call void @__olang_scope_close(ptr %s50)
  br label %bb290
bb287:
  %t1472 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t1473 = load ptr, ptr %t1472, !tbaa !27
  %t1474 = getelementptr { i64, ptr }, ptr %l690, i32 0, i32 1
  %t1475 = load ptr, ptr %t1474, !tbaa !27
  %t1476 = load i64, ptr %l692, !tbaa !24
  %t1477 = mul i64 %t1476, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t1473, ptr %t1475, i64 %t1477, i1 false)
  br label %bb289
bb288:
  %t1478 = load { i64, ptr }, ptr %l690, !tbaa !27
  store { i64, ptr } %t1478, ptr %l80, !tbaa !27
  br label %bb289
bb289:
  br label %bb290
bb290:
  br label %bb291
bb291:
  %t1479 = load i64, ptr %l68, !tbaa !24
  %t1482 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %s0, ptr %s0, ptr %l3, i64 %t1479)
  store ptr %t1482, ptr %l696
  br label %bb292
bb292:
  %t1483 = load ptr, ptr %l696, !tbaa !29
  store ptr %t1483, ptr %l81, !tbaa !29
  store i64 0, ptr %l82, !tbaa !24
  br label %bb293
bb293:
  %t1484 = load i64, ptr %l82, !tbaa !24
  store i64 %t1484, ptr %l697, !tbaa !24
  %t1485 = load ptr, ptr %l81, !tbaa !29
  %t1487 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t1485)
  store i64 %t1487, ptr %l699
  br label %bb294
bb294:
  %t1488 = load i64, ptr %l697, !tbaa !24
  %t1489 = load i64, ptr %l699, !tbaa !24
  %t1490 = icmp slt i64 %t1488, %t1489
  %t1492 = xor i1 %t1490, true
  br i1 %t1492, label %bb295, label %bb296
bb295:
  br label %bb312
bb296:
  br label %bb297
bb297:
  %t1494 = load ptr, ptr %l81, !tbaa !29
  %t1495 = load i64, ptr %l82, !tbaa !24
  %t1498 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t1494, i64 %t1495)
  store i64 %t1498, ptr %l704
  br label %bb298
bb298:
  %t1499 = load i64, ptr %l704, !tbaa !24
  store i64 %t1499, ptr %l83, !tbaa !24
  %t1500 = load i64, ptr %l55, !tbaa !24
  %t1502 = icmp slt i64 %t1500, 0
  br i1 %t1502, label %bb299, label %bb300
bb299:
  store i1 true, ptr %l707, !tbaa !21
  br label %bb301
bb300:
  %t1504 = load i64, ptr %l83, !tbaa !24
  %t1505 = load i64, ptr %l55, !tbaa !24
  %t1508 = icmp eq i64 %t1504, %t1505
  store i1 %t1508, ptr %l707, !tbaa !21
  br label %bb301
bb301:
  %t1510 = load i1, ptr %l707, !tbaa !21
  br i1 %t1510, label %bb302, label %bb303
bb302:
  %t1511 = load ptr, ptr %l1, !tbaa !29
  %t1513 = getelementptr %"compiler/free:Free", ptr %t1511, i32 0, i32 44
  %t1514 = load i64, ptr %l83, !tbaa !24
  %t1517 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t1513, i64 %t1514)
  store i64 %t1517, ptr %l715
  br label %bb304
bb303:
  store i1 false, ptr %l711, !tbaa !21
  br label %bb305
bb304:
  %t1518 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t1519 = load i64, ptr %l715, !tbaa !24
  %t1521 = icmp eq i64 %t1519, %t1518
  store i1 %t1521, ptr %l711, !tbaa !21
  br label %bb305
bb305:
  %t1523 = load i1, ptr %l711, !tbaa !21
  br i1 %t1523, label %bb306, label %bb307
bb306:
  store %olang.scope zeroinitializer, ptr %s56
  %t1524 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1524, ptr %l718, !tbaa !29
  %t1525 = load i64, ptr %l83, !tbaa !24
  store i64 %t1525, ptr %l719, !tbaa !24
  %t1526 = load ptr, ptr %l2, !tbaa !29
  %t1528 = getelementptr %"compiler/typed:Body", ptr %t1526, i32 0, i32 3
  %t1529 = load i64, ptr %t1528, !tbaa !24
  store i64 %t1529, ptr %l721, !tbaa !24
  %t1530 = load ptr, ptr %l0, !tbaa !29
  %t1532 = getelementptr %"compiler/free:walker", ptr %t1530, i32 0, i32 26
  %t1533 = load i64, ptr %l73, !tbaa !24
  %t1536 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t1532, i64 %t1533)
  store %"compiler/source:Span" %t1536, ptr %l725
  br label %bb308
bb307:
  br label %bb310
bb308:
  %t1537 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t1538 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t1540 = extractvalue { i64, ptr } %t1537, 1
  %t1541 = extractvalue { i64, ptr } %t1537, 0
  %t1542 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t1543 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t1544 = add i64 %t1541, %t1543
  %t1546 = extractvalue { i64, ptr } %t1538, 1
  %t1547 = extractvalue { i64, ptr } %t1538, 0
  %t1548 = add i64 %t1544, %t1547
  %t1549 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1548)
  call void @olang_textcopy(ptr %t1549, ptr %t1540, i64 %t1541)
  %t1550 = getelementptr i8, ptr %t1549, i64 %t1541
  call void @olang_textcopy(ptr %t1550, ptr %t1542, i64 %t1543)
  %t1551 = getelementptr i8, ptr %t1550, i64 %t1543
  call void @olang_textcopy(ptr %t1551, ptr %t1546, i64 %t1547)
  %t1552 = insertvalue { i64, ptr } undef, i64 %t1548, 0
  %t1553 = insertvalue { i64, ptr } %t1552, ptr %t1549, 1
  %t1555 = extractvalue { i64, ptr } %t1553, 0
  %t1556 = extractvalue { i64, ptr } %t1553, 1
  %t1557 = mul i64 %t1555, 1
  %t1558 = call ptr @__olang_scope_alloc(ptr %s56, i64 %t1557)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1558, ptr %t1556, i64 %t1557, i1 false)
  %t1559 = insertvalue { i64, ptr } undef, i64 %t1555, 0
  %t1560 = insertvalue { i64, ptr } %t1559, ptr %t1558, 1
  %t1561 = load i64, ptr %l58, !tbaa !24
  %t1562 = load ptr, ptr %l718, !tbaa !29
  %t1563 = load i64, ptr %l719, !tbaa !24
  %t1564 = load i64, ptr %l721, !tbaa !24
  %t1565 = load %"compiler/source:Span", ptr %l725
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %s56, ptr %t1562, i64 %t1563, i64 %t1564, %"compiler/source:Span" %t1565, { i64, ptr } %t1560, i64 %t1561)
  br label %bb309
bb309:
  call void @__olang_scope_close(ptr %s56)
  br label %bb310
bb310:
  br label %bb311
bb311:
  %t1568 = load i64, ptr %l82, !tbaa !24
  %t1570 = add i64 %t1568, 1
  store i64 %t1570, ptr %l82, !tbaa !24
  br label %bb293
bb312:
  %t1572 = load i64, ptr %l55, !tbaa !24
  %t1574 = icmp sge i64 %t1572, 0
  br i1 %t1574, label %bb313, label %bb314
bb313:
  call void @__olang_scope_close(ptr %s35)
  br label %bb317
bb314:
  br label %bb315
bb315:
  call void @__olang_scope_close(ptr %s35)
  br label %bb316
bb316:
  %t1576 = load i64, ptr %l67, !tbaa !24
  %t1578 = add i64 %t1576, 1
  store i64 %t1578, ptr %l67, !tbaa !24
  br label %bb213
bb317:
  br label %bb318
bb318:
  %t1580 = load i64, ptr %l53, !tbaa !24
  %t1582 = add i64 %t1580, 1
  store i64 %t1582, ptr %l53, !tbaa !24
  br label %bb142
bb319:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l22 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l40 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l8, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 18}
  %t17 = icmp eq i64 %t15, 10
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb39
bb10:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb11, label %bb12
bb11:
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 18}
  %t26 = icmp eq i64 %t24, 11
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb12
bb12:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb13, label %bb14
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l1, !tbaa !29
  br label %bb15
bb14:
  br label %bb27
bb15:
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr %"compiler/typed:Cond", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Cond", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb22
bb18:
  call void @__olang_check_failed(ptr @olang_loc_228ad70617d44d77_1dee412aac6cbab)
  unreachable
bb19:
  br label %bb20
bb20:
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t52 = getelementptr %"compiler/typed:Cond", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %t53)
  store i1 %t55, ptr %l28
  br label %bb21
bb21:
  %t56 = load i1, ptr %l28, !tbaa !21
  store i1 %t56, ptr %l22, !tbaa !21
  br label %bb22
bb22:
  %t57 = load i1, ptr %l22, !tbaa !21
  br i1 %t57, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb26
bb24:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Cond", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %t61)
  store i1 %t63, ptr %l32
  br label %bb25
bb25:
  %t64 = load i1, ptr %l32, !tbaa !21
  store i1 %t64, ptr %l29, !tbaa !21
  br label %bb26
bb26:
  %t65 = load i1, ptr %l29, !tbaa !21
  store i1 %t65, ptr %l3, !tbaa !21
  br label %bb39
bb27:
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb28, label %bb29
bb28:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 17
  store i1 %t73, ptr %l34, !tbaa !21
  br label %bb29
bb29:
  %t74 = load i1, ptr %l34, !tbaa !21
  br i1 %t74, label %bb30, label %bb31
bb30:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t77, i32 0, i32 2
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l2, !tbaa !29
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = call i1 @compiler_2ffree_2ecopiedStore(ptr %v0, ptr %t81)
  store i1 %t83, ptr %l40
  br label %bb33
bb33:
  %t84 = load i1, ptr %l40, !tbaa !21
  store i1 %t84, ptr %l3, !tbaa !21
  br label %bb39
bb34:
  br i1 true, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb38
bb37:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_5e2122fa9519644f_a9d9059c63542dd3)
  unreachable
bb39:
  %t85 = load i1, ptr %l3, !tbaa !21
  store i1 %t85, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ectorCall(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l2, !tbaa !29
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store ptr null, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_546be3fdfb2e7861_5a4791e17fa5075d)
  unreachable
bb11:
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i1
  %l39 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l5, !tbaa !29
  br label %bb32
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = icmp ne ptr %t20, null
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = load i64, ptr %t23, !range !{i64 0, i64 8}
  %t26 = icmp eq i64 %t24, 3
  store i1 %t26, ptr %l15, !tbaa !21
  br label %bb8
bb8:
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr { i64, [4 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t30, i32 0, i32 2
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %t34)
  store ptr %t36, ptr %l21
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l21, !tbaa !29
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb32
bb13:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb14, label %bb15
bb14:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t43 = load i64, ptr %t42, !range !{i64 0, i64 8}
  %t45 = icmp eq i64 %t43, 4
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb15
bb15:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [4 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t49, i32 0, i32 2
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Elem", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %t56)
  store ptr %t58, ptr %l30
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l30, !tbaa !29
  store ptr %t59, ptr %l5, !tbaa !29
  br label %bb32
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t61 = load ptr, ptr %l31, !tbaa !29
  %t62 = icmp ne ptr %t61, null
  br i1 %t62, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l31, !tbaa !29
  %t65 = load i64, ptr %t64, !range !{i64 0, i64 8}
  %t67 = icmp eq i64 %t65, 5
  store i1 %t67, ptr %l32, !tbaa !21
  br label %bb22
bb22:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb23, label %bb24
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t71, i32 0, i32 2
  %t73 = load ptr, ptr %t72
  store ptr %t73, ptr %l4, !tbaa !29
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/typed:Payload", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = call ptr @compiler_2ffree_2ederefRoot(ptr %v0, ptr %v1, ptr %t78)
  store ptr %t80, ptr %l39
  br label %bb26
bb26:
  %t81 = load ptr, ptr %l39, !tbaa !29
  store ptr %t81, ptr %l5, !tbaa !29
  br label %bb32
bb27:
  br i1 true, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  store ptr null, ptr %l5, !tbaa !29
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_5891e56eddc46c99_f944b0e713971375)
  unreachable
bb32:
  %t82 = load ptr, ptr %l5, !tbaa !29
  store ptr %t82, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l56 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i1
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i1
  %l108 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i1
  %l123 = alloca { i64, ptr }
  %l128 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca i1
  %l150 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l164 = alloca ptr
  %l165 = alloca i1
  %l180 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca i1
  %l196 = alloca { i64, ptr }
  %l201 = alloca ptr
  %l219 = alloca ptr
  %l221 = alloca ptr
  %l222 = alloca i1
  %l230 = alloca ptr
  %l246 = alloca ptr
  %l255 = alloca ptr
  %l256 = alloca ptr
  %l257 = alloca i1
  %l264 = alloca ptr
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t2 = load ptr, ptr %l35, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l35, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l36, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb31
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Call", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t22 = load i64, ptr %l1, !tbaa !24
  %t25 = icmp eq i64 %t21, %t22
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Call", ptr %t30, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l5, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb18
bb11:
  br label %bb12
bb12:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t47, ptr %l56, !tbaa !27
  %t48 = load i64, ptr %l4, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 %t48
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t56 = load i64, ptr %l1, !tbaa !24
  %t59 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t53, i64 %t56)
  store ptr %t59, ptr %l61
  br label %bb13
bb13:
  %t60 = load ptr, ptr %l61, !tbaa !29
  store ptr %t60, ptr %l7, !tbaa !29
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l7, !tbaa !29
  store ptr %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = add i64 %t70, 1
  store i64 %t72, ptr %l4, !tbaa !24
  br label %bb9
bb18:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Call", ptr %t74, i32 0, i32 0
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l8, !tbaa !29
  %t79 = load ptr, ptr %l8, !tbaa !29
  store ptr %t79, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t80 = load ptr, ptr %l71, !tbaa !29
  %t81 = icmp ne ptr %t80, null
  br i1 %t81, label %bb19, label %bb20
bb19:
  %t83 = load ptr, ptr %l71, !tbaa !29
  %t84 = load i64, ptr %t83, !range !{i64 0, i64 5}
  %t86 = icmp eq i64 %t84, 2
  store i1 %t86, ptr %l72, !tbaa !21
  br label %bb20
bb20:
  %t87 = load i1, ptr %l72, !tbaa !21
  br i1 %t87, label %bb21, label %bb22
bb21:
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t90 = getelementptr { i64, [3 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { ptr }, ptr %t90, i32 0, i32 0
  %t92 = load ptr, ptr %t91
  store ptr %t92, ptr %l9, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t94 = load ptr, ptr %l9, !tbaa !29
  %t95 = load i64, ptr %l1, !tbaa !24
  %t98 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t94, i64 %t95)
  store ptr %t98, ptr %l79
  br label %bb24
bb24:
  %t99 = load ptr, ptr %l79, !tbaa !29
  store ptr %t99, ptr %rv
  br label %ret
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_16263ed1acd4aa7e_23dcb8f717a142b2)
  unreachable
bb30:
  store ptr null, ptr %rv
  br label %ret
bb31:
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t102 = load ptr, ptr %l81, !tbaa !29
  %t103 = icmp ne ptr %t102, null
  br i1 %t103, label %bb32, label %bb33
bb32:
  %t105 = load ptr, ptr %l81, !tbaa !29
  %t106 = load i64, ptr %t105, !range !{i64 0, i64 18}
  %t108 = icmp eq i64 %t106, 5
  store i1 %t108, ptr %l82, !tbaa !21
  br label %bb33
bb33:
  %t109 = load i1, ptr %l82, !tbaa !21
  br i1 %t109, label %bb34, label %bb35
bb34:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr { i64, [5 x i64] }, ptr %t110, i32 0, i32 1
  %t113 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t112, i32 0, i32 2
  %t114 = load ptr, ptr %t113
  store ptr %t114, ptr %l10, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t116 = load ptr, ptr %l10, !tbaa !29
  %t118 = getelementptr %"compiler/typed:Promote", ptr %t116, i32 0, i32 0
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = load i64, ptr %l1, !tbaa !24
  %t123 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t119, i64 %t120)
  store ptr %t123, ptr %l90
  br label %bb37
bb37:
  %t124 = load ptr, ptr %l90, !tbaa !29
  store ptr %t124, ptr %rv
  br label %ret
bb38:
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t126 = load ptr, ptr %l91, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = load ptr, ptr %l91, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 18}
  %t132 = icmp eq i64 %t130, 2
  store i1 %t132, ptr %l92, !tbaa !21
  br label %bb40
bb40:
  %t133 = load i1, ptr %l92, !tbaa !21
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t136, i32 0, i32 2
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l11, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t140 = load ptr, ptr %l11, !tbaa !29
  %t141 = load i64, ptr %l1, !tbaa !24
  %t144 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t140, i64 %t141)
  store ptr %t144, ptr %l99
  br label %bb44
bb44:
  %t145 = load ptr, ptr %l99, !tbaa !29
  store ptr %t145, ptr %rv
  br label %ret
bb45:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t147 = load ptr, ptr %l100, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb46, label %bb47
bb46:
  %t150 = load ptr, ptr %l100, !tbaa !29
  %t151 = load i64, ptr %t150, !range !{i64 0, i64 18}
  %t153 = icmp eq i64 %t151, 3
  store i1 %t153, ptr %l101, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l101, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr { i64, [5 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l12, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t161 = load ptr, ptr %l12, !tbaa !29
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %t161, i64 %t162)
  store ptr %t165, ptr %l108
  br label %bb51
bb51:
  %t166 = load ptr, ptr %l108, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb52:
  %t167 = load ptr, ptr %l0, !tbaa !29
  store ptr %t167, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t168 = load ptr, ptr %l109, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb53, label %bb54
bb53:
  %t171 = load ptr, ptr %l109, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 18}
  %t174 = icmp eq i64 %t172, 7
  store i1 %t174, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t175 = load i1, ptr %l110, !tbaa !21
  br i1 %t175, label %bb55, label %bb56
bb55:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l13, !tbaa !29
  br label %bb57
bb56:
  br label %bb68
bb57:
  %t182 = load ptr, ptr %l13, !tbaa !29
  %t184 = getelementptr %"compiler/typed:Make", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !27
  store { i64, ptr } %t185, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l16, !tbaa !24
  br label %bb58
bb58:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb59, label %bb60
bb59:
  br label %bb67
bb60:
  br label %bb61
bb61:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t199, ptr %l123, !tbaa !27
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr ptr, ptr %t203, i64 %t200
  %t205 = load ptr, ptr %t204, !tbaa !39
  %t208 = load i64, ptr %l1, !tbaa !24
  %t211 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t205, i64 %t208)
  store ptr %t211, ptr %l128
  br label %bb62
bb62:
  %t212 = load ptr, ptr %l128, !tbaa !29
  store ptr %t212, ptr %l18, !tbaa !29
  %t213 = load ptr, ptr %l18, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  %t217 = xor i1 %t215, true
  br i1 %t217, label %bb63, label %bb64
bb63:
  %t219 = load ptr, ptr %l18, !tbaa !29
  store ptr %t219, ptr %rv
  br label %ret
bb64:
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t222 = load i64, ptr %l15, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l15, !tbaa !24
  br label %bb58
bb67:
  store ptr null, ptr %rv
  br label %ret
bb68:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t228 = load ptr, ptr %l137, !tbaa !29
  %t229 = icmp ne ptr %t228, null
  br i1 %t229, label %bb69, label %bb70
bb69:
  %t231 = load ptr, ptr %l137, !tbaa !29
  %t232 = load i64, ptr %t231, !range !{i64 0, i64 18}
  %t234 = icmp eq i64 %t232, 9
  store i1 %t234, ptr %l138, !tbaa !21
  br label %bb70
bb70:
  %t235 = load i1, ptr %l138, !tbaa !21
  br i1 %t235, label %bb71, label %bb72
bb71:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr { i64, [5 x i64] }, ptr %t236, i32 0, i32 1
  %t239 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t238, i32 0, i32 4
  %t240 = load { i64, ptr }, ptr %t239
  store { i64, ptr } %t240, ptr %l19, !tbaa !27
  br label %bb73
bb72:
  br label %bb84
bb73:
  %t242 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t242, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l22, !tbaa !24
  br label %bb74
bb74:
  %t248 = load i64, ptr %l21, !tbaa !24
  %t249 = load i64, ptr %l22, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb75, label %bb76
bb75:
  br label %bb83
bb76:
  br label %bb77
bb77:
  %t256 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t256, ptr %l150, !tbaa !27
  %t257 = load i64, ptr %l21, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr ptr, ptr %t260, i64 %t257
  %t262 = load ptr, ptr %t261, !tbaa !39
  %t265 = load i64, ptr %l1, !tbaa !24
  %t268 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t262, i64 %t265)
  store ptr %t268, ptr %l155
  br label %bb78
bb78:
  %t269 = load ptr, ptr %l155, !tbaa !29
  store ptr %t269, ptr %l24, !tbaa !29
  %t270 = load ptr, ptr %l24, !tbaa !29
  %t272 = icmp eq ptr %t270, null
  %t274 = xor i1 %t272, true
  br i1 %t274, label %bb79, label %bb80
bb79:
  %t276 = load ptr, ptr %l24, !tbaa !29
  store ptr %t276, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  br label %bb82
bb82:
  %t279 = load i64, ptr %l21, !tbaa !24
  %t281 = add i64 %t279, 1
  store i64 %t281, ptr %l21, !tbaa !24
  br label %bb74
bb83:
  store ptr null, ptr %rv
  br label %ret
bb84:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l164, !tbaa !29
  store i1 false, ptr %l165, !tbaa !21
  %t285 = load ptr, ptr %l164, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb85, label %bb86
bb85:
  %t288 = load ptr, ptr %l164, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 18}
  %t291 = icmp eq i64 %t289, 14
  store i1 %t291, ptr %l165, !tbaa !21
  br label %bb86
bb86:
  %t292 = load i1, ptr %l165, !tbaa !21
  br i1 %t292, label %bb87, label %bb88
bb87:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr { i64, [5 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t295, i32 0, i32 2
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l25, !tbaa !29
  br label %bb89
bb88:
  br label %bb97
bb89:
  %t299 = load ptr, ptr %l25, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Try", ptr %t299, i32 0, i32 0
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t304 = icmp eq ptr %t302, null
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb90, label %bb91
bb90:
  %t308 = load ptr, ptr %l25, !tbaa !29
  %t310 = getelementptr %"compiler/typed:Try", ptr %t308, i32 0, i32 0
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  br i1 %t313, label %bb92, label %bb93
bb91:
  br label %bb96
bb92:
  call void @__olang_check_failed(ptr @olang_loc_ea2e0f0d6ffcb248_fe73fa1c8e55849c)
  unreachable
bb93:
  br label %bb94
bb94:
  %t315 = load ptr, ptr %l25, !tbaa !29
  %t317 = getelementptr %"compiler/typed:Try", ptr %t315, i32 0, i32 0
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t319 = load i64, ptr %l1, !tbaa !24
  %t322 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t318, i64 %t319)
  store ptr %t322, ptr %l180
  br label %bb95
bb95:
  %t323 = load ptr, ptr %l180, !tbaa !29
  store ptr %t323, ptr %rv
  br label %ret
bb96:
  store ptr null, ptr %rv
  br label %ret
bb97:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l182, !tbaa !29
  store i1 false, ptr %l183, !tbaa !21
  %t326 = load ptr, ptr %l182, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb98, label %bb99
bb98:
  %t329 = load ptr, ptr %l182, !tbaa !29
  %t330 = load i64, ptr %t329, !range !{i64 0, i64 18}
  %t332 = icmp eq i64 %t330, 12
  store i1 %t332, ptr %l183, !tbaa !21
  br label %bb99
bb99:
  %t333 = load i1, ptr %l183, !tbaa !21
  br i1 %t333, label %bb100, label %bb101
bb100:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t336, i32 0, i32 2
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l26, !tbaa !29
  br label %bb102
bb101:
  br label %bb120
bb102:
  %t340 = load ptr, ptr %l26, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Seq", ptr %t340, i32 0, i32 0
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  store { i64, ptr } %t343, ptr %l27, !tbaa !27
  store i64 0, ptr %l28, !tbaa !24
  %t345 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t345, 0
  store i64 %t347, ptr %l29, !tbaa !24
  br label %bb103
bb103:
  %t349 = load i64, ptr %l28, !tbaa !24
  %t350 = load i64, ptr %l29, !tbaa !24
  %t353 = icmp slt i64 %t349, %t350
  %t355 = xor i1 %t353, true
  br i1 %t355, label %bb104, label %bb105
bb104:
  br label %bb112
bb105:
  br label %bb106
bb106:
  %t357 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t357, ptr %l196, !tbaa !27
  %t358 = load i64, ptr %l28, !tbaa !24
  %t360 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr ptr, ptr %t361, i64 %t358
  %t363 = load ptr, ptr %t362, !tbaa !39
  %t366 = load i64, ptr %l1, !tbaa !24
  %t369 = call ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %t363, i64 %t366)
  store ptr %t369, ptr %l201
  br label %bb107
bb107:
  %t370 = load ptr, ptr %l201, !tbaa !29
  store ptr %t370, ptr %l31, !tbaa !29
  %t371 = load ptr, ptr %l31, !tbaa !29
  %t373 = icmp eq ptr %t371, null
  %t375 = xor i1 %t373, true
  br i1 %t375, label %bb108, label %bb109
bb108:
  %t377 = load ptr, ptr %l31, !tbaa !29
  store ptr %t377, ptr %rv
  br label %ret
bb109:
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t380 = load i64, ptr %l28, !tbaa !24
  %t382 = add i64 %t380, 1
  store i64 %t382, ptr %l28, !tbaa !24
  br label %bb103
bb112:
  %t384 = load ptr, ptr %l26, !tbaa !29
  %t386 = getelementptr %"compiler/typed:Seq", ptr %t384, i32 0, i32 1
  %t387 = load ptr, ptr %t386, !tbaa !29
  %t389 = icmp eq ptr %t387, null
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb113, label %bb114
bb113:
  %t393 = load ptr, ptr %l26, !tbaa !29
  %t395 = getelementptr %"compiler/typed:Seq", ptr %t393, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb115, label %bb116
bb114:
  br label %bb119
bb115:
  call void @__olang_check_failed(ptr @olang_loc_6e2453cb19a4d71d_88f1503d6cec0391)
  unreachable
bb116:
  br label %bb117
bb117:
  %t400 = load ptr, ptr %l26, !tbaa !29
  %t402 = getelementptr %"compiler/typed:Seq", ptr %t400, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  %t404 = load i64, ptr %l1, !tbaa !24
  %t407 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t403, i64 %t404)
  store ptr %t407, ptr %l219
  br label %bb118
bb118:
  %t408 = load ptr, ptr %l219, !tbaa !29
  store ptr %t408, ptr %rv
  br label %ret
bb119:
  store ptr null, ptr %rv
  br label %ret
bb120:
  %t410 = load ptr, ptr %l0, !tbaa !29
  store ptr %t410, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t411 = load ptr, ptr %l221, !tbaa !29
  %t412 = icmp ne ptr %t411, null
  br i1 %t412, label %bb121, label %bb122
bb121:
  %t414 = load ptr, ptr %l221, !tbaa !29
  %t415 = load i64, ptr %t414, !range !{i64 0, i64 18}
  %t417 = icmp eq i64 %t415, 11
  store i1 %t417, ptr %l222, !tbaa !21
  br label %bb122
bb122:
  %t418 = load i1, ptr %l222, !tbaa !21
  br i1 %t418, label %bb123, label %bb124
bb123:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t421 = getelementptr { i64, [5 x i64] }, ptr %t419, i32 0, i32 1
  %t422 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t421, i32 0, i32 2
  %t423 = load ptr, ptr %t422
  store ptr %t423, ptr %l32, !tbaa !29
  br label %bb125
bb124:
  br label %bb141
bb125:
  %t425 = load ptr, ptr %l32, !tbaa !29
  %t427 = getelementptr %"compiler/typed:Cond", ptr %t425, i32 0, i32 0
  %t428 = load ptr, ptr %t427, !tbaa !29
  %t429 = load i64, ptr %l1, !tbaa !24
  %t432 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t428, i64 %t429)
  store ptr %t432, ptr %l230
  br label %bb126
bb126:
  %t433 = load ptr, ptr %l230, !tbaa !29
  store ptr %t433, ptr %l33, !tbaa !29
  %t434 = load ptr, ptr %l33, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb127, label %bb128
bb127:
  %t440 = load ptr, ptr %l33, !tbaa !29
  store ptr %t440, ptr %rv
  br label %ret
bb128:
  br label %bb129
bb129:
  %t443 = load ptr, ptr %l32, !tbaa !29
  %t445 = getelementptr %"compiler/typed:Cond", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = icmp eq ptr %t446, null
  %t450 = xor i1 %t448, true
  br i1 %t450, label %bb130, label %bb131
bb130:
  %t452 = load ptr, ptr %l32, !tbaa !29
  %t454 = getelementptr %"compiler/typed:Cond", ptr %t452, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !29
  %t457 = icmp eq ptr %t455, null
  br i1 %t457, label %bb132, label %bb133
bb131:
  br label %bb139
bb132:
  call void @__olang_check_failed(ptr @olang_loc_a8e684701cb727b6_7b41502ddc5bea8a)
  unreachable
bb133:
  br label %bb134
bb134:
  %t459 = load ptr, ptr %l32, !tbaa !29
  %t461 = getelementptr %"compiler/typed:Cond", ptr %t459, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !29
  %t463 = load i64, ptr %l1, !tbaa !24
  %t466 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t462, i64 %t463)
  store ptr %t466, ptr %l246
  br label %bb135
bb135:
  %t467 = load ptr, ptr %l246, !tbaa !29
  store ptr %t467, ptr %l33, !tbaa !29
  %t468 = load ptr, ptr %l33, !tbaa !29
  %t470 = icmp eq ptr %t468, null
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb136, label %bb137
bb136:
  %t474 = load ptr, ptr %l33, !tbaa !29
  store ptr %t474, ptr %rv
  br label %ret
bb137:
  br label %bb138
bb138:
  br label %bb139
bb139:
  %t477 = load ptr, ptr %l32, !tbaa !29
  %t479 = getelementptr %"compiler/typed:Cond", ptr %t477, i32 0, i32 2
  %t480 = load ptr, ptr %t479, !tbaa !29
  %t481 = load i64, ptr %l1, !tbaa !24
  %t484 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t480, i64 %t481)
  store ptr %t484, ptr %l255
  br label %bb140
bb140:
  %t485 = load ptr, ptr %l255, !tbaa !29
  store ptr %t485, ptr %rv
  br label %ret
bb141:
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l256, !tbaa !29
  store i1 false, ptr %l257, !tbaa !21
  %t487 = load ptr, ptr %l256, !tbaa !29
  %t488 = icmp ne ptr %t487, null
  br i1 %t488, label %bb142, label %bb143
bb142:
  %t490 = load ptr, ptr %l256, !tbaa !29
  %t491 = load i64, ptr %t490, !range !{i64 0, i64 18}
  %t493 = icmp eq i64 %t491, 17
  store i1 %t493, ptr %l257, !tbaa !21
  br label %bb143
bb143:
  %t494 = load i1, ptr %l257, !tbaa !21
  br i1 %t494, label %bb144, label %bb145
bb144:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr { i64, [5 x i64] }, ptr %t495, i32 0, i32 1
  %t498 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t497, i32 0, i32 2
  %t499 = load ptr, ptr %t498
  store ptr %t499, ptr %l34, !tbaa !29
  br label %bb146
bb145:
  br label %bb148
bb146:
  %t501 = load ptr, ptr %l34, !tbaa !29
  %t502 = load i64, ptr %l1, !tbaa !24
  %t505 = call ptr @compiler_2ffree_2efindCall(ptr %v0, ptr %v1, ptr %t501, i64 %t502)
  store ptr %t505, ptr %l264
  br label %bb147
bb147:
  %t506 = load ptr, ptr %l264, !tbaa !29
  store ptr %t506, ptr %rv
  br label %ret
bb148:
  br i1 true, label %bb149, label %bb150
bb149:
  br label %bb151
bb150:
  br label %bb152
bb151:
  store ptr null, ptr %rv
  br label %ret
bb152:
  call void @__olang_check_failed(ptr @olang_loc_3e8b13b2a7075e62_22250d1a20f2250e)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2ffree_2efindCallBlock(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l20 = alloca ptr
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t30 = call ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %t24, i64 %a1)
  store ptr %t30, ptr %l20
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l20, !tbaa !29
  store ptr %t31, ptr %l6, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = icmp eq ptr %t32, null
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t38 = load ptr, ptr %l6, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t41 = load i64, ptr %l3, !tbaa !24
  %t43 = add i64 %t41, 1
  store i64 %t43, ptr %l3, !tbaa !24
  br label %bb1
bb10:
  store ptr null, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2ffree_2eokind(i64 %a0) #0 {
entry:
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = ashr i64 %a0, 40
  store i64 %t3, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l48 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t20, ptr %l15
  br label %bb6
bb6:
  %t21 = load i1, ptr %l15, !tbaa !21
  store i1 %t21, ptr %l6, !tbaa !21
  br label %bb37
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t23 = load ptr, ptr %l16, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l17, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t41 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i1 %t41, ptr %l24
  br label %bb13
bb13:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l6, !tbaa !21
  br label %bb37
bb14:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = icmp ne ptr %t44, null
  br i1 %t45, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t48 = load i64, ptr %t47, !range !{i64 0, i64 8}
  %t50 = icmp eq i64 %t48, 4
  store i1 %t50, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t51 = load i1, ptr %l26, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr { i64, [4 x i64] }, ptr %t52, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t54, i32 0, i32 2
  %t56 = load ptr, ptr %t55
  store ptr %t56, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb25
bb19:
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Elem", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = call i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %t61)
  store i1 %t63, ptr %l33
  br label %bb20
bb20:
  %t64 = load i1, ptr %l33, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Elem", ptr %t65, i32 0, i32 0
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t72 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t68, ptr %t69)
  store i1 %t72, ptr %l38
  br label %bb23
bb22:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb24
bb23:
  %t73 = load i1, ptr %l38, !tbaa !21
  store i1 %t73, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t74 = load i1, ptr %l34, !tbaa !21
  store i1 %t74, ptr %l6, !tbaa !21
  br label %bb37
bb25:
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t77 = icmp ne ptr %t76, null
  br i1 %t77, label %bb26, label %bb27
bb26:
  %t79 = load ptr, ptr %l39, !tbaa !29
  %t80 = load i64, ptr %t79, !range !{i64 0, i64 8}
  %t82 = icmp eq i64 %t80, 5
  store i1 %t82, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t83 = load i1, ptr %l40, !tbaa !21
  br i1 %t83, label %bb28, label %bb29
bb28:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t86, i32 0, i32 2
  %t88 = load ptr, ptr %t87
  store ptr %t88, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/typed:Payload", ptr %t90, i32 0, i32 0
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t97 = call i1 @compiler_2ffree_2eplaceThrough(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t97, ptr %l48
  br label %bb31
bb31:
  %t98 = load i1, ptr %l48, !tbaa !21
  store i1 %t98, ptr %l6, !tbaa !21
  br label %bb37
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_40628693553637f3_9a0aaf33c7b3625f)
  unreachable
bb37:
  %t99 = load i1, ptr %l6, !tbaa !21
  store i1 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l31 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb36
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t11 = load ptr, ptr %l9, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 8}
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l16
  br label %bb12
bb12:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l4, !tbaa !21
  br label %bb36
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 8}
  %t36 = icmp eq i64 %t34, 2
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb31
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  store ptr %t44, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t45 = load ptr, ptr %l24, !tbaa !29
  %t46 = icmp ne ptr %t45, null
  br i1 %t46, label %bb19, label %bb20
bb19:
  %t48 = load ptr, ptr %l24, !tbaa !29
  %t49 = load i64, ptr %t48, !range !{i64 0, i64 18}
  %t51 = icmp eq i64 %t49, 2
  store i1 %t51, ptr %l25, !tbaa !21
  br label %bb20
bb20:
  %t52 = load i1, ptr %l25, !tbaa !21
  br i1 %t52, label %bb21, label %bb22
bb21:
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load ptr, ptr %t56
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = call i1 @compiler_2ffree_2epureBase(ptr %v0, ptr %t59)
  store i1 %t61, ptr %l31
  br label %bb24
bb24:
  %t62 = load i1, ptr %l31, !tbaa !21
  store i1 %t62, ptr %l23, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_73267d5e0cab398e_8c6ff0bab5f15012)
  unreachable
bb30:
  %t63 = load i1, ptr %l23, !tbaa !21
  store i1 %t63, ptr %l4, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_a4448d4b24e169cf_c9af2cff75b97a13)
  unreachable
bb36:
  %t64 = load i1, ptr %l4, !tbaa !21
  store i1 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2estmtMoves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l35 = alloca i1
  %l37 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l54 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l65 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb21
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t17 = load ptr, ptr %l14, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 18}
  %t23 = icmp eq i64 %t21, 4
  store i1 %t23, ptr %l15, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb14
bb9:
  %t25 = load ptr, ptr %l1, !tbaa !29
  store ptr %t25, ptr %l18, !tbaa !29
  store i1 false, ptr %l19, !tbaa !21
  %t26 = load ptr, ptr %l18, !tbaa !29
  %t27 = icmp ne ptr %t26, null
  br i1 %t27, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = load i64, ptr %t29, !range !{i64 0, i64 18}
  %t32 = icmp eq i64 %t30, 2
  store i1 %t32, ptr %l19, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l19, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_c5daa4e55685553d_6576efec0cd8f099)
  unreachable
bb20:
  %t34 = load i1, ptr %l13, !tbaa !21
  store i1 %t34, ptr %l6, !tbaa !21
  br label %bb64
bb21:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t36 = load ptr, ptr %l22, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb22, label %bb23
bb22:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 17}
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l23, !tbaa !21
  br label %bb23
bb23:
  %t43 = load i1, ptr %l23, !tbaa !21
  br i1 %t43, label %bb24, label %bb25
bb24:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr { i64, [3 x i64] }, ptr %t50, i32 0, i32 1
  %t53 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t52, i32 0, i32 2
  %t54 = load ptr, ptr %t53
  store ptr %t54, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t56 = load ptr, ptr %l2, !tbaa !29
  %t58 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t56)
  store i1 %t58, ptr %l31
  br label %bb27
bb27:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb28, label %bb29
bb28:
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = icmp eq ptr %t60, null
  br i1 %t62, label %bb30, label %bb31
bb29:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb34
bb30:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb33
bb31:
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t66 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t64)
  store i1 %t66, ptr %l37
  br label %bb32
bb32:
  %t67 = load i1, ptr %l37, !tbaa !21
  store i1 %t67, ptr %l35, !tbaa !21
  br label %bb33
bb33:
  %t68 = load i1, ptr %l35, !tbaa !21
  store i1 %t68, ptr %l32, !tbaa !21
  br label %bb34
bb34:
  %t69 = load i1, ptr %l32, !tbaa !21
  store i1 %t69, ptr %l6, !tbaa !21
  br label %bb64
bb35:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t71 = load ptr, ptr %l38, !tbaa !29
  %t72 = icmp ne ptr %t71, null
  br i1 %t72, label %bb36, label %bb37
bb36:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i64, ptr %t74, !range !{i64 0, i64 17}
  %t77 = icmp eq i64 %t75, 11
  store i1 %t77, ptr %l39, !tbaa !21
  br label %bb37
bb37:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb38, label %bb39
bb38:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  %t82 = getelementptr { %"compiler/source:Span", ptr }, ptr %t81, i32 0, i32 1
  %t83 = load ptr, ptr %t82
  store ptr %t83, ptr %l4, !tbaa !29
  br label %bb40
bb39:
  br label %bb42
bb40:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t85)
  store i1 %t87, ptr %l45
  br label %bb41
bb41:
  %t88 = load i1, ptr %l45, !tbaa !21
  store i1 %t88, ptr %l6, !tbaa !21
  br label %bb64
bb42:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb43, label %bb44
bb43:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 17}
  %t96 = icmp eq i64 %t94, 3
  store i1 %t96, ptr %l47, !tbaa !21
  br label %bb44
bb44:
  %t97 = load i1, ptr %l47, !tbaa !21
  br i1 %t97, label %bb45, label %bb46
bb45:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr { i64, [3 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l5, !tbaa !29
  br label %bb47
bb46:
  br label %bb59
bb47:
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = getelementptr %"compiler/typed:If", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t107)
  store i1 %t109, ptr %l54
  br label %bb48
bb48:
  %t110 = load i1, ptr %l54, !tbaa !21
  br i1 %t110, label %bb49, label %bb50
bb49:
  %t111 = load ptr, ptr %l5, !tbaa !29
  %t113 = getelementptr %"compiler/typed:If", ptr %t111, i32 0, i32 2
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = icmp eq ptr %t114, null
  br i1 %t116, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb58
bb51:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb57
bb52:
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t120 = getelementptr %"compiler/typed:If", ptr %t118, i32 0, i32 2
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t123 = icmp eq ptr %t121, null
  br i1 %t123, label %bb53, label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_d17276f5db7535d5_c56bc4e021877641)
  unreachable
bb54:
  br label %bb55
bb55:
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t127 = getelementptr %"compiler/typed:If", ptr %t125, i32 0, i32 2
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = call i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %t128)
  store i1 %t130, ptr %l65
  br label %bb56
bb56:
  %t131 = load i1, ptr %l65, !tbaa !21
  store i1 %t131, ptr %l59, !tbaa !21
  br label %bb57
bb57:
  %t132 = load i1, ptr %l59, !tbaa !21
  store i1 %t132, ptr %l55, !tbaa !21
  br label %bb58
bb58:
  %t133 = load i1, ptr %l55, !tbaa !21
  store i1 %t133, ptr %l6, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_3f14ee3b5ae87b07_81e960a9339250a3)
  unreachable
bb64:
  %t134 = load i1, ptr %l6, !tbaa !21
  store i1 %t134, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2ffree_2ewalker_2enewWalker(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, [2 x i64] }
  %l34 = alloca i32
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l44 = alloca ptr
  %l48 = alloca %"compiler/free:walker"
  %l87 = alloca ptr
  %l90 = alloca i64
  %l104 = alloca i64
  %l107 = alloca i64
  %l127 = alloca i64
  %l130 = alloca i64
  %l135 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l143 = alloca ptr
  %l144 = alloca %"compiler/source:Span"
  %l149 = alloca i64
  %l153 = alloca i64
  %l156 = alloca i64
  %l177 = alloca i32
  %l186 = alloca ptr
  %l189 = alloca i64
  %l190 = alloca i64
  %l196 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l210 = alloca i64
  %l213 = alloca i64
  %l231 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l241 = alloca i64
  %l244 = alloca i64
  %l265 = alloca ptr
  %l266 = alloca { i64, ptr }
  %l269 = alloca i64
  %l283 = alloca i64
  %l287 = alloca i64
  %l290 = alloca i64
  %l309 = alloca ptr
  %l313 = alloca i32
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  %t12 = alloca %"compiler/free:walker", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 6
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l44, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i1, ptr %l2, !tbaa !21
  call void @compiler_2ffree_3awalker_2ector(ptr %t12, ptr %v0, ptr %v0, ptr %t9, i64 %t10, i1 %t11)
  call void @llvm.memmove.p0.p0.i64(ptr %l48, ptr %t12, i64 1624, i1 false)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t16 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 1624, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %l48, i64 1624, i1 false)
  %t18 = load ptr, ptr %l44, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t18, i32 0, i32 6
  store ptr %t16, ptr %t19, !tbaa !29
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:Free", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_4f4bebe43ccb3632_b2d0ff49dc2f09b6)
  unreachable
bb6:
  br label %bb7
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:Free", ptr %t27, i32 0, i32 6
  %t30 = load ptr, ptr %t29, !tbaa !29
  store ptr %t30, ptr %l3, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  %t36 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 1
  store i64 %t33, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i1, ptr %l2, !tbaa !21
  %t41 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 2
  store i1 %t38, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l3, !tbaa !29
  %t44 = getelementptr %"compiler/free:walker", ptr %t42, i32 0, i32 5
  store i1 false, ptr %t44, !tbaa !21
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 6
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t47)
  br label %bb8
bb8:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t51)
  br label %bb9
bb9:
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t54 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t57 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 8
  store i32 %t54, ptr %t57, !tbaa !23
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/free:walker", ptr %t58, i32 0, i32 9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %t60)
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 10
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t64)
  br label %bb11
bb11:
  %t66 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %t68)
  br label %bb12
bb12:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/free:walker", ptr %t70, i32 0, i32 23
  store i64 0, ptr %t72, !tbaa !24
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 28
  store i64 0, ptr %t75, !tbaa !24
  %t76 = load ptr, ptr %l3, !tbaa !29
  %t78 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 29
  store i64 0, ptr %t78, !tbaa !24
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/free:walker", ptr %t79, i32 0, i32 30
  store i64 -1, ptr %t81, !tbaa !24
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t84 = getelementptr %"compiler/free:walker", ptr %t82, i32 0, i32 31
  store i64 -1, ptr %t84, !tbaa !24
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = getelementptr %"compiler/free:walker", ptr %t85, i32 0, i32 33
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %t87)
  br label %bb13
bb13:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %t89, i32 0, i32 39
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %t91)
  br label %bb14
bb14:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = getelementptr %"compiler/free:walker", ptr %t93, i32 0, i32 34
  store i64 -1, ptr %t95, !tbaa !24
  %t96 = load ptr, ptr %l3, !tbaa !29
  %t98 = getelementptr %"compiler/free:walker", ptr %t96, i32 0, i32 35
  store i64 -1, ptr %t98, !tbaa !24
  %t99 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereset(ptr %v0, ptr %t99)
  br label %bb15
bb15:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/free:Free", ptr %t101, i32 0, i32 1
  %t104 = load i64, ptr %l1, !tbaa !24
  %t107 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t103, i64 %t104)
  store ptr %t107, ptr %l87
  br label %bb16
bb16:
  %t108 = load ptr, ptr %l87, !tbaa !29
  store ptr %t108, ptr %l4, !tbaa !29
  %t109 = load ptr, ptr %l4, !tbaa !29
  %t111 = getelementptr %"compiler/typed:Body", ptr %t109, i32 0, i32 7
  %t113 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t111)
  store i64 %t113, ptr %l90
  br label %bb17
bb17:
  %t114 = load i64, ptr %l90, !tbaa !24
  store i64 %t114, ptr %l5, !tbaa !24
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t117 = getelementptr %"compiler/free:walker", ptr %t115, i32 0, i32 3
  %t118 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H2ad576503181bd1b8552368bfa2352a6(ptr %v0, ptr %t117, i64 %t118)
  br label %bb18
bb18:
  %t121 = load ptr, ptr %l3, !tbaa !29
  %t123 = getelementptr %"compiler/free:walker", ptr %t121, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t123)
  br label %bb19
bb19:
  %t125 = load ptr, ptr %l3, !tbaa !29
  %t127 = getelementptr %"compiler/free:walker", ptr %t125, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t127)
  br label %bb20
bb20:
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %t131)
  br label %bb21
bb21:
  store i64 0, ptr %l6, !tbaa !24
  %t133 = load i64, ptr %l5, !tbaa !24
  store i64 %t133, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l7, !tbaa !24
  %t136 = load i64, ptr %l6, !tbaa !24
  %t139 = icmp sgt i64 %t135, %t136
  br i1 %t139, label %bb22, label %bb23
bb22:
  %t141 = load i64, ptr %l8, !tbaa !24
  %t143 = icmp sgt i64 %t141, 0
  br i1 %t143, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l104, !tbaa !24
  br label %bb27
bb24:
  %t145 = load i64, ptr %l7, !tbaa !24
  %t146 = load i64, ptr %l6, !tbaa !24
  %t149 = sub i64 %t145, %t146
  %t150 = load i64, ptr %l8, !tbaa !24
  %t153 = add i64 %t149, %t150
  %t155 = sub i64 %t153, 1
  %t156 = load i64, ptr %l8, !tbaa !24
  %t159 = sdiv i64 %t155, %t156
  store i64 %t159, ptr %l107, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb26
bb26:
  %t161 = load i64, ptr %l107, !tbaa !24
  store i64 %t161, ptr %l104, !tbaa !24
  br label %bb27
bb27:
  %t162 = load i64, ptr %l104, !tbaa !24
  store i64 %t162, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t163 = load i64, ptr %l10, !tbaa !24
  %t164 = load i64, ptr %l9, !tbaa !24
  %t167 = icmp slt i64 %t163, %t164
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb45
bb30:
  br label %bb31
bb31:
  %t171 = load i64, ptr %l6, !tbaa !24
  %t172 = load i64, ptr %l10, !tbaa !24
  %t173 = load i64, ptr %l8, !tbaa !24
  %t176 = mul i64 %t172, %t173
  %t179 = add i64 %t171, %t176
  store i64 %t179, ptr %l11, !tbaa !24
  %t181 = load ptr, ptr %l3, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 4
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t183, i1 false)
  br label %bb32
bb32:
  %t185 = load i64, ptr %l11, !tbaa !24
  store i64 %t185, ptr %l127, !tbaa !24
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t188 = getelementptr %"compiler/free:walker", ptr %t186, i32 0, i32 3
  %t190 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %t188)
  store i64 %t190, ptr %l130
  br label %bb33
bb33:
  %t191 = load i64, ptr %l127, !tbaa !24
  %t192 = load i64, ptr %l130, !tbaa !24
  %t193 = icmp slt i64 %t191, %t192
  br i1 %t193, label %bb34, label %bb35
bb34:
  %t195 = load ptr, ptr %l3, !tbaa !29
  %t197 = getelementptr %"compiler/free:walker", ptr %t195, i32 0, i32 3
  %t198 = load i64, ptr %l11, !tbaa !24
  %t201 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t197, i64 %t198)
  store ptr %t201, ptr %l135
  br label %bb36
bb35:
  %t202 = load ptr, ptr %l3, !tbaa !29
  %t204 = getelementptr %"compiler/free:walker", ptr %t202, i32 0, i32 3
  store ptr %t204, ptr %l137, !tbaa !29
  %t205 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l138
  br label %bb38
bb36:
  %t206 = load ptr, ptr %l135, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t206)
  br label %bb37
bb37:
  br label %bb40
bb38:
  %t207 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l138
  %t208 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t207, ptr %t208
  %t209 = load ptr, ptr %l137, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t209, ptr %t208)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t211 = load ptr, ptr %l3, !tbaa !29
  %t213 = getelementptr %"compiler/free:walker", ptr %t211, i32 0, i32 20
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t213, i64 0)
  br label %bb41
bb41:
  %t215 = load ptr, ptr %l3, !tbaa !29
  %t217 = getelementptr %"compiler/free:walker", ptr %t215, i32 0, i32 21
  store ptr %t217, ptr %l143, !tbaa !29
  %t218 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 0, i32 0)
  store %"compiler/source:Span" %t218, ptr %l144
  br label %bb42
bb42:
  %t219 = load ptr, ptr %l143, !tbaa !29
  %t220 = load %"compiler/source:Span", ptr %l144
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t219, %"compiler/source:Span" %t220)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb44:
  %t221 = load i64, ptr %l10, !tbaa !24
  %t223 = add i64 %t221, 1
  store i64 %t223, ptr %l10, !tbaa !24
  br label %bb28
bb45:
  store i64 0, ptr %l12, !tbaa !24
  %t225 = load ptr, ptr %l4, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Body", ptr %t225, i32 0, i32 5
  %t229 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t227)
  store i64 %t229, ptr %l149
  br label %bb46
bb46:
  %t230 = load i64, ptr %l149, !tbaa !24
  store i64 %t230, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l13, !tbaa !24
  %t232 = load i64, ptr %l12, !tbaa !24
  %t235 = icmp sgt i64 %t231, %t232
  br i1 %t235, label %bb47, label %bb48
bb47:
  %t237 = load i64, ptr %l14, !tbaa !24
  %t239 = icmp sgt i64 %t237, 0
  br i1 %t239, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l153, !tbaa !24
  br label %bb52
bb49:
  %t241 = load i64, ptr %l13, !tbaa !24
  %t242 = load i64, ptr %l12, !tbaa !24
  %t245 = sub i64 %t241, %t242
  %t246 = load i64, ptr %l14, !tbaa !24
  %t249 = add i64 %t245, %t246
  %t251 = sub i64 %t249, 1
  %t252 = load i64, ptr %l14, !tbaa !24
  %t255 = sdiv i64 %t251, %t252
  store i64 %t255, ptr %l156, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb51
bb51:
  %t257 = load i64, ptr %l156, !tbaa !24
  store i64 %t257, ptr %l153, !tbaa !24
  br label %bb52
bb52:
  %t258 = load i64, ptr %l153, !tbaa !24
  store i64 %t258, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb53
bb53:
  %t259 = load i64, ptr %l16, !tbaa !24
  %t260 = load i64, ptr %l15, !tbaa !24
  %t263 = icmp slt i64 %t259, %t260
  %t265 = xor i1 %t263, true
  br i1 %t265, label %bb54, label %bb55
bb54:
  br label %bb63
bb55:
  br label %bb56
bb56:
  %t267 = load i64, ptr %l12, !tbaa !24
  %t268 = load i64, ptr %l16, !tbaa !24
  %t269 = load i64, ptr %l14, !tbaa !24
  %t272 = mul i64 %t268, %t269
  %t275 = add i64 %t267, %t272
  store i64 %t275, ptr %l17, !tbaa !24
  %t277 = load ptr, ptr %l4, !tbaa !29
  %t279 = getelementptr %"compiler/typed:Body", ptr %t277, i32 0, i32 5
  %t280 = load i64, ptr %l17, !tbaa !24
  %t283 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t279, i64 %t280)
  store i32 %t283, ptr %l177
  br label %bb57
bb57:
  %t284 = load i32, ptr %l177, !tbaa !23
  %t285 = sext i32 %t284 to i64
  store i64 %t285, ptr %l18, !tbaa !24
  %t287 = load ptr, ptr %l3, !tbaa !29
  %t289 = getelementptr %"compiler/free:walker", ptr %t287, i32 0, i32 6
  %t290 = load i64, ptr %l18, !tbaa !24
  %t291 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t289, i64 %t290, i64 %t291)
  br label %bb58
bb58:
  %t295 = load ptr, ptr %l3, !tbaa !29
  %t297 = getelementptr %"compiler/free:walker", ptr %t295, i32 0, i32 3
  %t298 = load i64, ptr %l18, !tbaa !24
  %t301 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t297, i64 %t298)
  store ptr %t301, ptr %l186
  br label %bb59
bb59:
  %t302 = load i64, ptr @G_2ecompiler_2ffree_2eOPar, !tbaa !24
  %t303 = load i64, ptr %l17, !tbaa !24
  %t306 = call i64 @compiler_2ffree_2eorig(i64 %t302, i64 %t303)
  store i64 %t306, ptr %l189
  br label %bb60
bb60:
  %t307 = load ptr, ptr %l186, !tbaa !29
  %t308 = load i64, ptr %l189, !tbaa !24
  %t309 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t307, i64 %t308)
  store i64 %t309, ptr %l190
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t310 = load i64, ptr %l16, !tbaa !24
  %t312 = add i64 %t310, 1
  store i64 %t312, ptr %l16, !tbaa !24
  br label %bb53
bb63:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = getelementptr %"compiler/free:Free", ptr %t314, i32 0, i32 58
  %t317 = load i64, ptr %l1, !tbaa !24
  %t320 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t316, i64 %t317)
  store { i64, ptr } %t320, ptr %l196
  br label %bb64
bb64:
  %t321 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t321, ptr %l19, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t324 = extractvalue { i64, ptr } %t322, 0
  %t325 = load i64, ptr %l5, !tbaa !24
  %t327 = add i64 %t325, 1
  %t330 = icmp eq i64 %t324, %t327
  br i1 %t330, label %bb65, label %bb66
bb65:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/free:Free", ptr %t332, i32 0, i32 57
  %t335 = load i64, ptr %l1, !tbaa !24
  %t338 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t334, i64 %t335)
  store { i64, ptr } %t338, ptr %l205
  br label %bb67
bb66:
  br label %bb94
bb67:
  %t339 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t339, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t340 = load i64, ptr %l5, !tbaa !24
  store i64 %t340, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t342 = load i64, ptr %l22, !tbaa !24
  %t343 = load i64, ptr %l21, !tbaa !24
  %t346 = icmp sgt i64 %t342, %t343
  br i1 %t346, label %bb68, label %bb69
bb68:
  %t348 = load i64, ptr %l23, !tbaa !24
  %t350 = icmp sgt i64 %t348, 0
  br i1 %t350, label %bb70, label %bb71
bb69:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb73
bb70:
  %t352 = load i64, ptr %l22, !tbaa !24
  %t353 = load i64, ptr %l21, !tbaa !24
  %t356 = sub i64 %t352, %t353
  %t357 = load i64, ptr %l23, !tbaa !24
  %t360 = add i64 %t356, %t357
  %t362 = sub i64 %t360, 1
  %t363 = load i64, ptr %l23, !tbaa !24
  %t366 = sdiv i64 %t362, %t363
  store i64 %t366, ptr %l213, !tbaa !24
  br label %bb72
bb71:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb72
bb72:
  %t368 = load i64, ptr %l213, !tbaa !24
  store i64 %t368, ptr %l210, !tbaa !24
  br label %bb73
bb73:
  %t369 = load i64, ptr %l210, !tbaa !24
  store i64 %t369, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb74
bb74:
  %t370 = load i64, ptr %l25, !tbaa !24
  %t371 = load i64, ptr %l24, !tbaa !24
  %t374 = icmp slt i64 %t370, %t371
  %t376 = xor i1 %t374, true
  br i1 %t376, label %bb75, label %bb76
bb75:
  br label %bb93
bb76:
  br label %bb77
bb77:
  %t378 = load i64, ptr %l21, !tbaa !24
  %t379 = load i64, ptr %l25, !tbaa !24
  %t380 = load i64, ptr %l23, !tbaa !24
  %t383 = mul i64 %t379, %t380
  %t386 = add i64 %t378, %t383
  store i64 %t386, ptr %l26, !tbaa !24
  %t388 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t388, ptr %l231, !tbaa !27
  %t389 = load i64, ptr %l26, !tbaa !24
  %t391 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr i64, ptr %t392, i64 %t389
  %t394 = load i64, ptr %t393, !tbaa !34
  store i64 %t394, ptr %l27, !tbaa !24
  %t396 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t396, ptr %l234, !tbaa !27
  %t397 = load i64, ptr %l26, !tbaa !24
  %t399 = add i64 %t397, 1
  %t401 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t402 = load ptr, ptr %t401, !tbaa !27
  %t403 = getelementptr i64, ptr %t402, i64 %t399
  %t404 = load i64, ptr %t403, !tbaa !34
  store i64 %t404, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t406 = load i64, ptr %l28, !tbaa !24
  %t407 = load i64, ptr %l27, !tbaa !24
  %t410 = icmp sgt i64 %t406, %t407
  br i1 %t410, label %bb78, label %bb79
bb78:
  %t412 = load i64, ptr %l29, !tbaa !24
  %t414 = icmp sgt i64 %t412, 0
  br i1 %t414, label %bb80, label %bb81
bb79:
  store i64 0, ptr %l241, !tbaa !24
  br label %bb83
bb80:
  %t416 = load i64, ptr %l28, !tbaa !24
  %t417 = load i64, ptr %l27, !tbaa !24
  %t420 = sub i64 %t416, %t417
  %t421 = load i64, ptr %l29, !tbaa !24
  %t424 = add i64 %t420, %t421
  %t426 = sub i64 %t424, 1
  %t427 = load i64, ptr %l29, !tbaa !24
  %t430 = sdiv i64 %t426, %t427
  store i64 %t430, ptr %l244, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l244, !tbaa !24
  br label %bb82
bb82:
  %t432 = load i64, ptr %l244, !tbaa !24
  store i64 %t432, ptr %l241, !tbaa !24
  br label %bb83
bb83:
  %t433 = load i64, ptr %l241, !tbaa !24
  store i64 %t433, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb84
bb84:
  %t434 = load i64, ptr %l31, !tbaa !24
  %t435 = load i64, ptr %l30, !tbaa !24
  %t438 = icmp slt i64 %t434, %t435
  %t440 = xor i1 %t438, true
  br i1 %t440, label %bb85, label %bb86
bb85:
  br label %bb91
bb86:
  br label %bb87
bb87:
  %t442 = load i64, ptr %l27, !tbaa !24
  %t443 = load i64, ptr %l31, !tbaa !24
  %t444 = load i64, ptr %l29, !tbaa !24
  %t447 = mul i64 %t443, %t444
  %t450 = add i64 %t442, %t447
  store i64 %t450, ptr %l32, !tbaa !24
  %t452 = load ptr, ptr %l3, !tbaa !29
  %t454 = getelementptr %"compiler/free:walker", ptr %t452, i32 0, i32 3
  %t455 = load i64, ptr %l26, !tbaa !24
  %t458 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t454, i64 %t455)
  store ptr %t458, ptr %l265
  br label %bb88
bb88:
  %t459 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t459, ptr %l266, !tbaa !27
  %t460 = load i64, ptr %l32, !tbaa !24
  %t462 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t463 = load ptr, ptr %t462, !tbaa !27
  %t464 = getelementptr i64, ptr %t463, i64 %t460
  %t465 = load i64, ptr %t464, !tbaa !34
  %t466 = load ptr, ptr %l265, !tbaa !29
  %t468 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t466, i64 %t465)
  store i64 %t468, ptr %l269
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t469 = load i64, ptr %l31, !tbaa !24
  %t471 = add i64 %t469, 1
  store i64 %t471, ptr %l31, !tbaa !24
  br label %bb84
bb91:
  br label %bb92
bb92:
  %t473 = load i64, ptr %l25, !tbaa !24
  %t475 = add i64 %t473, 1
  store i64 %t475, ptr %l25, !tbaa !24
  br label %bb74
bb93:
  br label %bb94
bb94:
  %t477 = load ptr, ptr %l4, !tbaa !29
  %t479 = getelementptr %"compiler/typed:Body", ptr %t477, i32 0, i32 1
  %t480 = load { i64, [2 x i64] }, ptr %t479
  store { i64, [2 x i64] } %t480, ptr %l33
  %t482 = load { i64, [2 x i64] }, ptr %l33
  %t484 = extractvalue { i64, [2 x i64] } %t482, 0
  %t485 = icmp eq i64 %t484, 1
  br i1 %t485, label %bb95, label %bb96
bb95:
  %t487 = getelementptr { i64, [2 x i64] }, ptr %l33, i32 0, i32 1
  %t488 = getelementptr { i32, i32 }, ptr %t487, i32 0, i32 0
  %t489 = load i32, ptr %t488
  store i32 %t489, ptr %l34, !tbaa !23
  br label %bb97
bb96:
  br label %bb113
bb97:
  %t491 = load ptr, ptr %l3, !tbaa !29
  %t492 = load i32, ptr %l34, !tbaa !23
  %t495 = getelementptr %"compiler/free:walker", ptr %t491, i32 0, i32 8
  store i32 %t492, ptr %t495, !tbaa !23
  store i64 0, ptr %l35, !tbaa !24
  %t496 = load ptr, ptr %l4, !tbaa !29
  %t498 = getelementptr %"compiler/typed:Body", ptr %t496, i32 0, i32 10
  %t500 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t498)
  store i64 %t500, ptr %l283
  br label %bb98
bb98:
  %t501 = load i64, ptr %l283, !tbaa !24
  store i64 %t501, ptr %l36, !tbaa !24
  store i64 1, ptr %l37, !tbaa !24
  %t502 = load i64, ptr %l36, !tbaa !24
  %t503 = load i64, ptr %l35, !tbaa !24
  %t506 = icmp sgt i64 %t502, %t503
  br i1 %t506, label %bb99, label %bb100
bb99:
  %t508 = load i64, ptr %l37, !tbaa !24
  %t510 = icmp sgt i64 %t508, 0
  br i1 %t510, label %bb101, label %bb102
bb100:
  store i64 0, ptr %l287, !tbaa !24
  br label %bb104
bb101:
  %t512 = load i64, ptr %l36, !tbaa !24
  %t513 = load i64, ptr %l35, !tbaa !24
  %t516 = sub i64 %t512, %t513
  %t517 = load i64, ptr %l37, !tbaa !24
  %t520 = add i64 %t516, %t517
  %t522 = sub i64 %t520, 1
  %t523 = load i64, ptr %l37, !tbaa !24
  %t526 = sdiv i64 %t522, %t523
  store i64 %t526, ptr %l290, !tbaa !24
  br label %bb103
bb102:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb103
bb103:
  %t528 = load i64, ptr %l290, !tbaa !24
  store i64 %t528, ptr %l287, !tbaa !24
  br label %bb104
bb104:
  %t529 = load i64, ptr %l287, !tbaa !24
  store i64 %t529, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb105
bb105:
  %t530 = load i64, ptr %l39, !tbaa !24
  %t531 = load i64, ptr %l38, !tbaa !24
  %t534 = icmp slt i64 %t530, %t531
  %t536 = xor i1 %t534, true
  br i1 %t536, label %bb106, label %bb107
bb106:
  br label %bb112
bb107:
  br label %bb108
bb108:
  %t538 = load i64, ptr %l35, !tbaa !24
  %t539 = load i64, ptr %l39, !tbaa !24
  %t540 = load i64, ptr %l37, !tbaa !24
  %t543 = mul i64 %t539, %t540
  %t546 = add i64 %t538, %t543
  store i64 %t546, ptr %l40, !tbaa !24
  %t548 = load ptr, ptr %l3, !tbaa !29
  %t550 = getelementptr %"compiler/free:walker", ptr %t548, i32 0, i32 7
  store ptr %t550, ptr %l309, !tbaa !29
  %t551 = load ptr, ptr %l4, !tbaa !29
  %t553 = getelementptr %"compiler/typed:Body", ptr %t551, i32 0, i32 10
  %t554 = load i64, ptr %l40, !tbaa !24
  %t557 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t553, i64 %t554)
  store i32 %t557, ptr %l313
  br label %bb109
bb109:
  %t558 = load i32, ptr %l313, !tbaa !23
  %t559 = sext i32 %t558 to i64
  %t560 = load i64, ptr %l40, !tbaa !24
  %t561 = load ptr, ptr %l309, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t561, i64 %t559, i64 %t560)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t564 = load i64, ptr %l39, !tbaa !24
  %t566 = add i64 %t564, 1
  store i64 %t566, ptr %l39, !tbaa !24
  br label %bb105
bb112:
  br label %bb118
bb113:
  br i1 true, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_47453ae46be9b210_439bef1cf54c0f44)
  unreachable
bb118:
  %t568 = load ptr, ptr %l3, !tbaa !29
  store ptr %t568, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2ffree_2eyieldsMoved(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Block", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l2, !tbaa !24
  %t11 = load i64, ptr %l3, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t18, ptr %l13, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t28 = call i1 @compiler_2ffree_2estmtMoves(ptr %v0, ptr %t24)
  store i1 %t28, ptr %l17
  br label %bb5
bb5:
  %t29 = load i1, ptr %l17, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t35 = add i64 %t33, 1
  store i64 %t35, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/free:retire" @compiler_2ffree_3aretire_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %rv = alloca %"compiler/free:retire"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/free:retire" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/free:retire" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/free:retire" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, 2
  store %"compiler/free:retire" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:retire", ptr %rv
  ret %"compiler/free:retire" %rr
}

define dso_local void @compiler_2ffree_3awalker_2ector(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i1 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i1
  %l9 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca i32
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l41 = alloca i64
  %l42 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l63 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l64 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l65 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l72 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l86 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca %"compiler/source:Span"
  %l89 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l103 = alloca %"compiler/free:walker"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l3, !tbaa !29
  store i64 %a1, ptr %l4, !tbaa !24
  store i1 %a2, ptr %l5, !tbaa !21
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l62
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l6
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l63
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l7
  store i1 false, ptr %l8, !tbaa !21
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l64
  br label %bb3
bb3:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l64
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %l9
  %t13 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t13, ptr %l65
  br label %bb4
bb4:
  %t14 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l65
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t14, ptr %l10
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t15, ptr %l11, !tbaa !23
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l67
  br label %bb5
bb5:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l12
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l68
  br label %bb6
bb6:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t21 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l69
  br label %bb7
bb7:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l16
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l70
  br label %bb8
bb8:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l17
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l71
  br label %bb9
bb9:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l18
  %t27 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l72
  br label %bb10
bb10:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l72
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l19
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l73
  br label %bb11
bb11:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l73
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %l20
  %t31 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %l74
  br label %bb12
bb12:
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %l21
  %t33 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t33, ptr %l75
  br label %bb13
bb13:
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l75
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %l22
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l76
  br label %bb14
bb14:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l76
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l23
  %t37 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t37, ptr %l77
  br label %bb15
bb15:
  %t38 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l77
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t38, ptr %l24
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l78
  br label %bb16
bb16:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l25
  store i64 0, ptr %l26, !tbaa !24
  %t41 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t41, ptr %l79
  br label %bb17
bb17:
  %t42 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l27
  %t43 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t43, ptr %l80
  br label %bb18
bb18:
  %t44 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l28
  %t45 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l81
  br label %bb19
bb19:
  %t46 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l29
  %t47 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l82
  br label %bb20
bb20:
  %t48 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l30
  store i64 0, ptr %l31, !tbaa !24
  store i64 0, ptr %l32, !tbaa !24
  store i64 -1, ptr %l33, !tbaa !24
  store i64 -1, ptr %l34, !tbaa !24
  store i64 -1, ptr %l35, !tbaa !24
  %t49 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t49, ptr %l83
  br label %bb21
bb21:
  %t50 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l83
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t50, ptr %l36
  store i64 -1, ptr %l37, !tbaa !24
  store i64 -1, ptr %l38, !tbaa !24
  %t51 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %l84
  br label %bb22
bb22:
  %t52 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l39
  %t53 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H8ba8de7724048003f4d7cc05c69a72ae(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t53, ptr %l85
  br label %bb23
bb23:
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l85
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %l40
  store i64 0, ptr %l41, !tbaa !24
  %t55 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t55, ptr %l86
  br label %bb24
bb24:
  %t56 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t56, ptr %l42
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l87
  br label %bb25
bb25:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l43
  %t59 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 0, i32 0)
  store %"compiler/source:Span" %t59, ptr %l88
  br label %bb26
bb26:
  %t60 = load %"compiler/source:Span", ptr %l88
  store %"compiler/source:Span" %t60, ptr %l44
  %t61 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %l89
  br label %bb27
bb27:
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l89
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %l45
  %t63 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t63, ptr %l90
  br label %bb28
bb28:
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l46
  %t65 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l91
  br label %bb29
bb29:
  %t66 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t66, ptr %l47
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l92
  br label %bb30
bb30:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l48
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l93
  br label %bb31
bb31:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l93
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l49
  %t71 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t71, ptr %l94
  br label %bb32
bb32:
  %t72 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t72, ptr %l50
  %t73 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t73, ptr %l95
  br label %bb33
bb33:
  %t74 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l95
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l51
  %t75 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %l96
  br label %bb34
bb34:
  %t76 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t76, ptr %l52
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l97
  br label %bb35
bb35:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l53
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l98
  br label %bb36
bb36:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l54
  %t81 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l99
  br label %bb37
bb37:
  %t82 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t82, ptr %l55
  %t83 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %l100
  br label %bb38
bb38:
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84, ptr %l56
  %t85 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l101
  br label %bb39
bb39:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l101
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l57
  %t87 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v1)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t87, ptr %l102
  br label %bb40
bb40:
  %t88 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l102
  %t89 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 0
  %t90 = load ptr, ptr %l3, !tbaa !29
  store ptr %t90, ptr %t89, !tbaa !29
  %t91 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 1
  %t92 = load i64, ptr %l4, !tbaa !24
  store i64 %t92, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 2
  %t94 = load i1, ptr %l5, !tbaa !21
  store i1 %t94, ptr %t93, !tbaa !21
  %t95 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 3
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %t95
  %t97 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 4
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, ptr %t97
  %t99 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 5
  %t100 = load i1, ptr %l8, !tbaa !21
  store i1 %t100, ptr %t99, !tbaa !21
  %t101 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 6
  %t102 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l9
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t102, ptr %t101
  %t103 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 7
  %t104 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t104, ptr %t103
  %t105 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 8
  %t106 = load i32, ptr %l11, !tbaa !23
  store i32 %t106, ptr %t105, !tbaa !23
  %t107 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 9
  %t108 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t108, ptr %t107
  %t109 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 10
  %t110 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t110, ptr %t109
  %t111 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 11
  %t112 = load i64, ptr %l14, !tbaa !24
  store i64 %t112, ptr %t111, !tbaa !24
  %t113 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 12
  %t114 = load i64, ptr %l15, !tbaa !24
  store i64 %t114, ptr %t113, !tbaa !24
  %t115 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 13
  %t116 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %t115
  %t117 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 14
  %t118 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t118, ptr %t117
  %t119 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 15
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l18
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %t119
  %t121 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 16
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %t121
  %t123 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 17
  %t124 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t124, ptr %t123
  %t125 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 18
  %t126 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t126, ptr %t125
  %t127 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 19
  %t128 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t128, ptr %t127
  %t129 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 20
  %t130 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %t129
  %t131 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 21
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %t131
  %t133 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 22
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %t133
  %t135 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 23
  %t136 = load i64, ptr %l26, !tbaa !24
  store i64 %t136, ptr %t135, !tbaa !24
  %t137 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 24
  %t138 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %t137
  %t139 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 25
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %t139
  %t141 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 26
  %t142 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %t141
  %t143 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 27
  %t144 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l30
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t144, ptr %t143
  %t145 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 28
  %t146 = load i64, ptr %l31, !tbaa !24
  store i64 %t146, ptr %t145, !tbaa !24
  %t147 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 29
  %t148 = load i64, ptr %l32, !tbaa !24
  store i64 %t148, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 30
  %t150 = load i64, ptr %l33, !tbaa !24
  store i64 %t150, ptr %t149, !tbaa !24
  %t151 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 31
  %t152 = load i64, ptr %l34, !tbaa !24
  store i64 %t152, ptr %t151, !tbaa !24
  %t153 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 32
  %t154 = load i64, ptr %l35, !tbaa !24
  store i64 %t154, ptr %t153, !tbaa !24
  %t155 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 33
  %t156 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l36
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t156, ptr %t155
  %t157 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 34
  %t158 = load i64, ptr %l37, !tbaa !24
  store i64 %t158, ptr %t157, !tbaa !24
  %t159 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 35
  %t160 = load i64, ptr %l38, !tbaa !24
  store i64 %t160, ptr %t159, !tbaa !24
  %t161 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 36
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %t161
  %t163 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 37
  %t164 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l40
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t164, ptr %t163
  %t165 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 38
  %t166 = load i64, ptr %l41, !tbaa !24
  store i64 %t166, ptr %t165, !tbaa !24
  %t167 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 39
  %t168 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l42
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t168, ptr %t167
  %t169 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 40
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %t169
  %t171 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 41
  %t172 = load %"compiler/source:Span", ptr %l44
  store %"compiler/source:Span" %t172, ptr %t171
  %t173 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 42
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %t173
  %t175 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 43
  %t176 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %t175
  %t177 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 44
  %t178 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, ptr %t177
  %t179 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 45
  %t180 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t180, ptr %t179
  %t181 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 46
  %t182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %t181
  %t183 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 47
  %t184 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %t183
  %t185 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 48
  %t186 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t186, ptr %t185
  %t187 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 49
  %t188 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %t187
  %t189 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 50
  %t190 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t190, ptr %t189
  %t191 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 51
  %t192 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t192, ptr %t191
  %t193 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 52
  %t194 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t194, ptr %t193
  %t195 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 53
  %t196 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %t195
  %t197 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 54
  %t198 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %t197
  %t199 = getelementptr %"compiler/free:walker", ptr %l103, i32 0, i32 55
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t88, ptr %t199
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l103, i64 1624, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" handle" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d2 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"place " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" sole " }>, align 8
@.c6 = private unnamed_addr constant [5 x i8] c"true\00"
@.c7 = private unnamed_addr constant [6 x i8] c"false\00"
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" lets " }>, align 8
@.d9 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" stores " }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" why " }>, align 8
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d12 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"store place " }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" body " }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" kind " }>, align 8
@.d15 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" site " }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d18 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"letgo place " }>, align 8
@.d19 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" body " }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" kind " }>, align 8
@.d21 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d24 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"body " }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d26 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" stored " }>, align 8
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2emut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load ptr, ptr %a0, !tbaa !29
  store ptr %t2, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t4 = icmp ne ptr %t3, null
  br i1 %t4, label %bb1, label %bb3
bb1:
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = icmp sge i64 %t6, 8
  br i1 %t7, label %bb4, label %bb5
bb2:
  br label %ret
bb3:
  %t9 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t10 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t9, i64 %t10)
  br label %bb2
bb4:
  %t11 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %v0, ptr %t11, i64 %t12)
  br label %bb2
bb5:
  %t13 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t13, 1
  store i64 %t14, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l2, !tbaa !29
  store ptr %t15, ptr %l6, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l6, !tbaa !29
  %t17 = call ptr @__olang_scope_of(ptr %t16, ptr null)
  %t18 = ptrtoint ptr %t17 to i64
  %t20 = inttoptr i64 %t18 to ptr
  %t21 = load ptr, ptr %l6, !tbaa !29
  %t22 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eStr_3cI64_3e(ptr %t20, ptr %s1, ptr %t21)
  store { i64, ptr } %t22, ptr %l7
  br label %bb6
bb6:
  %t23 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  call void @__olang_sb_put(ptr %v0, ptr %t24, i64 %t25)
  call void @__olang_scope_close(ptr %s1)
  br label %bb2
ret:
  ret void
}

@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" esc " }>, align 8
@.d28 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" multi " }>, align 8
@.d29 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" whole " }>, align 8
@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" res " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_sb_done(ptr)
@.d32 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"tasks " }>, align 8
@.d33 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" hidden " }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define linkonce_odr %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"its elements" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d38 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"a task can reach it: nothing is freed early where a program has tasks" }>, align 8
@.d39 = private constant <{ i64, [130 x i8] }> <{ i64 0, [130 x i8] c"C may call an export fn from a thread of its own: nothing is freed early where C is given one, links C of its own, or is a library" }>, align 8
@.d40 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"a destructor, Str, Eq or Hash lets go of it where no call is written" }>, align 8
@.d41 = private constant <{ i64, [144 x i8] }> <{ i64 0, [144 x i8] c"its new value may hold an instance whose destructor is still to run (O16), which a let-go would run early: build that instance outside the value" }>, align 8
@.d42 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"a value built into what it holds may hold an instance whose destructor is still to run (O16)" }>, align 8
@.d43 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"a call building into what it holds may register an instance whose destructor is still to run (O16)" }>, align 8
@.d44 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"its new value cannot be built in a region of its own here" }>, align 8
@.d45 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"what it holds has a destructor still to run when it lets go (O15): its holder ends it" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d46 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"what holds it is an owner held in a place of early freeing, whose storage is one region" }>, align 8
@.d47 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"its new value is moved out of a place that keeps" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 8}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 8}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb12
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 ]
bb3:
  br label %bb12
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb8, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [1 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [1 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb9, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [1 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [1 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb10, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [1 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [1 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb11, label %bb1
bb8:
  br label %bb3
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  %t58 = load i1, ptr %l2, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d48 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"free: registered " }>, align 8
@.d49 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare void @__olang_errpay_pop()
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d52 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d53 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d54 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tree" }>, align 8
@.d55 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d56 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d57 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d58 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"'; give it new storage - a constructor call, '$...', 'Copy()'" }>, align 8
@.d59 = private constant <{ i64, [51 x i8] }> <{ i64 0, [51 x i8] c"its new value is a copy holding other owners too: '" }>, align 8
@.d60 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d61 = private constant <{ i64, [50 x i8] }> <{ i64 0, [50 x i8] c"its new value is existing storage a copy shares: '" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
declare void @__olang_bang_failed_plain(ptr) cold noreturn
@.d63 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d64 = private constant <{ i64, [43 x i8] }> <{ i64 0, [43 x i8] c"its new value is moved out of another place" }>, align 8
@.d65 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"its new value has a default" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"its new value is existing storage: '" }>, align 8
@.d68 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"'; give it new storage - a constructor call, '$...', 'Copy()'" }>, align 8
@.d69 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"its elements may hold storage built with it: '" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d71 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"its new value is kept in another place too" }>, align 8
@.d72 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"its new value is built in a module compiled on its own" }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d75 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"a value of it read in this statement is in use when '" }>, align 8
@.d76 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"' lets go of it; read what you need first" }>, align 8
@.d77 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d78 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d80 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" from '" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d82 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d85 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c", '" }>, align 8
@.d86 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'," }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"what the loop on line " }>, align 8
@.d89 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" walks" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d92 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"after '" }>, align 8
@.d93 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
@.d94 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"), where the generator's caller may let go of it; read what you need" }>, align 8
@.d95 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" before the yield" }>, align 8
@.d96 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"after it lets go of it (line " }>, align 8
@.d97 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"); read what you need" }>, align 8
@.d98 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" before" }>, align 8
@.d99 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"after '" }>, align 8
@.d100 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"' (line " }>, align 8
@.d101 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"), which " }>, align 8
@.d102 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"; read what you need" }>, align 8
@.d103 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c" before the call" }>, align 8
@.d104 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" is used here, " }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fv_H8ba8de7724048003f4d7cc05c69a72ae(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
@.d105 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"null" }>, align 8
@.d106 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"..." }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eMovBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsSole(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_8f29d0df7ac0b0b1_5a3f673e10b5ae55 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esafe(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_3a516a19293feeda_7f77204653e04cce = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
@olang_loc_77e2c420ac7907a9_804235f2ad53d = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRTask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_834ee64634399a9c_46784e5d37862958 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_dcc3c6712d01991_ec14a6947a12b86d = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eRCopied = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_7bd178b281ab108b_bca5961225cfb287 = external constant [0 x i8]
@olang_loc_54a8cb88ede7d99c_f1d49282556d5568 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_df2621a9cc7e5891_c8dc80a57ad57a3d = external constant [0 x i8]
@olang_loc_d176219a3bee3f8a_90c874c8f8700e56 = external constant [0 x i8]
@olang_loc_3832ed25f787c577_46d12f44adcfa45b = external constant [0 x i8]
@olang_loc_78b7d87e61167558_7d12aa6674d4d96c = external constant [0 x i8]
@olang_loc_5c0fdc79e2d66a14_68e7480db742a728 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_9eead29ed0644a31_3adf6a8ef4d2d8d5 = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_4e10a6e17fa9b999_b873e8c9bb06b2fd = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, [1 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eVarRels(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erelsFit(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_a4118a366f7ca1d5_524409770a0878b9 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_5c44d6b41b035ab1_55f561a861d07b6d = external constant [0 x i8]
@olang_loc_3bfd4abaed3d7178_ecedd42d9535955c = external constant [0 x i8]
declare i1 @compiler_2ffree_2eruns({ i64, [1 x i64] } %a0)
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/free:store" @compiler_2ffree_3astore_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, ptr %a8)
@olang_loc_18f4ed1d8e27b1ae_93487f3f650a5572 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eValueParts(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
@G_2ecompiler_2ffree_2eRemovalNames = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@olang_loc_b71f5ffe7a4b5626_fc1be7c1ddcacd52 = external constant [0 x i8]
@olang_loc_80901eaab4a643b4_757281eb5f4291b0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bdafa441ac13699b_f5af7a3548cb73f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eoval(i64 %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eOPar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eOParC = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
declare i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eMustNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewithinExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_6cb79447255537d7_e828faabaec907d3 = external constant [0 x i8]
@olang_loc_b0d58e2b07420cd2_669637d27520b416 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [1 x i64] } %a4, i1 %a5, i1 %a6)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [1 x i64] } %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2ePush_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3amustW_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eplaceMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2ecallMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3amustW_2etryMust(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2eisConversion(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_2f86b0bb9e05ec4_6260055ddf2cdd10 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2eisParam(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_26_3e_2eAt_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3amustW_2efresh(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egive(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_304dd9f782c5c299_7aedab6f7faf5da5 = external constant [0 x i8]
@olang_loc_ceff65db82d42b72_bd0ee798a65f80fe = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_1c2ece56a8f93bb3_9a04e0623a4a84af = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eviewsOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3ed6c54977104fdc_6fa493e2929cd018 = external constant [0 x i8]
declare i1 @compiler_2ftyped_2eViewsMoved(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewCtor(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_68d09f9a6af90acb_8af3bb3c4e4b4237 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H5a6912247a81ac1f46c16a43fcc4c44a(ptr %v0, ptr %v1, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ethrough(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
@olang_loc_7f12d3772dd0a929_45b952e679e83a85 = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ffree_2eSFail = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2ePush_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i64 @compiler_2ffree_2eownCopySite(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4638628f5b2e3f80_2351d26d56dc1634 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc57530578add1ad359c6d87470cc4752(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_H68cd31c3dbcdb47f3349b834dda1e07d(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_95c175a58ff05fe9_ec975816cf48fd1d = external constant [0 x i8]
@olang_loc_c3a39e1a8321cbe9_14cb6b0bd5f3e345 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eAnyPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ffree_2eLVacate = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
@olang_loc_5c8710160ed2ee88_42fe4478e6ab17dc = external constant [0 x i8]
@G_2ecompiler_2ffree_2eLDrop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0)
@olang_loc_e32699ce7a94654a_1a46213a714ace46 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eHas_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_Ha64a825bb0b4fc6c7596ac96329c2853(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eLen_3cBool_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eLHeld = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ffree_2eLYield = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/free:letGo" @compiler_2ffree_3aletGo_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, %"compiler/source:Span" %a6, i64 %a7, i1 %a8)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2ePush_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, %"compiler/free:letGo" %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2ffree_2eSOk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_7676aaa4af173342_5bef0e3278c42ba6 = external constant [0 x i8]
@olang_loc_a47d70a6f4791f29_9aa1d88f57dbf58d = external constant [0 x i8]
declare { i64, { i64, ptr } } @compiler_2ffree_2ecompiler_2ffree_3awalker_2efreshSite(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_c3165b793781225b_53a43f46ee99ca6f = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainElems(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2emovesOnly(ptr %v0, ptr %a0)
@olang_loc_a02d4e2a18cd3a61_9c6a7f96807aa8b5 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eUnique(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_720a25314e6ed839_22eb7101f62f811d = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eloopAround(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_71c754545de4040c_468b95bb5168a5f8 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eClear_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hcb8ba31809995dcae45f5acc6cf39f88(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eClear_3cI64_2c_20I64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArrayRef(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_311feee871305b59_d38294057dde4ced = external constant [0 x i8]
@olang_loc_421add8d063ee188_aab923ea260c413c = external constant [0 x i8]
@olang_loc_34bfc259355dec67_8a2d14d061fee643 = external constant [0 x i8]
@olang_loc_806a74b5c91de186_4e306eb4964e9ec2 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsEntry(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_350c73b6578d6328_239abab62451b64c = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estore(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Haa8dec86a2077fe432a5bd923bc4b0fd(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_2a6707270ca06c1b_81c43f034781ce2f = external constant [0 x i8]
@olang_loc_de370d56f621a286_665adcb3259bb65a = external constant [0 x i8]
@olang_loc_61a66e32b2a4c4a5_788650647dbfbbd9 = external constant [0 x i8]
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepView(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2eremoves(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_228ad70617d44d77_1dee412aac6cbab = external constant [0 x i8]
@olang_loc_5e2122fa9519644f_a9d9059c63542dd3 = external constant [0 x i8]
@olang_loc_546be3fdfb2e7861_5a4791e17fa5075d = external constant [0 x i8]
@olang_loc_5891e56eddc46c99_f944b0e713971375 = external constant [0 x i8]
@olang_loc_16263ed1acd4aa7e_23dcb8f717a142b2 = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallPlace(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ea2e0f0d6ffcb248_fe73fa1c8e55849c = external constant [0 x i8]
declare ptr @compiler_2ffree_2efindCallStmt(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6e2453cb19a4d71d_88f1503d6cec0391 = external constant [0 x i8]
@olang_loc_a8e684701cb727b6_7b41502ddc5bea8a = external constant [0 x i8]
@olang_loc_3e8b13b2a7075e62_22250d1a20f2250e = external constant [0 x i8]
declare i1 @compiler_2ffree_2ereachedThrough(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2epureIndex(ptr %v0, ptr %a0)
@olang_loc_40628693553637f3_9a0aaf33c7b3625f = external constant [0 x i8]
@olang_loc_73267d5e0cab398e_8c6ff0bab5f15012 = external constant [0 x i8]
@olang_loc_a4448d4b24e169cf_c9af2cff75b97a13 = external constant [0 x i8]
@olang_loc_c5daa4e55685553d_6576efec0cd8f099 = external constant [0 x i8]
@olang_loc_d17276f5db7535d5_c56bc4e021877641 = external constant [0 x i8]
@olang_loc_3f14ee3b5ae87b07_81e960a9339250a3 = external constant [0 x i8]
@olang_loc_4f4bebe43ccb3632_b2d0ff49dc2f09b6 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eClea_Hf36a88772899b36a46c039ef55a38999(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__Hca84839cdf395382408370342cfafe64(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_Hc1e7c6bbb3acbd34c924c83b2bb772b9(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H2ad576503181bd1b8552368bfa2352a6(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eClear_3cBool_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2eAt_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_47453ae46be9b210_439bef1cf54c0f44 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eStr_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
