; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
@G_2estd_2flist_2efirstChunk = constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@G_2estd_2flist_2efirstChunkLog = constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
define dso_local i64 @std_2flist_2ehighBit(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 4294967296
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t8 = ashr i64 %t5, 32
  store i64 %t8, ptr %l0, !tbaa !24
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = add i64 %t10, 32
  store i64 %t13, ptr %l1, !tbaa !24
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t15 = load i64, ptr %l0, !tbaa !24
  %t17 = icmp sge i64 %t15, 65536
  br i1 %t17, label %bb4, label %bb5
bb4:
  %t19 = load i64, ptr %l0, !tbaa !24
  %t22 = ashr i64 %t19, 16
  store i64 %t22, ptr %l0, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = add i64 %t24, 16
  store i64 %t27, ptr %l1, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l0, !tbaa !24
  %t31 = icmp sge i64 %t29, 256
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr %l0, !tbaa !24
  %t36 = ashr i64 %t33, 8
  store i64 %t36, ptr %l0, !tbaa !24
  %t38 = load i64, ptr %l1, !tbaa !24
  %t41 = add i64 %t38, 8
  store i64 %t41, ptr %l1, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t43 = load i64, ptr %l0, !tbaa !24
  %t45 = icmp sge i64 %t43, 16
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load i64, ptr %l0, !tbaa !24
  %t50 = ashr i64 %t47, 4
  store i64 %t50, ptr %l0, !tbaa !24
  %t52 = load i64, ptr %l1, !tbaa !24
  %t55 = add i64 %t52, 4
  store i64 %t55, ptr %l1, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t57 = load i64, ptr %l0, !tbaa !24
  %t59 = icmp sge i64 %t57, 4
  br i1 %t59, label %bb13, label %bb14
bb13:
  %t61 = load i64, ptr %l0, !tbaa !24
  %t64 = ashr i64 %t61, 2
  store i64 %t64, ptr %l0, !tbaa !24
  %t66 = load i64, ptr %l1, !tbaa !24
  %t69 = add i64 %t66, 2
  store i64 %t69, ptr %l1, !tbaa !24
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t71 = load i64, ptr %l0, !tbaa !24
  %t73 = icmp sge i64 %t71, 2
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load i64, ptr %l1, !tbaa !24
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %l1, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t80 = load i64, ptr %l1, !tbaa !24
  store i64 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}


!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
