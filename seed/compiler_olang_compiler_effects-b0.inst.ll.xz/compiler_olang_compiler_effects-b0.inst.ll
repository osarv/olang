; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/effects:given" = type { i64, i64, i64, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/effects:fslot" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"std/prelude/map:MapEntry.03df2158eb545360607ea17ec9e1c3f3" = type { %"compiler/effects:pair", i1 }
%"compiler/effects:pair" = type { i64, i64 }
%"compiler/effects:fpath" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32 }
%"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/effects:link" = type { i64, i64, i64 }
define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H17d172c890106e7669720f11d3813b09(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca %"compiler/effects:given"
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_d304065e85e07eb7_978c4f606565fc53)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d304065e85e07eb7_978c4f606565fc53)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l34
  %t93 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l35, !tbaa !24
  %t96 = load i64, ptr %l35, !tbaa !24
  %t97 = mul i64 %t96, 80
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t101 = load i64, ptr %l37, !tbaa !24
  %t102 = load i64, ptr %l35, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  br i1 %t103, label %bb18, label %bb19
bb18:
  %t105 = load i64, ptr %l37, !tbaa !24
  %t106 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = icmp slt i64 %t105, %t107
  br i1 %t108, label %bb22, label %bb20
bb19:
  %t110 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t111 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  store { i64, ptr } %t110, ptr %t111, !tbaa !27
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t113 = load ptr, ptr %l31, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %l32, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t117, i64 %t115
  %t119 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t118, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %t119
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t120 = load i64, ptr %l37, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/effects:given", ptr %t122, i64 %t120
  store %"compiler/effects:given" zeroinitializer, ptr %t123
  br label %bb21
bb21:
  %t124 = load i64, ptr %l37, !tbaa !24
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l37, !tbaa !24
  br label %bb17
bb22:
  %t126 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t127 = load i64, ptr %l37, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/effects:given", ptr %t129, i64 %t127
  %t131 = load %"compiler/effects:given", ptr %t130
  store %"compiler/effects:given" %t131, ptr %l40
  %t132 = getelementptr %"compiler/effects:given", ptr %l40, i32 0, i32 5
  %t133 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t132, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l41, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l42, !tbaa !24
  %t137 = load i64, ptr %l42, !tbaa !24
  %t138 = mul i64 %t137, 8
  %t139 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l43, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l42, !tbaa !24
  %t147 = mul i64 %t146, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  %t148 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t149 = getelementptr %"compiler/effects:given", ptr %l40, i32 0, i32 5
  %t150 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t149, i32 0, i32 0
  store { i64, ptr } %t148, ptr %t150, !tbaa !27
  %t151 = load %"compiler/effects:given", ptr %l40
  %t152 = load i64, ptr %l37, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr %"compiler/effects:given", ptr %t154, i64 %t152
  store %"compiler/effects:given" %t151, ptr %t155
  br label %bb21
bb23:
  br label %bb24
bb24:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l4, !tbaa !24
  %t159 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t156, i32 0, i32 1
  %t161 = getelementptr { i64, ptr }, ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i64, ptr %t162, i64 %t157
  %t164 = load i64, ptr %t163, !tbaa !34
  store i64 %t164, ptr %l4, !tbaa !24
  br label %bb11
bb25:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l47, !tbaa !29
  %t167 = load i64, ptr %l3, !tbaa !24
  store i64 %t167, ptr %l48, !tbaa !24
  %t168 = load i64, ptr %l1, !tbaa !24
  store i64 %t168, ptr %l49, !tbaa !24
  %t169 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l50
  %t171 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %s0, ptr %l50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, ptr %l52
  br label %bb26
bb26:
  %t172 = load ptr, ptr %l47, !tbaa !29
  %t173 = load i64, ptr %l48, !tbaa !24
  %t174 = load i64, ptr %l49, !tbaa !24
  %t175 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H5ff29b28d6a4226c0ecc80ba4d487bea(ptr %v0, ptr %s0, ptr %t172, i64 %t173, i64 %t174, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t175)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hafeff049746af34a0f4960f24da5119b(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l41 = alloca %"compiler/effects:fslot"
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_28c32a1869498861_1488d00961e0923d)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_28c32a1869498861_1488d00961e0923d)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i64, ptr %l1, !tbaa !24
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %t52, i64 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t91 = call ptr @__olang_region_make(ptr %v0)
  %t92 = ptrtoint ptr %t91 to i64
  store i64 %t92, ptr %l33, !tbaa !24
  %t93 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l35
  %t95 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l36, !tbaa !24
  %t98 = load i64, ptr %l36, !tbaa !24
  %t99 = mul i64 %t98, 48
  %t100 = load i64, ptr %l33
  %t101 = inttoptr i64 %t100 to ptr
  %t102 = call ptr @__olang_held_alloc(ptr %t101, i64 %t99)
  %t103 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t105 = load i64, ptr %l38, !tbaa !24
  %t106 = load i64, ptr %l36, !tbaa !24
  %t107 = icmp slt i64 %t105, %t106
  br i1 %t107, label %bb18, label %bb19
bb18:
  %t109 = load i64, ptr %l38, !tbaa !24
  %t110 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 1
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = icmp slt i64 %t109, %t111
  br i1 %t112, label %bb22, label %bb20
bb19:
  %t114 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t115 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  store { i64, ptr } %t114, ptr %t115, !tbaa !27
  %t116 = load i64, ptr %l33
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = call ptr @__olang_region_or(ptr %t120, ptr null)
  %t122 = call ptr @__olang_region_home(ptr %t121)
  %t123 = icmp ne ptr %t122, null
  %t124 = select i1 %t123, ptr %t122, ptr null
  call void @__olang_region_settle_in(ptr %t117, ptr %t124)
  %t125 = load ptr, ptr %l31, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  %t127 = load i64, ptr %l32, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t129, i64 %t127
  %t131 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t130, i32 0, i32 1
  %t132 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t131
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t132, ptr %l45
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  %t134 = load ptr, ptr %l31, !tbaa !29
  %t135 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t134, i32 0, i32 0
  %t136 = load i64, ptr %l32, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t138, i64 %t136
  %t140 = getelementptr %"std/prelude/map:MapEntry.f17f3f0202174eb6591f595766c15613", ptr %t139, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %t140
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45, i32 0, i32 0
  %t142 = load { i64, ptr }, ptr %t141
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = call ptr @__olang_region_or(ptr %t143, ptr null)
  %t145 = call ptr @__olang_region_home(ptr %t144)
  %t146 = icmp ne ptr %t145, null
  %t147 = select i1 %t146, ptr %t145, ptr null
  call void @__olang_region_drop(ptr %t147)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l45
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t148 = load i64, ptr %l38, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/effects:fslot", ptr %t150, i64 %t148
  store %"compiler/effects:fslot" zeroinitializer, ptr %t151
  br label %bb21
bb21:
  %t152 = load i64, ptr %l38, !tbaa !24
  %t153 = add i64 %t152, 1
  store i64 %t153, ptr %l38, !tbaa !24
  br label %bb17
bb22:
  %t154 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35, i32 0, i32 0
  %t155 = load i64, ptr %l38, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr %"compiler/effects:fslot", ptr %t157, i64 %t155
  %t159 = load %"compiler/effects:fslot", ptr %t158
  store %"compiler/effects:fslot" %t159, ptr %l41
  %t160 = getelementptr %"compiler/effects:fslot", ptr %l41, i32 0, i32 1
  %t161 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t160, i32 0, i32 0
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  store { i64, ptr } %t162, ptr %l42, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  store i64 %t164, ptr %l43, !tbaa !24
  %t165 = load i64, ptr %l43, !tbaa !24
  %t166 = mul i64 %t165, 8
  %t167 = load i64, ptr %l33
  %t168 = inttoptr i64 %t167 to ptr
  %t169 = call ptr @__olang_held_alloc(ptr %t168, i64 %t166)
  %t170 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l44, !tbaa !27
  %t172 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = load i64, ptr %l43, !tbaa !24
  %t177 = mul i64 %t176, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t173, ptr %t175, i64 %t177, i1 false)
  %t178 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t179 = getelementptr %"compiler/effects:fslot", ptr %l41, i32 0, i32 1
  %t180 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t179, i32 0, i32 0
  store { i64, ptr } %t178, ptr %t180, !tbaa !27
  %t181 = load %"compiler/effects:fslot", ptr %l41
  %t182 = load i64, ptr %l38, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr %"compiler/effects:fslot", ptr %t184, i64 %t182
  store %"compiler/effects:fslot" %t181, ptr %t185
  br label %bb21
bb23:
  br label %bb24
bb24:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i64, ptr %l4, !tbaa !24
  %t189 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t186, i32 0, i32 1
  %t191 = getelementptr { i64, ptr }, ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i64, ptr %t192, i64 %t187
  %t194 = load i64, ptr %t193, !tbaa !34
  store i64 %t194, ptr %l4, !tbaa !24
  br label %bb11
bb25:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l49, !tbaa !29
  %t197 = load i64, ptr %l3, !tbaa !24
  store i64 %t197, ptr %l50, !tbaa !24
  %t198 = load i64, ptr %l1, !tbaa !24
  store i64 %t198, ptr %l51, !tbaa !24
  %t199 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t199, ptr %l52
  %t201 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %s0, ptr %l52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t201, ptr %l54
  br label %bb26
bb26:
  %t202 = load ptr, ptr %l49, !tbaa !29
  %t203 = load i64, ptr %l50, !tbaa !24
  %t204 = load i64, ptr %l51, !tbaa !24
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_He77e3d6ad35c8a6c8d6f6b9d4d267ded(ptr %v0, ptr %s0, ptr %t202, i64 %t203, i64 %t204, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e_H0ce891880ff4cf8c497cb99326d3b2fc(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca i64
  %l44 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l78 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  store { i64, ptr } %t23, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_7c5a221fc21546b6_8cd0583a02f1cc52)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_7c5a221fc21546b6_8cd0583a02f1cc52)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.03df2158eb545360607ea17ec9e1c3f3", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @__olang_region_make_part(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l31, !tbaa !24
  store i64 %t50, ptr %l32, !tbaa !24
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = mul i64 %t58, 24
  %t60 = mul i64 %t57, 24
  %t61 = extractvalue { i64, ptr } %t55, 1
  %t62 = call ptr @__olang_grow_in_place(ptr %t61, i64 %t59, i64 %t60, i64 %t57)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, i64 %t57, i64 0
  %t65 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t62, 1
  store { i64, ptr } %t66, ptr %l35, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_7c5a221fc21546b6_8cd0583a02f1cc52)
  unreachable
bb10:
  %t72 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t72, ptr %l33, !tbaa !27
  br label %bb12
bb11:
  %t73 = load i64, ptr %l32, !tbaa !24
  %t74 = mul i64 %t73, 24
  %t75 = load i64, ptr %l31
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = call ptr @__olang_held_alloc(ptr %t76, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb13
bb12:
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb19, label %bb20
bb13:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t86 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t91 = icmp slt i64 %t85, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l44, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr %"std/prelude/map:MapEntry.03df2158eb545360607ea17ec9e1c3f3", ptr %t99, i64 %t96
  %t101 = load %"std/prelude/map:MapEntry.03df2158eb545360607ea17ec9e1c3f3", ptr %t100
  %t103 = load i64, ptr %l38, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"std/prelude/map:MapEntry.03df2158eb545360607ea17ec9e1c3f3", ptr %t105, i64 %t103
  store %"std/prelude/map:MapEntry.03df2158eb545360607ea17ec9e1c3f3" %t101, ptr %t106
  %t107 = load i64, ptr %l38, !tbaa !24
  %t108 = add i64 %t107, 1
  store i64 %t108, ptr %l38, !tbaa !24
  br label %bb17
bb17:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = add i64 %t109, 1
  store i64 %t112, ptr %l5, !tbaa !24
  br label %bb13
bb18:
  br label %bb12
bb19:
  store { i64, ptr } zeroinitializer, ptr %l33, !tbaa !27
  br label %bb20
bb20:
  %t114 = load i64, ptr %l31
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = load { i64, ptr }, ptr %l33
  %t117 = extractvalue { i64, ptr } %t116, 1
  %t118 = call ptr @__olang_region_or(ptr %t117, ptr null)
  %t119 = icmp ne ptr %t118, null
  %t120 = select i1 %t119, ptr %t118, ptr null
  call void @__olang_region_settle_in(ptr %t115, ptr %t120)
  %t121 = load ptr, ptr %l21, !tbaa !29
  %t122 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t121, i32 0, i32 0
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l52, !tbaa !27
  %t124 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t125 = load ptr, ptr %l21, !tbaa !29
  %t126 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t125, i32 0, i32 0
  store { i64, ptr } %t124, ptr %t126, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l52
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release_part(ptr %t129, i64 %t128)
  store { i64, ptr } zeroinitializer, ptr %l52
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t130, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l55, !tbaa !29
  store { i64, ptr } %t133, ptr %l56, !tbaa !27
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t137, i32 0, i32 3
  %t140 = load i64, ptr %t139, !tbaa !24
  store i64 %t140, ptr %l58, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  store i64 %t142, ptr %l59, !tbaa !24
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb21, label %bb22
bb21:
  %t145 = load i64, ptr %l58, !tbaa !24
  %t146 = icmp sle i64 0, %t145
  br i1 %t146, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7c6b183b1a98ab13_d6bf4b540853c4f)
  unreachable
bb23:
  %t148 = load i64, ptr %l58, !tbaa !24
  %t149 = load i64, ptr %l59, !tbaa !24
  %t150 = icmp sle i64 %t148, %t149
  br i1 %t150, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7c6b183b1a98ab13_d6bf4b540853c4f)
  unreachable
bb25:
  %t152 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l58, !tbaa !24
  %t155 = getelementptr i64, ptr %t153, i64 0
  %t156 = sub i64 %t154, 0
  %t157 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t155, 1
  store { i64, ptr } %t158, ptr %l7, !tbaa !27
  %t160 = load i64, ptr %l1, !tbaa !24
  %t162 = call ptr @__olang_region_make_part(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l65, !tbaa !24
  store i64 %t160, ptr %l66, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t167 = load i64, ptr %l66, !tbaa !24
  %t168 = extractvalue { i64, ptr } %t165, 0
  %t169 = mul i64 %t168, 8
  %t170 = mul i64 %t167, 8
  %t171 = extractvalue { i64, ptr } %t165, 1
  %t172 = call ptr @__olang_grow_in_place(ptr %t171, i64 %t169, i64 %t170, i64 %t167)
  %t173 = icmp ne ptr %t172, null
  %t174 = select i1 %t173, i64 %t167, i64 0
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t172, 1
  store { i64, ptr } %t176, ptr %l69, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t180 = icmp ne i64 %t178, 0
  br i1 %t180, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7c6b183b1a98ab13_d6bf4b540853c4f)
  unreachable
bb27:
  %t182 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t182, ptr %l67, !tbaa !27
  br label %bb29
bb28:
  %t183 = load i64, ptr %l66, !tbaa !24
  %t184 = mul i64 %t183, 8
  %t185 = load i64, ptr %l65
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  %t188 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l67, !tbaa !27
  store i64 0, ptr %l72, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb29:
  %t190 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t193 = icmp eq i64 %t191, 0
  br i1 %t193, label %bb36, label %bb37
bb30:
  %t195 = load i64, ptr %l9, !tbaa !24
  %t196 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t201 = icmp slt i64 %t195, %t198
  %t203 = xor i1 %t201, true
  br i1 %t203, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t205 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t205, ptr %l78, !tbaa !27
  %t206 = load i64, ptr %l9, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr i64, ptr %t209, i64 %t206
  %t211 = load i64, ptr %t210, !tbaa !34
  %t213 = load i64, ptr %l72, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr i64, ptr %t215, i64 %t213
  store i64 %t211, ptr %t216, !tbaa !34
  %t217 = load i64, ptr %l72, !tbaa !24
  %t218 = add i64 %t217, 1
  store i64 %t218, ptr %l72, !tbaa !24
  br label %bb34
bb34:
  %t219 = load i64, ptr %l9, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l9, !tbaa !24
  br label %bb30
bb35:
  br label %bb29
bb36:
  store { i64, ptr } zeroinitializer, ptr %l67, !tbaa !27
  br label %bb37
bb37:
  %t224 = load i64, ptr %l65
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load { i64, ptr }, ptr %l67
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = call ptr @__olang_region_or(ptr %t227, ptr null)
  %t229 = icmp ne ptr %t228, null
  %t230 = select i1 %t229, ptr %t228, ptr null
  call void @__olang_region_settle_in(ptr %t225, ptr %t230)
  %t231 = load ptr, ptr %l55, !tbaa !29
  %t232 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t231, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l86, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t235 = load ptr, ptr %l55, !tbaa !29
  %t236 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t235, i32 0, i32 1
  store { i64, ptr } %t234, ptr %t236, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l86
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  call void @__olang_region_release_part(ptr %t239, i64 %t238)
  store { i64, ptr } zeroinitializer, ptr %l86
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H23909c0b6cdd8c6a8e8461d347ccf8af(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l19 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l40 = alloca %"compiler/effects:fpath"
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i32
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s0 = alloca %olang.scope
  %t21 = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp eq i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l9, !tbaa !29
  %t11 = call ptr @__olang_region_make_part(ptr %v0)
  %t12 = ptrtoint ptr %t11 to i64
  store i64 %t12, ptr %l10, !tbaa !24
  %t13 = icmp sge i64 8, 0
  br i1 %t13, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  %t15 = icmp sle i64 8, 1152921504606846975
  br i1 %t15, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4b410134ecf81b51_3b1651859bccdb6d)
  unreachable
bb5:
  %t17 = mul i64 8, 8
  %t18 = load i64, ptr %l10
  %t19 = inttoptr i64 %t18 to ptr
  %t20 = call ptr @__olang_held_alloc(ptr %t19, i64 %t17)
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, 8
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr i64, ptr %t20, i64 %t25
  store i64 -1, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 8, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t20, 1
  store { i64, ptr } %t30, ptr %l13, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_4b410134ecf81b51_3b1651859bccdb6d)
  unreachable
bb7:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb8
bb8:
  %t36 = load i64, ptr %l10
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load { i64, ptr }, ptr %l13
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = call ptr @__olang_region_or(ptr %t39, ptr null)
  %t41 = icmp ne ptr %t40, null
  %t42 = select i1 %t41, ptr %t40, ptr null
  call void @__olang_region_settle_in(ptr %t37, ptr %t42)
  %t43 = load ptr, ptr %l9, !tbaa !29
  %t44 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t43, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t47 = load ptr, ptr %l9, !tbaa !29
  %t48 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t47, i32 0, i32 2
  store { i64, ptr } %t46, ptr %t48, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l16
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  call void @__olang_region_release_part(ptr %t51, i64 %t50)
  store { i64, ptr } zeroinitializer, ptr %l16
  br label %bb9
bb9:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H0ad23e78b2b593286f94a0de5701989f(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l19
  br label %bb10
bb10:
  %t57 = load i64, ptr %l19, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l3, !tbaa !24
  %t61 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t58, i32 0, i32 2
  %t63 = getelementptr { i64, ptr }, ptr %t61, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i64, ptr %t64, i64 %t59
  %t66 = load i64, ptr %t65, !tbaa !34
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb11
bb11:
  %t68 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sge i64 %t68, 0
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t74, i32 0, i32 0
  %t79 = getelementptr { i64, ptr }, ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t80, i64 %t75
  %t82 = getelementptr %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t81, i32 0, i32 0
  %t83 = load i32, ptr %t82, !tbaa !23
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = icmp eq i32 %t83, %t84
  br i1 %t87, label %bb15, label %bb16
bb15:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l31, !tbaa !29
  %t90 = load i64, ptr %l4, !tbaa !24
  store i64 %t90, ptr %l32, !tbaa !24
  %t91 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t91, ptr %l34
  %t93 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l35, !tbaa !24
  %t96 = load i64, ptr %l35, !tbaa !24
  %t97 = mul i64 %t96, 40
  %t98 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t101 = load i64, ptr %l37, !tbaa !24
  %t102 = load i64, ptr %l35, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  br i1 %t103, label %bb18, label %bb19
bb18:
  %t105 = load i64, ptr %l37, !tbaa !24
  %t106 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 1
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = icmp slt i64 %t105, %t107
  br i1 %t108, label %bb22, label %bb20
bb19:
  %t110 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t111 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  store { i64, ptr } %t110, ptr %t111, !tbaa !27
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t113 = load ptr, ptr %l31, !tbaa !29
  %t114 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %l32, !tbaa !24
  %t116 = getelementptr { i64, ptr }, ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t117, i64 %t115
  %t119 = getelementptr %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t118, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %t119
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t120 = load i64, ptr %l37, !tbaa !24
  %t121 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr %"compiler/effects:fpath", ptr %t122, i64 %t120
  store %"compiler/effects:fpath" zeroinitializer, ptr %t123
  br label %bb21
bb21:
  %t124 = load i64, ptr %l37, !tbaa !24
  %t125 = add i64 %t124, 1
  store i64 %t125, ptr %l37, !tbaa !24
  br label %bb17
bb22:
  %t126 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34, i32 0, i32 0
  %t127 = load i64, ptr %l37, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr %"compiler/effects:fpath", ptr %t129, i64 %t127
  %t131 = load %"compiler/effects:fpath", ptr %t130
  store %"compiler/effects:fpath" %t131, ptr %l40
  %t132 = getelementptr %"compiler/effects:fpath", ptr %l40, i32 0, i32 0
  %t133 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t132, i32 0, i32 0
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !27
  store { i64, ptr } %t134, ptr %l41, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l42, !tbaa !24
  %t137 = load i64, ptr %l42, !tbaa !24
  %t138 = mul i64 %t137, 8
  %t139 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l43, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l42, !tbaa !24
  %t147 = mul i64 %t146, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  %t148 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t149 = getelementptr %"compiler/effects:fpath", ptr %l40, i32 0, i32 0
  %t150 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t149, i32 0, i32 0
  store { i64, ptr } %t148, ptr %t150, !tbaa !27
  %t151 = load %"compiler/effects:fpath", ptr %l40
  %t152 = load i64, ptr %l37, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr %"compiler/effects:fpath", ptr %t154, i64 %t152
  store %"compiler/effects:fpath" %t151, ptr %t155
  br label %bb21
bb23:
  br label %bb24
bb24:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load i64, ptr %l4, !tbaa !24
  %t159 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t156, i32 0, i32 1
  %t161 = getelementptr { i64, ptr }, ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i64, ptr %t162, i64 %t157
  %t164 = load i64, ptr %t163, !tbaa !34
  store i64 %t164, ptr %l4, !tbaa !24
  br label %bb11
bb25:
  %t166 = load ptr, ptr %l0, !tbaa !29
  store ptr %t166, ptr %l47, !tbaa !29
  %t167 = load i64, ptr %l3, !tbaa !24
  store i64 %t167, ptr %l48, !tbaa !24
  %t168 = load i32, ptr %l1, !tbaa !23
  store i32 %t168, ptr %l49, !tbaa !23
  %t169 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t169, ptr %l50
  %t171 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e(ptr %s0, ptr %l50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, ptr %l52
  br label %bb26
bb26:
  %t172 = load ptr, ptr %l47, !tbaa !29
  %t173 = load i64, ptr %l48, !tbaa !24
  %t174 = load i32, ptr %l49, !tbaa !23
  %t175 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H5654dfb8722cc0004754aed78f118291(ptr %v0, ptr %s0, ptr %t172, i64 %t173, i32 %t174, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t175)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H2e6c9dae6f3e304010aafc4515d4641b(ptr %v0, ptr %a0) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l7 = alloca { i64, ptr }
  %l9 = alloca i64
  %l14 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l39 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i64
  %l72 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t8 = icmp slt i64 %t6, 4
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i64 8, ptr %l14, !tbaa !24
  br label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t10, i32 0, i32 0
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = mul i64 %t15, 2
  store i64 %t17, ptr %l14, !tbaa !24
  br label %bb3
bb3:
  %t19 = load i64, ptr %l14, !tbaa !24
  store i64 %t19, ptr %l1, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  store { i64, ptr } %t23, ptr %l2, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l22, !tbaa !27
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t27, i32 0, i32 3
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l24, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 0, 0
  br i1 %t33, label %bb4, label %bb5
bb4:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = icmp sle i64 0, %t35
  br i1 %t36, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_ae67406c9931ff49_4b4459f87ee3c0ed)
  unreachable
bb6:
  %t38 = load i64, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = icmp sle i64 %t38, %t39
  br i1 %t40, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_ae67406c9931ff49_4b4459f87ee3c0ed)
  unreachable
bb8:
  %t42 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l24, !tbaa !24
  %t45 = getelementptr %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t43, i64 0
  %t46 = sub i64 %t44, 0
  %t47 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t45, 1
  store { i64, ptr } %t48, ptr %l3, !tbaa !27
  %t50 = load i64, ptr %l1, !tbaa !24
  %t54 = mul i64 %t50, 40
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ae67406c9931ff49_4b4459f87ee3c0ed)
  unreachable
bb10:
  %t58 = load i64, ptr %l5, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t64 = icmp slt i64 %t58, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t68 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t68, ptr %l39, !tbaa !27
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t72, i64 %t69
  %t74 = load %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t73
  store %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387" zeroinitializer, ptr %t73
  %t76 = load i64, ptr %l33, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387", ptr %t78, i64 %t76
  store %"std/prelude/map:MapEntry.0769abb240fa4d9f09390771d4b86387" %t74, ptr %t79
  %t80 = load i64, ptr %l33, !tbaa !24
  %t81 = add i64 %t80, 1
  store i64 %t81, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t82, 1
  store i64 %t85, ptr %l5, !tbaa !24
  br label %bb10
bb15:
  %t87 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t88 = load ptr, ptr %l21, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t88, i32 0, i32 0
  store { i64, ptr } %t87, ptr %t89, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t92, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l49, !tbaa !29
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t99, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  store i64 %t102, ptr %l52, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l53, !tbaa !24
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb16, label %bb17
bb16:
  %t107 = load i64, ptr %l52, !tbaa !24
  %t108 = icmp sle i64 0, %t107
  br i1 %t108, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_2fb9f75078a6e9dc_888656e0ac4b2310)
  unreachable
bb18:
  %t110 = load i64, ptr %l52, !tbaa !24
  %t111 = load i64, ptr %l53, !tbaa !24
  %t112 = icmp sle i64 %t110, %t111
  br i1 %t112, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_2fb9f75078a6e9dc_888656e0ac4b2310)
  unreachable
bb20:
  %t114 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = load i64, ptr %l52, !tbaa !24
  %t117 = getelementptr i64, ptr %t115, i64 0
  %t118 = sub i64 %t116, 0
  %t119 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t117, 1
  store { i64, ptr } %t120, ptr %l7, !tbaa !27
  %t122 = load i64, ptr %l1, !tbaa !24
  %t124 = call ptr @__olang_region_make_part(ptr %v0)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l59, !tbaa !24
  store i64 %t122, ptr %l60, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t129 = load i64, ptr %l60, !tbaa !24
  %t130 = extractvalue { i64, ptr } %t127, 0
  %t131 = mul i64 %t130, 8
  %t132 = mul i64 %t129, 8
  %t133 = extractvalue { i64, ptr } %t127, 1
  %t134 = call ptr @__olang_grow_in_place(ptr %t133, i64 %t131, i64 %t132, i64 %t129)
  %t135 = icmp ne ptr %t134, null
  %t136 = select i1 %t135, i64 %t129, i64 0
  %t137 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t134, 1
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 0
  %t142 = icmp ne i64 %t140, 0
  br i1 %t142, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2fb9f75078a6e9dc_888656e0ac4b2310)
  unreachable
bb22:
  %t144 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t144, ptr %l61, !tbaa !27
  br label %bb24
bb23:
  %t145 = load i64, ptr %l60, !tbaa !24
  %t146 = mul i64 %t145, 8
  %t147 = load i64, ptr %l59
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l61, !tbaa !27
  store i64 0, ptr %l66, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  %t152 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 0
  %t155 = icmp eq i64 %t153, 0
  br i1 %t155, label %bb31, label %bb32
bb25:
  %t157 = load i64, ptr %l9, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t163 = icmp slt i64 %t157, %t160
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  br label %bb28
bb28:
  %t167 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t167, ptr %l72, !tbaa !27
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i64, ptr %t171, i64 %t168
  %t173 = load i64, ptr %t172, !tbaa !34
  %t175 = load i64, ptr %l66, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i64, ptr %t177, i64 %t175
  store i64 %t173, ptr %t178, !tbaa !34
  %t179 = load i64, ptr %l66, !tbaa !24
  %t180 = add i64 %t179, 1
  store i64 %t180, ptr %l66, !tbaa !24
  br label %bb29
bb29:
  %t181 = load i64, ptr %l9, !tbaa !24
  %t184 = add i64 %t181, 1
  store i64 %t184, ptr %l9, !tbaa !24
  br label %bb25
bb30:
  br label %bb24
bb31:
  store { i64, ptr } zeroinitializer, ptr %l61, !tbaa !27
  br label %bb32
bb32:
  %t186 = load i64, ptr %l59
  %t187 = inttoptr i64 %t186 to ptr
  %t188 = load { i64, ptr }, ptr %l61
  %t189 = extractvalue { i64, ptr } %t188, 1
  %t190 = call ptr @__olang_region_or(ptr %t189, ptr null)
  %t191 = icmp ne ptr %t190, null
  %t192 = select i1 %t191, ptr %t190, ptr null
  call void @__olang_region_settle_in(ptr %t187, ptr %t192)
  %t193 = load ptr, ptr %l49, !tbaa !29
  %t194 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t193, i32 0, i32 1
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l80, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t197 = load ptr, ptr %l49, !tbaa !29
  %t198 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t197, i32 0, i32 1
  store { i64, ptr } %t196, ptr %t198, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l80
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  call void @__olang_region_release_part(ptr %t201, i64 %t200)
  store { i64, ptr } zeroinitializer, ptr %l80
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e_2eroom_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_866d9bbb4f0cfa78_ce909751b54c5fac)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_866d9bbb4f0cfa78_ce909751b54c5fac)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/effects:Facts", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 96
  %t93 = mul i64 %t90, 96
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_866d9bbb4f0cfa78_ce909751b54c5fac)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 96
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/effects:Facts", ptr %t132, i64 %t129
  %t134 = load %"compiler/effects:Facts", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/effects:Facts", ptr %t138, i64 %t136
  store %"compiler/effects:Facts" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_2eroom_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l50 = alloca i64
  %l56 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_1bd0ad365a8e38e_b00e754070167a92)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_1bd0ad365a8e38e_b00e754070167a92)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/effects:link", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  store i64 %t83, ptr %l44, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t90 = load i64, ptr %l44, !tbaa !24
  %t91 = extractvalue { i64, ptr } %t88, 0
  %t92 = mul i64 %t91, 24
  %t93 = mul i64 %t90, 24
  %t94 = extractvalue { i64, ptr } %t88, 1
  %t95 = call ptr @__olang_grow_in_place(ptr %t94, i64 %t92, i64 %t93, i64 %t90)
  %t96 = icmp ne ptr %t95, null
  %t97 = select i1 %t96, i64 %t90, i64 0
  %t98 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t95, 1
  store { i64, ptr } %t99, ptr %l47, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t103 = icmp ne i64 %t101, 0
  br i1 %t103, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_1bd0ad365a8e38e_b00e754070167a92)
  unreachable
bb19:
  %t105 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t105, ptr %l45, !tbaa !27
  br label %bb21
bb20:
  %t106 = load i64, ptr %l44, !tbaa !24
  %t107 = mul i64 %t106, 24
  %t108 = load i64, ptr %l43
  %t109 = inttoptr i64 %t108 to ptr
  %t110 = call ptr @__olang_held_alloc(ptr %t109, i64 %t107)
  %t111 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l45, !tbaa !27
  store i64 0, ptr %l50, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  %t113 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t116 = icmp eq i64 %t114, 0
  br i1 %t116, label %bb28, label %bb29
bb22:
  %t118 = load i64, ptr %l6, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t124 = icmp slt i64 %t118, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t128 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t128, ptr %l56, !tbaa !27
  %t129 = load i64, ptr %l6, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/effects:link", ptr %t132, i64 %t129
  %t134 = load %"compiler/effects:link", ptr %t133
  %t136 = load i64, ptr %l50, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/effects:link", ptr %t138, i64 %t136
  store %"compiler/effects:link" %t134, ptr %t139
  %t140 = load i64, ptr %l50, !tbaa !24
  %t141 = add i64 %t140, 1
  store i64 %t141, ptr %l50, !tbaa !24
  br label %bb26
bb26:
  %t142 = load i64, ptr %l6, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l6, !tbaa !24
  br label %bb22
bb27:
  br label %bb21
bb28:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb29
bb29:
  %t147 = load i64, ptr %l43
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = load { i64, ptr }, ptr %l45
  %t150 = extractvalue { i64, ptr } %t149, 1
  %t151 = call ptr @__olang_region_or(ptr %t150, ptr null)
  %t152 = icmp ne ptr %t151, null
  %t153 = select i1 %t152, ptr %t151, ptr null
  call void @__olang_region_settle_in(ptr %t148, ptr %t153)
  %t154 = load ptr, ptr %l33, !tbaa !29
  %t155 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t154, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l64, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t158 = load ptr, ptr %l33, !tbaa !29
  %t159 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t158, i32 0, i32 0
  store { i64, ptr } %t157, ptr %t159, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l64
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  call void @__olang_region_release_part(ptr %t162, i64 %t161)
  store { i64, ptr } zeroinitializer, ptr %l64
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fmap_3aMap_3cI64_2c_20B_H15a299a0cdd99bdc22e63502e715a10d(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_3ff008295ed8ce46_87da870ade3bcf92)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_3ff008295ed8ce46_87da870ade3bcf92)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  %t89 = mul i64 %t83, 72
  %t90 = load i64, ptr %l43
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %t91, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_3ff008295ed8ce46_87da870ade3bcf92)
  unreachable
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t95, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l52, !tbaa !27
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t109, i64 %t106
  %t111 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t110
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %t110
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t115, i64 %t113
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t111, ptr %t116
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t124 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb26
bb26:
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l45
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  %t136 = load ptr, ptr %l33, !tbaa !29
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l60, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t140 = load ptr, ptr %l33, !tbaa !29
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l60
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  call void @__olang_region_release_part(ptr %t144, i64 %t143)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2_H7657b8c78f167626aa1535ac93faf2ee(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  store { i64, ptr } %t56, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5213a0f1e2c931b9_35ec4be5ee832025)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5213a0f1e2c931b9_35ec4be5ee832025)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t85 = call ptr @__olang_region_make_part(ptr %v0)
  %t86 = ptrtoint ptr %t85 to i64
  store i64 %t86, ptr %l43, !tbaa !24
  %t89 = mul i64 %t83, 32
  %t90 = load i64, ptr %l43
  %t91 = inttoptr i64 %t90 to ptr
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %t91, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_5213a0f1e2c931b9_35ec4be5ee832025)
  unreachable
bb19:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t101 = icmp slt i64 %t95, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t105 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t105, ptr %l52, !tbaa !27
  %t106 = load i64, ptr %l6, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t109, i64 %t106
  %t111 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %t110
  %t113 = load i64, ptr %l46, !tbaa !24
  %t114 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t115, i64 %t113
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t111, ptr %t116
  %t117 = load i64, ptr %l46, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l46, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l6, !tbaa !24
  %t122 = add i64 %t119, 1
  store i64 %t122, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t124 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t124, 0
  %t127 = icmp eq i64 %t125, 0
  br i1 %t127, label %bb25, label %bb26
bb25:
  store { i64, ptr } zeroinitializer, ptr %l45, !tbaa !27
  br label %bb26
bb26:
  %t129 = load i64, ptr %l43
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = load { i64, ptr }, ptr %l45
  %t132 = extractvalue { i64, ptr } %t131, 1
  %t133 = call ptr @__olang_region_or(ptr %t132, ptr null)
  %t134 = icmp ne ptr %t133, null
  %t135 = select i1 %t134, ptr %t133, ptr null
  call void @__olang_region_settle_in(ptr %t130, ptr %t135)
  %t136 = load ptr, ptr %l33, !tbaa !29
  %t137 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t136, i32 0, i32 0
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l60, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t140 = load ptr, ptr %l33, !tbaa !29
  %t141 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t140, i32 0, i32 0
  store { i64, ptr } %t139, ptr %t141, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l61, !tbaa !24
  store i64 0, ptr %l62, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l62, !tbaa !24
  %t145 = load i64, ptr %l61, !tbaa !24
  %t146 = icmp slt i64 %t144, %t145
  br i1 %t146, label %bb28, label %bb29
bb28:
  %t148 = load i64, ptr %l62, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t150, i64 %t148
  %t152 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t151, i32 0, i32 0
  %t153 = load { i64, ptr }, ptr %t152
  %t154 = extractvalue { i64, ptr } %t153, 0
  %t155 = extractvalue { i64, ptr } %t153, 1
  call void @__olang_region_release_part(ptr %t155, i64 %t154)
  store { i64, ptr } zeroinitializer, ptr %t152
  %t156 = load i64, ptr %l62, !tbaa !24
  %t157 = add i64 %t156, 1
  store i64 %t157, ptr %l62, !tbaa !24
  br label %bb27
bb29:
  %t158 = load { i64, ptr }, ptr %l60
  %t159 = extractvalue { i64, ptr } %t158, 0
  %t160 = extractvalue { i64, ptr } %t158, 1
  call void @__olang_region_release_part(ptr %t160, i64 %t159)
  store { i64, ptr } zeroinitializer, ptr %l60
  br label %ret
ret:
  ret void
}

declare ptr @__olang_region_make_part(ptr) noinline
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_release_part(ptr, i64) noinline
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3agiven_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare ptr @__olang_region_make(ptr) noinline
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afslot_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afslot_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare ptr @__olang_grow_in_place(ptr, i64, i64, i64) noinline
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3afpath_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afpath_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3agiven_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:given"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 80
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:given", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %t15)
  store %"compiler/effects:given" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:given", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:given", ptr %t22, i64 %t20
  store %"compiler/effects:given" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afslot_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:fslot"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 48
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:fslot", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %v0, ptr %t15)
  store %"compiler/effects:fslot" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:fslot", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:fslot", ptr %t22, i64 %t20
  store %"compiler/effects:fslot" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2emir_2eHelperKind_2eCopy_2eArray_3ccompiler_2feffects_3afpath_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"compiler/effects:fpath"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 40
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/effects:fpath", ptr %t14, i64 %t12
  %t17 = call %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %v0, ptr %t15)
  store %"compiler/effects:fpath" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"compiler/effects:fpath", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/effects:fpath", ptr %t22, i64 %t20
  store %"compiler/effects:fpath" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr %"compiler/effects:given" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3agiven(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:given"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:given"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:given", ptr %a0
  store %"compiler/effects:given" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:given", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:given", ptr %l1
  store %"compiler/effects:given" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:given", ptr %rv
  ret %"compiler/effects:given" %rr
}

define linkonce_odr %"compiler/effects:fslot" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afslot(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fslot"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fslot"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fslot", ptr %a0
  store %"compiler/effects:fslot" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fslot", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:fslot", ptr %l1
  store %"compiler/effects:fslot" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fslot", ptr %rv
  ret %"compiler/effects:fslot" %rr
}

define linkonce_odr %"compiler/effects:fpath" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2feffects_3afpath(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:fpath"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/effects:fpath"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/effects:fpath", ptr %a0
  store %"compiler/effects:fpath" %t2, ptr %l1
  %t3 = getelementptr %"compiler/effects:fpath", ptr %l1, i32 0, i32 0
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/effects:fpath", ptr %l1, i32 0, i32 0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/effects:fpath", ptr %l1
  store %"compiler/effects:fpath" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/effects:fpath", ptr %rv
  ret %"compiler/effects:fpath" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@olang_loc_d304065e85e07eb7_978c4f606565fc53 = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Array_3cI64_3e_3e_2ebucketOf_3cI64_2c_20Array_3cI64_3e_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H5ff29b28d6a4226c0ecc80ba4d487bea(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_Hbbe9f70b7f65eade62601b1ea8bf7ab6(ptr %v0, ptr %a0)
@olang_loc_28c32a1869498861_1488d00961e0923d = external constant [0 x i8]
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_He77e3d6ad35c8a6c8d6f6b9d4d267ded(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3)
@olang_loc_7c5a221fc21546b6_8cd0583a02f1cc52 = external constant [0 x i8]
@olang_loc_7c6b183b1a98ab13_d6bf4b540853c4f = external constant [0 x i8]
@olang_loc_4b410134ecf81b51_3b1651859bccdb6d = external constant [0 x i8]
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H0ad23e78b2b593286f94a0de5701989f(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_H5654dfb8722cc0004754aed78f118291(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a3)
@olang_loc_ae67406c9931ff49_4b4459f87ee3c0ed = external constant [0 x i8]
@olang_loc_2fb9f75078a6e9dc_888656e0ac4b2310 = external constant [0 x i8]
@olang_loc_866d9bbb4f0cfa78_ce909751b54c5fac = external constant [0 x i8]
@olang_loc_1bd0ad365a8e38e_b00e754070167a92 = external constant [0 x i8]
@olang_loc_3ff008295ed8ce46_87da870ade3bcf92 = external constant [0 x i8]
@olang_loc_5213a0f1e2c931b9_35ec4be5ee832025 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
