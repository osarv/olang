; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_fce9662fae26a531_795e11cf8665bbad = weak_odr constant [54 x i8] c"std/prelude/vec.olang:148: slice bounds out of range\0A\00"
