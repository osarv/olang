; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_a0a676283fd88de_d08f829f5e086d52 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:61: slice bounds out of range\0A\00"
@olang_loc_fce9662fae26a531_795e11cf8665bbad = weak_odr constant [54 x i8] c"std/prelude/vec.olang:169: slice bounds out of range\0A\00"
