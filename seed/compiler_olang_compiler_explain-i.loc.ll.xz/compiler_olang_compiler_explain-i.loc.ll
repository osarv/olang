; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_ae21aa20b4d08a4_7974f82e99efdaf8 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:199: slice bounds out of range\0A\00"
