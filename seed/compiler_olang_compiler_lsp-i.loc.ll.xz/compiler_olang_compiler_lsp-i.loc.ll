; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_b5b019bde42e8960_96f7d378ff8c498c = weak_odr constant [40 x i8] c"std/json.olang:77: unreachable reached\0A\00"
@olang_loc_d41c611dfe842a23_3e2660b9c041b8e7 = weak_odr constant [40 x i8] c"std/json.olang:83: unreachable reached\0A\00"
