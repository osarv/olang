; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_6aedc85f0c11dafa_37647e3d146f545e = weak_odr constant [48 x i8] c"std/prelude/vec.olang:213: unreachable reached\0A\00"
@olang_loc_b6be7fe380d194c2_f52914772eb1dbde = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: slice bounds out of range\0A\00"
