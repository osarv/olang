; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_6aedc85f0c11dafa_37647e3d146f545e = weak_odr constant [48 x i8] c"std/prelude/vec.olang:215: unreachable reached\0A\00"
@olang_loc_ab96e50251c25b2a_50816d3318f348be = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
