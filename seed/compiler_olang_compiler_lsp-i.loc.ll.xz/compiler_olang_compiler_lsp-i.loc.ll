; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_6aedc85f0c11dafa_37647e3d146f545e = weak_odr constant [48 x i8] c"std/prelude/vec.olang:215: unreachable reached\0A\00"
@olang_loc_9932c5fcf7f9206d_786a753056557a99 = weak_odr constant [55 x i8] c"std/prelude/list.olang:110: array length out of range\0A\00"
@olang_loc_a91071e6b75f776e_9e937877aeb9211a = weak_odr constant [55 x i8] c"std/prelude/list.olang:108: array length out of range\0A\00"
@olang_loc_c5cd80569b3876e3_bf4a49248ce8f1ef = weak_odr constant [55 x i8] c"std/prelude/list.olang:103: array length out of range\0A\00"
@olang_loc_ea126fc19927bb40_3f432d984770bb8c = weak_odr constant [55 x i8] c"std/prelude/list.olang:114: array length out of range\0A\00"
