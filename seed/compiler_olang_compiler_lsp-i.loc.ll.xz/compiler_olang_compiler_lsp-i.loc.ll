; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_6aedc85f0c11dafa_37647e3d146f545e = weak_odr constant [48 x i8] c"std/prelude/vec.olang:213: unreachable reached\0A\00"
@olang_loc_8b7d73b05b3bfe0e_51c60bf7b995a2ba = weak_odr constant [53 x i8] c"std/prelude/vec.olang:53: slice bounds out of range\0A\00"
@olang_loc_b5b019bde42e8960_96f7d378ff8c498c = weak_odr constant [40 x i8] c"std/json.olang:86: unreachable reached\0A\00"
@olang_loc_d41c611dfe842a23_3e2660b9c041b8e7 = weak_odr constant [40 x i8] c"std/json.olang:92: unreachable reached\0A\00"
