; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/mir:Fn" = type { { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/eval:cfn" = type { i64, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, { i64, ptr } }
%"compiler/eval:Machine" = type { ptr, i32, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i64, i64, { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/source:Span", i32 }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/eval:Ptr" = type { i64, i64 }
%"compiler/eval:global" = type { i64, i1, i64, i64, i64, i1, i1 }
%"compiler/eval:gkey" = type { i64, i32 }
%"compiler/eval:alloc" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i1 }
%"compiler/mir:Local" = type { i32, %"compiler/source:Span", i32, i32, { i64, [1 x i64] } }
%"compiler/eval:frame" = type { i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i64, i64, i1, i64, i32, i32 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/mir:Lvalue" = type { { i64, [2 x i64] }, %"compiler/mir:Range" }
%"compiler/mir:Range" = type { i32, i32 }
%"compiler/eval:scope" = type { i64, i1, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i64, i1, i64, i64 }
%"compiler/eval:task" = type { i64, i64, i64, i64 }
%"compiler/mir:Task" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/source:Span", %"compiler/mir:Range" }
%"compiler/eval:genRec" = type { i64, i64, %"compiler/eval:frame", i64, i64, i64, i64 }
%"compiler/mir:BasicBlock" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [8 x i64] } }
%"compiler/mir:ScopeInfo" = type { i32, i32, i32, %"compiler/source:Span", i32 }
%"compiler/eval:reg" = type { i64, i64, i64, i64, i64, i64, i64, i64 }
%"compiler/mir:Call" = type { { i64, [7 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range", %"compiler/mir:Lvalue", i1, i32, i32, i32 }
%"compiler/eval:Image" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/eval:dkey" = type { i64, i32, i32, i32, i32, i64 }
define dso_local void @compiler_2feval_2eFloatOps_2einit() #0 {
entry:
  %l4 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t1 = mul i64 4, 4
  %t2 = load ptr, ptr @__olang_prog_scope
  %t3 = call ptr @__olang_scope_alloc_zeroed(ptr %t2, i64 %t1)
  %t4 = insertvalue { i64, ptr } undef, i64 4, 0
  %t5 = insertvalue { i64, ptr } %t4, ptr %t3, 1
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr i32, ptr %t8, i64 0
  store i32 3, ptr %t9
  %t11 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i32, ptr %t12, i64 1
  store i32 4, ptr %t13
  %t15 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i32, ptr %t16, i64 2
  store i32 5, ptr %t17
  %t19 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr i32, ptr %t20, i64 3
  store i32 6, ptr %t21
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t22, ptr @G_2ecompiler_2feval_2eFloatOps, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eInterpCrash_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t1 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t2 = extractvalue { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t3 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t4 = extractvalue { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t5 = add i64 %t2, %t4
  %t6 = load ptr, ptr @__olang_prog_scope
  %t7 = call ptr @__olang_scope_alloc(ptr %t6, i64 %t5)
  call void @olang_textcopy(ptr %t7, ptr %t1, i64 %t2)
  %t8 = getelementptr i8, ptr %t7, i64 %t2
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t7, 1
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = extractvalue { i64, ptr } %t10, 0
  %t14 = extractvalue { i64, ptr } %t10, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %t12, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr @G_2ecompiler_2feval_2eInterpCrash, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eNumNames_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x { i64, ptr }] }>, ptr @.d2, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eNumNames, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyChangeable_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 100, ptr getelementptr inbounds (<{ i64, [100 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyChangeable, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyClosed_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 53, ptr getelementptr inbounds (<{ i64, [53 x i8] }>, ptr @.d4, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyConvert_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d5, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyConvert, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyDepth_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d6, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyDepth, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyDestructor_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 61, ptr getelementptr inbounds (<{ i64, [61 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyDestructor, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyDivZero_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyDivZero, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyEnds_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyEnds, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyFfiFind_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d10, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyFfiFind, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyFfiPass_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 152, ptr getelementptr inbounds (<{ i64, [152 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyForeign_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 56, ptr getelementptr inbounds (<{ i64, [56 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyForeign, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyMemory_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 69, ptr getelementptr inbounds (<{ i64, [69 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyMemory, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyMutableGlobal_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyMutableGlobal, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNaNSignal_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 71, ptr getelementptr inbounds (<{ i64, [71 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNaNSignal, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNoBody_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNoClause_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNoClause, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNoValue_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNoValue, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyNull_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyNull, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyPayload_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 54, ptr getelementptr inbounds (<{ i64, [54 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyPayload, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyRunDepth_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 33, ptr getelementptr inbounds (<{ i64, [33 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyRunDepth, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhySteps_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 63, ptr getelementptr inbounds (<{ i64, [63 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhySteps, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eWhyWritesGlobalVar_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 72, ptr getelementptr inbounds (<{ i64, [72 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobalVar, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2eclassOf(i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = load i64, ptr %l2, !tbaa !24
  %t4 = shl i64 1, %t3
  %t8 = icmp slt i64 %t4, %a0
  %t10 = xor i1 %t8, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  br label %bb6
bb3:
  br label %bb4
bb4:
  %t12 = load i64, ptr %l1, !tbaa !24
  %t14 = add i64 %t12, 1
  store i64 %t14, ptr %l1, !tbaa !24
  br label %bb5
bb5:
  br label %bb1
bb6:
  %t16 = load i64, ptr %l1, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, [2 x i64] }
  %l11 = alloca i32
  %l14 = alloca i64
  %l23 = alloca %"compiler/mir:Fn"
  %l31 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca %"compiler/eval:cfn"
  %l37 = alloca %"compiler/eval:cfn"
  %l46 = alloca i64
  %l49 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca %"compiler/eval:cfn"
  %l76 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca %"compiler/eval:cfn"
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l88 = alloca i1
  %l95 = alloca { i64, ptr }
  %t24 = alloca %"compiler/mir:Fn", align 8
  %t50 = alloca %"compiler/eval:cfn", align 8
  %t60 = alloca i64
  %t149 = alloca %"compiler/eval:cfn", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 16
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eLen_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i64, ptr %l14, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 21
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/mir:Fn", ptr %t10, i32 0, i32 0
  %t13 = load { i64, [2 x i64] }, ptr %t12
  %t14 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %t9, { i64, [2 x i64] } %t13, i64 %t14)
  br label %bb2
bb2:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 16
  %t21 = load ptr, ptr %l1, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t21, i64 248, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %l23, i64 248, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2ePush_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %v1, ptr %t20, ptr %t24)
  br label %bb3
bb3:
  %t25 = load i64, ptr %l2, !tbaa !24
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t26, i32 0, i32 17
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t34 = icmp sge i64 %t25, %t31
  br i1 %t34, label %bb4, label %bb5
bb4:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/eval:Machine", ptr %t36, i32 0, i32 17
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l31, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t46 = mul i64 2, %t44
  store i64 %t46, ptr %l34, !tbaa !24
  call void @llvm.memset.p0.i64(ptr %l35, i8 0, i64 264, i1 false)
  %t47 = load i64, ptr %l34, !tbaa !24
  %t48 = icmp sgt i64 %t47, 0
  br i1 %t48, label %bb6, label %bb7
bb5:
  br label %bb25
bb6:
  call void @olang_2eHelperKind_2eZero_2ecompiler_2feval_3acfn(ptr %t50, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l37, ptr %t50, i64 264, i1 false)
  br label %bb8
bb7:
  %t51 = load i64, ptr %l34, !tbaa !24
  %t52 = icmp sge i64 %t51, 0
  br i1 %t52, label %bb9, label %bb10
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %l37, i64 264, i1 false)
  br label %bb7
bb9:
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = icmp sle i64 %t54, 34937015291116575
  br i1 %t55, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_8e30d4bcef98d937_821e6ec72834ca4b)
  unreachable
bb11:
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = mul i64 %t57, 264
  %t59 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t58)
  store i64 0, ptr %t60
  br label %fill.61
fill.61:
  %t64 = load i64, ptr %t60
  %t65 = icmp slt i64 %t64, %t57
  br i1 %t65, label %fillb.62, label %filld.63
fillb.62:
  %t66 = getelementptr %"compiler/eval:cfn", ptr %t59, i64 %t64
  call void @llvm.memmove.p0.p0.i64(ptr %t66, ptr %l35, i64 264, i1 false)
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %t60
  br label %fill.61
filld.63:
  %t68 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t59, 1
  %t71 = load ptr, ptr %l31, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 17
  store { i64, ptr } %t69, ptr %t72, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  store i64 %t75, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_8e30d4bcef98d937_821e6ec72834ca4b)
  unreachable
bb13:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb18
bb15:
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = load i64, ptr %l4, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l6, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l49, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb17
bb17:
  %t103 = load i64, ptr %l49, !tbaa !24
  store i64 %t103, ptr %l46, !tbaa !24
  br label %bb18
bb18:
  %t104 = load i64, ptr %l46, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t106 = load i64, ptr %l7, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t113 = load i64, ptr %l4, !tbaa !24
  %t114 = load i64, ptr %l8, !tbaa !24
  %t115 = load i64, ptr %l6, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l9, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/eval:Machine", ptr %t123, i32 0, i32 17
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  store { i64, ptr } %t126, ptr %l68, !tbaa !27
  %t127 = load i64, ptr %l9, !tbaa !24
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t128, ptr %l70, !tbaa !27
  %t129 = load i64, ptr %l9, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr %"compiler/eval:cfn", ptr %t132, i64 %t129
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t133, i64 264, i1 false)
  %t135 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr %"compiler/eval:cfn", ptr %t136, i64 %t127
  call void @llvm.memmove.p0.p0.i64(ptr %t137, ptr %l72, i64 264, i1 false)
  br label %bb23
bb23:
  %t138 = load i64, ptr %l8, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l8, !tbaa !24
  br label %bb19
bb24:
  br label %bb25
bb25:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/eval:Machine", ptr %t142, i32 0, i32 17
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l76, !tbaa !27
  %t146 = load i64, ptr %l2, !tbaa !24
  store i64 %t146, ptr %l77, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edecode(ptr %t149, ptr %v0, ptr %v1, ptr %v0, ptr %t147, ptr %t148)
  call void @llvm.memmove.p0.p0.i64(ptr %l80, ptr %t149, i64 264, i1 false)
  br label %bb26
bb26:
  %t152 = load i64, ptr %l77, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr %"compiler/eval:cfn", ptr %t154, i64 %t152
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %l80, i64 264, i1 false)
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/eval:Machine", ptr %t156, i32 0, i32 17
  %t159 = load { i64, ptr }, ptr %t158, !tbaa !27
  store { i64, ptr } %t159, ptr %l82, !tbaa !27
  %t160 = load i64, ptr %l2, !tbaa !24
  store i64 %t160, ptr %l83, !tbaa !24
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/eval:Machine", ptr %t161, i32 0, i32 15
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t166 = getelementptr %"compiler/mir:Fn", ptr %t164, i32 0, i32 0
  %t167 = load { i64, [2 x i64] }, ptr %t166
  %t170 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %t163, { i64, [2 x i64] } %t167)
  store i1 %t170, ptr %l88
  br label %bb27
bb27:
  %t171 = load i1, ptr %l88, !tbaa !21
  %t172 = load i64, ptr %l83, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr %"compiler/eval:cfn", ptr %t174, i64 %t172
  %t176 = getelementptr %"compiler/eval:cfn", ptr %t175, i32 0, i32 16
  store i1 %t171, ptr %t176, !tbaa !21
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr %"compiler/mir:Fn", ptr %t177, i32 0, i32 0
  %t180 = load { i64, [2 x i64] }, ptr %t179
  store { i64, [2 x i64] } %t180, ptr %l10
  %t182 = load { i64, [2 x i64] }, ptr %l10
  %t184 = extractvalue { i64, [2 x i64] } %t182, 0
  %t185 = icmp eq i64 %t184, 2
  br i1 %t185, label %bb28, label %bb29
bb28:
  %t187 = getelementptr { i64, [2 x i64] }, ptr %l10, i32 0, i32 1
  %t188 = getelementptr { i32, i32 }, ptr %t187, i32 0, i32 0
  %t189 = load i32, ptr %t188
  store i32 %t189, ptr %l11
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/eval:Machine", ptr %t191, i32 0, i32 17
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  store { i64, ptr } %t194, ptr %l95, !tbaa !27
  %t195 = load i64, ptr %l2, !tbaa !24
  %t196 = load i32, ptr %l11
  %t198 = trunc i64 1 to i32
  %t199 = icmp eq i32 %t196, %t198
  %t202 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr %"compiler/eval:cfn", ptr %t203, i64 %t195
  %t205 = getelementptr %"compiler/eval:cfn", ptr %t204, i32 0, i32 17
  store i1 %t199, ptr %t205, !tbaa !21
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_8d25544d0bd70291_3d464b777e1774ad)
  unreachable
bb36:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefineGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, i1 %a4, { i64, [2 x i64] } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca %"compiler/eval:global"
  %l7 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i1
  %l11 = alloca %"compiler/eval:global"
  %l17 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca %"compiler/eval:Ptr"
  %l28 = alloca ptr
  %l31 = alloca %"compiler/eval:gkey"
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = call %"compiler/eval:global" @compiler_2feval_3aglobal_2ector(ptr %s0)
  store %"compiler/eval:global" %t6, ptr %l11
  br label %bb2
bb2:
  %t7 = load %"compiler/eval:global", ptr %l11
  store %"compiler/eval:global" %t7, ptr %l6
  %t8 = load i32, ptr %l3, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t12 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 0
  store i64 %t10, ptr %t12, !tbaa !24
  %t15 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 1
  store i1 %a4, ptr %t15, !tbaa !21
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t20 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodeIndex(ptr %v0, ptr %t16, { i64, [2 x i64] } %a5)
  store i64 %t20, ptr %l17
  br label %bb3
bb3:
  %t21 = load i64, ptr %l17, !tbaa !24
  %t22 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 2
  store i64 %t21, ptr %t22, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t24, i32 %t25)
  store i64 %t28, ptr %l21
  br label %bb4
bb4:
  %t29 = load i64, ptr @G_2ecompiler_2feval_2eaGlobal, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 61
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load i64, ptr %l21, !tbaa !24
  %t38 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t34, i64 %t35, i64 %t29, i64 %t33)
  store %"compiler/eval:Ptr" %t38, ptr %l25
  br label %bb5
bb5:
  %t39 = load %"compiler/eval:Ptr", ptr %l25
  store %"compiler/eval:Ptr" %t39, ptr %l7
  %t40 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t43 = getelementptr %"compiler/eval:global", ptr %l6, i32 0, i32 3
  store i64 %t41, ptr %t43, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 34
  store ptr %t46, ptr %l28, !tbaa !29
  %t51 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s0, i64 %a1, i32 %a2)
  store %"compiler/eval:gkey" %t51, ptr %l31
  br label %bb6
bb6:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 33
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t54)
  store i64 %t56, ptr %l34
  br label %bb7
bb7:
  %t57 = load ptr, ptr %l28, !tbaa !29
  %t58 = load %"compiler/eval:gkey", ptr %l31
  %t59 = load i64, ptr %l34, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eP_Hdbb1ec214f67f51e9ea8789b3bf075dc(ptr %v0, ptr %t57, %"compiler/eval:gkey" %t58, i64 %t59)
  br label %bb8
bb8:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 40
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l36, !tbaa !27
  %t64 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t65 = load i64, ptr %t64, !tbaa !24
  %t66 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t69 = and i64 %t65, %t66
  store i64 %t69, ptr %l39, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 33
  %t74 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t72)
  store i64 %t74, ptr %l42
  br label %bb9
bb9:
  %t75 = load i64, ptr %l42, !tbaa !24
  %t76 = load i64, ptr %l39, !tbaa !24
  %t77 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr %"compiler/eval:alloc", ptr %t78, i64 %t76
  %t80 = getelementptr %"compiler/eval:alloc", ptr %t79, i32 0, i32 8
  store i64 %t75, ptr %t80, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Machine", ptr %t81, i32 0, i32 33
  %t84 = load %"compiler/eval:global", ptr %l6
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ePush_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t83, %"compiler/eval:global" %t84)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [2 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"compiler/mir:Fn"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l38 = alloca i1
  %l40 = alloca { i64, ptr }
  %l59 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i32
  %l72 = alloca %"compiler/mir:Fn"
  %l84 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i64
  %l115 = alloca i64
  %l117 = alloca i64
  %l121 = alloca i32
  %l125 = alloca %"compiler/mir:Local"
  %l127 = alloca ptr
  %l131 = alloca %"compiler/eval:Ptr"
  %l134 = alloca i64
  %l135 = alloca { i64, ptr }
  %l141 = alloca i64
  %l145 = alloca i64
  %l148 = alloca i64
  %l167 = alloca { i64, ptr }
  %l169 = alloca { i64, ptr }
  %rv = alloca { i64, [5 x i64] }
  %t8 = alloca { i64, [5 x i64] }, align 8
  %t114 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 13
  store i1 false, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 14
  store i1 false, ptr %t6, !tbaa !21
  %t7 = load ptr, ptr %l0, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [5 x i64] }, ptr %t8, i32 0, i32 0
  store i64 0, ptr %t9
  %t10 = load { i64, [5 x i64] }, ptr %t8
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 12
  store { i64, [5 x i64] } %t10, ptr %t13
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 6
  store i64 0, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 75
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t19)
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 78
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t23)
  br label %bb2
bb2:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 77
  store i64 0, ptr %t27, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 10
  %t31 = getelementptr %"compiler/eval:Ptr", ptr %t30, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp ne i64 %t32, 0
  br i1 %t34, label %bb3, label %bb4
bb3:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/eval:Machine", ptr %t36, i32 0, i32 40
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l40, !tbaa !27
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:Machine", ptr %t40, i32 0, i32 10
  %t43 = getelementptr %"compiler/eval:Ptr", ptr %t42, i32 0, i32 0
  %t44 = load i64, ptr %t43, !tbaa !24
  %t45 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t48 = and i64 %t44, %t45
  %t50 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"compiler/eval:alloc", ptr %t51, i64 %t48
  %t53 = getelementptr %"compiler/eval:alloc", ptr %t52, i32 0, i32 4
  %t54 = load i64, ptr %t53, !tbaa !24
  %t55 = load i64, ptr @G_2ecompiler_2feval_2eaFree, !tbaa !24
  %t58 = icmp ne i64 %t54, %t55
  store i1 %t58, ptr %l38, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb5
bb5:
  %t60 = load i1, ptr %l38, !tbaa !21
  br i1 %t60, label %bb6, label %bb7
bb6:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 10
  %t65 = getelementptr %"compiler/eval:Ptr", ptr %t64, i32 0, i32 0
  %t66 = load i64, ptr %t65, !tbaa !24
  %t67 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t70 = and i64 %t66, %t67
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t61, i64 %t70)
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t73 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t75 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Machine", ptr %t77, i32 0, i32 10
  store %"compiler/eval:Ptr" %t73, ptr %t81
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t82, i32 0, i32 11
  store i32 %t75, ptr %t86, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 21
  %t93 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t89, { i64, [2 x i64] } %a1)
  %t94 = extractvalue { i32, i64 } %t93, 1
  %t95 = extractvalue { i32, i64 } %t93, 0
  store i32 %t95, ptr %l64
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb11, label %ok.97, !prof !99
ok.97:
  store i64 %t94, ptr %l63
  br label %bb10
bb10:
  %t98 = load i64, ptr %l63, !tbaa !24
  store i64 %t98, ptr %l59, !tbaa !24
  br label %bb14
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t101 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t101, ptr %t99, { i64, ptr } %t100)
  br label %bb13
bb13:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/eval:Machine", ptr %t104, i32 0, i32 12
  %t107 = load { i64, [5 x i64] }, ptr %t106
  store { i64, [5 x i64] } %t107, ptr %rv
  br label %ret
bb14:
  %t109 = load i64, ptr %l59, !tbaa !24
  store i64 %t109, ptr %l5, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/eval:Machine", ptr %t110, i32 0, i32 16
  %t113 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t114, ptr %v0, ptr %v0, ptr %t112, i64 %t113)
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t114, i64 248, i1 false)
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l72, i64 248, i1 false)
  %t117 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 2
  %t118 = load i64, ptr %t117, !tbaa !24
  %t120 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 3
  %t121 = load %"compiler/source:Span", ptr %t120
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/eval:Machine", ptr %t123, i32 0, i32 69
  store i64 %t118, ptr %t127, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/eval:Machine", ptr %t128, i32 0, i32 70
  store %"compiler/source:Span" %t121, ptr %t132
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 50
  %t136 = load i64, ptr %t135, !tbaa !24
  store i64 %t136, ptr %l9, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load i64, ptr %l5, !tbaa !24
  %t140 = load i64, ptr @G_2ecompiler_2feval_2erRequest, !tbaa !24
  %t144 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t138, i64 %t139, i64 %t140, i64 0)
  store i64 %t144, ptr %l84
  br label %bb16
bb16:
  %t145 = load i64, ptr %l84, !tbaa !24
  store i64 %t145, ptr %l10, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t148 = icmp slt i64 %t146, 0
  br i1 %t148, label %bb17, label %bb18
bb17:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/eval:Machine", ptr %t150, i32 0, i32 12
  %t153 = load { i64, [5 x i64] }, ptr %t152
  store { i64, [5 x i64] } %t153, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  store i64 0, ptr %l11, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  store i64 %t157, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t159 = load i64, ptr %l12, !tbaa !24
  %t160 = load i64, ptr %l11, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb20, label %bb21
bb20:
  %t165 = load i64, ptr %l13, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb25
bb22:
  %t169 = load i64, ptr %l12, !tbaa !24
  %t170 = load i64, ptr %l11, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l13, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l97, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb24
bb24:
  %t185 = load i64, ptr %l97, !tbaa !24
  store i64 %t185, ptr %l94, !tbaa !24
  br label %bb25
bb25:
  %t186 = load i64, ptr %l94, !tbaa !24
  store i64 %t186, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb26
bb26:
  %t187 = load i64, ptr %l15, !tbaa !24
  %t188 = load i64, ptr %l14, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb27, label %bb28
bb27:
  br label %bb40
bb28:
  br label %bb29
bb29:
  %t195 = load i64, ptr %l11, !tbaa !24
  %t196 = load i64, ptr %l15, !tbaa !24
  %t197 = load i64, ptr %l13, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l16, !tbaa !24
  %t205 = load i64, ptr %l16, !tbaa !24
  store i64 %t205, ptr %l115, !tbaa !24
  %t206 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 4
  %t208 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t206)
  store i64 %t208, ptr %l117
  br label %bb30
bb30:
  %t209 = load i64, ptr %l115, !tbaa !24
  %t210 = load i64, ptr %l117, !tbaa !24
  %t211 = icmp slt i64 %t209, %t210
  br i1 %t211, label %bb31, label %bb32
bb31:
  %t213 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 4
  %t214 = load i64, ptr %l16, !tbaa !24
  %t217 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t213, i64 %t214)
  store i32 %t217, ptr %l121
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t218 = load i32, ptr %l121, !tbaa !23
  store i32 %t218, ptr %l17, !tbaa !23
  %t219 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 7
  %t220 = load i32, ptr %l17, !tbaa !23
  %t222 = sext i32 %t220 to i64
  %t225 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t219, i64 %t222)
  store %"compiler/mir:Local" %t225, ptr %l125
  br label %bb34
bb34:
  %t226 = getelementptr %"compiler/mir:Local", ptr %l125, i32 0, i32 2
  %t227 = load i32, ptr %t226, !tbaa !23
  store i32 %t227, ptr %l18, !tbaa !23
  %t229 = load ptr, ptr %l0, !tbaa !29
  store ptr %t229, ptr %l127, !tbaa !29
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t231 = load i64, ptr %l10, !tbaa !24
  %t232 = load i32, ptr %l17, !tbaa !23
  %t236 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t230, i64 %t231, i32 %t232)
  store %"compiler/eval:Ptr" %t236, ptr %l131
  br label %bb35
bb35:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i32, ptr %l18, !tbaa !23
  %t241 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t237, i32 %t238)
  store i64 %t241, ptr %l134
  br label %bb36
bb36:
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t242, ptr %l135, !tbaa !27
  %t243 = load i64, ptr %l16, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr i64, ptr %t246, i64 %t243
  %t248 = load i64, ptr %t247, !tbaa !34
  %t249 = load ptr, ptr %l127, !tbaa !29
  %t250 = load %"compiler/eval:Ptr", ptr %l131
  %t251 = load i64, ptr %l134, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t249, %"compiler/eval:Ptr" %t250, i64 %t251, i64 %t248)
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t253 = load i64, ptr %l15, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l15, !tbaa !24
  br label %bb26
bb40:
  store i64 0, ptr %l19, !tbaa !24
  %t257 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 6
  %t259 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t257)
  store i64 %t259, ptr %l141
  br label %bb41
bb41:
  %t260 = load i64, ptr %l141, !tbaa !24
  store i64 %t260, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t261 = load i64, ptr %l20, !tbaa !24
  %t262 = load i64, ptr %l19, !tbaa !24
  %t265 = icmp sgt i64 %t261, %t262
  br i1 %t265, label %bb42, label %bb43
bb42:
  %t267 = load i64, ptr %l21, !tbaa !24
  %t269 = icmp sgt i64 %t267, 0
  br i1 %t269, label %bb44, label %bb45
bb43:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb47
bb44:
  %t271 = load i64, ptr %l20, !tbaa !24
  %t272 = load i64, ptr %l19, !tbaa !24
  %t275 = sub i64 %t271, %t272
  %t276 = load i64, ptr %l21, !tbaa !24
  %t279 = add i64 %t275, %t276
  %t281 = sub i64 %t279, 1
  %t282 = load i64, ptr %l21, !tbaa !24
  %t285 = sdiv i64 %t281, %t282
  store i64 %t285, ptr %l148, !tbaa !24
  br label %bb46
bb45:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb46
bb46:
  %t287 = load i64, ptr %l148, !tbaa !24
  store i64 %t287, ptr %l145, !tbaa !24
  br label %bb47
bb47:
  %t288 = load i64, ptr %l145, !tbaa !24
  store i64 %t288, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb48
bb48:
  %t289 = load i64, ptr %l23, !tbaa !24
  %t290 = load i64, ptr %l22, !tbaa !24
  %t293 = icmp slt i64 %t289, %t290
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t297 = load i64, ptr %l19, !tbaa !24
  %t298 = load i64, ptr %l23, !tbaa !24
  %t299 = load i64, ptr %l21, !tbaa !24
  %t302 = mul i64 %t298, %t299
  %t305 = add i64 %t297, %t302
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/eval:Machine", ptr %t307, i32 0, i32 51
  %t310 = load { i64, ptr }, ptr %t309, !tbaa !27
  store { i64, ptr } %t310, ptr %l167, !tbaa !27
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/eval:Machine", ptr %t311, i32 0, i32 49
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  store { i64, ptr } %t314, ptr %l169, !tbaa !27
  %t315 = load i64, ptr %l10, !tbaa !24
  %t317 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr %"compiler/eval:frame", ptr %t318, i64 %t315
  %t320 = getelementptr %"compiler/eval:frame", ptr %t319, i32 0, i32 5
  %t321 = load i64, ptr %t320, !tbaa !24
  %t325 = add i64 %t321, %t305
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/eval:Machine", ptr %t326, i32 0, i32 61
  %t329 = load i64, ptr %t328, !tbaa !24
  %t332 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !27
  %t334 = getelementptr i64, ptr %t333, i64 %t325
  store i64 %t329, ptr %t334, !tbaa !34
  br label %bb52
bb52:
  %t335 = load i64, ptr %l23, !tbaa !24
  %t337 = add i64 %t335, 1
  store i64 %t337, ptr %l23, !tbaa !24
  br label %bb48
bb53:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t339, i64 %t340)
  br label %bb54
bb54:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %t343, i64 %t344)
  br label %bb55
bb55:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/eval:Machine", ptr %t347, i32 0, i32 12
  %t350 = load { i64, [5 x i64] }, ptr %t349
  store { i64, [5 x i64] } %t350, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eInt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  store %"compiler/eval:Ptr" %a1, ptr %l5
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l2, !tbaa !23
  %t8 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t4, i32 %t5)
  store i64 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"compiler/eval:Ptr", ptr %l5
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t9, %"compiler/eval:Ptr" %t10, i64 %t11)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i64, ptr %l9, !tbaa !24
  %t17 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t14, i64 %t15, i32 %t13)
  store i64 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i64, ptr %l11, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eMain(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca [0 x i64]
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %lp8 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l24 = alloca { i64, [5 x i64] }
  %l35 = alloca { i64, [5 x i64] }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [5 x i64] }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [0 x i64] zeroinitializer, ptr %l3
  store { i64, ptr } %a1, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  store i64 %t6, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t12 = icmp slt i64 %t8, %t9
  %t14 = xor i1 %t12, true
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t16 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t16, ptr %l17, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i64 %t17
  %t22 = load { i64, [2 x i64] }, ptr %t21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t27 = insertvalue { i64, ptr } undef, i64 0, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %l3, 1
  %t32 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %v2, ptr %t24, { i64, [2 x i64] } %t22, { i64, ptr } %t28)
  store { i64, [5 x i64] } %t32, ptr %l24
  br label %bb5
bb5:
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t33, ptr %lp8
  %t34 = load { i64, [5 x i64] }, ptr %l24
  %t35 = load ptr, ptr %lp8
  store { i64, [5 x i64] } %t34, ptr %t35
  %t36 = load ptr, ptr %lp8
  %t37 = load { i64, [5 x i64] }, ptr %t36
  %t39 = extractvalue { i64, [5 x i64] } %t37, 0
  %t40 = icmp eq i64 %t39, 0
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb6, label %bb7
bb6:
  %t44 = load ptr, ptr %lp8
  %t45 = load { i64, [5 x i64] }, ptr %t44
  call void @__olang_scope_close(ptr %s0)
  store { i64, [5 x i64] } %t45, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t47 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l5, !tbaa !24
  br label %bb1
bb10:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t54 = insertvalue { i64, ptr } undef, i64 0, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %l3, 1
  %t59 = call { i64, [5 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2eEval(ptr %v0, ptr %s0, ptr %v2, ptr %t51, { i64, [2 x i64] } %a2, { i64, ptr } %t55)
  store { i64, [5 x i64] } %t59, ptr %l35
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load { i64, [5 x i64] }, ptr %l35
  store { i64, [5 x i64] } %t60, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [5 x i64] }, ptr %rv
  ret { i64, [5 x i64] } %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eRefAt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1) #0 {
entry:
  %l4 = alloca %"compiler/eval:Ptr"
  %rv = alloca %"compiler/eval:Ptr"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
  store %"compiler/eval:Ptr" %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load %"compiler/eval:Ptr", ptr %l4
  store %"compiler/eval:Ptr" %t6, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eText(ptr %v0, ptr %v1, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { %"compiler/eval:Ptr", i64 }
  %l4 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { %"compiler/eval:Ptr", i64 }
  %l19 = alloca %"std/prelude/text:StringBuilder"
  %l24 = alloca i64
  %l27 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l51 = alloca %"compiler/eval:Ptr"
  %l52 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1, %"compiler/eval:Ptr" %a1, i32 %a2)
  store { %"compiler/eval:Ptr", i64 } %t7, ptr %l16
  br label %bb1
bb1:
  %t8 = load { %"compiler/eval:Ptr", i64 }, ptr %l16
  store { %"compiler/eval:Ptr", i64 } %t8, ptr %l3
  %t9 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l3, i32 0, i32 0
  %t10 = load %"compiler/eval:Ptr", ptr %t9
  store %"compiler/eval:Ptr" %t10, ptr %l4
  %t12 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l3, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t15, ptr %l19
  br label %bb2
bb2:
  %t16 = load %"std/prelude/text:StringBuilder", ptr %l19
  store %"std/prelude/text:StringBuilder" %t16, ptr %l6
  store i64 0, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t19 = load i64, ptr %l8, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb3, label %bb4
bb3:
  %t25 = load i64, ptr %l9, !tbaa !24
  %t27 = icmp sgt i64 %t25, 0
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb8
bb5:
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = sub i64 %t29, %t30
  %t34 = load i64, ptr %l9, !tbaa !24
  %t37 = add i64 %t33, %t34
  %t39 = sub i64 %t37, 1
  %t40 = load i64, ptr %l9, !tbaa !24
  %t43 = sdiv i64 %t39, %t40
  store i64 %t43, ptr %l27, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %l24, !tbaa !24
  br label %bb8
bb8:
  %t46 = load i64, ptr %l24, !tbaa !24
  store i64 %t46, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t47 = load i64, ptr %l11, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l11, !tbaa !24
  %t57 = load i64, ptr %l9, !tbaa !24
  %t60 = mul i64 %t56, %t57
  %t63 = add i64 %t55, %t60
  store ptr %l6, ptr %l45, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l46, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 0
  %t67 = load i64, ptr %t66, !tbaa !24
  %t68 = getelementptr %"compiler/eval:Ptr", ptr %l4, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t73 = add i64 %t69, %t63
  %t76 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t67, i64 %t73)
  store %"compiler/eval:Ptr" %t76, ptr %l51
  br label %bb13
bb13:
  %t77 = load ptr, ptr %l46, !tbaa !29
  %t78 = load %"compiler/eval:Ptr", ptr %l51
  %t79 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t77, %"compiler/eval:Ptr" %t78, i64 1)
  store i64 %t79, ptr %l52
  br label %bb14
bb14:
  %t80 = load i64, ptr %l52, !tbaa !24
  %t81 = trunc i64 %t80 to i8
  %t83 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t83, i8 %t81)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t85 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l11, !tbaa !24
  br label %bb9
bb17:
  %t90 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l6)
  store { i64, ptr } %t90, ptr %l58
  br label %bb18
bb18:
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t91, ptr %l59, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l60, !tbaa !24
  %t94 = load i64, ptr %l60, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l61, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l60, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t105, ptr %l59, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t106 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l6 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %rv = alloca { i64, i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 75
  %t4 = load i64, ptr %l1, !tbaa !24
  %t6 = mul i64 4, %t4
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t6)
  store i64 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 75
  %t13 = load i64, ptr %l1, !tbaa !24
  %t15 = mul i64 4, %t13
  %t17 = add i64 %t15, 1
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t12, i64 %t17)
  store i64 %t20, ptr %l12
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 75
  %t24 = load i64, ptr %l1, !tbaa !24
  %t26 = mul i64 4, %t24
  %t28 = add i64 %t26, 2
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t23, i64 %t28)
  store i64 %t31, ptr %l18
  br label %bb3
bb3:
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = insertvalue { i64, i64, i64 } undef, i64 %t32, 0
  %t34 = load i64, ptr %l12, !tbaa !24
  %t35 = insertvalue { i64, i64, i64 } %t33, i64 %t34, 1
  %t36 = load i64, ptr %l18, !tbaa !24
  %t37 = insertvalue { i64, i64, i64 } %t35, i64 %t36, 2
  store { i64, i64, i64 } %t37, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64, i64 }, ptr %rv
  ret { i64, i64, i64 } %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2eTraceWhat(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i64
  %l11 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 75
  %t6 = mul i64 4, %a1
  %t8 = add i64 %t6, 3
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t8)
  store i64 %t11, ptr %l8
  br label %bb1
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 76
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t19, i64 %t20)
  store { i64, ptr } %t23, ptr %l15
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l11, !tbaa !27
  br label %bb5
bb4:
  %t24 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t24, ptr %l11, !tbaa !27
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l4 = alloca %"compiler/mir:Lvalue"
  %l5 = alloca { %"compiler/eval:Ptr", i32 }
  %l7 = alloca i32
  %l8 = alloca %"compiler/eval:Ptr"
  %l15 = alloca { %"compiler/eval:Ptr", i32 }
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i64
  %l26 = alloca i64
  %l28 = alloca %"compiler/eval:Ptr"
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l4
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = load %"compiler/mir:Lvalue", ptr %l4
  %t16 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t10, i64 %t11, %"compiler/mir:Lvalue" %t12)
  store { %"compiler/eval:Ptr", i32 } %t16, ptr %l15
  br label %bb4
bb4:
  %t17 = load { %"compiler/eval:Ptr", i32 }, ptr %l15
  store { %"compiler/eval:Ptr", i32 } %t17, ptr %l5
  %t18 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l5, i32 0, i32 0
  %t19 = load %"compiler/eval:Ptr", ptr %t18
  store %"compiler/eval:Ptr" %t19, ptr %rv
  br label %ret
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6f754b89a33b6044_bbcfb7dbcaa58778)
  unreachable
bb10:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l1, !tbaa !24
  %t25 = load { i64, [4 x i64] }, ptr %l2
  %t29 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t23, i64 %t24, { i64, [4 x i64] } %t25)
  store i32 %t29, ptr %l21
  br label %bb11
bb11:
  %t30 = load i32, ptr %l21, !tbaa !23
  store i32 %t30, ptr %l7, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  store i64 %a3, ptr %l23, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i32, ptr %l7, !tbaa !23
  %t37 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t33, i32 %t34)
  store i64 %t37, ptr %l26
  br label %bb12
bb12:
  %t38 = load i64, ptr %l26, !tbaa !24
  %t39 = add i64 %t38, 16
  %t40 = load ptr, ptr %l22, !tbaa !29
  %t41 = load i64, ptr %l23, !tbaa !24
  %t43 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %t40, i64 %t41, i64 %t39)
  store %"compiler/eval:Ptr" %t43, ptr %l28
  br label %bb13
bb13:
  %t44 = load %"compiler/eval:Ptr", ptr %l28
  store %"compiler/eval:Ptr" %t44, ptr %l8
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load %"compiler/eval:Ptr", ptr %l8
  %t48 = load i32, ptr %l7, !tbaa !23
  %t49 = load { i64, [4 x i64] }, ptr %l2
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t45, i64 %t46, %"compiler/eval:Ptr" %t47, i32 %t48, { i64, [4 x i64] } %t49)
  br label %bb14
bb14:
  %t55 = load %"compiler/eval:Ptr", ptr %l8
  store %"compiler/eval:Ptr" %t55, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/eval:scope"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/eval:scope"
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:scope"
  %l14 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l31 = alloca %"compiler/eval:scope"
  %l36 = alloca %"compiler/eval:scope"
  %l41 = alloca %"compiler/eval:scope"
  %l46 = alloca %"compiler/eval:scope"
  %l51 = alloca %"compiler/eval:scope"
  %l56 = alloca %"compiler/eval:scope"
  %l61 = alloca %"compiler/eval:scope"
  %t36 = alloca %"compiler/eval:scope", align 8
  %t48 = alloca %"compiler/eval:scope", align 8
  %t55 = alloca %"compiler/eval:scope", align 8
  %t65 = alloca %"compiler/eval:scope", align 8
  %t77 = alloca %"compiler/eval:scope", align 8
  %t84 = alloca %"compiler/eval:scope", align 8
  %t96 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i1, ptr %l14, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t13 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t9, i64 %t10)
  store i1 %t13, ptr %l19
  br label %bb4
bb4:
  %t14 = load i1, ptr %l19, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l16, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t22 = and i64 %t18, %t19
  store i64 %t22, ptr %l3, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t28 = and i64 %t24, %t25
  store i64 %t28, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 43
  %t35 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t36, ptr %v0, ptr %t34, i64 %t35)
  call void @llvm.memmove.p0.p0.i64(ptr %l31, ptr %t36, i64 136, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l31, i64 136, i1 false)
  %t39 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr %"compiler/eval:scope", ptr %l6, i32 0, i32 5
  store i64 %t39, ptr %t41, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 43
  %t45 = load i64, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %l6, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t48, ptr %l36, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t44, i64 %t45, ptr %t48)
  br label %bb10
bb10:
  %t49 = load i64, ptr %l3, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/eval:Machine", ptr %t51, i32 0, i32 43
  %t54 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t55, ptr %v0, ptr %t53, i64 %t54)
  call void @llvm.memmove.p0.p0.i64(ptr %l41, ptr %t55, i64 136, i1 false)
  br label %bb11
bb11:
  %t58 = getelementptr %"compiler/eval:scope", ptr %l41, i32 0, i32 6
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Machine", ptr %t61, i32 0, i32 43
  %t64 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t65, ptr %v0, ptr %t63, i64 %t64)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t65, i64 136, i1 false)
  br label %bb12
bb12:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l46, i64 136, i1 false)
  %t68 = load i64, ptr %l8, !tbaa !24
  %t70 = getelementptr %"compiler/eval:scope", ptr %l9, i32 0, i32 7
  store i64 %t68, ptr %t70, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/eval:Machine", ptr %t71, i32 0, i32 43
  %t74 = load i64, ptr %l7, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l51, ptr %l9, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t77, ptr %l51, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t73, i64 %t74, ptr %t77)
  br label %bb13
bb13:
  %t78 = load i64, ptr %l4, !tbaa !24
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/eval:Machine", ptr %t80, i32 0, i32 43
  %t83 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t84, ptr %v0, ptr %t82, i64 %t83)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t84, i64 136, i1 false)
  br label %bb14
bb14:
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %l56, i64 136, i1 false)
  %t87 = load i64, ptr %l1, !tbaa !24
  %t89 = getelementptr %"compiler/eval:scope", ptr %l11, i32 0, i32 6
  store i64 %t87, ptr %t89, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/eval:Machine", ptr %t90, i32 0, i32 43
  %t93 = load i64, ptr %l10, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %l11, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %l61, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t92, i64 %t93, ptr %t96)
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaggregate(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i64 %a4, %"compiler/mir:Range" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Range"
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i64
  %l23 = alloca %"compiler/eval:Ptr"
  %l29 = alloca i64
  %l34 = alloca i32
  %l37 = alloca i32
  %l60 = alloca { i64, [4 x i64] }
  %l66 = alloca i32
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l76 = alloca %"compiler/eval:Ptr"
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca i64
  %l93 = alloca i64
  %l95 = alloca %"compiler/eval:Ptr"
  %l100 = alloca i32
  %l102 = alloca ptr
  %l103 = alloca i64
  %l104 = alloca i64
  %l109 = alloca i64
  %l110 = alloca %"compiler/eval:Ptr"
  %l115 = alloca i32
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store %"compiler/mir:Range" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load i64, ptr %l20, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %t7, i64 0, i64 %t8)
  store %"compiler/eval:Ptr" %t11, ptr %l23
  br label %bb2
bb2:
  %t12 = load %"compiler/eval:Ptr", ptr %l23
  store %"compiler/eval:Ptr" %t12, ptr %l7
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load %"compiler/eval:Ptr", ptr %l7
  %t15 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %t13, %"compiler/eval:Ptr" %t14, i64 %t15)
  br label %bb3
bb3:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t20 = load i32, ptr %l3, !tbaa !23
  %t23 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t19, i32 %t20)
  store i64 %t23, ptr %l29
  br label %bb4
bb4:
  %t24 = load i64, ptr %l29, !tbaa !24
  store i64 %t24, ptr %l8, !tbaa !24
  store i32 0, ptr %l9, !tbaa !23
  %t25 = getelementptr %"compiler/mir:Range", ptr %l5, i32 0, i32 1
  %t26 = load i32, ptr %t25, !tbaa !23
  store i32 %t26, ptr %l10, !tbaa !23
  store i32 1, ptr %l11, !tbaa !23
  %t28 = load i32, ptr %l10, !tbaa !23
  %t29 = load i32, ptr %l9, !tbaa !23
  %t32 = icmp sgt i32 %t28, %t29
  br i1 %t32, label %bb5, label %bb6
bb5:
  %t34 = load i32, ptr %l11, !tbaa !23
  %t36 = icmp sgt i32 %t34, 0
  br i1 %t36, label %bb7, label %bb8
bb6:
  store i32 0, ptr %l34, !tbaa !23
  br label %bb10
bb7:
  %t38 = load i32, ptr %l10, !tbaa !23
  %t39 = load i32, ptr %l9, !tbaa !23
  %t42 = sub i32 %t38, %t39
  %t43 = load i32, ptr %l11, !tbaa !23
  %t46 = add i32 %t42, %t43
  %t48 = sub i32 %t46, 1
  %t49 = load i32, ptr %l11, !tbaa !23
  %t52 = sdiv i32 %t48, %t49
  store i32 %t52, ptr %l37, !tbaa !23
  br label %bb9
bb8:
  store i32 0, ptr %l37, !tbaa !23
  br label %bb9
bb9:
  %t54 = load i32, ptr %l37, !tbaa !23
  store i32 %t54, ptr %l34, !tbaa !23
  br label %bb10
bb10:
  %t55 = load i32, ptr %l34, !tbaa !23
  store i32 %t55, ptr %l12, !tbaa !23
  store i32 0, ptr %l13, !tbaa !23
  br label %bb11
bb11:
  %t56 = load i32, ptr %l13, !tbaa !23
  %t57 = load i32, ptr %l12, !tbaa !23
  %t60 = icmp slt i32 %t56, %t57
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb36
bb13:
  br label %bb14
bb14:
  %t64 = load i32, ptr %l9, !tbaa !23
  %t65 = load i32, ptr %l13, !tbaa !23
  %t66 = load i32, ptr %l11, !tbaa !23
  %t69 = mul i32 %t65, %t66
  %t72 = add i32 %t64, %t69
  store i32 %t72, ptr %l14, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l1, !tbaa !24
  %t76 = load %"compiler/mir:Range", ptr %l5
  %t77 = load i32, ptr %l14, !tbaa !23
  %t79 = sext i32 %t77 to i64
  %t84 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t74, i64 %t75, %"compiler/mir:Range" %t76, i64 %t79)
  store { i64, [4 x i64] } %t84, ptr %l60
  br label %bb15
bb15:
  %t85 = load { i64, [4 x i64] }, ptr %l60
  store { i64, [4 x i64] } %t85, ptr %l15
  %t86 = load i64, ptr %l8, !tbaa !24
  %t87 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t90 = icmp eq i64 %t86, %t87
  br i1 %t90, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i32, ptr %l3, !tbaa !23
  %t96 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l66
  br label %bb18
bb17:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t98 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  %t101 = icmp eq i64 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb18:
  %t103 = load i32, ptr %l66, !tbaa !23
  store i32 %t103, ptr %l16, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l67, !tbaa !29
  %t105 = load i64, ptr %l1, !tbaa !24
  store i64 %t105, ptr %l68, !tbaa !24
  %t106 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l69, !tbaa !24
  %t108 = load i32, ptr %l14, !tbaa !23
  %t110 = sext i32 %t108 to i64
  store i64 %t110, ptr %l71, !tbaa !24
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l16, !tbaa !23
  %t115 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t111, i32 %t112)
  store i64 %t115, ptr %l74
  br label %bb19
bb19:
  %t116 = load i64, ptr %l71, !tbaa !24
  %t117 = load i64, ptr %l74, !tbaa !24
  %t118 = mul i64 %t116, %t117
  %t119 = load i64, ptr %l69, !tbaa !24
  %t121 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t119, i64 %t118)
  store %"compiler/eval:Ptr" %t121, ptr %l76
  br label %bb20
bb20:
  %t122 = load i32, ptr %l16, !tbaa !23
  %t123 = load { i64, [4 x i64] }, ptr %l15
  %t124 = load ptr, ptr %l67, !tbaa !29
  %t125 = load i64, ptr %l68, !tbaa !24
  %t126 = load %"compiler/eval:Ptr", ptr %l76
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t124, i64 %t125, %"compiler/eval:Ptr" %t126, i32 %t122, { i64, [4 x i64] } %t123)
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb34
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l3, !tbaa !23
  %t131 = load i64, ptr %l4, !tbaa !24
  %t135 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %t129, i32 %t130, i64 %t131)
  store i32 %t135, ptr %l85
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l102, !tbaa !29
  %t137 = load i64, ptr %l1, !tbaa !24
  store i64 %t137, ptr %l103, !tbaa !24
  %t138 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t139 = load i64, ptr %t138, !tbaa !24
  store i64 %t139, ptr %l104, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l3, !tbaa !23
  %t142 = load i32, ptr %l14, !tbaa !23
  %t144 = sext i32 %t142 to i64
  %t148 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t140, i32 %t141, i64 %t144)
  store i64 %t148, ptr %l109
  br label %bb29
bb24:
  %t149 = load i32, ptr %l85, !tbaa !23
  store i32 %t149, ptr %l17, !tbaa !23
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l86, !tbaa !29
  %t151 = load i64, ptr %l1, !tbaa !24
  store i64 %t151, ptr %l87, !tbaa !24
  %t152 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t153 = load i64, ptr %t152, !tbaa !24
  store i64 %t153, ptr %l88, !tbaa !24
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l17, !tbaa !23
  %t156 = load i32, ptr %l14, !tbaa !23
  %t158 = sext i32 %t156 to i64
  %t162 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t154, i32 %t155, i64 %t158)
  store i64 %t162, ptr %l93
  br label %bb25
bb25:
  %t163 = load i64, ptr %l93, !tbaa !24
  %t164 = add i64 8, %t163
  %t165 = load i64, ptr %l88, !tbaa !24
  %t167 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t165, i64 %t164)
  store %"compiler/eval:Ptr" %t167, ptr %l95
  br label %bb26
bb26:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load i32, ptr %l17, !tbaa !23
  %t170 = load i32, ptr %l14, !tbaa !23
  %t172 = sext i32 %t170 to i64
  %t176 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t168, i32 %t169, i64 %t172)
  store i32 %t176, ptr %l100
  br label %bb27
bb27:
  %t177 = load { i64, [4 x i64] }, ptr %l15
  %t178 = load ptr, ptr %l86, !tbaa !29
  %t179 = load i64, ptr %l87, !tbaa !24
  %t180 = load %"compiler/eval:Ptr", ptr %l95
  %t181 = load i32, ptr %l100, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t178, i64 %t179, %"compiler/eval:Ptr" %t180, i32 %t181, { i64, [4 x i64] } %t177)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb29:
  %t183 = load i64, ptr %l104, !tbaa !24
  %t184 = load i64, ptr %l109, !tbaa !24
  %t185 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s6, i64 %t183, i64 %t184)
  store %"compiler/eval:Ptr" %t185, ptr %l110
  br label %bb30
bb30:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load i32, ptr %l3, !tbaa !23
  %t188 = load i32, ptr %l14, !tbaa !23
  %t190 = sext i32 %t188 to i64
  %t194 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t186, i32 %t187, i64 %t190)
  store i32 %t194, ptr %l115
  br label %bb31
bb31:
  %t195 = load { i64, [4 x i64] }, ptr %l15
  %t196 = load ptr, ptr %l102, !tbaa !29
  %t197 = load i64, ptr %l103, !tbaa !24
  %t198 = load %"compiler/eval:Ptr", ptr %l110
  %t199 = load i32, ptr %l115, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t196, i64 %t197, %"compiler/eval:Ptr" %t198, i32 %t199, { i64, [4 x i64] } %t195)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t201 = load i32, ptr %l13, !tbaa !23
  %t203 = add i32 %t201, 1
  store i32 %t203, ptr %l13, !tbaa !23
  br label %bb11
bb36:
  %t205 = load i64, ptr %l8, !tbaa !24
  %t206 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  %t209 = icmp eq i64 %t205, %t206
  br i1 %t209, label %bb37, label %bb38
bb37:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load %"compiler/eval:Ptr", ptr %l7
  %t213 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t211, %"compiler/eval:Ptr" %t212, i64 8, i64 %t213)
  br label %bb39
bb38:
  %t217 = load i64, ptr %l8, !tbaa !24
  %t218 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  %t221 = icmp eq i64 %t217, %t218
  br i1 %t221, label %bb40, label %bb41
bb39:
  br label %bb44
bb40:
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t224 = load %"compiler/eval:Ptr", ptr %l7
  %t225 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t223, %"compiler/eval:Ptr" %t224, i64 4, i64 %t225)
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t231 = load %"compiler/eval:Ptr", ptr %l7
  %t232 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t229, %"compiler/eval:Ptr" %a2, %"compiler/eval:Ptr" %t231, i64 %t232)
  br label %bb45
bb45:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/eval:scope"
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/eval:scope"
  %l19 = alloca %"compiler/eval:scope"
  %l24 = alloca %"compiler/eval:scope"
  %l28 = alloca { i64, ptr }
  %l39 = alloca %"compiler/eval:Ptr"
  %l42 = alloca ptr
  %l43 = alloca %"compiler/eval:Ptr"
  %l45 = alloca %"compiler/eval:Ptr"
  %l56 = alloca %"compiler/eval:scope"
  %l61 = alloca %"compiler/eval:scope"
  %l63 = alloca ptr
  %l66 = alloca %"compiler/eval:Ptr"
  %l74 = alloca %"compiler/eval:scope"
  %l79 = alloca %"compiler/eval:scope"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %t11 = alloca %"compiler/eval:scope", align 8
  %t21 = alloca %"compiler/eval:scope", align 8
  %t91 = alloca %"compiler/eval:scope", align 8
  %t103 = alloca %"compiler/eval:scope", align 8
  %t127 = alloca %"compiler/eval:scope", align 8
  %t139 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %t1, %t2
  store i64 %t5, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 43
  %t10 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t11, ptr %v0, ptr %t9, i64 %t10)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t11, i64 136, i1 false)
  br label %bb1
bb1:
  %t14 = getelementptr %"compiler/eval:scope", ptr %l19, i32 0, i32 8
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 43
  %t20 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t21, ptr %v0, ptr %t19, i64 %t20)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t21, i64 136, i1 false)
  br label %bb2
bb2:
  %t24 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 9
  %t25 = load i64, ptr %t24, !tbaa !24
  store i64 %t25, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 40
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l28, !tbaa !27
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t36 = and i64 %t32, %t33
  %t38 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr %"compiler/eval:alloc", ptr %t39, i64 %t36
  %t41 = getelementptr %"compiler/eval:alloc", ptr %t40, i32 0, i32 1
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp sge i64 %t27, %t42
  br i1 %t45, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l5, !tbaa !24
  %t50 = mul i64 2, %t48
  %t51 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t52 = load i64, ptr %l1, !tbaa !24
  %t57 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t47, i64 %t50, i64 %t51, i64 %t52)
  store %"compiler/eval:Ptr" %t57, ptr %l39
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t58 = load %"compiler/eval:Ptr", ptr %l39
  store %"compiler/eval:Ptr" %t58, ptr %l6
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 13
  %t62 = load i1, ptr %t61, !tbaa !21
  br i1 %t62, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l42, !tbaa !29
  %t65 = load %"compiler/eval:Ptr", ptr %l6
  store %"compiler/eval:Ptr" %t65, ptr %l43
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t66, i64 0)
  store %"compiler/eval:Ptr" %t68, ptr %l45
  br label %bb9
bb9:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t70 = load ptr, ptr %l42, !tbaa !29
  %t71 = load %"compiler/eval:Ptr", ptr %l43
  %t72 = load %"compiler/eval:Ptr", ptr %l45
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t70, %"compiler/eval:Ptr" %t71, %"compiler/eval:Ptr" %t72, i64 %t69)
  br label %bb10
bb10:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i64, ptr %l4, !tbaa !24
  %t76 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t79 = and i64 %t75, %t76
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t74, i64 %t79)
  br label %bb11
bb11:
  %t82 = load i64, ptr %l3, !tbaa !24
  store i64 %t82, ptr %l7, !tbaa !24
  %t84 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t85 = load i64, ptr %t84, !tbaa !24
  store i64 %t85, ptr %l8, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 43
  %t90 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t91, ptr %v0, ptr %t89, i64 %t90)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t91, i64 136, i1 false)
  br label %bb12
bb12:
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %l56, i64 136, i1 false)
  %t94 = load i64, ptr %l8, !tbaa !24
  %t96 = getelementptr %"compiler/eval:scope", ptr %l9, i32 0, i32 8
  store i64 %t94, ptr %t96, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/eval:Machine", ptr %t97, i32 0, i32 43
  %t100 = load i64, ptr %l7, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l61, ptr %l9, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t103, ptr %l61, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t99, i64 %t100, ptr %t103)
  br label %bb13
bb13:
  %t104 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t105 = load i64, ptr %t104, !tbaa !24
  store i64 %t105, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb14:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l63, !tbaa !29
  %t108 = load i64, ptr %l4, !tbaa !24
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t108, i64 %t109)
  store %"compiler/eval:Ptr" %t112, ptr %l66
  br label %bb15
bb15:
  %t114 = load ptr, ptr %l63, !tbaa !29
  %t115 = load %"compiler/eval:Ptr", ptr %l66
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t114, %"compiler/eval:Ptr" %t115, i64 1, i64 %a2)
  br label %bb16
bb16:
  %t117 = load i64, ptr %l3, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l5, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l11, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/eval:Machine", ptr %t123, i32 0, i32 43
  %t126 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t127, ptr %v0, ptr %t125, i64 %t126)
  call void @llvm.memmove.p0.p0.i64(ptr %l74, ptr %t127, i64 136, i1 false)
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %l74, i64 136, i1 false)
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = getelementptr %"compiler/eval:scope", ptr %l12, i32 0, i32 9
  store i64 %t130, ptr %t132, !tbaa !24
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 43
  %t136 = load i64, ptr %l10, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l79, ptr %l12, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %l79, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t135, i64 %t136, ptr %t139)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb7
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  %t27 = zext i8 %t21 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eappendByte(ptr %v0, ptr %a0, i64 %a1, i64 %t27)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t31, 1
  store i64 %t33, ptr %l4, !tbaa !24
  br label %bb1
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i32
  %l24 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load i32, ptr %l18, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l21
  br label %bb8
bb8:
  %t37 = load i32, ptr %l21
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load i32, ptr %l3, !tbaa !23
  store i32 %t42, ptr %l24, !tbaa !23
  br label %bb11
bb10:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t44, ptr %l24, !tbaa !23
  br label %bb11
bb11:
  %t46 = load i32, ptr %l24, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i32
  %l15 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i32
  %l29 = alloca %"compiler/eval:Ptr"
  %l32 = alloca i64
  %l36 = alloca i32
  %l38 = alloca %"compiler/eval:Ptr"
  %l41 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l50 = alloca %"compiler/eval:Ptr"
  %l51 = alloca %"compiler/eval:Ptr"
  %l54 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { %"compiler/eval:Ptr", i64 }
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a2)
  store i32 %t10, ptr %l12
  br label %bb1
bb1:
  %t11 = load i32, ptr %l12, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l15
  br label %bb2
bb2:
  %t17 = load i32, ptr %l15
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l18, !tbaa !29
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load i32, ptr %l4, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l21
  br label %bb5
bb4:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t29 = load i32, ptr %l4, !tbaa !23
  %t32 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t32, ptr %l36
  br label %bb13
bb5:
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i32, ptr %l21, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t35, ptr %l22
  br label %bb6
bb6:
  %t36 = load i32, ptr %l22, !tbaa !23
  store i32 %t36, ptr %l5, !tbaa !23
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t38 = load i32, ptr %l5, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l25
  br label %bb7
bb7:
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = icmp ne i32 %t42, 0
  br i1 %t43, label %bb8, label %bb9
bb8:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load %"compiler/eval:Ptr", ptr %l1
  %t49 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t45, %"compiler/eval:Ptr" %t46)
  store %"compiler/eval:Ptr" %t49, ptr %l29
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l5, !tbaa !23
  %t54 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t50, i32 %t51)
  store i64 %t54, ptr %l32
  br label %bb11
bb11:
  %t55 = load %"compiler/eval:Ptr", ptr %l29
  %t56 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t55, 0
  %t57 = load i64, ptr %l32, !tbaa !24
  %t58 = insertvalue { %"compiler/eval:Ptr", i64 } %t56, i64 %t57, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t58, ptr %rv
  br label %ret
bb12:
  br label %bb18
bb13:
  %t60 = load i32, ptr %l36, !tbaa !23
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t63 = load %"compiler/eval:Ptr", ptr %l1
  store %"compiler/eval:Ptr" %t63, ptr %l38
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l4, !tbaa !23
  %t68 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t64, i32 %t65)
  store i64 %t68, ptr %l41
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t69 = load %"compiler/eval:Ptr", ptr %l38
  %t70 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t69, 0
  %t71 = load i64, ptr %l41, !tbaa !24
  %t72 = insertvalue { %"compiler/eval:Ptr", i64 } %t70, i64 %t71, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t72, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load %"compiler/eval:Ptr", ptr %l1
  %t78 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t74, %"compiler/eval:Ptr" %t75, i64 8)
  store i64 %t78, ptr %l45
  br label %bb19
bb19:
  %t79 = load i64, ptr %l45, !tbaa !24
  store i64 %t79, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  %t86 = add i64 %t84, 8
  %t89 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t82, i64 %t86)
  store %"compiler/eval:Ptr" %t89, ptr %l50
  br label %bb20
bb20:
  %t90 = load ptr, ptr %l46, !tbaa !29
  %t91 = load %"compiler/eval:Ptr", ptr %l50
  %t92 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t90, %"compiler/eval:Ptr" %t91)
  store %"compiler/eval:Ptr" %t92, ptr %l51
  br label %bb21
bb21:
  %t93 = load %"compiler/eval:Ptr", ptr %l51
  store %"compiler/eval:Ptr" %t93, ptr %l7
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp sgt i64 %t94, 0
  br i1 %t96, label %bb22, label %bb23
bb22:
  %t98 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t99 = load i64, ptr %t98, !tbaa !24
  %t101 = icmp eq i64 %t99, 0
  store i1 %t101, ptr %l54, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb24
bb24:
  %t103 = load i1, ptr %l54, !tbaa !21
  br i1 %t103, label %bb25, label %bb26
bb25:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNull, !tbaa !27
  %t106 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t106, ptr %t104, { i64, ptr } %t105)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t109 = load %"compiler/eval:Ptr", ptr %l7
  %t110 = load i64, ptr %l6, !tbaa !24
  %t112 = insertvalue { %"compiler/eval:Ptr", i64 } undef, %"compiler/eval:Ptr" %t109, 0
  %t114 = insertvalue { %"compiler/eval:Ptr", i64 } %t112, i64 %t110, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i64 } %t114, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/eval:Ptr", i64 }, ptr %rv
  ret { %"compiler/eval:Ptr", i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eatomic(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/mir:Range" %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l15 = alloca { i64, [4 x i64] }
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca %"compiler/eval:Ptr"
  %l19 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i64
  %l31 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/eval:Ptr"
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca { i64, [4 x i64] }
  %l49 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca %"compiler/eval:Ptr"
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca i64
  %l61 = alloca { i64, [4 x i64] }
  %l62 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca %"compiler/eval:Ptr"
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i64
  %l78 = alloca { i64, [4 x i64] }
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca i64
  %l86 = alloca { i64, [4 x i64] }
  %l87 = alloca i64
  %l90 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca %"compiler/eval:Ptr"
  %l95 = alloca i64
  %l96 = alloca ptr
  %l97 = alloca i64
  %l101 = alloca { i64, [4 x i64] }
  %l102 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l11, !tbaa !24
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t6 = load %"compiler/mir:Range", ptr %l3
  %t10 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t4, i64 %t5, %"compiler/mir:Range" %t6, i64 0)
  store { i64, [4 x i64] } %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = load { i64, [4 x i64] }, ptr %l15
  %t14 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t11, i64 %t12, { i64, [4 x i64] } %t13, i64 1)
  store %"compiler/eval:Ptr" %t14, ptr %l16
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l9, !tbaa !29
  %t16 = load %"compiler/eval:Ptr", ptr %l16
  %t17 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t15, %"compiler/eval:Ptr" %t16)
  store %"compiler/eval:Ptr" %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load %"compiler/eval:Ptr", ptr %l17
  store %"compiler/eval:Ptr" %t18, ptr %l5
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l19, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %a4)
  store i32 %t30, ptr %l23
  br label %bb4
bb4:
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = load i32, ptr %l23, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t33, ptr %l24
  br label %bb5
bb5:
  %t34 = load i32, ptr %l24, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t35, i32 %t34)
  store i64 %t39, ptr %l27
  br label %bb6
bb6:
  %t40 = load i64, ptr %l27, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load %"compiler/eval:Ptr", ptr %l5
  %t43 = load i64, ptr %l7, !tbaa !24
  %t47 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t41, %"compiler/eval:Ptr" %t42, i64 %t43)
  store i64 %t47, ptr %l31
  br label %bb7
bb7:
  %t48 = load i64, ptr %l31, !tbaa !24
  store i64 %t48, ptr %l8, !tbaa !24
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 13
  %t52 = load i1, ptr %t51, !tbaa !21
  br i1 %t52, label %bb8, label %bb9
bb8:
  store i64 0, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t55 = load i32, ptr %l2
  %t57 = trunc i64 24 to i32
  %t58 = icmp eq i32 %t55, %t57
  br i1 %t58, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t60 = load i64, ptr %l8, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
bb14:
  %t62 = load i32, ptr %l2
  %t64 = trunc i64 25 to i32
  %t65 = icmp eq i32 %t62, %t64
  br i1 %t65, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l40, !tbaa !29
  %t68 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t68, ptr %l41
  %t69 = load i64, ptr %l7, !tbaa !24
  store i64 %t69, ptr %l42, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l43, !tbaa !29
  %t71 = load i64, ptr %l1, !tbaa !24
  store i64 %t71, ptr %l44, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load %"compiler/mir:Range", ptr %l3
  %t78 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t72, i64 %t73, %"compiler/mir:Range" %t74, i64 1)
  store { i64, [4 x i64] } %t78, ptr %l48
  br label %bb18
bb18:
  %t79 = load ptr, ptr %l43, !tbaa !29
  %t80 = load i64, ptr %l44, !tbaa !24
  %t81 = load { i64, [4 x i64] }, ptr %l48
  %t82 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t79, i64 %t80, { i64, [4 x i64] } %t81)
  store i64 %t82, ptr %l49
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l40, !tbaa !29
  %t84 = load %"compiler/eval:Ptr", ptr %l41
  %t85 = load i64, ptr %l42, !tbaa !24
  %t86 = load i64, ptr %l49, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t83, %"compiler/eval:Ptr" %t84, i64 %t85, i64 %t86)
  br label %bb20
bb20:
  br label %bb50
bb21:
  %t87 = load i32, ptr %l2
  %t89 = trunc i64 26 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l52, !tbaa !29
  %t93 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t93, ptr %l53
  %t94 = load i64, ptr %l7, !tbaa !24
  store i64 %t94, ptr %l54, !tbaa !24
  %t95 = load i64, ptr %l8, !tbaa !24
  store i64 %t95, ptr %l55, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l56, !tbaa !29
  %t97 = load i64, ptr %l1, !tbaa !24
  store i64 %t97, ptr %l57, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l1, !tbaa !24
  %t100 = load %"compiler/mir:Range", ptr %l3
  %t104 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t98, i64 %t99, %"compiler/mir:Range" %t100, i64 1)
  store { i64, [4 x i64] } %t104, ptr %l61
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t106 = load i64, ptr %l57, !tbaa !24
  %t107 = load { i64, [4 x i64] }, ptr %l61
  %t108 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t105, i64 %t106, { i64, [4 x i64] } %t107)
  store i64 %t108, ptr %l62
  br label %bb26
bb26:
  %t109 = load i64, ptr %l55, !tbaa !24
  %t110 = load i64, ptr %l62, !tbaa !24
  %t111 = add i64 %t109, %t110
  store i64 %t111, ptr %l63, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t112, i64 %t113)
  store i64 %t116, ptr %l66
  br label %bb27
bb27:
  %t117 = load i64, ptr %l63, !tbaa !24
  %t118 = load i64, ptr %l66, !tbaa !24
  %t119 = and i64 %t117, %t118
  %t120 = load ptr, ptr %l52, !tbaa !29
  %t121 = load %"compiler/eval:Ptr", ptr %l53
  %t122 = load i64, ptr %l54, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t120, %"compiler/eval:Ptr" %t121, i64 %t122, i64 %t119)
  br label %bb28
bb28:
  br label %bb50
bb29:
  %t124 = load i32, ptr %l2
  %t126 = trunc i64 27 to i32
  %t127 = icmp eq i32 %t124, %t126
  br i1 %t127, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l70, !tbaa !29
  %t130 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t130, ptr %l71
  %t131 = load i64, ptr %l7, !tbaa !24
  store i64 %t131, ptr %l72, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l73, !tbaa !29
  %t133 = load i64, ptr %l1, !tbaa !24
  store i64 %t133, ptr %l74, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  %t136 = load %"compiler/mir:Range", ptr %l3
  %t140 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t134, i64 %t135, %"compiler/mir:Range" %t136, i64 1)
  store { i64, [4 x i64] } %t140, ptr %l78
  br label %bb33
bb33:
  %t141 = load ptr, ptr %l73, !tbaa !29
  %t142 = load i64, ptr %l74, !tbaa !24
  %t143 = load { i64, [4 x i64] }, ptr %l78
  %t144 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t141, i64 %t142, { i64, [4 x i64] } %t143)
  store i64 %t144, ptr %l79
  br label %bb34
bb34:
  %t145 = load ptr, ptr %l70, !tbaa !29
  %t146 = load %"compiler/eval:Ptr", ptr %l71
  %t147 = load i64, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l79, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t145, %"compiler/eval:Ptr" %t146, i64 %t147, i64 %t148)
  br label %bb35
bb35:
  br label %bb50
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb49
bb39:
  %t149 = load i64, ptr %l8, !tbaa !24
  store i64 %t149, ptr %l80, !tbaa !24
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l81, !tbaa !29
  %t151 = load i64, ptr %l1, !tbaa !24
  store i64 %t151, ptr %l82, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l1, !tbaa !24
  %t154 = load %"compiler/mir:Range", ptr %l3
  %t158 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t152, i64 %t153, %"compiler/mir:Range" %t154, i64 1)
  store { i64, [4 x i64] } %t158, ptr %l86
  br label %bb40
bb40:
  %t159 = load ptr, ptr %l81, !tbaa !29
  %t160 = load i64, ptr %l82, !tbaa !24
  %t161 = load { i64, [4 x i64] }, ptr %l86
  %t162 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t159, i64 %t160, { i64, [4 x i64] } %t161)
  store i64 %t162, ptr %l87
  br label %bb41
bb41:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i64, ptr %l7, !tbaa !24
  %t167 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %t163, i64 %t164)
  store i64 %t167, ptr %l90
  br label %bb42
bb42:
  %t168 = load i64, ptr %l87, !tbaa !24
  %t169 = load i64, ptr %l90, !tbaa !24
  %t170 = and i64 %t168, %t169
  %t171 = load i64, ptr %l80, !tbaa !24
  %t173 = icmp eq i64 %t171, %t170
  br i1 %t173, label %bb43, label %bb44
bb43:
  %t175 = load ptr, ptr %l0, !tbaa !29
  store ptr %t175, ptr %l93, !tbaa !29
  %t176 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t176, ptr %l94
  %t177 = load i64, ptr %l7, !tbaa !24
  store i64 %t177, ptr %l95, !tbaa !24
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l96, !tbaa !29
  %t179 = load i64, ptr %l1, !tbaa !24
  store i64 %t179, ptr %l97, !tbaa !24
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  %t182 = load %"compiler/mir:Range", ptr %l3
  %t186 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t180, i64 %t181, %"compiler/mir:Range" %t182, i64 2)
  store { i64, [4 x i64] } %t186, ptr %l101
  br label %bb45
bb44:
  br label %bb48
bb45:
  %t187 = load ptr, ptr %l96, !tbaa !29
  %t188 = load i64, ptr %l97, !tbaa !24
  %t189 = load { i64, [4 x i64] }, ptr %l101
  %t190 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t187, i64 %t188, { i64, [4 x i64] } %t189)
  store i64 %t190, ptr %l102
  br label %bb46
bb46:
  %t191 = load ptr, ptr %l93, !tbaa !29
  %t192 = load %"compiler/eval:Ptr", ptr %l94
  %t193 = load i64, ptr %l95, !tbaa !24
  %t194 = load i64, ptr %l102, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t191, %"compiler/eval:Ptr" %t192, i64 %t193, i64 %t194)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_561376b2ca02a7ba_25f299f9320c8ad6)
  unreachable
bb50:
  %t195 = load i64, ptr %l8, !tbaa !24
  store i64 %t195, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca { %"compiler/eval:Ptr", i64 }
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca %"compiler/eval:Ptr"
  %l25 = alloca { %"compiler/eval:Ptr", i64 }
  %l32 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i64
  %l39 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l67 = alloca i64
  %l68 = alloca ptr
  %l73 = alloca %"compiler/eval:Ptr"
  %l74 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load { i64, [4 x i64] }, ptr %l2
  %t7 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1, i64 %t2, { i64, [4 x i64] } %t3)
  store i32 %t7, ptr %l18
  br label %bb1
bb1:
  %t8 = load i32, ptr %l18, !tbaa !23
  store i32 %t8, ptr %l3, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i64, ptr %l1, !tbaa !24
  %t12 = load { i64, [4 x i64] }, ptr %l2
  %t16 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t10, i64 %t11, { i64, [4 x i64] } %t12, i64 1)
  store %"compiler/eval:Ptr" %t16, ptr %l23
  br label %bb2
bb2:
  %t17 = load i32, ptr %l3, !tbaa !23
  %t18 = load ptr, ptr %l19, !tbaa !29
  %t19 = load %"compiler/eval:Ptr", ptr %l23
  %t21 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t18, %"compiler/eval:Ptr" %t19, i32 %t17)
  store { %"compiler/eval:Ptr", i64 } %t21, ptr %l25
  br label %bb3
bb3:
  %t22 = load { %"compiler/eval:Ptr", i64 }, ptr %l25
  store { %"compiler/eval:Ptr", i64 } %t22, ptr %l4
  %t23 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l4, i32 0, i32 0
  %t24 = load %"compiler/eval:Ptr", ptr %t23
  store %"compiler/eval:Ptr" %t24, ptr %l5
  %t26 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l4, i32 0, i32 1
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l6, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 13
  %t32 = load i1, ptr %t31, !tbaa !21
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t34 = icmp sge i64 0, 0
  br i1 %t34, label %bb6, label %bb7
bb5:
  br label %bb8
bb6:
  %t36 = mul i64 0, 1
  %t37 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 0, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_9c6d2d38b14ece16_85850a0ccdf8ec6a)
  unreachable
bb8:
  %t41 = load i64, ptr %l6, !tbaa !24
  store i64 %t41, ptr %l32, !tbaa !24
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l33, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t47 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l36
  br label %bb9
bb9:
  %t48 = load ptr, ptr %l33, !tbaa !29
  %t49 = load i32, ptr %l36, !tbaa !23
  %t50 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t48, i32 %t49)
  store i64 %t50, ptr %l37
  br label %bb10
bb10:
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = load i64, ptr %l37, !tbaa !24
  %t53 = mul i64 %t51, %t52
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  store i64 %t55, ptr %l39, !tbaa !24
  %t56 = load i64, ptr %l39, !tbaa !24
  %t57 = icmp sge i64 %t56, 0
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t59 = load i64, ptr %l39, !tbaa !24
  %t60 = mul i64 %t59, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t60)
  %t62 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  %t64 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t64, ptr %lp8
  %t66 = load ptr, ptr %lp8
  store { i64, ptr } %t63, ptr %t66, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t67 = load i64, ptr %l7, !tbaa !24
  store i64 %t67, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t69 = load i64, ptr %l10, !tbaa !24
  %t70 = load i64, ptr %l9, !tbaa !24
  %t73 = icmp sgt i64 %t69, %t70
  br i1 %t73, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_3e93cd40ddf47e2b_3ba0afa8b25b773f)
  unreachable
bb13:
  %t75 = load i64, ptr %l11, !tbaa !24
  %t77 = icmp sgt i64 %t75, 0
  br i1 %t77, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb18
bb15:
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = sub i64 %t79, %t80
  %t84 = load i64, ptr %l11, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = sub i64 %t87, 1
  %t90 = load i64, ptr %l11, !tbaa !24
  %t93 = sdiv i64 %t89, %t90
  store i64 %t93, ptr %l49, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb17
bb17:
  %t95 = load i64, ptr %l49, !tbaa !24
  store i64 %t95, ptr %l46, !tbaa !24
  br label %bb18
bb18:
  %t96 = load i64, ptr %l46, !tbaa !24
  store i64 %t96, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t97 = load i64, ptr %l13, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb21:
  br label %bb22
bb22:
  %t105 = load i64, ptr %l9, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t110 = mul i64 %t106, %t107
  %t113 = add i64 %t105, %t110
  store i64 %t113, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l14, !tbaa !24
  store i64 %t115, ptr %l67, !tbaa !24
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l68, !tbaa !29
  %t117 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load i64, ptr %l14, !tbaa !24
  %t124 = add i64 %t120, %t121
  %t127 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t118, i64 %t124)
  store %"compiler/eval:Ptr" %t127, ptr %l73
  br label %bb23
bb23:
  %t128 = load ptr, ptr %l68, !tbaa !29
  %t129 = load %"compiler/eval:Ptr", ptr %l73
  %t130 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t128, %"compiler/eval:Ptr" %t129, i64 1)
  store i64 %t130, ptr %l74
  br label %bb24
bb24:
  %t131 = load i64, ptr %l74, !tbaa !24
  %t132 = trunc i64 %t131 to i8
  %t134 = load ptr, ptr %lp8
  %t135 = load i64, ptr %l67, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t135
  store i8 %t132, ptr %t138, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  %t139 = load i64, ptr %l13, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l13, !tbaa !24
  br label %bb19
bb26:
  %t143 = load ptr, ptr %lp8
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallExtern(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, %"compiler/mir:Range" %a4, %"compiler/eval:Ptr" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i1
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca { i64, [4 x i64] }
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i32
  %l29 = alloca i64
  %l30 = alloca { %"compiler/eval:Ptr", i64 }
  %l31 = alloca %"compiler/eval:Ptr"
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca %"compiler/eval:Ptr"
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca %"compiler/eval:Ptr"
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i8
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca %"compiler/eval:Ptr"
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l72 = alloca %"compiler/mir:Fn"
  %l73 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l91 = alloca i32
  %l95 = alloca i1
  %l99 = alloca i1
  %l105 = alloca i1
  %l113 = alloca i1
  %l117 = alloca i1
  %l120 = alloca i1
  %l124 = alloca i1
  %l127 = alloca i1
  %l129 = alloca i1
  %l137 = alloca i64
  %l140 = alloca i64
  %l141 = alloca %"compiler/eval:Ptr"
  %l143 = alloca %"compiler/eval:Ptr"
  %l147 = alloca i64
  %l151 = alloca i64
  %l159 = alloca i64
  %l162 = alloca i64
  %l185 = alloca { i64, [4 x i64] }
  %l190 = alloca i32
  %l191 = alloca { i64, ptr }
  %l197 = alloca i32
  %l201 = alloca i1
  %l202 = alloca i64
  %l205 = alloca i32
  %l206 = alloca i8
  %l210 = alloca i64
  %l214 = alloca i64
  %l221 = alloca i64
  %l230 = alloca i32
  %l233 = alloca i64
  %l237 = alloca i1
  %l241 = alloca ptr
  %l245 = alloca %"compiler/eval:Ptr"
  %l247 = alloca { %"compiler/eval:Ptr", i64 }
  %l252 = alloca i32
  %l255 = alloca i64
  %l257 = alloca i8
  %l262 = alloca i1
  %l263 = alloca i64
  %l266 = alloca i32
  %l267 = alloca i8
  %l270 = alloca i1
  %l271 = alloca i64
  %l273 = alloca i8
  %l279 = alloca i64
  %l280 = alloca i64
  %l283 = alloca i64
  %l285 = alloca i64
  %l288 = alloca i64
  %l294 = alloca ptr
  %l298 = alloca %"compiler/eval:Ptr"
  %l299 = alloca %"compiler/eval:Ptr"
  %l300 = alloca i64
  %l302 = alloca i8
  %l305 = alloca i1
  %l319 = alloca ptr
  %l322 = alloca i32
  %l323 = alloca i32
  %l326 = alloca i1
  %l329 = alloca i1
  %l330 = alloca i64
  %l332 = alloca i8
  %l335 = alloca i64
  %l338 = alloca i64
  %l339 = alloca i64
  %l342 = alloca i64
  %l353 = alloca i64
  %l361 = alloca i64
  %l364 = alloca i64
  %l389 = alloca i64
  %l391 = alloca i8
  %l393 = alloca i8
  %l395 = alloca i64
  %l398 = alloca i64
  %l402 = alloca i64
  %l409 = alloca i64
  %l412 = alloca i64
  %l430 = alloca ptr
  %l435 = alloca %"compiler/eval:Ptr"
  %l436 = alloca i64
  %l453 = alloca i64
  %l458 = alloca i64
  %l460 = alloca i64
  %l473 = alloca i1
  %l477 = alloca i8
  %l479 = alloca i8
  %l481 = alloca i8
  %l484 = alloca i32
  %l485 = alloca i8
  %l486 = alloca i64
  %l490 = alloca i64
  %l491 = alloca i32
  %l492 = alloca i64
  %l498 = alloca i64
  %l499 = alloca i32
  %l507 = alloca ptr
  %l508 = alloca i32
  %l513 = alloca i64
  %l516 = alloca i64
  %l542 = alloca { i64, ptr }
  %l552 = alloca i64
  %l555 = alloca i64
  %l573 = alloca ptr
  %l578 = alloca %"compiler/eval:Ptr"
  %l588 = alloca i64
  %l594 = alloca i64
  %l596 = alloca i64
  %l604 = alloca i1
  %l606 = alloca ptr
  %l607 = alloca %"compiler/eval:Ptr"
  %l610 = alloca %"compiler/eval:Ptr"
  %l615 = alloca %"compiler/eval:Ptr"
  %l617 = alloca i1
  %l621 = alloca i1
  %l625 = alloca ptr
  %l626 = alloca %"compiler/eval:Ptr"
  %l629 = alloca i64
  %s0 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %rv = alloca i1
  %t3 = alloca %"compiler/mir:Fn", align 8
  %t163 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  store %"compiler/eval:Ptr" %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t3, ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l72, ptr %t3, i64 248, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l72, i64 248, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 25
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v0, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l78
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb3, label %ok.16, !prof !99
ok.16:
  store { i64, ptr } %t13, ptr %l77
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t17, ptr %l73, !tbaa !27
  br label %bb6
bb3:
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t20 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t20, ptr %t18, { i64, ptr } %t19)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t24 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l9, !tbaa !29
  %t30 = load ptr, ptr %l9, !tbaa !29
  store ptr %t30, ptr %l84, !tbaa !29
  %t31 = load ptr, ptr %l9, !tbaa !29
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l87
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l84, !tbaa !29
  %t37 = load i32, ptr %l87, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t38, ptr %l88
  br label %bb8
bb8:
  %t39 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t39, ptr %l10, !tbaa !27
  %t40 = load ptr, ptr %l9, !tbaa !29
  %t41 = load i32, ptr %l3, !tbaa !23
  %t44 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t40, i32 %t41)
  store i32 %t44, ptr %l91
  br label %bb9
bb9:
  %t45 = load i32, ptr %l91, !tbaa !23
  store i32 %t45, ptr %l11, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 1
  %t49 = load i32, ptr %t48
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb10:
  %t54 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t60 = call i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %t54, i64 %t57)
  store i1 %t60, ptr %l99
  br label %bb12
bb11:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb13
bb12:
  %t61 = load i1, ptr %l99, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l95, !tbaa !21
  br label %bb13
bb13:
  %t64 = load i1, ptr %l95, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyExtern, !tbaa !27
  %t67 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t67, ptr %t65, { i64, ptr } %t66)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb17:
  %t71 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t73, ptr %l105
  br label %bb18
bb18:
  %t74 = load i1, ptr %l105, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t78 = load %"compiler/mir:Range", ptr %l4
  %t79 = load i32, ptr %l3, !tbaa !23
  %t80 = load %"compiler/eval:Ptr", ptr %l5
  %t81 = load i1, ptr %l6, !tbaa !21
  %t89 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eruntimeFn(ptr %v0, ptr %v0, ptr %t75, i64 %t76, { i64, ptr } %t77, %"compiler/mir:Range" %t78, i32 %t79, %"compiler/eval:Ptr" %t80, i1 %t81)
  store i1 %t89, ptr %l113
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load i1, ptr %l113, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
bb22:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t91, i32 0, i32 1
  %t94 = load i32, ptr %t93
  %t96 = trunc i64 1 to i32
  %t97 = icmp eq i32 %t94, %t96
  br i1 %t97, label %bb23, label %bb24
bb23:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t103 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewaitsForTask(ptr %v0, ptr %v0, ptr %t99, { i64, ptr } %t100)
  store i1 %t103, ptr %l120
  br label %bb25
bb24:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb26
bb25:
  %t104 = load i1, ptr %l120, !tbaa !21
  store i1 %t104, ptr %l117, !tbaa !21
  br label %bb26
bb26:
  %t105 = load i1, ptr %l117, !tbaa !21
  br i1 %t105, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l11, !tbaa !23
  %t111 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eforeignRef(ptr %v0, ptr %t107, i32 %t108)
  store i1 %t111, ptr %l124
  br label %bb30
bb30:
  %t112 = load i1, ptr %l124, !tbaa !21
  store i1 %t112, ptr %l12, !tbaa !21
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i32, ptr %l11, !tbaa !23
  %t117 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %t113, i32 %t114, i1 true)
  store i1 %t117, ptr %l127
  br label %bb31
bb31:
  %t118 = load i1, ptr %l127, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb32, label %bb33
bb32:
  %t121 = load i1, ptr %l12, !tbaa !21
  %t123 = xor i1 %t121, true
  store i1 %t123, ptr %l129, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l129, !tbaa !21
  br label %bb34
bb34:
  %t125 = load i1, ptr %l129, !tbaa !21
  br i1 %t125, label %bb35, label %bb36
bb35:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t128 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t128, ptr %t126, { i64, ptr } %t127)
  br label %bb37
bb36:
  br label %bb38
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb38:
  %t132 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t133 = load i32, ptr %t132, !tbaa !23
  %t135 = sext i32 %t133 to i64
  store i64 %t135, ptr %l13, !tbaa !24
  %t137 = load i64, ptr %l13, !tbaa !24
  store i64 %t137, ptr %l137, !tbaa !24
  %t138 = load i64, ptr %l137, !tbaa !24
  %t139 = icmp sge i64 %t138, 0
  br i1 %t139, label %bb39, label %bb40
bb39:
  %t141 = load i64, ptr %l137, !tbaa !24
  %t142 = mul i64 %t141, 1
  %t143 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t142)
  %t144 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  store { i64, ptr } %t145, ptr %l14, !tbaa !27
  %t147 = load i64, ptr %l13, !tbaa !24
  store i64 %t147, ptr %l140, !tbaa !24
  store %"compiler/eval:Ptr" zeroinitializer, ptr %l141
  %t148 = load i64, ptr %l140, !tbaa !24
  %t149 = icmp sgt i64 %t148, 0
  br i1 %t149, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_8455ed81fb66a668_e2c955a612231684)
  unreachable
bb41:
  %t151 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 0, i64 0)
  store %"compiler/eval:Ptr" %t151, ptr %l143
  br label %bb43
bb42:
  %t152 = load i64, ptr %l140, !tbaa !24
  %t153 = icmp sge i64 %t152, 0
  br i1 %t153, label %bb44, label %bb45
bb43:
  %t155 = load %"compiler/eval:Ptr", ptr %l143
  store %"compiler/eval:Ptr" %t155, ptr %l141
  br label %bb42
bb44:
  %t156 = load i64, ptr %l140, !tbaa !24
  %t157 = icmp sle i64 %t156, 576460752303423487
  br i1 %t157, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_e6f2fd943c115655_f5638f66c9629791)
  unreachable
bb46:
  %t159 = load i64, ptr %l140, !tbaa !24
  %t160 = mul i64 %t159, 16
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  %t162 = load %"compiler/eval:Ptr", ptr %l141
  store i64 0, ptr %t163
  br label %fill.164
fill.164:
  %t167 = load i64, ptr %t163
  %t168 = icmp slt i64 %t167, %t159
  br i1 %t168, label %fillb.165, label %filld.166
fillb.165:
  %t169 = getelementptr %"compiler/eval:Ptr", ptr %t161, i64 %t167
  store %"compiler/eval:Ptr" %t162, ptr %t169
  %t170 = add i64 %t167, 1
  store i64 %t170, ptr %t163
  br label %fill.164
filld.166:
  %t171 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t161, 1
  store { i64, ptr } %t172, ptr %l15, !tbaa !27
  %t174 = load i64, ptr %l13, !tbaa !24
  store i64 %t174, ptr %l147, !tbaa !24
  %t175 = load i64, ptr %l147, !tbaa !24
  %t176 = icmp sge i64 %t175, 0
  br i1 %t176, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_e6f2fd943c115655_f5638f66c9629791)
  unreachable
bb48:
  %t178 = load i64, ptr %l147, !tbaa !24
  %t179 = icmp sle i64 %t178, 1152921504606846975
  br i1 %t179, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_24365dba12301136_85ae2e45ea64b572)
  unreachable
bb50:
  %t181 = load i64, ptr %l147, !tbaa !24
  %t182 = mul i64 %t181, 8
  %t183 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l16, !tbaa !27
  %t187 = load i64, ptr %l13, !tbaa !24
  store i64 %t187, ptr %l151, !tbaa !24
  %t188 = load i64, ptr %l151, !tbaa !24
  %t189 = icmp sge i64 %t188, 0
  br i1 %t189, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_24365dba12301136_85ae2e45ea64b572)
  unreachable
bb52:
  %t191 = load i64, ptr %l151, !tbaa !24
  %t192 = icmp sle i64 %t191, 1152921504606846975
  br i1 %t192, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_e79146937ca231cb_dd9a37031fe8e967)
  unreachable
bb54:
  %t194 = load i64, ptr %l151, !tbaa !24
  %t195 = mul i64 %t194, 8
  %t196 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t195)
  %t197 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t198 = insertvalue { i64, ptr } %t197, ptr %t196, 1
  store { i64, ptr } %t198, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  %t200 = load i64, ptr %l13, !tbaa !24
  store i64 %t200, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t202 = load i64, ptr %l20, !tbaa !24
  %t203 = load i64, ptr %l19, !tbaa !24
  %t206 = icmp sgt i64 %t202, %t203
  br i1 %t206, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_e79146937ca231cb_dd9a37031fe8e967)
  unreachable
bb56:
  %t208 = load i64, ptr %l21, !tbaa !24
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb58, label %bb59
bb57:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb61
bb58:
  %t212 = load i64, ptr %l20, !tbaa !24
  %t213 = load i64, ptr %l19, !tbaa !24
  %t216 = sub i64 %t212, %t213
  %t217 = load i64, ptr %l21, !tbaa !24
  %t220 = add i64 %t216, %t217
  %t222 = sub i64 %t220, 1
  %t223 = load i64, ptr %l21, !tbaa !24
  %t226 = sdiv i64 %t222, %t223
  store i64 %t226, ptr %l162, !tbaa !24
  br label %bb60
bb59:
  store i64 0, ptr %l162, !tbaa !24
  br label %bb60
bb60:
  %t228 = load i64, ptr %l162, !tbaa !24
  store i64 %t228, ptr %l159, !tbaa !24
  br label %bb61
bb61:
  %t229 = load i64, ptr %l159, !tbaa !24
  store i64 %t229, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb62
bb62:
  %t230 = load i64, ptr %l23, !tbaa !24
  %t231 = load i64, ptr %l22, !tbaa !24
  %t234 = icmp slt i64 %t230, %t231
  %t236 = xor i1 %t234, true
  br i1 %t236, label %bb63, label %bb64
bb63:
  br label %bb141
bb64:
  br label %bb65
bb65:
  %t238 = load i64, ptr %l19, !tbaa !24
  %t239 = load i64, ptr %l23, !tbaa !24
  %t240 = load i64, ptr %l21, !tbaa !24
  %t243 = mul i64 %t239, %t240
  %t246 = add i64 %t238, %t243
  store i64 %t246, ptr %l24, !tbaa !24
  %t248 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 11
  %t249 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t250 = load i32, ptr %t249, !tbaa !23
  %t252 = sext i32 %t250 to i64
  %t253 = load i64, ptr %l24, !tbaa !24
  %t256 = add i64 %t252, %t253
  %t259 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t248, i64 %t256)
  store { i64, [4 x i64] } %t259, ptr %l185
  br label %bb66
bb66:
  %t260 = load { i64, [4 x i64] }, ptr %l185
  store { i64, [4 x i64] } %t260, ptr %l25
  %t261 = load i64, ptr %l24, !tbaa !24
  %t262 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t267 = icmp slt i64 %t261, %t264
  br i1 %t267, label %bb67, label %bb68
bb67:
  %t269 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t269, ptr %l191, !tbaa !27
  %t270 = load i64, ptr %l24, !tbaa !24
  %t272 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t273 = load ptr, ptr %t272, !tbaa !27
  %t274 = getelementptr i32, ptr %t273, i64 %t270
  %t275 = load i32, ptr %t274, !tbaa !33
  store i32 %t275, ptr %l190, !tbaa !23
  br label %bb70
bb68:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i64, ptr %l1, !tbaa !24
  %t279 = load { i64, [4 x i64] }, ptr %l25
  %t283 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t277, i64 %t278, { i64, [4 x i64] } %t279)
  store i32 %t283, ptr %l197
  br label %bb69
bb69:
  %t284 = load i32, ptr %l197, !tbaa !23
  store i32 %t284, ptr %l190, !tbaa !23
  br label %bb70
bb70:
  %t285 = load i32, ptr %l190, !tbaa !23
  store i32 %t285, ptr %l26, !tbaa !23
  %t286 = load i64, ptr %l24, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr i64, ptr %t289, i64 %t286
  store i64 -1, ptr %t290, !tbaa !34
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l26, !tbaa !23
  %t295 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %t291, i32 %t292, i1 false)
  store i1 %t295, ptr %l201
  br label %bb71
bb71:
  %t296 = load i1, ptr %l201, !tbaa !21
  br i1 %t296, label %bb72, label %bb73
bb72:
  %t297 = load i64, ptr %l24, !tbaa !24
  store i64 %t297, ptr %l202, !tbaa !24
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load i32, ptr %l26, !tbaa !23
  %t302 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %t298, i32 %t299)
  store i32 %t302, ptr %l205
  br label %bb74
bb73:
  br label %bb82
bb74:
  %t303 = load i32, ptr %l205
  %t304 = call i8 @std_2fffi_2eCode(i32 %t303)
  store i8 %t304, ptr %l206
  br label %bb75
bb75:
  %t305 = load i8, ptr %l206, !tbaa !22
  %t306 = load i64, ptr %l202, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i8, ptr %t308, i64 %t306
  store i8 %t305, ptr %t309, !tbaa !32
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t311 = load i64, ptr %l1, !tbaa !24
  %t312 = load { i64, [4 x i64] }, ptr %l25
  %t316 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t310, i64 %t311, { i64, [4 x i64] } %t312)
  store i64 %t316, ptr %l210
  br label %bb76
bb76:
  %t317 = load i64, ptr %l210, !tbaa !24
  store i64 %t317, ptr %l27, !tbaa !65
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i32, ptr %l26, !tbaa !23
  %t323 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t319, i32 %t320)
  store i64 %t323, ptr %l214
  br label %bb77
bb77:
  %t324 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t325 = load i64, ptr %l214, !tbaa !24
  %t327 = icmp eq i64 %t325, %t324
  br i1 %t327, label %bb78, label %bb79
bb78:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i64, ptr %l27, !tbaa !65
  %t332 = load i32, ptr %l26, !tbaa !23
  %t336 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t329, i64 %t330, i32 %t332)
  store i64 %t336, ptr %l221
  br label %bb80
bb79:
  br label %bb81
bb80:
  %t337 = load i64, ptr %l221, !tbaa !24
  store i64 %t337, ptr %l27, !tbaa !65
  br label %bb81
bb81:
  %t339 = load i64, ptr %l24, !tbaa !24
  %t340 = load i64, ptr %l27, !tbaa !65
  %t343 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr i64, ptr %t344, i64 %t339
  store i64 %t340, ptr %t345, !tbaa !85
  %t346 = load i64, ptr %l18, !tbaa !24
  %t348 = add i64 %t346, 1
  store i64 %t348, ptr %l18, !tbaa !24
  br label %bb140
bb82:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load i64, ptr %l1, !tbaa !24
  %t352 = load { i64, [4 x i64] }, ptr %l25
  %t356 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t350, i64 %t351, { i64, [4 x i64] } %t352)
  store i32 %t356, ptr %l230
  br label %bb83
bb83:
  %t357 = load i32, ptr %l230, !tbaa !23
  store i32 %t357, ptr %l28, !tbaa !23
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load i32, ptr %l28, !tbaa !23
  %t362 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t358, i32 %t359)
  store i64 %t362, ptr %l233
  br label %bb84
bb84:
  %t363 = load i64, ptr %l233, !tbaa !24
  store i64 %t363, ptr %l29, !tbaa !24
  %t364 = load i64, ptr %l29, !tbaa !24
  %t365 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t368 = icmp eq i64 %t364, %t365
  br i1 %t368, label %bb85, label %bb86
bb85:
  store i1 true, ptr %l237, !tbaa !21
  br label %bb87
bb86:
  %t370 = load i64, ptr %l29, !tbaa !24
  %t371 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t374 = icmp eq i64 %t370, %t371
  store i1 %t374, ptr %l237, !tbaa !21
  br label %bb87
bb87:
  %t376 = load i1, ptr %l237, !tbaa !21
  br i1 %t376, label %bb88, label %bb89
bb88:
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l241, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t379 = load i64, ptr %l1, !tbaa !24
  %t380 = load { i64, [4 x i64] }, ptr %l25
  %t384 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t378, i64 %t379, { i64, [4 x i64] } %t380, i64 1)
  store %"compiler/eval:Ptr" %t384, ptr %l245
  br label %bb90
bb89:
  br label %bb111
bb90:
  %t385 = load i32, ptr %l28, !tbaa !23
  %t386 = load ptr, ptr %l241, !tbaa !29
  %t387 = load %"compiler/eval:Ptr", ptr %l245
  %t389 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t386, %"compiler/eval:Ptr" %t387, i32 %t385)
  store { %"compiler/eval:Ptr", i64 } %t389, ptr %l247
  br label %bb91
bb91:
  %t390 = load { %"compiler/eval:Ptr", i64 }, ptr %l247
  store { %"compiler/eval:Ptr", i64 } %t390, ptr %l30
  %t391 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l30, i32 0, i32 0
  %t392 = load %"compiler/eval:Ptr", ptr %t391
  store %"compiler/eval:Ptr" %t392, ptr %l31
  %t394 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l30, i32 0, i32 1
  %t395 = load i64, ptr %t394, !tbaa !24
  store i64 %t395, ptr %l32, !tbaa !24
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t398 = load i32, ptr %l28, !tbaa !23
  %t401 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t397, i32 %t398)
  store i32 %t401, ptr %l252
  br label %bb92
bb92:
  %t402 = load i32, ptr %l252, !tbaa !23
  store i32 %t402, ptr %l33, !tbaa !23
  %t403 = getelementptr %"compiler/eval:Ptr", ptr %l31, i32 0, i32 0
  %t404 = load i64, ptr %t403, !tbaa !24
  %t406 = icmp eq i64 %t404, 0
  br i1 %t406, label %bb93, label %bb94
bb93:
  %t408 = load i64, ptr %l24, !tbaa !24
  store i64 %t408, ptr %l255, !tbaa !24
  %t410 = call i8 @std_2fffi_2eCode(i32 7)
  store i8 %t410, ptr %l257
  br label %bb95
bb94:
  br label %bb96
bb95:
  %t411 = load i8, ptr %l257, !tbaa !22
  %t412 = load i64, ptr %l255, !tbaa !24
  %t413 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr i8, ptr %t414, i64 %t412
  store i8 %t411, ptr %t415, !tbaa !32
  %t416 = load i64, ptr %l18, !tbaa !24
  %t418 = add i64 %t416, 1
  store i64 %t418, ptr %l18, !tbaa !24
  br label %bb140
bb96:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t421 = load i32, ptr %l33, !tbaa !23
  %t424 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %t420, i32 %t421, i1 false)
  store i1 %t424, ptr %l262
  br label %bb97
bb97:
  %t425 = load i1, ptr %l262, !tbaa !21
  br i1 %t425, label %bb98, label %bb99
bb98:
  %t426 = load i64, ptr %l24, !tbaa !24
  store i64 %t426, ptr %l263, !tbaa !24
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l33, !tbaa !23
  %t431 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %t427, i32 %t428)
  store i32 %t431, ptr %l266
  br label %bb100
bb99:
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i32, ptr %l33, !tbaa !23
  %t436 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %t432, i32 %t433)
  store i1 %t436, ptr %l270
  br label %bb102
bb100:
  %t437 = load i32, ptr %l266
  %t438 = call i8 @std_2fffi_2eArrayOf(i32 %t437)
  store i8 %t438, ptr %l267
  br label %bb101
bb101:
  %t439 = load i8, ptr %l267, !tbaa !22
  %t440 = load i64, ptr %l263, !tbaa !24
  %t441 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr i8, ptr %t442, i64 %t440
  store i8 %t439, ptr %t443, !tbaa !32
  br label %bb108
bb102:
  %t444 = load i1, ptr %l270, !tbaa !21
  br i1 %t444, label %bb103, label %bb104
bb103:
  %t445 = load i64, ptr %l24, !tbaa !24
  store i64 %t445, ptr %l271, !tbaa !24
  %t447 = call i8 @std_2fffi_2eArrayOf(i32 4)
  store i8 %t447, ptr %l273
  br label %bb105
bb104:
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t450 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t450, ptr %t448, { i64, ptr } %t449)
  br label %bb106
bb105:
  %t453 = load i8, ptr %l273, !tbaa !22
  %t454 = load i64, ptr %l271, !tbaa !24
  %t455 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t456 = load ptr, ptr %t455, !tbaa !27
  %t457 = getelementptr i8, ptr %t456, i64 %t454
  store i8 %t453, ptr %t457, !tbaa !32
  br label %bb107
bb106:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb107:
  br label %bb108
bb108:
  %t459 = load i64, ptr %l24, !tbaa !24
  %t460 = load %"compiler/eval:Ptr", ptr %l31
  %t463 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t464 = load ptr, ptr %t463, !tbaa !27
  %t465 = getelementptr %"compiler/eval:Ptr", ptr %t464, i64 %t459
  store %"compiler/eval:Ptr" %t460, ptr %t465
  %t466 = load i64, ptr %l24, !tbaa !24
  store i64 %t466, ptr %l279, !tbaa !24
  %t467 = load i64, ptr %l32, !tbaa !24
  store i64 %t467, ptr %l280, !tbaa !24
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load i32, ptr %l33, !tbaa !23
  %t472 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t468, i32 %t469)
  store i64 %t472, ptr %l283
  br label %bb109
bb109:
  %t473 = load i64, ptr %l280, !tbaa !24
  %t474 = load i64, ptr %l283, !tbaa !24
  %t475 = mul i64 %t473, %t474
  %t477 = load i64, ptr %l279, !tbaa !24
  %t478 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t479 = load ptr, ptr %t478, !tbaa !27
  %t480 = getelementptr i64, ptr %t479, i64 %t477
  store i64 %t475, ptr %t480, !tbaa !34
  %t481 = load i64, ptr %l18, !tbaa !24
  store i64 %t481, ptr %l285, !tbaa !24
  %t482 = load i64, ptr %l24, !tbaa !24
  %t484 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !27
  %t486 = getelementptr i64, ptr %t485, i64 %t482
  %t487 = load i64, ptr %t486, !tbaa !34
  %t489 = call i64 @std_2fffi_2eWordsFor(i64 %t487)
  store i64 %t489, ptr %l288
  br label %bb110
bb110:
  %t490 = load i64, ptr %l288, !tbaa !24
  %t491 = add i64 1, %t490
  %t492 = load i64, ptr %l285, !tbaa !24
  %t494 = add i64 %t492, %t491
  store i64 %t494, ptr %l18, !tbaa !24
  br label %bb140
bb111:
  %t496 = load i64, ptr %l29, !tbaa !24
  %t497 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t500 = icmp eq i64 %t496, %t497
  br i1 %t500, label %bb112, label %bb113
bb112:
  %t502 = load ptr, ptr %l0, !tbaa !29
  store ptr %t502, ptr %l294, !tbaa !29
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load i64, ptr %l1, !tbaa !24
  %t505 = load { i64, [4 x i64] }, ptr %l25
  %t509 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t503, i64 %t504, { i64, [4 x i64] } %t505, i64 1)
  store %"compiler/eval:Ptr" %t509, ptr %l298
  br label %bb114
bb113:
  br label %bb138
bb114:
  %t510 = load ptr, ptr %l294, !tbaa !29
  %t511 = load %"compiler/eval:Ptr", ptr %l298
  %t512 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t510, %"compiler/eval:Ptr" %t511)
  store %"compiler/eval:Ptr" %t512, ptr %l299
  br label %bb115
bb115:
  %t513 = load %"compiler/eval:Ptr", ptr %l299
  store %"compiler/eval:Ptr" %t513, ptr %l34
  %t514 = load i64, ptr %l24, !tbaa !24
  store i64 %t514, ptr %l300, !tbaa !24
  %t516 = call i8 @std_2fffi_2eCode(i32 7)
  store i8 %t516, ptr %l302
  br label %bb116
bb116:
  %t517 = load i8, ptr %l302, !tbaa !22
  %t518 = load i64, ptr %l300, !tbaa !24
  %t519 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr i8, ptr %t520, i64 %t518
  store i8 %t517, ptr %t521, !tbaa !32
  %t522 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t523 = load i64, ptr %t522, !tbaa !24
  %t525 = icmp eq i64 %t523, 0
  br i1 %t525, label %bb117, label %bb118
bb117:
  %t527 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 1
  %t528 = load i64, ptr %t527, !tbaa !24
  %t530 = icmp eq i64 %t528, 0
  store i1 %t530, ptr %l305, !tbaa !21
  br label %bb119
bb118:
  store i1 false, ptr %l305, !tbaa !21
  br label %bb119
bb119:
  %t532 = load i1, ptr %l305, !tbaa !21
  br i1 %t532, label %bb120, label %bb121
bb120:
  %t533 = load i64, ptr %l24, !tbaa !24
  %t535 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr i64, ptr %t536, i64 %t533
  store i64 0, ptr %t537, !tbaa !85
  %t538 = load i64, ptr %l18, !tbaa !24
  %t540 = add i64 %t538, 1
  store i64 %t540, ptr %l18, !tbaa !24
  br label %bb140
bb121:
  br label %bb122
bb122:
  %t542 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t543 = load i64, ptr %t542, !tbaa !24
  %t544 = load i64, ptr @G_2ecompiler_2feval_2eForeignId, !tbaa !24
  %t547 = icmp eq i64 %t543, %t544
  br i1 %t547, label %bb123, label %bb124
bb123:
  %t549 = load i64, ptr %l24, !tbaa !24
  %t550 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 1
  %t551 = load i64, ptr %t550, !tbaa !24
  %t555 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t556 = load ptr, ptr %t555, !tbaa !27
  %t557 = getelementptr i64, ptr %t556, i64 %t549
  store i64 %t551, ptr %t557, !tbaa !85
  %t558 = load i64, ptr %l18, !tbaa !24
  %t560 = add i64 %t558, 1
  store i64 %t560, ptr %l18, !tbaa !24
  br label %bb140
bb124:
  br label %bb125
bb125:
  %t562 = load ptr, ptr %l9, !tbaa !29
  store ptr %t562, ptr %l319, !tbaa !29
  %t563 = load ptr, ptr %l9, !tbaa !29
  %t564 = load i32, ptr %l28, !tbaa !23
  %t567 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t563, i32 %t564)
  store i32 %t567, ptr %l322
  br label %bb126
bb126:
  %t568 = load ptr, ptr %l319, !tbaa !29
  %t569 = load i32, ptr %l322, !tbaa !23
  %t570 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t568, i32 %t569)
  store i32 %t570, ptr %l323
  br label %bb127
bb127:
  %t571 = load i32, ptr %l323, !tbaa !23
  store i32 %t571, ptr %l35, !tbaa !23
  %t572 = getelementptr %"compiler/eval:Ptr", ptr %l34, i32 0, i32 0
  %t573 = load i64, ptr %t572, !tbaa !24
  %t575 = icmp ne i64 %t573, 0
  br i1 %t575, label %bb128, label %bb129
bb128:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load i32, ptr %l35, !tbaa !23
  %t581 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %t577, i32 %t578)
  store i1 %t581, ptr %l329
  br label %bb130
bb129:
  store i1 false, ptr %l326, !tbaa !21
  br label %bb131
bb130:
  %t582 = load i1, ptr %l329, !tbaa !21
  store i1 %t582, ptr %l326, !tbaa !21
  br label %bb131
bb131:
  %t583 = load i1, ptr %l326, !tbaa !21
  br i1 %t583, label %bb132, label %bb133
bb132:
  %t584 = load i64, ptr %l24, !tbaa !24
  store i64 %t584, ptr %l330, !tbaa !24
  %t586 = call i8 @std_2fffi_2eArrayOf(i32 4)
  store i8 %t586, ptr %l332
  br label %bb134
bb133:
  br label %bb137
bb134:
  %t587 = load i8, ptr %l332, !tbaa !22
  %t588 = load i64, ptr %l330, !tbaa !24
  %t589 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t590 = load ptr, ptr %t589, !tbaa !27
  %t591 = getelementptr i8, ptr %t590, i64 %t588
  store i8 %t587, ptr %t591, !tbaa !32
  %t592 = load i64, ptr %l24, !tbaa !24
  %t593 = load %"compiler/eval:Ptr", ptr %l34
  %t596 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t597 = load ptr, ptr %t596, !tbaa !27
  %t598 = getelementptr %"compiler/eval:Ptr", ptr %t597, i64 %t592
  store %"compiler/eval:Ptr" %t593, ptr %t598
  %t599 = load i64, ptr %l24, !tbaa !24
  store i64 %t599, ptr %l335, !tbaa !24
  %t600 = load ptr, ptr %l0, !tbaa !29
  %t601 = load i32, ptr %l35, !tbaa !23
  %t604 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t600, i32 %t601)
  store i64 %t604, ptr %l338
  br label %bb135
bb135:
  %t605 = load i64, ptr %l338, !tbaa !24
  %t606 = load i64, ptr %l335, !tbaa !24
  %t607 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t608 = load ptr, ptr %t607, !tbaa !27
  %t609 = getelementptr i64, ptr %t608, i64 %t606
  store i64 %t605, ptr %t609, !tbaa !34
  %t610 = load i64, ptr %l18, !tbaa !24
  store i64 %t610, ptr %l339, !tbaa !24
  %t611 = load i64, ptr %l24, !tbaa !24
  %t613 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr i64, ptr %t614, i64 %t611
  %t616 = load i64, ptr %t615, !tbaa !34
  %t618 = call i64 @std_2fffi_2eWordsFor(i64 %t616)
  store i64 %t618, ptr %l342
  br label %bb136
bb136:
  %t619 = load i64, ptr %l342, !tbaa !24
  %t620 = add i64 1, %t619
  %t621 = load i64, ptr %l339, !tbaa !24
  %t623 = add i64 %t621, %t620
  store i64 %t623, ptr %l18, !tbaa !24
  br label %bb140
bb137:
  br label %bb138
bb138:
  %t625 = load ptr, ptr %l0, !tbaa !29
  %t626 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t627 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t627, ptr %t625, { i64, ptr } %t626)
  br label %bb139
bb139:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb140:
  %t631 = load i64, ptr %l23, !tbaa !24
  %t633 = add i64 %t631, 1
  store i64 %t633, ptr %l23, !tbaa !24
  br label %bb62
bb141:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/eval:Machine", ptr %t635, i32 0, i32 13
  %t638 = load i1, ptr %t637, !tbaa !21
  br i1 %t638, label %bb142, label %bb143
bb142:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb143:
  br label %bb144
bb144:
  %t641 = load i64, ptr %l18, !tbaa !24
  store i64 %t641, ptr %l353, !tbaa !24
  %t642 = load i64, ptr %l353, !tbaa !24
  %t643 = icmp sge i64 %t642, 0
  br i1 %t643, label %bb145, label %bb146
bb145:
  %t645 = load i64, ptr %l353, !tbaa !24
  %t646 = icmp sle i64 %t645, 1152921504606846975
  br i1 %t646, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_84b043302e365534_8c4896c766887f8)
  unreachable
bb147:
  %t648 = load i64, ptr %l353, !tbaa !24
  %t649 = mul i64 %t648, 8
  %t650 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t649)
  %t651 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t652 = insertvalue { i64, ptr } %t651, ptr %t650, 1
  store { i64, ptr } %t652, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  %t654 = load i64, ptr %l13, !tbaa !24
  store i64 %t654, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t656 = load i64, ptr %l39, !tbaa !24
  %t657 = load i64, ptr %l38, !tbaa !24
  %t660 = icmp sgt i64 %t656, %t657
  br i1 %t660, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_84b043302e365534_8c4896c766887f8)
  unreachable
bb149:
  %t662 = load i64, ptr %l40, !tbaa !24
  %t664 = icmp sgt i64 %t662, 0
  br i1 %t664, label %bb151, label %bb152
bb150:
  store i64 0, ptr %l361, !tbaa !24
  br label %bb154
bb151:
  %t666 = load i64, ptr %l39, !tbaa !24
  %t667 = load i64, ptr %l38, !tbaa !24
  %t670 = sub i64 %t666, %t667
  %t671 = load i64, ptr %l40, !tbaa !24
  %t674 = add i64 %t670, %t671
  %t676 = sub i64 %t674, 1
  %t677 = load i64, ptr %l40, !tbaa !24
  %t680 = sdiv i64 %t676, %t677
  store i64 %t680, ptr %l364, !tbaa !24
  br label %bb153
bb152:
  store i64 0, ptr %l364, !tbaa !24
  br label %bb153
bb153:
  %t682 = load i64, ptr %l364, !tbaa !24
  store i64 %t682, ptr %l361, !tbaa !24
  br label %bb154
bb154:
  %t683 = load i64, ptr %l361, !tbaa !24
  store i64 %t683, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb155
bb155:
  %t684 = load i64, ptr %l42, !tbaa !24
  %t685 = load i64, ptr %l41, !tbaa !24
  %t688 = icmp slt i64 %t684, %t685
  %t690 = xor i1 %t688, true
  br i1 %t690, label %bb156, label %bb157
bb156:
  br label %bb183
bb157:
  br label %bb158
bb158:
  %t692 = load i64, ptr %l38, !tbaa !24
  %t693 = load i64, ptr %l42, !tbaa !24
  %t694 = load i64, ptr %l40, !tbaa !24
  %t697 = mul i64 %t693, %t694
  %t700 = add i64 %t692, %t697
  store i64 %t700, ptr %l43, !tbaa !24
  %t702 = load i64, ptr %l43, !tbaa !24
  %t704 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t705 = load ptr, ptr %t704, !tbaa !27
  %t706 = getelementptr i64, ptr %t705, i64 %t702
  %t707 = load i64, ptr %t706, !tbaa !34
  %t709 = icmp sge i64 %t707, 0
  br i1 %t709, label %bb159, label %bb160
bb159:
  %t711 = load i64, ptr %l43, !tbaa !24
  %t713 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !27
  %t715 = getelementptr %"compiler/eval:Ptr", ptr %t714, i64 %t711
  %t716 = load %"compiler/eval:Ptr", ptr %t715
  store %"compiler/eval:Ptr" %t716, ptr %l44
  %t718 = load i64, ptr %l43, !tbaa !24
  %t720 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t721 = load ptr, ptr %t720, !tbaa !27
  %t722 = getelementptr i64, ptr %t721, i64 %t718
  %t723 = load i64, ptr %t722, !tbaa !34
  store i64 %t723, ptr %l45, !tbaa !24
  %t725 = load i64, ptr %l37, !tbaa !24
  store i64 %t725, ptr %l389, !tbaa !24
  %t726 = load i64, ptr %l43, !tbaa !24
  %t728 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !27
  %t730 = getelementptr i8, ptr %t729, i64 %t726
  %t731 = load i8, ptr %t730, !tbaa !32
  store i8 %t731, ptr %l391, !tbaa !22
  %t733 = call i8 @std_2fffi_2eArrayOf(i32 4)
  store i8 %t733, ptr %l393
  br label %bb161
bb160:
  %t734 = load i64, ptr %l37, !tbaa !24
  %t735 = load i64, ptr %l43, !tbaa !24
  %t737 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t738 = load ptr, ptr %t737, !tbaa !27
  %t739 = getelementptr i64, ptr %t738, i64 %t735
  %t740 = load i64, ptr %t739, !tbaa !85
  %t743 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t744 = load ptr, ptr %t743, !tbaa !27
  %t745 = getelementptr i64, ptr %t744, i64 %t734
  store i64 %t740, ptr %t745, !tbaa !85
  %t746 = load i64, ptr %l37, !tbaa !24
  %t748 = add i64 %t746, 1
  store i64 %t748, ptr %l37, !tbaa !24
  br label %bb181
bb161:
  %t750 = load i8, ptr %l391, !tbaa !22
  %t751 = load i8, ptr %l393, !tbaa !22
  %t752 = icmp eq i8 %t750, %t751
  br i1 %t752, label %bb162, label %bb163
bb162:
  %t754 = load i64, ptr %l45, !tbaa !24
  store i64 %t754, ptr %l395, !tbaa !65
  br label %bb165
bb163:
  %t757 = load i64, ptr %l45, !tbaa !24
  store i64 %t757, ptr %l398, !tbaa !24
  %t758 = load ptr, ptr %l0, !tbaa !29
  %t759 = load i64, ptr %l43, !tbaa !24
  %t761 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t762 = load ptr, ptr %t761, !tbaa !27
  %t763 = getelementptr i8, ptr %t762, i64 %t759
  %t764 = load i8, ptr %t763, !tbaa !32
  %t767 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ekindWidth(ptr %v0, ptr %t758, i8 %t764)
  store i64 %t767, ptr %l402
  br label %bb164
bb164:
  %t768 = load i64, ptr %l398, !tbaa !24
  %t769 = load i64, ptr %l402, !tbaa !24
  %t770 = sdiv i64 %t768, %t769
  store i64 %t770, ptr %l395, !tbaa !65
  br label %bb165
bb165:
  %t773 = load i64, ptr %l395, !tbaa !65
  %t774 = load i64, ptr %l389, !tbaa !24
  %t775 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t776 = load ptr, ptr %t775, !tbaa !27
  %t777 = getelementptr i64, ptr %t776, i64 %t774
  store i64 %t773, ptr %t777, !tbaa !85
  store i64 0, ptr %l46, !tbaa !24
  %t778 = load i64, ptr %l45, !tbaa !24
  store i64 %t778, ptr %l47, !tbaa !24
  store i64 1, ptr %l48, !tbaa !24
  %t780 = load i64, ptr %l47, !tbaa !24
  %t781 = load i64, ptr %l46, !tbaa !24
  %t784 = icmp sgt i64 %t780, %t781
  br i1 %t784, label %bb166, label %bb167
bb166:
  %t786 = load i64, ptr %l48, !tbaa !24
  %t788 = icmp sgt i64 %t786, 0
  br i1 %t788, label %bb168, label %bb169
bb167:
  store i64 0, ptr %l409, !tbaa !24
  br label %bb171
bb168:
  %t790 = load i64, ptr %l47, !tbaa !24
  %t791 = load i64, ptr %l46, !tbaa !24
  %t794 = sub i64 %t790, %t791
  %t795 = load i64, ptr %l48, !tbaa !24
  %t798 = add i64 %t794, %t795
  %t800 = sub i64 %t798, 1
  %t801 = load i64, ptr %l48, !tbaa !24
  %t804 = sdiv i64 %t800, %t801
  store i64 %t804, ptr %l412, !tbaa !24
  br label %bb170
bb169:
  store i64 0, ptr %l412, !tbaa !24
  br label %bb170
bb170:
  %t806 = load i64, ptr %l412, !tbaa !24
  store i64 %t806, ptr %l409, !tbaa !24
  br label %bb171
bb171:
  %t807 = load i64, ptr %l409, !tbaa !24
  store i64 %t807, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb172
bb172:
  store %olang.scope zeroinitializer, ptr %s26
  %t808 = load i64, ptr %l50, !tbaa !24
  %t809 = load i64, ptr %l49, !tbaa !24
  %t812 = icmp slt i64 %t808, %t809
  %t814 = xor i1 %t812, true
  br i1 %t814, label %bb173, label %bb174
bb173:
  call void @__olang_scope_close(ptr %s26)
  br label %bb179
bb174:
  br label %bb175
bb175:
  %t816 = load i64, ptr %l46, !tbaa !24
  %t817 = load i64, ptr %l50, !tbaa !24
  %t818 = load i64, ptr %l48, !tbaa !24
  %t821 = mul i64 %t817, %t818
  %t824 = add i64 %t816, %t821
  store i64 %t824, ptr %l51, !tbaa !24
  %t826 = load ptr, ptr %l0, !tbaa !29
  store ptr %t826, ptr %l430, !tbaa !29
  %t827 = getelementptr %"compiler/eval:Ptr", ptr %l44, i32 0, i32 0
  %t828 = load i64, ptr %t827, !tbaa !24
  %t829 = getelementptr %"compiler/eval:Ptr", ptr %l44, i32 0, i32 1
  %t830 = load i64, ptr %t829, !tbaa !24
  %t831 = load i64, ptr %l51, !tbaa !24
  %t834 = add i64 %t830, %t831
  %t837 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s26, i64 %t828, i64 %t834)
  store %"compiler/eval:Ptr" %t837, ptr %l435
  br label %bb176
bb176:
  %t838 = load ptr, ptr %l430, !tbaa !29
  %t839 = load %"compiler/eval:Ptr", ptr %l435
  %t840 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t838, %"compiler/eval:Ptr" %t839, i64 1)
  store i64 %t840, ptr %l436
  br label %bb177
bb177:
  %t841 = load i64, ptr %l436, !tbaa !24
  %t843 = load i64, ptr %l37, !tbaa !24
  %t845 = add i64 %t843, 1
  %t846 = load i64, ptr %l51, !tbaa !24
  %t848 = sdiv i64 %t846, 8
  %t851 = add i64 %t845, %t848
  %t852 = load i64, ptr %l37, !tbaa !24
  %t854 = add i64 %t852, 1
  %t855 = load i64, ptr %l51, !tbaa !24
  %t857 = sdiv i64 %t855, 8
  %t860 = add i64 %t854, %t857
  %t862 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t863 = load ptr, ptr %t862, !tbaa !27
  %t864 = getelementptr i64, ptr %t863, i64 %t860
  %t865 = load i64, ptr %t864, !tbaa !85
  %t867 = load i64, ptr %l51, !tbaa !24
  %t869 = srem i64 %t867, 8
  %t872 = mul i64 %t869, 8
  store i64 %t872, ptr %l453, !tbaa !65
  %t874 = load i64, ptr %l453, !tbaa !65
  %t875 = load i64, ptr %l453, !tbaa !65
  %t876 = shl i64 %t841, %t875
  %t879 = or i64 %t865, %t876
  %t882 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !27
  %t884 = getelementptr i64, ptr %t883, i64 %t851
  store i64 %t879, ptr %t884, !tbaa !85
  call void @__olang_scope_close(ptr %s26)
  br label %bb178
bb178:
  %t885 = load i64, ptr %l50, !tbaa !24
  %t887 = add i64 %t885, 1
  store i64 %t887, ptr %l50, !tbaa !24
  br label %bb172
bb179:
  %t889 = load i64, ptr %l37, !tbaa !24
  store i64 %t889, ptr %l458, !tbaa !24
  %t890 = load i64, ptr %l45, !tbaa !24
  %t892 = call i64 @std_2fffi_2eWordsFor(i64 %t890)
  store i64 %t892, ptr %l460
  br label %bb180
bb180:
  %t893 = load i64, ptr %l460, !tbaa !24
  %t894 = add i64 1, %t893
  %t895 = load i64, ptr %l458, !tbaa !24
  %t897 = add i64 %t895, %t894
  store i64 %t897, ptr %l37, !tbaa !24
  br label %bb181
bb181:
  br label %bb182
bb182:
  %t899 = load i64, ptr %l42, !tbaa !24
  %t901 = add i64 %t899, 1
  store i64 %t901, ptr %l42, !tbaa !24
  br label %bb155
bb183:
  %t903 = load i32, ptr %l11, !tbaa !23
  %t904 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t907 = icmp eq i32 %t903, %t904
  br i1 %t907, label %bb184, label %bb185
bb184:
  store i1 true, ptr %l473, !tbaa !21
  br label %bb186
bb185:
  %t909 = load i32, ptr %l11, !tbaa !23
  %t910 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t913 = icmp eq i32 %t909, %t910
  store i1 %t913, ptr %l473, !tbaa !21
  br label %bb186
bb186:
  %t915 = load i1, ptr %l473, !tbaa !21
  br i1 %t915, label %bb187, label %bb188
bb187:
  store i8 0, ptr %l477, !tbaa !22
  br label %bb195
bb188:
  %t916 = load i1, ptr %l12, !tbaa !21
  br i1 %t916, label %bb189, label %bb190
bb189:
  %t919 = call i8 @std_2fffi_2eCode(i32 7)
  store i8 %t919, ptr %l481
  br label %bb191
bb190:
  %t920 = load ptr, ptr %l0, !tbaa !29
  %t921 = load i32, ptr %l11, !tbaa !23
  %t924 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %t920, i32 %t921)
  store i32 %t924, ptr %l484
  br label %bb192
bb191:
  %t925 = load i8, ptr %l481, !tbaa !22
  store i8 %t925, ptr %l479, !tbaa !22
  br label %bb194
bb192:
  %t926 = load i32, ptr %l484
  %t927 = call i8 @std_2fffi_2eCode(i32 %t926)
  store i8 %t927, ptr %l485
  br label %bb193
bb193:
  %t928 = load i8, ptr %l485, !tbaa !22
  store i8 %t928, ptr %l479, !tbaa !22
  br label %bb194
bb194:
  %t929 = load i8, ptr %l479, !tbaa !22
  store i8 %t929, ptr %l477, !tbaa !22
  br label %bb195
bb195:
  %t930 = load i8, ptr %l477, !tbaa !22
  store i8 %t930, ptr %l53, !tbaa !22
  %t931 = load ptr, ptr %l0, !tbaa !29
  %t933 = getelementptr %"compiler/eval:Machine", ptr %t931, i32 0, i32 26
  %t934 = load i64, ptr %l2, !tbaa !24
  %t937 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t933, i64 %t934)
  %t938 = extractvalue { i32, i64 } %t937, 1
  %t939 = extractvalue { i32, i64 } %t937, 0
  store i32 %t939, ptr %l491
  %t940 = icmp ne i32 %t939, 0
  br i1 %t940, label %bb197, label %ok.941, !prof !99
ok.941:
  store i64 %t938, ptr %l490
  br label %bb196
bb196:
  %t942 = load i64, ptr %l490, !tbaa !24
  store i64 %t942, ptr %l486, !tbaa !24
  br label %bb199
bb197:
  br label %bb198
bb198:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l486, !tbaa !24
  br label %bb199
bb199:
  %t943 = load i64, ptr %l486, !tbaa !24
  %t944 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t945 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t946 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t947 = load i8, ptr %l53, !tbaa !22
  %t954 = call { i32, i64 } @std_2fffi_2eCall(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t944, { i64, ptr } %t945, { i64, ptr } %t946, i8 %t947, i64 %t943)
  %t955 = extractvalue { i32, i64 } %t954, 1
  %t956 = extractvalue { i32, i64 } %t954, 0
  store i32 %t956, ptr %l499
  %t957 = icmp ne i32 %t956, 0
  br i1 %t957, label %bb201, label %ok.958, !prof !99
ok.958:
  store i64 %t955, ptr %l498
  br label %bb200
bb200:
  %t959 = load i64, ptr %l498, !tbaa !65
  store i64 %t959, ptr %l492, !tbaa !65
  br label %bb208
bb201:
  %t960 = load i32, ptr %l499, !tbaa !23
  %t961 = icmp eq i32 %t960, 65536
  br i1 %t961, label %bb202, label %bb203
bb202:
  br label %bb204
bb203:
  br label %bb205
bb204:
  call void @__olang_ert_req_clear()
  %t963 = load ptr, ptr %l0, !tbaa !29
  %t964 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiFind, !tbaa !27
  %t965 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t965, ptr %t963, { i64, ptr } %t964)
  br label %bb206
bb205:
  call void @__olang_ert_req_clear()
  %t968 = load ptr, ptr %l0, !tbaa !29
  %t969 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiPass, !tbaa !27
  %t970 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t970, ptr %t968, { i64, ptr } %t969)
  br label %bb207
bb206:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb207:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb208:
  %t975 = load i64, ptr %l492, !tbaa !65
  store i64 %t975, ptr %l55, !tbaa !65
  %t976 = load ptr, ptr %l0, !tbaa !29
  store ptr %t976, ptr %l507, !tbaa !29
  %t977 = call i32 @__olang_err()
  store i32 %t977, ptr %l508
  br label %bb209
bb209:
  %t978 = load i32, ptr %l508, !tbaa !23
  %t979 = load ptr, ptr %l507, !tbaa !29
  %t980 = getelementptr %"compiler/eval:Machine", ptr %t979, i32 0, i32 81
  store i32 %t978, ptr %t980, !tbaa !23
  store i64 0, ptr %l37, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  %t981 = load i64, ptr %l13, !tbaa !24
  store i64 %t981, ptr %l57, !tbaa !24
  store i64 1, ptr %l58, !tbaa !24
  %t983 = load i64, ptr %l57, !tbaa !24
  %t984 = load i64, ptr %l56, !tbaa !24
  %t987 = icmp sgt i64 %t983, %t984
  br i1 %t987, label %bb210, label %bb211
bb210:
  %t989 = load i64, ptr %l58, !tbaa !24
  %t991 = icmp sgt i64 %t989, 0
  br i1 %t991, label %bb212, label %bb213
bb211:
  store i64 0, ptr %l513, !tbaa !24
  br label %bb215
bb212:
  %t993 = load i64, ptr %l57, !tbaa !24
  %t994 = load i64, ptr %l56, !tbaa !24
  %t997 = sub i64 %t993, %t994
  %t998 = load i64, ptr %l58, !tbaa !24
  %t1001 = add i64 %t997, %t998
  %t1003 = sub i64 %t1001, 1
  %t1004 = load i64, ptr %l58, !tbaa !24
  %t1007 = sdiv i64 %t1003, %t1004
  store i64 %t1007, ptr %l516, !tbaa !24
  br label %bb214
bb213:
  store i64 0, ptr %l516, !tbaa !24
  br label %bb214
bb214:
  %t1009 = load i64, ptr %l516, !tbaa !24
  store i64 %t1009, ptr %l513, !tbaa !24
  br label %bb215
bb215:
  %t1010 = load i64, ptr %l513, !tbaa !24
  store i64 %t1010, ptr %l59, !tbaa !24
  store i64 0, ptr %l60, !tbaa !24
  br label %bb216
bb216:
  %t1011 = load i64, ptr %l60, !tbaa !24
  %t1012 = load i64, ptr %l59, !tbaa !24
  %t1015 = icmp slt i64 %t1011, %t1012
  %t1017 = xor i1 %t1015, true
  br i1 %t1017, label %bb217, label %bb218
bb217:
  br label %bb242
bb218:
  br label %bb219
bb219:
  %t1019 = load i64, ptr %l56, !tbaa !24
  %t1020 = load i64, ptr %l60, !tbaa !24
  %t1021 = load i64, ptr %l58, !tbaa !24
  %t1024 = mul i64 %t1020, %t1021
  %t1027 = add i64 %t1019, %t1024
  store i64 %t1027, ptr %l61, !tbaa !24
  %t1029 = load i64, ptr %l61, !tbaa !24
  %t1031 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t1032 = load ptr, ptr %t1031, !tbaa !27
  %t1033 = getelementptr i64, ptr %t1032, i64 %t1029
  %t1034 = load i64, ptr %t1033, !tbaa !34
  %t1036 = icmp sge i64 %t1034, 0
  br i1 %t1036, label %bb220, label %bb221
bb220:
  %t1038 = load i64, ptr %l61, !tbaa !24
  %t1040 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t1041 = load ptr, ptr %t1040, !tbaa !27
  %t1042 = getelementptr %"compiler/eval:Ptr", ptr %t1041, i64 %t1038
  %t1043 = load %"compiler/eval:Ptr", ptr %t1042
  store %"compiler/eval:Ptr" %t1043, ptr %l62
  %t1045 = load i64, ptr %l61, !tbaa !24
  %t1047 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t1048 = load ptr, ptr %t1047, !tbaa !27
  %t1049 = getelementptr i64, ptr %t1048, i64 %t1045
  %t1050 = load i64, ptr %t1049, !tbaa !34
  store i64 %t1050, ptr %l63, !tbaa !24
  %t1052 = load ptr, ptr %l0, !tbaa !29
  %t1054 = getelementptr %"compiler/eval:Machine", ptr %t1052, i32 0, i32 40
  %t1055 = load { i64, ptr }, ptr %t1054, !tbaa !27
  store { i64, ptr } %t1055, ptr %l542, !tbaa !27
  %t1056 = getelementptr %"compiler/eval:Ptr", ptr %l62, i32 0, i32 0
  %t1057 = load i64, ptr %t1056, !tbaa !24
  %t1058 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t1061 = and i64 %t1057, %t1058
  %t1063 = getelementptr { i64, ptr }, ptr %l542, i32 0, i32 1
  %t1064 = load ptr, ptr %t1063, !tbaa !27
  %t1065 = getelementptr %"compiler/eval:alloc", ptr %t1064, i64 %t1061
  %t1066 = getelementptr %"compiler/eval:alloc", ptr %t1065, i32 0, i32 10
  %t1067 = load i1, ptr %t1066, !tbaa !21
  %t1069 = icmp eq i1 %t1067, false
  br i1 %t1069, label %bb222, label %bb223
bb221:
  %t1071 = load i64, ptr %l37, !tbaa !24
  %t1073 = add i64 %t1071, 1
  store i64 %t1073, ptr %l37, !tbaa !24
  br label %bb240
bb222:
  store i64 0, ptr %l64, !tbaa !24
  %t1075 = load i64, ptr %l63, !tbaa !24
  store i64 %t1075, ptr %l65, !tbaa !24
  store i64 1, ptr %l66, !tbaa !24
  %t1077 = load i64, ptr %l65, !tbaa !24
  %t1078 = load i64, ptr %l64, !tbaa !24
  %t1081 = icmp sgt i64 %t1077, %t1078
  br i1 %t1081, label %bb224, label %bb225
bb223:
  br label %bb238
bb224:
  %t1083 = load i64, ptr %l66, !tbaa !24
  %t1085 = icmp sgt i64 %t1083, 0
  br i1 %t1085, label %bb226, label %bb227
bb225:
  store i64 0, ptr %l552, !tbaa !24
  br label %bb229
bb226:
  %t1087 = load i64, ptr %l65, !tbaa !24
  %t1088 = load i64, ptr %l64, !tbaa !24
  %t1091 = sub i64 %t1087, %t1088
  %t1092 = load i64, ptr %l66, !tbaa !24
  %t1095 = add i64 %t1091, %t1092
  %t1097 = sub i64 %t1095, 1
  %t1098 = load i64, ptr %l66, !tbaa !24
  %t1101 = sdiv i64 %t1097, %t1098
  store i64 %t1101, ptr %l555, !tbaa !24
  br label %bb228
bb227:
  store i64 0, ptr %l555, !tbaa !24
  br label %bb228
bb228:
  %t1103 = load i64, ptr %l555, !tbaa !24
  store i64 %t1103, ptr %l552, !tbaa !24
  br label %bb229
bb229:
  %t1104 = load i64, ptr %l552, !tbaa !24
  store i64 %t1104, ptr %l67, !tbaa !24
  store i64 0, ptr %l68, !tbaa !24
  br label %bb230
bb230:
  store %olang.scope zeroinitializer, ptr %s37
  %t1105 = load i64, ptr %l68, !tbaa !24
  %t1106 = load i64, ptr %l67, !tbaa !24
  %t1109 = icmp slt i64 %t1105, %t1106
  %t1111 = xor i1 %t1109, true
  br i1 %t1111, label %bb231, label %bb232
bb231:
  call void @__olang_scope_close(ptr %s37)
  br label %bb237
bb232:
  br label %bb233
bb233:
  %t1113 = load i64, ptr %l64, !tbaa !24
  %t1114 = load i64, ptr %l68, !tbaa !24
  %t1115 = load i64, ptr %l66, !tbaa !24
  %t1118 = mul i64 %t1114, %t1115
  %t1121 = add i64 %t1113, %t1118
  store i64 %t1121, ptr %l69, !tbaa !24
  %t1123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1123, ptr %l573, !tbaa !29
  %t1124 = getelementptr %"compiler/eval:Ptr", ptr %l62, i32 0, i32 0
  %t1125 = load i64, ptr %t1124, !tbaa !24
  %t1126 = getelementptr %"compiler/eval:Ptr", ptr %l62, i32 0, i32 1
  %t1127 = load i64, ptr %t1126, !tbaa !24
  %t1128 = load i64, ptr %l69, !tbaa !24
  %t1131 = add i64 %t1127, %t1128
  %t1134 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s37, i64 %t1125, i64 %t1131)
  store %"compiler/eval:Ptr" %t1134, ptr %l578
  br label %bb234
bb234:
  %t1135 = load i64, ptr %l37, !tbaa !24
  %t1137 = add i64 %t1135, 1
  %t1138 = load i64, ptr %l69, !tbaa !24
  %t1140 = sdiv i64 %t1138, 8
  %t1143 = add i64 %t1137, %t1140
  %t1145 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t1146 = load ptr, ptr %t1145, !tbaa !27
  %t1147 = getelementptr i64, ptr %t1146, i64 %t1143
  %t1148 = load i64, ptr %t1147, !tbaa !85
  %t1149 = load i64, ptr %l69, !tbaa !24
  %t1151 = srem i64 %t1149, 8
  %t1154 = mul i64 %t1151, 8
  store i64 %t1154, ptr %l588, !tbaa !65
  %t1156 = load i64, ptr %l588, !tbaa !65
  %t1157 = load i64, ptr %l588, !tbaa !65
  %t1158 = lshr i64 %t1148, %t1157
  %t1160 = and i64 %t1158, 255
  %t1162 = load ptr, ptr %l573, !tbaa !29
  %t1163 = load %"compiler/eval:Ptr", ptr %l578
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t1162, %"compiler/eval:Ptr" %t1163, i64 1, i64 %t1160)
  br label %bb235
bb235:
  call void @__olang_scope_close(ptr %s37)
  br label %bb236
bb236:
  %t1165 = load i64, ptr %l68, !tbaa !24
  %t1167 = add i64 %t1165, 1
  store i64 %t1167, ptr %l68, !tbaa !24
  br label %bb230
bb237:
  br label %bb238
bb238:
  %t1169 = load i64, ptr %l37, !tbaa !24
  store i64 %t1169, ptr %l594, !tbaa !24
  %t1170 = load i64, ptr %l63, !tbaa !24
  %t1172 = call i64 @std_2fffi_2eWordsFor(i64 %t1170)
  store i64 %t1172, ptr %l596
  br label %bb239
bb239:
  %t1173 = load i64, ptr %l596, !tbaa !24
  %t1174 = add i64 1, %t1173
  %t1175 = load i64, ptr %l594, !tbaa !24
  %t1177 = add i64 %t1175, %t1174
  store i64 %t1177, ptr %l37, !tbaa !24
  br label %bb240
bb240:
  br label %bb241
bb241:
  %t1179 = load i64, ptr %l60, !tbaa !24
  %t1181 = add i64 %t1179, 1
  store i64 %t1181, ptr %l60, !tbaa !24
  br label %bb216
bb242:
  %t1183 = load i1, ptr %l6, !tbaa !21
  br i1 %t1183, label %bb243, label %bb244
bb243:
  %t1185 = load i1, ptr %l12, !tbaa !21
  store i1 %t1185, ptr %l604, !tbaa !21
  br label %bb245
bb244:
  store i1 false, ptr %l604, !tbaa !21
  br label %bb245
bb245:
  %t1187 = load i1, ptr %l604, !tbaa !21
  br i1 %t1187, label %bb246, label %bb247
bb246:
  store %olang.scope zeroinitializer, ptr %s41
  %t1188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1188, ptr %l606, !tbaa !29
  %t1189 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t1189, ptr %l607
  %t1190 = load i64, ptr %l55, !tbaa !65
  %t1192 = icmp eq i64 %t1190, 0
  br i1 %t1192, label %bb248, label %bb249
bb247:
  %t1194 = load i1, ptr %l6, !tbaa !21
  br i1 %t1194, label %bb253, label %bb254
bb248:
  %t1196 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t1196, ptr %l610
  br label %bb251
bb249:
  %t1198 = load i64, ptr @G_2ecompiler_2feval_2eForeignId, !tbaa !24
  %t1199 = load i64, ptr %l55, !tbaa !65
  %t1203 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s41, i64 %t1198, i64 %t1199)
  store %"compiler/eval:Ptr" %t1203, ptr %l615
  br label %bb250
bb250:
  %t1204 = load %"compiler/eval:Ptr", ptr %l615
  store %"compiler/eval:Ptr" %t1204, ptr %l610
  br label %bb251
bb251:
  %t1205 = load ptr, ptr %l606, !tbaa !29
  %t1206 = load %"compiler/eval:Ptr", ptr %l607
  %t1207 = load %"compiler/eval:Ptr", ptr %l610
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t1205, %"compiler/eval:Ptr" %t1206, %"compiler/eval:Ptr" %t1207)
  br label %bb252
bb252:
  call void @__olang_scope_close(ptr %s41)
  br label %bb264
bb253:
  %t1208 = load i32, ptr %l11, !tbaa !23
  %t1209 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1212 = icmp ne i32 %t1208, %t1209
  store i1 %t1212, ptr %l617, !tbaa !21
  br label %bb255
bb254:
  store i1 false, ptr %l617, !tbaa !21
  br label %bb255
bb255:
  %t1214 = load i1, ptr %l617, !tbaa !21
  br i1 %t1214, label %bb256, label %bb257
bb256:
  %t1215 = load i32, ptr %l11, !tbaa !23
  %t1216 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t1219 = icmp ne i32 %t1215, %t1216
  store i1 %t1219, ptr %l621, !tbaa !21
  br label %bb258
bb257:
  store i1 false, ptr %l621, !tbaa !21
  br label %bb258
bb258:
  %t1221 = load i1, ptr %l621, !tbaa !21
  br i1 %t1221, label %bb259, label %bb260
bb259:
  %t1222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1222, ptr %l625, !tbaa !29
  %t1223 = load %"compiler/eval:Ptr", ptr %l5
  store %"compiler/eval:Ptr" %t1223, ptr %l626
  %t1224 = load ptr, ptr %l0, !tbaa !29
  %t1225 = load i32, ptr %l11, !tbaa !23
  %t1228 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t1224, i32 %t1225)
  store i64 %t1228, ptr %l629
  br label %bb261
bb260:
  br label %bb263
bb261:
  %t1229 = load i64, ptr %l55, !tbaa !65
  %t1231 = load ptr, ptr %l625, !tbaa !29
  %t1232 = load %"compiler/eval:Ptr", ptr %l626
  %t1233 = load i64, ptr %l629, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t1231, %"compiler/eval:Ptr" %t1232, i64 %t1233, i64 %t1229)
  br label %bb262
bb262:
  br label %bb263
bb263:
  br label %bb264
bb264:
  %t1235 = load ptr, ptr %l0, !tbaa !29
  %t1237 = getelementptr %"compiler/eval:Machine", ptr %t1235, i32 0, i32 13
  %t1238 = load i1, ptr %t1237, !tbaa !21
  %t1240 = xor i1 %t1238, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t1240, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, %"compiler/eval:Ptr", i1, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallee(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [7 x i64] }
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, [4 x i64] }
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca %"compiler/eval:alloc"
  %l11 = alloca i64
  %l12 = alloca { i64, [4 x i64] }
  %l13 = alloca i64
  %l14 = alloca %"compiler/eval:Ptr"
  %l15 = alloca %"compiler/eval:Ptr"
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i32
  %l46 = alloca %"compiler/eval:Ptr"
  %l49 = alloca %"compiler/eval:Ptr"
  %l50 = alloca ptr
  %l54 = alloca %"compiler/eval:Ptr"
  %l55 = alloca %"compiler/eval:Ptr"
  %l68 = alloca %"compiler/eval:alloc"
  %l80 = alloca i64
  %l82 = alloca ptr
  %l86 = alloca { i64, [2 x i64] }
  %l87 = alloca i64
  %l88 = alloca i32
  %l103 = alloca %"compiler/eval:Ptr"
  %l104 = alloca ptr
  %l108 = alloca %"compiler/eval:Ptr"
  %l109 = alloca %"compiler/eval:Ptr"
  %l120 = alloca ptr
  %l128 = alloca %"compiler/eval:Ptr"
  %l129 = alloca %"compiler/eval:Ptr"
  %l136 = alloca i1
  %l139 = alloca %"compiler/eval:alloc"
  %l147 = alloca i64
  %l149 = alloca ptr
  %l151 = alloca ptr
  %l154 = alloca %"compiler/eval:alloc"
  %l156 = alloca { i64, [2 x i64] }
  %l157 = alloca i64
  %l158 = alloca i32
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca { i64, %"compiler/eval:Ptr", i1, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [7 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [7 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [7 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { { i64, [2 x i64] }, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [2 x i64] }, ptr %t7
  store { i64, [2 x i64] } %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb12
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 21
  %t13 = load { i64, [2 x i64] }, ptr %l3
  %t16 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t12, { i64, [2 x i64] } %t13)
  %t17 = extractvalue { i32, i64 } %t16, 1
  %t18 = extractvalue { i32, i64 } %t16, 0
  store i32 %t18, ptr %l26
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20, !prof !99
ok.20:
  store i64 %t17, ptr %l25
  br label %bb4
bb4:
  %t21 = load i64, ptr %l25, !tbaa !24
  store i64 %t21, ptr %l21, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l21, !tbaa !24
  br label %bb7
bb7:
  %t22 = load i64, ptr %l21, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp slt i64 %t23, 0
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t29 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t29, ptr %t27, { i64, ptr } %t28)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t35 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 %t32, 0
  %t37 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t35, %"compiler/eval:Ptr" %t33, 1
  %t38 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t37, i1 false, 2
  %t39 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t38, i64 0, 3
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t39, ptr %rv
  br label %ret
bb12:
  %t41 = load { i64, [7 x i64] }, ptr %l2
  %t43 = extractvalue { i64, [7 x i64] } %t41, 0
  %t44 = icmp eq i64 %t43, 1
  br i1 %t44, label %bb13, label %bb14
bb13:
  %t46 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t47 = getelementptr { i64, i32 }, ptr %t46, i32 0, i32 0
  %t48 = load i64, ptr %t47
  store i64 %t48, ptr %l5, !tbaa !24
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t50 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t54 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t52, %"compiler/eval:Ptr" %t50, 1
  %t55 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t54, i1 true, 2
  %t57 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t55, i64 %t51, 3
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t57, ptr %rv
  br label %ret
bb16:
  %t59 = load { i64, [7 x i64] }, ptr %l2
  %t61 = extractvalue { i64, [7 x i64] } %t59, 0
  %t62 = icmp eq i64 %t61, 2
  br i1 %t62, label %bb17, label %bb18
bb17:
  %t64 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t65 = getelementptr { { i64, [4 x i64] } }, ptr %t64, i32 0, i32 0
  %t66 = load { i64, [4 x i64] }, ptr %t65
  store { i64, [4 x i64] } %t66, ptr %l6
  br label %bb19
bb18:
  br label %bb48
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load i64, ptr %l1, !tbaa !24
  %t70 = load { i64, [4 x i64] }, ptr %l6
  %t74 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t68, i64 %t69, { i64, [4 x i64] } %t70, i64 3)
  store %"compiler/eval:Ptr" %t74, ptr %l46
  br label %bb20
bb20:
  %t75 = load %"compiler/eval:Ptr", ptr %l46
  store %"compiler/eval:Ptr" %t75, ptr %l7
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load %"compiler/eval:Ptr", ptr %l7
  %t80 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t76, %"compiler/eval:Ptr" %t77)
  store %"compiler/eval:Ptr" %t80, ptr %l49
  br label %bb21
bb21:
  %t81 = load %"compiler/eval:Ptr", ptr %l49
  store %"compiler/eval:Ptr" %t81, ptr %l8
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l50, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t84 = load i64, ptr %t83, !tbaa !24
  %t85 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = add i64 %t86, 8
  %t91 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t84, i64 %t88)
  store %"compiler/eval:Ptr" %t91, ptr %l54
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l50, !tbaa !29
  %t93 = load %"compiler/eval:Ptr", ptr %l54
  %t94 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t92, %"compiler/eval:Ptr" %t93)
  store %"compiler/eval:Ptr" %t94, ptr %l55
  br label %bb23
bb23:
  %t95 = load %"compiler/eval:Ptr", ptr %l55
  store %"compiler/eval:Ptr" %t95, ptr %l9
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/eval:Machine", ptr %t96, i32 0, i32 13
  %t99 = load i1, ptr %t98, !tbaa !21
  br i1 %t99, label %bb24, label %bb25
bb24:
  %t101 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t102 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t104 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t102, %"compiler/eval:Ptr" %t101, 1
  %t105 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t104, i1 false, 2
  %t106 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t105, i64 0, 3
  call void @__olang_scope_close(ptr %s4)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t106, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t108 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 0
  %t109 = load i64, ptr %t108, !tbaa !24
  %t111 = icmp eq i64 %t109, 0
  br i1 %t111, label %bb27, label %bb28
bb27:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t115 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t115, ptr %t113, { i64, ptr } %t114)
  br label %bb29
bb28:
  br label %bb30
bb29:
  %t118 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t119 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t121 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t119, %"compiler/eval:Ptr" %t118, 1
  %t122 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t121, i1 false, 2
  %t123 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t122, i64 0, 3
  call void @__olang_scope_close(ptr %s4)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t123, ptr %rv
  br label %ret
bb30:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 0
  %t127 = load i64, ptr %t126, !tbaa !24
  %t130 = call %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %t125, i64 %t127)
  store %"compiler/eval:alloc" %t130, ptr %l68
  br label %bb31
bb31:
  %t131 = load %"compiler/eval:alloc", ptr %l68
  store %"compiler/eval:alloc" %t131, ptr %l10
  %t132 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 4
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t137 = icmp ne i64 %t133, %t134
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t141 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t141, ptr %t139, { i64, ptr } %t140)
  br label %bb34
bb33:
  br label %bb35
bb34:
  %t144 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t145 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t147 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t145, %"compiler/eval:Ptr" %t144, 1
  %t148 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t147, i1 false, 2
  %t149 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t148, i64 0, 3
  call void @__olang_scope_close(ptr %s4)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t149, ptr %rv
  br label %ret
bb35:
  %t151 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 12
  %t152 = load i1, ptr %t151, !tbaa !21
  br i1 %t152, label %bb36, label %bb37
bb36:
  %t154 = load %"compiler/eval:Ptr", ptr %l9
  %t155 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 11
  %t156 = load i64, ptr %t155, !tbaa !24
  %t157 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t159 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t157, %"compiler/eval:Ptr" %t154, 1
  %t160 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t159, i1 true, 2
  %t162 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t160, i64 %t156, 3
  call void @__olang_scope_close(ptr %s4)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t162, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t164, i32 0, i32 21
  store ptr %t166, ptr %l82, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/eval:Machine", ptr %t167, i32 0, i32 22
  %t170 = getelementptr %"compiler/eval:alloc", ptr %l10, i32 0, i32 11
  %t171 = load i64, ptr %t170, !tbaa !24
  %t174 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t169, i64 %t171)
  store { i64, [2 x i64] } %t174, ptr %l86
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l82, !tbaa !29
  %t176 = load { i64, [2 x i64] }, ptr %l86
  %t177 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t175, { i64, [2 x i64] } %t176)
  %t178 = extractvalue { i32, i64 } %t177, 1
  %t179 = extractvalue { i32, i64 } %t177, 0
  store i32 %t179, ptr %l88
  %t180 = icmp ne i32 %t179, 0
  br i1 %t180, label %bb41, label %ok.181, !prof !99
ok.181:
  store i64 %t178, ptr %l87
  br label %bb40
bb40:
  %t182 = load i64, ptr %l87, !tbaa !24
  store i64 %t182, ptr %l80, !tbaa !24
  br label %bb43
bb41:
  br label %bb42
bb42:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l80, !tbaa !24
  br label %bb43
bb43:
  %t183 = load i64, ptr %l80, !tbaa !24
  store i64 %t183, ptr %l11, !tbaa !24
  %t184 = load i64, ptr %l11, !tbaa !24
  %t186 = icmp slt i64 %t184, 0
  br i1 %t186, label %bb44, label %bb45
bb44:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t190 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t190, ptr %t188, { i64, ptr } %t189)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  %t193 = load i64, ptr %l11, !tbaa !24
  %t194 = load %"compiler/eval:Ptr", ptr %l9
  %t196 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 %t193, 0
  %t198 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t196, %"compiler/eval:Ptr" %t194, 1
  %t199 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t198, i1 false, 2
  %t200 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t199, i64 0, 3
  call void @__olang_scope_close(ptr %s4)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t200, ptr %rv
  br label %ret
bb48:
  %t202 = load { i64, [7 x i64] }, ptr %l2
  %t204 = extractvalue { i64, [7 x i64] } %t202, 0
  %t205 = icmp eq i64 %t204, 3
  br i1 %t205, label %bb49, label %bb50
bb49:
  %t207 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t208 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t207, i32 0, i32 0
  %t209 = load { i64, [4 x i64] }, ptr %t208
  store { i64, [4 x i64] } %t209, ptr %l12
  %t211 = getelementptr { i64, [7 x i64] }, ptr %l2, i32 0, i32 1
  %t212 = getelementptr { { i64, [4 x i64] }, i64, i32 }, ptr %t211, i32 0, i32 1
  %t213 = load i64, ptr %t212
  store i64 %t213, ptr %l13, !tbaa !24
  br label %bb51
bb50:
  br label %bb85
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i64, ptr %l1, !tbaa !24
  %t217 = load { i64, [4 x i64] }, ptr %l12
  %t221 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t215, i64 %t216, { i64, [4 x i64] } %t217, i64 3)
  store %"compiler/eval:Ptr" %t221, ptr %l103
  br label %bb52
bb52:
  %t222 = load %"compiler/eval:Ptr", ptr %l103
  store %"compiler/eval:Ptr" %t222, ptr %l14
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l104, !tbaa !29
  %t224 = getelementptr %"compiler/eval:Ptr", ptr %l14, i32 0, i32 0
  %t225 = load i64, ptr %t224, !tbaa !24
  %t226 = getelementptr %"compiler/eval:Ptr", ptr %l14, i32 0, i32 1
  %t227 = load i64, ptr %t226, !tbaa !24
  %t229 = add i64 %t227, 8
  %t232 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s10, i64 %t225, i64 %t229)
  store %"compiler/eval:Ptr" %t232, ptr %l108
  br label %bb53
bb53:
  %t233 = load ptr, ptr %l104, !tbaa !29
  %t234 = load %"compiler/eval:Ptr", ptr %l108
  %t235 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t233, %"compiler/eval:Ptr" %t234)
  store %"compiler/eval:Ptr" %t235, ptr %l109
  br label %bb54
bb54:
  %t236 = load %"compiler/eval:Ptr", ptr %l109
  store %"compiler/eval:Ptr" %t236, ptr %l15
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/eval:Machine", ptr %t237, i32 0, i32 13
  %t240 = load i1, ptr %t239, !tbaa !21
  br i1 %t240, label %bb55, label %bb56
bb55:
  %t242 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t243 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t245 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t243, %"compiler/eval:Ptr" %t242, 1
  %t246 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t245, i1 false, 2
  %t247 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t246, i64 0, 3
  call void @__olang_scope_close(ptr %s10)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t247, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t249 = getelementptr %"compiler/eval:Ptr", ptr %l15, i32 0, i32 0
  %t250 = load i64, ptr %t249, !tbaa !24
  %t252 = icmp eq i64 %t250, 0
  br i1 %t252, label %bb58, label %bb59
bb58:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t256 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t256, ptr %t254, { i64, ptr } %t255)
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t259 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t260 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t262 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t260, %"compiler/eval:Ptr" %t259, 1
  %t263 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t262, i1 false, 2
  %t264 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t263, i64 0, 3
  call void @__olang_scope_close(ptr %s10)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t264, ptr %rv
  br label %ret
bb61:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l120, !tbaa !29
  %t267 = getelementptr %"compiler/eval:Ptr", ptr %l15, i32 0, i32 0
  %t268 = load i64, ptr %t267, !tbaa !24
  %t269 = getelementptr %"compiler/eval:Ptr", ptr %l15, i32 0, i32 1
  %t270 = load i64, ptr %t269, !tbaa !24
  %t271 = load i64, ptr @G_2ecompiler_2ftypes_2eAnySlotBase, !tbaa !24
  %t272 = load i64, ptr %l13, !tbaa !24
  %t275 = add i64 %t271, %t272
  %t277 = mul i64 8, %t275
  %t280 = add i64 %t270, %t277
  %t283 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s10, i64 %t268, i64 %t280)
  store %"compiler/eval:Ptr" %t283, ptr %l128
  br label %bb62
bb62:
  %t284 = load ptr, ptr %l120, !tbaa !29
  %t285 = load %"compiler/eval:Ptr", ptr %l128
  %t286 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t284, %"compiler/eval:Ptr" %t285)
  store %"compiler/eval:Ptr" %t286, ptr %l129
  br label %bb63
bb63:
  %t287 = load %"compiler/eval:Ptr", ptr %l129
  store %"compiler/eval:Ptr" %t287, ptr %l16
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/eval:Machine", ptr %t288, i32 0, i32 13
  %t291 = load i1, ptr %t290, !tbaa !21
  br i1 %t291, label %bb64, label %bb65
bb64:
  %t293 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t294 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t296 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t294, %"compiler/eval:Ptr" %t293, 1
  %t297 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t296, i1 false, 2
  %t298 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t297, i64 0, 3
  call void @__olang_scope_close(ptr %s10)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t298, ptr %rv
  br label %ret
bb65:
  br label %bb66
bb66:
  %t300 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t301 = load i64, ptr %t300, !tbaa !24
  %t303 = icmp eq i64 %t301, 0
  br i1 %t303, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l136, !tbaa !21
  br label %bb70
bb68:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t307 = load i64, ptr %t306, !tbaa !24
  %t310 = call %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %t305, i64 %t307)
  store %"compiler/eval:alloc" %t310, ptr %l139
  br label %bb69
bb69:
  %t311 = getelementptr %"compiler/eval:alloc", ptr %l139, i32 0, i32 4
  %t312 = load i64, ptr %t311, !tbaa !24
  %t313 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t316 = icmp ne i64 %t312, %t313
  store i1 %t316, ptr %l136, !tbaa !21
  br label %bb70
bb70:
  %t318 = load i1, ptr %l136, !tbaa !21
  br i1 %t318, label %bb71, label %bb72
bb71:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t321 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t321, ptr %t319, { i64, ptr } %t320)
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t324 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t325 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 -1, 0
  %t327 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t325, %"compiler/eval:Ptr" %t324, 1
  %t328 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t327, i1 false, 2
  %t329 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t328, i64 0, 3
  call void @__olang_scope_close(ptr %s10)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t329, ptr %rv
  br label %ret
bb74:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/eval:Machine", ptr %t331, i32 0, i32 21
  store ptr %t333, ptr %l149, !tbaa !29
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t336 = getelementptr %"compiler/eval:Machine", ptr %t334, i32 0, i32 22
  store ptr %t336, ptr %l151, !tbaa !29
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t339 = load i64, ptr %t338, !tbaa !24
  %t342 = call %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %t337, i64 %t339)
  store %"compiler/eval:alloc" %t342, ptr %l154
  br label %bb75
bb75:
  %t343 = getelementptr %"compiler/eval:alloc", ptr %l154, i32 0, i32 11
  %t344 = load i64, ptr %t343, !tbaa !24
  %t345 = load ptr, ptr %l151, !tbaa !29
  %t347 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t345, i64 %t344)
  store { i64, [2 x i64] } %t347, ptr %l156
  br label %bb76
bb76:
  %t348 = load ptr, ptr %l149, !tbaa !29
  %t349 = load { i64, [2 x i64] }, ptr %l156
  %t350 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t348, { i64, [2 x i64] } %t349)
  %t351 = extractvalue { i32, i64 } %t350, 1
  %t352 = extractvalue { i32, i64 } %t350, 0
  store i32 %t352, ptr %l158
  %t353 = icmp ne i32 %t352, 0
  br i1 %t353, label %bb78, label %ok.354, !prof !99
ok.354:
  store i64 %t351, ptr %l157
  br label %bb77
bb77:
  %t355 = load i64, ptr %l157, !tbaa !24
  store i64 %t355, ptr %l147, !tbaa !24
  br label %bb80
bb78:
  br label %bb79
bb79:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l147, !tbaa !24
  br label %bb80
bb80:
  %t356 = load i64, ptr %l147, !tbaa !24
  store i64 %t356, ptr %l17, !tbaa !24
  %t357 = load i64, ptr %l17, !tbaa !24
  %t359 = icmp slt i64 %t357, 0
  br i1 %t359, label %bb81, label %bb82
bb81:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t363 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t363, ptr %t361, { i64, ptr } %t362)
  br label %bb83
bb82:
  br label %bb84
bb83:
  br label %bb84
bb84:
  %t366 = load i64, ptr %l17, !tbaa !24
  %t367 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t369 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } undef, i64 %t366, 0
  %t371 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t369, %"compiler/eval:Ptr" %t367, 1
  %t372 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t371, i1 false, 2
  %t373 = insertvalue { i64, %"compiler/eval:Ptr", i1, i64 } %t372, i64 0, 3
  call void @__olang_scope_close(ptr %s10)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t373, ptr %rv
  br label %ret
bb85:
  call void @__olang_check_failed(ptr @olang_loc_bde43f50f3dd47_4bb44709ac02dbdb)
  unreachable
ret:
  %rr = load { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %rv
  ret { i64, %"compiler/eval:Ptr", i1, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodeIndex(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [2 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca { i64, [2 x i64] }
  %l17 = alloca i64
  %l25 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [2 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 23
  %t4 = load { i64, [2 x i64] }, ptr %l1
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t3, { i64, [2 x i64] } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l8
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  %t13 = load i64, ptr %l3, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr %l2, !tbaa !24
  %t16 = icmp sge i64 %t14, 0
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 23
  store ptr %t22, ptr %l13, !tbaa !29
  %t23 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t23, ptr %l14
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Machine", ptr %t24, i32 0, i32 22
  %t28 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t26)
  store i64 %t28, ptr %l17
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load { i64, [2 x i64] }, ptr %l14
  %t31 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %t29, { i64, [2 x i64] } %t30, i64 %t31)
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 22
  %t35 = load { i64, [2 x i64] }, ptr %l1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t34, { i64, [2 x i64] } %t35)
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/eval:Machine", ptr %t38, i32 0, i32 24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t40, i64 0)
  br label %bb11
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 22
  %t46 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t44)
  store i64 %t46, ptr %l25
  br label %bb12
bb12:
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = sub i64 %t47, 1
  store i64 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodePtr(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i64
  %l10 = alloca i64
  %l16 = alloca %"compiler/eval:Ptr"
  %l18 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecodeIndex(ptr %v0, ptr %t1, { i64, [2 x i64] } %a1)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  store i64 %t13, ptr %l10
  br label %bb2
bb2:
  %t14 = load i64, ptr %l10, !tbaa !24
  %t15 = icmp eq i64 %t14, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr @G_2ecompiler_2feval_2eaCode, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 61
  %t22 = load i64, ptr %t21, !tbaa !24
  %t26 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t17, i64 0, i64 %t18, i64 %t22)
  store %"compiler/eval:Ptr" %t26, ptr %l16
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t27 = load %"compiler/eval:Ptr", ptr %l16
  store %"compiler/eval:Ptr" %t27, ptr %l3
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 40
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t33 = load i64, ptr %t32, !tbaa !24
  %t34 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t37 = and i64 %t33, %t34
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/eval:alloc", ptr %t42, i64 %t37
  %t44 = getelementptr %"compiler/eval:alloc", ptr %t43, i32 0, i32 11
  store i64 %t38, ptr %t44, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/eval:Machine", ptr %t45, i32 0, i32 24
  %t48 = load i64, ptr %l2, !tbaa !24
  %t49 = getelementptr %"compiler/eval:Ptr", ptr %l3, i32 0, i32 0
  %t50 = load i64, ptr %t49, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t47, i64 %t48, i64 %t50)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 24
  %t57 = load i64, ptr %l2, !tbaa !24
  %t60 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t56, i64 %t57)
  store i64 %t60, ptr %l30
  br label %bb8
bb8:
  %t61 = load i64, ptr %l30, !tbaa !24
  %t62 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t61, i64 0)
  store %"compiler/eval:Ptr" %t62, ptr %l31
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t63 = load %"compiler/eval:Ptr", ptr %l31
  store %"compiler/eval:Ptr" %t63, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2econvertArray(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca %"compiler/eval:Ptr"
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/eval:Ptr"
  %l15 = alloca { %"compiler/eval:Ptr", i64 }
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca i64
  %l23 = alloca i32
  %l26 = alloca i32
  %l29 = alloca i32
  %l33 = alloca %"compiler/eval:Ptr"
  %l38 = alloca i32
  %l42 = alloca i32
  %l45 = alloca i1
  %l46 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca i1
  %l52 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca i32
  %l63 = alloca i64
  %l70 = alloca %"compiler/eval:Ptr"
  %l80 = alloca ptr
  %l84 = alloca %"compiler/eval:Ptr"
  %l89 = alloca { %"compiler/eval:Ptr", i64 }
  %l95 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca %"compiler/eval:Ptr"
  %l105 = alloca %"compiler/eval:Ptr"
  %l108 = alloca i64
  %l112 = alloca ptr
  %l116 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store { i64, [4 x i64] } %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load { i64, [4 x i64] }, ptr %l3
  %t12 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t6, i64 %t7, { i64, [4 x i64] } %t8)
  store i32 %t12, ptr %l23
  br label %bb1
bb1:
  %t13 = load i32, ptr %l23, !tbaa !23
  store i32 %t13, ptr %l6, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l6, !tbaa !23
  %t18 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %t14, i32 %t15)
  store i32 %t18, ptr %l26
  br label %bb2
bb2:
  %t19 = load i32, ptr %l26, !tbaa !23
  store i32 %t19, ptr %l7, !tbaa !23
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t24, ptr %l29
  br label %bb3
bb3:
  %t25 = load i32, ptr %l29, !tbaa !23
  store i32 %t25, ptr %l8, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  %t28 = load { i64, [4 x i64] }, ptr %l3
  %t32 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t26, i64 %t27, { i64, [4 x i64] } %t28, i64 1)
  store %"compiler/eval:Ptr" %t32, ptr %l33
  br label %bb4
bb4:
  %t33 = load %"compiler/eval:Ptr", ptr %l33
  store %"compiler/eval:Ptr" %t33, ptr %l9
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 13
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l5, !tbaa !29
  %t40 = load i32, ptr %l7, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l38
  br label %bb8
bb8:
  %t44 = load i32, ptr %l38, !tbaa !23
  %t45 = icmp ne i32 %t44, 0
  store i1 %t45, ptr %l10, !tbaa !21
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t48 = load i32, ptr %l8, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l42
  br label %bb9
bb9:
  %t52 = load i32, ptr %l42, !tbaa !23
  %t53 = icmp ne i32 %t52, 0
  store i1 %t53, ptr %l11, !tbaa !21
  %t55 = load i1, ptr %l10, !tbaa !21
  br i1 %t55, label %bb10, label %bb11
bb10:
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l46, !tbaa !29
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t59 = load i32, ptr %l6, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l49
  br label %bb12
bb11:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb14
bb12:
  %t63 = load ptr, ptr %l46, !tbaa !29
  %t64 = load i32, ptr %l49, !tbaa !23
  %t65 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t63, i32 %t64)
  store i1 %t65, ptr %l50
  br label %bb13
bb13:
  %t66 = load i1, ptr %l50, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  %t69 = load i1, ptr %l45, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t70 = load i1, ptr %l11, !tbaa !21
  %t72 = xor i1 %t70, true
  store i1 %t72, ptr %l52, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb17
bb17:
  %t74 = load i1, ptr %l52, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l7, !tbaa !23
  %t79 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t75, i32 %t76)
  store i64 %t79, ptr %l57
  br label %bb20
bb19:
  br label %bb31
bb20:
  %t80 = load i64, ptr %l57, !tbaa !24
  store i64 %t80, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l12, !tbaa !24
  store i64 %t81, ptr %l58, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  store ptr %t82, ptr %l59, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t84 = load i32, ptr %l7, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l62
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l59, !tbaa !29
  %t89 = load i32, ptr %l62, !tbaa !23
  %t90 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t88, i32 %t89)
  store i64 %t90, ptr %l63
  br label %bb22
bb22:
  %t91 = load i64, ptr %l58, !tbaa !24
  %t92 = load i64, ptr %l63, !tbaa !24
  %t93 = mul i64 %t91, %t92
  store i64 %t93, ptr %l13, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l13, !tbaa !24
  %t97 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/eval:Machine", ptr %t98, i32 0, i32 61
  %t101 = load i64, ptr %t100, !tbaa !24
  %t106 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t95, i64 %t96, i64 %t97, i64 %t101)
  store %"compiler/eval:Ptr" %t106, ptr %l70
  br label %bb23
bb23:
  %t107 = load %"compiler/eval:Ptr", ptr %l70
  store %"compiler/eval:Ptr" %t107, ptr %l14
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 13
  %t111 = load i1, ptr %t110, !tbaa !21
  br i1 %t111, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb25:
  br label %bb26
bb26:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load %"compiler/eval:Ptr", ptr %l14
  %t115 = load %"compiler/eval:Ptr", ptr %l9
  %t116 = load i64, ptr %l13, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t113, %"compiler/eval:Ptr" %t114, %"compiler/eval:Ptr" %t115, i64 %t116)
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load %"compiler/eval:Ptr", ptr %l2
  %t123 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t121, %"compiler/eval:Ptr" %t122, i64 8, i64 %t123)
  br label %bb28
bb28:
  %t127 = load ptr, ptr %l0, !tbaa !29
  store ptr %t127, ptr %l80, !tbaa !29
  %t128 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t129 = load i64, ptr %t128, !tbaa !24
  %t130 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t131 = load i64, ptr %t130, !tbaa !24
  %t133 = add i64 %t131, 8
  %t136 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t129, i64 %t133)
  store %"compiler/eval:Ptr" %t136, ptr %l84
  br label %bb29
bb29:
  %t137 = load %"compiler/eval:Ptr", ptr %l14
  %t138 = load ptr, ptr %l80, !tbaa !29
  %t139 = load %"compiler/eval:Ptr", ptr %l84
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t138, %"compiler/eval:Ptr" %t139, %"compiler/eval:Ptr" %t137)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb31:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load %"compiler/eval:Ptr", ptr %l9
  %t143 = load i32, ptr %l6, !tbaa !23
  %t147 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t141, %"compiler/eval:Ptr" %t142, i32 %t143)
  store { %"compiler/eval:Ptr", i64 } %t147, ptr %l89
  br label %bb32
bb32:
  %t148 = load { %"compiler/eval:Ptr", i64 }, ptr %l89
  store { %"compiler/eval:Ptr", i64 } %t148, ptr %l15
  %t149 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l15, i32 0, i32 0
  %t150 = load %"compiler/eval:Ptr", ptr %t149
  store %"compiler/eval:Ptr" %t150, ptr %l16
  %t152 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l15, i32 0, i32 1
  %t153 = load i64, ptr %t152, !tbaa !24
  store i64 %t153, ptr %l17, !tbaa !24
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 13
  %t158 = load i1, ptr %t157, !tbaa !21
  br i1 %t158, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t160 = load i1, ptr %l11, !tbaa !21
  br i1 %t160, label %bb36, label %bb37
bb36:
  %t162 = load ptr, ptr %l5, !tbaa !29
  store ptr %t162, ptr %l95, !tbaa !29
  %t163 = load ptr, ptr %l5, !tbaa !29
  %t164 = load i32, ptr %l4, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l98
  br label %bb38
bb37:
  br label %bb46
bb38:
  %t168 = load ptr, ptr %l95, !tbaa !29
  %t169 = load i32, ptr %l98, !tbaa !23
  %t170 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t168, i32 %t169)
  store i1 %t170, ptr %l99
  br label %bb39
bb39:
  %t171 = load i1, ptr %l99, !tbaa !21
  br i1 %t171, label %bb40, label %bb41
bb40:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load %"compiler/eval:Ptr", ptr %l2
  %t174 = load %"compiler/eval:Ptr", ptr %l16
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t172, %"compiler/eval:Ptr" %t173, %"compiler/eval:Ptr" %t174)
  br label %bb42
bb41:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l103, !tbaa !29
  %t179 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t179, ptr %l104
  %t180 = load %"compiler/eval:Ptr", ptr %l16
  store %"compiler/eval:Ptr" %t180, ptr %l105
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i32, ptr %l8, !tbaa !23
  %t185 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t181, i32 %t182)
  store i64 %t185, ptr %l108
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t186 = load ptr, ptr %l103, !tbaa !29
  %t187 = load %"compiler/eval:Ptr", ptr %l104
  %t188 = load %"compiler/eval:Ptr", ptr %l105
  %t189 = load i64, ptr %l108, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t186, %"compiler/eval:Ptr" %t187, %"compiler/eval:Ptr" %t188, i64 %t189)
  br label %bb44
bb44:
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb46:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/eval:Ptr", ptr %l2
  %t192 = load i64, ptr %l17, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t190, %"compiler/eval:Ptr" %t191, i64 8, i64 %t192)
  br label %bb47
bb47:
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l112, !tbaa !29
  %t197 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t198 = load i64, ptr %t197, !tbaa !24
  %t199 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t200 = load i64, ptr %t199, !tbaa !24
  %t202 = add i64 %t200, 8
  %t205 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t198, i64 %t202)
  store %"compiler/eval:Ptr" %t205, ptr %l116
  br label %bb48
bb48:
  %t206 = load %"compiler/eval:Ptr", ptr %l16
  %t207 = load ptr, ptr %l112, !tbaa !29
  %t208 = load %"compiler/eval:Ptr", ptr %l116
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t207, %"compiler/eval:Ptr" %t208, %"compiler/eval:Ptr" %t206)
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l3, !tbaa !24
  %t11 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t5, %"compiler/eval:Ptr" %a2, i64 %t7, i1 false)
  store i64 %t11, ptr %l11
  br label %bb4
bb4:
  %t12 = load i64, ptr %l11, !tbaa !24
  store i64 %t12, ptr %l4, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l3, !tbaa !24
  %t19 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %t13, %"compiler/eval:Ptr" %a1, i64 %t15, i1 true)
  store i64 %t19, ptr %l15
  br label %bb5
bb5:
  %t20 = load i64, ptr %l15, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp slt i64 %t21, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb8
bb7:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t29 = load i1, ptr %l18, !tbaa !21
  br i1 %t29, label %bb9, label %bb10
bb9:
  br label %ret
bb10:
  br label %bb11
bb11:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2emove(ptr %v0, ptr %t30, i64 %t31, i64 %t32, i64 %t33)
  br label %bb12
bb12:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropFrame(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:frame"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l52 = alloca i1
  %l59 = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 50
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t8, i32 0, i32 49
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l14, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr %"compiler/eval:frame", ptr %t15, i64 %t6
  %t17 = load %"compiler/eval:frame", ptr %t16
  store %"compiler/eval:frame" %t17, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t19 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 5
  %t20 = load i64, ptr %t19, !tbaa !24
  %t21 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 4
  %t22 = load i64, ptr %t21, !tbaa !24
  %t25 = sub i64 %t20, %t22
  store i64 %t25, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp sgt i64 %t27, %t28
  br i1 %t31, label %bb1, label %bb2
bb1:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp sgt i64 %t33, 0
  br i1 %t35, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb3:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  %t41 = sub i64 %t37, %t38
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = add i64 %t41, %t42
  %t47 = sub i64 %t45, 1
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sdiv i64 %t47, %t48
  store i64 %t51, ptr %l26, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb5
bb5:
  %t53 = load i64, ptr %l26, !tbaa !24
  store i64 %t53, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t54 = load i64, ptr %l23, !tbaa !24
  store i64 %t54, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb8, label %bb9
bb8:
  br label %bb17
bb9:
  br label %bb10
bb10:
  %t63 = load i64, ptr %l3, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = mul i64 %t64, %t65
  %t71 = add i64 %t63, %t68
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 51
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l45, !tbaa !27
  %t77 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 4
  %t78 = load i64, ptr %t77, !tbaa !24
  %t82 = add i64 %t78, %t71
  %t84 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr i64, ptr %t85, i64 %t82
  %t87 = load i64, ptr %t86, !tbaa !34
  store i64 %t87, ptr %l9, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t89, i64 %t90)
  store i1 %t93, ptr %l52
  br label %bb11
bb11:
  %t94 = load i1, ptr %l52, !tbaa !21
  br i1 %t94, label %bb12, label %bb13
bb12:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropScope(ptr %v0, ptr %t95, i64 %t96)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l7, !tbaa !24
  br label %bb7
bb17:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 6
  %t105 = load i64, ptr %t104, !tbaa !24
  %t108 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t103, i64 %t105)
  store i1 %t108, ptr %l59
  br label %bb18
bb18:
  %t109 = load i1, ptr %l59, !tbaa !21
  br i1 %t109, label %bb19, label %bb20
bb19:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 6
  %t112 = load i64, ptr %t111, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropScope(ptr %v0, ptr %t110, i64 %t112)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/eval:Machine", ptr %t115, i32 0, i32 53
  %t118 = getelementptr %"compiler/eval:frame", ptr %l2, i32 0, i32 9
  %t119 = load i64, ptr %t118, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t117, i64 %t119)
  br label %bb23
bb23:
  %t122 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %t122)
  br label %bb24
bb24:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l8 = alloca i32
  %l11 = alloca i32
  %l14 = alloca ptr
  %l17 = alloca i32
  %l18 = alloca i32
  %l21 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load i32, ptr %l8, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t13 = load i32, ptr %l3, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l11
  br label %bb2
bb2:
  %t17 = load i32, ptr %l11
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l17
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l14, !tbaa !29
  %t29 = load i32, ptr %l17, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load i32, ptr %l18, !tbaa !23
  store i32 %t31, ptr %l3, !tbaa !23
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t33 = load i32, ptr %l3, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l21
  br label %bb8
bb8:
  %t37 = load i32, ptr %l21, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca { %"compiler/eval:Ptr", i64 }
  %l6 = alloca %"compiler/eval:Ptr"
  %l7 = alloca i64
  %l10 = alloca i32
  %l14 = alloca { %"compiler/eval:Ptr", i64 }
  %l24 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l41 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca { %"compiler/eval:Ptr", i32 }
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i32, ptr %l10, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l2, !tbaa !23
  %t13 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t7, %"compiler/eval:Ptr" %a1, i32 %t9)
  store { %"compiler/eval:Ptr", i64 } %t13, ptr %l14
  br label %bb2
bb2:
  %t14 = load { %"compiler/eval:Ptr", i64 }, ptr %l14
  store { %"compiler/eval:Ptr", i64 } %t14, ptr %l5
  %t15 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l5, i32 0, i32 0
  %t16 = load %"compiler/eval:Ptr", ptr %t15
  store %"compiler/eval:Ptr" %t16, ptr %l6
  %t18 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 13
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t27 = load i32, ptr %l4, !tbaa !23
  %t29 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t26, 0
  %t31 = insertvalue { %"compiler/eval:Ptr", i32 } %t29, i32 %t27, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i32 } %t31, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t33 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp slt i64 %t33, 0
  br i1 %t35, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb8
bb7:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp sge i64 %t37, %t38
  store i1 %t41, ptr %l24, !tbaa !21
  br label %bb8
bb8:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyOutside, !tbaa !27
  %t46 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t46, ptr %t44, { i64, ptr } %t45)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t49 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t50 = load i32, ptr %l4, !tbaa !23
  %t52 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t49, 0
  %t54 = insertvalue { %"compiler/eval:Ptr", i32 } %t52, i32 %t50, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i32 } %t54, ptr %rv
  br label %ret
bb12:
  %t56 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l33, !tbaa !24
  %t58 = getelementptr %"compiler/eval:Ptr", ptr %l6, i32 0, i32 1
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l34, !tbaa !24
  %t60 = load i64, ptr %l3, !tbaa !24
  store i64 %t60, ptr %l35, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l4, !tbaa !23
  %t65 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t61, i32 %t62)
  store i64 %t65, ptr %l38
  br label %bb13
bb13:
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = mul i64 %t66, %t67
  %t69 = load i64, ptr %l34, !tbaa !24
  %t71 = add i64 %t69, %t68
  %t72 = load i64, ptr %l33, !tbaa !24
  %t74 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t72, i64 %t71)
  store %"compiler/eval:Ptr" %t74, ptr %l41
  br label %bb14
bb14:
  %t75 = load i32, ptr %l4, !tbaa !23
  %t76 = load %"compiler/eval:Ptr", ptr %l41
  %t77 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t76, 0
  %t79 = insertvalue { %"compiler/eval:Ptr", i32 } %t77, i32 %t75, 1
  call void @__olang_scope_close(ptr %s0)
  store { %"compiler/eval:Ptr", i32 } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/eval:Ptr", i32 }, ptr %rv
  ret { %"compiler/eval:Ptr", i32 } %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eendsProgram(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:task"
  %l6 = alloca %"compiler/eval:task"
  %l10 = alloca %"compiler/mir:Fn"
  %l13 = alloca %"compiler/mir:Task"
  %rv = alloca i1
  %t14 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 47
  %t7 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/eval:task" %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"compiler/eval:task", ptr %l6
  store %"compiler/eval:task" %t8, ptr %l2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 16
  %t12 = getelementptr %"compiler/eval:task", ptr %l2, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t14, ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %t14, i64 248, i1 false)
  br label %bb2
bb2:
  %t17 = getelementptr %"compiler/mir:Fn", ptr %l10, i32 0, i32 16
  %t18 = getelementptr %"compiler/eval:task", ptr %l2, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t17, i64 %t19)
  store %"compiler/mir:Task" %t22, ptr %l13
  br label %bb3
bb3:
  %t23 = getelementptr %"compiler/mir:Task", ptr %l13, i32 0, i32 5
  %t24 = getelementptr %"compiler/mir:Range", ptr %t23, i32 0, i32 1
  %t25 = load i32, ptr %t24, !tbaa !23
  %t27 = icmp sgt i32 %t25, 0
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eenter(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2, %"compiler/mir:Range" %a3, %"compiler/mir:Range" %a4, i64 %a5, i64 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [7 x i64] }
  %l3 = alloca %"compiler/mir:Range"
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca { i64, %"compiler/eval:Ptr", i1, i64 }
  %l9 = alloca i64
  %l10 = alloca %"compiler/eval:Ptr"
  %l11 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/mir:Fn"
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca { i64, [1 x i64] }
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca %"compiler/eval:genRec"
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca { { i64, ptr }, i64 }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l69 = alloca %"compiler/mir:Fn"
  %l73 = alloca { i64, %"compiler/eval:Ptr", i1, i64 }
  %l83 = alloca i32
  %l89 = alloca %"compiler/mir:Fn"
  %l96 = alloca ptr
  %l100 = alloca %"compiler/mir:Fn"
  %l103 = alloca i64
  %l107 = alloca %"compiler/eval:genRec"
  %l131 = alloca i64
  %l136 = alloca i64
  %l141 = alloca i64
  %l148 = alloca %"compiler/mir:Fn"
  %l149 = alloca i1
  %l156 = alloca i32
  %l159 = alloca i32
  %l178 = alloca i64
  %l180 = alloca i64
  %l185 = alloca i32
  %l188 = alloca i1
  %l190 = alloca ptr
  %l194 = alloca %"compiler/eval:Ptr"
  %l195 = alloca ptr
  %l196 = alloca ptr
  %l197 = alloca i64
  %l201 = alloca { i64, [4 x i64] }
  %l202 = alloca %"compiler/eval:Ptr"
  %l203 = alloca %"compiler/eval:Ptr"
  %l204 = alloca ptr
  %l205 = alloca i64
  %l209 = alloca %"compiler/eval:Ptr"
  %l213 = alloca %"compiler/mir:Local"
  %l214 = alloca i32
  %l221 = alloca { i64, [4 x i64] }
  %l230 = alloca i64
  %l232 = alloca i64
  %l237 = alloca { i64, [1 x i64] }
  %l244 = alloca i1
  %l250 = alloca { i64, ptr }
  %l255 = alloca i64
  %l258 = alloca i64
  %l279 = alloca i1
  %l288 = alloca ptr
  %l289 = alloca i64
  %l295 = alloca { i64, [1 x i64] }
  %l296 = alloca i64
  %l299 = alloca { i64, [1 x i64] }
  %l300 = alloca i64
  %l318 = alloca i64
  %l321 = alloca i64
  %l343 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca i64
  %l355 = alloca { i64, [1 x i64] }
  %l356 = alloca i64
  %l360 = alloca { i64, ptr }
  %l362 = alloca { i64, ptr }
  %l373 = alloca { i64, ptr }
  %l381 = alloca %"compiler/eval:genRec"
  %l386 = alloca %"compiler/eval:genRec"
  %l388 = alloca i64
  %l390 = alloca i1
  %l399 = alloca i64
  %l404 = alloca i64
  %l408 = alloca i64
  %l411 = alloca i64
  %l429 = alloca i64
  %l430 = alloca ptr
  %l433 = alloca i32
  %l435 = alloca %"compiler/mir:Local"
  %l441 = alloca { { i64, ptr }, i64 }
  %l442 = alloca { i64, ptr }
  %l443 = alloca i64
  %l444 = alloca { i64, ptr }
  %l447 = alloca i64
  %l451 = alloca i64
  %l454 = alloca i64
  %l472 = alloca ptr
  %l473 = alloca ptr
  %l474 = alloca i64
  %l477 = alloca i32
  %l478 = alloca %"compiler/eval:Ptr"
  %l484 = alloca %"compiler/eval:Ptr"
  %l488 = alloca i64
  %l491 = alloca i64
  %l493 = alloca i64
  %l496 = alloca { i64, ptr }
  %l498 = alloca { i64, ptr }
  %l504 = alloca i64
  %l505 = alloca ptr
  %l513 = alloca %"compiler/eval:Ptr"
  %l514 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %s44 = alloca %olang.scope
  %s45 = alloca %olang.scope
  %rv = alloca i64
  %t3 = alloca %"compiler/mir:Fn", align 8
  %t44 = alloca %"compiler/mir:Fn", align 8
  %t66 = alloca %"compiler/mir:Fn", align 8
  %t80 = alloca %"compiler/eval:genRec", align 8
  %t99 = alloca { i64, [5 x i64] }, align 8
  %t166 = alloca %"compiler/mir:Fn", align 8
  %t651 = alloca %"compiler/eval:genRec", align 8
  %t663 = alloca %"compiler/eval:genRec", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [7 x i64] } %a2, ptr %l2
  store %"compiler/mir:Range" %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  store i64 %a5, ptr %l5
  store i64 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t3, ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l69, ptr %t3, i64 248, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l69, i64 248, i1 false)
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  %t8 = load { i64, [7 x i64] }, ptr %l2
  %t12 = call { i64, %"compiler/eval:Ptr", i1, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ecallee(ptr %v0, ptr %t6, i64 %t7, { i64, [7 x i64] } %t8)
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t12, ptr %l73
  br label %bb2
bb2:
  %t13 = load { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %l73
  store { i64, %"compiler/eval:Ptr", i1, i64 } %t13, ptr %l8
  %t14 = getelementptr { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %l8, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l9, !tbaa !24
  %t17 = getelementptr { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %l8, i32 0, i32 1
  %t18 = load %"compiler/eval:Ptr", ptr %t17
  store %"compiler/eval:Ptr" %t18, ptr %l10
  %t20 = getelementptr { i64, %"compiler/eval:Ptr", i1, i64 }, ptr %l8, i32 0, i32 2
  %t21 = load i1, ptr %t20, !tbaa !21
  store i1 %t21, ptr %l11, !tbaa !21
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 13
  %t26 = load i1, ptr %t25, !tbaa !21
  br i1 %t26, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i64, ptr %l1, !tbaa !24
  %t31 = load { i64, [7 x i64] }, ptr %l2
  %t35 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %t29, i64 %t30, { i64, [7 x i64] } %t31)
  store i32 %t35, ptr %l83
  br label %bb6
bb6:
  %t36 = load i32, ptr %l83, !tbaa !23
  store i32 %t36, ptr %l12, !tbaa !23
  %t37 = load i1, ptr %l11, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store i64 -1, ptr %l13, !tbaa !24
  store i1 false, ptr %l14, !tbaa !21
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:Machine", ptr %t40, i32 0, i32 16
  %t43 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t44, ptr %v0, ptr %v0, ptr %t42, i64 %t43)
  call void @llvm.memmove.p0.p0.i64(ptr %l89, ptr %t44, i64 248, i1 false)
  br label %bb10
bb10:
  %t47 = getelementptr %"compiler/mir:Fn", ptr %l89, i32 0, i32 25
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = getelementptr %"compiler/eval:Ptr", ptr %l10, i32 0, i32 0
  %t51 = load i64, ptr %t50, !tbaa !24
  %t53 = icmp eq i64 %t51, 0
  br i1 %t53, label %bb13, label %bb14
bb12:
  br label %bb28
bb13:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t57 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t57, ptr %t55, { i64, ptr } %t56)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb16:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l96, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 16
  %t65 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t66, ptr %v0, ptr %v0, ptr %t64, i64 %t65)
  call void @llvm.memmove.p0.p0.i64(ptr %l100, ptr %t66, i64 248, i1 false)
  br label %bb17
bb17:
  %t69 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 248, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %l100, i64 248, i1 false)
  %t70 = load %"compiler/eval:Ptr", ptr %l10
  %t71 = load ptr, ptr %l96, !tbaa !29
  %t74 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2egenIndex(ptr %v0, ptr %v0, ptr %t71, ptr %t69, %"compiler/eval:Ptr" %t70)
  store i64 %t74, ptr %l103
  br label %bb18
bb18:
  %t75 = load i64, ptr %l103, !tbaa !24
  store i64 %t75, ptr %l13, !tbaa !24
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Machine", ptr %t76, i32 0, i32 54
  %t79 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t80, ptr %v0, ptr %t78, i64 %t79)
  call void @llvm.memmove.p0.p0.i64(ptr %l107, ptr %t80, i64 176, i1 false)
  br label %bb19
bb19:
  %t83 = getelementptr %"compiler/eval:genRec", ptr %l107, i32 0, i32 0
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l15, !tbaa !24
  %t86 = load i64, ptr %l15, !tbaa !24
  %t88 = icmp eq i64 %t86, 2
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t91, i32 0, i32 69
  %t94 = load i64, ptr %t93, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/eval:Machine", ptr %t95, i32 0, i32 70
  %t98 = load %"compiler/source:Span", ptr %t97
  store { i64, [5 x i64] } zeroinitializer, ptr %t99
  %t100 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 0
  store i64 2, ptr %t100
  %t102 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } undef, i32 12, 0
  %t104 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t102, i64 %t94, 1
  %t106 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t104, %"compiler/source:Span" %t98, 2
  %t107 = insertvalue { i32, i64, %"compiler/source:Span", { i64, ptr } } %t106, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, 3
  %t108 = getelementptr { i64, [5 x i64] }, ptr %t99, i32 0, i32 1
  store { i32, i64, %"compiler/source:Span", { i64, ptr } } %t107, ptr %t108
  %t109 = load { i64, [5 x i64] }, ptr %t99
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v0, ptr %t90, { i64, [5 x i64] } %t109)
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb23:
  %t113 = load i64, ptr %l15, !tbaa !24
  %t115 = icmp eq i64 %t113, 3
  br i1 %t115, label %bb24, label %bb25
bb24:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i64, ptr %l1, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = load { i64, [7 x i64] }, ptr %l2
  %t121 = load i64, ptr %l5, !tbaa !24
  %t122 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenOver(ptr %v0, ptr %t117, i64 %t118, i64 %t119, { i64, [7 x i64] } %t120, i64 %t121, i64 %t122)
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb27:
  %t130 = load i64, ptr %l15, !tbaa !24
  %t132 = icmp eq i64 %t130, 1
  store i1 %t132, ptr %l14, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb28:
  %t134 = load i1, ptr %l14, !tbaa !21
  br i1 %t134, label %bb29, label %bb30
bb29:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l5, !tbaa !24
  %t139 = load i64, ptr %l6, !tbaa !24
  %t144 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erestoreGen(ptr %v0, ptr %t136, i64 %t137, i64 %t138, i64 %t139)
  store i64 %t144, ptr %l136
  br label %bb31
bb30:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l9, !tbaa !24
  %t147 = load i64, ptr %l5, !tbaa !24
  %t148 = load i64, ptr %l6, !tbaa !24
  %t153 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t145, i64 %t146, i64 %t147, i64 %t148)
  store i64 %t153, ptr %l141
  br label %bb32
bb31:
  %t154 = load i64, ptr %l136, !tbaa !24
  store i64 %t154, ptr %l131, !tbaa !24
  br label %bb33
bb32:
  %t155 = load i64, ptr %l141, !tbaa !24
  store i64 %t155, ptr %l131, !tbaa !24
  br label %bb33
bb33:
  %t156 = load i64, ptr %l131, !tbaa !24
  store i64 %t156, ptr %l16, !tbaa !24
  %t157 = load i64, ptr %l16, !tbaa !24
  %t159 = icmp slt i64 %t157, 0
  br i1 %t159, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 16
  %t165 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t166, ptr %v0, ptr %v0, ptr %t164, i64 %t165)
  call void @llvm.memmove.p0.p0.i64(ptr %l148, ptr %t166, i64 248, i1 false)
  br label %bb37
bb37:
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %l148, i64 248, i1 false)
  %t169 = load { i64, [7 x i64] }, ptr %l2
  %t171 = extractvalue { i64, [7 x i64] } %t169, 0
  %t172 = icmp eq i64 %t171, 3
  br i1 %t172, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb41
bb40:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_11a19fcb84a16e6d_1ab7f06eb0f74619)
  unreachable
bb46:
  %t174 = load i1, ptr %l149, !tbaa !21
  store i1 %t174, ptr %l18, !tbaa !21
  store i32 0, ptr %l19, !tbaa !23
  %t175 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 1
  %t176 = load i32, ptr %t175, !tbaa !23
  store i32 %t176, ptr %l20, !tbaa !23
  store i32 1, ptr %l21, !tbaa !23
  %t178 = load i32, ptr %l20, !tbaa !23
  %t179 = load i32, ptr %l19, !tbaa !23
  %t182 = icmp sgt i32 %t178, %t179
  br i1 %t182, label %bb47, label %bb48
bb47:
  %t184 = load i32, ptr %l21, !tbaa !23
  %t186 = icmp sgt i32 %t184, 0
  br i1 %t186, label %bb49, label %bb50
bb48:
  store i32 0, ptr %l156, !tbaa !23
  br label %bb52
bb49:
  %t188 = load i32, ptr %l20, !tbaa !23
  %t189 = load i32, ptr %l19, !tbaa !23
  %t192 = sub i32 %t188, %t189
  %t193 = load i32, ptr %l21, !tbaa !23
  %t196 = add i32 %t192, %t193
  %t198 = sub i32 %t196, 1
  %t199 = load i32, ptr %l21, !tbaa !23
  %t202 = sdiv i32 %t198, %t199
  store i32 %t202, ptr %l159, !tbaa !23
  br label %bb51
bb50:
  store i32 0, ptr %l159, !tbaa !23
  br label %bb51
bb51:
  %t204 = load i32, ptr %l159, !tbaa !23
  store i32 %t204, ptr %l156, !tbaa !23
  br label %bb52
bb52:
  %t205 = load i32, ptr %l156, !tbaa !23
  store i32 %t205, ptr %l22, !tbaa !23
  store i32 0, ptr %l23, !tbaa !23
  br label %bb53
bb53:
  %t206 = load i32, ptr %l23, !tbaa !23
  %t207 = load i32, ptr %l22, !tbaa !23
  %t210 = icmp slt i32 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb54, label %bb55
bb54:
  br label %bb78
bb55:
  br label %bb56
bb56:
  %t214 = load i32, ptr %l19, !tbaa !23
  %t215 = load i32, ptr %l23, !tbaa !23
  %t216 = load i32, ptr %l21, !tbaa !23
  %t219 = mul i32 %t215, %t216
  %t222 = add i32 %t214, %t219
  store i32 %t222, ptr %l24, !tbaa !23
  %t224 = load i32, ptr %l24, !tbaa !23
  %t226 = sext i32 %t224 to i64
  store i64 %t226, ptr %l178, !tbaa !24
  %t227 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 4
  %t229 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t227)
  store i64 %t229, ptr %l180
  br label %bb57
bb57:
  %t230 = load i64, ptr %l178, !tbaa !24
  %t231 = load i64, ptr %l180, !tbaa !24
  %t232 = icmp slt i64 %t230, %t231
  br i1 %t232, label %bb58, label %bb59
bb58:
  %t234 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 4
  %t235 = load i32, ptr %l24, !tbaa !23
  %t237 = sext i32 %t235 to i64
  %t240 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t234, i64 %t237)
  store i32 %t240, ptr %l185
  br label %bb60
bb59:
  br label %bb76
bb60:
  %t241 = load i32, ptr %l185, !tbaa !23
  store i32 %t241, ptr %l25, !tbaa !23
  %t242 = load i32, ptr %l24, !tbaa !23
  %t244 = icmp eq i32 %t242, 0
  br i1 %t244, label %bb61, label %bb62
bb61:
  %t246 = load i1, ptr %l18, !tbaa !21
  store i1 %t246, ptr %l188, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l188, !tbaa !21
  br label %bb63
bb63:
  %t248 = load i1, ptr %l188, !tbaa !21
  br i1 %t248, label %bb64, label %bb65
bb64:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l190, !tbaa !29
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l16, !tbaa !24
  %t252 = load i32, ptr %l25, !tbaa !23
  %t256 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t250, i64 %t251, i32 %t252)
  store %"compiler/eval:Ptr" %t256, ptr %l194
  br label %bb66
bb65:
  br label %bb71
bb66:
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l195, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l196, !tbaa !29
  %t259 = load i64, ptr %l1, !tbaa !24
  store i64 %t259, ptr %l197, !tbaa !24
  %t260 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 11
  %t261 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t262 = load i32, ptr %t261, !tbaa !23
  %t264 = sext i32 %t262 to i64
  %t267 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t260, i64 %t264)
  store { i64, [4 x i64] } %t267, ptr %l201
  br label %bb67
bb67:
  %t268 = load ptr, ptr %l196, !tbaa !29
  %t269 = load i64, ptr %l197, !tbaa !24
  %t270 = load { i64, [4 x i64] }, ptr %l201
  %t271 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t268, i64 %t269, { i64, [4 x i64] } %t270, i64 1)
  store %"compiler/eval:Ptr" %t271, ptr %l202
  br label %bb68
bb68:
  %t272 = load ptr, ptr %l195, !tbaa !29
  %t273 = load %"compiler/eval:Ptr", ptr %l202
  %t274 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t272, %"compiler/eval:Ptr" %t273)
  store %"compiler/eval:Ptr" %t274, ptr %l203
  br label %bb69
bb69:
  %t275 = load ptr, ptr %l190, !tbaa !29
  %t276 = load %"compiler/eval:Ptr", ptr %l194
  %t277 = load %"compiler/eval:Ptr", ptr %l203
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t275, %"compiler/eval:Ptr" %t276, %"compiler/eval:Ptr" %t277)
  br label %bb70
bb70:
  br label %bb77
bb71:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l204, !tbaa !29
  %t279 = load i64, ptr %l1, !tbaa !24
  store i64 %t279, ptr %l205, !tbaa !24
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i64, ptr %l16, !tbaa !24
  %t282 = load i32, ptr %l25, !tbaa !23
  %t286 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t280, i64 %t281, i32 %t282)
  store %"compiler/eval:Ptr" %t286, ptr %l209
  br label %bb72
bb72:
  %t287 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 7
  %t288 = load i32, ptr %l25, !tbaa !23
  %t290 = sext i32 %t288 to i64
  %t293 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t287, i64 %t290)
  store %"compiler/mir:Local" %t293, ptr %l213
  br label %bb73
bb73:
  %t294 = getelementptr %"compiler/mir:Local", ptr %l213, i32 0, i32 2
  %t295 = load i32, ptr %t294, !tbaa !23
  store i32 %t295, ptr %l214, !tbaa !23
  %t296 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 11
  %t297 = getelementptr %"compiler/mir:Range", ptr %l3, i32 0, i32 0
  %t298 = load i32, ptr %t297, !tbaa !23
  %t300 = sext i32 %t298 to i64
  %t301 = load i32, ptr %l24, !tbaa !23
  %t303 = sext i32 %t301 to i64
  %t306 = add i64 %t300, %t303
  %t309 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %t296, i64 %t306)
  store { i64, [4 x i64] } %t309, ptr %l221
  br label %bb74
bb74:
  %t310 = load ptr, ptr %l204, !tbaa !29
  %t311 = load i64, ptr %l205, !tbaa !24
  %t312 = load %"compiler/eval:Ptr", ptr %l209
  %t313 = load i32, ptr %l214, !tbaa !23
  %t314 = load { i64, [4 x i64] }, ptr %l221
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %t310, i64 %t311, %"compiler/eval:Ptr" %t312, i32 %t313, { i64, [4 x i64] } %t314)
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t315 = load i32, ptr %l23, !tbaa !23
  %t317 = add i32 %t315, 1
  store i32 %t317, ptr %l23, !tbaa !23
  br label %bb53
bb78:
  %t319 = load i1, ptr %l14, !tbaa !21
  %t321 = xor i1 %t319, true
  br i1 %t321, label %bb79, label %bb80
bb79:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i64, ptr %l16, !tbaa !24
  %t325 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %t323, i64 %t324, i64 %t325)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  store i64 0, ptr %l26, !tbaa !24
  %t329 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 6
  store ptr %t329, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb83
bb83:
  %t331 = load i64, ptr %l28, !tbaa !24
  store i64 %t331, ptr %l230, !tbaa !24
  %t332 = load ptr, ptr %l27, !tbaa !29
  %t334 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t332)
  store i64 %t334, ptr %l232
  br label %bb84
bb84:
  %t335 = load i64, ptr %l230, !tbaa !24
  %t336 = load i64, ptr %l232, !tbaa !24
  %t337 = icmp slt i64 %t335, %t336
  %t339 = xor i1 %t337, true
  br i1 %t339, label %bb85, label %bb86
bb85:
  br label %bb99
bb86:
  br label %bb87
bb87:
  %t341 = load ptr, ptr %l27, !tbaa !29
  %t342 = load i64, ptr %l28, !tbaa !24
  %t345 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t341, i64 %t342)
  store { i64, [1 x i64] } %t345, ptr %l237
  br label %bb88
bb88:
  %t346 = load { i64, [1 x i64] }, ptr %l237
  %t349 = extractvalue { i64, [1 x i64] } %t346, 0
  %t350 = icmp eq i64 %t349, 4
  br i1 %t350, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb97
bb92:
  br i1 true, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  %t352 = load i64, ptr %l26, !tbaa !24
  %t354 = add i64 %t352, 1
  store i64 %t354, ptr %l26, !tbaa !24
  br label %bb97
bb96:
  call void @__olang_check_failed(ptr @olang_loc_e8d82fb02ccf62bc_44b724ba703ff148)
  unreachable
bb97:
  br label %bb98
bb98:
  %t356 = load i64, ptr %l28, !tbaa !24
  %t358 = add i64 %t356, 1
  store i64 %t358, ptr %l28, !tbaa !24
  br label %bb83
bb99:
  %t360 = load { i64, [7 x i64] }, ptr %l2
  %t362 = extractvalue { i64, [7 x i64] } %t360, 0
  %t363 = icmp eq i64 %t362, 0
  br i1 %t363, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  br label %bb103
bb102:
  store i1 true, ptr %l244, !tbaa !21
  br label %bb108
bb103:
  br i1 true, label %bb104, label %bb105
bb104:
  br label %bb106
bb105:
  br label %bb107
bb106:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb108
bb107:
  call void @__olang_check_failed(ptr @olang_loc_36e0ec838c111677_372a612bd7b0a623)
  unreachable
bb108:
  %t365 = load i1, ptr %l244, !tbaa !21
  store i1 %t365, ptr %l30, !tbaa !21
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/eval:Machine", ptr %t366, i32 0, i32 0
  %t369 = load ptr, ptr %t368, !tbaa !29
  %t370 = load i32, ptr %l12, !tbaa !23
  %t373 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t369, i32 %t370)
  store { i64, ptr } %t373, ptr %l250
  br label %bb109
bb109:
  %t374 = load { i64, ptr }, ptr %l250, !tbaa !27
  store { i64, ptr } %t374, ptr %l31, !tbaa !27
  store i64 0, ptr %l32, !tbaa !24
  %t375 = load i64, ptr %l26, !tbaa !24
  store i64 %t375, ptr %l33, !tbaa !24
  store i64 1, ptr %l34, !tbaa !24
  %t377 = load i64, ptr %l33, !tbaa !24
  %t378 = load i64, ptr %l32, !tbaa !24
  %t381 = icmp sgt i64 %t377, %t378
  br i1 %t381, label %bb110, label %bb111
bb110:
  %t383 = load i64, ptr %l34, !tbaa !24
  %t385 = icmp sgt i64 %t383, 0
  br i1 %t385, label %bb112, label %bb113
bb111:
  store i64 0, ptr %l255, !tbaa !24
  br label %bb115
bb112:
  %t387 = load i64, ptr %l33, !tbaa !24
  %t388 = load i64, ptr %l32, !tbaa !24
  %t391 = sub i64 %t387, %t388
  %t392 = load i64, ptr %l34, !tbaa !24
  %t395 = add i64 %t391, %t392
  %t397 = sub i64 %t395, 1
  %t398 = load i64, ptr %l34, !tbaa !24
  %t401 = sdiv i64 %t397, %t398
  store i64 %t401, ptr %l258, !tbaa !24
  br label %bb114
bb113:
  store i64 0, ptr %l258, !tbaa !24
  br label %bb114
bb114:
  %t403 = load i64, ptr %l258, !tbaa !24
  store i64 %t403, ptr %l255, !tbaa !24
  br label %bb115
bb115:
  %t404 = load i64, ptr %l255, !tbaa !24
  store i64 %t404, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb116
bb116:
  %t405 = load i64, ptr %l36, !tbaa !24
  %t406 = load i64, ptr %l35, !tbaa !24
  %t409 = icmp slt i64 %t405, %t406
  %t411 = xor i1 %t409, true
  br i1 %t411, label %bb117, label %bb118
bb117:
  br label %bb172
bb118:
  br label %bb119
bb119:
  %t413 = load i64, ptr %l32, !tbaa !24
  %t414 = load i64, ptr %l36, !tbaa !24
  %t415 = load i64, ptr %l34, !tbaa !24
  %t418 = mul i64 %t414, %t415
  %t421 = add i64 %t413, %t418
  store i64 %t421, ptr %l37, !tbaa !24
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t425 = getelementptr %"compiler/eval:Machine", ptr %t423, i32 0, i32 61
  %t426 = load i64, ptr %t425, !tbaa !24
  store i64 %t426, ptr %l38, !tbaa !24
  %t428 = load i1, ptr %l30, !tbaa !21
  br i1 %t428, label %bb120, label %bb121
bb120:
  store i1 true, ptr %l279, !tbaa !21
  br label %bb122
bb121:
  %t430 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t430, 0
  %t433 = load i64, ptr %l26, !tbaa !24
  %t436 = icmp eq i64 %t432, %t433
  store i1 %t436, ptr %l279, !tbaa !21
  br label %bb122
bb122:
  %t438 = load i1, ptr %l279, !tbaa !21
  br i1 %t438, label %bb123, label %bb124
bb123:
  %t439 = load i64, ptr %l37, !tbaa !24
  %t440 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t441 = load i32, ptr %t440, !tbaa !23
  %t443 = sext i32 %t441 to i64
  %t446 = icmp slt i64 %t439, %t443
  br i1 %t446, label %bb125, label %bb126
bb124:
  %t448 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 6
  %t449 = load i64, ptr %l37, !tbaa !24
  %t452 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t448, i64 %t449)
  store { i64, [1 x i64] } %t452, ptr %l299
  br label %bb130
bb125:
  %t453 = load ptr, ptr %l0, !tbaa !29
  store ptr %t453, ptr %l288, !tbaa !29
  %t454 = load i64, ptr %l1, !tbaa !24
  store i64 %t454, ptr %l289, !tbaa !24
  %t455 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 12
  %t456 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t457 = load i32, ptr %t456, !tbaa !23
  %t459 = sext i32 %t457 to i64
  %t460 = load i64, ptr %l37, !tbaa !24
  %t463 = add i64 %t459, %t460
  %t466 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t455, i64 %t463)
  store { i64, [1 x i64] } %t466, ptr %l295
  br label %bb127
bb126:
  br label %bb129
bb127:
  %t467 = load ptr, ptr %l288, !tbaa !29
  %t468 = load i64, ptr %l289, !tbaa !24
  %t469 = load { i64, [1 x i64] }, ptr %l295
  %t470 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t467, i64 %t468, { i64, [1 x i64] } %t469)
  store i64 %t470, ptr %l296
  br label %bb128
bb128:
  %t471 = load i64, ptr %l296, !tbaa !24
  store i64 %t471, ptr %l38, !tbaa !24
  br label %bb129
bb129:
  br label %bb170
bb130:
  %t472 = load { i64, [1 x i64] }, ptr %l299
  store { i64, [1 x i64] } %t472, ptr %l39
  %t473 = load { i64, [1 x i64] }, ptr %l39
  %t475 = extractvalue { i64, [1 x i64] } %t473, 0
  %t476 = icmp eq i64 %t475, 0
  br i1 %t476, label %bb131, label %bb132
bb131:
  %t478 = getelementptr { i64, [1 x i64] }, ptr %l39, i32 0, i32 1
  %t479 = getelementptr { i64 }, ptr %t478, i32 0, i32 0
  %t480 = load i64, ptr %t479
  store i64 %t480, ptr %l40, !tbaa !24
  br label %bb133
bb132:
  br label %bb134
bb133:
  %t482 = load i64, ptr %l40, !tbaa !24
  store i64 %t482, ptr %l300, !tbaa !24
  br label %bb149
bb134:
  %t484 = load { i64, [1 x i64] }, ptr %l39
  %t486 = extractvalue { i64, [1 x i64] } %t484, 0
  %t487 = icmp eq i64 %t486, 1
  br i1 %t487, label %bb135, label %bb136
bb135:
  br label %bb139
bb136:
  %t489 = load { i64, [1 x i64] }, ptr %l39
  %t491 = extractvalue { i64, [1 x i64] } %t489, 0
  %t492 = icmp eq i64 %t491, 2
  br i1 %t492, label %bb137, label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb140
bb139:
  %t494 = load i64, ptr @G_2ecompiler_2ftypes_2eResultVar, !tbaa !24
  store i64 %t494, ptr %l300, !tbaa !24
  br label %bb149
bb140:
  %t496 = load { i64, [1 x i64] }, ptr %l39
  %t498 = extractvalue { i64, [1 x i64] } %t496, 0
  %t499 = icmp eq i64 %t498, 3
  br i1 %t499, label %bb141, label %bb142
bb141:
  br label %bb143
bb142:
  br label %bb144
bb143:
  %t501 = load i64, ptr @G_2ecompiler_2ftypes_2eClosingVar, !tbaa !24
  store i64 %t501, ptr %l300, !tbaa !24
  br label %bb149
bb144:
  br i1 true, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb148
bb147:
  store i64 -9, ptr %l300, !tbaa !24
  br label %bb149
bb148:
  call void @__olang_check_failed(ptr @olang_loc_5609b5c4ef82b256_83c053ae3d548522)
  unreachable
bb149:
  %t503 = load i64, ptr %l300, !tbaa !24
  store i64 %t503, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  %t504 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t504, 0
  store i64 %t506, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t508 = load i64, ptr %l43, !tbaa !24
  %t509 = load i64, ptr %l42, !tbaa !24
  %t512 = icmp sgt i64 %t508, %t509
  br i1 %t512, label %bb150, label %bb151
bb150:
  %t514 = load i64, ptr %l44, !tbaa !24
  %t516 = icmp sgt i64 %t514, 0
  br i1 %t516, label %bb152, label %bb153
bb151:
  store i64 0, ptr %l318, !tbaa !24
  br label %bb155
bb152:
  %t518 = load i64, ptr %l43, !tbaa !24
  %t519 = load i64, ptr %l42, !tbaa !24
  %t522 = sub i64 %t518, %t519
  %t523 = load i64, ptr %l44, !tbaa !24
  %t526 = add i64 %t522, %t523
  %t528 = sub i64 %t526, 1
  %t529 = load i64, ptr %l44, !tbaa !24
  %t532 = sdiv i64 %t528, %t529
  store i64 %t532, ptr %l321, !tbaa !24
  br label %bb154
bb153:
  store i64 0, ptr %l321, !tbaa !24
  br label %bb154
bb154:
  %t534 = load i64, ptr %l321, !tbaa !24
  store i64 %t534, ptr %l318, !tbaa !24
  br label %bb155
bb155:
  %t535 = load i64, ptr %l318, !tbaa !24
  store i64 %t535, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb156
bb156:
  %t536 = load i64, ptr %l46, !tbaa !24
  %t537 = load i64, ptr %l45, !tbaa !24
  %t540 = icmp slt i64 %t536, %t537
  %t542 = xor i1 %t540, true
  br i1 %t542, label %bb157, label %bb158
bb157:
  br label %bb169
bb158:
  br label %bb159
bb159:
  %t544 = load i64, ptr %l42, !tbaa !24
  %t545 = load i64, ptr %l46, !tbaa !24
  %t546 = load i64, ptr %l44, !tbaa !24
  %t549 = mul i64 %t545, %t546
  %t552 = add i64 %t544, %t549
  store i64 %t552, ptr %l47, !tbaa !24
  %t554 = load i64, ptr %l47, !tbaa !24
  %t556 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t557 = load ptr, ptr %t556, !tbaa !27
  %t558 = getelementptr i64, ptr %t557, i64 %t554
  %t559 = load i64, ptr %t558, !tbaa !34
  %t560 = load i64, ptr %l41, !tbaa !24
  %t563 = icmp eq i64 %t559, %t560
  br i1 %t563, label %bb160, label %bb161
bb160:
  %t565 = load i64, ptr %l47, !tbaa !24
  %t566 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t567 = load i32, ptr %t566, !tbaa !23
  %t569 = sext i32 %t567 to i64
  %t572 = icmp slt i64 %t565, %t569
  store i1 %t572, ptr %l343, !tbaa !21
  br label %bb162
bb161:
  store i1 false, ptr %l343, !tbaa !21
  br label %bb162
bb162:
  %t574 = load i1, ptr %l343, !tbaa !21
  br i1 %t574, label %bb163, label %bb164
bb163:
  %t575 = load ptr, ptr %l0, !tbaa !29
  store ptr %t575, ptr %l348, !tbaa !29
  %t576 = load i64, ptr %l1, !tbaa !24
  store i64 %t576, ptr %l349, !tbaa !24
  %t577 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 12
  %t578 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t579 = load i32, ptr %t578, !tbaa !23
  %t581 = sext i32 %t579 to i64
  %t582 = load i64, ptr %l47, !tbaa !24
  %t585 = add i64 %t581, %t582
  %t588 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t577, i64 %t585)
  store { i64, [1 x i64] } %t588, ptr %l355
  br label %bb165
bb164:
  br label %bb167
bb165:
  %t589 = load ptr, ptr %l348, !tbaa !29
  %t590 = load i64, ptr %l349, !tbaa !24
  %t591 = load { i64, [1 x i64] }, ptr %l355
  %t592 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t589, i64 %t590, { i64, [1 x i64] } %t591)
  store i64 %t592, ptr %l356
  br label %bb166
bb166:
  %t593 = load i64, ptr %l356, !tbaa !24
  store i64 %t593, ptr %l38, !tbaa !24
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t594 = load i64, ptr %l46, !tbaa !24
  %t596 = add i64 %t594, 1
  store i64 %t596, ptr %l46, !tbaa !24
  br label %bb156
bb169:
  br label %bb170
bb170:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t600 = getelementptr %"compiler/eval:Machine", ptr %t598, i32 0, i32 51
  %t601 = load { i64, ptr }, ptr %t600, !tbaa !27
  store { i64, ptr } %t601, ptr %l360, !tbaa !27
  %t602 = load ptr, ptr %l0, !tbaa !29
  %t604 = getelementptr %"compiler/eval:Machine", ptr %t602, i32 0, i32 49
  %t605 = load { i64, ptr }, ptr %t604, !tbaa !27
  store { i64, ptr } %t605, ptr %l362, !tbaa !27
  %t606 = load i64, ptr %l16, !tbaa !24
  %t608 = getelementptr { i64, ptr }, ptr %l362, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !27
  %t610 = getelementptr %"compiler/eval:frame", ptr %t609, i64 %t606
  %t611 = getelementptr %"compiler/eval:frame", ptr %t610, i32 0, i32 5
  %t612 = load i64, ptr %t611, !tbaa !24
  %t613 = load i64, ptr %l37, !tbaa !24
  %t616 = add i64 %t612, %t613
  %t617 = load i64, ptr %l38, !tbaa !24
  %t620 = getelementptr { i64, ptr }, ptr %l360, i32 0, i32 1
  %t621 = load ptr, ptr %t620, !tbaa !27
  %t622 = getelementptr i64, ptr %t621, i64 %t616
  store i64 %t617, ptr %t622, !tbaa !34
  br label %bb171
bb171:
  %t623 = load i64, ptr %l36, !tbaa !24
  %t625 = add i64 %t623, 1
  store i64 %t625, ptr %l36, !tbaa !24
  br label %bb116
bb172:
  %t627 = load i64, ptr %l13, !tbaa !24
  %t629 = icmp sge i64 %t627, 0
  br i1 %t629, label %bb173, label %bb174
bb173:
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t633 = getelementptr %"compiler/eval:Machine", ptr %t631, i32 0, i32 49
  %t634 = load { i64, ptr }, ptr %t633, !tbaa !27
  store { i64, ptr } %t634, ptr %l373, !tbaa !27
  %t635 = load i64, ptr %l16, !tbaa !24
  %t636 = load i64, ptr %l13, !tbaa !24
  %t638 = trunc i64 %t636 to i32
  %t641 = getelementptr { i64, ptr }, ptr %l373, i32 0, i32 1
  %t642 = load ptr, ptr %t641, !tbaa !27
  %t643 = getelementptr %"compiler/eval:frame", ptr %t642, i64 %t635
  %t644 = getelementptr %"compiler/eval:frame", ptr %t643, i32 0, i32 18
  store i32 %t638, ptr %t644, !tbaa !23
  %t645 = load i64, ptr %l13, !tbaa !24
  store i64 %t645, ptr %l48, !tbaa !24
  store i64 2, ptr %l49, !tbaa !24
  %t647 = load ptr, ptr %l0, !tbaa !29
  %t649 = getelementptr %"compiler/eval:Machine", ptr %t647, i32 0, i32 54
  %t650 = load i64, ptr %l48, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t651, ptr %v0, ptr %t649, i64 %t650)
  call void @llvm.memmove.p0.p0.i64(ptr %l381, ptr %t651, i64 176, i1 false)
  br label %bb175
bb174:
  br label %bb177
bb175:
  call void @llvm.memmove.p0.p0.i64(ptr %l50, ptr %l381, i64 176, i1 false)
  %t654 = load i64, ptr %l49, !tbaa !24
  %t656 = getelementptr %"compiler/eval:genRec", ptr %l50, i32 0, i32 0
  store i64 %t654, ptr %t656, !tbaa !24
  %t657 = load ptr, ptr %l0, !tbaa !29
  %t659 = getelementptr %"compiler/eval:Machine", ptr %t657, i32 0, i32 54
  %t660 = load i64, ptr %l48, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l386, ptr %l50, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t663, ptr %l386, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %t659, i64 %t660, ptr %t663)
  br label %bb176
bb176:
  br label %bb177
bb177:
  %t664 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 5
  %t666 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t664)
  store i64 %t666, ptr %l388
  br label %bb178
bb178:
  %t667 = load i64, ptr %l388, !tbaa !24
  %t668 = icmp sgt i64 %t667, 0
  br i1 %t668, label %bb179, label %bb180
bb179:
  %t670 = load i1, ptr %l14, !tbaa !21
  %t672 = xor i1 %t670, true
  store i1 %t672, ptr %l390, !tbaa !21
  br label %bb181
bb180:
  store i1 false, ptr %l390, !tbaa !21
  br label %bb181
bb181:
  %t674 = load i1, ptr %l390, !tbaa !21
  br i1 %t674, label %bb182, label %bb183
bb182:
  store %olang.scope zeroinitializer, ptr %s38
  %t675 = getelementptr %"compiler/eval:Ptr", ptr %l10, i32 0, i32 0
  %t676 = load i64, ptr %t675, !tbaa !24
  %t678 = icmp eq i64 %t676, 0
  br i1 %t678, label %bb184, label %bb185
bb183:
  br label %bb233
bb184:
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNullCall, !tbaa !27
  %t682 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t682, ptr %t680, { i64, ptr } %t681)
  br label %bb186
bb185:
  br label %bb187
bb186:
  call void @__olang_scope_close(ptr %s38)
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb187:
  %t686 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 5
  %t688 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t686)
  store i64 %t688, ptr %l399
  br label %bb188
bb188:
  %t689 = load i64, ptr %l399, !tbaa !24
  %t690 = icmp sge i64 %t689, 0
  br i1 %t690, label %bb189, label %bb190
bb189:
  %t692 = load i64, ptr %l399, !tbaa !24
  %t693 = icmp sle i64 %t692, 2305843009213693951
  br i1 %t693, label %bb191, label %bb192
bb190:
  call void @__olang_check_failed(ptr @olang_loc_94877e621914b8e2_5997ae45c40d186e)
  unreachable
bb191:
  %t695 = load i64, ptr %l399, !tbaa !24
  %t696 = mul i64 %t695, 4
  %t697 = call ptr @__olang_scope_alloc_zeroed(ptr %s38, i64 %t696)
  %t698 = insertvalue { i64, ptr } undef, i64 %t695, 0
  %t699 = insertvalue { i64, ptr } %t698, ptr %t697, 1
  store { i64, ptr } %t699, ptr %l51, !tbaa !27
  store i64 0, ptr %l52, !tbaa !24
  %t701 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 5
  %t703 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t701)
  store i64 %t703, ptr %l404
  br label %bb193
bb192:
  call void @__olang_check_failed(ptr @olang_loc_94877e621914b8e2_5997ae45c40d186e)
  unreachable
bb193:
  %t704 = load i64, ptr %l404, !tbaa !24
  store i64 %t704, ptr %l53, !tbaa !24
  store i64 1, ptr %l54, !tbaa !24
  %t705 = load i64, ptr %l53, !tbaa !24
  %t706 = load i64, ptr %l52, !tbaa !24
  %t709 = icmp sgt i64 %t705, %t706
  br i1 %t709, label %bb194, label %bb195
bb194:
  %t711 = load i64, ptr %l54, !tbaa !24
  %t713 = icmp sgt i64 %t711, 0
  br i1 %t713, label %bb196, label %bb197
bb195:
  store i64 0, ptr %l408, !tbaa !24
  br label %bb199
bb196:
  %t715 = load i64, ptr %l53, !tbaa !24
  %t716 = load i64, ptr %l52, !tbaa !24
  %t719 = sub i64 %t715, %t716
  %t720 = load i64, ptr %l54, !tbaa !24
  %t723 = add i64 %t719, %t720
  %t725 = sub i64 %t723, 1
  %t726 = load i64, ptr %l54, !tbaa !24
  %t729 = sdiv i64 %t725, %t726
  store i64 %t729, ptr %l411, !tbaa !24
  br label %bb198
bb197:
  store i64 0, ptr %l411, !tbaa !24
  br label %bb198
bb198:
  %t731 = load i64, ptr %l411, !tbaa !24
  store i64 %t731, ptr %l408, !tbaa !24
  br label %bb199
bb199:
  %t732 = load i64, ptr %l408, !tbaa !24
  store i64 %t732, ptr %l55, !tbaa !24
  store i64 0, ptr %l56, !tbaa !24
  br label %bb200
bb200:
  %t733 = load i64, ptr %l56, !tbaa !24
  %t734 = load i64, ptr %l55, !tbaa !24
  %t737 = icmp slt i64 %t733, %t734
  %t739 = xor i1 %t737, true
  br i1 %t739, label %bb201, label %bb202
bb201:
  br label %bb207
bb202:
  br label %bb203
bb203:
  %t741 = load i64, ptr %l52, !tbaa !24
  %t742 = load i64, ptr %l56, !tbaa !24
  %t743 = load i64, ptr %l54, !tbaa !24
  %t746 = mul i64 %t742, %t743
  %t749 = add i64 %t741, %t746
  store i64 %t749, ptr %l57, !tbaa !24
  %t751 = load i64, ptr %l57, !tbaa !24
  store i64 %t751, ptr %l429, !tbaa !24
  %t752 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 7
  store ptr %t752, ptr %l430, !tbaa !29
  %t753 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 5
  %t754 = load i64, ptr %l57, !tbaa !24
  %t757 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t753, i64 %t754)
  store i32 %t757, ptr %l433
  br label %bb204
bb204:
  %t758 = load i32, ptr %l433, !tbaa !23
  %t759 = sext i32 %t758 to i64
  %t760 = load ptr, ptr %l430, !tbaa !29
  %t762 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %t760, i64 %t759)
  store %"compiler/mir:Local" %t762, ptr %l435
  br label %bb205
bb205:
  %t763 = getelementptr %"compiler/mir:Local", ptr %l435, i32 0, i32 2
  %t764 = load i32, ptr %t763, !tbaa !23
  %t766 = load i64, ptr %l429, !tbaa !24
  %t767 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t768 = load ptr, ptr %t767, !tbaa !27
  %t769 = getelementptr i32, ptr %t768, i64 %t766
  store i32 %t764, ptr %t769, !tbaa !33
  br label %bb206
bb206:
  %t770 = load i64, ptr %l56, !tbaa !24
  %t772 = add i64 %t770, 1
  store i64 %t772, ptr %l56, !tbaa !24
  br label %bb200
bb207:
  %t774 = load ptr, ptr %l0, !tbaa !29
  %t775 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t778 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %s38, ptr %s38, ptr %t774, { i64, ptr } %t775)
  store { { i64, ptr }, i64 } %t778, ptr %l441
  br label %bb208
bb208:
  %t779 = load { { i64, ptr }, i64 }, ptr %l441
  store { { i64, ptr }, i64 } %t779, ptr %l58
  %t780 = getelementptr { { i64, ptr }, i64 }, ptr %l58, i32 0, i32 0
  %t781 = load { i64, ptr }, ptr %t780, !tbaa !27
  store { i64, ptr } %t781, ptr %l442, !tbaa !27
  %t782 = load { i64, ptr }, ptr %l442, !tbaa !27
  %t783 = extractvalue { i64, ptr } %t782, 0
  store i64 %t783, ptr %l443, !tbaa !24
  %t784 = load i64, ptr %l443, !tbaa !24
  %t785 = mul i64 %t784, 8
  %t786 = call ptr @__olang_scope_alloc(ptr %s38, i64 %t785)
  %t787 = insertvalue { i64, ptr } undef, i64 %t784, 0
  %t788 = insertvalue { i64, ptr } %t787, ptr %t786, 1
  store { i64, ptr } %t788, ptr %l444, !tbaa !27
  %t789 = getelementptr { i64, ptr }, ptr %l444, i32 0, i32 1
  %t790 = load ptr, ptr %t789, !tbaa !27
  %t791 = getelementptr { i64, ptr }, ptr %l442, i32 0, i32 1
  %t792 = load ptr, ptr %t791, !tbaa !27
  %t793 = load i64, ptr %l443, !tbaa !24
  %t794 = mul i64 %t793, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t790, ptr %t792, i64 %t794, i1 false)
  %t795 = load { i64, ptr }, ptr %l444, !tbaa !27
  store { i64, ptr } %t795, ptr %l59, !tbaa !27
  %t796 = getelementptr { { i64, ptr }, i64 }, ptr %l58, i32 0, i32 1
  %t797 = load i64, ptr %t796, !tbaa !24
  store i64 %t797, ptr %l60, !tbaa !24
  store i64 0, ptr %l61, !tbaa !24
  %t799 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 5
  %t801 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t799)
  store i64 %t801, ptr %l447
  br label %bb209
bb209:
  %t802 = load i64, ptr %l447, !tbaa !24
  store i64 %t802, ptr %l62, !tbaa !24
  store i64 1, ptr %l63, !tbaa !24
  %t803 = load i64, ptr %l62, !tbaa !24
  %t804 = load i64, ptr %l61, !tbaa !24
  %t807 = icmp sgt i64 %t803, %t804
  br i1 %t807, label %bb210, label %bb211
bb210:
  %t809 = load i64, ptr %l63, !tbaa !24
  %t811 = icmp sgt i64 %t809, 0
  br i1 %t811, label %bb212, label %bb213
bb211:
  store i64 0, ptr %l451, !tbaa !24
  br label %bb215
bb212:
  %t813 = load i64, ptr %l62, !tbaa !24
  %t814 = load i64, ptr %l61, !tbaa !24
  %t817 = sub i64 %t813, %t814
  %t818 = load i64, ptr %l63, !tbaa !24
  %t821 = add i64 %t817, %t818
  %t823 = sub i64 %t821, 1
  %t824 = load i64, ptr %l63, !tbaa !24
  %t827 = sdiv i64 %t823, %t824
  store i64 %t827, ptr %l454, !tbaa !24
  br label %bb214
bb213:
  store i64 0, ptr %l454, !tbaa !24
  br label %bb214
bb214:
  %t829 = load i64, ptr %l454, !tbaa !24
  store i64 %t829, ptr %l451, !tbaa !24
  br label %bb215
bb215:
  %t830 = load i64, ptr %l451, !tbaa !24
  store i64 %t830, ptr %l64, !tbaa !24
  store i64 0, ptr %l65, !tbaa !24
  br label %bb216
bb216:
  store %olang.scope zeroinitializer, ptr %s44
  %t831 = load i64, ptr %l65, !tbaa !24
  %t832 = load i64, ptr %l64, !tbaa !24
  %t835 = icmp slt i64 %t831, %t832
  %t837 = xor i1 %t835, true
  br i1 %t837, label %bb217, label %bb218
bb217:
  call void @__olang_scope_close(ptr %s44)
  br label %bb232
bb218:
  br label %bb219
bb219:
  %t839 = load i64, ptr %l61, !tbaa !24
  %t840 = load i64, ptr %l65, !tbaa !24
  %t841 = load i64, ptr %l63, !tbaa !24
  %t844 = mul i64 %t840, %t841
  %t847 = add i64 %t839, %t844
  store i64 %t847, ptr %l66, !tbaa !24
  %t849 = load ptr, ptr %l0, !tbaa !29
  store ptr %t849, ptr %l472, !tbaa !29
  %t850 = load ptr, ptr %l0, !tbaa !29
  store ptr %t850, ptr %l473, !tbaa !29
  %t851 = load i64, ptr %l16, !tbaa !24
  store i64 %t851, ptr %l474, !tbaa !24
  %t852 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 5
  %t853 = load i64, ptr %l66, !tbaa !24
  %t856 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t852, i64 %t853)
  store i32 %t856, ptr %l477
  br label %bb220
bb220:
  %t857 = load ptr, ptr %l473, !tbaa !29
  %t858 = load i64, ptr %l474, !tbaa !24
  %t859 = load i32, ptr %l477, !tbaa !23
  %t860 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t857, i64 %t858, i32 %t859)
  store %"compiler/eval:Ptr" %t860, ptr %l478
  br label %bb221
bb221:
  %t861 = getelementptr %"compiler/eval:Ptr", ptr %l10, i32 0, i32 0
  %t862 = load i64, ptr %t861, !tbaa !24
  %t863 = getelementptr %"compiler/eval:Ptr", ptr %l10, i32 0, i32 1
  %t864 = load i64, ptr %t863, !tbaa !24
  %t865 = load i64, ptr %l66, !tbaa !24
  %t867 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t868 = load ptr, ptr %t867, !tbaa !27
  %t869 = getelementptr i64, ptr %t868, i64 %t865
  %t870 = load i64, ptr %t869, !tbaa !34
  %t873 = add i64 %t864, %t870
  %t876 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s44, i64 %t862, i64 %t873)
  store %"compiler/eval:Ptr" %t876, ptr %l484
  br label %bb222
bb222:
  %t877 = load ptr, ptr %l0, !tbaa !29
  %t878 = load i64, ptr %l66, !tbaa !24
  %t880 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t881 = load ptr, ptr %t880, !tbaa !27
  %t882 = getelementptr i32, ptr %t881, i64 %t878
  %t883 = load i32, ptr %t882, !tbaa !33
  %t886 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t877, i32 %t883)
  store i64 %t886, ptr %l488
  br label %bb223
bb223:
  %t887 = load ptr, ptr %l472, !tbaa !29
  %t888 = load %"compiler/eval:Ptr", ptr %l478
  %t889 = load %"compiler/eval:Ptr", ptr %l484
  %t890 = load i64, ptr %l488, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t887, %"compiler/eval:Ptr" %t888, %"compiler/eval:Ptr" %t889, i64 %t890)
  br label %bb224
bb224:
  %t891 = load i64, ptr %l26, !tbaa !24
  %t892 = load i64, ptr %l66, !tbaa !24
  %t895 = add i64 %t891, %t892
  store i64 %t895, ptr %l491, !tbaa !24
  %t896 = getelementptr %"compiler/mir:Fn", ptr %l17, i32 0, i32 6
  %t898 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t896)
  store i64 %t898, ptr %l493
  br label %bb225
bb225:
  %t899 = load i64, ptr %l491, !tbaa !24
  %t900 = load i64, ptr %l493, !tbaa !24
  %t901 = icmp slt i64 %t899, %t900
  br i1 %t901, label %bb226, label %bb227
bb226:
  store %olang.scope zeroinitializer, ptr %s45
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t905 = getelementptr %"compiler/eval:Machine", ptr %t903, i32 0, i32 51
  %t906 = load { i64, ptr }, ptr %t905, !tbaa !27
  store { i64, ptr } %t906, ptr %l496, !tbaa !27
  %t907 = load ptr, ptr %l0, !tbaa !29
  %t909 = getelementptr %"compiler/eval:Machine", ptr %t907, i32 0, i32 49
  %t910 = load { i64, ptr }, ptr %t909, !tbaa !27
  store { i64, ptr } %t910, ptr %l498, !tbaa !27
  %t911 = load i64, ptr %l16, !tbaa !24
  %t913 = getelementptr { i64, ptr }, ptr %l498, i32 0, i32 1
  %t914 = load ptr, ptr %t913, !tbaa !27
  %t915 = getelementptr %"compiler/eval:frame", ptr %t914, i64 %t911
  %t916 = getelementptr %"compiler/eval:frame", ptr %t915, i32 0, i32 5
  %t917 = load i64, ptr %t916, !tbaa !24
  %t918 = load i64, ptr %l26, !tbaa !24
  %t921 = add i64 %t917, %t918
  %t922 = load i64, ptr %l66, !tbaa !24
  %t925 = add i64 %t921, %t922
  store i64 %t925, ptr %l504, !tbaa !24
  %t926 = load ptr, ptr %l0, !tbaa !29
  store ptr %t926, ptr %l505, !tbaa !29
  %t927 = getelementptr %"compiler/eval:Ptr", ptr %l10, i32 0, i32 0
  %t928 = load i64, ptr %t927, !tbaa !24
  %t929 = getelementptr %"compiler/eval:Ptr", ptr %l10, i32 0, i32 1
  %t930 = load i64, ptr %t929, !tbaa !24
  %t931 = load i64, ptr %l60, !tbaa !24
  %t934 = add i64 %t930, %t931
  %t935 = load i64, ptr %l66, !tbaa !24
  %t937 = mul i64 8, %t935
  %t940 = add i64 %t934, %t937
  %t943 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s45, i64 %t928, i64 %t940)
  store %"compiler/eval:Ptr" %t943, ptr %l513
  br label %bb228
bb227:
  br label %bb230
bb228:
  %t944 = load ptr, ptr %l505, !tbaa !29
  %t945 = load %"compiler/eval:Ptr", ptr %l513
  %t946 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t944, %"compiler/eval:Ptr" %t945, i64 8)
  store i64 %t946, ptr %l514
  br label %bb229
bb229:
  %t947 = load i64, ptr %l514, !tbaa !24
  %t948 = load i64, ptr %l504, !tbaa !24
  %t949 = getelementptr { i64, ptr }, ptr %l496, i32 0, i32 1
  %t950 = load ptr, ptr %t949, !tbaa !27
  %t951 = getelementptr i64, ptr %t950, i64 %t948
  store i64 %t947, ptr %t951, !tbaa !34
  call void @__olang_scope_close(ptr %s45)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s44)
  br label %bb231
bb231:
  %t952 = load i64, ptr %l65, !tbaa !24
  %t954 = add i64 %t952, 1
  store i64 %t954, ptr %l65, !tbaa !24
  br label %bb216
bb232:
  call void @__olang_scope_close(ptr %s38)
  br label %bb233
bb233:
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t958 = getelementptr %"compiler/eval:Machine", ptr %t956, i32 0, i32 13
  %t959 = load i1, ptr %t958, !tbaa !21
  br i1 %t959, label %bb234, label %bb235
bb234:
  call void @__olang_scope_close(ptr %s0)
  store i64 -2, ptr %rv
  br label %ret
bb235:
  br label %bb236
bb236:
  %t962 = load i64, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t962, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eflatOperand(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, [4 x i64] } %a2, ptr %a3, i64 %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca %"compiler/mir:Lvalue"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l22 = alloca i1
  %l28 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca i1
  %l56 = alloca ptr
  %l60 = alloca %"compiler/mir:Local"
  %l62 = alloca i1
  %l66 = alloca ptr
  %l70 = alloca %"compiler/mir:Local"
  %l72 = alloca i64
  %l76 = alloca %"compiler/mir:Local"
  %l80 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i32, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i32, ptr %t7
  store i32 %t8, ptr %l6, !tbaa !23
  %t10 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { i32, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l7, !tbaa !24
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l6, !tbaa !23
  %t18 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l22
  br label %bb4
bb4:
  %t19 = load i1, ptr %l22, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 -1, ptr %l8, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l6, !tbaa !23
  %t25 = load i64, ptr %l7, !tbaa !24
  %t29 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %t23, i32 %t24, i64 %t25)
  store i64 %t29, ptr %l28
  br label %bb8
bb8:
  %t30 = load i64, ptr %l28, !tbaa !24
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = sext i32 %t31 to i64
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t37 = getelementptr %"compiler/eval:cfn", ptr %t35, i32 0, i32 13
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l32, !tbaa !27
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l8, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i64, ptr %t44, i64 %t39
  store i64 %t40, ptr %t45, !tbaa !34
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/eval:cfn", ptr %t46, i32 0, i32 13
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l36, !tbaa !27
  %t50 = load i64, ptr %l4, !tbaa !24
  %t52 = add i64 %t50, 1
  %t56 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i64, ptr %t57, i64 %t52
  store i64 %t30, ptr %t58, !tbaa !34
  %t59 = load ptr, ptr %l3, !tbaa !29
  %t61 = getelementptr %"compiler/eval:cfn", ptr %t59, i32 0, i32 13
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  store { i64, ptr } %t62, ptr %l41, !tbaa !27
  %t63 = load i64, ptr %l5, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i64, ptr %t68, i64 %t63
  store i64 %t33, ptr %t69, !tbaa !34
  store i1 true, ptr %rv
  br label %ret
bb9:
  %t71 = load { i64, [4 x i64] }, ptr %l2
  %t73 = extractvalue { i64, [4 x i64] } %t71, 0
  %t74 = icmp eq i64 %t73, 1
  br i1 %t74, label %bb10, label %bb11
bb10:
  %t76 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t77 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t76, i32 0, i32 0
  %t78 = load %"compiler/mir:Lvalue", ptr %t77
  store %"compiler/mir:Lvalue" %t78, ptr %l11
  br label %bb12
bb11:
  br label %bb28
bb12:
  %t80 = getelementptr %"compiler/mir:Lvalue", ptr %l11, i32 0, i32 1
  %t81 = getelementptr %"compiler/mir:Range", ptr %t80, i32 0, i32 1
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = icmp ne i32 %t82, 0
  br i1 %t84, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t87 = load %"compiler/mir:Lvalue", ptr %l11
  %t89 = call i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %t87)
  store i64 %t89, ptr %l52
  br label %bb16
bb16:
  %t90 = load i64, ptr %l52, !tbaa !24
  store i64 %t90, ptr %l12, !tbaa !24
  %t91 = load i64, ptr %l12, !tbaa !24
  %t93 = icmp slt i64 %t91, 0
  br i1 %t93, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l55, !tbaa !21
  br label %bb21
bb18:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l56, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/mir:Fn", ptr %t96, i32 0, i32 7
  %t99 = load i64, ptr %l12, !tbaa !24
  %t102 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t98, i64 %t99)
  store %"compiler/mir:Local" %t102, ptr %l60
  br label %bb19
bb19:
  %t103 = getelementptr %"compiler/mir:Local", ptr %l60, i32 0, i32 2
  %t104 = load i32, ptr %t103, !tbaa !23
  %t105 = load ptr, ptr %l56, !tbaa !29
  %t107 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %t105, i32 %t104)
  store i1 %t107, ptr %l62
  br label %bb20
bb20:
  %t108 = load i1, ptr %l62, !tbaa !21
  %t109 = xor i1 %t108, true
  store i1 %t109, ptr %l55, !tbaa !21
  br label %bb21
bb21:
  %t111 = load i1, ptr %l55, !tbaa !21
  br i1 %t111, label %bb22, label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t113 = load i64, ptr %l12, !tbaa !24
  store i64 %t113, ptr %l13, !tbaa !24
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l66, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/mir:Fn", ptr %t116, i32 0, i32 7
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t118, i64 %t119)
  store %"compiler/mir:Local" %t122, ptr %l70
  br label %bb25
bb25:
  %t123 = getelementptr %"compiler/mir:Local", ptr %l70, i32 0, i32 2
  %t124 = load i32, ptr %t123, !tbaa !23
  %t125 = load ptr, ptr %l66, !tbaa !29
  %t127 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t125, i32 %t124)
  store i64 %t127, ptr %l72
  br label %bb26
bb26:
  %t128 = load i64, ptr %l72, !tbaa !24
  store i64 %t128, ptr %l14, !tbaa !24
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/mir:Fn", ptr %t129, i32 0, i32 7
  %t132 = load i64, ptr %l12, !tbaa !24
  %t135 = call %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v1, ptr %t131, i64 %t132)
  store %"compiler/mir:Local" %t135, ptr %l76
  br label %bb27
bb27:
  %t136 = getelementptr %"compiler/mir:Local", ptr %l76, i32 0, i32 2
  %t137 = load i32, ptr %t136, !tbaa !23
  %t139 = sext i32 %t137 to i64
  %t141 = load ptr, ptr %l3, !tbaa !29
  %t143 = getelementptr %"compiler/eval:cfn", ptr %t141, i32 0, i32 13
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l80, !tbaa !27
  %t145 = load i64, ptr %l4, !tbaa !24
  %t146 = load i64, ptr %l13, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr i64, ptr %t150, i64 %t145
  store i64 %t146, ptr %t151, !tbaa !34
  %t152 = load ptr, ptr %l3, !tbaa !29
  %t154 = getelementptr %"compiler/eval:cfn", ptr %t152, i32 0, i32 13
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l84, !tbaa !27
  %t156 = load i64, ptr %l4, !tbaa !24
  %t158 = add i64 %t156, 1
  %t159 = load i64, ptr %l14, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i64, ptr %t163, i64 %t158
  store i64 %t159, ptr %t164, !tbaa !34
  %t165 = load ptr, ptr %l3, !tbaa !29
  %t167 = getelementptr %"compiler/eval:cfn", ptr %t165, i32 0, i32 13
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  store { i64, ptr } %t168, ptr %l89, !tbaa !27
  %t169 = load i64, ptr %l5, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr i64, ptr %t174, i64 %t169
  store i64 %t139, ptr %t175, !tbaa !34
  store i1 true, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  call void @__olang_check_failed(ptr @olang_loc_e07540d555d7dc03_f134256d7232b767)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatCompare(ptr %v0, ptr %a0, i32 %a1, double %a2, double %a3) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca double
  %l3 = alloca double
  %l4 = alloca i1
  %l5 = alloca i1
  %l49 = alloca i64
  %l51 = alloca i64
  %rv = alloca i64
  store i32 %a1, ptr %l1
  store double %a2, ptr %l2
  store double %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1
  %t3 = trunc i64 13 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t6 = load double, ptr %l2, !tbaa !26
  %t7 = load double, ptr %l3, !tbaa !26
  %t10 = fcmp oeq double %t6, %t7
  store i1 %t10, ptr %l5, !tbaa !21
  br label %bb29
bb4:
  %t12 = load i32, ptr %l1
  %t14 = trunc i64 14 to i32
  %t15 = icmp eq i32 %t12, %t14
  br i1 %t15, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t17 = load double, ptr %l2, !tbaa !26
  %t18 = load double, ptr %l3, !tbaa !26
  %t21 = fcmp une double %t17, %t18
  store i1 %t21, ptr %l5, !tbaa !21
  br label %bb29
bb8:
  %t23 = load i32, ptr %l1
  %t25 = trunc i64 15 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t28 = load double, ptr %l2, !tbaa !26
  %t29 = load double, ptr %l3, !tbaa !26
  %t32 = fcmp olt double %t28, %t29
  store i1 %t32, ptr %l5, !tbaa !21
  br label %bb29
bb12:
  %t34 = load i32, ptr %l1
  %t36 = trunc i64 16 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t39 = load double, ptr %l2, !tbaa !26
  %t40 = load double, ptr %l3, !tbaa !26
  %t43 = fcmp ole double %t39, %t40
  store i1 %t43, ptr %l5, !tbaa !21
  br label %bb29
bb16:
  %t45 = load i32, ptr %l1
  %t47 = trunc i64 17 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t50 = load double, ptr %l2, !tbaa !26
  %t51 = load double, ptr %l3, !tbaa !26
  %t54 = fcmp ogt double %t50, %t51
  store i1 %t54, ptr %l5, !tbaa !21
  br label %bb29
bb20:
  %t56 = load i32, ptr %l1
  %t58 = trunc i64 18 to i32
  %t59 = icmp eq i32 %t56, %t58
  br i1 %t59, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  %t61 = load double, ptr %l2, !tbaa !26
  %t62 = load double, ptr %l3, !tbaa !26
  %t65 = fcmp oge double %t61, %t62
  store i1 %t65, ptr %l5, !tbaa !21
  br label %bb29
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store i1 false, ptr %l5, !tbaa !21
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_9ff5c0c5c0f3031a_9845a0a415f7f056)
  unreachable
bb29:
  %t67 = load i1, ptr %l5, !tbaa !21
  store i1 %t67, ptr %l4, !tbaa !21
  %t68 = load i32, ptr %l1
  %t70 = trunc i64 13 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb30, label %bb31
bb30:
  br label %bb42
bb31:
  %t73 = load i32, ptr %l1
  %t75 = trunc i64 14 to i32
  %t76 = icmp eq i32 %t73, %t75
  br i1 %t76, label %bb32, label %bb33
bb32:
  br label %bb42
bb33:
  %t78 = load i32, ptr %l1
  %t80 = trunc i64 15 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb34, label %bb35
bb34:
  br label %bb42
bb35:
  %t83 = load i32, ptr %l1
  %t85 = trunc i64 16 to i32
  %t86 = icmp eq i32 %t83, %t85
  br i1 %t86, label %bb36, label %bb37
bb36:
  br label %bb42
bb37:
  %t88 = load i32, ptr %l1
  %t90 = trunc i64 17 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb38, label %bb39
bb38:
  br label %bb42
bb39:
  %t93 = load i32, ptr %l1
  %t95 = trunc i64 18 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb49
bb43:
  br i1 true, label %bb44, label %bb45
bb44:
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t100 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %a0)
  store i64 %t100, ptr %l49
  br label %bb47
bb47:
  %t101 = load i64, ptr %l49, !tbaa !24
  store i64 %t101, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_dc78e3ab17f01d1b_791cd762b2865477)
  unreachable
bb49:
  %t102 = load i1, ptr %l4, !tbaa !21
  br i1 %t102, label %bb50, label %bb51
bb50:
  store i64 1, ptr %l51, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l51, !tbaa !24
  br label %bb52
bb52:
  %t104 = load i64, ptr %l51, !tbaa !24
  store i64 %t104, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2efloatText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca i32
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a2)
  store i32 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l3, !tbaa !23
  %t10 = load i32, ptr %l3, !tbaa !23
  %t12 = icmp eq i32 %t10, 11
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t16 = and i64 %t14, 65535
  %t18 = trunc i64 %t16 to i16
  %t20 = call i16 asm "", "=r,0"(i16 %t18)
  %t21 = bitcast i16 %t20 to half
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t23 = fpext half %t21 to double
  %t24 = call ptr @__olang_sb_room(ptr %s2, i64 48)
  %t25 = call i64 @__olang_fmt_float(ptr %t24, i64 48, double %t23, i32 2)
  call void @__olang_sb_add(ptr %s2, i64 %t25)
  %t26 = load ptr, ptr %s2
  %t27 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t28 = load i64, ptr %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t26, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l15, !tbaa !27
  %t32 = getelementptr %olang.builder, ptr %s2, i32 0, i32 3
  %t33 = load ptr, ptr %t32
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %sbgrew.35, label %sbdone.36
sbgrew.35:
  call void @__olang_sb_done(ptr %s2)
  br label %sbdone.36
sbdone.36:
  %t37 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t37, ptr %l8, !tbaa !27
  br label %bb18
bb5:
  %t38 = load i32, ptr %l3, !tbaa !23
  %t40 = icmp eq i32 %t38, 12
  br i1 %t40, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t44 = and i64 %t42, 65535
  %t46 = trunc i64 %t44 to i16
  %t48 = bitcast i16 %t46 to bfloat
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t50 = fpext bfloat %t48 to double
  %t51 = call ptr @__olang_sb_room(ptr %s4, i64 48)
  %t52 = call i64 @__olang_fmt_float(ptr %t51, i64 48, double %t50, i32 3)
  call void @__olang_sb_add(ptr %s4, i64 %t52)
  %t53 = load ptr, ptr %s4
  %t54 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t55 = load i64, ptr %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t53, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  store { i64, ptr } %t58, ptr %l22, !tbaa !27
  %t59 = getelementptr %olang.builder, ptr %s4, i32 0, i32 3
  %t60 = load ptr, ptr %t59
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %sbgrew.62, label %sbdone.63
sbgrew.62:
  call void @__olang_sb_done(ptr %s4)
  br label %sbdone.63
sbdone.63:
  %t64 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t64, ptr %l8, !tbaa !27
  br label %bb18
bb9:
  %t65 = load i32, ptr %l3, !tbaa !23
  %t67 = icmp eq i32 %t65, 13
  br i1 %t67, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = and i64 %t69, 4294967295
  %t73 = trunc i64 %t71 to i32
  %t75 = bitcast i32 %t73 to float
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t77 = fpext float %t75 to double
  %t78 = call ptr @__olang_sb_room(ptr %s6, i64 48)
  %t79 = call i64 @__olang_fmt_float(ptr %t78, i64 48, double %t77, i32 1)
  call void @__olang_sb_add(ptr %s6, i64 %t79)
  %t80 = load ptr, ptr %s6
  %t81 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t82 = load i64, ptr %t81
  %t83 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t82)
  call void @olang_textcopy(ptr %t83, ptr %t80, i64 %t82)
  %t84 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l29, !tbaa !27
  %t86 = getelementptr %olang.builder, ptr %s6, i32 0, i32 3
  %t87 = load ptr, ptr %t86
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %sbgrew.89, label %sbdone.90
sbgrew.89:
  call void @__olang_sb_done(ptr %s6)
  br label %sbdone.90
sbdone.90:
  %t91 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t91, ptr %l8, !tbaa !27
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  %t92 = load i64, ptr %l1, !tbaa !24
  %t95 = bitcast i64 %t92 to double
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t97 = call ptr @__olang_sb_room(ptr %s8, i64 48)
  %t98 = call i64 @__olang_fmt_float(ptr %t97, i64 48, double %t95, i32 0)
  call void @__olang_sb_add(ptr %s8, i64 %t98)
  %t99 = load ptr, ptr %s8
  %t100 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t101 = load i64, ptr %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t99, i64 %t101)
  %t103 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  store { i64, ptr } %t104, ptr %l33, !tbaa !27
  %t105 = getelementptr %olang.builder, ptr %s8, i32 0, i32 3
  %t106 = load ptr, ptr %t105
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %sbgrew.108, label %sbdone.109
sbgrew.108:
  call void @__olang_sb_done(ptr %s8)
  br label %sbdone.109
sbdone.109:
  %t110 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t110, ptr %l8, !tbaa !27
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1a5820d8caa3da70_8ddb412d29c69c24)
  unreachable
bb18:
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l8 = alloca %"compiler/mir:Fn"
  %t15 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 16
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 49
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:frame", ptr %t11, i64 %a1
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t15, ptr %v0, ptr %v1, ptr %t3, i64 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t15, i64 248, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l8, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2efreedEarly(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 69
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 70
  %t8 = getelementptr %"compiler/source:Span", ptr %t7, i32 0, i32 0
  %t9 = load i32, ptr %t8, !tbaa !23
  %t10 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFreedEarly, !tbaa !27
  %t11 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t12 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t14 = call i64 @__olang_fmt_i64(ptr null, i64 %t4)
  %t15 = add i64 %t12, %t14
  %t16 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t20 = sext i32 %t9 to i64
  %t21 = call i64 @__olang_fmt_i64(ptr null, i64 %t20)
  %t22 = add i64 %t18, %t21
  %t23 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t27 = extractvalue { i64, ptr } %t10, 1
  %t28 = extractvalue { i64, ptr } %t10, 0
  %t29 = add i64 %t25, %t28
  %t30 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t32 = add i64 %t29, %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @olang_textcopy(ptr %t33, ptr %t11, i64 %t12)
  %t34 = getelementptr i8, ptr %t33, i64 %t12
  %t35 = call i64 @__olang_fmt_i64(ptr %t34, i64 %t4)
  %t36 = getelementptr i8, ptr %t34, i64 %t14
  call void @olang_textcopy(ptr %t36, ptr %t16, i64 %t17)
  %t37 = getelementptr i8, ptr %t36, i64 %t17
  %t38 = call i64 @__olang_fmt_i64(ptr %t37, i64 %t20)
  %t39 = getelementptr i8, ptr %t37, i64 %t21
  call void @olang_textcopy(ptr %t39, ptr %t23, i64 %t24)
  %t40 = getelementptr i8, ptr %t39, i64 %t24
  call void @olang_textcopy(ptr %t40, ptr %t27, i64 %t28)
  %t41 = getelementptr i8, ptr %t40, i64 %t28
  call void @olang_textcopy(ptr %t41, ptr %t30, i64 %t31)
  %t42 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t33, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = mul i64 %t45, 1
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @llvm.memcpy.p0.p0.i64(ptr %t48, ptr %t46, i64 %t47, i1 false)
  %t49 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = call i32 @std_2fio_2ePrintErr(ptr %s0, { i64, ptr } %t50)
  store i32 %t52, ptr %l8
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb2, label %ok.54, !prof !99
ok.54:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t55 = load i32, ptr %l8, !tbaa !23
  %t56 = ashr i32 %t55, 16
  %t58 = icmp eq i32 %t56, 1
  store i1 %t58, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  call void @std_2fos_2eExit(i32 70)
  unreachable
bb5:
  call void @__olang_check_failed(ptr @olang_loc_c25616630356082_96e485ee4d1c8d36)
  unreachable
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalWritten(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l11 = alloca i64
  %l13 = alloca ptr
  %l16 = alloca %"compiler/eval:gkey"
  %l17 = alloca i64
  %l18 = alloca i32
  %l21 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l2
  %t4 = load { i64, [2 x i64] }, ptr %l2
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t10 = getelementptr { i64, i32, i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t14 = getelementptr { i64, i32, i32 }, ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l4, !tbaa !23
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 34
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = load i32, ptr %l4, !tbaa !23
  %t24 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s1, i64 %t20, i32 %t21)
  store %"compiler/eval:gkey" %t24, ptr %l16
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = load %"compiler/eval:gkey", ptr %l16
  %t27 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t25, %"compiler/eval:gkey" %t26)
  %t28 = extractvalue { i32, i64 } %t27, 1
  %t29 = extractvalue { i32, i64 } %t27, 0
  store i32 %t29, ptr %l18
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store i64 %t28, ptr %l17
  br label %bb5
bb5:
  %t32 = load i64, ptr %l17, !tbaa !24
  store i64 %t32, ptr %l11, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l11, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l11, !tbaa !24
  store i64 %t33, ptr %l5, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 64
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp ne i64 %t38, %t42
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobalVar, !tbaa !27
  %t50 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t50, ptr %t48, { i64, ptr } %t49)
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_cdcdbab6c5a00ca5_1566754bdc1f9529)
  unreachable
bb21:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalsReady(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2, { i64, [15 x i64] } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca { i64, [15 x i64] }
  %l4 = alloca %"compiler/mir:Fn"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca %"compiler/mir:Lvalue"
  %l7 = alloca %"compiler/mir:Lvalue"
  %l8 = alloca { i64, [4 x i64] }
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Range"
  %l11 = alloca { i64, [4 x i64] }
  %l12 = alloca { i64, [4 x i64] }
  %l16 = alloca { i64, ptr }
  %l19 = alloca %"compiler/mir:Fn"
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i1
  %l42 = alloca i1
  %l55 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l74 = alloca i1
  %l91 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l104 = alloca i1
  %rv = alloca i1
  %t15 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [15 x i64] } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 16
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/eval:Machine", ptr %t4, i32 0, i32 49
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l16, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/eval:frame", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i32 0, i32 0
  %t14 = load i64, ptr %t13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t15, ptr %v0, ptr %v0, ptr %t3, i64 %t14)
  call void @llvm.memmove.p0.p0.i64(ptr %l19, ptr %t15, i64 248, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l19, i64 248, i1 false)
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/eval:Machine", ptr %t18, i32 0, i32 1
  %t21 = load i32, ptr %t20
  %t23 = trunc i64 0 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb2, label %bb3
bb2:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalWritten(ptr %v0, ptr %t26, %"compiler/mir:Lvalue" %a2)
  store i1 %t30, ptr %l26
  br label %bb4
bb3:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb5
bb4:
  %t31 = load i1, ptr %l26, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l23, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t36 = load { i64, [15 x i64] }, ptr %l3
  %t38 = extractvalue { i64, [15 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 0
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t42 = getelementptr { { i64, [4 x i64] } }, ptr %t41, i32 0, i32 0
  %t43 = load { i64, [4 x i64] }, ptr %t42
  store { i64, [4 x i64] } %t43, ptr %l5
  br label %bb15
bb10:
  %t45 = load { i64, [15 x i64] }, ptr %l3
  %t47 = extractvalue { i64, [15 x i64] } %t45, 0
  %t48 = icmp eq i64 %t47, 7
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t50 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t51 = getelementptr { { i64, [1 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t50, i32 0, i32 1
  %t52 = load { i64, [4 x i64] }, ptr %t51
  store { i64, [4 x i64] } %t52, ptr %l5
  br label %bb15
bb12:
  %t54 = load { i64, [15 x i64] }, ptr %l3
  %t56 = extractvalue { i64, [15 x i64] } %t54, 0
  %t57 = icmp eq i64 %t56, 11
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t60 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t59, i32 0, i32 0
  %t61 = load { i64, [4 x i64] }, ptr %t60
  store { i64, [4 x i64] } %t61, ptr %l5
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i64, ptr %l1, !tbaa !24
  %t65 = load { i64, [4 x i64] }, ptr %l5
  %t69 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t63, i64 %t64, { i64, [4 x i64] } %t65)
  store i1 %t69, ptr %l42
  br label %bb16
bb16:
  %t70 = load i1, ptr %l42, !tbaa !21
  store i1 %t70, ptr %l29, !tbaa !21
  br label %bb64
bb17:
  %t71 = load { i64, [15 x i64] }, ptr %l3
  %t73 = extractvalue { i64, [15 x i64] } %t71, 0
  %t74 = icmp eq i64 %t73, 1
  br i1 %t74, label %bb18, label %bb19
bb18:
  %t76 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t77 = getelementptr { %"compiler/mir:Lvalue", i32 }, ptr %t76, i32 0, i32 0
  %t78 = load %"compiler/mir:Lvalue", ptr %t77
  store %"compiler/mir:Lvalue" %t78, ptr %l6
  br label %bb24
bb19:
  %t80 = load { i64, [15 x i64] }, ptr %l3
  %t82 = extractvalue { i64, [15 x i64] } %t80, 0
  %t83 = icmp eq i64 %t82, 2
  br i1 %t83, label %bb20, label %bb21
bb20:
  %t85 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t86 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t85, i32 0, i32 0
  %t87 = load %"compiler/mir:Lvalue", ptr %t86
  store %"compiler/mir:Lvalue" %t87, ptr %l6
  br label %bb24
bb21:
  %t89 = load { i64, [15 x i64] }, ptr %l3
  %t91 = extractvalue { i64, [15 x i64] } %t89, 0
  %t92 = icmp eq i64 %t91, 5
  br i1 %t92, label %bb22, label %bb23
bb22:
  %t94 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t95 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t94, i32 0, i32 0
  %t96 = load %"compiler/mir:Lvalue", ptr %t95
  store %"compiler/mir:Lvalue" %t96, ptr %l6
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load i64, ptr %l1, !tbaa !24
  %t100 = load %"compiler/mir:Lvalue", ptr %l6
  %t104 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %t98, i64 %t99, %"compiler/mir:Lvalue" %t100)
  store i1 %t104, ptr %l55
  br label %bb25
bb25:
  %t105 = load i1, ptr %l55, !tbaa !21
  store i1 %t105, ptr %l29, !tbaa !21
  br label %bb64
bb26:
  %t106 = load { i64, [15 x i64] }, ptr %l3
  %t108 = extractvalue { i64, [15 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 9
  br i1 %t109, label %bb27, label %bb28
bb27:
  %t111 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t112 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t111, i32 0, i32 0
  %t113 = load %"compiler/mir:Lvalue", ptr %t112
  store %"compiler/mir:Lvalue" %t113, ptr %l7
  %t115 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t116 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t115, i32 0, i32 1
  %t117 = load { i64, [4 x i64] }, ptr %t116
  store { i64, [4 x i64] } %t117, ptr %l8
  %t119 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t120 = getelementptr { %"compiler/mir:Lvalue", { i64, [4 x i64] }, { i64, [4 x i64] }, i32 }, ptr %t119, i32 0, i32 2
  %t121 = load { i64, [4 x i64] }, ptr %t120
  store { i64, [4 x i64] } %t121, ptr %l9
  br label %bb29
bb28:
  br label %bb39
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l1, !tbaa !24
  %t125 = load %"compiler/mir:Lvalue", ptr %l7
  %t129 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %t123, i64 %t124, %"compiler/mir:Lvalue" %t125)
  store i1 %t129, ptr %l64
  br label %bb30
bb30:
  %t130 = load i1, ptr %l64, !tbaa !21
  br i1 %t130, label %bb31, label %bb32
bb31:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l1, !tbaa !24
  %t133 = load { i64, [4 x i64] }, ptr %l8
  %t137 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t131, i64 %t132, { i64, [4 x i64] } %t133)
  store i1 %t137, ptr %l69
  br label %bb33
bb32:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb34
bb33:
  %t138 = load i1, ptr %l69, !tbaa !21
  store i1 %t138, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t139 = load i1, ptr %l65, !tbaa !21
  br i1 %t139, label %bb35, label %bb36
bb35:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i64, ptr %l1, !tbaa !24
  %t142 = load { i64, [4 x i64] }, ptr %l9
  %t146 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t140, i64 %t141, { i64, [4 x i64] } %t142)
  store i1 %t146, ptr %l74
  br label %bb37
bb36:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb38
bb37:
  %t147 = load i1, ptr %l74, !tbaa !21
  store i1 %t147, ptr %l70, !tbaa !21
  br label %bb38
bb38:
  %t148 = load i1, ptr %l70, !tbaa !21
  store i1 %t148, ptr %l29, !tbaa !21
  br label %bb64
bb39:
  %t149 = load { i64, [15 x i64] }, ptr %l3
  %t151 = extractvalue { i64, [15 x i64] } %t149, 0
  %t152 = icmp eq i64 %t151, 3
  br i1 %t152, label %bb40, label %bb41
bb40:
  %t154 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t155 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t154, i32 0, i32 2
  %t156 = load %"compiler/mir:Range", ptr %t155
  store %"compiler/mir:Range" %t156, ptr %l10
  br label %bb48
bb41:
  %t158 = load { i64, [15 x i64] }, ptr %l3
  %t160 = extractvalue { i64, [15 x i64] } %t158, 0
  %t161 = icmp eq i64 %t160, 4
  br i1 %t161, label %bb42, label %bb43
bb42:
  %t163 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t164 = getelementptr { i32, i32, %"compiler/mir:Range" }, ptr %t163, i32 0, i32 2
  %t165 = load %"compiler/mir:Range", ptr %t164
  store %"compiler/mir:Range" %t165, ptr %l10
  br label %bb48
bb43:
  %t167 = load { i64, [15 x i64] }, ptr %l3
  %t169 = extractvalue { i64, [15 x i64] } %t167, 0
  %t170 = icmp eq i64 %t169, 6
  br i1 %t170, label %bb44, label %bb45
bb44:
  %t172 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t173 = getelementptr { i32, i64, %"compiler/mir:Range" }, ptr %t172, i32 0, i32 2
  %t174 = load %"compiler/mir:Range", ptr %t173
  store %"compiler/mir:Range" %t174, ptr %l10
  br label %bb48
bb45:
  %t176 = load { i64, [15 x i64] }, ptr %l3
  %t178 = extractvalue { i64, [15 x i64] } %t176, 0
  %t179 = icmp eq i64 %t178, 10
  br i1 %t179, label %bb46, label %bb47
bb46:
  %t181 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t182 = getelementptr { { i64, [2 x i64] }, i32, { i64, [1 x i64] }, %"compiler/mir:Range", %"compiler/mir:Range" }, ptr %t181, i32 0, i32 3
  %t183 = load %"compiler/mir:Range", ptr %t182
  store %"compiler/mir:Range" %t183, ptr %l10
  br label %bb48
bb47:
  br label %bb50
bb48:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l1, !tbaa !24
  %t187 = load %"compiler/mir:Range", ptr %l10
  %t192 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v0, ptr %t185, i64 %t186, ptr %l4, %"compiler/mir:Range" %t187)
  store i1 %t192, ptr %l91
  br label %bb49
bb49:
  %t193 = load i1, ptr %l91, !tbaa !21
  store i1 %t193, ptr %l29, !tbaa !21
  br label %bb64
bb50:
  %t194 = load { i64, [15 x i64] }, ptr %l3
  %t196 = extractvalue { i64, [15 x i64] } %t194, 0
  %t197 = icmp eq i64 %t196, 8
  br i1 %t197, label %bb51, label %bb52
bb51:
  %t199 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t200 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t199, i32 0, i32 2
  %t201 = load { i64, [4 x i64] }, ptr %t200
  store { i64, [4 x i64] } %t201, ptr %l11
  %t203 = getelementptr { i64, [15 x i64] }, ptr %l3, i32 0, i32 1
  %t204 = getelementptr { { i64, [1 x i64] }, i32, { i64, [4 x i64] }, { i64, [4 x i64] } }, ptr %t203, i32 0, i32 3
  %t205 = load { i64, [4 x i64] }, ptr %t204
  store { i64, [4 x i64] } %t205, ptr %l12
  br label %bb53
bb52:
  br label %bb59
bb53:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i64, ptr %l1, !tbaa !24
  %t209 = load { i64, [4 x i64] }, ptr %l11
  %t213 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t207, i64 %t208, { i64, [4 x i64] } %t209)
  store i1 %t213, ptr %l99
  br label %bb54
bb54:
  %t214 = load i1, ptr %l99, !tbaa !21
  br i1 %t214, label %bb55, label %bb56
bb55:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i64, ptr %l1, !tbaa !24
  %t217 = load { i64, [4 x i64] }, ptr %l12
  %t221 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %t215, i64 %t216, { i64, [4 x i64] } %t217)
  store i1 %t221, ptr %l104
  br label %bb57
bb56:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb58
bb57:
  %t222 = load i1, ptr %l104, !tbaa !21
  store i1 %t222, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t223 = load i1, ptr %l100, !tbaa !21
  store i1 %t223, ptr %l29, !tbaa !21
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_d7d71e32b1402da8_19cce939fe39e26c)
  unreachable
bb64:
  %t224 = load i1, ptr %l29, !tbaa !21
  store i1 %t224, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca ptr
  %l7 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = load { i64, [4 x i64] }, ptr %l2
  %t8 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t2, i64 %t3, { i64, [4 x i64] } %t4)
  store i64 %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l2
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l11
  br label %bb2
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i32, ptr %l11, !tbaa !23
  %t19 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t16, i64 %t17, i32 %t18)
  store i64 %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load i64, ptr %l12, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintToFloat(ptr %v0, ptr %a0, i64 %a1, i1 %a2, i32 %a3) #0 {
entry:
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i64
  %l9 = alloca i32
  %l13 = alloca i64
  %l36 = alloca i64
  %rv = alloca i64
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t4, i32 %a3)
  store i32 %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load i32, ptr %l9, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  br i1 %a2, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l1, !tbaa !24
  store i64 %t12, ptr %l5, !tbaa !65
  %t15 = load i32, ptr %l4, !tbaa !23
  %t17 = icmp eq i32 %t15, 11
  br i1 %t17, label %bb4, label %bb5
bb3:
  br label %bb21
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load i64, ptr %l5, !tbaa !65
  %t21 = uitofp i64 %t19 to double
  %t22 = call double @llvm.arithmetic.fence.f64(double %t21)
  %t23 = fptrunc double %t22 to half
  %t25 = bitcast half %t23 to i16
  %t26 = call i16 asm "", "=r,0"(i16 %t25)
  %t28 = zext i16 %t26 to i64
  store i64 %t28, ptr %l13, !tbaa !24
  br label %bb20
bb7:
  %t30 = load i32, ptr %l4, !tbaa !23
  %t32 = icmp eq i32 %t30, 12
  br i1 %t32, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t34 = load i64, ptr %l5, !tbaa !65
  %t36 = call bfloat @__olang_int_bf16(i64 %t34, i1 false)
  %t38 = bitcast bfloat %t36 to i16
  %t39 = call i16 asm "", "=r,0"(i16 %t38)
  %t41 = zext i16 %t39 to i64
  store i64 %t41, ptr %l13, !tbaa !24
  br label %bb20
bb11:
  %t43 = load i32, ptr %l4, !tbaa !23
  %t45 = icmp eq i32 %t43, 13
  br i1 %t45, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t47 = load i64, ptr %l5, !tbaa !65
  %t49 = uitofp i64 %t47 to float
  %t51 = bitcast float %t49 to i32
  %t53 = zext i32 %t51 to i64
  store i64 %t53, ptr %l13, !tbaa !24
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t55 = load i64, ptr %l5, !tbaa !65
  %t57 = uitofp i64 %t55 to double
  %t59 = bitcast double %t57 to i64
  store i64 %t59, ptr %l13, !tbaa !24
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_20cdf2bac11b5657_20b8fcdfbd19fb1b)
  unreachable
bb20:
  %t62 = load i64, ptr %l13, !tbaa !24
  store i64 %t62, ptr %rv
  br label %ret
bb21:
  %t63 = load i32, ptr %l4, !tbaa !23
  %t65 = icmp eq i32 %t63, 11
  br i1 %t65, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t67 = load i64, ptr %l1, !tbaa !24
  %t69 = sitofp i64 %t67 to double
  %t70 = call double @llvm.arithmetic.fence.f64(double %t69)
  %t71 = fptrunc double %t70 to half
  %t73 = bitcast half %t71 to i16
  %t74 = call i16 asm "", "=r,0"(i16 %t73)
  %t76 = zext i16 %t74 to i64
  store i64 %t76, ptr %l36, !tbaa !24
  br label %bb38
bb25:
  %t78 = load i32, ptr %l4, !tbaa !23
  %t80 = icmp eq i32 %t78, 12
  br i1 %t80, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t82 = load i64, ptr %l1, !tbaa !24
  %t84 = icmp slt i64 %t82, 0
  %t85 = sub i64 0, %t82
  %t86 = select i1 %t84, i64 %t85, i64 %t82
  %t87 = call bfloat @__olang_int_bf16(i64 %t86, i1 %t84)
  %t89 = bitcast bfloat %t87 to i16
  %t90 = call i16 asm "", "=r,0"(i16 %t89)
  %t92 = zext i16 %t90 to i64
  store i64 %t92, ptr %l36, !tbaa !24
  br label %bb38
bb29:
  %t94 = load i32, ptr %l4, !tbaa !23
  %t96 = icmp eq i32 %t94, 13
  br i1 %t96, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t98 = load i64, ptr %l1, !tbaa !24
  %t100 = sitofp i64 %t98 to float
  %t102 = bitcast float %t100 to i32
  %t104 = zext i32 %t102 to i64
  store i64 %t104, ptr %l36, !tbaa !24
  br label %bb38
bb33:
  br i1 true, label %bb34, label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb37
bb36:
  %t106 = load i64, ptr %l1, !tbaa !24
  %t108 = sitofp i64 %t106 to double
  %t110 = bitcast double %t108 to i64
  store i64 %t110, ptr %l36, !tbaa !24
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_3dd741f2ac40c2b6_e435d9fa661ce11a)
  unreachable
bb38:
  %t113 = load i64, ptr %l36, !tbaa !24
  store i64 %t113, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l17 = alloca i64
  %l20 = alloca i1
  %l23 = alloca i64
  %l27 = alloca i64
  %l29 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 64
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l1, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load i64, ptr %l1, !tbaa !24
  store i64 %t13, ptr %l11, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = call i64 @compiler_2feval_2ebmask(i64 %t14)
  store i64 %t16, ptr %l13
  br label %bb5
bb5:
  %t17 = load i64, ptr %l11, !tbaa !24
  %t18 = load i64, ptr %l13, !tbaa !24
  %t19 = and i64 %t17, %t18
  store i64 %t19, ptr %l4, !tbaa !24
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i32, ptr %l2, !tbaa !23
  %t25 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t21, i32 %t22)
  store i64 %t25, ptr %l17
  br label %bb6
bb6:
  %t26 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t27 = load i64, ptr %l17, !tbaa !24
  %t29 = icmp eq i64 %t27, %t26
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t32, 1
  store i64 %t34, ptr %l23, !tbaa !24
  %t36 = load i64, ptr %l23, !tbaa !24
  %t37 = load i64, ptr %l23, !tbaa !24
  %t38 = ashr i64 %t31, %t37
  %t40 = and i64 %t38, 1
  %t42 = icmp eq i64 %t40, 1
  store i1 %t42, ptr %l20, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l20, !tbaa !21
  br i1 %t44, label %bb10, label %bb11
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  store i64 %t45, ptr %l27, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = call i64 @compiler_2feval_2ebmask(i64 %t46)
  store i64 %t48, ptr %l29
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t49 = load i64, ptr %l29, !tbaa !24
  %t50 = xor i64 %t49, -1
  %t51 = load i64, ptr %l27, !tbaa !24
  %t53 = or i64 %t51, %t50
  store i64 %t53, ptr %rv
  br label %ret
bb13:
  %t55 = load i64, ptr %l4, !tbaa !24
  store i64 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eleave(ptr %v0, ptr %a0, i64 %a1, i1 %a2, { i64, [4 x i64] } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l5 = alloca %"compiler/eval:frame"
  %l7 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 49
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l7, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = load %"compiler/eval:frame", ptr %t9
  store %"compiler/eval:frame" %t10, ptr %l5
  %t12 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 11
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load i1, ptr %l2, !tbaa !21
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb3, label %bb4
bb2:
  br label %bb11
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edeliver(ptr %v0, ptr %t21, i64 %t22, { i64, [4 x i64] } %a3)
  br label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 13
  %t30 = load i1, ptr %t29, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 49
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t36 = load i64, ptr %l1, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr %"compiler/eval:frame", ptr %t39, i64 %t36
  %t41 = getelementptr %"compiler/eval:frame", ptr %t40, i32 0, i32 11
  store i1 true, ptr %t41, !tbaa !21
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 49
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l23, !tbaa !27
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load i1, ptr %l2, !tbaa !21
  %t50 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"compiler/eval:frame", ptr %t51, i64 %t46
  %t53 = getelementptr %"compiler/eval:frame", ptr %t52, i32 0, i32 12
  store i1 %t47, ptr %t53, !tbaa !21
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 49
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l27, !tbaa !27
  %t58 = load i64, ptr %l1, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr %"compiler/eval:frame", ptr %t63, i64 %t58
  %t65 = getelementptr %"compiler/eval:frame", ptr %t64, i32 0, i32 13
  store i64 %a4, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t66, i32 0, i32 53
  %t69 = getelementptr %"compiler/eval:frame", ptr %l5, i32 0, i32 6
  %t70 = load i64, ptr %t69, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t68, i64 %t70)
  br label %bb10
bb10:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 49
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l34, !tbaa !27
  %t77 = load i64, ptr %l1, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"compiler/eval:frame", ptr %t80, i64 %t77
  %t82 = getelementptr %"compiler/eval:frame", ptr %t81, i32 0, i32 10
  store i1 true, ptr %t82, !tbaa !21
  br label %ret
bb11:
  %t83 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %t83)
  br label %bb12
bb12:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/eval:frame", ptr %l5
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereturned(ptr %v0, ptr %t85, %"compiler/eval:frame" %t86)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elenOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i32
  %l16 = alloca ptr
  %l19 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i64
  %l28 = alloca ptr
  %l32 = alloca %"compiler/eval:Ptr"
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a3)
  store i32 %t10, ptr %l10
  br label %bb1
bb1:
  %t11 = load i32, ptr %l10, !tbaa !23
  store i32 %t11, ptr %l5, !tbaa !23
  %t12 = load ptr, ptr %l4, !tbaa !29
  %t13 = load i32, ptr %l5, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l13
  br label %bb2
bb2:
  %t17 = load i32, ptr %l13
  %t19 = trunc i64 20 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l4, !tbaa !29
  store ptr %t22, ptr %l16, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t24 = load i32, ptr %l5, !tbaa !23
  %t27 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t23, i32 %t24)
  store i32 %t27, ptr %l19
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i32, ptr %l19, !tbaa !23
  %t30 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t28, i32 %t29)
  store i32 %t30, ptr %l20
  br label %bb6
bb6:
  %t31 = load i32, ptr %l20, !tbaa !23
  store i32 %t31, ptr %l5, !tbaa !23
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t33 = load i32, ptr %l5, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l23
  br label %bb8
bb8:
  %t37 = load i32, ptr %l23, !tbaa !23
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb9, label %bb10
bb9:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  %t44 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %t40, i32 %t41)
  store i64 %t44, ptr %l27
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t45 = load i64, ptr %l27, !tbaa !24
  store i64 %t45, ptr %rv
  br label %ret
bb12:
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l28, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t53 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t47, i64 %a1, { i64, [4 x i64] } %a2, i64 1)
  store %"compiler/eval:Ptr" %t53, ptr %l32
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l28, !tbaa !29
  %t55 = load %"compiler/eval:Ptr", ptr %l32
  %t56 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t54, %"compiler/eval:Ptr" %t55, i64 8)
  store i64 %t56, ptr %l33
  br label %bb14
bb14:
  %t57 = load i64, ptr %l33, !tbaa !24
  store i64 %t57, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l12 = alloca i64
  %l14 = alloca i1
  %l18 = alloca %"compiler/eval:scope"
  %l20 = alloca i1
  %l24 = alloca %"compiler/eval:scope"
  %l27 = alloca i64
  %rv = alloca i1
  %t26 = alloca %"compiler/eval:scope", align 8
  %t37 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t5 = and i64 %t1, %t2
  store i64 %t5, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  %t9 = icmp ne i64 %t7, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/eval:Machine", ptr %t12, i32 0, i32 43
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l12
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t17 = load i64, ptr %l9, !tbaa !24
  %t18 = load i64, ptr %l12, !tbaa !24
  %t19 = icmp slt i64 %t17, %t18
  store i1 %t19, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l8, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/eval:Machine", ptr %t22, i32 0, i32 43
  %t25 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t26, ptr %v0, ptr %t24, i64 %t25)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t26, i64 136, i1 false)
  br label %bb7
bb6:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb8
bb7:
  %t29 = getelementptr %"compiler/eval:scope", ptr %l18, i32 0, i32 1
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 43
  %t36 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t37, ptr %v0, ptr %t35, i64 %t36)
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %t37, i64 136, i1 false)
  br label %bb11
bb10:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb12
bb11:
  %t40 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t43, ptr %l27, !tbaa !24
  %t45 = load i64, ptr %l27, !tbaa !24
  %t46 = load i64, ptr %l27, !tbaa !24
  %t47 = ashr i64 %t42, %t46
  %t50 = icmp eq i64 %t41, %t47
  store i1 %t50, ptr %l20, !tbaa !21
  br label %bb12
bb12:
  %t52 = load i1, ptr %l20, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l20 = alloca %"compiler/eval:Ptr"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 51
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 49
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr %"compiler/eval:frame", ptr %t12, i64 %a1
  %t14 = getelementptr %"compiler/eval:frame", ptr %t13, i32 0, i32 3
  %t15 = load i64, ptr %t14, !tbaa !24
  %t18 = sext i32 %a2 to i64
  %t21 = add i64 %t15, %t18
  %t23 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = getelementptr i64, ptr %t24, i64 %t21
  %t26 = load i64, ptr %t25, !tbaa !34
  store i64 %t26, ptr %l3, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp eq i64 %t28, 0
  br i1 %t30, label %bb1, label %bb2
bb1:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyClosed, !tbaa !27
  %t34 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t34, ptr %t32, { i64, ptr } %t33)
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t37 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/eval:Ptr" %t37, ptr %rv
  br label %ret
bb4:
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s0, i64 %t39, i64 0)
  store %"compiler/eval:Ptr" %t41, ptr %l20
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t42 = load %"compiler/eval:Ptr", ptr %l20
  store %"compiler/eval:Ptr" %t42, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l12 = alloca i1
  %l17 = alloca ptr
  %l23 = alloca i1
  %l36 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l107 = alloca i1
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l134 = alloca i64
  %l142 = alloca i1
  %l143 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l155 = alloca i1
  %l173 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 50
  %t4 = load i64, ptr %t3, !tbaa !24
  %t8 = icmp sgt i64 %t4, %a1
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/eval:Machine", ptr %t10, i32 0, i32 13
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l12, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb59
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load ptr, ptr %l17, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 6
  %t23 = load i64, ptr %t22, !tbaa !24
  %t25 = add i64 %t23, 1
  %t27 = load ptr, ptr %l17, !tbaa !29
  %t28 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 6
  store i64 %t25, ptr %t28, !tbaa !24
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/eval:Machine", ptr %t29, i32 0, i32 2
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sge i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/eval:Machine", ptr %t36, i32 0, i32 6
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:Machine", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp sgt i64 %t39, %t43
  store i1 %t46, ptr %l23, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t48 = load i1, ptr %l23, !tbaa !21
  br i1 %t48, label %bb11, label %bb12
bb11:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhySteps, !tbaa !27
  %t51 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t51, ptr %t49, { i64, ptr } %t50)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %ret
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 50
  %t57 = load i64, ptr %t56, !tbaa !24
  %t59 = sub i64 %t57, 1
  store i64 %t59, ptr %l2, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Machine", ptr %t61, i32 0, i32 53
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t63)
  store i64 %t65, ptr %l36
  br label %bb15
bb15:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t66, i32 0, i32 49
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l38, !tbaa !27
  %t70 = load i64, ptr %l2, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr %"compiler/eval:frame", ptr %t73, i64 %t70
  %t75 = getelementptr %"compiler/eval:frame", ptr %t74, i32 0, i32 9
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = load i64, ptr %l36, !tbaa !24
  %t79 = icmp sgt i64 %t77, %t76
  br i1 %t79, label %bb16, label %bb17
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estepClose(ptr %v0, ptr %t81)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb58
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/eval:Machine", ptr %t83, i32 0, i32 49
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l44, !tbaa !27
  %t87 = load i64, ptr %l2, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr %"compiler/eval:frame", ptr %t90, i64 %t87
  %t92 = getelementptr %"compiler/eval:frame", ptr %t91, i32 0, i32 0
  %t93 = load i64, ptr %t92, !tbaa !24
  store i64 %t93, ptr %l3, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/eval:Machine", ptr %t95, i32 0, i32 49
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l48, !tbaa !27
  %t99 = load i64, ptr %l2, !tbaa !24
  %t101 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr %"compiler/eval:frame", ptr %t102, i64 %t99
  %t104 = getelementptr %"compiler/eval:frame", ptr %t103, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  store i64 %t105, ptr %l4, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/eval:Machine", ptr %t107, i32 0, i32 17
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l52, !tbaa !27
  %t111 = load i64, ptr %l3, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr %"compiler/eval:cfn", ptr %t114, i64 %t111
  %t116 = getelementptr %"compiler/eval:cfn", ptr %t115, i32 0, i32 8
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l54, !tbaa !27
  %t118 = load i64, ptr %l4, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l54, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr i64, ptr %t121, i64 %t118
  %t123 = load i64, ptr %t122, !tbaa !34
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/eval:Machine", ptr %t124, i32 0, i32 49
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l58, !tbaa !27
  %t128 = load i64, ptr %l2, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr %"compiler/eval:frame", ptr %t131, i64 %t128
  %t133 = getelementptr %"compiler/eval:frame", ptr %t132, i32 0, i32 2
  %t134 = load i64, ptr %t133, !tbaa !24
  %t137 = add i64 %t123, %t134
  store i64 %t137, ptr %l5, !tbaa !24
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/eval:Machine", ptr %t139, i32 0, i32 49
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l63, !tbaa !27
  %t143 = load i64, ptr %l2, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr %"compiler/eval:frame", ptr %t146, i64 %t143
  %t148 = getelementptr %"compiler/eval:frame", ptr %t147, i32 0, i32 10
  %t149 = load i1, ptr %t148, !tbaa !21
  br i1 %t149, label %bb20, label %bb21
bb20:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/eval:Machine", ptr %t151, i32 0, i32 49
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l67, !tbaa !27
  %t155 = load i64, ptr %l2, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr %"compiler/eval:frame", ptr %t158, i64 %t155
  %t160 = getelementptr %"compiler/eval:frame", ptr %t159, i32 0, i32 10
  store i1 false, ptr %t160, !tbaa !21
  %t161 = load i64, ptr %l5, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 17
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l71, !tbaa !27
  %t166 = load i64, ptr %l3, !tbaa !24
  %t168 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr %"compiler/eval:cfn", ptr %t169, i64 %t166
  %t171 = getelementptr %"compiler/eval:cfn", ptr %t170, i32 0, i32 8
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l73, !tbaa !27
  %t173 = load i64, ptr %l4, !tbaa !24
  %t175 = add i64 %t173, 1
  %t177 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !27
  %t179 = getelementptr i64, ptr %t178, i64 %t175
  %t180 = load i64, ptr %t179, !tbaa !34
  %t183 = icmp slt i64 %t161, %t180
  br i1 %t183, label %bb22, label %bb23
bb21:
  br label %bb26
bb22:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/eval:Machine", ptr %t185, i32 0, i32 49
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  store { i64, ptr } %t188, ptr %l79, !tbaa !27
  %t189 = load i64, ptr %l2, !tbaa !24
  store i64 %t189, ptr %l80, !tbaa !24
  %t190 = load i64, ptr %l80, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr %"compiler/eval:frame", ptr %t192, i64 %t190
  %t194 = getelementptr %"compiler/eval:frame", ptr %t193, i32 0, i32 2
  %t195 = load i64, ptr %t194, !tbaa !24
  %t197 = add i64 %t195, 1
  %t199 = load i64, ptr %l80, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr %"compiler/eval:frame", ptr %t201, i64 %t199
  %t203 = getelementptr %"compiler/eval:frame", ptr %t202, i32 0, i32 2
  store i64 %t197, ptr %t203, !tbaa !24
  br label %bb25
bb23:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i64, ptr %l2, !tbaa !24
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/eval:Machine", ptr %t206, i32 0, i32 17
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l86, !tbaa !27
  %t210 = load i64, ptr %l3, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr %"compiler/eval:cfn", ptr %t213, i64 %t210
  %t215 = getelementptr %"compiler/eval:cfn", ptr %t214, i32 0, i32 9
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !27
  store { i64, ptr } %t216, ptr %l88, !tbaa !27
  %t217 = load i64, ptr %l4, !tbaa !24
  %t219 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = getelementptr { i64, [8 x i64] }, ptr %t220, i64 %t217
  %t222 = load { i64, [8 x i64] }, ptr %t221
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/eval:Machine", ptr %t223, i32 0, i32 17
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  store { i64, ptr } %t226, ptr %l92, !tbaa !27
  %t227 = load i64, ptr %l3, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr %"compiler/eval:cfn", ptr %t230, i64 %t227
  %t232 = getelementptr %"compiler/eval:cfn", ptr %t231, i32 0, i32 11
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l94, !tbaa !27
  %t234 = load i64, ptr %l4, !tbaa !24
  %t236 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr i1, ptr %t237, i64 %t234
  %t239 = load i1, ptr %t238, !tbaa !31
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eterm(ptr %v0, ptr %t204, i64 %t205, { i64, [8 x i64] } %t222, i1 %t239)
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb58
bb26:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/eval:Machine", ptr %t244, i32 0, i32 17
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l98, !tbaa !27
  %t248 = load i64, ptr %l3, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr %"compiler/eval:cfn", ptr %t251, i64 %t248
  %t253 = getelementptr %"compiler/eval:cfn", ptr %t252, i32 0, i32 8
  %t254 = load { i64, ptr }, ptr %t253, !tbaa !27
  store { i64, ptr } %t254, ptr %l100, !tbaa !27
  %t255 = load i64, ptr %l4, !tbaa !24
  %t257 = add i64 %t255, 1
  %t259 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr i64, ptr %t260, i64 %t257
  %t262 = load i64, ptr %t261, !tbaa !34
  store i64 %t262, ptr %l6, !tbaa !24
  %t264 = load i64, ptr %l5, !tbaa !24
  %t265 = load i64, ptr %l6, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  br i1 %t268, label %bb27, label %bb28
bb27:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/eval:Machine", ptr %t270, i32 0, i32 17
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  store { i64, ptr } %t273, ptr %l109, !tbaa !27
  %t274 = load i64, ptr %l3, !tbaa !24
  %t276 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !27
  %t278 = getelementptr %"compiler/eval:cfn", ptr %t277, i64 %t274
  %t279 = getelementptr %"compiler/eval:cfn", ptr %t278, i32 0, i32 13
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l111, !tbaa !27
  %t281 = load i64, ptr %l5, !tbaa !24
  %t282 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t285 = mul i64 %t281, %t282
  %t287 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr i64, ptr %t288, i64 %t285
  %t290 = load i64, ptr %t289, !tbaa !34
  %t292 = icmp ne i64 %t290, 0
  store i1 %t292, ptr %l107, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb29
bb29:
  %t294 = load i1, ptr %l107, !tbaa !21
  br i1 %t294, label %bb30, label %bb31
bb30:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/eval:Machine", ptr %t295, i32 0, i32 17
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, ptr } %t298, ptr %l118, !tbaa !27
  %t299 = load i64, ptr %l3, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr %"compiler/eval:cfn", ptr %t302, i64 %t299
  %t304 = getelementptr %"compiler/eval:cfn", ptr %t303, i32 0, i32 13
  %t305 = load { i64, ptr }, ptr %t304, !tbaa !27
  store { i64, ptr } %t305, ptr %l7, !tbaa !27
  br label %bb32
bb31:
  br label %bb52
bb32:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = load i64, ptr %l2, !tbaa !24
  %t309 = load i64, ptr %l3, !tbaa !24
  %t310 = load i64, ptr %l5, !tbaa !24
  %t311 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t311, ptr %l125, !tbaa !27
  %t312 = load i64, ptr %l5, !tbaa !24
  %t313 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t316 = mul i64 %t312, %t313
  %t318 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr i64, ptr %t319, i64 %t316
  %t321 = load i64, ptr %t320, !tbaa !34
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %t307, i64 %t308, i64 %t309, i64 %t310, i64 %t321)
  br label %bb33
bb33:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/eval:Machine", ptr %t327, i32 0, i32 13
  %t330 = load i1, ptr %t329, !tbaa !21
  br i1 %t330, label %bb34, label %bb35
bb34:
  br label %ret
bb35:
  br label %bb36
bb36:
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t334 = getelementptr %"compiler/eval:Machine", ptr %t332, i32 0, i32 49
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l133, !tbaa !27
  %t336 = load i64, ptr %l2, !tbaa !24
  store i64 %t336, ptr %l134, !tbaa !24
  %t337 = load i64, ptr %l134, !tbaa !24
  %t338 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr %"compiler/eval:frame", ptr %t339, i64 %t337
  %t341 = getelementptr %"compiler/eval:frame", ptr %t340, i32 0, i32 2
  %t342 = load i64, ptr %t341, !tbaa !24
  %t344 = add i64 %t342, 1
  %t346 = load i64, ptr %l134, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr %"compiler/eval:frame", ptr %t348, i64 %t346
  %t350 = getelementptr %"compiler/eval:frame", ptr %t349, i32 0, i32 2
  store i64 %t344, ptr %t350, !tbaa !24
  %t351 = load i64, ptr %l5, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l5, !tbaa !24
  %t355 = load i64, ptr %l5, !tbaa !24
  %t356 = load i64, ptr %l6, !tbaa !24
  %t359 = icmp sge i64 %t355, %t356
  br i1 %t359, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l142, !tbaa !21
  br label %bb39
bb38:
  %t361 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t361, ptr %l143, !tbaa !27
  %t362 = load i64, ptr %l5, !tbaa !24
  %t363 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t366 = mul i64 %t362, %t363
  %t368 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr i64, ptr %t369, i64 %t366
  %t371 = load i64, ptr %t370, !tbaa !34
  %t373 = icmp eq i64 %t371, 0
  store i1 %t373, ptr %l142, !tbaa !21
  br label %bb39
bb39:
  %t375 = load i1, ptr %l142, !tbaa !21
  br i1 %t375, label %bb40, label %bb41
bb40:
  br label %bb51
bb41:
  br label %bb42
bb42:
  %t376 = load ptr, ptr %l0, !tbaa !29
  store ptr %t376, ptr %l149, !tbaa !29
  %t377 = load ptr, ptr %l149, !tbaa !29
  %t378 = getelementptr %"compiler/eval:Machine", ptr %t377, i32 0, i32 6
  %t379 = load i64, ptr %t378, !tbaa !24
  %t381 = add i64 %t379, 1
  %t383 = load ptr, ptr %l149, !tbaa !29
  %t384 = getelementptr %"compiler/eval:Machine", ptr %t383, i32 0, i32 6
  store i64 %t381, ptr %t384, !tbaa !24
  %t385 = load ptr, ptr %l0, !tbaa !29
  %t387 = getelementptr %"compiler/eval:Machine", ptr %t385, i32 0, i32 2
  %t388 = load i64, ptr %t387, !tbaa !24
  %t390 = icmp sge i64 %t388, 0
  br i1 %t390, label %bb43, label %bb44
bb43:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/eval:Machine", ptr %t392, i32 0, i32 6
  %t395 = load i64, ptr %t394, !tbaa !24
  %t396 = load ptr, ptr %l0, !tbaa !29
  %t398 = getelementptr %"compiler/eval:Machine", ptr %t396, i32 0, i32 2
  %t399 = load i64, ptr %t398, !tbaa !24
  %t402 = icmp sgt i64 %t395, %t399
  store i1 %t402, ptr %l155, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb45
bb45:
  %t404 = load i1, ptr %l155, !tbaa !21
  br i1 %t404, label %bb46, label %bb47
bb46:
  %t405 = load ptr, ptr %l0, !tbaa !29
  %t406 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhySteps, !tbaa !27
  %t407 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t407, ptr %t405, { i64, ptr } %t406)
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb32
bb51:
  br label %bb58
bb52:
  %t410 = load i64, ptr %l5, !tbaa !24
  %t411 = load i64, ptr %l6, !tbaa !24
  %t414 = icmp slt i64 %t410, %t411
  br i1 %t414, label %bb53, label %bb54
bb53:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load i64, ptr %l2, !tbaa !24
  %t418 = load i64, ptr %l3, !tbaa !24
  %t419 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estmtAt(ptr %v0, ptr %t416, i64 %t417, i64 %t418, i64 %t419)
  br label %bb55
bb54:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load i64, ptr %l2, !tbaa !24
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/eval:Machine", ptr %t426, i32 0, i32 17
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l173, !tbaa !27
  %t430 = load i64, ptr %l3, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr %"compiler/eval:cfn", ptr %t433, i64 %t430
  %t435 = getelementptr %"compiler/eval:cfn", ptr %t434, i32 0, i32 9
  %t436 = load { i64, ptr }, ptr %t435, !tbaa !27
  store { i64, ptr } %t436, ptr %l175, !tbaa !27
  %t437 = load i64, ptr %l4, !tbaa !24
  %t439 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr { i64, [8 x i64] }, ptr %t440, i64 %t437
  %t442 = load { i64, [8 x i64] }, ptr %t441
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/eval:Machine", ptr %t443, i32 0, i32 17
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !27
  store { i64, ptr } %t446, ptr %l179, !tbaa !27
  %t447 = load i64, ptr %l3, !tbaa !24
  %t449 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t450 = load ptr, ptr %t449, !tbaa !27
  %t451 = getelementptr %"compiler/eval:cfn", ptr %t450, i64 %t447
  %t452 = getelementptr %"compiler/eval:cfn", ptr %t451, i32 0, i32 11
  %t453 = load { i64, ptr }, ptr %t452, !tbaa !27
  store { i64, ptr } %t453, ptr %l181, !tbaa !27
  %t454 = load i64, ptr %l4, !tbaa !24
  %t456 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr i1, ptr %t457, i64 %t454
  %t459 = load i1, ptr %t458, !tbaa !31
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eterm(ptr %v0, ptr %t424, i64 %t425, { i64, [8 x i64] } %t442, i1 %t459)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb1
bb59:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2emask(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sge i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = mul i64 8, %t5
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = shl i64 1, %t9
  %t12 = sub i64 %t10, 1
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/eval:scope"
  %l19 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i32
  %l25 = alloca i64
  %l29 = alloca %"compiler/eval:scope"
  %l49 = alloca %"compiler/eval:scope"
  %l51 = alloca i64
  %rv = alloca i64
  %t20 = alloca %"compiler/eval:scope", align 8
  %t76 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 44
  %t5 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l23
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l22
  br label %bb1
bb1:
  %t10 = load i64, ptr %l22, !tbaa !24
  store i64 %t10, ptr %l19, !tbaa !24
  br label %bb5
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScopeSlot(ptr %v0, ptr %t11)
  store i64 %t13, ptr %l25
  br label %bb4
bb4:
  %t14 = load i64, ptr %l25, !tbaa !24
  store i64 %t14, ptr %l19, !tbaa !24
  br label %bb5
bb5:
  %t15 = load i64, ptr %l19, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 43
  %t19 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t20, ptr %v0, ptr %t18, i64 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t20, i64 136, i1 false)
  br label %bb6
bb6:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l29, i64 136, i1 false)
  %t27 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 1
  store i1 true, ptr %t27, !tbaa !21
  %t30 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 2
  store i64 %a1, ptr %t30, !tbaa !24
  %t33 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 3
  store i64 0, ptr %t33, !tbaa !24
  %t36 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 4
  store i64 -1, ptr %t36, !tbaa !24
  %t39 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 5
  store i64 0, ptr %t39, !tbaa !24
  %t42 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 6
  store i64 0, ptr %t42, !tbaa !24
  %t45 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 7
  store i64 0, ptr %t45, !tbaa !24
  %t48 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 8
  store i64 0, ptr %t48, !tbaa !24
  %t51 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 9
  store i64 0, ptr %t51, !tbaa !24
  %t54 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 10
  store i64 -1, ptr %t54, !tbaa !24
  %t57 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 11
  store i64 -1, ptr %t57, !tbaa !24
  %t60 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 12
  store i64 0, ptr %t60, !tbaa !24
  %t63 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 13
  store i64 0, ptr %t63, !tbaa !24
  %t66 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 15
  store i64 0, ptr %t66, !tbaa !24
  %t69 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 16
  store i64 -1, ptr %t69, !tbaa !24
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 43
  %t73 = load i64, ptr %l2, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %l3, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t76, ptr %l49, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t72, i64 %t73, ptr %t76)
  br label %bb7
bb7:
  %t77 = getelementptr %"compiler/eval:scope", ptr %l3, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t79 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t79, ptr %l51, !tbaa !24
  %t81 = load i64, ptr %l51, !tbaa !24
  %t82 = load i64, ptr %l51, !tbaa !24
  %t83 = shl i64 %t78, %t82
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = or i64 %t83, %t84
  store i64 %t87, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewSlot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l16 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/eval:alloc"
  %l22 = alloca %"compiler/eval:alloc"
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l60 = alloca ptr
  %rv = alloca i64
  %t41 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 41
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 40
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp sge i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 40
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l1, !tbaa !27
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t25 = mul i64 2, %t23
  store i64 %t25, ptr %l19, !tbaa !24
  store %"compiler/eval:alloc" zeroinitializer, ptr %l20
  %t26 = load i64, ptr %l19, !tbaa !24
  %t27 = icmp sgt i64 %t26, 0
  br i1 %t27, label %bb3, label %bb4
bb2:
  br label %bb22
bb3:
  %t29 = call %"compiler/eval:alloc" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aalloc()
  store %"compiler/eval:alloc" %t29, ptr %l22
  br label %bb5
bb4:
  %t30 = load i64, ptr %l19, !tbaa !24
  %t31 = icmp sge i64 %t30, 0
  br i1 %t31, label %bb6, label %bb7
bb5:
  %t33 = load %"compiler/eval:alloc", ptr %l22
  store %"compiler/eval:alloc" %t33, ptr %l20
  br label %bb4
bb6:
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = icmp sle i64 %t34, 88686269585142075
  br i1 %t35, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_1aa148087c58143e_12c49f79ebc6dae2)
  unreachable
bb8:
  %t37 = load i64, ptr %l19, !tbaa !24
  %t38 = mul i64 %t37, 104
  %t39 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t38)
  %t40 = load %"compiler/eval:alloc", ptr %l20
  store i64 0, ptr %t41
  br label %fill.42
fill.42:
  %t45 = load i64, ptr %t41
  %t46 = icmp slt i64 %t45, %t37
  br i1 %t46, label %fillb.43, label %filld.44
fillb.43:
  %t47 = getelementptr %"compiler/eval:alloc", ptr %t39, i64 %t45
  store %"compiler/eval:alloc" %t40, ptr %t47
  %t48 = add i64 %t45, 1
  store i64 %t48, ptr %t41
  br label %fill.42
filld.44:
  %t49 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t39, 1
  %t52 = load ptr, ptr %l16, !tbaa !29
  %t53 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 40
  store { i64, ptr } %t50, ptr %t53, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 41
  %t57 = load i64, ptr %t56, !tbaa !24
  store i64 %t57, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l3, !tbaa !24
  %t60 = load i64, ptr %l2, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1aa148087c58143e_12c49f79ebc6dae2)
  unreachable
bb10:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb15
bb12:
  %t69 = load i64, ptr %l3, !tbaa !24
  %t70 = load i64, ptr %l2, !tbaa !24
  %t73 = sub i64 %t69, %t70
  %t74 = load i64, ptr %l4, !tbaa !24
  %t77 = add i64 %t73, %t74
  %t79 = sub i64 %t77, 1
  %t80 = load i64, ptr %l4, !tbaa !24
  %t83 = sdiv i64 %t79, %t80
  store i64 %t83, ptr %l34, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb14
bb14:
  %t85 = load i64, ptr %l34, !tbaa !24
  store i64 %t85, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t86 = load i64, ptr %l31, !tbaa !24
  store i64 %t86, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb16
bb16:
  %t87 = load i64, ptr %l6, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  br label %bb19
bb19:
  %t95 = load i64, ptr %l2, !tbaa !24
  %t96 = load i64, ptr %l6, !tbaa !24
  %t97 = load i64, ptr %l4, !tbaa !24
  %t100 = mul i64 %t96, %t97
  %t103 = add i64 %t95, %t100
  store i64 %t103, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/eval:Machine", ptr %t105, i32 0, i32 40
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l53, !tbaa !27
  %t109 = load i64, ptr %l7, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t110, ptr %l55, !tbaa !27
  %t111 = load i64, ptr %l7, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr %"compiler/eval:alloc", ptr %t114, i64 %t111
  %t116 = load %"compiler/eval:alloc", ptr %t115
  %t119 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr %"compiler/eval:alloc", ptr %t120, i64 %t109
  store %"compiler/eval:alloc" %t116, ptr %t121
  br label %bb20
bb20:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t124 = add i64 %t122, 1
  store i64 %t124, ptr %l6, !tbaa !24
  br label %bb16
bb21:
  br label %bb22
bb22:
  %t126 = load ptr, ptr %l0, !tbaa !29
  store ptr %t126, ptr %l60, !tbaa !29
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 41
  %t129 = load i64, ptr %t128, !tbaa !24
  %t131 = add i64 %t129, 1
  %t133 = load ptr, ptr %l60, !tbaa !29
  %t134 = getelementptr %"compiler/eval:Machine", ptr %t133, i32 0, i32 41
  store i64 %t131, ptr %t134, !tbaa !24
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = getelementptr %"compiler/eval:Machine", ptr %t135, i32 0, i32 41
  %t138 = load i64, ptr %t137, !tbaa !24
  %t140 = sub i64 %t138, 1
  store i64 %t140, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewTaskSlot(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/eval:task"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 47
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = call %"compiler/eval:task" @compiler_2feval_3atask_2ector(ptr %s0)
  store %"compiler/eval:task" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load %"compiler/eval:task", ptr %l3
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ePush_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t5, %"compiler/eval:task" %t6)
  br label %bb2
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/eval:Machine", ptr %t7, i32 0, i32 47
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eLen_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t9)
  store i64 %t11, ptr %l6
  br label %bb3
bb3:
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = sub i64 %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eobjectAt(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca i32
  %l16 = alloca ptr
  %l20 = alloca %"compiler/eval:Ptr"
  %l21 = alloca %"compiler/eval:Ptr"
  %l24 = alloca %"compiler/eval:Ptr"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/eval:Ptr"
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayOf(ptr %v0, ptr %t1, i32 %a2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load i32, ptr %l3, !tbaa !23
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t11 = icmp ne i32 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = icmp eq i32 %t21, 0
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l16, !tbaa !29
  %t26 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  %t28 = getelementptr %"compiler/eval:Ptr", ptr %l1, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t31 = add i64 %t29, 8
  %t34 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s1, i64 %t27, i64 %t31)
  store %"compiler/eval:Ptr" %t34, ptr %l20
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t35 = load ptr, ptr %l16, !tbaa !29
  %t36 = load %"compiler/eval:Ptr", ptr %l20
  %t37 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t35, %"compiler/eval:Ptr" %t36)
  store %"compiler/eval:Ptr" %t37, ptr %l21
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t38 = load %"compiler/eval:Ptr", ptr %l21
  store %"compiler/eval:Ptr" %t38, ptr %rv
  br label %ret
bb10:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load %"compiler/eval:Ptr", ptr %l1
  %t43 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t39, %"compiler/eval:Ptr" %t40)
  store %"compiler/eval:Ptr" %t43, ptr %l24
  br label %bb11
bb11:
  %t44 = load %"compiler/eval:Ptr", ptr %l24
  store %"compiler/eval:Ptr" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoperandReady(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i1
  %l11 = alloca i1
  %rv = alloca i1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 1
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t6, i32 0, i32 0
  %t8 = load %"compiler/mir:Lvalue", ptr %t7
  store %"compiler/mir:Lvalue" %t8, ptr %l3
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t12 = load %"compiler/mir:Lvalue", ptr %l3
  %t16 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %t12)
  store i1 %t16, ptr %l11
  br label %bb4
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l4, !tbaa !21
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_ad3bfe70499dbe21_2daaaf2a9e405db5)
  unreachable
bb10:
  %t18 = load i1, ptr %l4, !tbaa !21
  store i1 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eoverflowsWide(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, i64 }
  %l12 = alloca { i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, i64 }
  %l17 = alloca i64
  %l18 = alloca { i64, i64 }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca { i64, i64 }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca { i64, i64 }
  %l31 = alloca { i64, i64 }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, i64, i64, i64 }
  %l36 = alloca i64
  %l37 = alloca { i64, i64 }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, i64 }
  %l41 = alloca { i64, i64 }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca { i64, i64 }
  %l48 = alloca { i64, [4 x i64] }
  %l52 = alloca i32
  %l55 = alloca i64
  %l57 = alloca ptr
  %l61 = alloca i32
  %l62 = alloca i1
  %l68 = alloca i64
  %l71 = alloca ptr
  %l75 = alloca i64
  %l77 = alloca double
  %l80 = alloca i1
  %l85 = alloca { i64, i64 }
  %l88 = alloca i64
  %l89 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i1
  %l97 = alloca ptr
  %l101 = alloca i32
  %l102 = alloca i1
  %l106 = alloca i1
  %l111 = alloca { i64, i64 }
  %l120 = alloca i1
  %l124 = alloca { i64, i64 }
  %l130 = alloca i1
  %l134 = alloca ptr
  %l135 = alloca i64
  %l139 = alloca { i64, [4 x i64] }
  %l140 = alloca { i64, i64 }
  %l146 = alloca { i64, i64 }
  %l150 = alloca i1
  %l154 = alloca i1
  %l158 = alloca i1
  %l161 = alloca i1
  %l167 = alloca i1
  %l176 = alloca i1
  %l181 = alloca { i64, i64 }
  %l187 = alloca i1
  %l192 = alloca { i64, i64 }
  %l197 = alloca i1
  %l200 = alloca i1
  %l203 = alloca i1
  %l211 = alloca { i64, i64 }
  %l218 = alloca { i64, i64, i64, i64 }
  %l224 = alloca i1
  %l231 = alloca { i64, i64 }
  %l237 = alloca { i64, i64 }
  %l244 = alloca i64
  %l250 = alloca { i64, i64 }
  %l259 = alloca { i64, i64 }
  %l268 = alloca i1
  %l278 = alloca i64
  %l284 = alloca i64
  %l293 = alloca i1
  %l304 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load %"compiler/mir:Range", ptr %l4
  %t7 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Range" %t3, i64 0)
  store { i64, [4 x i64] } %t7, ptr %l48
  br label %bb1
bb1:
  %t8 = load { i64, [4 x i64] }, ptr %l48
  store { i64, [4 x i64] } %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l5
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l52
  br label %bb2
bb2:
  %t16 = load i32, ptr %l52, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t17, i32 %t18)
  store i64 %t21, ptr %l55
  br label %bb3
bb3:
  %t22 = load i64, ptr %l55, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/eval:Machine", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l57, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t31 = load i32, ptr %l3, !tbaa !23
  %t34 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t30, i32 %t31)
  store i32 %t34, ptr %l61
  br label %bb4
bb4:
  %t35 = load ptr, ptr %l57, !tbaa !29
  %t36 = load i32, ptr %l61, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t37, ptr %l62
  br label %bb5
bb5:
  %t38 = load i1, ptr %l62, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l8, !tbaa !21
  %t41 = load i32, ptr %l2
  %t43 = trunc i64 20 to i32
  %t44 = icmp eq i32 %t41, %t43
  br i1 %t44, label %bb6, label %bb7
bb6:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load i32, ptr %l6, !tbaa !23
  %t50 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t46, i32 %t47)
  store i64 %t50, ptr %l68
  br label %bb8
bb7:
  br label %bb23
bb8:
  %t51 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t52 = load i64, ptr %l68, !tbaa !24
  %t54 = icmp eq i64 %t52, %t51
  br i1 %t54, label %bb9, label %bb10
bb9:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l71, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load { i64, [4 x i64] }, ptr %l5
  %t63 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t57, i64 %t58, { i64, [4 x i64] } %t59)
  store i64 %t63, ptr %l75
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t64 = load i32, ptr %l6, !tbaa !23
  %t65 = load ptr, ptr %l71, !tbaa !29
  %t66 = load i64, ptr %l75, !tbaa !24
  %t68 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t65, i64 %t66, i32 %t64)
  store double %t68, ptr %l77
  br label %bb12
bb12:
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load i1, ptr %l8, !tbaa !21
  %t71 = load double, ptr %l77, !tbaa !26
  %t74 = call i1 @compiler_2feval_2efloatFits(double %t71, i64 %t69, i1 %t70)
  store i1 %t74, ptr %l80
  br label %bb13
bb13:
  %t75 = load i1, ptr %l80, !tbaa !21
  %t76 = xor i1 %t75, true
  store i1 %t76, ptr %rv
  br label %ret
bb14:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t80 = load { i64, [4 x i64] }, ptr %l5
  %t84 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t78, i64 %t79, { i64, [4 x i64] } %t80)
  store { i64, i64 } %t84, ptr %l85
  br label %bb15
bb15:
  %t85 = load { i64, i64 }, ptr %l85
  store { i64, i64 } %t85, ptr %l9
  %t86 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 0
  %t87 = load i64, ptr %t86, !tbaa !24
  %t89 = getelementptr { i64, i64 }, ptr %l9, i32 0, i32 1
  %t90 = load i64, ptr %t89, !tbaa !24
  store i64 %t87, ptr %l88, !tbaa !24
  store i64 %t90, ptr %l89, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l6, !tbaa !23
  %t98 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t94, i32 %t95)
  store i64 %t98, ptr %l92
  br label %bb16
bb16:
  %t99 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t100 = load i64, ptr %l92, !tbaa !24
  %t102 = icmp ne i64 %t100, %t99
  br i1 %t102, label %bb17, label %bb18
bb17:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/eval:Machine", ptr %t104, i32 0, i32 0
  %t107 = load ptr, ptr %t106, !tbaa !29
  store ptr %t107, ptr %l97, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/eval:Machine", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i32, ptr %l6, !tbaa !23
  %t115 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t111, i32 %t112)
  store i32 %t115, ptr %l101
  br label %bb19
bb18:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb21
bb19:
  %t116 = load ptr, ptr %l97, !tbaa !29
  %t117 = load i32, ptr %l101, !tbaa !23
  %t118 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t116, i32 %t117)
  store i1 %t118, ptr %l102
  br label %bb20
bb20:
  %t119 = load i1, ptr %l102, !tbaa !21
  %t120 = xor i1 %t119, true
  store i1 %t120, ptr %l95, !tbaa !21
  br label %bb21
bb21:
  %t122 = load i64, ptr %l7, !tbaa !24
  %t123 = load i1, ptr %l8, !tbaa !21
  %t124 = load i64, ptr %l88, !tbaa !24
  %t125 = load i64, ptr %l89, !tbaa !24
  %t126 = load i1, ptr %l95, !tbaa !21
  %t129 = call i1 @compiler_2feval_2efits128(i64 %t124, i64 %t125, i1 %t126, i64 %t122, i1 %t123)
  store i1 %t129, ptr %l106
  br label %bb22
bb22:
  %t130 = load i1, ptr %l106, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %rv
  br label %ret
bb23:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l1, !tbaa !24
  %t135 = load { i64, [4 x i64] }, ptr %l5
  %t139 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t133, i64 %t134, { i64, [4 x i64] } %t135)
  store { i64, i64 } %t139, ptr %l111
  br label %bb24
bb24:
  %t140 = load { i64, i64 }, ptr %l111
  store { i64, i64 } %t140, ptr %l12
  %t141 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 0
  %t142 = load i64, ptr %t141, !tbaa !24
  store i64 %t142, ptr %l13, !tbaa !24
  %t144 = getelementptr { i64, i64 }, ptr %l12, i32 0, i32 1
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l14, !tbaa !24
  %t147 = load i32, ptr %l2
  %t149 = trunc i64 0 to i32
  %t150 = icmp eq i32 %t147, %t149
  br i1 %t150, label %bb25, label %bb26
bb25:
  %t152 = load i1, ptr %l8, !tbaa !21
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb27, label %bb28
bb26:
  br label %bb37
bb27:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t158 = icmp ne i64 %t156, 0
  br i1 %t158, label %bb29, label %bb30
bb28:
  br label %bb32
bb29:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb31
bb30:
  %t160 = load i64, ptr %l14, !tbaa !24
  %t162 = icmp ne i64 %t160, 0
  store i1 %t162, ptr %l120, !tbaa !21
  br label %bb31
bb31:
  %t164 = load i1, ptr %l120, !tbaa !21
  store i1 %t164, ptr %rv
  br label %ret
bb32:
  %t165 = load i64, ptr %l7, !tbaa !24
  %t167 = call { i64, i64 } @compiler_2feval_2ewideMin(i64 %t165)
  store { i64, i64 } %t167, ptr %l124
  br label %bb33
bb33:
  %t168 = load { i64, i64 }, ptr %l124
  store { i64, i64 } %t168, ptr %l15
  %t169 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 0
  %t170 = load i64, ptr %t169, !tbaa !24
  %t172 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 1
  %t173 = load i64, ptr %t172, !tbaa !24
  store i64 %t173, ptr %l17, !tbaa !24
  %t175 = load i64, ptr %l13, !tbaa !24
  %t179 = icmp eq i64 %t175, %t170
  br i1 %t179, label %bb34, label %bb35
bb34:
  %t181 = load i64, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l17, !tbaa !24
  %t185 = icmp eq i64 %t181, %t182
  store i1 %t185, ptr %l130, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb36
bb36:
  %t187 = load i1, ptr %l130, !tbaa !21
  store i1 %t187, ptr %rv
  br label %ret
bb37:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l134, !tbaa !29
  %t189 = load i64, ptr %l1, !tbaa !24
  store i64 %t189, ptr %l135, !tbaa !24
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load i64, ptr %l1, !tbaa !24
  %t192 = load %"compiler/mir:Range", ptr %l4
  %t196 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t190, i64 %t191, %"compiler/mir:Range" %t192, i64 1)
  store { i64, [4 x i64] } %t196, ptr %l139
  br label %bb38
bb38:
  %t197 = load ptr, ptr %l134, !tbaa !29
  %t198 = load i64, ptr %l135, !tbaa !24
  %t199 = load { i64, [4 x i64] }, ptr %l139
  %t200 = call { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %t197, i64 %t198, { i64, [4 x i64] } %t199)
  store { i64, i64 } %t200, ptr %l140
  br label %bb39
bb39:
  %t201 = load { i64, i64 }, ptr %l140
  store { i64, i64 } %t201, ptr %l18
  %t202 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 0
  %t203 = load i64, ptr %t202, !tbaa !24
  store i64 %t203, ptr %l19, !tbaa !24
  %t205 = getelementptr { i64, i64 }, ptr %l18, i32 0, i32 1
  %t206 = load i64, ptr %t205, !tbaa !24
  store i64 %t206, ptr %l20, !tbaa !24
  %t208 = load i32, ptr %l2
  %t210 = trunc i64 6 to i32
  %t211 = icmp eq i32 %t208, %t210
  br i1 %t211, label %bb40, label %bb41
bb40:
  %t213 = load i64, ptr %l7, !tbaa !24
  %t215 = call { i64, i64 } @compiler_2feval_2ewideMin(i64 %t213)
  store { i64, i64 } %t215, ptr %l146
  br label %bb42
bb41:
  br label %bb55
bb42:
  %t216 = load { i64, i64 }, ptr %l146
  store { i64, i64 } %t216, ptr %l21
  %t217 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 0
  %t218 = load i64, ptr %t217, !tbaa !24
  store i64 %t218, ptr %l22, !tbaa !24
  %t220 = getelementptr { i64, i64 }, ptr %l21, i32 0, i32 1
  %t221 = load i64, ptr %t220, !tbaa !24
  store i64 %t221, ptr %l23, !tbaa !24
  %t223 = load i1, ptr %l8, !tbaa !21
  br i1 %t223, label %bb43, label %bb44
bb43:
  %t225 = load i64, ptr %l13, !tbaa !24
  %t226 = load i64, ptr %l22, !tbaa !24
  %t229 = icmp eq i64 %t225, %t226
  store i1 %t229, ptr %l150, !tbaa !21
  br label %bb45
bb44:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb45
bb45:
  %t231 = load i1, ptr %l150, !tbaa !21
  br i1 %t231, label %bb46, label %bb47
bb46:
  %t232 = load i64, ptr %l14, !tbaa !24
  %t233 = load i64, ptr %l23, !tbaa !24
  %t236 = icmp eq i64 %t232, %t233
  store i1 %t236, ptr %l154, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb48
bb48:
  %t238 = load i1, ptr %l154, !tbaa !21
  br i1 %t238, label %bb49, label %bb50
bb49:
  %t239 = load i64, ptr %l19, !tbaa !24
  %t241 = icmp eq i64 %t239, -1
  store i1 %t241, ptr %l158, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb51
bb51:
  %t243 = load i1, ptr %l158, !tbaa !21
  br i1 %t243, label %bb52, label %bb53
bb52:
  %t244 = load i64, ptr %l20, !tbaa !24
  %t246 = icmp eq i64 %t244, -1
  store i1 %t246, ptr %l161, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb54
bb54:
  %t248 = load i1, ptr %l161, !tbaa !21
  store i1 %t248, ptr %rv
  br label %ret
bb55:
  %t249 = load i32, ptr %l2
  %t251 = trunc i64 5 to i32
  %t252 = icmp eq i32 %t249, %t251
  br i1 %t252, label %bb56, label %bb57
bb56:
  %t254 = load i1, ptr %l8, !tbaa !21
  br i1 %t254, label %bb58, label %bb59
bb57:
  br label %bb101
bb58:
  %t256 = load i64, ptr %l14, !tbaa !24
  %t258 = icmp slt i64 %t256, 0
  %t259 = load i64, ptr %l20, !tbaa !24
  %t261 = icmp slt i64 %t259, 0
  %t264 = icmp ne i1 %t258, %t261
  store i1 %t264, ptr %l167, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb60
bb60:
  %t266 = load i1, ptr %l167, !tbaa !21
  store i1 %t266, ptr %l24, !tbaa !21
  %t267 = load i64, ptr %l13, !tbaa !24
  store i64 %t267, ptr %l25, !tbaa !24
  %t269 = load i64, ptr %l14, !tbaa !24
  store i64 %t269, ptr %l26, !tbaa !24
  %t271 = load i1, ptr %l8, !tbaa !21
  br i1 %t271, label %bb61, label %bb62
bb61:
  %t273 = load i64, ptr %l14, !tbaa !24
  %t275 = icmp slt i64 %t273, 0
  store i1 %t275, ptr %l176, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l176, !tbaa !21
  br label %bb63
bb63:
  %t277 = load i1, ptr %l176, !tbaa !21
  br i1 %t277, label %bb64, label %bb65
bb64:
  %t278 = load i64, ptr %l13, !tbaa !24
  %t279 = load i64, ptr %l14, !tbaa !24
  %t282 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t278, i64 %t279)
  store { i64, i64 } %t282, ptr %l181
  br label %bb66
bb65:
  br label %bb67
bb66:
  %t283 = load { i64, i64 }, ptr %l181
  store { i64, i64 } %t283, ptr %l27
  %t284 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 0
  %t285 = load i64, ptr %t284, !tbaa !24
  store i64 %t285, ptr %l25, !tbaa !24
  %t287 = getelementptr { i64, i64 }, ptr %l27, i32 0, i32 1
  %t288 = load i64, ptr %t287, !tbaa !24
  store i64 %t288, ptr %l26, !tbaa !24
  br label %bb67
bb67:
  %t290 = load i64, ptr %l19, !tbaa !24
  store i64 %t290, ptr %l28, !tbaa !24
  %t292 = load i64, ptr %l20, !tbaa !24
  store i64 %t292, ptr %l29, !tbaa !24
  %t294 = load i1, ptr %l8, !tbaa !21
  br i1 %t294, label %bb68, label %bb69
bb68:
  %t296 = load i64, ptr %l20, !tbaa !24
  %t298 = icmp slt i64 %t296, 0
  store i1 %t298, ptr %l187, !tbaa !21
  br label %bb70
bb69:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb70
bb70:
  %t300 = load i1, ptr %l187, !tbaa !21
  br i1 %t300, label %bb71, label %bb72
bb71:
  %t301 = load i64, ptr %l19, !tbaa !24
  %t302 = load i64, ptr %l20, !tbaa !24
  %t305 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t301, i64 %t302)
  store { i64, i64 } %t305, ptr %l192
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t306 = load { i64, i64 }, ptr %l192
  store { i64, i64 } %t306, ptr %l30
  %t307 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 0
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l28, !tbaa !24
  %t310 = getelementptr { i64, i64 }, ptr %l30, i32 0, i32 1
  %t311 = load i64, ptr %t310, !tbaa !24
  store i64 %t311, ptr %l29, !tbaa !24
  br label %bb74
bb74:
  %t313 = load i64, ptr %l25, !tbaa !24
  %t315 = icmp eq i64 %t313, 0
  br i1 %t315, label %bb75, label %bb76
bb75:
  %t317 = load i64, ptr %l26, !tbaa !24
  %t319 = icmp eq i64 %t317, 0
  store i1 %t319, ptr %l197, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb77
bb77:
  %t321 = load i1, ptr %l197, !tbaa !21
  br i1 %t321, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l200, !tbaa !21
  br label %bb83
bb79:
  %t322 = load i64, ptr %l28, !tbaa !24
  %t324 = icmp eq i64 %t322, 0
  br i1 %t324, label %bb80, label %bb81
bb80:
  %t326 = load i64, ptr %l29, !tbaa !24
  %t328 = icmp eq i64 %t326, 0
  store i1 %t328, ptr %l203, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb82
bb82:
  %t330 = load i1, ptr %l203, !tbaa !21
  store i1 %t330, ptr %l200, !tbaa !21
  br label %bb83
bb83:
  %t331 = load i1, ptr %l200, !tbaa !21
  br i1 %t331, label %bb84, label %bb85
bb84:
  store i1 false, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t333 = load i64, ptr %l25, !tbaa !24
  %t334 = load i64, ptr %l26, !tbaa !24
  %t335 = load i64, ptr %l28, !tbaa !24
  %t336 = load i64, ptr %l29, !tbaa !24
  %t341 = call { i64, i64 } @compiler_2feval_2emul128(i64 %t333, i64 %t334, i64 %t335, i64 %t336)
  store { i64, i64 } %t341, ptr %l211
  br label %bb87
bb87:
  %t342 = load { i64, i64 }, ptr %l211
  store { i64, i64 } %t342, ptr %l31
  %t343 = getelementptr { i64, i64 }, ptr %l31, i32 0, i32 0
  %t344 = load i64, ptr %t343, !tbaa !24
  store i64 %t344, ptr %l32, !tbaa !24
  %t346 = getelementptr { i64, i64 }, ptr %l31, i32 0, i32 1
  %t347 = load i64, ptr %t346, !tbaa !24
  store i64 %t347, ptr %l33, !tbaa !24
  %t349 = load i64, ptr %l32, !tbaa !24
  %t350 = load i64, ptr %l33, !tbaa !24
  %t351 = load i64, ptr %l25, !tbaa !24
  %t352 = load i64, ptr %l26, !tbaa !24
  %t357 = call { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %t349, i64 %t350, i64 %t351, i64 %t352)
  store { i64, i64, i64, i64 } %t357, ptr %l218
  br label %bb88
bb88:
  %t358 = load { i64, i64, i64, i64 }, ptr %l218
  store { i64, i64, i64, i64 } %t358, ptr %l34
  %t359 = getelementptr { i64, i64, i64, i64 }, ptr %l34, i32 0, i32 0
  %t360 = load i64, ptr %t359, !tbaa !24
  %t362 = getelementptr { i64, i64, i64, i64 }, ptr %l34, i32 0, i32 1
  %t363 = load i64, ptr %t362, !tbaa !24
  store i64 %t363, ptr %l36, !tbaa !24
  %t366 = load i64, ptr %l28, !tbaa !24
  %t369 = icmp ne i64 %t360, %t366
  br i1 %t369, label %bb89, label %bb90
bb89:
  store i1 true, ptr %l224, !tbaa !21
  br label %bb91
bb90:
  %t371 = load i64, ptr %l36, !tbaa !24
  %t372 = load i64, ptr %l29, !tbaa !24
  %t375 = icmp ne i64 %t371, %t372
  store i1 %t375, ptr %l224, !tbaa !21
  br label %bb91
bb91:
  %t377 = load i1, ptr %l224, !tbaa !21
  br i1 %t377, label %bb92, label %bb93
bb92:
  store i1 true, ptr %rv
  br label %ret
bb93:
  br label %bb94
bb94:
  %t379 = load i64, ptr %l7, !tbaa !24
  %t380 = load i1, ptr %l8, !tbaa !21
  %t383 = call { i64, i64 } @compiler_2feval_2ewideMax(i64 %t379, i1 %t380)
  store { i64, i64 } %t383, ptr %l231
  br label %bb95
bb95:
  %t384 = load { i64, i64 }, ptr %l231
  store { i64, i64 } %t384, ptr %l37
  %t385 = getelementptr { i64, i64 }, ptr %l37, i32 0, i32 0
  %t386 = load i64, ptr %t385, !tbaa !24
  store i64 %t386, ptr %l38, !tbaa !24
  %t388 = getelementptr { i64, i64 }, ptr %l37, i32 0, i32 1
  %t389 = load i64, ptr %t388, !tbaa !24
  store i64 %t389, ptr %l39, !tbaa !24
  %t391 = load i1, ptr %l24, !tbaa !21
  br i1 %t391, label %bb96, label %bb97
bb96:
  %t393 = load i64, ptr %l38, !tbaa !24
  %t394 = load i64, ptr %l39, !tbaa !24
  %t397 = call { i64, i64 } @compiler_2feval_2eadd128(i64 %t393, i64 %t394, i64 1, i64 0)
  store { i64, i64 } %t397, ptr %l237
  br label %bb98
bb97:
  br label %bb99
bb98:
  %t398 = load { i64, i64 }, ptr %l237
  store { i64, i64 } %t398, ptr %l40
  %t399 = getelementptr { i64, i64 }, ptr %l40, i32 0, i32 0
  %t400 = load i64, ptr %t399, !tbaa !24
  store i64 %t400, ptr %l38, !tbaa !24
  %t402 = getelementptr { i64, i64 }, ptr %l40, i32 0, i32 1
  %t403 = load i64, ptr %t402, !tbaa !24
  store i64 %t403, ptr %l39, !tbaa !24
  br label %bb99
bb99:
  %t405 = load i64, ptr %l32, !tbaa !24
  %t406 = load i64, ptr %l33, !tbaa !24
  %t407 = load i64, ptr %l38, !tbaa !24
  %t408 = load i64, ptr %l39, !tbaa !24
  %t413 = call i64 @compiler_2feval_2ecmp128(i64 %t405, i64 %t406, i64 %t407, i64 %t408, i1 false)
  store i64 %t413, ptr %l244
  br label %bb100
bb100:
  %t414 = load i64, ptr %l244, !tbaa !24
  %t415 = icmp sgt i64 %t414, 0
  store i1 %t415, ptr %rv
  br label %ret
bb101:
  %t417 = load i64, ptr %l13, !tbaa !24
  %t418 = load i64, ptr %l14, !tbaa !24
  %t419 = load i64, ptr %l19, !tbaa !24
  %t420 = load i64, ptr %l20, !tbaa !24
  %t425 = call { i64, i64 } @compiler_2feval_2esub128(i64 %t417, i64 %t418, i64 %t419, i64 %t420)
  store { i64, i64 } %t425, ptr %l250
  br label %bb102
bb102:
  %t426 = load { i64, i64 }, ptr %l250
  store { i64, i64 } %t426, ptr %l41
  %t427 = getelementptr { i64, i64 }, ptr %l41, i32 0, i32 0
  %t428 = load i64, ptr %t427, !tbaa !24
  store i64 %t428, ptr %l42, !tbaa !24
  %t430 = getelementptr { i64, i64 }, ptr %l41, i32 0, i32 1
  %t431 = load i64, ptr %t430, !tbaa !24
  store i64 %t431, ptr %l43, !tbaa !24
  %t433 = load i32, ptr %l2
  %t435 = trunc i64 3 to i32
  %t436 = icmp eq i32 %t433, %t435
  br i1 %t436, label %bb103, label %bb104
bb103:
  %t438 = load i64, ptr %l13, !tbaa !24
  %t439 = load i64, ptr %l14, !tbaa !24
  %t440 = load i64, ptr %l19, !tbaa !24
  %t441 = load i64, ptr %l20, !tbaa !24
  %t446 = call { i64, i64 } @compiler_2feval_2eadd128(i64 %t438, i64 %t439, i64 %t440, i64 %t441)
  store { i64, i64 } %t446, ptr %l259
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t447 = load { i64, i64 }, ptr %l259
  store { i64, i64 } %t447, ptr %l44
  %t448 = getelementptr { i64, i64 }, ptr %l44, i32 0, i32 0
  %t449 = load i64, ptr %t448, !tbaa !24
  store i64 %t449, ptr %l42, !tbaa !24
  %t451 = getelementptr { i64, i64 }, ptr %l44, i32 0, i32 1
  %t452 = load i64, ptr %t451, !tbaa !24
  store i64 %t452, ptr %l43, !tbaa !24
  br label %bb106
bb106:
  %t454 = load i64, ptr %l7, !tbaa !24
  %t456 = icmp slt i64 %t454, 128
  br i1 %t456, label %bb107, label %bb108
bb107:
  %t458 = load i64, ptr %l42, !tbaa !24
  %t459 = load i64, ptr %l43, !tbaa !24
  %t460 = load i64, ptr %l7, !tbaa !24
  %t461 = load i1, ptr %l8, !tbaa !21
  %t466 = call i1 @compiler_2feval_2efits128(i64 %t458, i64 %t459, i1 true, i64 %t460, i1 %t461)
  store i1 %t466, ptr %l268
  br label %bb109
bb108:
  br label %bb110
bb109:
  %t467 = load i1, ptr %l268, !tbaa !21
  %t468 = xor i1 %t467, true
  store i1 %t468, ptr %rv
  br label %ret
bb110:
  %t470 = load i1, ptr %l8, !tbaa !21
  %t472 = xor i1 %t470, true
  br i1 %t472, label %bb111, label %bb112
bb111:
  %t474 = load i32, ptr %l2
  %t476 = trunc i64 3 to i32
  %t477 = icmp eq i32 %t474, %t476
  br i1 %t477, label %bb113, label %bb114
bb112:
  br label %bb118
bb113:
  %t479 = load i64, ptr %l42, !tbaa !24
  %t480 = load i64, ptr %l43, !tbaa !24
  %t481 = load i64, ptr %l13, !tbaa !24
  %t482 = load i64, ptr %l14, !tbaa !24
  %t487 = call i64 @compiler_2feval_2ecmp128(i64 %t479, i64 %t480, i64 %t481, i64 %t482, i1 false)
  store i64 %t487, ptr %l278
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t488 = load i64, ptr %l278, !tbaa !24
  %t489 = icmp slt i64 %t488, 0
  store i1 %t489, ptr %rv
  br label %ret
bb116:
  %t491 = load i64, ptr %l13, !tbaa !24
  %t492 = load i64, ptr %l14, !tbaa !24
  %t493 = load i64, ptr %l19, !tbaa !24
  %t494 = load i64, ptr %l20, !tbaa !24
  %t499 = call i64 @compiler_2feval_2ecmp128(i64 %t491, i64 %t492, i64 %t493, i64 %t494, i1 false)
  store i64 %t499, ptr %l284
  br label %bb117
bb117:
  %t500 = load i64, ptr %l284, !tbaa !24
  %t501 = icmp slt i64 %t500, 0
  store i1 %t501, ptr %rv
  br label %ret
bb118:
  %t503 = load i32, ptr %l2
  %t505 = trunc i64 3 to i32
  %t506 = icmp eq i32 %t503, %t505
  br i1 %t506, label %bb119, label %bb120
bb119:
  %t508 = load i64, ptr %l14, !tbaa !24
  %t510 = icmp slt i64 %t508, 0
  %t511 = load i64, ptr %l20, !tbaa !24
  %t513 = icmp slt i64 %t511, 0
  %t516 = icmp eq i1 %t510, %t513
  br i1 %t516, label %bb121, label %bb122
bb120:
  br label %bb124
bb121:
  %t518 = load i64, ptr %l43, !tbaa !24
  %t520 = icmp slt i64 %t518, 0
  %t521 = load i64, ptr %l14, !tbaa !24
  %t523 = icmp slt i64 %t521, 0
  %t526 = icmp ne i1 %t520, %t523
  store i1 %t526, ptr %l293, !tbaa !21
  br label %bb123
bb122:
  store i1 false, ptr %l293, !tbaa !21
  br label %bb123
bb123:
  %t528 = load i1, ptr %l293, !tbaa !21
  store i1 %t528, ptr %rv
  br label %ret
bb124:
  %t529 = load i64, ptr %l14, !tbaa !24
  %t531 = icmp slt i64 %t529, 0
  %t532 = load i64, ptr %l20, !tbaa !24
  %t534 = icmp slt i64 %t532, 0
  %t537 = icmp ne i1 %t531, %t534
  br i1 %t537, label %bb125, label %bb126
bb125:
  %t539 = load i64, ptr %l43, !tbaa !24
  %t541 = icmp slt i64 %t539, 0
  %t542 = load i64, ptr %l14, !tbaa !24
  %t544 = icmp slt i64 %t542, 0
  %t547 = icmp ne i1 %t541, %t544
  store i1 %t547, ptr %l304, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb127
bb127:
  %t549 = load i1, ptr %l304, !tbaa !21
  store i1 %t549, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2epack(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l21 = alloca i64
  %l24 = alloca i64
  %l43 = alloca { i64, ptr }
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l52 = alloca i64
  %l55 = alloca { i64, ptr }
  %l58 = alloca i64
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %rv = alloca { { i64, ptr }, i64 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 1152921504606846975
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4df6f2ee185eb0d1_4c6469cdbf591dfd)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 8
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_4df6f2ee185eb0d1_4c6469cdbf591dfd)
  unreachable
bb5:
  %t28 = load i64, ptr %l6, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l21, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l24, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l24, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l24, !tbaa !24
  store i64 %t48, ptr %l21, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l21, !tbaa !24
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb25
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l4, !tbaa !24
  %t59 = load i64, ptr %l8, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l9, !tbaa !24
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = load i64, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t68, i32 %t75)
  store i1 %t78, ptr %l46
  br label %bb15
bb15:
  %t79 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t79, ptr %l47, !tbaa !27
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 %t80
  %t85 = load i32, ptr %t84, !tbaa !33
  %t86 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t89 = icmp ne i32 %t85, %t86
  br i1 %t89, label %bb16, label %bb17
bb16:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t91, i32 0, i32 0
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t95, ptr %l55, !tbaa !27
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr i32, ptr %t99, i64 %t96
  %t101 = load i32, ptr %t100, !tbaa !33
  %t104 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t94, i32 %t101)
  store i64 %t104, ptr %l58
  br label %bb18
bb17:
  store i64 1, ptr %l52, !tbaa !24
  br label %bb19
bb18:
  %t105 = load i64, ptr %l58, !tbaa !24
  store i64 %t105, ptr %l52, !tbaa !24
  br label %bb19
bb19:
  %t106 = load i64, ptr %l52, !tbaa !24
  store i64 %t106, ptr %l10, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t109 = icmp slt i64 %t107, 1
  br i1 %t109, label %bb20, label %bb21
bb20:
  store i64 1, ptr %l10, !tbaa !24
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t111 = load i64, ptr %l3, !tbaa !24
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l10, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = mul i64 %t121, %t122
  store i64 %t125, ptr %l3, !tbaa !24
  %t127 = load i64, ptr %l9, !tbaa !24
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = load ptr, ptr %lp2
  %t132 = getelementptr { i64, ptr }, ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i64, ptr %t133, i64 %t127
  store i64 %t128, ptr %t134, !tbaa !34
  %t135 = load i64, ptr %l3, !tbaa !24
  store i64 %t135, ptr %l71, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t137, ptr %l73, !tbaa !27
  %t138 = load i64, ptr %l9, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i32, ptr %t141, i64 %t138
  %t143 = load i32, ptr %t142, !tbaa !33
  %t146 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t136, i32 %t143)
  store i64 %t146, ptr %l76
  br label %bb23
bb23:
  %t147 = load i64, ptr %l71, !tbaa !24
  %t148 = load i64, ptr %l76, !tbaa !24
  %t149 = add i64 %t147, %t148
  store i64 %t149, ptr %l3, !tbaa !24
  br label %bb24
bb24:
  %t151 = load i64, ptr %l8, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l8, !tbaa !24
  br label %bb11
bb25:
  %t155 = load ptr, ptr %lp2
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  %t157 = load i64, ptr %l3, !tbaa !24
  %t159 = add i64 %t157, 7
  %t161 = sdiv i64 %t159, 8
  %t163 = mul i64 %t161, 8
  %t165 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t156, 0
  %t167 = insertvalue { { i64, ptr }, i64 } %t165, i64 %t163, 1
  store { { i64, ptr }, i64 } %t167, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i64 }, ptr %rv
  ret { { i64, ptr }, i64 } %rr
}

define dso_local i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca { i64, ptr }
  %l11 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i32
  %l26 = alloca { i64, ptr }
  %l29 = alloca i1
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %rv = alloca i32
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i32, ptr %l11, !tbaa !23
  store i32 %t11, ptr %l4, !tbaa !23
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l14
  br label %bb2
bb2:
  %t17 = load i32, ptr %l14
  %t19 = trunc i64 24 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l20
  br label %bb5
bb4:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l23
  br label %bb6
bb5:
  %t32 = load i32, ptr %l20, !tbaa !23
  store i32 %t32, ptr %l17, !tbaa !23
  br label %bb7
bb6:
  %t33 = load i32, ptr %l23, !tbaa !23
  store i32 %t33, ptr %l17, !tbaa !23
  br label %bb7
bb7:
  %t34 = load i32, ptr %l17, !tbaa !23
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t35, i32 %t34)
  store { i64, ptr } %t39, ptr %l26
  br label %bb8
bb8:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  %t41 = load i64, ptr %l2, !tbaa !24
  %t43 = icmp sge i64 %t41, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t51 = icmp slt i64 %t45, %t48
  store i1 %t51, ptr %l29, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t53 = load i1, ptr %l29, !tbaa !21
  br i1 %t53, label %bb12, label %bb13
bb12:
  %t54 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l34, !tbaa !23
  br label %bb14
bb13:
  store i32 0, ptr %l34, !tbaa !23
  br label %bb14
bb14:
  %t62 = load i32, ptr %l34, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/eval:Ptr"
  %l6 = alloca i32
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca { i64, [1 x i64] }
  %l20 = alloca i64
  %l21 = alloca i32
  %l22 = alloca i32
  %l24 = alloca { %"compiler/eval:Ptr", i32 }
  %l25 = alloca i64
  %l26 = alloca { %"compiler/eval:Ptr", i32 }
  %l27 = alloca i32
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l44 = alloca %"compiler/eval:Ptr"
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l57 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca %"compiler/eval:gkey"
  %l63 = alloca i64
  %l64 = alloca i32
  %l73 = alloca i1
  %l78 = alloca i1
  %l82 = alloca %"compiler/eval:global"
  %l93 = alloca %"compiler/eval:global"
  %l95 = alloca %"compiler/eval:Ptr"
  %l103 = alloca i32
  %l106 = alloca i32
  %l130 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l142 = alloca i64
  %l143 = alloca i64
  %l147 = alloca i64
  %l149 = alloca %"compiler/eval:Ptr"
  %l153 = alloca i32
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca ptr
  %l169 = alloca %"compiler/eval:Ptr"
  %l172 = alloca i64
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca { %"compiler/eval:Ptr", i32 }
  %l190 = alloca { %"compiler/eval:Ptr", i32 }
  %l195 = alloca ptr
  %l198 = alloca i32
  %l199 = alloca i32
  %l202 = alloca i1
  %l206 = alloca %"compiler/eval:Ptr"
  %l217 = alloca i64
  %l225 = alloca %"compiler/eval:Ptr"
  %l229 = alloca i32
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { %"compiler/eval:Ptr", i32 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Lvalue" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 49
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l30, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/eval:Machine", ptr %t13, i32 0, i32 0
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l4, !tbaa !29
  %t18 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  store %"compiler/eval:Ptr" %t18, ptr %l5
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t20, ptr %l6, !tbaa !23
  %t22 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 0
  %t23 = load { i64, [2 x i64] }, ptr %t22
  store { i64, [2 x i64] } %t23, ptr %l7
  %t25 = load { i64, [2 x i64] }, ptr %l7
  %t27 = extractvalue { i64, [2 x i64] } %t25, 0
  %t28 = icmp eq i64 %t27, 1
  br i1 %t28, label %bb1, label %bb2
bb1:
  %t30 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t31 = getelementptr { i32 }, ptr %t30, i32 0, i32 0
  %t32 = load i32, ptr %t31
  store i32 %t32, ptr %l8, !tbaa !23
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i32, ptr %l8, !tbaa !23
  %t40 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t34, i64 %t35, i32 %t36)
  store %"compiler/eval:Ptr" %t40, ptr %l44
  br label %bb4
bb4:
  %t41 = load %"compiler/eval:Ptr", ptr %l44
  store %"compiler/eval:Ptr" %t41, ptr %l5
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 17
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l46, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr %"compiler/eval:cfn", ptr %t49, i64 %t46
  %t51 = getelementptr %"compiler/eval:cfn", ptr %t50, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l48, !tbaa !27
  %t53 = load i32, ptr %l8, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t57 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr %"compiler/mir:Local", ptr %t58, i64 %t55
  %t60 = getelementptr %"compiler/mir:Local", ptr %t59, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  store i32 %t61, ptr %l6, !tbaa !23
  br label %bb33
bb5:
  %t63 = load { i64, [2 x i64] }, ptr %l7
  %t65 = extractvalue { i64, [2 x i64] } %t63, 0
  %t66 = icmp eq i64 %t65, 2
  br i1 %t66, label %bb6, label %bb7
bb6:
  %t68 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t69 = getelementptr { i64, i32, i32 }, ptr %t68, i32 0, i32 0
  %t70 = load i64, ptr %t69
  store i64 %t70, ptr %l9, !tbaa !24
  %t72 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t73 = getelementptr { i64, i32, i32 }, ptr %t72, i32 0, i32 1
  %t74 = load i32, ptr %t73
  store i32 %t74, ptr %l10, !tbaa !23
  %t76 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t77 = getelementptr { i64, i32, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l11, !tbaa !23
  br label %bb8
bb7:
  br label %bb28
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/eval:Machine", ptr %t80, i32 0, i32 34
  store ptr %t82, ptr %l59, !tbaa !29
  %t83 = load i64, ptr %l9, !tbaa !24
  %t84 = load i32, ptr %l10, !tbaa !23
  %t87 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s2, i64 %t83, i32 %t84)
  store %"compiler/eval:gkey" %t87, ptr %l62
  br label %bb9
bb9:
  %t88 = load ptr, ptr %l59, !tbaa !29
  %t89 = load %"compiler/eval:gkey", ptr %l62
  %t90 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t88, %"compiler/eval:gkey" %t89)
  %t91 = extractvalue { i32, i64 } %t90, 1
  %t92 = extractvalue { i32, i64 } %t90, 0
  store i32 %t92, ptr %l64
  %t93 = icmp ne i32 %t92, 0
  br i1 %t93, label %bb11, label %ok.94, !prof !99
ok.94:
  store i64 %t91, ptr %l63
  br label %bb10
bb10:
  %t95 = load i64, ptr %l63, !tbaa !24
  store i64 %t95, ptr %l57, !tbaa !24
  br label %bb14
bb11:
  br label %bb12
bb12:
  call void @__olang_ert_req_clear()
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t98 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t98, ptr %t96, { i64, ptr } %t97)
  br label %bb13
bb13:
  %t101 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t102 = load i32, ptr %l11, !tbaa !23
  %t104 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t101, 0
  %t106 = insertvalue { %"compiler/eval:Ptr", i32 } %t104, i32 %t102, 1
  call void @__olang_scope_close(ptr %s2)
  store { %"compiler/eval:Ptr", i32 } %t106, ptr %rv
  br label %ret
bb14:
  %t108 = load i64, ptr %l57, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/eval:Machine", ptr %t109, i32 0, i32 1
  %t112 = load i32, ptr %t111
  %t114 = trunc i64 0 to i32
  %t115 = icmp eq i32 %t112, %t114
  br i1 %t115, label %bb15, label %bb16
bb15:
  %t117 = load i64, ptr %l12, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/eval:Machine", ptr %t118, i32 0, i32 64
  %t121 = load i64, ptr %t120, !tbaa !24
  %t124 = icmp ne i64 %t117, %t121
  store i1 %t124, ptr %l73, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb17
bb17:
  %t126 = load i1, ptr %l73, !tbaa !21
  br i1 %t126, label %bb18, label %bb19
bb18:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/eval:Machine", ptr %t127, i32 0, i32 33
  %t130 = load i64, ptr %l12, !tbaa !24
  %t133 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t129, i64 %t130)
  store %"compiler/eval:global" %t133, ptr %l82
  br label %bb20
bb19:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb21
bb20:
  %t134 = getelementptr %"compiler/eval:global", ptr %l82, i32 0, i32 4
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = icmp ne i64 %t135, 2
  store i1 %t137, ptr %l78, !tbaa !21
  br label %bb21
bb21:
  %t139 = load i1, ptr %l78, !tbaa !21
  br i1 %t139, label %bb22, label %bb23
bb22:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoGlobal, !tbaa !27
  %t142 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t142, ptr %t140, { i64, ptr } %t141)
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t145 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t146 = load i32, ptr %l11, !tbaa !23
  %t148 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t145, 0
  %t150 = insertvalue { %"compiler/eval:Ptr", i32 } %t148, i32 %t146, 1
  call void @__olang_scope_close(ptr %s2)
  store { %"compiler/eval:Ptr", i32 } %t150, ptr %rv
  br label %ret
bb25:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t152, i32 0, i32 33
  %t155 = load i64, ptr %l12, !tbaa !24
  %t158 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t154, i64 %t155)
  store %"compiler/eval:global" %t158, ptr %l93
  br label %bb26
bb26:
  %t159 = getelementptr %"compiler/eval:global", ptr %l93, i32 0, i32 3
  %t160 = load i64, ptr %t159, !tbaa !24
  %t162 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s2, i64 %t160, i64 0)
  store %"compiler/eval:Ptr" %t162, ptr %l95
  br label %bb27
bb27:
  %t163 = load %"compiler/eval:Ptr", ptr %l95
  store %"compiler/eval:Ptr" %t163, ptr %l5
  %t164 = load i32, ptr %l11, !tbaa !23
  store i32 %t164, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb28:
  %t166 = load { i64, [2 x i64] }, ptr %l7
  %t168 = extractvalue { i64, [2 x i64] } %t166, 0
  %t169 = icmp eq i64 %t168, 0
  br i1 %t169, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_de6102181a77a536_5fca55a0d6277082)
  unreachable
bb33:
  store i32 0, ptr %l13, !tbaa !23
  %t171 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 1
  %t172 = getelementptr %"compiler/mir:Range", ptr %t171, i32 0, i32 1
  %t173 = load i32, ptr %t172, !tbaa !23
  store i32 %t173, ptr %l14, !tbaa !23
  store i32 1, ptr %l15, !tbaa !23
  %t175 = load i32, ptr %l14, !tbaa !23
  %t176 = load i32, ptr %l13, !tbaa !23
  %t179 = icmp sgt i32 %t175, %t176
  br i1 %t179, label %bb34, label %bb35
bb34:
  %t181 = load i32, ptr %l15, !tbaa !23
  %t183 = icmp sgt i32 %t181, 0
  br i1 %t183, label %bb36, label %bb37
bb35:
  store i32 0, ptr %l103, !tbaa !23
  br label %bb39
bb36:
  %t185 = load i32, ptr %l14, !tbaa !23
  %t186 = load i32, ptr %l13, !tbaa !23
  %t189 = sub i32 %t185, %t186
  %t190 = load i32, ptr %l15, !tbaa !23
  %t193 = add i32 %t189, %t190
  %t195 = sub i32 %t193, 1
  %t196 = load i32, ptr %l15, !tbaa !23
  %t199 = sdiv i32 %t195, %t196
  store i32 %t199, ptr %l106, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l106, !tbaa !23
  br label %bb38
bb38:
  %t201 = load i32, ptr %l106, !tbaa !23
  store i32 %t201, ptr %l103, !tbaa !23
  br label %bb39
bb39:
  %t202 = load i32, ptr %l103, !tbaa !23
  store i32 %t202, ptr %l16, !tbaa !23
  store i32 0, ptr %l17, !tbaa !23
  br label %bb40
bb40:
  %t203 = load i32, ptr %l17, !tbaa !23
  %t204 = load i32, ptr %l16, !tbaa !23
  %t207 = icmp slt i32 %t203, %t204
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb41, label %bb42
bb41:
  br label %bb96
bb42:
  br label %bb43
bb43:
  %t211 = load i32, ptr %l13, !tbaa !23
  %t212 = load i32, ptr %l17, !tbaa !23
  %t213 = load i32, ptr %l15, !tbaa !23
  %t216 = mul i32 %t212, %t213
  %t219 = add i32 %t211, %t216
  store i32 %t219, ptr %l18, !tbaa !23
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/eval:Machine", ptr %t221, i32 0, i32 13
  %t224 = load i1, ptr %t223, !tbaa !21
  br i1 %t224, label %bb44, label %bb45
bb44:
  %t226 = load %"compiler/eval:Ptr", ptr @G_2ecompiler_2feval_2eNullPtr
  %t227 = load i32, ptr %l6, !tbaa !23
  %t229 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t226, 0
  %t231 = insertvalue { %"compiler/eval:Ptr", i32 } %t229, i32 %t227, 1
  store { %"compiler/eval:Ptr", i32 } %t231, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/eval:Machine", ptr %t233, i32 0, i32 17
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l130, !tbaa !27
  %t237 = load i64, ptr %l3, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr %"compiler/eval:cfn", ptr %t240, i64 %t237
  %t242 = getelementptr %"compiler/eval:cfn", ptr %t241, i32 0, i32 3
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  store { i64, ptr } %t243, ptr %l132, !tbaa !27
  %t244 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 1
  %t245 = getelementptr %"compiler/mir:Range", ptr %t244, i32 0, i32 0
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  %t249 = load i32, ptr %l18, !tbaa !23
  %t251 = sext i32 %t249 to i64
  %t254 = add i64 %t248, %t251
  %t256 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr { i64, [1 x i64] }, ptr %t257, i64 %t254
  %t259 = load { i64, [1 x i64] }, ptr %t258
  store { i64, [1 x i64] } %t259, ptr %l19
  %t261 = load { i64, [1 x i64] }, ptr %l19
  %t263 = extractvalue { i64, [1 x i64] } %t261, 0
  %t264 = icmp eq i64 %t263, 0
  br i1 %t264, label %bb47, label %bb48
bb47:
  %t266 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t267 = getelementptr { i64 }, ptr %t266, i32 0, i32 0
  %t268 = load i64, ptr %t267
  store i64 %t268, ptr %l20, !tbaa !24
  br label %bb49
bb48:
  br label %bb53
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t270 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t271 = load i64, ptr %t270, !tbaa !24
  store i64 %t271, ptr %l142, !tbaa !24
  %t272 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t273 = load i64, ptr %t272, !tbaa !24
  store i64 %t273, ptr %l143, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i32, ptr %l6, !tbaa !23
  %t276 = load i64, ptr %l20, !tbaa !24
  %t280 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t274, i32 %t275, i64 %t276)
  store i64 %t280, ptr %l147
  br label %bb50
bb50:
  %t281 = load i64, ptr %l143, !tbaa !24
  %t282 = load i64, ptr %l147, !tbaa !24
  %t283 = add i64 %t281, %t282
  %t284 = load i64, ptr %l142, !tbaa !24
  %t286 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s9, i64 %t284, i64 %t283)
  store %"compiler/eval:Ptr" %t286, ptr %l149
  br label %bb51
bb51:
  %t287 = load %"compiler/eval:Ptr", ptr %l149
  store %"compiler/eval:Ptr" %t287, ptr %l5
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load i32, ptr %l6, !tbaa !23
  %t290 = load i64, ptr %l20, !tbaa !24
  %t294 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t288, i32 %t289, i64 %t290)
  store i32 %t294, ptr %l153
  br label %bb52
bb52:
  %t295 = load i32, ptr %l153, !tbaa !23
  store i32 %t295, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  br label %bb94
bb53:
  %t296 = load { i64, [1 x i64] }, ptr %l19
  %t298 = extractvalue { i64, [1 x i64] } %t296, 0
  %t299 = icmp eq i64 %t298, 1
  br i1 %t299, label %bb54, label %bb55
bb54:
  %t301 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t302 = getelementptr { i32 }, ptr %t301, i32 0, i32 0
  %t303 = load i32, ptr %t302
  store i32 %t303, ptr %l21, !tbaa !23
  br label %bb56
bb55:
  br label %bb62
bb56:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = getelementptr %"compiler/eval:Machine", ptr %t305, i32 0, i32 17
  %t308 = load { i64, ptr }, ptr %t307, !tbaa !27
  store { i64, ptr } %t308, ptr %l158, !tbaa !27
  %t309 = load i64, ptr %l3, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr %"compiler/eval:cfn", ptr %t312, i64 %t309
  %t314 = getelementptr %"compiler/eval:cfn", ptr %t313, i32 0, i32 1
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  store { i64, ptr } %t315, ptr %l160, !tbaa !27
  %t316 = load i32, ptr %l21, !tbaa !23
  %t318 = sext i32 %t316 to i64
  %t320 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr %"compiler/mir:Local", ptr %t321, i64 %t318
  %t323 = getelementptr %"compiler/mir:Local", ptr %t322, i32 0, i32 2
  %t324 = load i32, ptr %t323, !tbaa !23
  store i32 %t324, ptr %l22, !tbaa !23
  %t326 = load ptr, ptr %l0, !tbaa !29
  store ptr %t326, ptr %l164, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l165, !tbaa !29
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t329 = load i64, ptr %l1, !tbaa !24
  %t330 = load i32, ptr %l21, !tbaa !23
  %t334 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t328, i64 %t329, i32 %t330)
  store %"compiler/eval:Ptr" %t334, ptr %l169
  br label %bb57
bb57:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load i32, ptr %l22, !tbaa !23
  %t339 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t335, i32 %t336)
  store i64 %t339, ptr %l172
  br label %bb58
bb58:
  %t340 = load ptr, ptr %l165, !tbaa !29
  %t341 = load %"compiler/eval:Ptr", ptr %l169
  %t342 = load i64, ptr %l172, !tbaa !24
  %t343 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t340, %"compiler/eval:Ptr" %t341, i64 %t342)
  store i64 %t343, ptr %l173
  br label %bb59
bb59:
  %t344 = load i32, ptr %l22, !tbaa !23
  %t345 = load ptr, ptr %l164, !tbaa !29
  %t346 = load i64, ptr %l173, !tbaa !24
  %t348 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t345, i64 %t346, i32 %t344)
  store i64 %t348, ptr %l175
  br label %bb60
bb60:
  %t349 = load i64, ptr %l175, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/eval:Ptr", ptr %l5
  %t352 = load i32, ptr %l6, !tbaa !23
  %t358 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %t350, %"compiler/eval:Ptr" %t351, i32 %t352, i64 %t349)
  store { %"compiler/eval:Ptr", i32 } %t358, ptr %l180
  br label %bb61
bb61:
  %t359 = load { %"compiler/eval:Ptr", i32 }, ptr %l180
  store { %"compiler/eval:Ptr", i32 } %t359, ptr %l24
  %t360 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l24, i32 0, i32 0
  %t361 = load %"compiler/eval:Ptr", ptr %t360
  store %"compiler/eval:Ptr" %t361, ptr %l5
  %t363 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l24, i32 0, i32 1
  %t364 = load i32, ptr %t363, !tbaa !23
  store i32 %t364, ptr %l6, !tbaa !23
  br label %bb94
bb62:
  %t366 = load { i64, [1 x i64] }, ptr %l19
  %t368 = extractvalue { i64, [1 x i64] } %t366, 0
  %t369 = icmp eq i64 %t368, 2
  br i1 %t369, label %bb63, label %bb64
bb63:
  %t371 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t372 = getelementptr { i64 }, ptr %t371, i32 0, i32 0
  %t373 = load i64, ptr %t372
  store i64 %t373, ptr %l25, !tbaa !24
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t376 = load %"compiler/eval:Ptr", ptr %l5
  %t377 = load i32, ptr %l6, !tbaa !23
  %t378 = load i64, ptr %l25, !tbaa !24
  %t383 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eelement(ptr %v0, ptr %t375, %"compiler/eval:Ptr" %t376, i32 %t377, i64 %t378)
  store { %"compiler/eval:Ptr", i32 } %t383, ptr %l190
  br label %bb66
bb66:
  %t384 = load { %"compiler/eval:Ptr", i32 }, ptr %l190
  store { %"compiler/eval:Ptr", i32 } %t384, ptr %l26
  %t385 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l26, i32 0, i32 0
  %t386 = load %"compiler/eval:Ptr", ptr %t385
  store %"compiler/eval:Ptr" %t386, ptr %l5
  %t388 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l26, i32 0, i32 1
  %t389 = load i32, ptr %t388, !tbaa !23
  store i32 %t389, ptr %l6, !tbaa !23
  br label %bb94
bb67:
  %t391 = load { i64, [1 x i64] }, ptr %l19
  %t393 = extractvalue { i64, [1 x i64] } %t391, 0
  %t394 = icmp eq i64 %t393, 3
  br i1 %t394, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb82
bb70:
  %t396 = load ptr, ptr %l4, !tbaa !29
  store ptr %t396, ptr %l195, !tbaa !29
  %t397 = load ptr, ptr %l4, !tbaa !29
  %t398 = load i32, ptr %l6, !tbaa !23
  %t401 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t397, i32 %t398)
  store i32 %t401, ptr %l198
  br label %bb71
bb71:
  %t402 = load ptr, ptr %l195, !tbaa !29
  %t403 = load i32, ptr %l198, !tbaa !23
  %t404 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t402, i32 %t403)
  store i32 %t404, ptr %l199
  br label %bb72
bb72:
  %t405 = load i32, ptr %l199, !tbaa !23
  store i32 %t405, ptr %l27, !tbaa !23
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i32, ptr %l27, !tbaa !23
  %t410 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %t406, i32 %t407)
  store i1 %t410, ptr %l202
  br label %bb73
bb73:
  %t411 = load i1, ptr %l202, !tbaa !21
  %t412 = xor i1 %t411, true
  br i1 %t412, label %bb74, label %bb75
bb74:
  %t414 = load ptr, ptr %l0, !tbaa !29
  %t415 = load %"compiler/eval:Ptr", ptr %l5
  %t418 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t414, %"compiler/eval:Ptr" %t415)
  store %"compiler/eval:Ptr" %t418, ptr %l206
  br label %bb76
bb75:
  br label %bb77
bb76:
  %t419 = load %"compiler/eval:Ptr", ptr %l206
  store %"compiler/eval:Ptr" %t419, ptr %l5
  br label %bb77
bb77:
  %t420 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t421 = load i64, ptr %t420, !tbaa !24
  %t423 = icmp eq i64 %t421, 0
  br i1 %t423, label %bb78, label %bb79
bb78:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNull, !tbaa !27
  %t427 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t427, ptr %t425, { i64, ptr } %t426)
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb81
bb81:
  %t430 = load i32, ptr %l27, !tbaa !23
  store i32 %t430, ptr %l6, !tbaa !23
  br label %bb94
bb82:
  %t432 = load { i64, [1 x i64] }, ptr %l19
  %t434 = extractvalue { i64, [1 x i64] } %t432, 0
  %t435 = icmp eq i64 %t434, 4
  br i1 %t435, label %bb83, label %bb84
bb83:
  %t437 = getelementptr { i64, [1 x i64] }, ptr %l19, i32 0, i32 1
  %t438 = getelementptr { i64 }, ptr %t437, i32 0, i32 0
  %t439 = load i64, ptr %t438
  store i64 %t439, ptr %l28, !tbaa !24
  br label %bb85
bb84:
  br label %bb93
bb85:
  store %olang.scope zeroinitializer, ptr %s15
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load %"compiler/eval:Ptr", ptr %l5
  %t445 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t441, %"compiler/eval:Ptr" %t442, i64 8)
  store i64 %t445, ptr %l217
  br label %bb86
bb86:
  %t446 = load i64, ptr %l28, !tbaa !24
  %t447 = load i64, ptr %l217, !tbaa !24
  %t449 = icmp ne i64 %t447, %t446
  br i1 %t449, label %bb87, label %bb88
bb87:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t452 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyPayload, !tbaa !27
  %t453 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t453, ptr %t451, { i64, ptr } %t452)
  br label %bb89
bb88:
  br label %bb90
bb89:
  br label %bb90
bb90:
  %t456 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 0
  %t457 = load i64, ptr %t456, !tbaa !24
  %t458 = getelementptr %"compiler/eval:Ptr", ptr %l5, i32 0, i32 1
  %t459 = load i64, ptr %t458, !tbaa !24
  %t461 = add i64 %t459, 8
  %t464 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s15, i64 %t457, i64 %t461)
  store %"compiler/eval:Ptr" %t464, ptr %l225
  br label %bb91
bb91:
  %t465 = load %"compiler/eval:Ptr", ptr %l225
  store %"compiler/eval:Ptr" %t465, ptr %l5
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t467 = load i32, ptr %l6, !tbaa !23
  %t468 = load i64, ptr %l28, !tbaa !24
  %t472 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epayloadType(ptr %v0, ptr %t466, i32 %t467, i64 %t468)
  store i32 %t472, ptr %l229
  br label %bb92
bb92:
  %t473 = load i32, ptr %l229, !tbaa !23
  store i32 %t473, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  br label %bb94
bb93:
  call void @__olang_check_failed(ptr @olang_loc_c157b2e02f5238d7_241c429033d52203)
  unreachable
bb94:
  br label %bb95
bb95:
  %t474 = load i32, ptr %l17, !tbaa !23
  %t476 = add i32 %t474, 1
  store i32 %t476, ptr %l17, !tbaa !23
  br label %bb40
bb96:
  %t478 = load %"compiler/eval:Ptr", ptr %l5
  %t479 = load i32, ptr %l6, !tbaa !23
  %t481 = insertvalue { %"compiler/eval:Ptr", i32 } undef, %"compiler/eval:Ptr" %t478, 0
  %t483 = insertvalue { %"compiler/eval:Ptr", i32 } %t481, i32 %t479, 1
  store { %"compiler/eval:Ptr", i32 } %t483, ptr %rv
  br label %ret
ret:
  %rr = load { %"compiler/eval:Ptr", i32 }, ptr %rv
  ret { %"compiler/eval:Ptr", i32 } %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eplaceReady(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/mir:Lvalue"
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca %"compiler/eval:global"
  %l13 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca %"compiler/eval:gkey"
  %l19 = alloca i64
  %l20 = alloca i32
  %l23 = alloca i1
  %l32 = alloca %"compiler/eval:global"
  %l34 = alloca i1
  %l42 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l64 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l2, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  store { i64, [2 x i64] } %t2, ptr %l3
  %t4 = load { i64, [2 x i64] }, ptr %l3
  %t6 = extractvalue { i64, [2 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t10 = getelementptr { i64, i32, i32 }, ptr %t9, i32 0, i32 0
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l4, !tbaa !24
  %t13 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t14 = getelementptr { i64, i32, i32 }, ptr %t13, i32 0, i32 1
  %t15 = load i32, ptr %t14
  store i32 %t15, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  br label %bb53
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 34
  store ptr %t19, ptr %l15, !tbaa !29
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i32, ptr %l5, !tbaa !23
  %t24 = call %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %s1, i64 %t20, i32 %t21)
  store %"compiler/eval:gkey" %t24, ptr %l18
  br label %bb4
bb4:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = load %"compiler/eval:gkey", ptr %l18
  %t27 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %t25, %"compiler/eval:gkey" %t26)
  %t28 = extractvalue { i32, i64 } %t27, 1
  %t29 = extractvalue { i32, i64 } %t27, 0
  store i32 %t29, ptr %l20
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb6, label %ok.31, !prof !99
ok.31:
  store i64 %t28, ptr %l19
  br label %bb5
bb5:
  %t32 = load i64, ptr %l19, !tbaa !24
  store i64 %t32, ptr %l13, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l13, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = icmp slt i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb11
bb10:
  %t38 = load i64, ptr %l6, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 64
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = icmp eq i64 %t38, %t42
  store i1 %t45, ptr %l23, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l23, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 33
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t51, i64 %t52)
  store %"compiler/eval:global" %t55, ptr %l32
  br label %bb15
bb15:
  %t56 = load %"compiler/eval:global", ptr %l32
  store %"compiler/eval:global" %t56, ptr %l7
  %t57 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 5
  %t58 = load i1, ptr %t57, !tbaa !21
  br i1 %t58, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb18
bb17:
  %t60 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 6
  %t61 = load i1, ptr %t60, !tbaa !21
  store i1 %t61, ptr %l34, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l34, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 14
  store i1 true, ptr %t66, !tbaa !21
  br label %bb21
bb20:
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/eval:Machine", ptr %t67, i32 0, i32 1
  %t70 = load i32, ptr %t69
  %t72 = trunc i64 1 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 4
  %t76 = load i64, ptr %t75, !tbaa !24
  %t78 = icmp ne i64 %t76, 0
  br i1 %t78, label %bb24, label %bb25
bb23:
  br label %bb31
bb24:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb26
bb25:
  %t80 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 2
  %t81 = load i64, ptr %t80, !tbaa !24
  %t83 = icmp slt i64 %t81, 0
  store i1 %t83, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  %t85 = load i1, ptr %l42, !tbaa !21
  br i1 %t85, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %t87, i64 %t88)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb31:
  %t92 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 1
  %t93 = load i1, ptr %t92, !tbaa !21
  br i1 %t93, label %bb32, label %bb33
bb32:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l50, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l4, !tbaa !24
  %t99 = load i32, ptr %l5, !tbaa !23
  %t104 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesAfter(ptr %v0, ptr %t96, i64 %a1, i64 %t98, i32 %t99)
  store i1 %t104, ptr %l55
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t105 = load i1, ptr %l55, !tbaa !21
  br i1 %t105, label %bb35, label %bb36
bb35:
  %t106 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyWritesGlobalVar, !tbaa !27
  store { i64, ptr } %t106, ptr %l56, !tbaa !27
  br label %bb37
bb36:
  %t108 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyMutableGlobal, !tbaa !27
  store { i64, ptr } %t108, ptr %l56, !tbaa !27
  br label %bb37
bb37:
  %t110 = load ptr, ptr @__olang_prog_scope
  %t111 = load ptr, ptr %l50, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l56, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t110, ptr %t111, { i64, ptr } %t112)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb39:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 0
  %t116 = load i64, ptr %t115, !tbaa !24
  %t118 = trunc i64 %t116 to i32
  %t122 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %t114, i32 %t118)
  store i1 %t122, ptr %l64
  br label %bb40
bb40:
  %t123 = load i1, ptr %l64, !tbaa !21
  br i1 %t123, label %bb41, label %bb42
bb41:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyChangeable, !tbaa !27
  %t126 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t126, ptr %t124, { i64, ptr } %t125)
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb44:
  %t130 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 4
  %t131 = load i64, ptr %t130, !tbaa !24
  %t133 = icmp eq i64 %t131, 2
  br i1 %t133, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t136 = getelementptr %"compiler/eval:global", ptr %l7, i32 0, i32 4
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = icmp eq i64 %t137, 1
  br i1 %t139, label %bb48, label %bb49
bb48:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyCycle, !tbaa !27
  %t143 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t143, ptr %t141, { i64, ptr } %t142)
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb51:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %t147, i64 %t148)
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 true, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_a7714af53687ff6b_1e8ca3031727412f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l20 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 50
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp eq i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 50
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = sub i64 %t11, 1
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 50
  store i64 %t13, ptr %t16, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/eval:Machine", ptr %t17, i32 0, i32 17
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 49
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  store { i64, ptr } %t24, ptr %l10, !tbaa !27
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 50
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr %"compiler/eval:frame", ptr %t31, i64 %t28
  %t33 = getelementptr %"compiler/eval:frame", ptr %t32, i32 0, i32 0
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/eval:cfn", ptr %t37, i64 %t34
  %t39 = getelementptr %"compiler/eval:cfn", ptr %t38, i32 0, i32 17
  %t40 = load i1, ptr %t39, !tbaa !21
  br i1 %t40, label %bb4, label %bb5
bb4:
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l15, !tbaa !29
  %t43 = load ptr, ptr %l15, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t43, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = sub i64 %t45, 1
  %t49 = load ptr, ptr %l15, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 5
  store i64 %t47, ptr %t50, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 49
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l20, !tbaa !27
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 50
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr %"compiler/eval:frame", ptr %t62, i64 %t59
  %t64 = getelementptr %"compiler/eval:frame", ptr %t63, i32 0, i32 3
  %t65 = load i64, ptr %t64, !tbaa !24
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t51, i32 0, i32 52
  store i64 %t65, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/eval:Machine", ptr %t70, i32 0, i32 50
  %t73 = load i64, ptr %t72, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropOwnDefers(ptr %v0, ptr %t69, i64 %t73)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eprim(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca { i64, [4 x i64] }
  %l6 = alloca i32
  %l7 = alloca %"compiler/eval:Ptr"
  %l8 = alloca %"compiler/eval:Ptr"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca %"compiler/eval:Ptr"
  %l17 = alloca %"compiler/eval:Ptr"
  %l18 = alloca %"compiler/eval:Ptr"
  %l19 = alloca %"compiler/eval:Ptr"
  %l20 = alloca %"compiler/eval:Ptr"
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca %"compiler/eval:Ptr"
  %l28 = alloca %"compiler/eval:Ptr"
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca %"compiler/eval:Ptr"
  %l39 = alloca %"compiler/eval:Ptr"
  %l43 = alloca { i64, [4 x i64] }
  %l47 = alloca i32
  %l54 = alloca i64
  %l60 = alloca %"compiler/eval:Ptr"
  %l61 = alloca ptr
  %l62 = alloca i64
  %l66 = alloca { i64, [4 x i64] }
  %l67 = alloca %"compiler/eval:Ptr"
  %l70 = alloca i64
  %l80 = alloca i64
  %l83 = alloca i64
  %l101 = alloca ptr
  %l107 = alloca %"compiler/eval:Ptr"
  %l108 = alloca %"compiler/eval:Ptr"
  %l109 = alloca ptr
  %l115 = alloca %"compiler/eval:Ptr"
  %l116 = alloca %"compiler/eval:Ptr"
  %l120 = alloca i1
  %l130 = alloca ptr
  %l134 = alloca %"compiler/eval:Ptr"
  %l136 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca i64
  %l142 = alloca { i64, [4 x i64] }
  %l143 = alloca i64
  %l145 = alloca i64
  %l148 = alloca ptr
  %l152 = alloca i64
  %l155 = alloca i64
  %l158 = alloca ptr
  %l162 = alloca i64
  %l164 = alloca i64
  %l170 = alloca %"compiler/eval:Ptr"
  %l171 = alloca ptr
  %l175 = alloca %"compiler/eval:Ptr"
  %l176 = alloca %"compiler/eval:Ptr"
  %l179 = alloca i1
  %l185 = alloca %"compiler/eval:Ptr"
  %l186 = alloca i64
  %l187 = alloca ptr
  %l188 = alloca ptr
  %l189 = alloca i64
  %l193 = alloca { i64, [4 x i64] }
  %l194 = alloca i32
  %l195 = alloca %"compiler/eval:Ptr"
  %l198 = alloca i64
  %l201 = alloca ptr
  %l202 = alloca i64
  %l206 = alloca %"compiler/eval:Ptr"
  %l224 = alloca i64
  %l244 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i64
  %l252 = alloca { i64, [4 x i64] }
  %l253 = alloca i64
  %l257 = alloca i64
  %l261 = alloca i32
  %l262 = alloca i64
  %l265 = alloca i64
  %l266 = alloca i64
  %l268 = alloca i64
  %l271 = alloca i64
  %l273 = alloca i64
  %l276 = alloca i64
  %l280 = alloca i64
  %l283 = alloca i1
  %l286 = alloca i1
  %l294 = alloca i64
  %l295 = alloca ptr
  %l296 = alloca i64
  %l300 = alloca { i64, [4 x i64] }
  %l301 = alloca i32
  %l302 = alloca ptr
  %l303 = alloca i64
  %l307 = alloca { i64, [4 x i64] }
  %l308 = alloca i64
  %l315 = alloca i1
  %l319 = alloca i1
  %l323 = alloca i1
  %l334 = alloca i64
  %l337 = alloca i1
  %l343 = alloca %"compiler/eval:Ptr"
  %l344 = alloca ptr
  %l345 = alloca i64
  %l349 = alloca { i64, [4 x i64] }
  %l350 = alloca %"compiler/eval:Ptr"
  %l353 = alloca i64
  %l360 = alloca i64
  %l363 = alloca i64
  %l386 = alloca i64
  %l393 = alloca %"compiler/eval:Ptr"
  %l394 = alloca ptr
  %l400 = alloca %"compiler/eval:Ptr"
  %l401 = alloca %"compiler/eval:Ptr"
  %l402 = alloca ptr
  %l408 = alloca %"compiler/eval:Ptr"
  %l410 = alloca i64
  %l411 = alloca %"compiler/eval:Ptr"
  %l414 = alloca %"compiler/eval:Ptr"
  %l415 = alloca ptr
  %l421 = alloca %"compiler/eval:Ptr"
  %l422 = alloca %"compiler/eval:Ptr"
  %l423 = alloca ptr
  %l429 = alloca %"compiler/eval:Ptr"
  %l431 = alloca i64
  %l432 = alloca %"compiler/eval:Ptr"
  %l436 = alloca i1
  %l446 = alloca i64
  %l448 = alloca i64
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t3 = load %"compiler/mir:Range", ptr %l4
  %t7 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t1, i64 %t2, %"compiler/mir:Range" %t3, i64 0)
  store { i64, [4 x i64] } %t7, ptr %l43
  br label %bb1
bb1:
  %t8 = load { i64, [4 x i64] }, ptr %l43
  store { i64, [4 x i64] } %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load { i64, [4 x i64] }, ptr %l5
  %t15 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t9, i64 %t10, { i64, [4 x i64] } %t11)
  store i32 %t15, ptr %l47
  br label %bb2
bb2:
  %t16 = load i32, ptr %l47, !tbaa !23
  store i32 %t16, ptr %l6, !tbaa !23
  %t17 = load i32, ptr %l2
  %t19 = trunc i64 22 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t24 = load { i64, [4 x i64] }, ptr %l5
  %t25 = load i32, ptr %l6, !tbaa !23
  %t30 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2elenOf(ptr %v0, ptr %t22, i64 %t23, { i64, [4 x i64] } %t24, i32 %t25)
  store i64 %t30, ptr %l54
  br label %bb6
bb6:
  %t31 = load i64, ptr %l54, !tbaa !24
  store i64 %t31, ptr %rv
  br label %ret
bb7:
  %t32 = load i32, ptr %l2
  %t34 = trunc i64 19 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb40
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l1, !tbaa !24
  %t39 = load { i64, [4 x i64] }, ptr %l5
  %t43 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t37, i64 %t38, { i64, [4 x i64] } %t39, i64 1)
  store %"compiler/eval:Ptr" %t43, ptr %l60
  br label %bb11
bb11:
  %t44 = load %"compiler/eval:Ptr", ptr %l60
  store %"compiler/eval:Ptr" %t44, ptr %l7
  %t45 = load ptr, ptr %l0, !tbaa !29
  store ptr %t45, ptr %l61, !tbaa !29
  %t46 = load i64, ptr %l1, !tbaa !24
  store i64 %t46, ptr %l62, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l1, !tbaa !24
  %t49 = load %"compiler/mir:Range", ptr %l4
  %t53 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t47, i64 %t48, %"compiler/mir:Range" %t49, i64 1)
  store { i64, [4 x i64] } %t53, ptr %l66
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l61, !tbaa !29
  %t55 = load i64, ptr %l62, !tbaa !24
  %t56 = load { i64, [4 x i64] }, ptr %l66
  %t57 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t54, i64 %t55, { i64, [4 x i64] } %t56, i64 2)
  store %"compiler/eval:Ptr" %t57, ptr %l67
  br label %bb13
bb13:
  %t58 = load %"compiler/eval:Ptr", ptr %l67
  store %"compiler/eval:Ptr" %t58, ptr %l8
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l70
  br label %bb14
bb14:
  %t64 = load i64, ptr %l70, !tbaa !24
  store i64 %t64, ptr %l9, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 13
  %t68 = load i1, ptr %t67, !tbaa !21
  br i1 %t68, label %bb15, label %bb16
bb15:
  store i64 0, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  store i64 0, ptr %l10, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t73 = add i64 %t71, 7
  %t75 = sdiv i64 %t73, 8
  store i64 %t75, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t77 = load i64, ptr %l11, !tbaa !24
  %t78 = load i64, ptr %l10, !tbaa !24
  %t81 = icmp sgt i64 %t77, %t78
  br i1 %t81, label %bb18, label %bb19
bb18:
  %t83 = load i64, ptr %l12, !tbaa !24
  %t85 = icmp sgt i64 %t83, 0
  br i1 %t85, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb23
bb20:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  %t91 = sub i64 %t87, %t88
  %t92 = load i64, ptr %l12, !tbaa !24
  %t95 = add i64 %t91, %t92
  %t97 = sub i64 %t95, 1
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  store i64 %t101, ptr %l83, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l83, !tbaa !24
  br label %bb22
bb22:
  %t103 = load i64, ptr %l83, !tbaa !24
  store i64 %t103, ptr %l80, !tbaa !24
  br label %bb23
bb23:
  %t104 = load i64, ptr %l80, !tbaa !24
  store i64 %t104, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t105 = load i64, ptr %l14, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t109 = icmp slt i64 %t105, %t106
  %t111 = xor i1 %t109, true
  br i1 %t111, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb26:
  br label %bb27
bb27:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t114 = load i64, ptr %l14, !tbaa !24
  %t115 = load i64, ptr %l12, !tbaa !24
  %t118 = mul i64 %t114, %t115
  %t121 = add i64 %t113, %t118
  store i64 %t121, ptr %l15, !tbaa !24
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l101, !tbaa !29
  %t124 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 0
  %t125 = load i64, ptr %t124, !tbaa !24
  %t126 = getelementptr %"compiler/eval:Ptr", ptr %l7, i32 0, i32 1
  %t127 = load i64, ptr %t126, !tbaa !24
  %t128 = load i64, ptr %l15, !tbaa !24
  %t130 = mul i64 8, %t128
  %t133 = add i64 %t127, %t130
  %t136 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t125, i64 %t133)
  store %"compiler/eval:Ptr" %t136, ptr %l107
  br label %bb28
bb28:
  %t137 = load ptr, ptr %l101, !tbaa !29
  %t138 = load %"compiler/eval:Ptr", ptr %l107
  %t139 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t137, %"compiler/eval:Ptr" %t138)
  store %"compiler/eval:Ptr" %t139, ptr %l108
  br label %bb29
bb29:
  %t140 = load %"compiler/eval:Ptr", ptr %l108
  store %"compiler/eval:Ptr" %t140, ptr %l16
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l109, !tbaa !29
  %t142 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = getelementptr %"compiler/eval:Ptr", ptr %l8, i32 0, i32 1
  %t145 = load i64, ptr %t144, !tbaa !24
  %t146 = load i64, ptr %l15, !tbaa !24
  %t148 = mul i64 8, %t146
  %t151 = add i64 %t145, %t148
  %t154 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s5, i64 %t143, i64 %t151)
  store %"compiler/eval:Ptr" %t154, ptr %l115
  br label %bb30
bb30:
  %t155 = load ptr, ptr %l109, !tbaa !29
  %t156 = load %"compiler/eval:Ptr", ptr %l115
  %t157 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t155, %"compiler/eval:Ptr" %t156)
  store %"compiler/eval:Ptr" %t157, ptr %l116
  br label %bb31
bb31:
  %t158 = load %"compiler/eval:Ptr", ptr %l116
  store %"compiler/eval:Ptr" %t158, ptr %l17
  %t159 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 0
  %t160 = load i64, ptr %t159, !tbaa !24
  %t161 = getelementptr %"compiler/eval:Ptr", ptr %l17, i32 0, i32 0
  %t162 = load i64, ptr %t161, !tbaa !24
  %t165 = icmp ne i64 %t160, %t162
  br i1 %t165, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb34
bb33:
  %t167 = getelementptr %"compiler/eval:Ptr", ptr %l16, i32 0, i32 1
  %t168 = load i64, ptr %t167, !tbaa !24
  %t169 = getelementptr %"compiler/eval:Ptr", ptr %l17, i32 0, i32 1
  %t170 = load i64, ptr %t169, !tbaa !24
  %t173 = icmp ne i64 %t168, %t170
  store i1 %t173, ptr %l120, !tbaa !21
  br label %bb34
bb34:
  %t175 = load i1, ptr %l120, !tbaa !21
  br i1 %t175, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s5)
  store i64 0, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t177 = load i64, ptr %l14, !tbaa !24
  %t179 = add i64 %t177, 1
  store i64 %t179, ptr %l14, !tbaa !24
  br label %bb24
bb39:
  store i64 1, ptr %rv
  br label %ret
bb40:
  %t182 = load i32, ptr %l2
  %t184 = trunc i64 23 to i32
  %t185 = icmp eq i32 %t182, %t184
  br i1 %t185, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb51
bb43:
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l130, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i64, ptr %l1, !tbaa !24
  %t190 = load { i64, [4 x i64] }, ptr %l5
  %t194 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t188, i64 %t189, { i64, [4 x i64] } %t190, i64 1)
  store %"compiler/eval:Ptr" %t194, ptr %l134
  br label %bb44
bb44:
  %t195 = load i32, ptr %l6, !tbaa !23
  %t196 = load ptr, ptr %l130, !tbaa !29
  %t197 = load %"compiler/eval:Ptr", ptr %l134
  %t199 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2etagOf(ptr %v0, ptr %t196, %"compiler/eval:Ptr" %t197, i32 %t195)
  store i64 %t199, ptr %l136
  br label %bb45
bb45:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l137, !tbaa !29
  %t201 = load i64, ptr %l1, !tbaa !24
  store i64 %t201, ptr %l138, !tbaa !24
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l1, !tbaa !24
  %t204 = load %"compiler/mir:Range", ptr %l4
  %t208 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t202, i64 %t203, %"compiler/mir:Range" %t204, i64 1)
  store { i64, [4 x i64] } %t208, ptr %l142
  br label %bb46
bb46:
  %t209 = load ptr, ptr %l137, !tbaa !29
  %t210 = load i64, ptr %l138, !tbaa !24
  %t211 = load { i64, [4 x i64] }, ptr %l142
  %t212 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t209, i64 %t210, { i64, [4 x i64] } %t211)
  store i64 %t212, ptr %l143
  br label %bb47
bb47:
  %t213 = load i64, ptr %l136, !tbaa !24
  %t214 = load i64, ptr %l143, !tbaa !24
  %t215 = icmp eq i64 %t213, %t214
  br i1 %t215, label %bb48, label %bb49
bb48:
  store i64 1, ptr %l145, !tbaa !24
  br label %bb50
bb49:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb50
bb50:
  %t217 = load i64, ptr %l145, !tbaa !24
  store i64 %t217, ptr %rv
  br label %ret
bb51:
  %t218 = load i32, ptr %l2
  %t220 = trunc i64 20 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l148, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load i64, ptr %l1, !tbaa !24
  %t226 = load { i64, [4 x i64] }, ptr %l5
  %t230 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t224, i64 %t225, { i64, [4 x i64] } %t226)
  store i64 %t230, ptr %l152
  br label %bb55
bb55:
  %t231 = load i32, ptr %l6, !tbaa !23
  %t233 = load ptr, ptr %l148, !tbaa !29
  %t234 = load i64, ptr %l152, !tbaa !24
  %t237 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econvert(ptr %v0, ptr %t233, i64 %t234, i32 %t231, i32 %a3)
  store i64 %t237, ptr %l155
  br label %bb56
bb56:
  %t238 = load i64, ptr %l155, !tbaa !24
  store i64 %t238, ptr %rv
  br label %ret
bb57:
  %t239 = load i32, ptr %l2
  %t241 = trunc i64 21 to i32
  %t242 = icmp eq i32 %t239, %t241
  br i1 %t242, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb63
bb60:
  %t244 = load ptr, ptr %l0, !tbaa !29
  store ptr %t244, ptr %l158, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load i64, ptr %l1, !tbaa !24
  %t247 = load { i64, [4 x i64] }, ptr %l5
  %t251 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t245, i64 %t246, { i64, [4 x i64] } %t247)
  store i64 %t251, ptr %l162
  br label %bb61
bb61:
  %t252 = load i32, ptr %l6, !tbaa !23
  %t253 = load ptr, ptr %l158, !tbaa !29
  %t254 = load i64, ptr %l162, !tbaa !24
  %t256 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebitcast(ptr %v0, ptr %t253, i64 %t254, i32 %t252)
  store i64 %t256, ptr %l164
  br label %bb62
bb62:
  %t257 = load i64, ptr %l164, !tbaa !24
  store i64 %t257, ptr %rv
  br label %ret
bb63:
  %t258 = load i32, ptr %l2
  %t260 = trunc i64 42 to i32
  %t261 = icmp eq i32 %t258, %t260
  br i1 %t261, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb83
bb66:
  store %olang.scope zeroinitializer, ptr %s11
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t264 = load i64, ptr %l1, !tbaa !24
  %t265 = load { i64, [4 x i64] }, ptr %l5
  %t269 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t263, i64 %t264, { i64, [4 x i64] } %t265, i64 1)
  store %"compiler/eval:Ptr" %t269, ptr %l170
  br label %bb67
bb67:
  %t270 = load %"compiler/eval:Ptr", ptr %l170
  store %"compiler/eval:Ptr" %t270, ptr %l18
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l171, !tbaa !29
  %t272 = getelementptr %"compiler/eval:Ptr", ptr %l18, i32 0, i32 0
  %t273 = load i64, ptr %t272, !tbaa !24
  %t274 = getelementptr %"compiler/eval:Ptr", ptr %l18, i32 0, i32 1
  %t275 = load i64, ptr %t274, !tbaa !24
  %t277 = add i64 %t275, 8
  %t280 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s11, i64 %t273, i64 %t277)
  store %"compiler/eval:Ptr" %t280, ptr %l175
  br label %bb68
bb68:
  %t281 = load ptr, ptr %l171, !tbaa !29
  %t282 = load %"compiler/eval:Ptr", ptr %l175
  %t283 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t281, %"compiler/eval:Ptr" %t282)
  store %"compiler/eval:Ptr" %t283, ptr %l176
  br label %bb69
bb69:
  %t284 = load %"compiler/eval:Ptr", ptr %l176
  store %"compiler/eval:Ptr" %t284, ptr %l19
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/eval:Machine", ptr %t285, i32 0, i32 13
  %t288 = load i1, ptr %t287, !tbaa !21
  br i1 %t288, label %bb70, label %bb71
bb70:
  store i1 true, ptr %l179, !tbaa !21
  br label %bb72
bb71:
  %t290 = getelementptr %"compiler/eval:Ptr", ptr %l19, i32 0, i32 0
  %t291 = load i64, ptr %t290, !tbaa !24
  %t293 = icmp eq i64 %t291, 0
  store i1 %t293, ptr %l179, !tbaa !21
  br label %bb72
bb72:
  %t295 = load i1, ptr %l179, !tbaa !21
  br i1 %t295, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s11)
  store i64 0, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load %"compiler/eval:Ptr", ptr %l19
  %t301 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t297, %"compiler/eval:Ptr" %t298)
  store %"compiler/eval:Ptr" %t301, ptr %l185
  br label %bb76
bb76:
  %t302 = load %"compiler/eval:Ptr", ptr %l185
  store %"compiler/eval:Ptr" %t302, ptr %l20
  %t303 = getelementptr %"compiler/eval:Ptr", ptr %l20, i32 0, i32 0
  %t304 = load i64, ptr %t303, !tbaa !24
  store i64 %t304, ptr %l186, !tbaa !24
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l187, !tbaa !29
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l188, !tbaa !29
  %t307 = load i64, ptr %l1, !tbaa !24
  store i64 %t307, ptr %l189, !tbaa !24
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i64, ptr %l1, !tbaa !24
  %t310 = load %"compiler/mir:Range", ptr %l4
  %t314 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t308, i64 %t309, %"compiler/mir:Range" %t310, i64 1)
  store { i64, [4 x i64] } %t314, ptr %l193
  br label %bb77
bb77:
  %t315 = load ptr, ptr %l188, !tbaa !29
  %t316 = load i64, ptr %l189, !tbaa !24
  %t317 = load { i64, [4 x i64] }, ptr %l193
  %t318 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t315, i64 %t316, { i64, [4 x i64] } %t317)
  store i32 %t318, ptr %l194
  br label %bb78
bb78:
  %t319 = load ptr, ptr %l187, !tbaa !29
  %t320 = load i32, ptr %l194, !tbaa !23
  %t321 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etypeid(ptr %v0, ptr %t319, i32 %t320)
  store %"compiler/eval:Ptr" %t321, ptr %l195
  br label %bb79
bb79:
  %t322 = getelementptr %"compiler/eval:Ptr", ptr %l195, i32 0, i32 0
  %t323 = load i64, ptr %t322, !tbaa !24
  %t324 = load i64, ptr %l186, !tbaa !24
  %t326 = icmp eq i64 %t324, %t323
  br i1 %t326, label %bb80, label %bb81
bb80:
  store i64 1, ptr %l198, !tbaa !24
  br label %bb82
bb81:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s11)
  %t328 = load i64, ptr %l198, !tbaa !24
  store i64 %t328, ptr %rv
  br label %ret
bb83:
  %t329 = load i32, ptr %l2
  %t331 = trunc i64 29 to i32
  %t332 = icmp eq i32 %t329, %t331
  br i1 %t332, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l201, !tbaa !29
  %t335 = load i64, ptr %l1, !tbaa !24
  store i64 %t335, ptr %l202, !tbaa !24
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load i64, ptr %l1, !tbaa !24
  %t338 = load { i64, [4 x i64] }, ptr %l5
  %t342 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t336, i64 %t337, { i64, [4 x i64] } %t338, i64 1)
  store %"compiler/eval:Ptr" %t342, ptr %l206
  br label %bb87
bb87:
  %t343 = load i32, ptr %l6, !tbaa !23
  %t344 = load ptr, ptr %l201, !tbaa !29
  %t345 = load i64, ptr %l202, !tbaa !24
  %t346 = load %"compiler/eval:Ptr", ptr %l206
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eretire(ptr %v0, ptr %t344, i64 %t345, %"compiler/eval:Ptr" %t346, i32 %t343)
  br label %bb88
bb88:
  store i64 0, ptr %rv
  br label %ret
bb89:
  %t349 = load i32, ptr %l2
  %t351 = trunc i64 24 to i32
  %t352 = icmp eq i32 %t349, %t351
  br i1 %t352, label %bb90, label %bb91
bb90:
  br label %bb100
bb91:
  %t354 = load i32, ptr %l2
  %t356 = trunc i64 25 to i32
  %t357 = icmp eq i32 %t354, %t356
  br i1 %t357, label %bb92, label %bb93
bb92:
  br label %bb100
bb93:
  %t359 = load i32, ptr %l2
  %t361 = trunc i64 26 to i32
  %t362 = icmp eq i32 %t359, %t361
  br i1 %t362, label %bb94, label %bb95
bb94:
  br label %bb100
bb95:
  %t364 = load i32, ptr %l2
  %t366 = trunc i64 27 to i32
  %t367 = icmp eq i32 %t364, %t366
  br i1 %t367, label %bb96, label %bb97
bb96:
  br label %bb100
bb97:
  %t369 = load i32, ptr %l2
  %t371 = trunc i64 28 to i32
  %t372 = icmp eq i32 %t369, %t371
  br i1 %t372, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t375 = load i64, ptr %l1, !tbaa !24
  %t376 = load i32, ptr %l2
  %t377 = load %"compiler/mir:Range", ptr %l4
  %t378 = load i32, ptr %l6, !tbaa !23
  %t384 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eatomic(ptr %v0, ptr %t374, i64 %t375, i32 %t376, %"compiler/mir:Range" %t377, i32 %t378)
  store i64 %t384, ptr %l224
  br label %bb101
bb101:
  %t385 = load i64, ptr %l224, !tbaa !24
  store i64 %t385, ptr %rv
  br label %ret
bb102:
  %t386 = load i32, ptr %l2
  %t388 = trunc i64 37 to i32
  %t389 = icmp eq i32 %t386, %t388
  br i1 %t389, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb107
bb105:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t393 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t393, ptr %t391, { i64, ptr } %t392)
  br label %bb106
bb106:
  store i64 0, ptr %rv
  br label %ret
bb107:
  %t397 = load i32, ptr %l2
  %t399 = trunc i64 31 to i32
  %t400 = icmp eq i32 %t397, %t399
  br i1 %t400, label %bb108, label %bb109
bb108:
  br label %bb120
bb109:
  %t402 = load i32, ptr %l2
  %t404 = trunc i64 32 to i32
  %t405 = icmp eq i32 %t402, %t404
  br i1 %t405, label %bb110, label %bb111
bb110:
  br label %bb120
bb111:
  %t407 = load i32, ptr %l2
  %t409 = trunc i64 33 to i32
  %t410 = icmp eq i32 %t407, %t409
  br i1 %t410, label %bb112, label %bb113
bb112:
  br label %bb120
bb113:
  %t412 = load i32, ptr %l2
  %t414 = trunc i64 36 to i32
  %t415 = icmp eq i32 %t412, %t414
  br i1 %t415, label %bb114, label %bb115
bb114:
  br label %bb120
bb115:
  %t417 = load i32, ptr %l2
  %t419 = trunc i64 34 to i32
  %t420 = icmp eq i32 %t417, %t419
  br i1 %t420, label %bb116, label %bb117
bb116:
  br label %bb120
bb117:
  %t422 = load i32, ptr %l2
  %t424 = trunc i64 35 to i32
  %t425 = icmp eq i32 %t422, %t424
  br i1 %t425, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb137
bb120:
  store i64 0, ptr %l21, !tbaa !24
  %t427 = load i32, ptr %l2
  %t429 = trunc i64 34 to i32
  %t430 = icmp eq i32 %t427, %t429
  br i1 %t430, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l244, !tbaa !21
  br label %bb123
bb122:
  %t432 = load i32, ptr %l2
  %t434 = trunc i64 35 to i32
  %t435 = icmp eq i32 %t432, %t434
  store i1 %t435, ptr %l244, !tbaa !21
  br label %bb123
bb123:
  %t437 = load i1, ptr %l244, !tbaa !21
  br i1 %t437, label %bb124, label %bb125
bb124:
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l247, !tbaa !29
  %t439 = load i64, ptr %l1, !tbaa !24
  store i64 %t439, ptr %l248, !tbaa !24
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i64, ptr %l1, !tbaa !24
  %t442 = load %"compiler/mir:Range", ptr %l4
  %t446 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t440, i64 %t441, %"compiler/mir:Range" %t442, i64 1)
  store { i64, [4 x i64] } %t446, ptr %l252
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t447 = load ptr, ptr %l247, !tbaa !29
  %t448 = load i64, ptr %l248, !tbaa !24
  %t449 = load { i64, [4 x i64] }, ptr %l252
  %t450 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t447, i64 %t448, { i64, [4 x i64] } %t449)
  store i64 %t450, ptr %l253
  br label %bb127
bb127:
  %t451 = load i64, ptr %l253, !tbaa !24
  store i64 %t451, ptr %l21, !tbaa !24
  br label %bb128
bb128:
  %t452 = load ptr, ptr %l0, !tbaa !29
  %t453 = load i64, ptr %l1, !tbaa !24
  %t454 = load { i64, [4 x i64] }, ptr %l5
  %t458 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t452, i64 %t453, { i64, [4 x i64] } %t454)
  store i64 %t458, ptr %l257
  br label %bb129
bb129:
  %t459 = load i64, ptr %l257, !tbaa !24
  store i64 %t459, ptr %l22, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t462 = getelementptr %"compiler/eval:Machine", ptr %t460, i32 0, i32 13
  %t463 = load i1, ptr %t462, !tbaa !21
  br i1 %t463, label %bb130, label %bb131
bb130:
  store i64 0, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t466 = load i32, ptr %l2
  store i32 %t466, ptr %l261
  %t467 = load i64, ptr %l22, !tbaa !24
  store i64 %t467, ptr %l262, !tbaa !24
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t469 = load i32, ptr %l6, !tbaa !23
  %t472 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t468, i32 %t469)
  store i64 %t472, ptr %l265
  br label %bb133
bb133:
  %t473 = load i64, ptr %l265, !tbaa !24
  %t474 = call i64 @compiler_2feval_2ebmask(i64 %t473)
  store i64 %t474, ptr %l266
  br label %bb134
bb134:
  %t475 = load i64, ptr %l262, !tbaa !24
  %t476 = load i64, ptr %l266, !tbaa !24
  %t477 = and i64 %t475, %t476
  store i64 %t477, ptr %l268, !tbaa !65
  %t479 = load ptr, ptr %l0, !tbaa !29
  %t480 = load i32, ptr %l6, !tbaa !23
  %t483 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %t479, i32 %t480)
  store i64 %t483, ptr %l271
  br label %bb135
bb135:
  %t484 = load i64, ptr %l21, !tbaa !24
  %t485 = load i32, ptr %l261
  %t486 = load i64, ptr %l268, !tbaa !65
  %t487 = load i64, ptr %l271, !tbaa !24
  %t489 = call i64 @compiler_2feval_2ebitOp(i32 %t485, i64 %t486, i64 %t487, i64 %t484)
  store i64 %t489, ptr %l273
  br label %bb136
bb136:
  %t490 = load i64, ptr %l273, !tbaa !24
  store i64 %t490, ptr %rv
  br label %ret
bb137:
  br i1 true, label %bb138, label %bb139
bb138:
  br label %bb140
bb139:
  br label %bb141
bb140:
  br label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_c5a1577ee3e22d75_549c323efc9636a1)
  unreachable
bb142:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t492 = load i32, ptr %l6, !tbaa !23
  %t495 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t491, i32 %t492)
  store i64 %t495, ptr %l276
  br label %bb143
bb143:
  %t496 = load i64, ptr %l276, !tbaa !24
  store i64 %t496, ptr %l23, !tbaa !24
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i64, ptr %l1, !tbaa !24
  %t499 = load { i64, [4 x i64] }, ptr %l5
  %t503 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t497, i64 %t498, { i64, [4 x i64] } %t499)
  store i64 %t503, ptr %l280
  br label %bb144
bb144:
  %t504 = load i64, ptr %l280, !tbaa !24
  store i64 %t504, ptr %l24, !tbaa !24
  %t505 = load i32, ptr %l2
  %t507 = trunc i64 0 to i32
  %t508 = icmp eq i32 %t505, %t507
  br i1 %t508, label %bb145, label %bb146
bb145:
  store i1 true, ptr %l283, !tbaa !21
  br label %bb147
bb146:
  %t510 = load i32, ptr %l2
  %t512 = trunc i64 1 to i32
  %t513 = icmp eq i32 %t510, %t512
  store i1 %t513, ptr %l283, !tbaa !21
  br label %bb147
bb147:
  %t515 = load i1, ptr %l283, !tbaa !21
  br i1 %t515, label %bb148, label %bb149
bb148:
  store i1 true, ptr %l286, !tbaa !21
  br label %bb150
bb149:
  %t516 = load i32, ptr %l2
  %t518 = trunc i64 2 to i32
  %t519 = icmp eq i32 %t516, %t518
  store i1 %t519, ptr %l286, !tbaa !21
  br label %bb150
bb150:
  %t521 = load i1, ptr %l286, !tbaa !21
  br i1 %t521, label %bb151, label %bb152
bb151:
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t523 = load i32, ptr %l2
  %t524 = load i64, ptr %l24, !tbaa !24
  %t525 = load i32, ptr %l6, !tbaa !23
  %t526 = load i64, ptr %l23, !tbaa !24
  %t532 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %t522, i32 %t523, i64 %t524, i32 %t525, i64 %t526)
  store i64 %t532, ptr %l294
  br label %bb153
bb152:
  br label %bb154
bb153:
  %t533 = load i64, ptr %l294, !tbaa !24
  store i64 %t533, ptr %rv
  br label %ret
bb154:
  %t534 = load ptr, ptr %l0, !tbaa !29
  store ptr %t534, ptr %l295, !tbaa !29
  %t535 = load i64, ptr %l1, !tbaa !24
  store i64 %t535, ptr %l296, !tbaa !24
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load i64, ptr %l1, !tbaa !24
  %t538 = load %"compiler/mir:Range", ptr %l4
  %t542 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t536, i64 %t537, %"compiler/mir:Range" %t538, i64 1)
  store { i64, [4 x i64] } %t542, ptr %l300
  br label %bb155
bb155:
  %t543 = load ptr, ptr %l295, !tbaa !29
  %t544 = load i64, ptr %l296, !tbaa !24
  %t545 = load { i64, [4 x i64] }, ptr %l300
  %t546 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t543, i64 %t544, { i64, [4 x i64] } %t545)
  store i32 %t546, ptr %l301
  br label %bb156
bb156:
  %t547 = load i32, ptr %l301, !tbaa !23
  store i32 %t547, ptr %l25, !tbaa !23
  %t548 = load ptr, ptr %l0, !tbaa !29
  store ptr %t548, ptr %l302, !tbaa !29
  %t549 = load i64, ptr %l1, !tbaa !24
  store i64 %t549, ptr %l303, !tbaa !24
  %t550 = load ptr, ptr %l0, !tbaa !29
  %t551 = load i64, ptr %l1, !tbaa !24
  %t552 = load %"compiler/mir:Range", ptr %l4
  %t556 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t550, i64 %t551, %"compiler/mir:Range" %t552, i64 1)
  store { i64, [4 x i64] } %t556, ptr %l307
  br label %bb157
bb157:
  %t557 = load ptr, ptr %l302, !tbaa !29
  %t558 = load i64, ptr %l303, !tbaa !24
  %t559 = load { i64, [4 x i64] }, ptr %l307
  %t560 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t557, i64 %t558, { i64, [4 x i64] } %t559)
  store i64 %t560, ptr %l308
  br label %bb158
bb158:
  %t561 = load i64, ptr %l308, !tbaa !24
  store i64 %t561, ptr %l26, !tbaa !24
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = getelementptr %"compiler/eval:Machine", ptr %t562, i32 0, i32 13
  %t565 = load i1, ptr %t564, !tbaa !21
  br i1 %t565, label %bb159, label %bb160
bb159:
  store i64 0, ptr %rv
  br label %ret
bb160:
  br label %bb161
bb161:
  %t568 = load i64, ptr %l23, !tbaa !24
  %t569 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  %t572 = icmp eq i64 %t568, %t569
  br i1 %t572, label %bb162, label %bb163
bb162:
  store i1 true, ptr %l315, !tbaa !21
  br label %bb164
bb163:
  %t574 = load i64, ptr %l23, !tbaa !24
  %t575 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  %t578 = icmp eq i64 %t574, %t575
  store i1 %t578, ptr %l315, !tbaa !21
  br label %bb164
bb164:
  %t580 = load i1, ptr %l315, !tbaa !21
  br i1 %t580, label %bb165, label %bb166
bb165:
  store i1 true, ptr %l319, !tbaa !21
  br label %bb167
bb166:
  %t581 = load i64, ptr %l23, !tbaa !24
  %t582 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  %t585 = icmp eq i64 %t581, %t582
  store i1 %t585, ptr %l319, !tbaa !21
  br label %bb167
bb167:
  %t587 = load i1, ptr %l319, !tbaa !21
  br i1 %t587, label %bb168, label %bb169
bb168:
  store i1 true, ptr %l323, !tbaa !21
  br label %bb170
bb169:
  %t588 = load i64, ptr %l23, !tbaa !24
  %t589 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t592 = icmp eq i64 %t588, %t589
  store i1 %t592, ptr %l323, !tbaa !21
  br label %bb170
bb170:
  %t594 = load i1, ptr %l323, !tbaa !21
  br i1 %t594, label %bb171, label %bb172
bb171:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load i32, ptr %l2
  %t597 = load i64, ptr %l24, !tbaa !24
  %t598 = load i64, ptr %l26, !tbaa !24
  %t599 = load i32, ptr %l6, !tbaa !23
  %t600 = load i32, ptr %l25, !tbaa !23
  %t601 = load i64, ptr %l23, !tbaa !24
  %t609 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %t595, i32 %t596, i64 %t597, i64 %t598, i32 %t599, i32 %t600, i64 %t601)
  store i64 %t609, ptr %l334
  br label %bb173
bb172:
  br label %bb174
bb173:
  %t610 = load i64, ptr %l334, !tbaa !24
  store i64 %t610, ptr %rv
  br label %ret
bb174:
  %t611 = load i32, ptr %l2
  %t613 = trunc i64 13 to i32
  %t614 = icmp eq i32 %t611, %t613
  br i1 %t614, label %bb175, label %bb176
bb175:
  store i1 true, ptr %l337, !tbaa !21
  br label %bb177
bb176:
  %t616 = load i32, ptr %l2
  %t618 = trunc i64 14 to i32
  %t619 = icmp eq i32 %t616, %t618
  store i1 %t619, ptr %l337, !tbaa !21
  br label %bb177
bb177:
  %t621 = load i1, ptr %l337, !tbaa !21
  br i1 %t621, label %bb178, label %bb179
bb178:
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t623 = load i64, ptr %l1, !tbaa !24
  %t624 = load { i64, [4 x i64] }, ptr %l5
  %t628 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t622, i64 %t623, { i64, [4 x i64] } %t624, i64 1)
  store %"compiler/eval:Ptr" %t628, ptr %l343
  br label %bb180
bb179:
  br label %bb224
bb180:
  %t629 = load %"compiler/eval:Ptr", ptr %l343
  store %"compiler/eval:Ptr" %t629, ptr %l27
  %t630 = load ptr, ptr %l0, !tbaa !29
  store ptr %t630, ptr %l344, !tbaa !29
  %t631 = load i64, ptr %l1, !tbaa !24
  store i64 %t631, ptr %l345, !tbaa !24
  %t632 = load ptr, ptr %l0, !tbaa !29
  %t633 = load i64, ptr %l1, !tbaa !24
  %t634 = load %"compiler/mir:Range", ptr %l4
  %t638 = call { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %t632, i64 %t633, %"compiler/mir:Range" %t634, i64 1)
  store { i64, [4 x i64] } %t638, ptr %l349
  br label %bb181
bb181:
  %t639 = load ptr, ptr %l344, !tbaa !29
  %t640 = load i64, ptr %l345, !tbaa !24
  %t641 = load { i64, [4 x i64] }, ptr %l349
  %t642 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t639, i64 %t640, { i64, [4 x i64] } %t641, i64 2)
  store %"compiler/eval:Ptr" %t642, ptr %l350
  br label %bb182
bb182:
  %t643 = load %"compiler/eval:Ptr", ptr %l350
  store %"compiler/eval:Ptr" %t643, ptr %l28
  store i1 true, ptr %l29, !tbaa !21
  %t644 = load ptr, ptr %l0, !tbaa !29
  %t645 = load i32, ptr %l6, !tbaa !23
  %t648 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t644, i32 %t645)
  store i64 %t648, ptr %l353
  br label %bb183
bb183:
  %t649 = load i64, ptr %l353, !tbaa !24
  store i64 %t649, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  %t650 = load i64, ptr %l30, !tbaa !24
  %t652 = add i64 %t650, 7
  %t654 = sdiv i64 %t652, 8
  store i64 %t654, ptr %l32, !tbaa !24
  store i64 1, ptr %l33, !tbaa !24
  %t656 = load i64, ptr %l32, !tbaa !24
  %t657 = load i64, ptr %l31, !tbaa !24
  %t660 = icmp sgt i64 %t656, %t657
  br i1 %t660, label %bb184, label %bb185
bb184:
  %t662 = load i64, ptr %l33, !tbaa !24
  %t664 = icmp sgt i64 %t662, 0
  br i1 %t664, label %bb186, label %bb187
bb185:
  store i64 0, ptr %l360, !tbaa !24
  br label %bb189
bb186:
  %t666 = load i64, ptr %l32, !tbaa !24
  %t667 = load i64, ptr %l31, !tbaa !24
  %t670 = sub i64 %t666, %t667
  %t671 = load i64, ptr %l33, !tbaa !24
  %t674 = add i64 %t670, %t671
  %t676 = sub i64 %t674, 1
  %t677 = load i64, ptr %l33, !tbaa !24
  %t680 = sdiv i64 %t676, %t677
  store i64 %t680, ptr %l363, !tbaa !24
  br label %bb188
bb187:
  store i64 0, ptr %l363, !tbaa !24
  br label %bb188
bb188:
  %t682 = load i64, ptr %l363, !tbaa !24
  store i64 %t682, ptr %l360, !tbaa !24
  br label %bb189
bb189:
  %t683 = load i64, ptr %l360, !tbaa !24
  store i64 %t683, ptr %l34, !tbaa !24
  store i64 0, ptr %l35, !tbaa !24
  br label %bb190
bb190:
  store %olang.scope zeroinitializer, ptr %s25
  %t684 = load i64, ptr %l35, !tbaa !24
  %t685 = load i64, ptr %l34, !tbaa !24
  %t688 = icmp slt i64 %t684, %t685
  %t690 = xor i1 %t688, true
  br i1 %t690, label %bb191, label %bb192
bb191:
  call void @__olang_scope_close(ptr %s25)
  br label %bb220
bb192:
  br label %bb193
bb193:
  %t692 = load i64, ptr %l31, !tbaa !24
  %t693 = load i64, ptr %l35, !tbaa !24
  %t694 = load i64, ptr %l33, !tbaa !24
  %t697 = mul i64 %t693, %t694
  %t700 = add i64 %t692, %t697
  store i64 %t700, ptr %l36, !tbaa !24
  %t702 = load i64, ptr %l30, !tbaa !24
  %t703 = load i64, ptr %l36, !tbaa !24
  %t705 = mul i64 8, %t703
  %t708 = sub i64 %t702, %t705
  %t710 = icmp sge i64 %t708, 8
  br i1 %t710, label %bb194, label %bb195
bb194:
  store i64 8, ptr %l386, !tbaa !24
  br label %bb196
bb195:
  %t712 = load i64, ptr %l30, !tbaa !24
  %t713 = load i64, ptr %l36, !tbaa !24
  %t715 = mul i64 8, %t713
  %t718 = sub i64 %t712, %t715
  store i64 %t718, ptr %l386, !tbaa !24
  br label %bb196
bb196:
  %t720 = load i64, ptr %l386, !tbaa !24
  store i64 %t720, ptr %l37, !tbaa !24
  %t721 = load i64, ptr %l37, !tbaa !24
  %t723 = icmp eq i64 %t721, 8
  br i1 %t723, label %bb197, label %bb198
bb197:
  %t725 = load ptr, ptr %l0, !tbaa !29
  store ptr %t725, ptr %l394, !tbaa !29
  %t726 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 0
  %t727 = load i64, ptr %t726, !tbaa !24
  %t728 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 1
  %t729 = load i64, ptr %t728, !tbaa !24
  %t730 = load i64, ptr %l36, !tbaa !24
  %t732 = mul i64 8, %t730
  %t735 = add i64 %t729, %t732
  %t738 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s25, i64 %t727, i64 %t735)
  store %"compiler/eval:Ptr" %t738, ptr %l400
  br label %bb199
bb198:
  %t739 = load ptr, ptr %l0, !tbaa !29
  store ptr %t739, ptr %l402, !tbaa !29
  %t740 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 0
  %t741 = load i64, ptr %t740, !tbaa !24
  %t742 = getelementptr %"compiler/eval:Ptr", ptr %l27, i32 0, i32 1
  %t743 = load i64, ptr %t742, !tbaa !24
  %t744 = load i64, ptr %l36, !tbaa !24
  %t746 = mul i64 8, %t744
  %t749 = add i64 %t743, %t746
  %t752 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s25, i64 %t741, i64 %t749)
  store %"compiler/eval:Ptr" %t752, ptr %l408
  br label %bb201
bb199:
  %t753 = load ptr, ptr %l394, !tbaa !29
  %t754 = load %"compiler/eval:Ptr", ptr %l400
  %t755 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t753, %"compiler/eval:Ptr" %t754)
  store %"compiler/eval:Ptr" %t755, ptr %l401
  br label %bb200
bb200:
  %t756 = load %"compiler/eval:Ptr", ptr %l401
  store %"compiler/eval:Ptr" %t756, ptr %l393
  br label %bb204
bb201:
  %t757 = load i64, ptr %l37, !tbaa !24
  %t758 = load ptr, ptr %l402, !tbaa !29
  %t759 = load %"compiler/eval:Ptr", ptr %l408
  %t761 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t758, %"compiler/eval:Ptr" %t759, i64 %t757)
  store i64 %t761, ptr %l410
  br label %bb202
bb202:
  %t762 = load i64, ptr %l410, !tbaa !24
  %t763 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s25, i64 0, i64 %t762)
  store %"compiler/eval:Ptr" %t763, ptr %l411
  br label %bb203
bb203:
  %t764 = load %"compiler/eval:Ptr", ptr %l411
  store %"compiler/eval:Ptr" %t764, ptr %l393
  br label %bb204
bb204:
  %t765 = load %"compiler/eval:Ptr", ptr %l393
  store %"compiler/eval:Ptr" %t765, ptr %l38
  %t766 = load i64, ptr %l37, !tbaa !24
  %t768 = icmp eq i64 %t766, 8
  br i1 %t768, label %bb205, label %bb206
bb205:
  %t770 = load ptr, ptr %l0, !tbaa !29
  store ptr %t770, ptr %l415, !tbaa !29
  %t771 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 0
  %t772 = load i64, ptr %t771, !tbaa !24
  %t773 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 1
  %t774 = load i64, ptr %t773, !tbaa !24
  %t775 = load i64, ptr %l36, !tbaa !24
  %t777 = mul i64 8, %t775
  %t780 = add i64 %t774, %t777
  %t783 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s25, i64 %t772, i64 %t780)
  store %"compiler/eval:Ptr" %t783, ptr %l421
  br label %bb207
bb206:
  %t784 = load ptr, ptr %l0, !tbaa !29
  store ptr %t784, ptr %l423, !tbaa !29
  %t785 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 0
  %t786 = load i64, ptr %t785, !tbaa !24
  %t787 = getelementptr %"compiler/eval:Ptr", ptr %l28, i32 0, i32 1
  %t788 = load i64, ptr %t787, !tbaa !24
  %t789 = load i64, ptr %l36, !tbaa !24
  %t791 = mul i64 8, %t789
  %t794 = add i64 %t788, %t791
  %t797 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s25, i64 %t786, i64 %t794)
  store %"compiler/eval:Ptr" %t797, ptr %l429
  br label %bb209
bb207:
  %t798 = load ptr, ptr %l415, !tbaa !29
  %t799 = load %"compiler/eval:Ptr", ptr %l421
  %t800 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %t798, %"compiler/eval:Ptr" %t799)
  store %"compiler/eval:Ptr" %t800, ptr %l422
  br label %bb208
bb208:
  %t801 = load %"compiler/eval:Ptr", ptr %l422
  store %"compiler/eval:Ptr" %t801, ptr %l414
  br label %bb212
bb209:
  %t802 = load i64, ptr %l37, !tbaa !24
  %t803 = load ptr, ptr %l423, !tbaa !29
  %t804 = load %"compiler/eval:Ptr", ptr %l429
  %t806 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t803, %"compiler/eval:Ptr" %t804, i64 %t802)
  store i64 %t806, ptr %l431
  br label %bb210
bb210:
  %t807 = load i64, ptr %l431, !tbaa !24
  %t808 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s25, i64 0, i64 %t807)
  store %"compiler/eval:Ptr" %t808, ptr %l432
  br label %bb211
bb211:
  %t809 = load %"compiler/eval:Ptr", ptr %l432
  store %"compiler/eval:Ptr" %t809, ptr %l414
  br label %bb212
bb212:
  %t810 = load %"compiler/eval:Ptr", ptr %l414
  store %"compiler/eval:Ptr" %t810, ptr %l39
  %t811 = getelementptr %"compiler/eval:Ptr", ptr %l38, i32 0, i32 0
  %t812 = load i64, ptr %t811, !tbaa !24
  %t813 = getelementptr %"compiler/eval:Ptr", ptr %l39, i32 0, i32 0
  %t814 = load i64, ptr %t813, !tbaa !24
  %t817 = icmp ne i64 %t812, %t814
  br i1 %t817, label %bb213, label %bb214
bb213:
  store i1 true, ptr %l436, !tbaa !21
  br label %bb215
bb214:
  %t819 = getelementptr %"compiler/eval:Ptr", ptr %l38, i32 0, i32 1
  %t820 = load i64, ptr %t819, !tbaa !24
  %t821 = getelementptr %"compiler/eval:Ptr", ptr %l39, i32 0, i32 1
  %t822 = load i64, ptr %t821, !tbaa !24
  %t825 = icmp ne i64 %t820, %t822
  store i1 %t825, ptr %l436, !tbaa !21
  br label %bb215
bb215:
  %t827 = load i1, ptr %l436, !tbaa !21
  br i1 %t827, label %bb216, label %bb217
bb216:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb218
bb217:
  br label %bb218
bb218:
  call void @__olang_scope_close(ptr %s25)
  br label %bb219
bb219:
  %t828 = load i64, ptr %l35, !tbaa !24
  %t830 = add i64 %t828, 1
  store i64 %t830, ptr %l35, !tbaa !24
  br label %bb190
bb220:
  %t832 = load i1, ptr %l29, !tbaa !21
  %t833 = load i32, ptr %l2
  %t835 = trunc i64 13 to i32
  %t836 = icmp eq i32 %t833, %t835
  %t839 = icmp eq i1 %t832, %t836
  br i1 %t839, label %bb221, label %bb222
bb221:
  store i64 1, ptr %l446, !tbaa !24
  br label %bb223
bb222:
  store i64 0, ptr %l446, !tbaa !24
  br label %bb223
bb223:
  %t841 = load i64, ptr %l446, !tbaa !24
  store i64 %t841, ptr %rv
  br label %ret
bb224:
  %t842 = load ptr, ptr %l0, !tbaa !29
  %t844 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t842)
  store i64 %t844, ptr %l448
  br label %bb225
bb225:
  %t845 = load i64, ptr %l448, !tbaa !24
  store i64 %t845, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Fn"
  %l6 = alloca { i64, [8 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"compiler/eval:frame"
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l68 = alloca i64
  %l72 = alloca i64
  %l79 = alloca i1
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l98 = alloca %"compiler/mir:Fn"
  %l101 = alloca { i64, ptr }
  %l104 = alloca %"compiler/mir:BasicBlock"
  %l115 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l123 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l146 = alloca %"compiler/eval:frame"
  %l170 = alloca i64
  %l173 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca i64
  %l207 = alloca i64
  %l210 = alloca i64
  %l229 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l240 = alloca i64
  %l243 = alloca i64
  %l261 = alloca { i64, ptr }
  %l265 = alloca ptr
  %l267 = alloca { i64, ptr }
  %l270 = alloca i64
  %l273 = alloca %"compiler/eval:Ptr"
  %l276 = alloca { i64, ptr }
  %l292 = alloca i64
  %l295 = alloca i64
  %l314 = alloca { i64, ptr }
  %l331 = alloca ptr
  %l334 = alloca i64
  %l335 = alloca %"compiler/eval:frame"
  %l337 = alloca %"compiler/eval:frame"
  %l346 = alloca i64
  %l349 = alloca i64
  %l368 = alloca { i64, ptr }
  %l370 = alloca { i64, ptr }
  %l376 = alloca { i64, ptr }
  %l380 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca i64
  %t116 = alloca %"compiler/mir:Fn", align 8
  %t676 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 50
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/eval:Machine", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sge i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l55, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 1
  %t17 = load i32, ptr %t16
  %t19 = trunc i64 0 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t22 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDepth, !tbaa !27
  store { i64, ptr } %t22, ptr %l59, !tbaa !27
  br label %bb5
bb4:
  %t24 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyRunDepth, !tbaa !27
  store { i64, ptr } %t24, ptr %l59, !tbaa !27
  br label %bb5
bb5:
  %t26 = load ptr, ptr @__olang_prog_scope
  %t27 = load ptr, ptr %l55, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l59, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t26, ptr %t27, { i64, ptr } %t28)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/eval:Machine", ptr %t30, i32 0, i32 17
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l64, !tbaa !27
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/eval:cfn", ptr %t37, i64 %t34
  %t39 = getelementptr %"compiler/eval:cfn", ptr %t38, i32 0, i32 17
  %t40 = load i1, ptr %t39, !tbaa !21
  br i1 %t40, label %bb8, label %bb9
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/eval:Machine", ptr %t42, i32 0, i32 5
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l68, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 1
  %t49 = load i32, ptr %t48
  %t51 = trunc i64 0 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb10, label %bb11
bb9:
  br label %bb43
bb10:
  store i64 2000, ptr %l72, !tbaa !24
  br label %bb12
bb11:
  store i64 100000, ptr %l72, !tbaa !24
  br label %bb12
bb12:
  %t54 = load i64, ptr %l68, !tbaa !24
  %t55 = load i64, ptr %l72, !tbaa !24
  %t56 = icmp sge i64 %t54, %t55
  br i1 %t56, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/eval:Machine", ptr %t58, i32 0, i32 50
  %t61 = load i64, ptr %t60, !tbaa !24
  %t63 = sub i64 %t61, 1
  store i64 %t63, ptr %l4, !tbaa !24
  br label %bb15
bb14:
  br label %bb42
bb15:
  %t65 = load i64, ptr %l4, !tbaa !24
  %t67 = icmp sgt i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 17
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l81, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/eval:Machine", ptr %t73, i32 0, i32 49
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  store { i64, ptr } %t76, ptr %l83, !tbaa !27
  %t77 = load i64, ptr %l4, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr %"compiler/eval:frame", ptr %t80, i64 %t77
  %t82 = getelementptr %"compiler/eval:frame", ptr %t81, i32 0, i32 0
  %t83 = load i64, ptr %t82, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr %"compiler/eval:cfn", ptr %t86, i64 %t83
  %t88 = getelementptr %"compiler/eval:cfn", ptr %t87, i32 0, i32 17
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l79, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb18
bb18:
  %t91 = load i1, ptr %l79, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  br label %bb21
bb21:
  %t94 = load i64, ptr %l4, !tbaa !24
  %t96 = sub i64 %t94, 1
  store i64 %t96, ptr %l4, !tbaa !24
  br label %bb22
bb22:
  br label %bb15
bb23:
  %t98 = load i64, ptr %l4, !tbaa !24
  %t100 = icmp sge i64 %t98, 0
  br i1 %t100, label %bb24, label %bb25
bb24:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/eval:Machine", ptr %t102, i32 0, i32 16
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/eval:Machine", ptr %t105, i32 0, i32 49
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l95, !tbaa !27
  %t109 = load i64, ptr %l4, !tbaa !24
  %t111 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr %"compiler/eval:frame", ptr %t112, i64 %t109
  %t114 = getelementptr %"compiler/eval:frame", ptr %t113, i32 0, i32 0
  %t115 = load i64, ptr %t114, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t116, ptr %v0, ptr %v0, ptr %t104, i64 %t115)
  call void @llvm.memmove.p0.p0.i64(ptr %l98, ptr %t116, i64 248, i1 false)
  br label %bb26
bb25:
  br label %bb37
bb26:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l98, i64 248, i1 false)
  %t119 = getelementptr %"compiler/mir:Fn", ptr %l5, i32 0, i32 9
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/eval:Machine", ptr %t120, i32 0, i32 49
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l101, !tbaa !27
  %t124 = load i64, ptr %l4, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr %"compiler/eval:frame", ptr %t127, i64 %t124
  %t129 = getelementptr %"compiler/eval:frame", ptr %t128, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = call %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v0, ptr %t119, i64 %t130)
  store %"compiler/mir:BasicBlock" %t133, ptr %l104
  br label %bb27
bb27:
  %t134 = getelementptr %"compiler/mir:BasicBlock", ptr %l104, i32 0, i32 1
  %t135 = load { i64, [8 x i64] }, ptr %t134
  store { i64, [8 x i64] } %t135, ptr %l6
  %t137 = load { i64, [8 x i64] }, ptr %l6
  %t139 = extractvalue { i64, [8 x i64] } %t137, 0
  %t140 = icmp eq i64 %t139, 4
  br i1 %t140, label %bb28, label %bb29
bb28:
  %t142 = getelementptr { i64, [8 x i64] }, ptr %l6, i32 0, i32 1
  %t143 = getelementptr { %"compiler/source:Span", i32 }, ptr %t142, i32 0, i32 0
  %t144 = load %"compiler/source:Span", ptr %t143
  store %"compiler/source:Span" %t144, ptr %l7
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t146 = getelementptr %"compiler/mir:Fn", ptr %l5, i32 0, i32 2
  %t147 = load i64, ptr %t146, !tbaa !24
  %t149 = load %"compiler/source:Span", ptr %l7
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t155 = getelementptr %"compiler/eval:Machine", ptr %t151, i32 0, i32 69
  store i64 %t147, ptr %t155, !tbaa !24
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/eval:Machine", ptr %t156, i32 0, i32 70
  store %"compiler/source:Span" %t149, ptr %t160
  br label %bb36
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_f2c339cbb479452c_c316cd9120a44978)
  unreachable
bb36:
  br label %bb37
bb37:
  %t161 = load ptr, ptr %l0, !tbaa !29
  store ptr %t161, ptr %l115, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/eval:Machine", ptr %t162, i32 0, i32 1
  %t165 = load i32, ptr %t164
  %t167 = trunc i64 0 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb38, label %bb39
bb38:
  %t170 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyEqDepth, !tbaa !27
  store { i64, ptr } %t170, ptr %l119, !tbaa !27
  br label %bb40
bb39:
  %t172 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyRunEqDepth, !tbaa !27
  store { i64, ptr } %t172, ptr %l119, !tbaa !27
  br label %bb40
bb40:
  %t174 = load ptr, ptr @__olang_prog_scope
  %t175 = load ptr, ptr %l115, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l119, !tbaa !27
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t174, ptr %t175, { i64, ptr } %t176)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb42:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l123, !tbaa !29
  %t179 = load ptr, ptr %l123, !tbaa !29
  %t180 = getelementptr %"compiler/eval:Machine", ptr %t179, i32 0, i32 5
  %t181 = load i64, ptr %t180, !tbaa !24
  %t183 = add i64 %t181, 1
  %t185 = load ptr, ptr %l123, !tbaa !29
  %t186 = getelementptr %"compiler/eval:Machine", ptr %t185, i32 0, i32 5
  store i64 %t183, ptr %t186, !tbaa !24
  br label %bb43
bb43:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = getelementptr %"compiler/eval:Machine", ptr %t187, i32 0, i32 17
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l127, !tbaa !27
  %t191 = load i64, ptr %l1, !tbaa !24
  %t193 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr %"compiler/eval:cfn", ptr %t194, i64 %t191
  %t196 = getelementptr %"compiler/eval:cfn", ptr %t195, i32 0, i32 16
  %t197 = load i1, ptr %t196, !tbaa !21
  br i1 %t197, label %bb44, label %bb45
bb44:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/eval:Machine", ptr %t199, i32 0, i32 14
  store i1 true, ptr %t201, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/eval:Machine", ptr %t202, i32 0, i32 17
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  store { i64, ptr } %t205, ptr %l132, !tbaa !27
  %t206 = load i64, ptr %l1, !tbaa !24
  %t208 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !27
  %t210 = getelementptr %"compiler/eval:cfn", ptr %t209, i64 %t206
  %t211 = getelementptr %"compiler/eval:cfn", ptr %t210, i32 0, i32 1
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l10, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  store i64 %t216, ptr %l11, !tbaa !24
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/eval:Machine", ptr %t218, i32 0, i32 17
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  store { i64, ptr } %t221, ptr %l138, !tbaa !27
  %t222 = load i64, ptr %l1, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr %"compiler/eval:cfn", ptr %t225, i64 %t222
  %t227 = getelementptr %"compiler/eval:cfn", ptr %t226, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t228, 0
  store i64 %t230, ptr %l12, !tbaa !24
  %t232 = load ptr, ptr %l0, !tbaa !29
  %t234 = getelementptr %"compiler/eval:Machine", ptr %t232, i32 0, i32 17
  %t235 = load { i64, ptr }, ptr %t234, !tbaa !27
  store { i64, ptr } %t235, ptr %l143, !tbaa !27
  %t236 = load i64, ptr %l1, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr %"compiler/eval:cfn", ptr %t239, i64 %t236
  %t241 = getelementptr %"compiler/eval:cfn", ptr %t240, i32 0, i32 15
  %t242 = load i64, ptr %t241, !tbaa !24
  store i64 %t242, ptr %l13, !tbaa !24
  %t244 = call %"compiler/eval:frame" @compiler_2feval_3aframe_2ector(ptr %s0)
  store %"compiler/eval:frame" %t244, ptr %l146
  br label %bb47
bb47:
  %t245 = load %"compiler/eval:frame", ptr %l146
  store %"compiler/eval:frame" %t245, ptr %l14
  %t246 = load i64, ptr %l1, !tbaa !24
  %t254 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 0
  store i64 %t246, ptr %t254, !tbaa !24
  %t257 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 7
  store i64 %a2, ptr %t257, !tbaa !24
  %t260 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 8
  store i64 %a3, ptr %t260, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = getelementptr %"compiler/eval:Machine", ptr %t261, i32 0, i32 52
  %t264 = load i64, ptr %t263, !tbaa !24
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/eval:Machine", ptr %t266, i32 0, i32 52
  %t269 = load i64, ptr %t268, !tbaa !24
  %t270 = load i64, ptr %l11, !tbaa !24
  %t273 = add i64 %t269, %t270
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/eval:Machine", ptr %t275, i32 0, i32 52
  %t278 = load i64, ptr %t277, !tbaa !24
  %t279 = load i64, ptr %l11, !tbaa !24
  %t282 = add i64 %t278, %t279
  %t283 = load i64, ptr %l12, !tbaa !24
  %t286 = add i64 %t282, %t283
  %t290 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 3
  store i64 %t264, ptr %t290, !tbaa !24
  %t293 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 4
  store i64 %t273, ptr %t293, !tbaa !24
  %t296 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 5
  store i64 %t286, ptr %t296, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/eval:Machine", ptr %t297, i32 0, i32 53
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t299)
  store i64 %t301, ptr %l170
  br label %bb48
bb48:
  %t302 = load i64, ptr %l170, !tbaa !24
  %t303 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 9
  store i64 %t302, ptr %t303, !tbaa !24
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load i64, ptr @G_2ecompiler_2feval_2esStore, !tbaa !24
  %t308 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %t304, i64 %t305)
  store i64 %t308, ptr %l173
  br label %bb49
bb49:
  %t309 = load i64, ptr %l173, !tbaa !24
  %t310 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 6
  store i64 %t309, ptr %t310, !tbaa !24
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/eval:Machine", ptr %t311, i32 0, i32 52
  %t314 = load i64, ptr %t313, !tbaa !24
  %t315 = load i64, ptr %l11, !tbaa !24
  %t318 = add i64 %t314, %t315
  %t319 = load i64, ptr %l12, !tbaa !24
  %t322 = add i64 %t318, %t319
  %t323 = load i64, ptr %l13, !tbaa !24
  %t326 = add i64 %t322, %t323
  store i64 %t326, ptr %l21, !tbaa !24
  %t328 = load i64, ptr %l21, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"compiler/eval:Machine", ptr %t329, i32 0, i32 51
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t337 = icmp sgt i64 %t328, %t334
  br i1 %t337, label %bb50, label %bb51
bb50:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = getelementptr %"compiler/eval:Machine", ptr %t339, i32 0, i32 51
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  store { i64, ptr } %t342, ptr %l22, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t344, 0
  store i64 %t346, ptr %l23, !tbaa !24
  br label %bb52
bb51:
  br label %bb74
bb52:
  %t348 = load i64, ptr %l23, !tbaa !24
  %t349 = load i64, ptr %l21, !tbaa !24
  %t352 = icmp slt i64 %t348, %t349
  %t354 = xor i1 %t352, true
  br i1 %t354, label %bb53, label %bb54
bb53:
  br label %bb57
bb54:
  br label %bb55
bb55:
  %t356 = load i64, ptr %l23, !tbaa !24
  %t358 = mul i64 %t356, 2
  store i64 %t358, ptr %l23, !tbaa !24
  br label %bb56
bb56:
  br label %bb52
bb57:
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l197, !tbaa !29
  %t361 = load i64, ptr %l23, !tbaa !24
  store i64 %t361, ptr %l198, !tbaa !24
  %t362 = load i64, ptr %l198, !tbaa !24
  %t363 = icmp sge i64 %t362, 0
  br i1 %t363, label %bb58, label %bb59
bb58:
  %t365 = load i64, ptr %l198, !tbaa !24
  %t366 = icmp sle i64 %t365, 1152921504606846975
  br i1 %t366, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_d67750d3ea89b5a6_4cf132db9678b04a)
  unreachable
bb60:
  %t368 = load i64, ptr %l198, !tbaa !24
  %t369 = mul i64 %t368, 8
  %t370 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t369)
  %t371 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  %t374 = load ptr, ptr %l197, !tbaa !29
  %t375 = getelementptr %"compiler/eval:Machine", ptr %t374, i32 0, i32 51
  store { i64, ptr } %t372, ptr %t375, !tbaa !27
  store i64 0, ptr %l24, !tbaa !24
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t378 = getelementptr %"compiler/eval:Machine", ptr %t376, i32 0, i32 52
  %t379 = load i64, ptr %t378, !tbaa !24
  store i64 %t379, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t381 = load i64, ptr %l25, !tbaa !24
  %t382 = load i64, ptr %l24, !tbaa !24
  %t385 = icmp sgt i64 %t381, %t382
  br i1 %t385, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_d67750d3ea89b5a6_4cf132db9678b04a)
  unreachable
bb62:
  %t387 = load i64, ptr %l26, !tbaa !24
  %t389 = icmp sgt i64 %t387, 0
  br i1 %t389, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb67
bb64:
  %t391 = load i64, ptr %l25, !tbaa !24
  %t392 = load i64, ptr %l24, !tbaa !24
  %t395 = sub i64 %t391, %t392
  %t396 = load i64, ptr %l26, !tbaa !24
  %t399 = add i64 %t395, %t396
  %t401 = sub i64 %t399, 1
  %t402 = load i64, ptr %l26, !tbaa !24
  %t405 = sdiv i64 %t401, %t402
  store i64 %t405, ptr %l210, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l210, !tbaa !24
  br label %bb66
bb66:
  %t407 = load i64, ptr %l210, !tbaa !24
  store i64 %t407, ptr %l207, !tbaa !24
  br label %bb67
bb67:
  %t408 = load i64, ptr %l207, !tbaa !24
  store i64 %t408, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb68
bb68:
  %t409 = load i64, ptr %l28, !tbaa !24
  %t410 = load i64, ptr %l27, !tbaa !24
  %t413 = icmp slt i64 %t409, %t410
  %t415 = xor i1 %t413, true
  br i1 %t415, label %bb69, label %bb70
bb69:
  br label %bb73
bb70:
  br label %bb71
bb71:
  %t417 = load i64, ptr %l24, !tbaa !24
  %t418 = load i64, ptr %l28, !tbaa !24
  %t419 = load i64, ptr %l26, !tbaa !24
  %t422 = mul i64 %t418, %t419
  %t425 = add i64 %t417, %t422
  store i64 %t425, ptr %l29, !tbaa !24
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = getelementptr %"compiler/eval:Machine", ptr %t427, i32 0, i32 51
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  store { i64, ptr } %t430, ptr %l229, !tbaa !27
  %t431 = load i64, ptr %l29, !tbaa !24
  %t432 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t432, ptr %l231, !tbaa !27
  %t433 = load i64, ptr %l29, !tbaa !24
  %t435 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr i64, ptr %t436, i64 %t433
  %t438 = load i64, ptr %t437, !tbaa !34
  %t441 = getelementptr { i64, ptr }, ptr %l229, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr i64, ptr %t442, i64 %t431
  store i64 %t438, ptr %t443, !tbaa !34
  br label %bb72
bb72:
  %t444 = load i64, ptr %l28, !tbaa !24
  %t446 = add i64 %t444, 1
  store i64 %t446, ptr %l28, !tbaa !24
  br label %bb68
bb73:
  br label %bb74
bb74:
  store i64 0, ptr %l30, !tbaa !24
  %t448 = load i64, ptr %l11, !tbaa !24
  store i64 %t448, ptr %l31, !tbaa !24
  store i64 1, ptr %l32, !tbaa !24
  %t450 = load i64, ptr %l31, !tbaa !24
  %t451 = load i64, ptr %l30, !tbaa !24
  %t454 = icmp sgt i64 %t450, %t451
  br i1 %t454, label %bb75, label %bb76
bb75:
  %t456 = load i64, ptr %l32, !tbaa !24
  %t458 = icmp sgt i64 %t456, 0
  br i1 %t458, label %bb77, label %bb78
bb76:
  store i64 0, ptr %l240, !tbaa !24
  br label %bb80
bb77:
  %t460 = load i64, ptr %l31, !tbaa !24
  %t461 = load i64, ptr %l30, !tbaa !24
  %t464 = sub i64 %t460, %t461
  %t465 = load i64, ptr %l32, !tbaa !24
  %t468 = add i64 %t464, %t465
  %t470 = sub i64 %t468, 1
  %t471 = load i64, ptr %l32, !tbaa !24
  %t474 = sdiv i64 %t470, %t471
  store i64 %t474, ptr %l243, !tbaa !24
  br label %bb79
bb78:
  store i64 0, ptr %l243, !tbaa !24
  br label %bb79
bb79:
  %t476 = load i64, ptr %l243, !tbaa !24
  store i64 %t476, ptr %l240, !tbaa !24
  br label %bb80
bb80:
  %t477 = load i64, ptr %l240, !tbaa !24
  store i64 %t477, ptr %l33, !tbaa !24
  store i64 0, ptr %l34, !tbaa !24
  br label %bb81
bb81:
  %t478 = load i64, ptr %l34, !tbaa !24
  %t479 = load i64, ptr %l33, !tbaa !24
  %t482 = icmp slt i64 %t478, %t479
  %t484 = xor i1 %t482, true
  br i1 %t484, label %bb82, label %bb83
bb82:
  br label %bb91
bb83:
  br label %bb84
bb84:
  %t486 = load i64, ptr %l30, !tbaa !24
  %t487 = load i64, ptr %l34, !tbaa !24
  %t488 = load i64, ptr %l32, !tbaa !24
  %t491 = mul i64 %t487, %t488
  %t494 = add i64 %t486, %t491
  store i64 %t494, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  %t496 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t496, ptr %l261, !tbaa !27
  %t497 = load i64, ptr %l35, !tbaa !24
  %t499 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t500 = load ptr, ptr %t499, !tbaa !27
  %t501 = getelementptr %"compiler/mir:Local", ptr %t500, i64 %t497
  %t502 = getelementptr %"compiler/mir:Local", ptr %t501, i32 0, i32 4
  %t503 = load { i64, [1 x i64] }, ptr %t502
  %t505 = extractvalue { i64, [1 x i64] } %t503, 0
  %t506 = icmp eq i64 %t505, 3
  br i1 %t506, label %bb85, label %bb86
bb85:
  %t508 = load ptr, ptr %l0, !tbaa !29
  store ptr %t508, ptr %l265, !tbaa !29
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t510, ptr %l267, !tbaa !27
  %t511 = load i64, ptr %l35, !tbaa !24
  %t513 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t514 = load ptr, ptr %t513, !tbaa !27
  %t515 = getelementptr %"compiler/mir:Local", ptr %t514, i64 %t511
  %t516 = getelementptr %"compiler/mir:Local", ptr %t515, i32 0, i32 2
  %t517 = load i32, ptr %t516, !tbaa !23
  %t520 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t509, i32 %t517)
  store i64 %t520, ptr %l270
  br label %bb87
bb86:
  br label %bb89
bb87:
  %t521 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t522 = getelementptr %"compiler/eval:frame", ptr %l14, i32 0, i32 6
  %t523 = load i64, ptr %t522, !tbaa !24
  %t524 = load ptr, ptr %l265, !tbaa !29
  %t525 = load i64, ptr %l270, !tbaa !24
  %t528 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t524, i64 %t525, i64 %t521, i64 %t523)
  store %"compiler/eval:Ptr" %t528, ptr %l273
  br label %bb88
bb88:
  %t529 = getelementptr %"compiler/eval:Ptr", ptr %l273, i32 0, i32 0
  %t530 = load i64, ptr %t529, !tbaa !24
  store i64 %t530, ptr %l36, !tbaa !24
  br label %bb89
bb89:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/eval:Machine", ptr %t532, i32 0, i32 51
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l276, !tbaa !27
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/eval:Machine", ptr %t536, i32 0, i32 52
  %t539 = load i64, ptr %t538, !tbaa !24
  %t540 = load i64, ptr %l35, !tbaa !24
  %t543 = add i64 %t539, %t540
  %t544 = load i64, ptr %l36, !tbaa !24
  %t547 = getelementptr { i64, ptr }, ptr %l276, i32 0, i32 1
  %t548 = load ptr, ptr %t547, !tbaa !27
  %t549 = getelementptr i64, ptr %t548, i64 %t543
  store i64 %t544, ptr %t549, !tbaa !34
  br label %bb90
bb90:
  %t550 = load i64, ptr %l34, !tbaa !24
  %t552 = add i64 %t550, 1
  store i64 %t552, ptr %l34, !tbaa !24
  br label %bb81
bb91:
  %t554 = load i64, ptr %l11, !tbaa !24
  store i64 %t554, ptr %l37, !tbaa !24
  %t556 = load i64, ptr %l21, !tbaa !24
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = getelementptr %"compiler/eval:Machine", ptr %t557, i32 0, i32 52
  %t560 = load i64, ptr %t559, !tbaa !24
  %t563 = sub i64 %t556, %t560
  store i64 %t563, ptr %l38, !tbaa !24
  store i64 1, ptr %l39, !tbaa !24
  %t565 = load i64, ptr %l38, !tbaa !24
  %t566 = load i64, ptr %l37, !tbaa !24
  %t569 = icmp sgt i64 %t565, %t566
  br i1 %t569, label %bb92, label %bb93
bb92:
  %t571 = load i64, ptr %l39, !tbaa !24
  %t573 = icmp sgt i64 %t571, 0
  br i1 %t573, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l292, !tbaa !24
  br label %bb97
bb94:
  %t575 = load i64, ptr %l38, !tbaa !24
  %t576 = load i64, ptr %l37, !tbaa !24
  %t579 = sub i64 %t575, %t576
  %t580 = load i64, ptr %l39, !tbaa !24
  %t583 = add i64 %t579, %t580
  %t585 = sub i64 %t583, 1
  %t586 = load i64, ptr %l39, !tbaa !24
  %t589 = sdiv i64 %t585, %t586
  store i64 %t589, ptr %l295, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l295, !tbaa !24
  br label %bb96
bb96:
  %t591 = load i64, ptr %l295, !tbaa !24
  store i64 %t591, ptr %l292, !tbaa !24
  br label %bb97
bb97:
  %t592 = load i64, ptr %l292, !tbaa !24
  store i64 %t592, ptr %l40, !tbaa !24
  store i64 0, ptr %l41, !tbaa !24
  br label %bb98
bb98:
  %t593 = load i64, ptr %l41, !tbaa !24
  %t594 = load i64, ptr %l40, !tbaa !24
  %t597 = icmp slt i64 %t593, %t594
  %t599 = xor i1 %t597, true
  br i1 %t599, label %bb99, label %bb100
bb99:
  br label %bb103
bb100:
  br label %bb101
bb101:
  %t601 = load i64, ptr %l37, !tbaa !24
  %t602 = load i64, ptr %l41, !tbaa !24
  %t603 = load i64, ptr %l39, !tbaa !24
  %t606 = mul i64 %t602, %t603
  %t609 = add i64 %t601, %t606
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = getelementptr %"compiler/eval:Machine", ptr %t611, i32 0, i32 51
  %t614 = load { i64, ptr }, ptr %t613, !tbaa !27
  store { i64, ptr } %t614, ptr %l314, !tbaa !27
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t617 = getelementptr %"compiler/eval:Machine", ptr %t615, i32 0, i32 52
  %t618 = load i64, ptr %t617, !tbaa !24
  %t622 = add i64 %t618, %t609
  %t624 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t625 = load ptr, ptr %t624, !tbaa !27
  %t626 = getelementptr i64, ptr %t625, i64 %t622
  store i64 0, ptr %t626, !tbaa !34
  br label %bb102
bb102:
  %t627 = load i64, ptr %l41, !tbaa !24
  %t629 = add i64 %t627, 1
  store i64 %t629, ptr %l41, !tbaa !24
  br label %bb98
bb103:
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load i64, ptr %l21, !tbaa !24
  %t635 = getelementptr %"compiler/eval:Machine", ptr %t631, i32 0, i32 52
  store i64 %t632, ptr %t635, !tbaa !24
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t638 = getelementptr %"compiler/eval:Machine", ptr %t636, i32 0, i32 50
  %t639 = load i64, ptr %t638, !tbaa !24
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = getelementptr %"compiler/eval:Machine", ptr %t640, i32 0, i32 49
  %t643 = load { i64, ptr }, ptr %t642, !tbaa !27
  %t645 = extractvalue { i64, ptr } %t643, 0
  %t648 = icmp sge i64 %t639, %t645
  br i1 %t648, label %bb104, label %bb105
bb104:
  %t650 = load ptr, ptr %l0, !tbaa !29
  %t652 = getelementptr %"compiler/eval:Machine", ptr %t650, i32 0, i32 49
  %t653 = load { i64, ptr }, ptr %t652, !tbaa !27
  store { i64, ptr } %t653, ptr %l43, !tbaa !27
  %t655 = load ptr, ptr %l0, !tbaa !29
  store ptr %t655, ptr %l331, !tbaa !29
  %t656 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t656, 0
  %t660 = mul i64 2, %t658
  store i64 %t660, ptr %l334, !tbaa !24
  store %"compiler/eval:frame" zeroinitializer, ptr %l335
  %t661 = load i64, ptr %l334, !tbaa !24
  %t662 = icmp sgt i64 %t661, 0
  br i1 %t662, label %bb106, label %bb107
bb105:
  br label %bb125
bb106:
  %t664 = call %"compiler/eval:frame" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aframe()
  store %"compiler/eval:frame" %t664, ptr %l337
  br label %bb108
bb107:
  %t665 = load i64, ptr %l334, !tbaa !24
  %t666 = icmp sge i64 %t665, 0
  br i1 %t666, label %bb109, label %bb110
bb108:
  %t668 = load %"compiler/eval:frame", ptr %l337
  store %"compiler/eval:frame" %t668, ptr %l335
  br label %bb107
bb109:
  %t669 = load i64, ptr %l334, !tbaa !24
  %t670 = icmp sle i64 %t669, 72057594037927935
  br i1 %t670, label %bb111, label %bb112
bb110:
  call void @__olang_check_failed(ptr @olang_loc_84b7ba4c2a706fc5_7fbf5d3432269f09)
  unreachable
bb111:
  %t672 = load i64, ptr %l334, !tbaa !24
  %t673 = mul i64 %t672, 128
  %t674 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t673)
  %t675 = load %"compiler/eval:frame", ptr %l335
  store i64 0, ptr %t676
  br label %fill.677
fill.677:
  %t680 = load i64, ptr %t676
  %t681 = icmp slt i64 %t680, %t672
  br i1 %t681, label %fillb.678, label %filld.679
fillb.678:
  %t682 = getelementptr %"compiler/eval:frame", ptr %t674, i64 %t680
  store %"compiler/eval:frame" %t675, ptr %t682
  %t683 = add i64 %t680, 1
  store i64 %t683, ptr %t676
  br label %fill.677
filld.679:
  %t684 = insertvalue { i64, ptr } undef, i64 %t672, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t674, 1
  %t687 = load ptr, ptr %l331, !tbaa !29
  %t688 = getelementptr %"compiler/eval:Machine", ptr %t687, i32 0, i32 49
  store { i64, ptr } %t685, ptr %t688, !tbaa !27
  store i64 0, ptr %l44, !tbaa !24
  %t689 = load ptr, ptr %l0, !tbaa !29
  %t691 = getelementptr %"compiler/eval:Machine", ptr %t689, i32 0, i32 50
  %t692 = load i64, ptr %t691, !tbaa !24
  store i64 %t692, ptr %l45, !tbaa !24
  store i64 1, ptr %l46, !tbaa !24
  %t694 = load i64, ptr %l45, !tbaa !24
  %t695 = load i64, ptr %l44, !tbaa !24
  %t698 = icmp sgt i64 %t694, %t695
  br i1 %t698, label %bb113, label %bb114
bb112:
  call void @__olang_check_failed(ptr @olang_loc_84b7ba4c2a706fc5_7fbf5d3432269f09)
  unreachable
bb113:
  %t700 = load i64, ptr %l46, !tbaa !24
  %t702 = icmp sgt i64 %t700, 0
  br i1 %t702, label %bb115, label %bb116
bb114:
  store i64 0, ptr %l346, !tbaa !24
  br label %bb118
bb115:
  %t704 = load i64, ptr %l45, !tbaa !24
  %t705 = load i64, ptr %l44, !tbaa !24
  %t708 = sub i64 %t704, %t705
  %t709 = load i64, ptr %l46, !tbaa !24
  %t712 = add i64 %t708, %t709
  %t714 = sub i64 %t712, 1
  %t715 = load i64, ptr %l46, !tbaa !24
  %t718 = sdiv i64 %t714, %t715
  store i64 %t718, ptr %l349, !tbaa !24
  br label %bb117
bb116:
  store i64 0, ptr %l349, !tbaa !24
  br label %bb117
bb117:
  %t720 = load i64, ptr %l349, !tbaa !24
  store i64 %t720, ptr %l346, !tbaa !24
  br label %bb118
bb118:
  %t721 = load i64, ptr %l346, !tbaa !24
  store i64 %t721, ptr %l47, !tbaa !24
  store i64 0, ptr %l48, !tbaa !24
  br label %bb119
bb119:
  %t722 = load i64, ptr %l48, !tbaa !24
  %t723 = load i64, ptr %l47, !tbaa !24
  %t726 = icmp slt i64 %t722, %t723
  %t728 = xor i1 %t726, true
  br i1 %t728, label %bb120, label %bb121
bb120:
  br label %bb124
bb121:
  br label %bb122
bb122:
  %t730 = load i64, ptr %l44, !tbaa !24
  %t731 = load i64, ptr %l48, !tbaa !24
  %t732 = load i64, ptr %l46, !tbaa !24
  %t735 = mul i64 %t731, %t732
  %t738 = add i64 %t730, %t735
  store i64 %t738, ptr %l49, !tbaa !24
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t742 = getelementptr %"compiler/eval:Machine", ptr %t740, i32 0, i32 49
  %t743 = load { i64, ptr }, ptr %t742, !tbaa !27
  store { i64, ptr } %t743, ptr %l368, !tbaa !27
  %t744 = load i64, ptr %l49, !tbaa !24
  %t745 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t745, ptr %l370, !tbaa !27
  %t746 = load i64, ptr %l49, !tbaa !24
  %t748 = getelementptr { i64, ptr }, ptr %l370, i32 0, i32 1
  %t749 = load ptr, ptr %t748, !tbaa !27
  %t750 = getelementptr %"compiler/eval:frame", ptr %t749, i64 %t746
  %t751 = load %"compiler/eval:frame", ptr %t750
  %t754 = getelementptr { i64, ptr }, ptr %l368, i32 0, i32 1
  %t755 = load ptr, ptr %t754, !tbaa !27
  %t756 = getelementptr %"compiler/eval:frame", ptr %t755, i64 %t744
  store %"compiler/eval:frame" %t751, ptr %t756
  br label %bb123
bb123:
  %t757 = load i64, ptr %l48, !tbaa !24
  %t759 = add i64 %t757, 1
  store i64 %t759, ptr %l48, !tbaa !24
  br label %bb119
bb124:
  br label %bb125
bb125:
  %t761 = load ptr, ptr %l0, !tbaa !29
  %t763 = getelementptr %"compiler/eval:Machine", ptr %t761, i32 0, i32 49
  %t764 = load { i64, ptr }, ptr %t763, !tbaa !27
  store { i64, ptr } %t764, ptr %l376, !tbaa !27
  %t765 = load ptr, ptr %l0, !tbaa !29
  %t767 = getelementptr %"compiler/eval:Machine", ptr %t765, i32 0, i32 50
  %t768 = load i64, ptr %t767, !tbaa !24
  %t769 = load %"compiler/eval:frame", ptr %l14
  %t772 = getelementptr { i64, ptr }, ptr %l376, i32 0, i32 1
  %t773 = load ptr, ptr %t772, !tbaa !27
  %t774 = getelementptr %"compiler/eval:frame", ptr %t773, i64 %t768
  store %"compiler/eval:frame" %t769, ptr %t774
  %t775 = load ptr, ptr %l0, !tbaa !29
  store ptr %t775, ptr %l380, !tbaa !29
  %t776 = load ptr, ptr %l380, !tbaa !29
  %t777 = getelementptr %"compiler/eval:Machine", ptr %t776, i32 0, i32 50
  %t778 = load i64, ptr %t777, !tbaa !24
  %t780 = add i64 %t778, 1
  %t782 = load ptr, ptr %l380, !tbaa !29
  %t783 = getelementptr %"compiler/eval:Machine", ptr %t782, i32 0, i32 50
  store i64 %t780, ptr %t783, !tbaa !24
  %t784 = load ptr, ptr %l0, !tbaa !29
  %t786 = getelementptr %"compiler/eval:Machine", ptr %t784, i32 0, i32 50
  %t787 = load i64, ptr %t786, !tbaa !24
  %t789 = sub i64 %t787, 1
  call void @__olang_scope_close(ptr %s0)
  store i64 %t789, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputData(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i32 %a4, i64 %a5, %"compiler/source:Span" %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:Ptr"
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca { i64, [1 x i64] }
  %l9 = alloca i64
  %l10 = alloca { %"compiler/eval:Ptr", i64 }
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca %"compiler/mir:Fn"
  %l20 = alloca { i64, [1 x i64] }
  %l24 = alloca ptr
  %l25 = alloca %"compiler/eval:Ptr"
  %l28 = alloca i64
  %l36 = alloca { %"compiler/eval:Ptr", i64 }
  %l43 = alloca i64
  %l50 = alloca ptr
  %l54 = alloca %"compiler/eval:Ptr"
  %l65 = alloca ptr
  %l66 = alloca %"compiler/eval:Ptr"
  %l67 = alloca %"compiler/eval:Ptr"
  %l70 = alloca i64
  %s4 = alloca %olang.scope
  %t3 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t3, ptr %v0, ptr %v0, ptr %t1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t3, i64 248, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l16, i64 248, i1 false)
  %t6 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 19
  %t7 = load i32, ptr %l4, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %t6, i64 %t9)
  store { i64, [1 x i64] } %t12, ptr %l20
  br label %bb2
bb2:
  %t13 = load { i64, [1 x i64] }, ptr %l20
  store { i64, [1 x i64] } %t13, ptr %l8
  %t14 = load { i64, [1 x i64] }, ptr %l8
  %t16 = extractvalue { i64, [1 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 0
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = getelementptr { i64, [1 x i64] }, ptr %l8, i32 0, i32 1
  %t20 = getelementptr { i64 }, ptr %t19, i32 0, i32 0
  %t21 = load i64, ptr %t20
  store i64 %t21, ptr %l9, !tbaa !24
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l24, !tbaa !29
  %t24 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t24, ptr %l25
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l3, !tbaa !23
  %t29 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t25, i32 %t26)
  store i64 %t29, ptr %l28
  br label %bb6
bb6:
  %t30 = load i64, ptr %l9, !tbaa !24
  %t31 = load ptr, ptr %l24, !tbaa !29
  %t32 = load %"compiler/eval:Ptr", ptr %l25
  %t33 = load i64, ptr %l28, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t31, %"compiler/eval:Ptr" %t32, i64 %t33, i64 %t30)
  br label %bb7
bb7:
  br label %ret
bb8:
  br i1 true, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_12565802a2336670_a75db38aedd0e3fc)
  unreachable
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l3, !tbaa !23
  %t37 = load i32, ptr %l4, !tbaa !23
  %t46 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2edataFor(ptr %v0, ptr %v0, ptr %t35, ptr %l7, i32 %t36, i32 %t37, i64 %a5, %"compiler/source:Span" %a6)
  store { %"compiler/eval:Ptr", i64 } %t46, ptr %l36
  br label %bb14
bb14:
  %t47 = load { %"compiler/eval:Ptr", i64 }, ptr %l36
  store { %"compiler/eval:Ptr", i64 } %t47, ptr %l10
  %t48 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l10, i32 0, i32 0
  %t49 = load %"compiler/eval:Ptr", ptr %t48
  store %"compiler/eval:Ptr" %t49, ptr %l11
  %t51 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l10, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  store i64 %t52, ptr %l12, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/eval:Machine", ptr %t54, i32 0, i32 13
  %t57 = load i1, ptr %t56, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t59, i32 %t60)
  store i64 %t63, ptr %l43
  br label %bb18
bb18:
  %t64 = load i64, ptr %l43, !tbaa !24
  store i64 %t64, ptr %l13, !tbaa !24
  %t65 = load i64, ptr %l13, !tbaa !24
  %t66 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  %t69 = icmp eq i64 %t65, %t66
  br i1 %t69, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb25
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load %"compiler/eval:Ptr", ptr %l2
  %t73 = load i64, ptr %l12, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t71, %"compiler/eval:Ptr" %t72, i64 8, i64 %t73)
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l50, !tbaa !29
  %t78 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = getelementptr %"compiler/eval:Ptr", ptr %l2, i32 0, i32 1
  %t81 = load i64, ptr %t80, !tbaa !24
  %t83 = add i64 %t81, 8
  %t86 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t79, i64 %t83)
  store %"compiler/eval:Ptr" %t86, ptr %l54
  br label %bb23
bb23:
  %t87 = load %"compiler/eval:Ptr", ptr %l11
  %t88 = load ptr, ptr %l50, !tbaa !29
  %t89 = load %"compiler/eval:Ptr", ptr %l54
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t88, %"compiler/eval:Ptr" %t89, %"compiler/eval:Ptr" %t87)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  br label %bb42
bb25:
  %t91 = load i64, ptr %l13, !tbaa !24
  %t92 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t95 = icmp eq i64 %t91, %t92
  br i1 %t95, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load %"compiler/eval:Ptr", ptr %l2
  %t99 = load %"compiler/eval:Ptr", ptr %l11
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t97, %"compiler/eval:Ptr" %t98, %"compiler/eval:Ptr" %t99)
  br label %bb29
bb29:
  br label %bb42
bb30:
  %t103 = load i64, ptr %l13, !tbaa !24
  %t104 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  br i1 %t107, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l65, !tbaa !29
  %t110 = load %"compiler/eval:Ptr", ptr %l2
  store %"compiler/eval:Ptr" %t110, ptr %l66
  %t111 = load %"compiler/eval:Ptr", ptr %l11
  store %"compiler/eval:Ptr" %t111, ptr %l67
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i32, ptr %l3, !tbaa !23
  %t116 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t112, i32 %t113)
  store i64 %t116, ptr %l70
  br label %bb34
bb34:
  %t117 = load ptr, ptr %l65, !tbaa !29
  %t118 = load %"compiler/eval:Ptr", ptr %l66
  %t119 = load %"compiler/eval:Ptr", ptr %l67
  %t120 = load i64, ptr %l70, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t117, %"compiler/eval:Ptr" %t118, %"compiler/eval:Ptr" %t119, i64 %t120)
  br label %bb35
bb35:
  br label %bb42
bb36:
  br i1 true, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNotModelled, !tbaa !27
  %t123 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t123, ptr %t121, { i64, ptr } %t122)
  br label %bb40
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_1069159e4cdf0a01_3c7ea434b50ec3ad)
  unreachable
bb42:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeMutable(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/mir:Range" %a2) #0 {
entry:
  %l2 = alloca %"compiler/mir:Range"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l9 = alloca { i64, [4 x i64] }
  %l10 = alloca %"compiler/mir:Lvalue"
  %l15 = alloca i32
  %l18 = alloca i32
  %l43 = alloca { i64, [4 x i64] }
  %l49 = alloca i1
  %rv = alloca i1
  store %"compiler/mir:Range" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store i32 0, ptr %l3, !tbaa !23
  %t1 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 1
  %t2 = load i32, ptr %t1, !tbaa !23
  store i32 %t2, ptr %l4, !tbaa !23
  store i32 1, ptr %l5, !tbaa !23
  %t4 = load i32, ptr %l4, !tbaa !23
  %t5 = load i32, ptr %l3, !tbaa !23
  %t8 = icmp sgt i32 %t4, %t5
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp sgt i32 %t10, 0
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i32 0, ptr %l15, !tbaa !23
  br label %bb6
bb3:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = load i32, ptr %l3, !tbaa !23
  %t18 = sub i32 %t14, %t15
  %t19 = load i32, ptr %l5, !tbaa !23
  %t22 = add i32 %t18, %t19
  %t24 = sub i32 %t22, 1
  %t25 = load i32, ptr %l5, !tbaa !23
  %t28 = sdiv i32 %t24, %t25
  store i32 %t28, ptr %l18, !tbaa !23
  br label %bb5
bb4:
  store i32 0, ptr %l18, !tbaa !23
  br label %bb5
bb5:
  %t30 = load i32, ptr %l18, !tbaa !23
  store i32 %t30, ptr %l15, !tbaa !23
  br label %bb6
bb6:
  %t31 = load i32, ptr %l15, !tbaa !23
  store i32 %t31, ptr %l6, !tbaa !23
  store i32 0, ptr %l7, !tbaa !23
  br label %bb7
bb7:
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr %l6, !tbaa !23
  %t36 = icmp slt i32 %t32, %t33
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb8, label %bb9
bb8:
  br label %bb26
bb9:
  br label %bb10
bb10:
  %t40 = load i32, ptr %l3, !tbaa !23
  %t41 = load i32, ptr %l7, !tbaa !23
  %t42 = load i32, ptr %l5, !tbaa !23
  %t45 = mul i32 %t41, %t42
  %t48 = add i32 %t40, %t45
  %t52 = getelementptr %"compiler/mir:Fn", ptr %a1, i32 0, i32 11
  %t53 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 0
  %t54 = load i32, ptr %t53, !tbaa !23
  %t56 = sext i32 %t54 to i64
  %t59 = sext i32 %t48 to i64
  %t62 = add i64 %t56, %t59
  %t65 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v1, ptr %t52, i64 %t62)
  store { i64, [4 x i64] } %t65, ptr %l43
  br label %bb11
bb11:
  %t66 = load { i64, [4 x i64] }, ptr %l43
  store { i64, [4 x i64] } %t66, ptr %l9
  %t67 = load { i64, [4 x i64] }, ptr %l9
  %t69 = extractvalue { i64, [4 x i64] } %t67, 0
  %t70 = icmp eq i64 %t69, 1
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = getelementptr { i64, [4 x i64] }, ptr %l9, i32 0, i32 1
  %t73 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t72, i32 0, i32 0
  %t74 = load %"compiler/mir:Lvalue", ptr %t73
  store %"compiler/mir:Lvalue" %t74, ptr %l10
  br label %bb14
bb13:
  br label %bb19
bb14:
  %t77 = load %"compiler/mir:Lvalue", ptr %l10
  %t80 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %t77)
  store i1 %t80, ptr %l49
  br label %bb15
bb15:
  %t81 = load i1, ptr %l49, !tbaa !21
  br i1 %t81, label %bb16, label %bb17
bb16:
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb24
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_4b87b113311cbcf6_8401054b0e12d93a)
  unreachable
bb24:
  br label %bb25
bb25:
  %t83 = load i32, ptr %l7, !tbaa !23
  %t85 = add i32 %t83, 1
  store i32 %t85, ptr %l7, !tbaa !23
  br label %bb7
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunCleanups(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [5 x i64] }
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i1
  %l43 = alloca i64
  %l50 = alloca i64
  %l63 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l76 = alloca { i64, ptr }
  %t141 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 12
  %t4 = load { i64, [5 x i64] }, ptr %t3
  store { i64, [5 x i64] } %t4, ptr %l2
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 79
  %t9 = load i64, ptr %t8, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 80
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l4
  br label %bb1
bb1:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/eval:Machine", ptr %t16, i32 0, i32 50
  %t19 = load i64, ptr %t18, !tbaa !24
  %t23 = icmp sgt i64 %t19, %a1
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  br label %bb33
bb3:
  br label %bb4
bb4:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/eval:Machine", ptr %t27, i32 0, i32 50
  %t30 = load i64, ptr %t29, !tbaa !24
  %t32 = sub i64 %t30, 1
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/eval:Machine", ptr %t34, i32 0, i32 57
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t36)
  store i64 %t38, ptr %l35
  br label %bb5
bb5:
  %t39 = load i64, ptr %l35, !tbaa !24
  %t40 = sub i64 %t39, 1
  store i64 %t40, ptr %l6, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t44 = icmp slt i64 %t42, 0
  br i1 %t44, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb9
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/eval:Machine", ptr %t46, i32 0, i32 57
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t48, i64 %t49)
  store i64 %t52, ptr %l43
  br label %bb8
bb8:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t54 = load i64, ptr %l43, !tbaa !24
  %t56 = icmp ne i64 %t54, %t53
  store i1 %t56, ptr %l39, !tbaa !21
  br label %bb9
bb9:
  %t58 = load i1, ptr %l39, !tbaa !21
  br i1 %t58, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropFrame(ptr %v0, ptr %t59)
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb32
bb13:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/eval:Machine", ptr %t61, i32 0, i32 59
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l50
  br label %bb14
bb14:
  %t68 = load i64, ptr %l50, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/eval:Machine", ptr %t69, i32 0, i32 57
  %t72 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t71, i64 %t72)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/eval:Machine", ptr %t75, i32 0, i32 58
  %t78 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t77, i64 %t78)
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Machine", ptr %t81, i32 0, i32 59
  %t84 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t83, i64 %t84)
  br label %bb17
bb17:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/eval:Machine", ptr %t87, i32 0, i32 53
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/eval:Machine", ptr %t90, i32 0, i32 49
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l63, !tbaa !27
  %t94 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr %"compiler/eval:frame", ptr %t97, i64 %t94
  %t99 = getelementptr %"compiler/eval:frame", ptr %t98, i32 0, i32 9
  %t100 = load i64, ptr %t99, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %t89, i64 %t100)
  br label %bb18
bb18:
  %t103 = load i64, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/eval:Machine", ptr %t105, i32 0, i32 49
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  store { i64, ptr } %t108, ptr %l68, !tbaa !27
  %t109 = load i64, ptr %l5, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr %"compiler/eval:frame", ptr %t114, i64 %t109
  %t116 = getelementptr %"compiler/eval:frame", ptr %t115, i32 0, i32 1
  store i64 %t103, ptr %t116, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 49
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l72, !tbaa !27
  %t121 = load i64, ptr %l5, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr %"compiler/eval:frame", ptr %t126, i64 %t121
  %t128 = getelementptr %"compiler/eval:frame", ptr %t127, i32 0, i32 2
  store i64 0, ptr %t128, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/eval:Machine", ptr %t129, i32 0, i32 49
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l76, !tbaa !27
  %t133 = load i64, ptr %l5, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr %"compiler/eval:frame", ptr %t138, i64 %t133
  %t140 = getelementptr %"compiler/eval:frame", ptr %t139, i32 0, i32 10
  store i1 false, ptr %t140, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 0
  store i64 0, ptr %t142
  %t143 = load { i64, [5 x i64] }, ptr %t141
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/eval:Machine", ptr %t145, i32 0, i32 13
  store i1 false, ptr %t149, !tbaa !21
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/eval:Machine", ptr %t150, i32 0, i32 60
  store i1 false, ptr %t154, !tbaa !21
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/eval:Machine", ptr %t155, i32 0, i32 12
  store { i64, [5 x i64] } %t143, ptr %t159
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i64, ptr %l5, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eloop(ptr %v0, ptr %t160, i64 %t161)
  br label %bb19
bb19:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/eval:Machine", ptr %t164, i32 0, i32 60
  %t167 = load i1, ptr %t166, !tbaa !21
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb20, label %bb21
bb20:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/eval:Machine", ptr %t171, i32 0, i32 12
  %t174 = load { i64, [5 x i64] }, ptr %t173
  %t178 = extractvalue { i64, [5 x i64] } %t174, 0
  %t179 = icmp eq i64 %t178, 2
  br i1 %t179, label %bb22, label %bb23
bb21:
  br label %bb31
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/eval:Machine", ptr %t181, i32 0, i32 12
  %t184 = load { i64, [5 x i64] }, ptr %t183
  store { i64, [5 x i64] } %t184, ptr %l2
  br label %bb33
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_26a77dbb944b4c43_3cbd97c51474f5af)
  unreachable
bb30:
  br label %bb31
bb31:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/eval:Machine", ptr %t186, i32 0, i32 60
  store i1 false, ptr %t188, !tbaa !21
  br label %bb32
bb32:
  br label %bb1
bb33:
  %t189 = load { i64, [5 x i64] }, ptr %l2
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/eval:Machine", ptr %t191, i32 0, i32 13
  store i1 true, ptr %t195, !tbaa !21
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/eval:Machine", ptr %t196, i32 0, i32 12
  store { i64, [5 x i64] } %t189, ptr %t200
  %t201 = load i64, ptr %l3, !tbaa !24
  %t203 = load %"compiler/source:Span", ptr %l4
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/eval:Machine", ptr %t205, i32 0, i32 79
  store i64 %t201, ptr %t209, !tbaa !24
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/eval:Machine", ptr %t210, i32 0, i32 80
  store %"compiler/source:Span" %t203, ptr %t214
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunDtor(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/eval:Ptr" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, [2 x i64] }
  %l18 = alloca { i64, [2 x i64] }
  %l19 = alloca i32
  %l22 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l33 = alloca i64
  %l39 = alloca %"compiler/mir:Fn"
  %l41 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l47 = alloca i32
  %l48 = alloca %"compiler/eval:Ptr"
  %l51 = alloca i64
  %l55 = alloca i64
  %l58 = alloca i64
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %t53 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 28
  %t7 = call { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Ha5986096190b27059e1b255ecbd90571(ptr %v0, ptr %t3, i32 %a2)
  %t8 = extractvalue { i32, { i64, [2 x i64] } } %t7, 1
  %t9 = extractvalue { i32, { i64, [2 x i64] } } %t7, 0
  store i32 %t9, ptr %l19
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store { i64, [2 x i64] } %t8, ptr %l18
  br label %bb1
bb1:
  %t12 = load { i64, [2 x i64] }, ptr %l18
  store { i64, [2 x i64] } %t12, ptr %l14
  br label %bb5
bb2:
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t15 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t15, ptr %t13, { i64, ptr } %t14)
  br label %bb4
bb4:
  br label %ret
bb5:
  %t18 = load { i64, [2 x i64] }, ptr %l14
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/eval:Machine", ptr %t19, i32 0, i32 21
  %t25 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t21, { i64, [2 x i64] } %t18)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l27
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  store i64 %t26, ptr %l26
  br label %bb6
bb6:
  %t30 = load i64, ptr %l26, !tbaa !24
  store i64 %t30, ptr %l22, !tbaa !24
  br label %bb10
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t33 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t33, ptr %t31, { i64, ptr } %t32)
  br label %bb9
bb9:
  br label %ret
bb10:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i64, ptr %l5, !tbaa !24
  %t39 = load i64, ptr @G_2ecompiler_2feval_2erDtor, !tbaa !24
  %t43 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t37, i64 %t38, i64 %t39, i64 0)
  store i64 %t43, ptr %l33
  br label %bb11
bb11:
  %t44 = load i64, ptr %l33, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp slt i64 %t45, 0
  br i1 %t47, label %bb12, label %bb13
bb12:
  br label %ret
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/eval:Machine", ptr %t49, i32 0, i32 16
  %t52 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t53, ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t53, i64 248, i1 false)
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l39, i64 248, i1 false)
  %t56 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 4
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l41
  br label %bb16
bb16:
  %t59 = load i64, ptr %l41, !tbaa !24
  %t60 = icmp sgt i64 %t59, 0
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l43, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l44, !tbaa !29
  %t64 = load i64, ptr %l6, !tbaa !24
  store i64 %t64, ptr %l45, !tbaa !24
  %t65 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 4
  %t67 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %t65, i64 0)
  store i32 %t67, ptr %l47
  br label %bb19
bb18:
  br label %bb22
bb19:
  %t68 = load ptr, ptr %l44, !tbaa !29
  %t69 = load i64, ptr %l45, !tbaa !24
  %t70 = load i32, ptr %l47, !tbaa !23
  %t71 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t68, i64 %t69, i32 %t70)
  store %"compiler/eval:Ptr" %t71, ptr %l48
  br label %bb20
bb20:
  %t73 = load ptr, ptr %l43, !tbaa !29
  %t74 = load %"compiler/eval:Ptr", ptr %l48
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %t73, %"compiler/eval:Ptr" %t74, %"compiler/eval:Ptr" %a3)
  br label %bb21
bb21:
  br label %bb22
bb22:
  store i64 0, ptr %l8, !tbaa !24
  %t76 = getelementptr %"compiler/mir:Fn", ptr %l7, i32 0, i32 6
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %t76)
  store i64 %t78, ptr %l51
  br label %bb23
bb23:
  %t79 = load i64, ptr %l51, !tbaa !24
  store i64 %t79, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = icmp sgt i64 %t80, %t81
  br i1 %t84, label %bb24, label %bb25
bb24:
  %t86 = load i64, ptr %l10, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb29
bb26:
  %t90 = load i64, ptr %l9, !tbaa !24
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = sub i64 %t90, %t91
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = add i64 %t94, %t95
  %t100 = sub i64 %t98, 1
  %t101 = load i64, ptr %l10, !tbaa !24
  %t104 = sdiv i64 %t100, %t101
  store i64 %t104, ptr %l58, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb28
bb28:
  %t106 = load i64, ptr %l58, !tbaa !24
  store i64 %t106, ptr %l55, !tbaa !24
  br label %bb29
bb29:
  %t107 = load i64, ptr %l55, !tbaa !24
  store i64 %t107, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  %t108 = load i64, ptr %l12, !tbaa !24
  %t109 = load i64, ptr %l11, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t121 = mul i64 %t117, %t118
  %t124 = add i64 %t116, %t121
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/eval:Machine", ptr %t126, i32 0, i32 51
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  store { i64, ptr } %t129, ptr %l77, !tbaa !27
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/eval:Machine", ptr %t130, i32 0, i32 49
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = load i64, ptr %l6, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr %"compiler/eval:frame", ptr %t137, i64 %t134
  %t139 = getelementptr %"compiler/eval:frame", ptr %t138, i32 0, i32 5
  %t140 = load i64, ptr %t139, !tbaa !24
  %t144 = add i64 %t140, %t124
  %t148 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !27
  %t150 = getelementptr i64, ptr %t149, i64 %t144
  store i64 %a1, ptr %t150, !tbaa !34
  br label %bb34
bb34:
  %t151 = load i64, ptr %l12, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l12, !tbaa !24
  br label %bb30
bb35:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eruntimeFn(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/mir:Range" %a3, i32 %a4, %"compiler/eval:Ptr" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca { ptr, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca [3 x i64]
  %l21 = alloca [24 x i8]
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca %"std/prelude/text:StringBuilder"
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l54 = alloca i32
  %l57 = alloca %"compiler/mir:Fn"
  %l58 = alloca %"compiler/mir:Fn"
  %l62 = alloca i1
  %l65 = alloca i64
  %l67 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca { i64, [4 x i64] }
  %l72 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i64
  %l79 = alloca i64
  %l84 = alloca { i64, ptr }
  %l86 = alloca i64
  %l94 = alloca i64
  %l97 = alloca i64
  %l116 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca i64
  %l125 = alloca { i64, [4 x i64] }
  %l126 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l128 = alloca i64
  %l130 = alloca { i64, [4 x i64] }
  %l131 = alloca i64
  %l135 = alloca i1
  %l136 = alloca ptr
  %l137 = alloca i64
  %l139 = alloca { i64, [4 x i64] }
  %l140 = alloca i64
  %l143 = alloca ptr
  %l144 = alloca i64
  %l146 = alloca { i64, [4 x i64] }
  %l147 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca i64
  %l155 = alloca { i64, [4 x i64] }
  %l160 = alloca i1
  %l165 = alloca i1
  %l167 = alloca ptr
  %l168 = alloca i64
  %l170 = alloca { i64, [4 x i64] }
  %l171 = alloca { i64, ptr }
  %l175 = alloca i32
  %l180 = alloca i64
  %l183 = alloca i64
  %l207 = alloca i64
  %l213 = alloca ptr
  %l214 = alloca i64
  %l216 = alloca { i64, [4 x i64] }
  %l220 = alloca i1
  %l222 = alloca i1
  %l223 = alloca ptr
  %l224 = alloca i64
  %l226 = alloca { i64, [4 x i64] }
  %l227 = alloca i64
  %l230 = alloca ptr
  %l231 = alloca i64
  %l233 = alloca { i64, [4 x i64] }
  %l234 = alloca { i64, ptr }
  %l236 = alloca i1
  %l237 = alloca i64
  %l242 = alloca i64
  %l247 = alloca i64
  %l248 = alloca ptr
  %l249 = alloca i64
  %l251 = alloca { i64, [4 x i64] }
  %l256 = alloca i1
  %l257 = alloca ptr
  %l258 = alloca i64
  %l260 = alloca { i64, [4 x i64] }
  %l261 = alloca { i64, ptr }
  %l262 = alloca ptr
  %l263 = alloca i64
  %l265 = alloca { i64, [4 x i64] }
  %l266 = alloca i64
  %l267 = alloca ptr
  %l268 = alloca i64
  %l270 = alloca { i64, [4 x i64] }
  %l271 = alloca i64
  %l272 = alloca i32
  %l273 = alloca ptr
  %l274 = alloca i64
  %l276 = alloca { i64, [4 x i64] }
  %l277 = alloca i64
  %l278 = alloca i32
  %l279 = alloca ptr
  %l280 = alloca i64
  %l282 = alloca { i64, [4 x i64] }
  %l283 = alloca i64
  %l284 = alloca i32
  %l285 = alloca ptr
  %l286 = alloca i64
  %l288 = alloca { i64, [4 x i64] }
  %l289 = alloca { i64, ptr }
  %l290 = alloca i32
  %l293 = alloca i1
  %l294 = alloca ptr
  %l295 = alloca i64
  %l297 = alloca { i64, [4 x i64] }
  %l298 = alloca { i64, ptr }
  %l299 = alloca ptr
  %l300 = alloca i64
  %l302 = alloca { i64, [4 x i64] }
  %l303 = alloca { i64, ptr }
  %l304 = alloca ptr
  %l305 = alloca i64
  %l307 = alloca { i64, [4 x i64] }
  %l308 = alloca i64
  %l309 = alloca i32
  %l312 = alloca i1
  %l313 = alloca ptr
  %l314 = alloca i64
  %l316 = alloca { i64, [4 x i64] }
  %l317 = alloca { i64, ptr }
  %l319 = alloca i32
  %l321 = alloca ptr
  %l322 = alloca i64
  %l324 = alloca { i64, [4 x i64] }
  %l329 = alloca i1
  %l330 = alloca ptr
  %l331 = alloca i64
  %l333 = alloca { i64, [4 x i64] }
  %l334 = alloca { i64, ptr }
  %l337 = alloca i64
  %l346 = alloca i64
  %l349 = alloca i64
  %l378 = alloca i64
  %l383 = alloca ptr
  %l384 = alloca i64
  %l386 = alloca { i64, [4 x i64] }
  %l387 = alloca { i64, ptr }
  %l388 = alloca ptr
  %l389 = alloca i64
  %l391 = alloca { i64, [4 x i64] }
  %l392 = alloca { i64, ptr }
  %l393 = alloca { i64, ptr }
  %l394 = alloca ptr
  %l395 = alloca i64
  %l397 = alloca { i64, [4 x i64] }
  %l398 = alloca i64
  %l400 = alloca i64
  %l407 = alloca i64
  %l410 = alloca i64
  %l435 = alloca i64
  %l441 = alloca ptr
  %l442 = alloca i64
  %l444 = alloca { i64, [4 x i64] }
  %l449 = alloca i1
  %l450 = alloca ptr
  %l451 = alloca i64
  %l453 = alloca { i64, [4 x i64] }
  %l454 = alloca { i64, ptr }
  %l455 = alloca ptr
  %l456 = alloca i64
  %l458 = alloca { i64, [4 x i64] }
  %l459 = alloca { i64, ptr }
  %l460 = alloca ptr
  %l461 = alloca i64
  %l463 = alloca { i64, [4 x i64] }
  %l464 = alloca i64
  %l466 = alloca i32
  %l469 = alloca i1
  %l473 = alloca ptr
  %l474 = alloca i64
  %l476 = alloca { i64, [4 x i64] }
  %l477 = alloca { i64, ptr }
  %l478 = alloca ptr
  %l479 = alloca i64
  %l481 = alloca { i64, [4 x i64] }
  %l482 = alloca i64
  %l483 = alloca %"std/prelude/text:StringBuilder"
  %l488 = alloca i64
  %l491 = alloca i64
  %l518 = alloca { i64, ptr }
  %l526 = alloca i1
  %l528 = alloca i1
  %l530 = alloca i1
  %l532 = alloca i1
  %l534 = alloca i1
  %l536 = alloca ptr
  %l537 = alloca i32
  %l541 = alloca i32
  %l543 = alloca i1
  %l547 = alloca ptr
  %l548 = alloca %"compiler/eval:Ptr"
  %l551 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca i1
  %t3 = alloca %"compiler/mir:Fn", align 8
  %t9 = alloca { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2efnOfFrame(ptr %t3, ptr %v0, ptr %v0, ptr %t1, i64 %t2)
  call void @llvm.memmove.p0.p0.i64(ptr %l57, ptr %t3, i64 248, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l57, i64 248, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l58, ptr %l7, i64 248, i1 false)
  %t7 = getelementptr { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, ptr null, i32 1
  %t8 = ptrtoint ptr %t7 to i64
  %t10 = getelementptr { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, ptr %t9, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %l58, i64 248, i1 false)
  %t11 = getelementptr { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, ptr %t9, i32 0, i32 1
  store %"compiler/mir:Range" %a3, ptr %t11, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t13 = getelementptr { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, ptr %t9, i32 0, i32 2
  store ptr %v0, ptr %t13, !tbaa !28
  %t14 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_31, 0
  %t15 = insertvalue { ptr, ptr } %t14, ptr %t9, 1
  store { ptr, ptr } %t15, ptr %l8
  store i64 0, ptr %l9, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t17, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d32, i32 0, i32 1) })
  store i1 %t19, ptr %l62
  br label %bb2
bb2:
  %t20 = load i1, ptr %l62, !tbaa !21
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/eval:Machine", ptr %t21, i32 0, i32 74
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l65
  br label %bb6
bb6:
  %t26 = load i64, ptr %l65, !tbaa !24
  store i64 %t26, ptr %l9, !tbaa !24
  br label %bb234
bb7:
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t29, ptr %l67
  br label %bb8
bb8:
  %t30 = load i1, ptr %l67, !tbaa !21
  br i1 %t30, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb40
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l68, !tbaa !29
  %t32 = load i64, ptr %l1, !tbaa !24
  store i64 %t32, ptr %l69, !tbaa !24
  %t33 = load { ptr, ptr }, ptr %l8
  %t35 = extractvalue { ptr, ptr } %t33, 0
  %t36 = extractvalue { ptr, ptr } %t33, 1
  %t37 = call { i64, [4 x i64] } %t35(ptr %t36, i64 0)
  store { i64, [4 x i64] } %t37, ptr %l71
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l68, !tbaa !29
  %t39 = load i64, ptr %l69, !tbaa !24
  %t40 = load { i64, [4 x i64] }, ptr %l71
  %t41 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t38, i64 %t39, { i64, [4 x i64] } %t40)
  store i64 %t41, ptr %l72
  br label %bb13
bb13:
  %t42 = load i64, ptr %l72, !tbaa !24
  store i64 %t42, ptr %l10, !tbaa !24
  %t43 = load i64, ptr %l10, !tbaa !24
  %t45 = icmp slt i64 %t43, 0
  br i1 %t45, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l75, !tbaa !21
  br label %bb17
bb15:
  %t47 = load i64, ptr %l10, !tbaa !24
  store i64 %t47, ptr %l76, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 74
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l79
  br label %bb16
bb16:
  %t53 = load i64, ptr %l76, !tbaa !24
  %t54 = load i64, ptr %l79, !tbaa !24
  %t55 = icmp sge i64 %t53, %t54
  store i1 %t55, ptr %l75, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l75, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb39
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/eval:Machine", ptr %t58, i32 0, i32 74
  %t61 = load i64, ptr %l10, !tbaa !24
  %t64 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t60, i64 %t61)
  store { i64, ptr } %t64, ptr %l84
  br label %bb20
bb20:
  %t65 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t65, ptr %l11, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l86, !tbaa !24
  %t69 = load i64, ptr %l86, !tbaa !24
  %t70 = icmp sge i64 %t69, 0
  br i1 %t70, label %bb21, label %bb22
bb21:
  %t72 = load i64, ptr %l86, !tbaa !24
  %t73 = mul i64 %t72, 1
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 0
  store i64 %t80, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t82 = load i64, ptr %l14, !tbaa !24
  %t83 = load i64, ptr %l13, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_7289625dc306da68_1bb592dfdbe27504)
  unreachable
bb23:
  %t88 = load i64, ptr %l15, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l94, !tbaa !24
  br label %bb28
bb25:
  %t92 = load i64, ptr %l14, !tbaa !24
  %t93 = load i64, ptr %l13, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l15, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l15, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l97, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb27
bb27:
  %t108 = load i64, ptr %l97, !tbaa !24
  store i64 %t108, ptr %l94, !tbaa !24
  br label %bb28
bb28:
  %t109 = load i64, ptr %l94, !tbaa !24
  store i64 %t109, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb29
bb29:
  %t110 = load i64, ptr %l17, !tbaa !24
  %t111 = load i64, ptr %l16, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l17, !tbaa !24
  %t120 = load i64, ptr %l15, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  store i64 %t126, ptr %l18, !tbaa !24
  %t128 = load i64, ptr %l18, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t129, ptr %l116, !tbaa !27
  %t130 = load i64, ptr %l18, !tbaa !24
  %t132 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !27
  %t134 = getelementptr i8, ptr %t133, i64 %t130
  %t135 = load i8, ptr %t134, !tbaa !32
  %t139 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i8, ptr %t140, i64 %t128
  store i8 %t135, ptr %t141, !tbaa !32
  br label %bb33
bb33:
  %t142 = load i64, ptr %l17, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l17, !tbaa !24
  br label %bb29
bb34:
  %t146 = load ptr, ptr %l0, !tbaa !29
  store ptr %t146, ptr %l122, !tbaa !29
  %t147 = load i64, ptr %l1, !tbaa !24
  store i64 %t147, ptr %l123, !tbaa !24
  %t148 = load { ptr, ptr }, ptr %l8
  %t150 = extractvalue { ptr, ptr } %t148, 0
  %t151 = extractvalue { ptr, ptr } %t148, 1
  %t152 = call { i64, [4 x i64] } %t150(ptr %t151, i64 1)
  store { i64, [4 x i64] } %t152, ptr %l125
  br label %bb35
bb35:
  %t153 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t153, ptr %l126, !tbaa !27
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l127, !tbaa !29
  %t155 = load i64, ptr %l1, !tbaa !24
  store i64 %t155, ptr %l128, !tbaa !24
  %t156 = load { ptr, ptr }, ptr %l8
  %t158 = extractvalue { ptr, ptr } %t156, 0
  %t159 = extractvalue { ptr, ptr } %t156, 1
  %t160 = call { i64, [4 x i64] } %t158(ptr %t159, i64 2)
  store { i64, [4 x i64] } %t160, ptr %l130
  br label %bb36
bb36:
  %t161 = load ptr, ptr %l127, !tbaa !29
  %t162 = load i64, ptr %l128, !tbaa !24
  %t163 = load { i64, [4 x i64] }, ptr %l130
  %t164 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t161, i64 %t162, { i64, [4 x i64] } %t163)
  store i64 %t164, ptr %l131
  br label %bb37
bb37:
  %t165 = load ptr, ptr %l122, !tbaa !29
  %t166 = load i64, ptr %l123, !tbaa !24
  %t167 = load { i64, [4 x i64] }, ptr %l125
  %t168 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t169 = load i64, ptr %l131, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s4, ptr %t165, i64 %t166, { i64, [4 x i64] } %t167, { i64, ptr } %t168, i64 %t169)
  br label %bb38
bb38:
  %t170 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  store i64 %t172, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb39:
  br label %bb234
bb40:
  %t174 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t176 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t174, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t176, ptr %l135
  br label %bb41
bb41:
  %t177 = load i1, ptr %l135, !tbaa !21
  br i1 %t177, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb54
bb44:
  store %olang.scope zeroinitializer, ptr %s8
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l136, !tbaa !29
  %t179 = load i64, ptr %l1, !tbaa !24
  store i64 %t179, ptr %l137, !tbaa !24
  %t180 = load { ptr, ptr }, ptr %l8
  %t182 = extractvalue { ptr, ptr } %t180, 0
  %t183 = extractvalue { ptr, ptr } %t180, 1
  %t184 = call { i64, [4 x i64] } %t182(ptr %t183, i64 2)
  store { i64, [4 x i64] } %t184, ptr %l139
  br label %bb45
bb45:
  %t185 = load ptr, ptr %l136, !tbaa !29
  %t186 = load i64, ptr %l137, !tbaa !24
  %t187 = load { i64, [4 x i64] }, ptr %l139
  %t188 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t185, i64 %t186, { i64, [4 x i64] } %t187)
  store i64 %t188, ptr %l140
  br label %bb46
bb46:
  %t189 = load i64, ptr %l140, !tbaa !24
  %t190 = icmp sge i64 %t189, 0
  br i1 %t190, label %bb47, label %bb48
bb47:
  %t192 = load i64, ptr %l140, !tbaa !24
  %t193 = mul i64 %t192, 1
  %t194 = call ptr @__olang_scope_alloc_zeroed(ptr %s8, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  store { i64, ptr } %t196, ptr %l19, !tbaa !27
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l143, !tbaa !29
  %t199 = load i64, ptr %l1, !tbaa !24
  store i64 %t199, ptr %l144, !tbaa !24
  %t200 = load { ptr, ptr }, ptr %l8
  %t202 = extractvalue { ptr, ptr } %t200, 0
  %t203 = extractvalue { ptr, ptr } %t200, 1
  %t204 = call { i64, [4 x i64] } %t202(ptr %t203, i64 0)
  store { i64, [4 x i64] } %t204, ptr %l146
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_d526727003b18a55_2e4fcca09321f611)
  unreachable
bb49:
  %t205 = load ptr, ptr %l143, !tbaa !29
  %t206 = load i64, ptr %l144, !tbaa !24
  %t207 = load { i64, [4 x i64] }, ptr %l146
  %t208 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s8, ptr %t205, i64 %t206, { i64, [4 x i64] } %t207)
  store { i64, ptr } %t208, ptr %l147
  br label %bb50
bb50:
  %t209 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t217 = extractvalue { i64, ptr } %t209, 1
  %t218 = extractvalue { i64, ptr } %t209, 0
  %t220 = call i64 @__olang_env(ptr %t214, ptr %t217, i64 %t212)
  store i64 %t220, ptr %l151
  br label %bb51
bb51:
  %t221 = load i64, ptr %l151, !tbaa !24
  store i64 %t221, ptr %l9, !tbaa !24
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l152, !tbaa !29
  %t223 = load i64, ptr %l1, !tbaa !24
  store i64 %t223, ptr %l153, !tbaa !24
  %t224 = load { ptr, ptr }, ptr %l8
  %t226 = extractvalue { ptr, ptr } %t224, 0
  %t227 = extractvalue { ptr, ptr } %t224, 1
  %t228 = call { i64, [4 x i64] } %t226(ptr %t227, i64 1)
  store { i64, [4 x i64] } %t228, ptr %l155
  br label %bb52
bb52:
  %t229 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t230 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t233 = load ptr, ptr %l152, !tbaa !29
  %t234 = load i64, ptr %l153, !tbaa !24
  %t235 = load { i64, [4 x i64] }, ptr %l155
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s8, ptr %t233, i64 %t234, { i64, [4 x i64] } %t235, { i64, ptr } %t229, i64 %t232)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s8)
  br label %bb234
bb54:
  %t238 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t240 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t238, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t240, ptr %l160
  br label %bb55
bb55:
  %t241 = load i1, ptr %l160, !tbaa !21
  br i1 %t241, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  br label %bb59
bb58:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/eval:Machine", ptr %t242, i32 0, i32 81
  %t245 = load i32, ptr %t244, !tbaa !23
  %t247 = sext i32 %t245 to i64
  store i64 %t247, ptr %l9, !tbaa !24
  br label %bb234
bb59:
  %t249 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t251 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t249, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t251, ptr %l165
  br label %bb60
bb60:
  %t252 = load i1, ptr %l165, !tbaa !21
  br i1 %t252, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb81
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t253 = insertvalue [3 x i64] undef, i64 0, 0
  %t254 = insertvalue [3 x i64] %t253, i64 0, 1
  %t255 = insertvalue [3 x i64] %t254, i64 0, 2
  store [3 x i64] %t255, ptr %l20
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l167, !tbaa !29
  %t258 = load i64, ptr %l1, !tbaa !24
  store i64 %t258, ptr %l168, !tbaa !24
  %t259 = load { ptr, ptr }, ptr %l8
  %t261 = extractvalue { ptr, ptr } %t259, 0
  %t262 = extractvalue { ptr, ptr } %t259, 1
  %t263 = call { i64, [4 x i64] } %t261(ptr %t262, i64 0)
  store { i64, [4 x i64] } %t263, ptr %l170
  br label %bb64
bb64:
  %t264 = load ptr, ptr %l167, !tbaa !29
  %t265 = load i64, ptr %l168, !tbaa !24
  %t266 = load { i64, [4 x i64] }, ptr %l170
  %t267 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s10, ptr %t264, i64 %t265, { i64, [4 x i64] } %t266)
  store { i64, ptr } %t267, ptr %l171
  br label %bb65
bb65:
  %t269 = insertvalue { i64, ptr } undef, i64 3, 0
  %t270 = insertvalue { i64, ptr } %t269, ptr %l20, 1
  %t272 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = extractvalue { i64, ptr } %t272, 0
  %t276 = extractvalue { i64, ptr } %t270, 1
  %t277 = extractvalue { i64, ptr } %t270, 0
  %t278 = call i32 @__olang_stat(ptr %t273, ptr %t276)
  store i32 %t278, ptr %l175
  br label %bb66
bb66:
  %t279 = load i32, ptr %l175, !tbaa !23
  %t280 = sext i32 %t279 to i64
  store i64 %t280, ptr %l9, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  store i64 24, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t282 = load i64, ptr %l23, !tbaa !24
  %t283 = load i64, ptr %l22, !tbaa !24
  %t286 = icmp sgt i64 %t282, %t283
  br i1 %t286, label %bb67, label %bb68
bb67:
  %t288 = load i64, ptr %l24, !tbaa !24
  %t290 = icmp sgt i64 %t288, 0
  br i1 %t290, label %bb69, label %bb70
bb68:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb72
bb69:
  %t292 = load i64, ptr %l23, !tbaa !24
  %t293 = load i64, ptr %l22, !tbaa !24
  %t296 = sub i64 %t292, %t293
  %t297 = load i64, ptr %l24, !tbaa !24
  %t300 = add i64 %t296, %t297
  %t302 = sub i64 %t300, 1
  %t303 = load i64, ptr %l24, !tbaa !24
  %t306 = sdiv i64 %t302, %t303
  store i64 %t306, ptr %l183, !tbaa !24
  br label %bb71
bb70:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb71
bb71:
  %t308 = load i64, ptr %l183, !tbaa !24
  store i64 %t308, ptr %l180, !tbaa !24
  br label %bb72
bb72:
  %t309 = load i64, ptr %l180, !tbaa !24
  store i64 %t309, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb73
bb73:
  %t310 = load i64, ptr %l26, !tbaa !24
  %t311 = load i64, ptr %l25, !tbaa !24
  %t314 = icmp slt i64 %t310, %t311
  %t316 = xor i1 %t314, true
  br i1 %t316, label %bb74, label %bb75
bb74:
  br label %bb78
bb75:
  br label %bb76
bb76:
  %t318 = load i64, ptr %l22, !tbaa !24
  %t319 = load i64, ptr %l26, !tbaa !24
  %t320 = load i64, ptr %l24, !tbaa !24
  %t323 = mul i64 %t319, %t320
  %t326 = add i64 %t318, %t323
  store i64 %t326, ptr %l27, !tbaa !24
  %t328 = load i64, ptr %l27, !tbaa !24
  %t329 = load i64, ptr %l27, !tbaa !24
  %t331 = sdiv i64 %t329, 8
  %t333 = getelementptr [3 x i64], ptr %l20, i64 0, i64 %t331
  %t334 = load i64, ptr %t333, !tbaa !34
  %t335 = load i64, ptr %l27, !tbaa !24
  %t337 = srem i64 %t335, 8
  %t339 = mul i64 8, %t337
  store i64 %t339, ptr %l207, !tbaa !24
  %t341 = load i64, ptr %l207, !tbaa !24
  %t342 = load i64, ptr %l207, !tbaa !24
  %t343 = ashr i64 %t334, %t342
  %t345 = and i64 %t343, 255
  %t347 = trunc i64 %t345 to i8
  %t350 = getelementptr [24 x i8], ptr %l21, i64 0, i64 %t328
  store i8 %t347, ptr %t350, !tbaa !32
  br label %bb77
bb77:
  %t351 = load i64, ptr %l26, !tbaa !24
  %t353 = add i64 %t351, 1
  store i64 %t353, ptr %l26, !tbaa !24
  br label %bb73
bb78:
  %t355 = load ptr, ptr %l0, !tbaa !29
  store ptr %t355, ptr %l213, !tbaa !29
  %t356 = load i64, ptr %l1, !tbaa !24
  store i64 %t356, ptr %l214, !tbaa !24
  %t357 = load { ptr, ptr }, ptr %l8
  %t359 = extractvalue { ptr, ptr } %t357, 0
  %t360 = extractvalue { ptr, ptr } %t357, 1
  %t361 = call { i64, [4 x i64] } %t359(ptr %t360, i64 1)
  store { i64, [4 x i64] } %t361, ptr %l216
  br label %bb79
bb79:
  %t363 = insertvalue { i64, ptr } undef, i64 24, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %l21, 1
  %t365 = load ptr, ptr %l213, !tbaa !29
  %t366 = load i64, ptr %l214, !tbaa !24
  %t367 = load { i64, [4 x i64] }, ptr %l216
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s10, ptr %t365, i64 %t366, { i64, [4 x i64] } %t367, { i64, ptr } %t364, i64 24)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s10)
  br label %bb234
bb81:
  %t369 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t371 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t369, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t371, ptr %l220
  br label %bb82
bb82:
  %t372 = load i1, ptr %l220, !tbaa !21
  br i1 %t372, label %bb83, label %bb84
bb83:
  br label %bb88
bb84:
  %t373 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t375 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t373, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t375, ptr %l222
  br label %bb85
bb85:
  %t376 = load i1, ptr %l222, !tbaa !21
  br i1 %t376, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  br label %bb103
bb88:
  store %olang.scope zeroinitializer, ptr %s14
  %t377 = load ptr, ptr %l0, !tbaa !29
  store ptr %t377, ptr %l223, !tbaa !29
  %t378 = load i64, ptr %l1, !tbaa !24
  store i64 %t378, ptr %l224, !tbaa !24
  %t379 = load { ptr, ptr }, ptr %l8
  %t381 = extractvalue { ptr, ptr } %t379, 0
  %t382 = extractvalue { ptr, ptr } %t379, 1
  %t383 = call { i64, [4 x i64] } %t381(ptr %t382, i64 2)
  store { i64, [4 x i64] } %t383, ptr %l226
  br label %bb89
bb89:
  %t384 = load ptr, ptr %l223, !tbaa !29
  %t385 = load i64, ptr %l224, !tbaa !24
  %t386 = load { i64, [4 x i64] }, ptr %l226
  %t387 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t384, i64 %t385, { i64, [4 x i64] } %t386)
  store i64 %t387, ptr %l227
  br label %bb90
bb90:
  %t388 = load i64, ptr %l227, !tbaa !24
  %t389 = icmp sge i64 %t388, 0
  br i1 %t389, label %bb91, label %bb92
bb91:
  %t391 = load i64, ptr %l227, !tbaa !24
  %t392 = mul i64 %t391, 1
  %t393 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t392)
  %t394 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  store { i64, ptr } %t395, ptr %l28, !tbaa !27
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l230, !tbaa !29
  %t398 = load i64, ptr %l1, !tbaa !24
  store i64 %t398, ptr %l231, !tbaa !24
  %t399 = load { ptr, ptr }, ptr %l8
  %t401 = extractvalue { ptr, ptr } %t399, 0
  %t402 = extractvalue { ptr, ptr } %t399, 1
  %t403 = call { i64, [4 x i64] } %t401(ptr %t402, i64 0)
  store { i64, [4 x i64] } %t403, ptr %l233
  br label %bb93
bb92:
  call void @__olang_check_failed(ptr @olang_loc_1269d295d9d04536_be9a6b7fb42413f2)
  unreachable
bb93:
  %t404 = load ptr, ptr %l230, !tbaa !29
  %t405 = load i64, ptr %l231, !tbaa !24
  %t406 = load { i64, [4 x i64] }, ptr %l233
  %t407 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s14, ptr %t404, i64 %t405, { i64, [4 x i64] } %t406)
  store { i64, ptr } %t407, ptr %l234
  br label %bb94
bb94:
  %t408 = load { i64, ptr }, ptr %l234, !tbaa !27
  store { i64, ptr } %t408, ptr %l29, !tbaa !27
  %t409 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t411 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s14, { i64, ptr } %t409, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t411, ptr %l236
  br label %bb95
bb95:
  %t412 = load i1, ptr %l236, !tbaa !21
  br i1 %t412, label %bb96, label %bb97
bb96:
  %t413 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t419 = extractvalue { i64, ptr } %t413, 1
  %t420 = extractvalue { i64, ptr } %t413, 0
  %t422 = extractvalue { i64, ptr } %t414, 1
  %t423 = extractvalue { i64, ptr } %t414, 0
  %t425 = call i64 @__olang_dir(ptr %t419, ptr %t422, i64 %t417)
  store i64 %t425, ptr %l242
  br label %bb98
bb97:
  %t426 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t427 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t430 = extractvalue { i64, ptr } %t428, 0
  %t432 = extractvalue { i64, ptr } %t426, 1
  %t433 = extractvalue { i64, ptr } %t426, 0
  %t435 = extractvalue { i64, ptr } %t427, 1
  %t436 = extractvalue { i64, ptr } %t427, 0
  %t438 = call i64 @__olang_realpath(ptr %t432, ptr %t435, i64 %t430)
  store i64 %t438, ptr %l247
  br label %bb99
bb98:
  %t439 = load i64, ptr %l242, !tbaa !24
  store i64 %t439, ptr %l237, !tbaa !24
  br label %bb100
bb99:
  %t440 = load i64, ptr %l247, !tbaa !24
  store i64 %t440, ptr %l237, !tbaa !24
  br label %bb100
bb100:
  %t441 = load i64, ptr %l237, !tbaa !24
  store i64 %t441, ptr %l9, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l248, !tbaa !29
  %t443 = load i64, ptr %l1, !tbaa !24
  store i64 %t443, ptr %l249, !tbaa !24
  %t444 = load { ptr, ptr }, ptr %l8
  %t446 = extractvalue { ptr, ptr } %t444, 0
  %t447 = extractvalue { ptr, ptr } %t444, 1
  %t448 = call { i64, [4 x i64] } %t446(ptr %t447, i64 1)
  store { i64, [4 x i64] } %t448, ptr %l251
  br label %bb101
bb101:
  %t449 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t450 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t452 = extractvalue { i64, ptr } %t450, 0
  %t453 = load ptr, ptr %l248, !tbaa !29
  %t454 = load i64, ptr %l249, !tbaa !24
  %t455 = load { i64, [4 x i64] }, ptr %l251
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s14, ptr %t453, i64 %t454, { i64, [4 x i64] } %t455, { i64, ptr } %t449, i64 %t452)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s14)
  br label %bb234
bb103:
  %t458 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t460 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t458, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t460, ptr %l256
  br label %bb104
bb104:
  %t461 = load i1, ptr %l256, !tbaa !21
  br i1 %t461, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  br label %bb121
bb107:
  store %olang.scope zeroinitializer, ptr %s15
  %t462 = load ptr, ptr %l0, !tbaa !29
  store ptr %t462, ptr %l257, !tbaa !29
  %t463 = load i64, ptr %l1, !tbaa !24
  store i64 %t463, ptr %l258, !tbaa !24
  %t464 = load { ptr, ptr }, ptr %l8
  %t466 = extractvalue { ptr, ptr } %t464, 0
  %t467 = extractvalue { ptr, ptr } %t464, 1
  %t468 = call { i64, [4 x i64] } %t466(ptr %t467, i64 0)
  store { i64, [4 x i64] } %t468, ptr %l260
  br label %bb108
bb108:
  %t469 = load ptr, ptr %l257, !tbaa !29
  %t470 = load i64, ptr %l258, !tbaa !24
  %t471 = load { i64, [4 x i64] }, ptr %l260
  %t472 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s15, ptr %t469, i64 %t470, { i64, [4 x i64] } %t471)
  store { i64, ptr } %t472, ptr %l261
  br label %bb109
bb109:
  %t473 = load ptr, ptr %l0, !tbaa !29
  store ptr %t473, ptr %l262, !tbaa !29
  %t474 = load i64, ptr %l1, !tbaa !24
  store i64 %t474, ptr %l263, !tbaa !24
  %t475 = load { ptr, ptr }, ptr %l8
  %t477 = extractvalue { ptr, ptr } %t475, 0
  %t478 = extractvalue { ptr, ptr } %t475, 1
  %t479 = call { i64, [4 x i64] } %t477(ptr %t478, i64 1)
  store { i64, [4 x i64] } %t479, ptr %l265
  br label %bb110
bb110:
  %t480 = load ptr, ptr %l262, !tbaa !29
  %t481 = load i64, ptr %l263, !tbaa !24
  %t482 = load { i64, [4 x i64] }, ptr %l265
  %t483 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t480, i64 %t481, { i64, [4 x i64] } %t482)
  store i64 %t483, ptr %l266
  br label %bb111
bb111:
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l267, !tbaa !29
  %t485 = load i64, ptr %l1, !tbaa !24
  store i64 %t485, ptr %l268, !tbaa !24
  %t486 = load { ptr, ptr }, ptr %l8
  %t488 = extractvalue { ptr, ptr } %t486, 0
  %t489 = extractvalue { ptr, ptr } %t486, 1
  %t490 = call { i64, [4 x i64] } %t488(ptr %t489, i64 2)
  store { i64, [4 x i64] } %t490, ptr %l270
  br label %bb112
bb112:
  %t491 = load ptr, ptr %l267, !tbaa !29
  %t492 = load i64, ptr %l268, !tbaa !24
  %t493 = load { i64, [4 x i64] }, ptr %l270
  %t494 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t491, i64 %t492, { i64, [4 x i64] } %t493)
  store i64 %t494, ptr %l271
  br label %bb113
bb113:
  %t495 = load i64, ptr %l271, !tbaa !24
  %t496 = trunc i64 %t495 to i32
  store i32 %t496, ptr %l272, !tbaa !23
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l273, !tbaa !29
  %t498 = load i64, ptr %l1, !tbaa !24
  store i64 %t498, ptr %l274, !tbaa !24
  %t499 = load { ptr, ptr }, ptr %l8
  %t501 = extractvalue { ptr, ptr } %t499, 0
  %t502 = extractvalue { ptr, ptr } %t499, 1
  %t503 = call { i64, [4 x i64] } %t501(ptr %t502, i64 3)
  store { i64, [4 x i64] } %t503, ptr %l276
  br label %bb114
bb114:
  %t504 = load ptr, ptr %l273, !tbaa !29
  %t505 = load i64, ptr %l274, !tbaa !24
  %t506 = load { i64, [4 x i64] }, ptr %l276
  %t507 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t504, i64 %t505, { i64, [4 x i64] } %t506)
  store i64 %t507, ptr %l277
  br label %bb115
bb115:
  %t508 = load i64, ptr %l277, !tbaa !24
  %t509 = trunc i64 %t508 to i32
  store i32 %t509, ptr %l278, !tbaa !23
  %t510 = load ptr, ptr %l0, !tbaa !29
  store ptr %t510, ptr %l279, !tbaa !29
  %t511 = load i64, ptr %l1, !tbaa !24
  store i64 %t511, ptr %l280, !tbaa !24
  %t512 = load { ptr, ptr }, ptr %l8
  %t514 = extractvalue { ptr, ptr } %t512, 0
  %t515 = extractvalue { ptr, ptr } %t512, 1
  %t516 = call { i64, [4 x i64] } %t514(ptr %t515, i64 4)
  store { i64, [4 x i64] } %t516, ptr %l282
  br label %bb116
bb116:
  %t517 = load ptr, ptr %l279, !tbaa !29
  %t518 = load i64, ptr %l280, !tbaa !24
  %t519 = load { i64, [4 x i64] }, ptr %l282
  %t520 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t517, i64 %t518, { i64, [4 x i64] } %t519)
  store i64 %t520, ptr %l283
  br label %bb117
bb117:
  %t521 = load i64, ptr %l283, !tbaa !24
  %t522 = trunc i64 %t521 to i32
  store i32 %t522, ptr %l284, !tbaa !23
  %t523 = load ptr, ptr %l0, !tbaa !29
  store ptr %t523, ptr %l285, !tbaa !29
  %t524 = load i64, ptr %l1, !tbaa !24
  store i64 %t524, ptr %l286, !tbaa !24
  %t525 = load { ptr, ptr }, ptr %l8
  %t527 = extractvalue { ptr, ptr } %t525, 0
  %t528 = extractvalue { ptr, ptr } %t525, 1
  %t529 = call { i64, [4 x i64] } %t527(ptr %t528, i64 5)
  store { i64, [4 x i64] } %t529, ptr %l288
  br label %bb118
bb118:
  %t530 = load ptr, ptr %l285, !tbaa !29
  %t531 = load i64, ptr %l286, !tbaa !24
  %t532 = load { i64, [4 x i64] }, ptr %l288
  %t533 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s15, ptr %t530, i64 %t531, { i64, [4 x i64] } %t532)
  store { i64, ptr } %t533, ptr %l289
  br label %bb119
bb119:
  %t534 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 1
  %t536 = extractvalue { i64, ptr } %t534, 0
  %t537 = load i64, ptr %l266, !tbaa !24
  %t538 = load i32, ptr %l272, !tbaa !23
  %t539 = load i32, ptr %l278, !tbaa !23
  %t540 = load i32, ptr %l284, !tbaa !23
  %t541 = load { i64, ptr }, ptr %l289, !tbaa !27
  %t542 = extractvalue { i64, ptr } %t541, 1
  %t543 = extractvalue { i64, ptr } %t541, 0
  %t544 = call i32 @__olang_spawn(ptr %t535, i64 %t537, i32 %t538, i32 %t539, i32 %t540, ptr %t542)
  store i32 %t544, ptr %l290
  br label %bb120
bb120:
  %t545 = load i32, ptr %l290, !tbaa !23
  %t546 = sext i32 %t545 to i64
  store i64 %t546, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb234
bb121:
  %t548 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t550 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t548, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t550, ptr %l293
  br label %bb122
bb122:
  %t551 = load i1, ptr %l293, !tbaa !21
  br i1 %t551, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb133
bb125:
  store %olang.scope zeroinitializer, ptr %s16
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l294, !tbaa !29
  %t553 = load i64, ptr %l1, !tbaa !24
  store i64 %t553, ptr %l295, !tbaa !24
  %t554 = load { ptr, ptr }, ptr %l8
  %t556 = extractvalue { ptr, ptr } %t554, 0
  %t557 = extractvalue { ptr, ptr } %t554, 1
  %t558 = call { i64, [4 x i64] } %t556(ptr %t557, i64 0)
  store { i64, [4 x i64] } %t558, ptr %l297
  br label %bb126
bb126:
  %t559 = load ptr, ptr %l294, !tbaa !29
  %t560 = load i64, ptr %l295, !tbaa !24
  %t561 = load { i64, [4 x i64] }, ptr %l297
  %t562 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s16, ptr %t559, i64 %t560, { i64, [4 x i64] } %t561)
  store { i64, ptr } %t562, ptr %l298
  br label %bb127
bb127:
  %t563 = load ptr, ptr %l0, !tbaa !29
  store ptr %t563, ptr %l299, !tbaa !29
  %t564 = load i64, ptr %l1, !tbaa !24
  store i64 %t564, ptr %l300, !tbaa !24
  %t565 = load { ptr, ptr }, ptr %l8
  %t567 = extractvalue { ptr, ptr } %t565, 0
  %t568 = extractvalue { ptr, ptr } %t565, 1
  %t569 = call { i64, [4 x i64] } %t567(ptr %t568, i64 1)
  store { i64, [4 x i64] } %t569, ptr %l302
  br label %bb128
bb128:
  %t570 = load ptr, ptr %l299, !tbaa !29
  %t571 = load i64, ptr %l300, !tbaa !24
  %t572 = load { i64, [4 x i64] }, ptr %l302
  %t573 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s16, ptr %t570, i64 %t571, { i64, [4 x i64] } %t572)
  store { i64, ptr } %t573, ptr %l303
  br label %bb129
bb129:
  %t574 = load ptr, ptr %l0, !tbaa !29
  store ptr %t574, ptr %l304, !tbaa !29
  %t575 = load i64, ptr %l1, !tbaa !24
  store i64 %t575, ptr %l305, !tbaa !24
  %t576 = load { ptr, ptr }, ptr %l8
  %t578 = extractvalue { ptr, ptr } %t576, 0
  %t579 = extractvalue { ptr, ptr } %t576, 1
  %t580 = call { i64, [4 x i64] } %t578(ptr %t579, i64 2)
  store { i64, [4 x i64] } %t580, ptr %l307
  br label %bb130
bb130:
  %t581 = load ptr, ptr %l304, !tbaa !29
  %t582 = load i64, ptr %l305, !tbaa !24
  %t583 = load { i64, [4 x i64] }, ptr %l307
  %t584 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t581, i64 %t582, { i64, [4 x i64] } %t583)
  store i64 %t584, ptr %l308
  br label %bb131
bb131:
  %t585 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t585, 1
  %t587 = extractvalue { i64, ptr } %t585, 0
  %t588 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t589 = extractvalue { i64, ptr } %t588, 1
  %t590 = extractvalue { i64, ptr } %t588, 0
  %t591 = load i64, ptr %l308, !tbaa !24
  %t592 = call i32 @__olang_exec(ptr %t586, ptr %t589, i64 %t591)
  store i32 %t592, ptr %l309
  br label %bb132
bb132:
  %t593 = load i32, ptr %l309, !tbaa !23
  %t594 = sext i32 %t593 to i64
  store i64 %t594, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb234
bb133:
  %t596 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t598 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t596, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t598, ptr %l312
  br label %bb134
bb134:
  %t599 = load i1, ptr %l312, !tbaa !21
  br i1 %t599, label %bb135, label %bb136
bb135:
  br label %bb137
bb136:
  br label %bb143
bb137:
  store %olang.scope zeroinitializer, ptr %s17
  %t600 = load ptr, ptr %l0, !tbaa !29
  store ptr %t600, ptr %l313, !tbaa !29
  %t601 = load i64, ptr %l1, !tbaa !24
  store i64 %t601, ptr %l314, !tbaa !24
  %t602 = load { ptr, ptr }, ptr %l8
  %t604 = extractvalue { ptr, ptr } %t602, 0
  %t605 = extractvalue { ptr, ptr } %t602, 1
  %t606 = call { i64, [4 x i64] } %t604(ptr %t605, i64 0)
  store { i64, [4 x i64] } %t606, ptr %l316
  br label %bb138
bb138:
  %t607 = load ptr, ptr %l313, !tbaa !29
  %t608 = load i64, ptr %l314, !tbaa !24
  %t609 = load { i64, [4 x i64] }, ptr %l316
  %t610 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s17, ptr %t607, i64 %t608, { i64, [4 x i64] } %t609)
  store { i64, ptr } %t610, ptr %l317
  br label %bb139
bb139:
  %t611 = load { i64, ptr }, ptr %l317, !tbaa !27
  store { i64, ptr } %t611, ptr %l30, !tbaa !27
  %t612 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t612, 1
  %t615 = extractvalue { i64, ptr } %t612, 0
  %t616 = call i32 @__olang_mkdtemp(ptr %t614)
  store i32 %t616, ptr %l319
  br label %bb140
bb140:
  %t617 = load i32, ptr %l319, !tbaa !23
  %t618 = sext i32 %t617 to i64
  store i64 %t618, ptr %l9, !tbaa !24
  %t620 = load ptr, ptr %l0, !tbaa !29
  store ptr %t620, ptr %l321, !tbaa !29
  %t621 = load i64, ptr %l1, !tbaa !24
  store i64 %t621, ptr %l322, !tbaa !24
  %t622 = load { ptr, ptr }, ptr %l8
  %t624 = extractvalue { ptr, ptr } %t622, 0
  %t625 = extractvalue { ptr, ptr } %t622, 1
  %t626 = call { i64, [4 x i64] } %t624(ptr %t625, i64 0)
  store { i64, [4 x i64] } %t626, ptr %l324
  br label %bb141
bb141:
  %t627 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t628 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t630 = extractvalue { i64, ptr } %t628, 0
  %t631 = load ptr, ptr %l321, !tbaa !29
  %t632 = load i64, ptr %l322, !tbaa !24
  %t633 = load { i64, [4 x i64] }, ptr %l324
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s17, ptr %t631, i64 %t632, { i64, [4 x i64] } %t633, { i64, ptr } %t627, i64 %t630)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s17)
  br label %bb234
bb143:
  %t636 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t638 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t636, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t638, ptr %l329
  br label %bb144
bb144:
  %t639 = load i1, ptr %l329, !tbaa !21
  br i1 %t639, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb187
bb147:
  store %olang.scope zeroinitializer, ptr %s18
  %t640 = load ptr, ptr %l0, !tbaa !29
  store ptr %t640, ptr %l330, !tbaa !29
  %t641 = load i64, ptr %l1, !tbaa !24
  store i64 %t641, ptr %l331, !tbaa !24
  %t642 = load { ptr, ptr }, ptr %l8
  %t644 = extractvalue { ptr, ptr } %t642, 0
  %t645 = extractvalue { ptr, ptr } %t642, 1
  %t646 = call { i64, [4 x i64] } %t644(ptr %t645, i64 2)
  store { i64, [4 x i64] } %t646, ptr %l333
  br label %bb148
bb148:
  %t647 = load ptr, ptr %l330, !tbaa !29
  %t648 = load i64, ptr %l331, !tbaa !24
  %t649 = load { i64, [4 x i64] }, ptr %l333
  %t650 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s18, ptr %t647, i64 %t648, { i64, [4 x i64] } %t649)
  store { i64, ptr } %t650, ptr %l334
  br label %bb149
bb149:
  %t651 = load { i64, ptr }, ptr %l334, !tbaa !27
  store { i64, ptr } %t651, ptr %l31, !tbaa !27
  %t652 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t654 = extractvalue { i64, ptr } %t652, 0
  %t656 = sdiv i64 %t654, 8
  store i64 %t656, ptr %l337, !tbaa !24
  %t657 = load i64, ptr %l337, !tbaa !24
  %t658 = icmp sge i64 %t657, 0
  br i1 %t658, label %bb150, label %bb151
bb150:
  %t660 = load i64, ptr %l337, !tbaa !24
  %t661 = icmp sle i64 %t660, 1152921504606846975
  br i1 %t661, label %bb152, label %bb153
bb151:
  call void @__olang_check_failed(ptr @olang_loc_d5c4bb6f444265cb_1686743ce9a847e7)
  unreachable
bb152:
  %t663 = load i64, ptr %l337, !tbaa !24
  %t664 = mul i64 %t663, 8
  %t665 = call ptr @__olang_scope_alloc_zeroed(ptr %s18, i64 %t664)
  %t666 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t667 = insertvalue { i64, ptr } %t666, ptr %t665, 1
  store { i64, ptr } %t667, ptr %l32, !tbaa !27
  store i64 0, ptr %l33, !tbaa !24
  %t669 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t671 = extractvalue { i64, ptr } %t669, 0
  store i64 %t671, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t673 = load i64, ptr %l34, !tbaa !24
  %t674 = load i64, ptr %l33, !tbaa !24
  %t677 = icmp sgt i64 %t673, %t674
  br i1 %t677, label %bb154, label %bb155
bb153:
  call void @__olang_check_failed(ptr @olang_loc_d5c4bb6f444265cb_1686743ce9a847e7)
  unreachable
bb154:
  %t679 = load i64, ptr %l35, !tbaa !24
  %t681 = icmp sgt i64 %t679, 0
  br i1 %t681, label %bb156, label %bb157
bb155:
  store i64 0, ptr %l346, !tbaa !24
  br label %bb159
bb156:
  %t683 = load i64, ptr %l34, !tbaa !24
  %t684 = load i64, ptr %l33, !tbaa !24
  %t687 = sub i64 %t683, %t684
  %t688 = load i64, ptr %l35, !tbaa !24
  %t691 = add i64 %t687, %t688
  %t693 = sub i64 %t691, 1
  %t694 = load i64, ptr %l35, !tbaa !24
  %t697 = sdiv i64 %t693, %t694
  store i64 %t697, ptr %l349, !tbaa !24
  br label %bb158
bb157:
  store i64 0, ptr %l349, !tbaa !24
  br label %bb158
bb158:
  %t699 = load i64, ptr %l349, !tbaa !24
  store i64 %t699, ptr %l346, !tbaa !24
  br label %bb159
bb159:
  %t700 = load i64, ptr %l346, !tbaa !24
  store i64 %t700, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb160
bb160:
  %t701 = load i64, ptr %l37, !tbaa !24
  %t702 = load i64, ptr %l36, !tbaa !24
  %t705 = icmp slt i64 %t701, %t702
  %t707 = xor i1 %t705, true
  br i1 %t707, label %bb161, label %bb162
bb161:
  br label %bb165
bb162:
  br label %bb163
bb163:
  %t709 = load i64, ptr %l33, !tbaa !24
  %t710 = load i64, ptr %l37, !tbaa !24
  %t711 = load i64, ptr %l35, !tbaa !24
  %t714 = mul i64 %t710, %t711
  %t717 = add i64 %t709, %t714
  store i64 %t717, ptr %l38, !tbaa !24
  %t719 = load i64, ptr %l38, !tbaa !24
  %t721 = sdiv i64 %t719, 8
  %t722 = load i64, ptr %l38, !tbaa !24
  %t724 = sdiv i64 %t722, 8
  %t726 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t727 = load ptr, ptr %t726, !tbaa !27
  %t728 = getelementptr i64, ptr %t727, i64 %t724
  %t729 = load i64, ptr %t728, !tbaa !85
  %t730 = load i64, ptr %l38, !tbaa !24
  %t732 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t733 = load ptr, ptr %t732, !tbaa !27
  %t734 = getelementptr i8, ptr %t733, i64 %t730
  %t735 = load i8, ptr %t734, !tbaa !32
  %t737 = zext i8 %t735 to i64
  %t738 = load i64, ptr %l38, !tbaa !24
  %t740 = srem i64 %t738, 8
  %t742 = mul i64 8, %t740
  store i64 %t742, ptr %l378, !tbaa !65
  %t745 = load i64, ptr %l378, !tbaa !65
  %t746 = load i64, ptr %l378, !tbaa !65
  %t747 = shl i64 %t737, %t746
  %t750 = or i64 %t729, %t747
  %t753 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t754 = load ptr, ptr %t753, !tbaa !27
  %t755 = getelementptr i64, ptr %t754, i64 %t721
  store i64 %t750, ptr %t755, !tbaa !85
  br label %bb164
bb164:
  %t756 = load i64, ptr %l37, !tbaa !24
  %t758 = add i64 %t756, 1
  store i64 %t758, ptr %l37, !tbaa !24
  br label %bb160
bb165:
  %t760 = load ptr, ptr %l0, !tbaa !29
  store ptr %t760, ptr %l383, !tbaa !29
  %t761 = load i64, ptr %l1, !tbaa !24
  store i64 %t761, ptr %l384, !tbaa !24
  %t762 = load { ptr, ptr }, ptr %l8
  %t764 = extractvalue { ptr, ptr } %t762, 0
  %t765 = extractvalue { ptr, ptr } %t762, 1
  %t766 = call { i64, [4 x i64] } %t764(ptr %t765, i64 0)
  store { i64, [4 x i64] } %t766, ptr %l386
  br label %bb166
bb166:
  %t767 = load ptr, ptr %l383, !tbaa !29
  %t768 = load i64, ptr %l384, !tbaa !24
  %t769 = load { i64, [4 x i64] }, ptr %l386
  %t770 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s18, ptr %t767, i64 %t768, { i64, [4 x i64] } %t769)
  store { i64, ptr } %t770, ptr %l387
  br label %bb167
bb167:
  %t771 = load ptr, ptr %l0, !tbaa !29
  store ptr %t771, ptr %l388, !tbaa !29
  %t772 = load i64, ptr %l1, !tbaa !24
  store i64 %t772, ptr %l389, !tbaa !24
  %t773 = load { ptr, ptr }, ptr %l8
  %t775 = extractvalue { ptr, ptr } %t773, 0
  %t776 = extractvalue { ptr, ptr } %t773, 1
  %t777 = call { i64, [4 x i64] } %t775(ptr %t776, i64 1)
  store { i64, [4 x i64] } %t777, ptr %l391
  br label %bb168
bb168:
  %t778 = load ptr, ptr %l388, !tbaa !29
  %t779 = load i64, ptr %l389, !tbaa !24
  %t780 = load { i64, [4 x i64] }, ptr %l391
  %t781 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s18, ptr %t778, i64 %t779, { i64, [4 x i64] } %t780)
  store { i64, ptr } %t781, ptr %l392
  br label %bb169
bb169:
  %t782 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t782, ptr %l393, !tbaa !27
  %t783 = load ptr, ptr %l0, !tbaa !29
  store ptr %t783, ptr %l394, !tbaa !29
  %t784 = load i64, ptr %l1, !tbaa !24
  store i64 %t784, ptr %l395, !tbaa !24
  %t785 = load { ptr, ptr }, ptr %l8
  %t787 = extractvalue { ptr, ptr } %t785, 0
  %t788 = extractvalue { ptr, ptr } %t785, 1
  %t789 = call { i64, [4 x i64] } %t787(ptr %t788, i64 3)
  store { i64, [4 x i64] } %t789, ptr %l397
  br label %bb170
bb170:
  %t790 = load ptr, ptr %l394, !tbaa !29
  %t791 = load i64, ptr %l395, !tbaa !24
  %t792 = load { i64, [4 x i64] }, ptr %l397
  %t793 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t790, i64 %t791, { i64, [4 x i64] } %t792)
  store i64 %t793, ptr %l398
  br label %bb171
bb171:
  %t794 = load i64, ptr %l398, !tbaa !24
  %t795 = trunc i64 %t794 to i8
  %t796 = load { i64, ptr }, ptr %l387, !tbaa !27
  %t797 = extractvalue { i64, ptr } %t796, 1
  %t798 = extractvalue { i64, ptr } %t796, 0
  %t799 = load { i64, ptr }, ptr %l392, !tbaa !27
  %t800 = extractvalue { i64, ptr } %t799, 1
  %t801 = extractvalue { i64, ptr } %t799, 0
  %t802 = load { i64, ptr }, ptr %l393, !tbaa !27
  %t803 = extractvalue { i64, ptr } %t802, 1
  %t804 = extractvalue { i64, ptr } %t802, 0
  %t806 = call i64 @__olang_dyncall(ptr %t797, ptr %t800, ptr %t803, i8 zeroext %t795)
  store i64 %t806, ptr %l400
  br label %bb172
bb172:
  %t807 = load i64, ptr %l400, !tbaa !65
  store i64 %t807, ptr %l9, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  %t809 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t811 = extractvalue { i64, ptr } %t809, 0
  store i64 %t811, ptr %l40, !tbaa !24
  store i64 1, ptr %l41, !tbaa !24
  %t813 = load i64, ptr %l40, !tbaa !24
  %t814 = load i64, ptr %l39, !tbaa !24
  %t817 = icmp sgt i64 %t813, %t814
  br i1 %t817, label %bb173, label %bb174
bb173:
  %t819 = load i64, ptr %l41, !tbaa !24
  %t821 = icmp sgt i64 %t819, 0
  br i1 %t821, label %bb175, label %bb176
bb174:
  store i64 0, ptr %l407, !tbaa !24
  br label %bb178
bb175:
  %t823 = load i64, ptr %l40, !tbaa !24
  %t824 = load i64, ptr %l39, !tbaa !24
  %t827 = sub i64 %t823, %t824
  %t828 = load i64, ptr %l41, !tbaa !24
  %t831 = add i64 %t827, %t828
  %t833 = sub i64 %t831, 1
  %t834 = load i64, ptr %l41, !tbaa !24
  %t837 = sdiv i64 %t833, %t834
  store i64 %t837, ptr %l410, !tbaa !24
  br label %bb177
bb176:
  store i64 0, ptr %l410, !tbaa !24
  br label %bb177
bb177:
  %t839 = load i64, ptr %l410, !tbaa !24
  store i64 %t839, ptr %l407, !tbaa !24
  br label %bb178
bb178:
  %t840 = load i64, ptr %l407, !tbaa !24
  store i64 %t840, ptr %l42, !tbaa !24
  store i64 0, ptr %l43, !tbaa !24
  br label %bb179
bb179:
  %t841 = load i64, ptr %l43, !tbaa !24
  %t842 = load i64, ptr %l42, !tbaa !24
  %t845 = icmp slt i64 %t841, %t842
  %t847 = xor i1 %t845, true
  br i1 %t847, label %bb180, label %bb181
bb180:
  br label %bb184
bb181:
  br label %bb182
bb182:
  %t849 = load i64, ptr %l39, !tbaa !24
  %t850 = load i64, ptr %l43, !tbaa !24
  %t851 = load i64, ptr %l41, !tbaa !24
  %t854 = mul i64 %t850, %t851
  %t857 = add i64 %t849, %t854
  store i64 %t857, ptr %l44, !tbaa !24
  %t859 = load i64, ptr %l44, !tbaa !24
  %t860 = load i64, ptr %l44, !tbaa !24
  %t862 = sdiv i64 %t860, 8
  %t864 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t865 = load ptr, ptr %t864, !tbaa !27
  %t866 = getelementptr i64, ptr %t865, i64 %t862
  %t867 = load i64, ptr %t866, !tbaa !85
  %t868 = load i64, ptr %l44, !tbaa !24
  %t870 = srem i64 %t868, 8
  %t872 = mul i64 8, %t870
  store i64 %t872, ptr %l435, !tbaa !65
  %t875 = load i64, ptr %l435, !tbaa !65
  %t876 = load i64, ptr %l435, !tbaa !65
  %t877 = lshr i64 %t867, %t876
  %t879 = and i64 %t877, 255
  %t881 = trunc i64 %t879 to i8
  %t884 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t885 = load ptr, ptr %t884, !tbaa !27
  %t886 = getelementptr i8, ptr %t885, i64 %t859
  store i8 %t881, ptr %t886, !tbaa !32
  br label %bb183
bb183:
  %t887 = load i64, ptr %l43, !tbaa !24
  %t889 = add i64 %t887, 1
  store i64 %t889, ptr %l43, !tbaa !24
  br label %bb179
bb184:
  %t891 = load ptr, ptr %l0, !tbaa !29
  store ptr %t891, ptr %l441, !tbaa !29
  %t892 = load i64, ptr %l1, !tbaa !24
  store i64 %t892, ptr %l442, !tbaa !24
  %t893 = load { ptr, ptr }, ptr %l8
  %t895 = extractvalue { ptr, ptr } %t893, 0
  %t896 = extractvalue { ptr, ptr } %t893, 1
  %t897 = call { i64, [4 x i64] } %t895(ptr %t896, i64 2)
  store { i64, [4 x i64] } %t897, ptr %l444
  br label %bb185
bb185:
  %t898 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t899 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t901 = extractvalue { i64, ptr } %t899, 0
  %t902 = load ptr, ptr %l441, !tbaa !29
  %t903 = load i64, ptr %l442, !tbaa !24
  %t904 = load { i64, [4 x i64] }, ptr %l444
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %s18, ptr %t902, i64 %t903, { i64, [4 x i64] } %t904, { i64, ptr } %t898, i64 %t901)
  br label %bb186
bb186:
  call void @__olang_scope_close(ptr %s18)
  br label %bb234
bb187:
  %t907 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t909 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t907, { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t909, ptr %l449
  br label %bb188
bb188:
  %t910 = load i1, ptr %l449, !tbaa !21
  br i1 %t910, label %bb189, label %bb190
bb189:
  br label %bb191
bb190:
  br label %bb199
bb191:
  store %olang.scope zeroinitializer, ptr %s25
  %t911 = load ptr, ptr %l0, !tbaa !29
  store ptr %t911, ptr %l450, !tbaa !29
  %t912 = load i64, ptr %l1, !tbaa !24
  store i64 %t912, ptr %l451, !tbaa !24
  %t913 = load { ptr, ptr }, ptr %l8
  %t915 = extractvalue { ptr, ptr } %t913, 0
  %t916 = extractvalue { ptr, ptr } %t913, 1
  %t917 = call { i64, [4 x i64] } %t915(ptr %t916, i64 0)
  store { i64, [4 x i64] } %t917, ptr %l453
  br label %bb192
bb192:
  %t918 = load ptr, ptr %l450, !tbaa !29
  %t919 = load i64, ptr %l451, !tbaa !24
  %t920 = load { i64, [4 x i64] }, ptr %l453
  %t921 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s25, ptr %t918, i64 %t919, { i64, [4 x i64] } %t920)
  store { i64, ptr } %t921, ptr %l454
  br label %bb193
bb193:
  %t922 = load ptr, ptr %l0, !tbaa !29
  store ptr %t922, ptr %l455, !tbaa !29
  %t923 = load i64, ptr %l1, !tbaa !24
  store i64 %t923, ptr %l456, !tbaa !24
  %t924 = load { ptr, ptr }, ptr %l8
  %t926 = extractvalue { ptr, ptr } %t924, 0
  %t927 = extractvalue { ptr, ptr } %t924, 1
  %t928 = call { i64, [4 x i64] } %t926(ptr %t927, i64 1)
  store { i64, [4 x i64] } %t928, ptr %l458
  br label %bb194
bb194:
  %t929 = load ptr, ptr %l455, !tbaa !29
  %t930 = load i64, ptr %l456, !tbaa !24
  %t931 = load { i64, [4 x i64] }, ptr %l458
  %t932 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s25, ptr %t929, i64 %t930, { i64, [4 x i64] } %t931)
  store { i64, ptr } %t932, ptr %l459
  br label %bb195
bb195:
  %t933 = load ptr, ptr %l0, !tbaa !29
  store ptr %t933, ptr %l460, !tbaa !29
  %t934 = load i64, ptr %l1, !tbaa !24
  store i64 %t934, ptr %l461, !tbaa !24
  %t935 = load { ptr, ptr }, ptr %l8
  %t937 = extractvalue { ptr, ptr } %t935, 0
  %t938 = extractvalue { ptr, ptr } %t935, 1
  %t939 = call { i64, [4 x i64] } %t937(ptr %t938, i64 2)
  store { i64, [4 x i64] } %t939, ptr %l463
  br label %bb196
bb196:
  %t940 = load ptr, ptr %l460, !tbaa !29
  %t941 = load i64, ptr %l461, !tbaa !24
  %t942 = load { i64, [4 x i64] }, ptr %l463
  %t943 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t940, i64 %t941, { i64, [4 x i64] } %t942)
  store i64 %t943, ptr %l464
  br label %bb197
bb197:
  %t944 = load i64, ptr %l464, !tbaa !24
  %t945 = trunc i64 %t944 to i8
  %t946 = load { i64, ptr }, ptr %l454, !tbaa !27
  %t947 = extractvalue { i64, ptr } %t946, 1
  %t948 = extractvalue { i64, ptr } %t946, 0
  %t949 = load { i64, ptr }, ptr %l459, !tbaa !27
  %t950 = extractvalue { i64, ptr } %t949, 1
  %t951 = extractvalue { i64, ptr } %t949, 0
  %t953 = call i32 @__olang_dyncall_check(ptr %t947, ptr %t950, i8 zeroext %t945)
  store i32 %t953, ptr %l466
  br label %bb198
bb198:
  %t954 = load i32, ptr %l466, !tbaa !23
  %t955 = sext i32 %t954 to i64
  store i64 %t955, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s25)
  br label %bb234
bb199:
  %t957 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t959 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t957, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t959, ptr %l469
  br label %bb200
bb200:
  %t960 = load i1, ptr %l469, !tbaa !21
  br i1 %t960, label %bb201, label %bb202
bb201:
  br label %bb203
bb202:
  br label %bb228
bb203:
  %t961 = load ptr, ptr %l0, !tbaa !29
  %t963 = getelementptr %"compiler/eval:Machine", ptr %t961, i32 0, i32 1
  %t964 = load i32, ptr %t963
  %t966 = trunc i64 1 to i32
  %t967 = icmp eq i32 %t964, %t966
  br i1 %t967, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s27
  %t969 = load ptr, ptr %l0, !tbaa !29
  store ptr %t969, ptr %l473, !tbaa !29
  %t970 = load i64, ptr %l1, !tbaa !24
  store i64 %t970, ptr %l474, !tbaa !24
  %t971 = load { ptr, ptr }, ptr %l8
  %t973 = extractvalue { ptr, ptr } %t971, 0
  %t974 = extractvalue { ptr, ptr } %t971, 1
  %t975 = call { i64, [4 x i64] } %t973(ptr %t974, i64 0)
  store { i64, [4 x i64] } %t975, ptr %l476
  br label %bb206
bb205:
  br label %bb227
bb206:
  %t976 = load ptr, ptr %l473, !tbaa !29
  %t977 = load i64, ptr %l474, !tbaa !24
  %t978 = load { i64, [4 x i64] }, ptr %l476
  %t979 = call { i64, ptr } @compiler_2feval_2ecompiler_2feval_3aMachine_2ebytesOf(ptr %v0, ptr %s27, ptr %t976, i64 %t977, { i64, [4 x i64] } %t978)
  store { i64, ptr } %t979, ptr %l477
  br label %bb207
bb207:
  %t980 = load { i64, ptr }, ptr %l477, !tbaa !27
  store { i64, ptr } %t980, ptr %l45, !tbaa !27
  %t981 = load ptr, ptr %l0, !tbaa !29
  store ptr %t981, ptr %l478, !tbaa !29
  %t982 = load i64, ptr %l1, !tbaa !24
  store i64 %t982, ptr %l479, !tbaa !24
  %t983 = load { ptr, ptr }, ptr %l8
  %t985 = extractvalue { ptr, ptr } %t983, 0
  %t986 = extractvalue { ptr, ptr } %t983, 1
  %t987 = call { i64, [4 x i64] } %t985(ptr %t986, i64 1)
  store { i64, [4 x i64] } %t987, ptr %l481
  br label %bb208
bb208:
  %t988 = load ptr, ptr %l478, !tbaa !29
  %t989 = load i64, ptr %l479, !tbaa !24
  %t990 = load { i64, [4 x i64] }, ptr %l481
  %t991 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintArg(ptr %v0, ptr %t988, i64 %t989, { i64, [4 x i64] } %t990)
  store i64 %t991, ptr %l482
  br label %bb209
bb209:
  %t992 = load i64, ptr %l482, !tbaa !24
  store i64 %t992, ptr %l46, !tbaa !24
  %t993 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s27)
  store %"std/prelude/text:StringBuilder" %t993, ptr %l483
  br label %bb210
bb210:
  %t994 = load %"std/prelude/text:StringBuilder", ptr %l483
  store %"std/prelude/text:StringBuilder" %t994, ptr %l47
  store i64 0, ptr %l48, !tbaa !24
  %t995 = load i64, ptr %l46, !tbaa !24
  store i64 %t995, ptr %l49, !tbaa !24
  store i64 1, ptr %l50, !tbaa !24
  %t997 = load i64, ptr %l49, !tbaa !24
  %t998 = load i64, ptr %l48, !tbaa !24
  %t1001 = icmp sgt i64 %t997, %t998
  br i1 %t1001, label %bb211, label %bb212
bb211:
  %t1003 = load i64, ptr %l50, !tbaa !24
  %t1005 = icmp sgt i64 %t1003, 0
  br i1 %t1005, label %bb213, label %bb214
bb212:
  store i64 0, ptr %l488, !tbaa !24
  br label %bb216
bb213:
  %t1007 = load i64, ptr %l49, !tbaa !24
  %t1008 = load i64, ptr %l48, !tbaa !24
  %t1011 = sub i64 %t1007, %t1008
  %t1012 = load i64, ptr %l50, !tbaa !24
  %t1015 = add i64 %t1011, %t1012
  %t1017 = sub i64 %t1015, 1
  %t1018 = load i64, ptr %l50, !tbaa !24
  %t1021 = sdiv i64 %t1017, %t1018
  store i64 %t1021, ptr %l491, !tbaa !24
  br label %bb215
bb214:
  store i64 0, ptr %l491, !tbaa !24
  br label %bb215
bb215:
  %t1023 = load i64, ptr %l491, !tbaa !24
  store i64 %t1023, ptr %l488, !tbaa !24
  br label %bb216
bb216:
  %t1024 = load i64, ptr %l488, !tbaa !24
  store i64 %t1024, ptr %l51, !tbaa !24
  store i64 0, ptr %l52, !tbaa !24
  br label %bb217
bb217:
  %t1025 = load i64, ptr %l52, !tbaa !24
  %t1026 = load i64, ptr %l51, !tbaa !24
  %t1029 = icmp slt i64 %t1025, %t1026
  %t1031 = xor i1 %t1029, true
  br i1 %t1031, label %bb218, label %bb219
bb218:
  br label %bb223
bb219:
  br label %bb220
bb220:
  %t1033 = load i64, ptr %l48, !tbaa !24
  %t1034 = load i64, ptr %l52, !tbaa !24
  %t1035 = load i64, ptr %l50, !tbaa !24
  %t1038 = mul i64 %t1034, %t1035
  %t1041 = add i64 %t1033, %t1038
  %t1045 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t1046 = load ptr, ptr %t1045, !tbaa !27
  %t1047 = getelementptr i8, ptr %t1046, i64 %t1041
  %t1048 = load i8, ptr %t1047, !tbaa !32
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s27, ptr %l47, i8 %t1048)
  br label %bb221
bb221:
  br label %bb222
bb222:
  %t1052 = load i64, ptr %l52, !tbaa !24
  %t1054 = add i64 %t1052, 1
  store i64 %t1054, ptr %l52, !tbaa !24
  br label %bb217
bb223:
  %t1056 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eInterpCrash, !tbaa !27
  %t1057 = load ptr, ptr @__olang_prog_scope
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s27, ptr %t1057, ptr %l47, { i64, ptr } %t1056)
  br label %bb224
bb224:
  %t1061 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s27, ptr %s27, ptr %l47)
  store { i64, ptr } %t1061, ptr %l518
  br label %bb225
bb225:
  %t1062 = load { i64, ptr }, ptr %l518, !tbaa !27
  call void @std_2fos_2eOnCrash(ptr %s27, { i64, ptr } %t1062)
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s27)
  br label %bb227
bb227:
  br label %bb234
bb228:
  br i1 true, label %bb229, label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb233
bb231:
  %t1063 = load ptr, ptr %l0, !tbaa !29
  %t1064 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyFfiFind, !tbaa !27
  %t1065 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t1065, ptr %t1063, { i64, ptr } %t1064)
  br label %bb232
bb232:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb233:
  call void @__olang_check_failed(ptr @olang_loc_de11af42111bcb9b_94efc9af890b5bc7)
  unreachable
bb234:
  %t1069 = load ptr, ptr %l0, !tbaa !29
  %t1071 = getelementptr %"compiler/eval:Machine", ptr %t1069, i32 0, i32 13
  %t1072 = load i1, ptr %t1071, !tbaa !21
  br i1 %t1072, label %bb235, label %bb236
bb235:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb236:
  br label %bb237
bb237:
  %t1075 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1077 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1075, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t1077, ptr %l526
  br label %bb238
bb238:
  %t1078 = load i1, ptr %l526, !tbaa !21
  %t1079 = xor i1 %t1078, true
  br i1 %t1079, label %bb239, label %bb240
bb239:
  %t1081 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1083 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1081, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t1083, ptr %l530
  br label %bb241
bb240:
  store i1 false, ptr %l528, !tbaa !21
  br label %bb242
bb241:
  %t1084 = load i1, ptr %l530, !tbaa !21
  %t1085 = xor i1 %t1084, true
  store i1 %t1085, ptr %l528, !tbaa !21
  br label %bb242
bb242:
  %t1087 = load i1, ptr %l528, !tbaa !21
  br i1 %t1087, label %bb243, label %bb244
bb243:
  %t1088 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t1090 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1088, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d48, i32 0, i32 1) })
  store i1 %t1090, ptr %l534
  br label %bb245
bb244:
  store i1 false, ptr %l532, !tbaa !21
  br label %bb246
bb245:
  %t1091 = load i1, ptr %l534, !tbaa !21
  %t1092 = xor i1 %t1091, true
  store i1 %t1092, ptr %l532, !tbaa !21
  br label %bb246
bb246:
  %t1094 = load i1, ptr %l532, !tbaa !21
  br i1 %t1094, label %bb247, label %bb248
bb247:
  %t1095 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1095, ptr %l536, !tbaa !29
  %t1096 = call i32 @__olang_err()
  store i32 %t1096, ptr %l537
  br label %bb249
bb248:
  br label %bb250
bb249:
  %t1097 = load i32, ptr %l537, !tbaa !23
  %t1098 = load ptr, ptr %l536, !tbaa !29
  %t1099 = getelementptr %"compiler/eval:Machine", ptr %t1098, i32 0, i32 81
  store i32 %t1097, ptr %t1099, !tbaa !23
  br label %bb250
bb250:
  %t1100 = load ptr, ptr %l0, !tbaa !29
  %t1102 = getelementptr %"compiler/eval:Machine", ptr %t1100, i32 0, i32 0
  %t1103 = load ptr, ptr %t1102, !tbaa !29
  %t1107 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t1103, i32 %a4)
  store i32 %t1107, ptr %l541
  br label %bb251
bb251:
  %t1108 = load i32, ptr %l541, !tbaa !23
  store i32 %t1108, ptr %l54, !tbaa !23
  br i1 %a6, label %bb252, label %bb253
bb252:
  %t1111 = load i32, ptr %l54, !tbaa !23
  %t1112 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1115 = icmp ne i32 %t1111, %t1112
  store i1 %t1115, ptr %l543, !tbaa !21
  br label %bb254
bb253:
  store i1 false, ptr %l543, !tbaa !21
  br label %bb254
bb254:
  %t1117 = load i1, ptr %l543, !tbaa !21
  br i1 %t1117, label %bb255, label %bb256
bb255:
  %t1118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1118, ptr %l547, !tbaa !29
  store %"compiler/eval:Ptr" %a5, ptr %l548
  %t1120 = load ptr, ptr %l0, !tbaa !29
  %t1121 = load i32, ptr %l54, !tbaa !23
  %t1124 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t1120, i32 %t1121)
  store i64 %t1124, ptr %l551
  br label %bb257
bb256:
  br label %bb259
bb257:
  %t1125 = load i64, ptr %l9, !tbaa !24
  %t1126 = load ptr, ptr %l547, !tbaa !29
  %t1127 = load %"compiler/eval:Ptr", ptr %l548
  %t1128 = load i64, ptr %l551, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %t1126, %"compiler/eval:Ptr" %t1127, i64 %t1128, i64 %t1125)
  br label %bb258
bb258:
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca %"compiler/mir:Lvalue"
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i32
  %l8 = alloca { %"compiler/eval:Ptr", i32 }
  %l21 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca %"compiler/eval:Ptr"
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l52 = alloca { %"compiler/eval:Ptr", i32 }
  %l55 = alloca ptr
  %l56 = alloca %"compiler/eval:Ptr"
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l65 = alloca %"compiler/eval:Ptr"
  %l66 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca i64
  %l72 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [4 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [4 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [4 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i64 0, ptr %rv
  br label %ret
bb4:
  %t7 = load { i64, [4 x i64] }, ptr %l2
  %t9 = extractvalue { i64, [4 x i64] } %t7, 0
  %t10 = icmp eq i64 %t9, 2
  br i1 %t10, label %bb5, label %bb6
bb5:
  %t12 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t13 = getelementptr { i32, i64 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t17 = getelementptr { i32, i64 }, ptr %t16, i32 0, i32 1
  %t18 = load i64, ptr %t17
  store i64 %t18, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load i64, ptr %l4, !tbaa !24
  %t26 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %t20, i32 %t21, i64 %t22)
  store i64 %t26, ptr %l21
  br label %bb8
bb8:
  %t27 = load i64, ptr %l21, !tbaa !24
  store i64 %t27, ptr %rv
  br label %ret
bb9:
  %t28 = load { i64, [4 x i64] }, ptr %l2
  %t30 = extractvalue { i64, [4 x i64] } %t28, 0
  %t31 = icmp eq i64 %t30, 1
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = getelementptr { i64, [4 x i64] }, ptr %l2, i32 0, i32 1
  %t34 = getelementptr { %"compiler/mir:Lvalue" }, ptr %t33, i32 0, i32 0
  %t35 = load %"compiler/mir:Lvalue", ptr %t34
  store %"compiler/mir:Lvalue" %t35, ptr %l5
  br label %bb12
bb11:
  br label %bb31
bb12:
  %t37 = getelementptr %"compiler/mir:Lvalue", ptr %l5, i32 0, i32 1
  %t38 = getelementptr %"compiler/mir:Range", ptr %t37, i32 0, i32 1
  %t39 = load i32, ptr %t38, !tbaa !23
  %t41 = icmp eq i32 %t39, 0
  br i1 %t41, label %bb13, label %bb14
bb13:
  %t43 = getelementptr %"compiler/mir:Lvalue", ptr %l5, i32 0, i32 0
  %t44 = load { i64, [2 x i64] }, ptr %t43
  store { i64, [2 x i64] } %t44, ptr %l6
  %t46 = load { i64, [2 x i64] }, ptr %l6
  %t48 = extractvalue { i64, [2 x i64] } %t46, 0
  %t49 = icmp eq i64 %t48, 1
  br i1 %t49, label %bb15, label %bb16
bb14:
  br label %bb27
bb15:
  %t51 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t52 = getelementptr { i32 }, ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l7, !tbaa !23
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l31, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load i64, ptr %l1, !tbaa !24
  %t58 = load i32, ptr %l7, !tbaa !23
  %t62 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2elocalPtr(ptr %v0, ptr %t56, i64 %t57, i32 %t58)
  store %"compiler/eval:Ptr" %t62, ptr %l35
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/eval:Machine", ptr %t64, i32 0, i32 17
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  store { i64, ptr } %t67, ptr %l38, !tbaa !27
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/eval:Machine", ptr %t68, i32 0, i32 49
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l40, !tbaa !27
  %t72 = load i64, ptr %l1, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr %"compiler/eval:frame", ptr %t75, i64 %t72
  %t77 = getelementptr %"compiler/eval:frame", ptr %t76, i32 0, i32 0
  %t78 = load i64, ptr %t77, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr %"compiler/eval:cfn", ptr %t81, i64 %t78
  %t83 = getelementptr %"compiler/eval:cfn", ptr %t82, i32 0, i32 1
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l43, !tbaa !27
  %t85 = load i32, ptr %l7, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t89 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr %"compiler/mir:Local", ptr %t90, i64 %t87
  %t92 = getelementptr %"compiler/mir:Local", ptr %t91, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %t63, i32 %t93)
  store i64 %t96, ptr %l47
  br label %bb19
bb19:
  %t97 = load ptr, ptr %l31, !tbaa !29
  %t98 = load %"compiler/eval:Ptr", ptr %l35
  %t99 = load i64, ptr %l47, !tbaa !24
  %t100 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t97, %"compiler/eval:Ptr" %t98, i64 %t99)
  store i64 %t100, ptr %l48
  br label %bb20
bb20:
  %t101 = load i64, ptr %l48, !tbaa !24
  store i64 %t101, ptr %rv
  br label %ret
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_1c104311c72af5f5_c45dcd645c687dc1)
  unreachable
bb26:
  br label %bb27
bb27:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i64, ptr %l1, !tbaa !24
  %t104 = load %"compiler/mir:Lvalue", ptr %l5
  %t108 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t102, i64 %t103, %"compiler/mir:Lvalue" %t104)
  store { %"compiler/eval:Ptr", i32 } %t108, ptr %l52
  br label %bb28
bb28:
  %t109 = load { %"compiler/eval:Ptr", i32 }, ptr %l52
  store { %"compiler/eval:Ptr", i32 } %t109, ptr %l8
  %t110 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 0
  %t111 = load %"compiler/eval:Ptr", ptr %t110
  %t113 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l8, i32 0, i32 1
  %t114 = load i32, ptr %t113, !tbaa !23
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l55, !tbaa !29
  store %"compiler/eval:Ptr" %t111, ptr %l56
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t122 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %t118, i32 %t114)
  store i64 %t122, ptr %l59
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l55, !tbaa !29
  %t124 = load %"compiler/eval:Ptr", ptr %l56
  %t125 = load i64, ptr %l59, !tbaa !24
  %t126 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t123, %"compiler/eval:Ptr" %t124, i64 %t125)
  store i64 %t126, ptr %l60
  br label %bb30
bb30:
  %t127 = load i64, ptr %l60, !tbaa !24
  store i64 %t127, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb39
bb34:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l61, !tbaa !29
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i64, ptr %l1, !tbaa !24
  %t131 = load { i64, [4 x i64] }, ptr %l2
  %t135 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t129, i64 %t130, { i64, [4 x i64] } %t131, i64 1)
  store %"compiler/eval:Ptr" %t135, ptr %l65
  br label %bb35
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l66, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i64, ptr %l1, !tbaa !24
  %t139 = load { i64, [4 x i64] }, ptr %l2
  %t143 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t137, i64 %t138, { i64, [4 x i64] } %t139)
  store i32 %t143, ptr %l70
  br label %bb36
bb36:
  %t144 = load ptr, ptr %l66, !tbaa !29
  %t145 = load i32, ptr %l70, !tbaa !23
  %t146 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %t144, i32 %t145)
  store i64 %t146, ptr %l71
  br label %bb37
bb37:
  %t147 = load ptr, ptr %l61, !tbaa !29
  %t148 = load %"compiler/eval:Ptr", ptr %l65
  %t149 = load i64, ptr %l71, !tbaa !24
  %t150 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t147, %"compiler/eval:Ptr" %t148, i64 %t149)
  store i64 %t150, ptr %l72
  br label %bb38
bb38:
  %t151 = load i64, ptr %l72, !tbaa !24
  store i64 %t151, ptr %rv
  br label %ret
bb39:
  call void @__olang_check_failed(ptr @olang_loc_eac386e3c6428a04_b108c34b7dde3e30)
  unreachable
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshapeOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i64
  %l45 = alloca i64
  %l47 = alloca i64
  %l51 = alloca i64
  %l53 = alloca i64
  %l73 = alloca ptr
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i64
  %l88 = alloca i32
  %l90 = alloca i64
  %l100 = alloca ptr
  %l103 = alloca i32
  %l104 = alloca i1
  %l105 = alloca i64
  %l112 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t15, ptr %l12
  br label %bb2
bb2:
  %t16 = load i32, ptr %l12, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t18 = load i32, ptr %l3, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l15
  br label %bb3
bb3:
  %t22 = load i32, ptr %l15
  store i32 %t22, ptr %l4
  %t23 = load i32, ptr %l4
  %t25 = trunc i64 1 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t28 = load i64, ptr @G_2ecompiler_2feval_2evVoid, !tbaa !24
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb107
bb7:
  %t30 = load i32, ptr %l4
  %t32 = trunc i64 2 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t35 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  store i64 %t35, ptr %l16, !tbaa !24
  br label %bb107
bb11:
  %t37 = load i32, ptr %l4
  %t39 = trunc i64 3 to i32
  %t40 = icmp eq i32 %t37, %t39
  br i1 %t40, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  %t42 = load i32, ptr %l4
  %t44 = trunc i64 4 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb14, label %bb15
bb14:
  br label %bb20
bb15:
  %t47 = load i32, ptr %l4
  %t49 = trunc i64 5 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  %t52 = load i32, ptr %l4
  %t54 = trunc i64 6 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t57 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  store i64 %t57, ptr %l16, !tbaa !24
  br label %bb107
bb21:
  %t59 = load i32, ptr %l4
  %t61 = trunc i64 7 to i32
  %t62 = icmp eq i32 %t59, %t61
  br i1 %t62, label %bb22, label %bb23
bb22:
  br label %bb30
bb23:
  %t64 = load i32, ptr %l4
  %t66 = trunc i64 8 to i32
  %t67 = icmp eq i32 %t64, %t66
  br i1 %t67, label %bb24, label %bb25
bb24:
  br label %bb30
bb25:
  %t69 = load i32, ptr %l4
  %t71 = trunc i64 9 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb26, label %bb27
bb26:
  br label %bb30
bb27:
  %t74 = load i32, ptr %l4
  %t76 = trunc i64 10 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb28, label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb31
bb30:
  %t79 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  store i64 %t79, ptr %l16, !tbaa !24
  br label %bb107
bb31:
  %t81 = load i32, ptr %l4
  %t83 = trunc i64 31 to i32
  %t84 = icmp eq i32 %t81, %t83
  br i1 %t84, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb43
bb34:
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t87 = load i32, ptr %l3, !tbaa !23
  %t90 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t86, i32 %t87)
  store i64 %t90, ptr %l45
  br label %bb35
bb35:
  %t91 = load i64, ptr %l45, !tbaa !24
  %t92 = icmp sgt i64 %t91, 64
  br i1 %t92, label %bb36, label %bb37
bb36:
  %t94 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  store i64 %t94, ptr %l47, !tbaa !24
  br label %bb42
bb37:
  %t96 = load ptr, ptr %l2, !tbaa !29
  %t97 = load i32, ptr %l3, !tbaa !23
  %t100 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t96, i32 %t97)
  store i64 %t100, ptr %l51
  br label %bb38
bb38:
  %t101 = load i64, ptr %l51, !tbaa !24
  %t102 = icmp eq i64 %t101, 1
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load i64, ptr @G_2ecompiler_2feval_2evInt, !tbaa !24
  store i64 %t104, ptr %l53, !tbaa !24
  br label %bb41
bb40:
  %t106 = load i64, ptr @G_2ecompiler_2feval_2evUint, !tbaa !24
  store i64 %t106, ptr %l53, !tbaa !24
  br label %bb41
bb41:
  %t108 = load i64, ptr %l53, !tbaa !24
  store i64 %t108, ptr %l47, !tbaa !24
  br label %bb42
bb42:
  %t109 = load i64, ptr %l47, !tbaa !24
  store i64 %t109, ptr %l16, !tbaa !24
  br label %bb107
bb43:
  %t110 = load i32, ptr %l4
  %t112 = trunc i64 11 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb44, label %bb45
bb44:
  br label %bb52
bb45:
  %t115 = load i32, ptr %l4
  %t117 = trunc i64 12 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  %t120 = load i32, ptr %l4
  %t122 = trunc i64 13 to i32
  %t123 = icmp eq i32 %t120, %t122
  br i1 %t123, label %bb48, label %bb49
bb48:
  br label %bb52
bb49:
  %t125 = load i32, ptr %l4
  %t127 = trunc i64 14 to i32
  %t128 = icmp eq i32 %t125, %t127
  br i1 %t128, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t130 = load i64, ptr @G_2ecompiler_2feval_2evFloat, !tbaa !24
  store i64 %t130, ptr %l16, !tbaa !24
  br label %bb107
bb53:
  %t132 = load i32, ptr %l4
  %t134 = trunc i64 15 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t137 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  store i64 %t137, ptr %l16, !tbaa !24
  br label %bb107
bb57:
  %t139 = load i32, ptr %l4
  %t141 = trunc i64 16 to i32
  %t142 = icmp eq i32 %t139, %t141
  br i1 %t142, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t144 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  store i64 %t144, ptr %l16, !tbaa !24
  br label %bb107
bb61:
  %t146 = load i32, ptr %l4
  %t148 = trunc i64 20 to i32
  %t149 = icmp eq i32 %t146, %t148
  br i1 %t149, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb70
bb64:
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l73, !tbaa !29
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t153 = load i32, ptr %l3, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t152, i32 %t153)
  store i32 %t156, ptr %l76
  br label %bb65
bb65:
  %t157 = load ptr, ptr %l73, !tbaa !29
  %t158 = load i32, ptr %l76, !tbaa !23
  %t159 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t159, ptr %l77
  br label %bb66
bb66:
  %t160 = load i1, ptr %l77, !tbaa !21
  br i1 %t160, label %bb67, label %bb68
bb67:
  %t161 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  store i64 %t161, ptr %l78, !tbaa !24
  br label %bb69
bb68:
  %t163 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  store i64 %t163, ptr %l78, !tbaa !24
  br label %bb69
bb69:
  %t165 = load i64, ptr %l78, !tbaa !24
  store i64 %t165, ptr %l16, !tbaa !24
  br label %bb107
bb70:
  %t166 = load i32, ptr %l4
  %t168 = trunc i64 21 to i32
  %t169 = icmp eq i32 %t166, %t168
  br i1 %t169, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  %t171 = load i64, ptr @G_2ecompiler_2feval_2evFunc, !tbaa !24
  store i64 %t171, ptr %l16, !tbaa !24
  br label %bb107
bb74:
  %t173 = load i32, ptr %l4
  %t175 = trunc i64 19 to i32
  %t176 = icmp eq i32 %t173, %t175
  br i1 %t176, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb82
bb77:
  %t178 = load ptr, ptr %l2, !tbaa !29
  %t179 = load i32, ptr %l3, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l88
  br label %bb78
bb78:
  %t183 = load i32, ptr %l88, !tbaa !23
  %t184 = icmp eq i32 %t183, 0
  br i1 %t184, label %bb79, label %bb80
bb79:
  %t186 = load i64, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  store i64 %t186, ptr %l90, !tbaa !24
  br label %bb81
bb80:
  %t188 = load i64, ptr @G_2ecompiler_2feval_2evFixed, !tbaa !24
  store i64 %t188, ptr %l90, !tbaa !24
  br label %bb81
bb81:
  %t190 = load i64, ptr %l90, !tbaa !24
  store i64 %t190, ptr %l16, !tbaa !24
  br label %bb107
bb82:
  %t191 = load i32, ptr %l4
  %t193 = trunc i64 22 to i32
  %t194 = icmp eq i32 %t191, %t193
  br i1 %t194, label %bb83, label %bb84
bb83:
  br label %bb87
bb84:
  %t196 = load i32, ptr %l4
  %t198 = trunc i64 23 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb85, label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t201 = load i64, ptr @G_2ecompiler_2feval_2evAgg, !tbaa !24
  store i64 %t201, ptr %l16, !tbaa !24
  br label %bb107
bb88:
  %t203 = load i32, ptr %l4
  %t205 = trunc i64 24 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb89, label %bb90
bb89:
  br label %bb91
bb90:
  br label %bb97
bb91:
  %t208 = load ptr, ptr %l2, !tbaa !29
  store ptr %t208, ptr %l100, !tbaa !29
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t210 = load i32, ptr %l3, !tbaa !23
  %t213 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %t209, i32 %t210)
  store i32 %t213, ptr %l103
  br label %bb92
bb92:
  %t214 = load ptr, ptr %l100, !tbaa !29
  %t215 = load i32, ptr %l103, !tbaa !23
  %t216 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t214, i32 %t215)
  store i1 %t216, ptr %l104
  br label %bb93
bb93:
  %t217 = load i1, ptr %l104, !tbaa !21
  br i1 %t217, label %bb94, label %bb95
bb94:
  %t218 = load i64, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  store i64 %t218, ptr %l105, !tbaa !24
  br label %bb96
bb95:
  %t220 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  store i64 %t220, ptr %l105, !tbaa !24
  br label %bb96
bb96:
  %t222 = load i64, ptr %l105, !tbaa !24
  store i64 %t222, ptr %l16, !tbaa !24
  br label %bb107
bb97:
  %t223 = load i32, ptr %l4
  %t225 = trunc i64 18 to i32
  %t226 = icmp eq i32 %t223, %t225
  br i1 %t226, label %bb98, label %bb99
bb98:
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load i32, ptr %l3, !tbaa !23
  %t232 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enamedShape(ptr %v0, ptr %t228, i32 %t229)
  store i64 %t232, ptr %l112
  br label %bb101
bb101:
  %t233 = load i64, ptr %l112, !tbaa !24
  store i64 %t233, ptr %l16, !tbaa !24
  br label %bb107
bb102:
  br i1 true, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  br label %bb106
bb105:
  %t234 = load i64, ptr @G_2ecompiler_2feval_2evNone, !tbaa !24
  store i64 %t234, ptr %l16, !tbaa !24
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_5b67d157b70117f_cddce93e80c09b93)
  unreachable
bb107:
  %t236 = load i64, ptr %l16, !tbaa !24
  store i64 %t236, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estartGlobal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/eval:global"
  %l12 = alloca %"compiler/eval:global"
  %l14 = alloca i64
  %l16 = alloca ptr
  %l20 = alloca { i64, [2 x i64] }
  %l21 = alloca i64
  %l22 = alloca i32
  %l32 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l52 = alloca %"compiler/eval:global"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 33
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t3, i64 %t4)
  store %"compiler/eval:global" %t7, ptr %l12
  br label %bb1
bb1:
  %t8 = getelementptr %"compiler/eval:global", ptr %l12, i32 0, i32 2
  %t9 = load i64, ptr %t8, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/eval:Machine", ptr %t11, i32 0, i32 21
  store ptr %t13, ptr %l16, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/eval:Machine", ptr %t14, i32 0, i32 22
  %t20 = call { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %t16, i64 %t9)
  store { i64, [2 x i64] } %t20, ptr %l20
  br label %bb2
bb2:
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = load { i64, [2 x i64] }, ptr %l20
  %t23 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %t21, { i64, [2 x i64] } %t22)
  %t24 = extractvalue { i32, i64 } %t23, 1
  %t25 = extractvalue { i32, i64 } %t23, 0
  store i32 %t25, ptr %l22
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb4, label %ok.27, !prof !99
ok.27:
  store i64 %t24, ptr %l21
  br label %bb3
bb3:
  %t28 = load i64, ptr %l21, !tbaa !24
  store i64 %t28, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  br label %bb5
bb5:
  call void @__olang_ert_req_clear()
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyNoBody, !tbaa !27
  %t31 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t31, ptr %t29, { i64, ptr } %t30)
  br label %bb6
bb6:
  br label %ret
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/eval:Machine", ptr %t35, i32 0, i32 14
  %t38 = load i1, ptr %t37, !tbaa !21
  store i1 %t38, ptr %l4, !tbaa !21
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/eval:Machine", ptr %t40, i32 0, i32 14
  store i1 false, ptr %t42, !tbaa !21
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i64, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  %t46 = load i64, ptr %l1, !tbaa !24
  %t51 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epushFrame(ptr %v0, ptr %t43, i64 %t34, i64 %t45, i64 %t46)
  store i64 %t51, ptr %l32
  br label %bb8
bb8:
  %t52 = load i64, ptr %l32, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l5, !tbaa !24
  %t55 = icmp slt i64 %t53, 0
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i1, ptr %l4, !tbaa !21
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t57, i32 0, i32 14
  store i1 %t58, ptr %t61, !tbaa !21
  br label %ret
bb10:
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/eval:Machine", ptr %t62, i32 0, i32 49
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  store { i64, ptr } %t65, ptr %l38, !tbaa !27
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i1, ptr %l4, !tbaa !21
  %t70 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr %"compiler/eval:frame", ptr %t71, i64 %t66
  %t73 = getelementptr %"compiler/eval:frame", ptr %t72, i32 0, i32 15
  store i1 %t67, ptr %t73, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/eval:Machine", ptr %t74, i32 0, i32 49
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l42, !tbaa !27
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/eval:Machine", ptr %t79, i32 0, i32 64
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr %"compiler/eval:frame", ptr %t86, i64 %t78
  %t88 = getelementptr %"compiler/eval:frame", ptr %t87, i32 0, i32 14
  store i64 %t82, ptr %t88, !tbaa !24
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load i64, ptr %l1, !tbaa !24
  %t93 = getelementptr %"compiler/eval:Machine", ptr %t89, i32 0, i32 64
  store i64 %t90, ptr %t93, !tbaa !24
  %t94 = load i64, ptr %l1, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/eval:Machine", ptr %t96, i32 0, i32 33
  %t99 = load i64, ptr %l6, !tbaa !24
  %t102 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t98, i64 %t99)
  store %"compiler/eval:global" %t102, ptr %l52
  br label %bb12
bb12:
  %t103 = load %"compiler/eval:global", ptr %l52
  store %"compiler/eval:global" %t103, ptr %l8
  %t104 = load i64, ptr %l7, !tbaa !24
  %t106 = getelementptr %"compiler/eval:global", ptr %l8, i32 0, i32 4
  store i64 %t104, ptr %t106, !tbaa !24
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/eval:Machine", ptr %t107, i32 0, i32 33
  %t110 = load i64, ptr %l6, !tbaa !24
  %t111 = load %"compiler/eval:global", ptr %l8
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eSetAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t109, i64 %t110, %"compiler/eval:global" %t111)
  br label %bb13
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2estmtAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca { i64, [21 x i64] }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca %"compiler/mir:Lvalue"
  %l9 = alloca { i64, [15 x i64] }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca %"compiler/mir:Local"
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca %"compiler/mir:ScopeInfo"
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/eval:scope"
  %l25 = alloca %"compiler/eval:Ptr"
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca %"compiler/eval:scope"
  %l29 = alloca i32
  %l30 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i32
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, [1 x i64] }
  %l38 = alloca i32
  %l39 = alloca { i64, [4 x i64] }
  %l40 = alloca i64
  %l42 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, [1 x i64] }
  %l44 = alloca %"compiler/mir:Lvalue"
  %l45 = alloca { %"compiler/eval:Ptr", i32 }
  %l46 = alloca %"compiler/eval:Ptr"
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/mir:Lvalue"
  %l49 = alloca { %"compiler/eval:Ptr", i32 }
  %l50 = alloca %"compiler/eval:Ptr"
  %l51 = alloca i32
  %l52 = alloca i64
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca { i64, [1 x i64] }
  %l55 = alloca i32
  %l56 = alloca { i64, [4 x i64] }
  %l57 = alloca %"compiler/source:Span"
  %l58 = alloca %"compiler/mir:Lvalue"
  %l59 = alloca %"compiler/mir:Lvalue"
  %l60 = alloca { i64, [4 x i64] }
  %l61 = alloca { %"compiler/eval:Ptr", i32 }
  %l62 = alloca %"compiler/eval:Ptr"
  %l63 = alloca i32
  %l64 = alloca { %"compiler/eval:Ptr", i32 }
  %l65 = alloca %"compiler/eval:Ptr"
  %l66 = alloca i32
  %l67 = alloca { %"compiler/eval:Ptr", i64 }
  %l68 = alloca %"compiler/eval:Ptr"
  %l69 = alloca i64
  %l70 = alloca { %"compiler/eval:Ptr", i64 }
  %l71 = alloca %"compiler/eval:Ptr"
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l76 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l101 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { i64, ptr }
  %l111 = alloca { i64, [21 x i64] }
  %l112 = alloca { i64, [21 x i64] }
  %l121 = alloca i1
  %l126 = alloca i1
  %l132 = alloca { i64, [21 x i64] }
  %l140 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l149 = alloca i64
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l160 = alloca i64
  %l161 = alloca ptr
  %l164 = alloca i64
  %l167 = alloca %"compiler/eval:Ptr"
  %l169 = alloca { i64, [21 x i64] }
  %l173 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l185 = alloca i1
  %l187 = alloca { i64, ptr }
  %l193 = alloca i64
  %l201 = alloca { i64, ptr }
  %l203 = alloca { i64, [21 x i64] }
  %l207 = alloca { i64, ptr }
  %l209 = alloca { i64, ptr }
  %l214 = alloca i64
  %l230 = alloca i64
  %l232 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l252 = alloca %"compiler/eval:scope"
  %l257 = alloca %"compiler/eval:scope"
  %l264 = alloca %"compiler/eval:Ptr"
  %l272 = alloca %"compiler/eval:scope"
  %l277 = alloca %"compiler/eval:scope"
  %l278 = alloca { i64, [21 x i64] }
  %l286 = alloca { i64, ptr }
  %l288 = alloca { i64, ptr }
  %l296 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l306 = alloca i1
  %l311 = alloca { i64, ptr }
  %l313 = alloca { i64, [21 x i64] }
  %l320 = alloca { i64, [21 x i64] }
  %l345 = alloca { i64, [21 x i64] }
  %l349 = alloca { i64, ptr }
  %l351 = alloca { i64, ptr }
  %l359 = alloca { i64, ptr }
  %l361 = alloca { i64, ptr }
  %l371 = alloca { i64, [21 x i64] }
  %l383 = alloca i64
  %l387 = alloca i1
  %l392 = alloca i1
  %l396 = alloca i1
  %l399 = alloca i1
  %l403 = alloca ptr
  %l407 = alloca %"compiler/eval:Ptr"
  %l408 = alloca %"compiler/eval:Ptr"
  %l415 = alloca { i64, [21 x i64] }
  %l426 = alloca { %"compiler/eval:Ptr", i32 }
  %l428 = alloca ptr
  %l432 = alloca i64
  %l435 = alloca { i64, [21 x i64] }
  %l445 = alloca { %"compiler/eval:Ptr", i32 }
  %l450 = alloca i64
  %l456 = alloca i64
  %l460 = alloca { i64, ptr }
  %l462 = alloca { i64, [21 x i64] }
  %l476 = alloca { i64, [21 x i64] }
  %l488 = alloca { %"compiler/eval:Ptr", i32 }
  %l494 = alloca { %"compiler/eval:Ptr", i32 }
  %l500 = alloca { %"compiler/eval:Ptr", i64 }
  %l506 = alloca { %"compiler/eval:Ptr", i64 }
  %l509 = alloca ptr
  %l513 = alloca i64
  %l517 = alloca i32
  %l518 = alloca i64
  %l523 = alloca i1
  %l527 = alloca i1
  %l533 = alloca ptr
  %l534 = alloca %"compiler/eval:Ptr"
  %l535 = alloca %"compiler/eval:Ptr"
  %l536 = alloca i64
  %l537 = alloca ptr
  %l540 = alloca i32
  %l541 = alloca i64
  %l543 = alloca { i64, [21 x i64] }
  %l559 = alloca { i64, ptr }
  %l560 = alloca i64
  %t436 = alloca %"compiler/eval:scope", align 8
  %t448 = alloca %"compiler/eval:scope", align 8
  %t476 = alloca %"compiler/eval:scope", align 8
  %t488 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 17
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l78, !tbaa !27
  %t5 = load i64, ptr %l2, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:cfn", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:cfn", ptr %t9, i32 0, i32 13
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l80, !tbaa !27
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = load i64, ptr @G_2ecompiler_2feval_2efastStride, !tbaa !24
  %t16 = mul i64 %t12, %t13
  %t18 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  store i64 %t21, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp ne i64 %t23, 0
  br i1 %t25, label %bb1, label %bb2
bb1:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i64, ptr %l1, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %t27, i64 %t28, i64 %t29, i64 %t30, i64 %t31)
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 13
  %t40 = load i1, ptr %t39, !tbaa !21
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb4, label %bb5
bb4:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 49
  %t47 = load { i64, ptr }, ptr %t46, !tbaa !27
  store { i64, ptr } %t47, ptr %l96, !tbaa !27
  %t48 = load i64, ptr %l1, !tbaa !24
  store i64 %t48, ptr %l97, !tbaa !24
  %t49 = load i64, ptr %l97, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr %"compiler/eval:frame", ptr %t51, i64 %t49
  %t53 = getelementptr %"compiler/eval:frame", ptr %t52, i32 0, i32 2
  %t54 = load i64, ptr %t53, !tbaa !24
  %t56 = add i64 %t54, 1
  %t58 = load i64, ptr %l97, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/eval:frame", ptr %t60, i64 %t58
  %t62 = getelementptr %"compiler/eval:frame", ptr %t61, i32 0, i32 2
  store i64 %t56, ptr %t62, !tbaa !24
  br label %bb6
bb5:
  br label %bb6
bb6:
  br label %ret
bb7:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/eval:Machine", ptr %t63, i32 0, i32 17
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  store { i64, ptr } %t66, ptr %l101, !tbaa !27
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr %"compiler/eval:cfn", ptr %t70, i64 %t67
  %t72 = getelementptr %"compiler/eval:cfn", ptr %t71, i32 0, i32 10
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l103, !tbaa !27
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i1, ptr %t77, i64 %t74
  %t79 = load i1, ptr %t78, !tbaa !31
  store i1 %t79, ptr %l5, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/eval:Machine", ptr %t81, i32 0, i32 17
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l107, !tbaa !27
  %t85 = load i64, ptr %l2, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr %"compiler/eval:cfn", ptr %t88, i64 %t85
  %t90 = getelementptr %"compiler/eval:cfn", ptr %t89, i32 0, i32 7
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  store { i64, ptr } %t91, ptr %l109, !tbaa !27
  %t92 = load i64, ptr %l3, !tbaa !24
  %t94 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !27
  %t96 = getelementptr { i64, [21 x i64] }, ptr %t95, i64 %t92
  call void @llvm.memmove.p0.p0.i64(ptr %l111, ptr %t96, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l111, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l112, ptr %l6, i64 176, i1 false)
  %t97 = load { i64, [21 x i64] }, ptr %l112
  %t98 = extractvalue { i64, [21 x i64] } %t97, 0
  %t99 = icmp eq i64 %t98, 0
  br i1 %t99, label %bb8, label %bb9
bb8:
  %t101 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t102 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t101, i32 0, i32 0
  %t103 = load %"compiler/source:Span", ptr %t102
  store %"compiler/source:Span" %t103, ptr %l7
  %t105 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t105, i32 0, i32 1
  %t107 = load %"compiler/mir:Lvalue", ptr %t106
  store %"compiler/mir:Lvalue" %t107, ptr %l8
  %t109 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } }, ptr %t109, i32 0, i32 2
  %t111 = load { i64, [15 x i64] }, ptr %t110
  store { i64, [15 x i64] } %t111, ptr %l9
  br label %bb10
bb9:
  br label %bb20
bb10:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i64, ptr %l2, !tbaa !24
  %t115 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t113, i64 %t114, %"compiler/source:Span" %t115)
  br label %bb11
bb11:
  %t119 = load i1, ptr %l5, !tbaa !21
  br i1 %t119, label %bb12, label %bb13
bb12:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i64, ptr %l1, !tbaa !24
  %t123 = load %"compiler/mir:Lvalue", ptr %l8
  %t124 = load { i64, [15 x i64] }, ptr %l9
  %t129 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eglobalsReady(ptr %v0, ptr %t121, i64 %t122, %"compiler/mir:Lvalue" %t123, { i64, [15 x i64] } %t124)
  store i1 %t129, ptr %l126
  br label %bb14
bb13:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb15
bb14:
  %t130 = load i1, ptr %l126, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l121, !tbaa !21
  br label %bb15
bb15:
  %t133 = load i1, ptr %l121, !tbaa !21
  br i1 %t133, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  %t136 = load %"compiler/mir:Lvalue", ptr %l8
  %t137 = load { i64, [15 x i64] }, ptr %l9
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eassign(ptr %v0, ptr %t134, i64 %t135, %"compiler/mir:Lvalue" %t136, { i64, [15 x i64] } %t137)
  br label %bb19
bb19:
  br label %bb197
bb20:
  call void @llvm.memmove.p0.p0.i64(ptr %l132, ptr %l6, i64 176, i1 false)
  %t142 = load { i64, [21 x i64] }, ptr %l132
  %t143 = extractvalue { i64, [21 x i64] } %t142, 0
  %t144 = icmp eq i64 %t143, 1
  br i1 %t144, label %bb21, label %bb22
bb21:
  %t146 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t147 = getelementptr { %"compiler/source:Span", i32 }, ptr %t146, i32 0, i32 0
  %t148 = load %"compiler/source:Span", ptr %t147
  store %"compiler/source:Span" %t148, ptr %l10
  %t150 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t151 = getelementptr { %"compiler/source:Span", i32 }, ptr %t150, i32 0, i32 1
  %t152 = load i32, ptr %t151
  store i32 %t152, ptr %l11, !tbaa !23
  br label %bb23
bb22:
  br label %bb31
bb23:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l2, !tbaa !24
  %t156 = load %"compiler/source:Span", ptr %l10
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t154, i64 %t155, %"compiler/source:Span" %t156)
  br label %bb24
bb24:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/eval:Machine", ptr %t160, i32 0, i32 17
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l140, !tbaa !27
  %t164 = load i64, ptr %l2, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr %"compiler/eval:cfn", ptr %t167, i64 %t164
  %t169 = getelementptr %"compiler/eval:cfn", ptr %t168, i32 0, i32 1
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l142, !tbaa !27
  %t171 = load i32, ptr %l11, !tbaa !23
  %t173 = sext i32 %t171 to i64
  %t175 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr %"compiler/mir:Local", ptr %t176, i64 %t173
  %t178 = load %"compiler/mir:Local", ptr %t177
  store %"compiler/mir:Local" %t178, ptr %l12
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  %t182 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 4
  %t183 = load { i64, [1 x i64] }, ptr %t182
  %t187 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %t180, i64 %t181, { i64, [1 x i64] } %t183)
  store i64 %t187, ptr %l149
  br label %bb25
bb25:
  %t188 = load i64, ptr %l149, !tbaa !24
  store i64 %t188, ptr %l13, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/eval:Machine", ptr %t189, i32 0, i32 13
  %t192 = load i1, ptr %t191, !tbaa !21
  br i1 %t192, label %bb26, label %bb27
bb26:
  br label %ret
bb27:
  br label %bb28
bb28:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/eval:Machine", ptr %t194, i32 0, i32 51
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l153, !tbaa !27
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/eval:Machine", ptr %t198, i32 0, i32 49
  %t201 = load { i64, ptr }, ptr %t200, !tbaa !27
  store { i64, ptr } %t201, ptr %l155, !tbaa !27
  %t202 = load i64, ptr %l1, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr %"compiler/eval:frame", ptr %t205, i64 %t202
  %t207 = getelementptr %"compiler/eval:frame", ptr %t206, i32 0, i32 3
  %t208 = load i64, ptr %t207, !tbaa !24
  %t209 = load i32, ptr %l11, !tbaa !23
  %t211 = sext i32 %t209 to i64
  %t214 = add i64 %t208, %t211
  store i64 %t214, ptr %l160, !tbaa !24
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l161, !tbaa !29
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/mir:Local", ptr %l12, i32 0, i32 2
  %t218 = load i32, ptr %t217, !tbaa !23
  %t221 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t216, i32 %t218)
  store i64 %t221, ptr %l164
  br label %bb29
bb29:
  %t222 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t223 = load i64, ptr %l13, !tbaa !24
  %t224 = load ptr, ptr %l161, !tbaa !29
  %t225 = load i64, ptr %l164, !tbaa !24
  %t228 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t224, i64 %t225, i64 %t222, i64 %t223)
  store %"compiler/eval:Ptr" %t228, ptr %l167
  br label %bb30
bb30:
  %t229 = getelementptr %"compiler/eval:Ptr", ptr %l167, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t232 = load i64, ptr %l160, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i64, ptr %t234, i64 %t232
  store i64 %t230, ptr %t235, !tbaa !34
  br label %bb197
bb31:
  call void @llvm.memmove.p0.p0.i64(ptr %l169, ptr %l6, i64 176, i1 false)
  %t236 = load { i64, [21 x i64] }, ptr %l169
  %t237 = extractvalue { i64, [21 x i64] } %t236, 0
  %t238 = icmp eq i64 %t237, 2
  br i1 %t238, label %bb32, label %bb33
bb32:
  %t240 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t241 = getelementptr { %"compiler/source:Span", i32 }, ptr %t240, i32 0, i32 1
  %t242 = load i32, ptr %t241
  store i32 %t242, ptr %l14, !tbaa !23
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/eval:Machine", ptr %t244, i32 0, i32 49
  %t247 = load { i64, ptr }, ptr %t246, !tbaa !27
  store { i64, ptr } %t247, ptr %l173, !tbaa !27
  %t248 = load i64, ptr %l1, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr %"compiler/eval:frame", ptr %t251, i64 %t248
  %t253 = getelementptr %"compiler/eval:frame", ptr %t252, i32 0, i32 3
  %t254 = load i64, ptr %t253, !tbaa !24
  %t255 = load i32, ptr %l14, !tbaa !23
  %t257 = sext i32 %t255 to i64
  %t260 = add i64 %t254, %t257
  store i64 %t260, ptr %l15, !tbaa !24
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/eval:Machine", ptr %t262, i32 0, i32 51
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !27
  store { i64, ptr } %t265, ptr %l180, !tbaa !27
  %t266 = load i64, ptr %l15, !tbaa !24
  %t268 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !27
  %t270 = getelementptr i64, ptr %t269, i64 %t266
  %t271 = load i64, ptr %t270, !tbaa !34
  store i64 %t271, ptr %l16, !tbaa !24
  %t273 = load i64, ptr %l16, !tbaa !24
  %t275 = icmp ne i64 %t273, 0
  br i1 %t275, label %bb35, label %bb36
bb35:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/eval:Machine", ptr %t277, i32 0, i32 40
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l187, !tbaa !27
  %t281 = load i64, ptr %l16, !tbaa !24
  %t282 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t285 = and i64 %t281, %t282
  %t287 = getelementptr { i64, ptr }, ptr %l187, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr %"compiler/eval:alloc", ptr %t288, i64 %t285
  %t290 = getelementptr %"compiler/eval:alloc", ptr %t289, i32 0, i32 3
  %t291 = load i64, ptr %t290, !tbaa !24
  %t292 = load i64, ptr %l16, !tbaa !24
  %t293 = load i64, ptr @G_2ecompiler_2feval_2eslotBits, !tbaa !24
  store i64 %t293, ptr %l193, !tbaa !24
  %t295 = load i64, ptr %l193, !tbaa !24
  %t296 = load i64, ptr %l193, !tbaa !24
  %t297 = ashr i64 %t292, %t296
  %t300 = icmp eq i64 %t291, %t297
  store i1 %t300, ptr %l185, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb37
bb37:
  %t302 = load i1, ptr %l185, !tbaa !21
  br i1 %t302, label %bb38, label %bb39
bb38:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i64, ptr %l16, !tbaa !24
  %t305 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t308 = and i64 %t304, %t305
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %t303, i64 %t308)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/eval:Machine", ptr %t311, i32 0, i32 51
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  store { i64, ptr } %t314, ptr %l201, !tbaa !27
  %t315 = load i64, ptr %l15, !tbaa !24
  %t317 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = getelementptr i64, ptr %t318, i64 %t315
  store i64 0, ptr %t319, !tbaa !34
  br label %bb197
bb42:
  call void @llvm.memmove.p0.p0.i64(ptr %l203, ptr %l6, i64 176, i1 false)
  %t320 = load { i64, [21 x i64] }, ptr %l203
  %t321 = extractvalue { i64, [21 x i64] } %t320, 0
  %t322 = icmp eq i64 %t321, 3
  br i1 %t322, label %bb43, label %bb44
bb43:
  %t324 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t325 = getelementptr { %"compiler/source:Span", i32 }, ptr %t324, i32 0, i32 1
  %t326 = load i32, ptr %t325
  store i32 %t326, ptr %l17, !tbaa !23
  br label %bb45
bb44:
  br label %bb79
bb45:
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/eval:Machine", ptr %t328, i32 0, i32 17
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l207, !tbaa !27
  %t332 = load i64, ptr %l2, !tbaa !24
  %t334 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr %"compiler/eval:cfn", ptr %t335, i64 %t332
  %t337 = getelementptr %"compiler/eval:cfn", ptr %t336, i32 0, i32 2
  %t338 = load { i64, ptr }, ptr %t337, !tbaa !27
  store { i64, ptr } %t338, ptr %l209, !tbaa !27
  %t339 = load i32, ptr %l17, !tbaa !23
  %t341 = sext i32 %t339 to i64
  %t343 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr %"compiler/mir:ScopeInfo", ptr %t344, i64 %t341
  %t346 = load %"compiler/mir:ScopeInfo", ptr %t345
  store %"compiler/mir:ScopeInfo" %t346, ptr %l18
  %t348 = getelementptr %"compiler/mir:ScopeInfo", ptr %l18, i32 0, i32 0
  %t349 = load i32, ptr %t348
  store i32 %t349, ptr %l19
  %t351 = load i32, ptr %l19
  %t353 = trunc i64 5 to i32
  %t354 = icmp eq i32 %t351, %t353
  br i1 %t354, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t356 = load i64, ptr @G_2ecompiler_2feval_2esInert, !tbaa !24
  store i64 %t356, ptr %l214, !tbaa !24
  br label %bb66
bb49:
  %t358 = load i32, ptr %l19
  %t360 = trunc i64 6 to i32
  %t361 = icmp eq i32 %t358, %t360
  br i1 %t361, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  %t363 = load i64, ptr @G_2ecompiler_2feval_2esBuilder, !tbaa !24
  store i64 %t363, ptr %l214, !tbaa !24
  br label %bb66
bb53:
  %t365 = load i32, ptr %l19
  %t367 = trunc i64 4 to i32
  %t368 = icmp eq i32 %t365, %t367
  br i1 %t368, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  %t370 = load i64, ptr @G_2ecompiler_2feval_2esRegion, !tbaa !24
  store i64 %t370, ptr %l214, !tbaa !24
  br label %bb66
bb57:
  %t372 = load i32, ptr %l19
  %t374 = trunc i64 3 to i32
  %t375 = icmp eq i32 %t372, %t374
  br i1 %t375, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  %t377 = load i64, ptr @G_2ecompiler_2feval_2esJoin, !tbaa !24
  store i64 %t377, ptr %l214, !tbaa !24
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  %t379 = load i64, ptr @G_2ecompiler_2feval_2esBlock, !tbaa !24
  store i64 %t379, ptr %l214, !tbaa !24
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_fe5b662c8cf4b58_7006b7c636f2421c)
  unreachable
bb66:
  %t381 = load i64, ptr %l214, !tbaa !24
  store i64 %t381, ptr %l20, !tbaa !24
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t383 = load i64, ptr %l20, !tbaa !24
  %t386 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScope(ptr %v0, ptr %t382, i64 %t383)
  store i64 %t386, ptr %l230
  br label %bb67
bb67:
  %t387 = load i64, ptr %l230, !tbaa !24
  store i64 %t387, ptr %l21, !tbaa !24
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/eval:Machine", ptr %t388, i32 0, i32 51
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  store { i64, ptr } %t391, ptr %l232, !tbaa !27
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/eval:Machine", ptr %t392, i32 0, i32 49
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !27
  store { i64, ptr } %t395, ptr %l234, !tbaa !27
  %t396 = load i64, ptr %l1, !tbaa !24
  %t398 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t399 = load ptr, ptr %t398, !tbaa !27
  %t400 = getelementptr %"compiler/eval:frame", ptr %t399, i64 %t396
  %t401 = getelementptr %"compiler/eval:frame", ptr %t400, i32 0, i32 4
  %t402 = load i64, ptr %t401, !tbaa !24
  %t403 = load i32, ptr %l17, !tbaa !23
  %t405 = sext i32 %t403 to i64
  %t408 = add i64 %t402, %t405
  %t409 = load i64, ptr %l21, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i64, ptr %t413, i64 %t408
  store i64 %t409, ptr %t414, !tbaa !34
  %t415 = load i64, ptr %l20, !tbaa !24
  %t416 = load i64, ptr @G_2ecompiler_2feval_2esJoin, !tbaa !24
  %t419 = icmp eq i64 %t415, %t416
  br i1 %t419, label %bb68, label %bb69
bb68:
  %t421 = load i64, ptr %l21, !tbaa !24
  %t422 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t425 = and i64 %t421, %t422
  store i64 %t425, ptr %l22, !tbaa !24
  %t427 = getelementptr %"compiler/mir:ScopeInfo", ptr %l18, i32 0, i32 4
  %t428 = load i32, ptr %t427, !tbaa !23
  %t430 = sext i32 %t428 to i64
  store i64 %t430, ptr %l23, !tbaa !24
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/eval:Machine", ptr %t432, i32 0, i32 43
  %t435 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t436, ptr %v0, ptr %t434, i64 %t435)
  call void @llvm.memmove.p0.p0.i64(ptr %l252, ptr %t436, i64 136, i1 false)
  br label %bb70
bb69:
  br label %bb72
bb70:
  call void @llvm.memmove.p0.p0.i64(ptr %l24, ptr %l252, i64 136, i1 false)
  %t439 = load i64, ptr %l23, !tbaa !24
  %t441 = getelementptr %"compiler/eval:scope", ptr %l24, i32 0, i32 13
  store i64 %t439, ptr %t441, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/eval:Machine", ptr %t442, i32 0, i32 43
  %t445 = load i64, ptr %l22, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l257, ptr %l24, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t448, ptr %l257, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t444, i64 %t445, ptr %t448)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t449 = load i64, ptr %l20, !tbaa !24
  %t450 = load i64, ptr @G_2ecompiler_2feval_2esBuilder, !tbaa !24
  %t453 = icmp eq i64 %t449, %t450
  br i1 %t453, label %bb73, label %bb74
bb73:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i64, ptr @G_2ecompiler_2feval_2eaValue, !tbaa !24
  %t457 = load i64, ptr %l21, !tbaa !24
  %t461 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %t455, i64 64, i64 %t456, i64 %t457)
  store %"compiler/eval:Ptr" %t461, ptr %l264
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t462 = load %"compiler/eval:Ptr", ptr %l264
  store %"compiler/eval:Ptr" %t462, ptr %l25
  %t463 = load i64, ptr %l21, !tbaa !24
  %t464 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t467 = and i64 %t463, %t464
  store i64 %t467, ptr %l26, !tbaa !24
  %t469 = getelementptr %"compiler/eval:Ptr", ptr %l25, i32 0, i32 0
  %t470 = load i64, ptr %t469, !tbaa !24
  store i64 %t470, ptr %l27, !tbaa !24
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/eval:Machine", ptr %t472, i32 0, i32 43
  %t475 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t476, ptr %v0, ptr %t474, i64 %t475)
  call void @llvm.memmove.p0.p0.i64(ptr %l272, ptr %t476, i64 136, i1 false)
  br label %bb76
bb76:
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %l272, i64 136, i1 false)
  %t479 = load i64, ptr %l27, !tbaa !24
  %t481 = getelementptr %"compiler/eval:scope", ptr %l28, i32 0, i32 8
  store i64 %t479, ptr %t481, !tbaa !24
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/eval:Machine", ptr %t482, i32 0, i32 43
  %t485 = load i64, ptr %l26, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l277, ptr %l28, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t488, ptr %l277, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t484, i64 %t485, ptr %t488)
  br label %bb77
bb77:
  br label %bb78
bb78:
  br label %bb197
bb79:
  call void @llvm.memmove.p0.p0.i64(ptr %l278, ptr %l6, i64 176, i1 false)
  %t489 = load { i64, [21 x i64] }, ptr %l278
  %t490 = extractvalue { i64, [21 x i64] } %t489, 0
  %t491 = icmp eq i64 %t490, 4
  br i1 %t491, label %bb80, label %bb81
bb80:
  %t493 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", i32 }, ptr %t493, i32 0, i32 1
  %t495 = load i32, ptr %t494
  store i32 %t495, ptr %l29, !tbaa !23
  br label %bb82
bb81:
  br label %bb89
bb82:
  %t497 = load ptr, ptr %l0, !tbaa !29
  %t498 = load i64, ptr %l1, !tbaa !24
  %t499 = load i32, ptr %l29, !tbaa !23
  %t501 = sext i32 %t499 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropDefers(ptr %v0, ptr %t497, i64 %t498, i64 %t501, i1 false)
  br label %bb83
bb83:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t507 = getelementptr %"compiler/eval:Machine", ptr %t505, i32 0, i32 51
  %t508 = load { i64, ptr }, ptr %t507, !tbaa !27
  store { i64, ptr } %t508, ptr %l286, !tbaa !27
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t511 = getelementptr %"compiler/eval:Machine", ptr %t509, i32 0, i32 49
  %t512 = load { i64, ptr }, ptr %t511, !tbaa !27
  store { i64, ptr } %t512, ptr %l288, !tbaa !27
  %t513 = load i64, ptr %l1, !tbaa !24
  %t515 = getelementptr { i64, ptr }, ptr %l288, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = getelementptr %"compiler/eval:frame", ptr %t516, i64 %t513
  %t518 = getelementptr %"compiler/eval:frame", ptr %t517, i32 0, i32 4
  %t519 = load i64, ptr %t518, !tbaa !24
  %t520 = load i32, ptr %l29, !tbaa !23
  %t522 = sext i32 %t520 to i64
  %t525 = add i64 %t519, %t522
  %t527 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !27
  %t529 = getelementptr i64, ptr %t528, i64 %t525
  %t530 = load i64, ptr %t529, !tbaa !34
  store i64 %t530, ptr %l30, !tbaa !24
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = getelementptr %"compiler/eval:Machine", ptr %t532, i32 0, i32 51
  %t535 = load { i64, ptr }, ptr %t534, !tbaa !27
  store { i64, ptr } %t535, ptr %l296, !tbaa !27
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/eval:Machine", ptr %t536, i32 0, i32 49
  %t539 = load { i64, ptr }, ptr %t538, !tbaa !27
  store { i64, ptr } %t539, ptr %l298, !tbaa !27
  %t540 = load i64, ptr %l1, !tbaa !24
  %t542 = getelementptr { i64, ptr }, ptr %l298, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = getelementptr %"compiler/eval:frame", ptr %t543, i64 %t540
  %t545 = getelementptr %"compiler/eval:frame", ptr %t544, i32 0, i32 4
  %t546 = load i64, ptr %t545, !tbaa !24
  %t547 = load i32, ptr %l29, !tbaa !23
  %t549 = sext i32 %t547 to i64
  %t552 = add i64 %t546, %t549
  %t554 = getelementptr { i64, ptr }, ptr %l296, i32 0, i32 1
  %t555 = load ptr, ptr %t554, !tbaa !27
  %t556 = getelementptr i64, ptr %t555, i64 %t552
  store i64 0, ptr %t556, !tbaa !34
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t558 = load i64, ptr %l30, !tbaa !24
  %t561 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t557, i64 %t558)
  store i1 %t561, ptr %l306
  br label %bb84
bb84:
  %t562 = load i1, ptr %l306, !tbaa !21
  br i1 %t562, label %bb85, label %bb86
bb85:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t565 = getelementptr %"compiler/eval:Machine", ptr %t563, i32 0, i32 53
  %t566 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t565, i64 %t566)
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t571 = getelementptr %"compiler/eval:Machine", ptr %t569, i32 0, i32 49
  %t572 = load { i64, ptr }, ptr %t571, !tbaa !27
  store { i64, ptr } %t572, ptr %l311, !tbaa !27
  %t573 = load i64, ptr %l1, !tbaa !24
  %t575 = getelementptr { i64, ptr }, ptr %l311, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !27
  %t577 = getelementptr %"compiler/eval:frame", ptr %t576, i64 %t573
  %t578 = getelementptr %"compiler/eval:frame", ptr %t577, i32 0, i32 10
  store i1 true, ptr %t578, !tbaa !21
  br label %ret
bb88:
  br label %bb197
bb89:
  call void @llvm.memmove.p0.p0.i64(ptr %l313, ptr %l6, i64 176, i1 false)
  %t579 = load { i64, [21 x i64] }, ptr %l313
  %t580 = extractvalue { i64, [21 x i64] } %t579, 0
  %t581 = icmp eq i64 %t580, 12
  br i1 %t581, label %bb90, label %bb91
bb90:
  %t583 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t584 = getelementptr { %"compiler/source:Span" }, ptr %t583, i32 0, i32 0
  %t585 = load %"compiler/source:Span", ptr %t584
  store %"compiler/source:Span" %t585, ptr %l31
  br label %bb92
bb91:
  br label %bb94
bb92:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load i64, ptr %l1, !tbaa !24
  %t589 = load i64, ptr %l2, !tbaa !24
  %t590 = load %"compiler/source:Span", ptr %l31
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2etraced(ptr %v0, ptr %t587, i64 %t588, i64 %t589, %"compiler/source:Span" %t590)
  br label %bb93
bb93:
  br label %bb197
bb94:
  call void @llvm.memmove.p0.p0.i64(ptr %l320, ptr %l6, i64 176, i1 false)
  %t595 = load { i64, [21 x i64] }, ptr %l320
  %t596 = extractvalue { i64, [21 x i64] } %t595, 0
  %t597 = icmp eq i64 %t596, 13
  br i1 %t597, label %bb95, label %bb96
bb95:
  %t599 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t600 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t599, i32 0, i32 1
  %t601 = load i32, ptr %t600
  store i32 %t601, ptr %l32, !tbaa !23
  %t603 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t604 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t603, i32 0, i32 2
  %t605 = load i32, ptr %t604
  store i32 %t605, ptr %l33, !tbaa !23
  br label %bb97
bb96:
  br label %bb108
bb97:
  %t607 = load i32, ptr %l33, !tbaa !23
  %t608 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t611 = icmp eq i32 %t607, %t608
  br i1 %t611, label %bb98, label %bb99
bb98:
  %t613 = load ptr, ptr %l0, !tbaa !29
  %t614 = load i64, ptr %l1, !tbaa !24
  %t615 = load i32, ptr %l32, !tbaa !23
  %t617 = sext i32 %t615 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropDefers(ptr %v0, ptr %t613, i64 %t614, i64 %t617, i1 true)
  br label %bb100
bb99:
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = getelementptr %"compiler/eval:Machine", ptr %t621, i32 0, i32 1
  %t624 = load i32, ptr %t623
  %t626 = trunc i64 1 to i32
  %t627 = icmp eq i32 %t624, %t626
  br i1 %t627, label %bb101, label %bb102
bb100:
  br label %bb107
bb101:
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t631 = getelementptr %"compiler/eval:Machine", ptr %t629, i32 0, i32 57
  %t632 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t631, i64 %t632)
  br label %bb103
bb102:
  br label %bb106
bb103:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/eval:Machine", ptr %t635, i32 0, i32 58
  %t638 = load i32, ptr %l32, !tbaa !23
  %t640 = sext i32 %t638 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t637, i64 %t640)
  br label %bb104
bb104:
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t645 = getelementptr %"compiler/eval:Machine", ptr %t643, i32 0, i32 59
  %t646 = load i32, ptr %l33, !tbaa !23
  %t648 = sext i32 %t646 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t645, i64 %t648)
  br label %bb105
bb105:
  br label %bb106
bb106:
  br label %bb107
bb107:
  br label %bb197
bb108:
  call void @llvm.memmove.p0.p0.i64(ptr %l345, ptr %l6, i64 176, i1 false)
  %t651 = load { i64, [21 x i64] }, ptr %l345
  %t652 = extractvalue { i64, [21 x i64] } %t651, 0
  %t653 = icmp eq i64 %t652, 5
  br i1 %t653, label %bb109, label %bb110
bb109:
  %t655 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t656 = getelementptr { %"compiler/source:Span", i32 }, ptr %t655, i32 0, i32 1
  %t657 = load i32, ptr %t656
  store i32 %t657, ptr %l34, !tbaa !23
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t659 = load ptr, ptr %l0, !tbaa !29
  %t661 = getelementptr %"compiler/eval:Machine", ptr %t659, i32 0, i32 51
  %t662 = load { i64, ptr }, ptr %t661, !tbaa !27
  store { i64, ptr } %t662, ptr %l349, !tbaa !27
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t665 = getelementptr %"compiler/eval:Machine", ptr %t663, i32 0, i32 49
  %t666 = load { i64, ptr }, ptr %t665, !tbaa !27
  store { i64, ptr } %t666, ptr %l351, !tbaa !27
  %t667 = load i64, ptr %l1, !tbaa !24
  %t669 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !27
  %t671 = getelementptr %"compiler/eval:frame", ptr %t670, i64 %t667
  %t672 = getelementptr %"compiler/eval:frame", ptr %t671, i32 0, i32 4
  %t673 = load i64, ptr %t672, !tbaa !24
  %t674 = load i32, ptr %l34, !tbaa !23
  %t676 = sext i32 %t674 to i64
  %t679 = add i64 %t673, %t676
  %t681 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t682 = load ptr, ptr %t681, !tbaa !27
  %t683 = getelementptr i64, ptr %t682, i64 %t679
  %t684 = load i64, ptr %t683, !tbaa !34
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/eval:Machine", ptr %t686, i32 0, i32 51
  %t689 = load { i64, ptr }, ptr %t688, !tbaa !27
  store { i64, ptr } %t689, ptr %l359, !tbaa !27
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t692 = getelementptr %"compiler/eval:Machine", ptr %t690, i32 0, i32 49
  %t693 = load { i64, ptr }, ptr %t692, !tbaa !27
  store { i64, ptr } %t693, ptr %l361, !tbaa !27
  %t694 = load i64, ptr %l1, !tbaa !24
  %t696 = getelementptr { i64, ptr }, ptr %l361, i32 0, i32 1
  %t697 = load ptr, ptr %t696, !tbaa !27
  %t698 = getelementptr %"compiler/eval:frame", ptr %t697, i64 %t694
  %t699 = getelementptr %"compiler/eval:frame", ptr %t698, i32 0, i32 4
  %t700 = load i64, ptr %t699, !tbaa !24
  %t701 = load i32, ptr %l34, !tbaa !23
  %t703 = sext i32 %t701 to i64
  %t706 = add i64 %t700, %t703
  %t708 = getelementptr { i64, ptr }, ptr %l359, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !27
  %t710 = getelementptr i64, ptr %t709, i64 %t706
  store i64 0, ptr %t710, !tbaa !34
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t713 = load ptr, ptr %l0, !tbaa !29
  %t715 = getelementptr %"compiler/eval:Machine", ptr %t713, i32 0, i32 65
  %t716 = load i64, ptr %t715, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eadopt(ptr %v0, ptr %t711, i64 %t684, i64 %t716)
  br label %bb112
bb112:
  br label %bb197
bb113:
  call void @llvm.memmove.p0.p0.i64(ptr %l371, ptr %l6, i64 176, i1 false)
  %t720 = load { i64, [21 x i64] }, ptr %l371
  %t721 = extractvalue { i64, [21 x i64] } %t720, 0
  %t722 = icmp eq i64 %t721, 6
  br i1 %t722, label %bb114, label %bb115
bb114:
  %t724 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t725 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t724, i32 0, i32 0
  %t726 = load %"compiler/source:Span", ptr %t725
  store %"compiler/source:Span" %t726, ptr %l36
  %t728 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t729 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t728, i32 0, i32 1
  %t730 = load { i64, [1 x i64] }, ptr %t729
  store { i64, [1 x i64] } %t730, ptr %l37
  %t732 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t733 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t732, i32 0, i32 2
  %t734 = load i32, ptr %t733
  store i32 %t734, ptr %l38, !tbaa !23
  %t736 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t737 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t736, i32 0, i32 3
  %t738 = load { i64, [4 x i64] }, ptr %t737
  store { i64, [4 x i64] } %t738, ptr %l39
  br label %bb116
bb115:
  br label %bb136
bb116:
  %t740 = load ptr, ptr %l0, !tbaa !29
  %t741 = load i64, ptr %l2, !tbaa !24
  %t742 = load %"compiler/source:Span", ptr %l36
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t740, i64 %t741, %"compiler/source:Span" %t742)
  br label %bb117
bb117:
  %t746 = load ptr, ptr %l0, !tbaa !29
  %t747 = load i64, ptr %l1, !tbaa !24
  %t748 = load { i64, [1 x i64] }, ptr %l37
  %t752 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t746, i64 %t747, { i64, [1 x i64] } %t748)
  store i64 %t752, ptr %l383
  br label %bb118
bb118:
  %t753 = load i64, ptr %l383, !tbaa !24
  store i64 %t753, ptr %l40, !tbaa !24
  %t754 = load ptr, ptr %l0, !tbaa !29
  %t756 = getelementptr %"compiler/eval:Machine", ptr %t754, i32 0, i32 1
  %t757 = load i32, ptr %t756
  %t759 = trunc i64 0 to i32
  %t760 = icmp eq i32 %t757, %t759
  br i1 %t760, label %bb119, label %bb120
bb119:
  %t762 = load i64, ptr %l40, !tbaa !24
  %t763 = load ptr, ptr %l0, !tbaa !29
  %t765 = getelementptr %"compiler/eval:Machine", ptr %t763, i32 0, i32 61
  %t766 = load i64, ptr %t765, !tbaa !24
  %t769 = icmp eq i64 %t762, %t766
  br i1 %t769, label %bb121, label %bb122
bb120:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb128
bb121:
  %t771 = load ptr, ptr %l0, !tbaa !29
  %t773 = getelementptr %"compiler/eval:Machine", ptr %t771, i32 0, i32 64
  %t774 = load i64, ptr %t773, !tbaa !24
  %t776 = icmp sge i64 %t774, 0
  store i1 %t776, ptr %l392, !tbaa !21
  br label %bb123
bb122:
  store i1 false, ptr %l392, !tbaa !21
  br label %bb123
bb123:
  %t778 = load i1, ptr %l392, !tbaa !21
  br i1 %t778, label %bb124, label %bb125
bb124:
  %t779 = load ptr, ptr %l0, !tbaa !29
  %t780 = load i64, ptr %l1, !tbaa !24
  %t783 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2einitFrame(ptr %v0, ptr %t779, i64 %t780)
  store i1 %t783, ptr %l399
  br label %bb126
bb125:
  store i1 false, ptr %l396, !tbaa !21
  br label %bb127
bb126:
  %t784 = load i1, ptr %l399, !tbaa !21
  store i1 %t784, ptr %l396, !tbaa !21
  br label %bb127
bb127:
  %t785 = load i1, ptr %l396, !tbaa !21
  %t786 = xor i1 %t785, true
  store i1 %t786, ptr %l387, !tbaa !21
  br label %bb128
bb128:
  %t788 = load i1, ptr %l387, !tbaa !21
  br i1 %t788, label %bb129, label %bb130
bb129:
  %t789 = load ptr, ptr %l0, !tbaa !29
  %t790 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyDestructor, !tbaa !27
  %t791 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t791, ptr %t789, { i64, ptr } %t790)
  br label %bb131
bb130:
  br label %bb132
bb131:
  br label %ret
bb132:
  %t794 = load ptr, ptr %l0, !tbaa !29
  store ptr %t794, ptr %l403, !tbaa !29
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t796 = load i64, ptr %l1, !tbaa !24
  %t797 = load { i64, [4 x i64] }, ptr %l39
  %t801 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t795, i64 %t796, { i64, [4 x i64] } %t797, i64 1)
  store %"compiler/eval:Ptr" %t801, ptr %l407
  br label %bb133
bb133:
  %t802 = load ptr, ptr %l403, !tbaa !29
  %t803 = load %"compiler/eval:Ptr", ptr %l407
  %t804 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t802, %"compiler/eval:Ptr" %t803)
  store %"compiler/eval:Ptr" %t804, ptr %l408
  br label %bb134
bb134:
  %t805 = load %"compiler/eval:Ptr", ptr %l408
  %t806 = load ptr, ptr %l0, !tbaa !29
  %t807 = load i64, ptr %l40, !tbaa !24
  %t808 = load i64, ptr @G_2ecompiler_2feval_2egDtor, !tbaa !24
  %t809 = load i32, ptr %l38, !tbaa !23
  %t811 = sext i32 %t809 to i64
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %t806, i64 %t807, i64 %t808, i64 %t811, %"compiler/eval:Ptr" %t805)
  br label %bb135
bb135:
  br label %bb197
bb136:
  call void @llvm.memmove.p0.p0.i64(ptr %l415, ptr %l6, i64 176, i1 false)
  %t818 = load { i64, [21 x i64] }, ptr %l415
  %t819 = extractvalue { i64, [21 x i64] } %t818, 0
  %t820 = icmp eq i64 %t819, 7
  br i1 %t820, label %bb137, label %bb138
bb137:
  %t822 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t823 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Lvalue" }, ptr %t822, i32 0, i32 0
  %t824 = load %"compiler/source:Span", ptr %t823
  store %"compiler/source:Span" %t824, ptr %l42
  %t826 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t827 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Lvalue" }, ptr %t826, i32 0, i32 1
  %t828 = load { i64, [1 x i64] }, ptr %t827
  store { i64, [1 x i64] } %t828, ptr %l43
  %t830 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t831 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, %"compiler/mir:Lvalue" }, ptr %t830, i32 0, i32 2
  %t832 = load %"compiler/mir:Lvalue", ptr %t831
  store %"compiler/mir:Lvalue" %t832, ptr %l44
  br label %bb139
bb138:
  br label %bb144
bb139:
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = load i64, ptr %l2, !tbaa !24
  %t836 = load %"compiler/source:Span", ptr %l42
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t834, i64 %t835, %"compiler/source:Span" %t836)
  br label %bb140
bb140:
  %t840 = load ptr, ptr %l0, !tbaa !29
  %t841 = load i64, ptr %l1, !tbaa !24
  %t842 = load %"compiler/mir:Lvalue", ptr %l44
  %t846 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t840, i64 %t841, %"compiler/mir:Lvalue" %t842)
  store { %"compiler/eval:Ptr", i32 } %t846, ptr %l426
  br label %bb141
bb141:
  %t847 = load { %"compiler/eval:Ptr", i32 }, ptr %l426
  store { %"compiler/eval:Ptr", i32 } %t847, ptr %l45
  %t848 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l45, i32 0, i32 0
  %t849 = load %"compiler/eval:Ptr", ptr %t848
  store %"compiler/eval:Ptr" %t849, ptr %l46
  %t851 = load ptr, ptr %l0, !tbaa !29
  store ptr %t851, ptr %l428, !tbaa !29
  %t852 = load ptr, ptr %l0, !tbaa !29
  %t853 = load i64, ptr %l1, !tbaa !24
  %t854 = load { i64, [1 x i64] }, ptr %l43
  %t858 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %t852, i64 %t853, { i64, [1 x i64] } %t854)
  store i64 %t858, ptr %l432
  br label %bb142
bb142:
  %t859 = load i64, ptr @G_2ecompiler_2feval_2egOwner, !tbaa !24
  %t860 = load %"compiler/eval:Ptr", ptr %l46
  %t861 = load ptr, ptr %l428, !tbaa !29
  %t862 = load i64, ptr %l432, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %t861, i64 %t862, i64 %t859, i64 0, %"compiler/eval:Ptr" %t860)
  br label %bb143
bb143:
  br label %bb197
bb144:
  call void @llvm.memmove.p0.p0.i64(ptr %l435, ptr %l6, i64 176, i1 false)
  %t865 = load { i64, [21 x i64] }, ptr %l435
  %t866 = extractvalue { i64, [21 x i64] } %t865, 0
  %t867 = icmp eq i64 %t866, 8
  br i1 %t867, label %bb145, label %bb146
bb145:
  %t869 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t870 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t869, i32 0, i32 0
  %t871 = load %"compiler/source:Span", ptr %t870
  store %"compiler/source:Span" %t871, ptr %l47
  %t873 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t874 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue" }, ptr %t873, i32 0, i32 1
  %t875 = load %"compiler/mir:Lvalue", ptr %t874
  store %"compiler/mir:Lvalue" %t875, ptr %l48
  br label %bb147
bb146:
  br label %bb156
bb147:
  %t877 = load ptr, ptr %l0, !tbaa !29
  %t878 = load i64, ptr %l2, !tbaa !24
  %t879 = load %"compiler/source:Span", ptr %l47
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t877, i64 %t878, %"compiler/source:Span" %t879)
  br label %bb148
bb148:
  %t883 = load ptr, ptr %l0, !tbaa !29
  %t884 = load i64, ptr %l1, !tbaa !24
  %t885 = load %"compiler/mir:Lvalue", ptr %l48
  %t889 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t883, i64 %t884, %"compiler/mir:Lvalue" %t885)
  store { %"compiler/eval:Ptr", i32 } %t889, ptr %l445
  br label %bb149
bb149:
  %t890 = load { %"compiler/eval:Ptr", i32 }, ptr %l445
  store { %"compiler/eval:Ptr", i32 } %t890, ptr %l49
  %t891 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l49, i32 0, i32 0
  %t892 = load %"compiler/eval:Ptr", ptr %t891
  store %"compiler/eval:Ptr" %t892, ptr %l50
  %t894 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l49, i32 0, i32 1
  %t895 = load i32, ptr %t894, !tbaa !23
  store i32 %t895, ptr %l51, !tbaa !23
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t899 = getelementptr %"compiler/eval:Machine", ptr %t897, i32 0, i32 53
  %t901 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t899)
  store i64 %t901, ptr %l450
  br label %bb150
bb150:
  %t902 = load i64, ptr %l450, !tbaa !24
  store i64 %t902, ptr %l52, !tbaa !24
  %t903 = load ptr, ptr %l0, !tbaa !29
  %t904 = load %"compiler/eval:Ptr", ptr %l50
  %t905 = load i32, ptr %l51, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereleaseHeld(ptr %v0, ptr %t903, %"compiler/eval:Ptr" %t904, i32 %t905)
  br label %bb151
bb151:
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t911 = getelementptr %"compiler/eval:Machine", ptr %t909, i32 0, i32 53
  %t913 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t911)
  store i64 %t913, ptr %l456
  br label %bb152
bb152:
  %t914 = load i64, ptr %l52, !tbaa !24
  %t915 = load i64, ptr %l456, !tbaa !24
  %t917 = icmp sgt i64 %t915, %t914
  br i1 %t917, label %bb153, label %bb154
bb153:
  %t919 = load ptr, ptr %l0, !tbaa !29
  %t921 = getelementptr %"compiler/eval:Machine", ptr %t919, i32 0, i32 49
  %t922 = load { i64, ptr }, ptr %t921, !tbaa !27
  store { i64, ptr } %t922, ptr %l460, !tbaa !27
  %t923 = load i64, ptr %l1, !tbaa !24
  %t925 = getelementptr { i64, ptr }, ptr %l460, i32 0, i32 1
  %t926 = load ptr, ptr %t925, !tbaa !27
  %t927 = getelementptr %"compiler/eval:frame", ptr %t926, i64 %t923
  %t928 = getelementptr %"compiler/eval:frame", ptr %t927, i32 0, i32 10
  store i1 true, ptr %t928, !tbaa !21
  br label %ret
bb154:
  br label %bb155
bb155:
  br label %bb197
bb156:
  call void @llvm.memmove.p0.p0.i64(ptr %l462, ptr %l6, i64 176, i1 false)
  %t929 = load { i64, [21 x i64] }, ptr %l462
  %t930 = extractvalue { i64, [21 x i64] } %t929, 0
  %t931 = icmp eq i64 %t930, 9
  br i1 %t931, label %bb157, label %bb158
bb157:
  %t933 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t934 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t933, i32 0, i32 0
  %t935 = load %"compiler/source:Span", ptr %t934
  store %"compiler/source:Span" %t935, ptr %l53
  %t937 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t938 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t937, i32 0, i32 1
  %t939 = load { i64, [1 x i64] }, ptr %t938
  store { i64, [1 x i64] } %t939, ptr %l54
  %t941 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t942 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t941, i32 0, i32 2
  %t943 = load i32, ptr %t942
  store i32 %t943, ptr %l55
  %t945 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t946 = getelementptr { %"compiler/source:Span", { i64, [1 x i64] }, i32, { i64, [4 x i64] } }, ptr %t945, i32 0, i32 3
  %t947 = load { i64, [4 x i64] }, ptr %t946
  store { i64, [4 x i64] } %t947, ptr %l56
  br label %bb159
bb158:
  br label %bb162
bb159:
  %t949 = load ptr, ptr %l0, !tbaa !29
  %t950 = load i64, ptr %l2, !tbaa !24
  %t951 = load %"compiler/source:Span", ptr %l53
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t949, i64 %t950, %"compiler/source:Span" %t951)
  br label %bb160
bb160:
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t956 = load i64, ptr %l1, !tbaa !24
  %t957 = load { i64, [1 x i64] }, ptr %l54
  %t958 = load i32, ptr %l55
  %t959 = load { i64, [4 x i64] }, ptr %l56
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrite(ptr %v0, ptr %t955, i64 %t956, { i64, [1 x i64] } %t957, i32 %t958, { i64, [4 x i64] } %t959)
  br label %bb161
bb161:
  br label %bb197
bb162:
  call void @llvm.memmove.p0.p0.i64(ptr %l476, ptr %l6, i64 176, i1 false)
  %t965 = load { i64, [21 x i64] }, ptr %l476
  %t966 = extractvalue { i64, [21 x i64] } %t965, 0
  %t967 = icmp eq i64 %t966, 10
  br i1 %t967, label %bb163, label %bb164
bb163:
  %t969 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t970 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t969, i32 0, i32 0
  %t971 = load %"compiler/source:Span", ptr %t970
  store %"compiler/source:Span" %t971, ptr %l57
  %t973 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t974 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t973, i32 0, i32 1
  %t975 = load %"compiler/mir:Lvalue", ptr %t974
  store %"compiler/mir:Lvalue" %t975, ptr %l58
  %t977 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t978 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t977, i32 0, i32 2
  %t979 = load %"compiler/mir:Lvalue", ptr %t978
  store %"compiler/mir:Lvalue" %t979, ptr %l59
  %t981 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t982 = getelementptr { %"compiler/source:Span", %"compiler/mir:Lvalue", %"compiler/mir:Lvalue", { i64, [4 x i64] } }, ptr %t981, i32 0, i32 3
  %t983 = load { i64, [4 x i64] }, ptr %t982
  store { i64, [4 x i64] } %t983, ptr %l60
  br label %bb165
bb164:
  br label %bb190
bb165:
  %t985 = load ptr, ptr %l0, !tbaa !29
  %t986 = load i64, ptr %l2, !tbaa !24
  %t987 = load %"compiler/source:Span", ptr %l57
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t985, i64 %t986, %"compiler/source:Span" %t987)
  br label %bb166
bb166:
  %t991 = load ptr, ptr %l0, !tbaa !29
  %t992 = load i64, ptr %l1, !tbaa !24
  %t993 = load %"compiler/mir:Lvalue", ptr %l58
  %t997 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t991, i64 %t992, %"compiler/mir:Lvalue" %t993)
  store { %"compiler/eval:Ptr", i32 } %t997, ptr %l488
  br label %bb167
bb167:
  %t998 = load { %"compiler/eval:Ptr", i32 }, ptr %l488
  store { %"compiler/eval:Ptr", i32 } %t998, ptr %l61
  %t999 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l61, i32 0, i32 0
  %t1000 = load %"compiler/eval:Ptr", ptr %t999
  store %"compiler/eval:Ptr" %t1000, ptr %l62
  %t1002 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l61, i32 0, i32 1
  %t1003 = load i32, ptr %t1002, !tbaa !23
  store i32 %t1003, ptr %l63, !tbaa !23
  %t1005 = load ptr, ptr %l0, !tbaa !29
  %t1006 = load i64, ptr %l1, !tbaa !24
  %t1007 = load %"compiler/mir:Lvalue", ptr %l59
  %t1011 = call { %"compiler/eval:Ptr", i32 } @compiler_2feval_2ecompiler_2feval_3aMachine_2eplace(ptr %v0, ptr %t1005, i64 %t1006, %"compiler/mir:Lvalue" %t1007)
  store { %"compiler/eval:Ptr", i32 } %t1011, ptr %l494
  br label %bb168
bb168:
  %t1012 = load { %"compiler/eval:Ptr", i32 }, ptr %l494
  store { %"compiler/eval:Ptr", i32 } %t1012, ptr %l64
  %t1013 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l64, i32 0, i32 0
  %t1014 = load %"compiler/eval:Ptr", ptr %t1013
  store %"compiler/eval:Ptr" %t1014, ptr %l65
  %t1016 = getelementptr { %"compiler/eval:Ptr", i32 }, ptr %l64, i32 0, i32 1
  %t1017 = load i32, ptr %t1016, !tbaa !23
  store i32 %t1017, ptr %l66, !tbaa !23
  %t1019 = load ptr, ptr %l0, !tbaa !29
  %t1020 = load %"compiler/eval:Ptr", ptr %l62
  %t1021 = load i32, ptr %l63, !tbaa !23
  %t1025 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1019, %"compiler/eval:Ptr" %t1020, i32 %t1021)
  store { %"compiler/eval:Ptr", i64 } %t1025, ptr %l500
  br label %bb169
bb169:
  %t1026 = load { %"compiler/eval:Ptr", i64 }, ptr %l500
  store { %"compiler/eval:Ptr", i64 } %t1026, ptr %l67
  %t1027 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l67, i32 0, i32 0
  %t1028 = load %"compiler/eval:Ptr", ptr %t1027
  store %"compiler/eval:Ptr" %t1028, ptr %l68
  %t1030 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l67, i32 0, i32 1
  %t1031 = load i64, ptr %t1030, !tbaa !24
  store i64 %t1031, ptr %l69, !tbaa !24
  %t1033 = load ptr, ptr %l0, !tbaa !29
  %t1034 = load %"compiler/eval:Ptr", ptr %l65
  %t1035 = load i32, ptr %l66, !tbaa !23
  %t1039 = call { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayView(ptr %v0, ptr %t1033, %"compiler/eval:Ptr" %t1034, i32 %t1035)
  store { %"compiler/eval:Ptr", i64 } %t1039, ptr %l506
  br label %bb170
bb170:
  %t1040 = load { %"compiler/eval:Ptr", i64 }, ptr %l506
  store { %"compiler/eval:Ptr", i64 } %t1040, ptr %l70
  %t1041 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l70, i32 0, i32 0
  %t1042 = load %"compiler/eval:Ptr", ptr %t1041
  store %"compiler/eval:Ptr" %t1042, ptr %l71
  %t1044 = getelementptr { %"compiler/eval:Ptr", i64 }, ptr %l70, i32 0, i32 1
  %t1045 = load i64, ptr %t1044, !tbaa !24
  store i64 %t1045, ptr %l72, !tbaa !24
  %t1047 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1047, ptr %l509, !tbaa !29
  %t1048 = load ptr, ptr %l0, !tbaa !29
  %t1049 = load i64, ptr %l1, !tbaa !24
  %t1050 = load { i64, [4 x i64] }, ptr %l60
  %t1054 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escalar(ptr %v0, ptr %t1048, i64 %t1049, { i64, [4 x i64] } %t1050)
  store i64 %t1054, ptr %l513
  br label %bb171
bb171:
  %t1055 = load ptr, ptr %l0, !tbaa !29
  %t1056 = load i64, ptr %l1, !tbaa !24
  %t1057 = load { i64, [4 x i64] }, ptr %l60
  %t1061 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %t1055, i64 %t1056, { i64, [4 x i64] } %t1057)
  store i32 %t1061, ptr %l517
  br label %bb172
bb172:
  %t1062 = load ptr, ptr %l509, !tbaa !29
  %t1063 = load i64, ptr %l513, !tbaa !24
  %t1064 = load i32, ptr %l517, !tbaa !23
  %t1065 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t1062, i64 %t1063, i32 %t1064)
  store i64 %t1065, ptr %l518
  br label %bb173
bb173:
  %t1066 = load i64, ptr %l518, !tbaa !24
  store i64 %t1066, ptr %l73, !tbaa !24
  %t1067 = load ptr, ptr %l0, !tbaa !29
  %t1069 = getelementptr %"compiler/eval:Machine", ptr %t1067, i32 0, i32 13
  %t1070 = load i1, ptr %t1069, !tbaa !21
  br i1 %t1070, label %bb174, label %bb175
bb174:
  br label %ret
bb175:
  br label %bb176
bb176:
  %t1072 = load i64, ptr %l73, !tbaa !24
  %t1074 = icmp slt i64 %t1072, 0
  br i1 %t1074, label %bb177, label %bb178
bb177:
  store i1 true, ptr %l523, !tbaa !21
  br label %bb179
bb178:
  %t1076 = load i64, ptr %l73, !tbaa !24
  %t1077 = load i64, ptr %l69, !tbaa !24
  %t1080 = icmp sgt i64 %t1076, %t1077
  store i1 %t1080, ptr %l523, !tbaa !21
  br label %bb179
bb179:
  %t1082 = load i1, ptr %l523, !tbaa !21
  br i1 %t1082, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l527, !tbaa !21
  br label %bb182
bb181:
  %t1083 = load i64, ptr %l73, !tbaa !24
  %t1084 = load i64, ptr %l72, !tbaa !24
  %t1087 = icmp sgt i64 %t1083, %t1084
  store i1 %t1087, ptr %l527, !tbaa !21
  br label %bb182
bb182:
  %t1089 = load i1, ptr %l527, !tbaa !21
  br i1 %t1089, label %bb183, label %bb184
bb183:
  %t1090 = load ptr, ptr %l0, !tbaa !29
  %t1091 = load { i64, ptr }, ptr @G_2ecompiler_2feval_2eWhyOutside, !tbaa !27
  %t1092 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %t1092, ptr %t1090, { i64, ptr } %t1091)
  br label %bb185
bb184:
  br label %bb186
bb185:
  br label %ret
bb186:
  %t1095 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1095, ptr %l533, !tbaa !29
  %t1096 = load %"compiler/eval:Ptr", ptr %l68
  store %"compiler/eval:Ptr" %t1096, ptr %l534
  %t1097 = load %"compiler/eval:Ptr", ptr %l71
  store %"compiler/eval:Ptr" %t1097, ptr %l535
  %t1098 = load i64, ptr %l73, !tbaa !24
  store i64 %t1098, ptr %l536, !tbaa !24
  %t1099 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1099, ptr %l537, !tbaa !29
  %t1100 = load ptr, ptr %l0, !tbaa !29
  %t1101 = load i32, ptr %l63, !tbaa !23
  %t1104 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eelemOf(ptr %v0, ptr %t1100, i32 %t1101)
  store i32 %t1104, ptr %l540
  br label %bb187
bb187:
  %t1105 = load ptr, ptr %l537, !tbaa !29
  %t1106 = load i32, ptr %l540, !tbaa !23
  %t1107 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t1105, i32 %t1106)
  store i64 %t1107, ptr %l541
  br label %bb188
bb188:
  %t1108 = load i64, ptr %l536, !tbaa !24
  %t1109 = load i64, ptr %l541, !tbaa !24
  %t1110 = mul i64 %t1108, %t1109
  %t1111 = load ptr, ptr %l533, !tbaa !29
  %t1112 = load %"compiler/eval:Ptr", ptr %l534
  %t1113 = load %"compiler/eval:Ptr", ptr %l535
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t1111, %"compiler/eval:Ptr" %t1112, %"compiler/eval:Ptr" %t1113, i64 %t1110)
  br label %bb189
bb189:
  br label %bb197
bb190:
  call void @llvm.memmove.p0.p0.i64(ptr %l543, ptr %l6, i64 176, i1 false)
  %t1115 = load { i64, [21 x i64] }, ptr %l543
  %t1116 = extractvalue { i64, [21 x i64] } %t1115, 0
  %t1117 = icmp eq i64 %t1116, 11
  br i1 %t1117, label %bb191, label %bb192
bb191:
  %t1119 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1120 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1119, i32 0, i32 0
  %t1121 = load %"compiler/source:Span", ptr %t1120
  store %"compiler/source:Span" %t1121, ptr %l74
  %t1123 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1124 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1123, i32 0, i32 1
  %t1125 = load i32, ptr %t1124
  store i32 %t1125, ptr %l75, !tbaa !23
  %t1127 = getelementptr { i64, [21 x i64] }, ptr %l6, i32 0, i32 1
  %t1128 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t1127, i32 0, i32 2
  %t1129 = load i32, ptr %t1128
  store i32 %t1129, ptr %l76, !tbaa !23
  br label %bb193
bb192:
  br label %bb196
bb193:
  %t1131 = load ptr, ptr %l0, !tbaa !29
  %t1132 = load i64, ptr %l2, !tbaa !24
  %t1133 = load %"compiler/source:Span", ptr %l74
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %t1131, i64 %t1132, %"compiler/source:Span" %t1133)
  br label %bb194
bb194:
  %t1137 = load ptr, ptr %l0, !tbaa !29
  %t1138 = load i64, ptr %l1, !tbaa !24
  %t1139 = load i32, ptr %l75, !tbaa !23
  %t1140 = load i32, ptr %l76, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2espawn(ptr %v0, ptr %t1137, i64 %t1138, i32 %t1139, i32 %t1140)
  br label %bb195
bb195:
  br label %bb197
bb196:
  call void @__olang_check_failed(ptr @olang_loc_7f284a3be8281e29_2098fbd9ac092a4d)
  unreachable
bb197:
  %t1145 = load ptr, ptr %l0, !tbaa !29
  %t1147 = getelementptr %"compiler/eval:Machine", ptr %t1145, i32 0, i32 13
  %t1148 = load i1, ptr %t1147, !tbaa !21
  %t1150 = xor i1 %t1148, true
  br i1 %t1150, label %bb198, label %bb199
bb198:
  %t1152 = load ptr, ptr %l0, !tbaa !29
  %t1154 = getelementptr %"compiler/eval:Machine", ptr %t1152, i32 0, i32 49
  %t1155 = load { i64, ptr }, ptr %t1154, !tbaa !27
  store { i64, ptr } %t1155, ptr %l559, !tbaa !27
  %t1156 = load i64, ptr %l1, !tbaa !24
  store i64 %t1156, ptr %l560, !tbaa !24
  %t1157 = load i64, ptr %l560, !tbaa !24
  %t1158 = getelementptr { i64, ptr }, ptr %l559, i32 0, i32 1
  %t1159 = load ptr, ptr %t1158, !tbaa !27
  %t1160 = getelementptr %"compiler/eval:frame", ptr %t1159, i64 %t1157
  %t1161 = getelementptr %"compiler/eval:frame", ptr %t1160, i32 0, i32 2
  %t1162 = load i64, ptr %t1161, !tbaa !24
  %t1164 = add i64 %t1162, 1
  %t1166 = load i64, ptr %l560, !tbaa !24
  %t1167 = getelementptr { i64, ptr }, ptr %l559, i32 0, i32 1
  %t1168 = load ptr, ptr %t1167, !tbaa !27
  %t1169 = getelementptr %"compiler/eval:frame", ptr %t1168, i64 %t1166
  %t1170 = getelementptr %"compiler/eval:frame", ptr %t1169, i32 0, i32 2
  store i64 %t1164, ptr %t1170, !tbaa !24
  br label %bb200
bb199:
  br label %bb200
bb200:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2esuspend(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, i32 %a3, %"compiler/mir:Range" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/mir:Range"
  %l5 = alloca i64
  %l6 = alloca %"compiler/eval:frame"
  %l7 = alloca %"compiler/eval:genRec"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/mir:Fn"
  %l22 = alloca i64
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i32
  %l29 = alloca { i64, [1 x i64] }
  %l30 = alloca i32
  %l32 = alloca { i64, ptr }
  %l39 = alloca i64
  %l46 = alloca { i64, ptr }
  %l54 = alloca %"compiler/eval:genRec"
  %l63 = alloca i64
  %l66 = alloca { i64, ptr }
  %l75 = alloca i64
  %l78 = alloca i64
  %l105 = alloca i64
  %l108 = alloca i64
  %l132 = alloca { i64, ptr }
  %l142 = alloca %"compiler/mir:Fn"
  %l150 = alloca i32
  %l153 = alloca i32
  %l177 = alloca { i64, [1 x i64] }
  %l185 = alloca { i64, ptr }
  %l209 = alloca %"compiler/eval:genRec"
  %t54 = alloca %"compiler/eval:genRec", align 8
  %t241 = alloca %"compiler/mir:Fn", align 8
  %t389 = alloca %"compiler/eval:genRec", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/mir:Range" %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 49
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l32, !tbaa !27
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/eval:frame", ptr %t8, i64 %t5
  %t10 = getelementptr %"compiler/eval:frame", ptr %t9, i32 0, i32 18
  %t11 = load i32, ptr %t10, !tbaa !23
  %t13 = sext i32 %t11 to i64
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l39
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %ret
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edeliver(ptr %v0, ptr %t22, i64 %t23, { i64, [4 x i64] } %a2)
  br label %bb5
bb5:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 13
  %t31 = load i1, ptr %t30, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/eval:Machine", ptr %t33, i32 0, i32 49
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l46, !tbaa !27
  %t37 = load i64, ptr %l1, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/eval:frame", ptr %t40, i64 %t37
  %t42 = load %"compiler/eval:frame", ptr %t41
  store %"compiler/eval:frame" %t42, ptr %l6
  %t46 = sext i32 %a3 to i64
  %t48 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 1
  store i64 %t46, ptr %t48, !tbaa !24
  %t49 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 2
  store i64 0, ptr %t49, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/eval:Machine", ptr %t50, i32 0, i32 54
  %t53 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %t54, ptr %v0, ptr %t52, i64 %t53)
  call void @llvm.memmove.p0.p0.i64(ptr %l54, ptr %t54, i64 176, i1 false)
  br label %bb9
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l54, i64 176, i1 false)
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/eval:Machine", ptr %t57, i32 0, i32 52
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 3
  %t62 = load i64, ptr %t61, !tbaa !24
  %t65 = sub i64 %t60, %t62
  store i64 %t65, ptr %l8, !tbaa !24
  %t67 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 3
  %t68 = load i64, ptr %t67, !tbaa !24
  %t70 = icmp slt i64 %t68, 0
  br i1 %t70, label %bb10, label %bb11
bb10:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/eval:Machine", ptr %t72, i32 0, i32 56
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t74)
  store i64 %t76, ptr %l63
  br label %bb12
bb11:
  br label %bb26
bb12:
  %t77 = load i64, ptr %l63, !tbaa !24
  %t78 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 3
  store i64 %t77, ptr %t78, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/eval:Machine", ptr %t80, i32 0, i32 17
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l66, !tbaa !27
  %t84 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 0
  %t85 = load i64, ptr %t84, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr %"compiler/eval:cfn", ptr %t88, i64 %t85
  %t90 = getelementptr %"compiler/eval:cfn", ptr %t89, i32 0, i32 2
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t96 = add i64 %t79, %t93
  %t98 = add i64 %t96, 1
  store i64 %t98, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t100 = load i64, ptr %l10, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = icmp sgt i64 %t100, %t101
  br i1 %t104, label %bb13, label %bb14
bb13:
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = icmp sgt i64 %t106, 0
  br i1 %t108, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb18
bb15:
  %t110 = load i64, ptr %l10, !tbaa !24
  %t111 = load i64, ptr %l9, !tbaa !24
  %t114 = sub i64 %t110, %t111
  %t115 = load i64, ptr %l11, !tbaa !24
  %t118 = add i64 %t114, %t115
  %t120 = sub i64 %t118, 1
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = sdiv i64 %t120, %t121
  store i64 %t124, ptr %l78, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l78, !tbaa !24
  br label %bb17
bb17:
  %t126 = load i64, ptr %l78, !tbaa !24
  store i64 %t126, ptr %l75, !tbaa !24
  br label %bb18
bb18:
  %t127 = load i64, ptr %l75, !tbaa !24
  store i64 %t127, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb19
bb19:
  %t128 = load i64, ptr %l13, !tbaa !24
  %t129 = load i64, ptr %l12, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb20, label %bb21
bb20:
  br label %bb25
bb21:
  br label %bb22
bb22:
  %t136 = load i64, ptr %l9, !tbaa !24
  %t137 = load i64, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = mul i64 %t137, %t138
  %t144 = add i64 %t136, %t141
  store i64 %t144, ptr %l14, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/eval:Machine", ptr %t146, i32 0, i32 56
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t148, i64 0)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t150 = load i64, ptr %l13, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l13, !tbaa !24
  br label %bb19
bb25:
  br label %bb26
bb26:
  %t154 = load i64, ptr %l8, !tbaa !24
  %t156 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 4
  store i64 %t154, ptr %t156, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l8, !tbaa !24
  store i64 %t157, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t159 = load i64, ptr %l16, !tbaa !24
  %t160 = load i64, ptr %l15, !tbaa !24
  %t163 = icmp sgt i64 %t159, %t160
  br i1 %t163, label %bb27, label %bb28
bb27:
  %t165 = load i64, ptr %l17, !tbaa !24
  %t167 = icmp sgt i64 %t165, 0
  br i1 %t167, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l105, !tbaa !24
  br label %bb32
bb29:
  %t169 = load i64, ptr %l16, !tbaa !24
  %t170 = load i64, ptr %l15, !tbaa !24
  %t173 = sub i64 %t169, %t170
  %t174 = load i64, ptr %l17, !tbaa !24
  %t177 = add i64 %t173, %t174
  %t179 = sub i64 %t177, 1
  %t180 = load i64, ptr %l17, !tbaa !24
  %t183 = sdiv i64 %t179, %t180
  store i64 %t183, ptr %l108, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb31
bb31:
  %t185 = load i64, ptr %l108, !tbaa !24
  store i64 %t185, ptr %l105, !tbaa !24
  br label %bb32
bb32:
  %t186 = load i64, ptr %l105, !tbaa !24
  store i64 %t186, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb33
bb33:
  %t187 = load i64, ptr %l19, !tbaa !24
  %t188 = load i64, ptr %l18, !tbaa !24
  %t191 = icmp slt i64 %t187, %t188
  %t193 = xor i1 %t191, true
  br i1 %t193, label %bb34, label %bb35
bb34:
  br label %bb39
bb35:
  br label %bb36
bb36:
  %t195 = load i64, ptr %l15, !tbaa !24
  %t196 = load i64, ptr %l19, !tbaa !24
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = mul i64 %t196, %t197
  %t203 = add i64 %t195, %t200
  store i64 %t203, ptr %l20, !tbaa !24
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/eval:Machine", ptr %t205, i32 0, i32 56
  %t208 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 3
  %t209 = load i64, ptr %t208, !tbaa !24
  %t210 = load i64, ptr %l20, !tbaa !24
  %t213 = add i64 %t209, %t210
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/eval:Machine", ptr %t214, i32 0, i32 51
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l132, !tbaa !27
  %t218 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 3
  %t219 = load i64, ptr %t218, !tbaa !24
  %t220 = load i64, ptr %l20, !tbaa !24
  %t223 = add i64 %t219, %t220
  %t225 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr i64, ptr %t226, i64 %t223
  %t228 = load i64, ptr %t227, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t207, i64 %t213, i64 %t228)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t232 = load i64, ptr %l19, !tbaa !24
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l19, !tbaa !24
  br label %bb33
bb39:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/eval:Machine", ptr %t236, i32 0, i32 16
  %t239 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 0
  %t240 = load i64, ptr %t239, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t241, ptr %v0, ptr %v0, ptr %t238, i64 %t240)
  call void @llvm.memmove.p0.p0.i64(ptr %l142, ptr %t241, i64 248, i1 false)
  br label %bb40
bb40:
  call void @llvm.memmove.p0.p0.i64(ptr %l21, ptr %l142, i64 248, i1 false)
  %t244 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 3
  %t245 = load i64, ptr %t244, !tbaa !24
  %t246 = load i64, ptr %l8, !tbaa !24
  %t249 = add i64 %t245, %t246
  store i64 %t249, ptr %l22, !tbaa !24
  store i32 0, ptr %l23, !tbaa !23
  %t251 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 1
  %t252 = load i32, ptr %t251, !tbaa !23
  store i32 %t252, ptr %l24, !tbaa !23
  store i32 1, ptr %l25, !tbaa !23
  %t254 = load i32, ptr %l24, !tbaa !23
  %t255 = load i32, ptr %l23, !tbaa !23
  %t258 = icmp sgt i32 %t254, %t255
  br i1 %t258, label %bb41, label %bb42
bb41:
  %t260 = load i32, ptr %l25, !tbaa !23
  %t262 = icmp sgt i32 %t260, 0
  br i1 %t262, label %bb43, label %bb44
bb42:
  store i32 0, ptr %l150, !tbaa !23
  br label %bb46
bb43:
  %t264 = load i32, ptr %l24, !tbaa !23
  %t265 = load i32, ptr %l23, !tbaa !23
  %t268 = sub i32 %t264, %t265
  %t269 = load i32, ptr %l25, !tbaa !23
  %t272 = add i32 %t268, %t269
  %t274 = sub i32 %t272, 1
  %t275 = load i32, ptr %l25, !tbaa !23
  %t278 = sdiv i32 %t274, %t275
  store i32 %t278, ptr %l153, !tbaa !23
  br label %bb45
bb44:
  store i32 0, ptr %l153, !tbaa !23
  br label %bb45
bb45:
  %t280 = load i32, ptr %l153, !tbaa !23
  store i32 %t280, ptr %l150, !tbaa !23
  br label %bb46
bb46:
  %t281 = load i32, ptr %l150, !tbaa !23
  store i32 %t281, ptr %l26, !tbaa !23
  store i32 0, ptr %l27, !tbaa !23
  br label %bb47
bb47:
  %t282 = load i32, ptr %l27, !tbaa !23
  %t283 = load i32, ptr %l26, !tbaa !23
  %t286 = icmp slt i32 %t282, %t283
  %t288 = xor i1 %t286, true
  br i1 %t288, label %bb48, label %bb49
bb48:
  br label %bb63
bb49:
  br label %bb50
bb50:
  %t290 = load i32, ptr %l23, !tbaa !23
  %t291 = load i32, ptr %l27, !tbaa !23
  %t292 = load i32, ptr %l25, !tbaa !23
  %t295 = mul i32 %t291, %t292
  %t298 = add i32 %t290, %t295
  %t300 = getelementptr %"compiler/mir:Fn", ptr %l21, i32 0, i32 12
  %t301 = getelementptr %"compiler/mir:Range", ptr %l4, i32 0, i32 0
  %t302 = load i32, ptr %t301, !tbaa !23
  %t304 = sext i32 %t302 to i64
  %t307 = sext i32 %t298 to i64
  %t310 = add i64 %t304, %t307
  %t313 = call { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %t300, i64 %t310)
  store { i64, [1 x i64] } %t313, ptr %l177
  br label %bb51
bb51:
  %t314 = load { i64, [1 x i64] }, ptr %l177
  store { i64, [1 x i64] } %t314, ptr %l29
  %t315 = load { i64, [1 x i64] }, ptr %l29
  %t317 = extractvalue { i64, [1 x i64] } %t315, 0
  %t318 = icmp eq i64 %t317, 0
  br i1 %t318, label %bb52, label %bb53
bb52:
  %t320 = getelementptr { i64, [1 x i64] }, ptr %l29, i32 0, i32 1
  %t321 = getelementptr { i32 }, ptr %t320, i32 0, i32 0
  %t322 = load i32, ptr %t321
  store i32 %t322, ptr %l30, !tbaa !23
  br label %bb54
bb53:
  br label %bb56
bb54:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/eval:Machine", ptr %t324, i32 0, i32 56
  %t327 = load i64, ptr %l22, !tbaa !24
  %t328 = load ptr, ptr %l0, !tbaa !29
  %t330 = getelementptr %"compiler/eval:Machine", ptr %t328, i32 0, i32 51
  %t331 = load { i64, ptr }, ptr %t330, !tbaa !27
  store { i64, ptr } %t331, ptr %l185, !tbaa !27
  %t332 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 4
  %t333 = load i64, ptr %t332, !tbaa !24
  %t334 = load i32, ptr %l30, !tbaa !23
  %t336 = sext i32 %t334 to i64
  %t339 = add i64 %t333, %t336
  %t341 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i64, ptr %t342, i64 %t339
  %t344 = load i64, ptr %t343, !tbaa !34
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t326, i64 %t327, i64 %t344)
  br label %bb55
bb55:
  %t348 = load i64, ptr %l22, !tbaa !24
  %t350 = add i64 %t348, 1
  store i64 %t350, ptr %l22, !tbaa !24
  br label %bb61
bb56:
  br i1 true, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_check_failed(ptr @olang_loc_77ec49cd2ef2b53_f798fa63e9acfcff)
  unreachable
bb61:
  br label %bb62
bb62:
  %t352 = load i32, ptr %l27, !tbaa !23
  %t354 = add i32 %t352, 1
  store i32 %t354, ptr %l27, !tbaa !23
  br label %bb47
bb63:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/eval:Machine", ptr %t356, i32 0, i32 56
  %t359 = load i64, ptr %l22, !tbaa !24
  %t360 = getelementptr %"compiler/eval:frame", ptr %l6, i32 0, i32 6
  %t361 = load i64, ptr %t360, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t358, i64 %t359, i64 %t361)
  br label %bb64
bb64:
  %t365 = load i64, ptr %l22, !tbaa !24
  %t367 = add i64 %t365, 1
  %t368 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 3
  %t369 = load i64, ptr %t368, !tbaa !24
  %t370 = load i64, ptr %l8, !tbaa !24
  %t373 = add i64 %t369, %t370
  %t376 = sub i64 %t367, %t373
  %t378 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 5
  store i64 %t376, ptr %t378, !tbaa !24
  %t379 = load %"compiler/eval:frame", ptr %l6
  %t381 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 2
  store %"compiler/eval:frame" %t379, ptr %t381
  %t382 = getelementptr %"compiler/eval:genRec", ptr %l7, i32 0, i32 0
  store i64 1, ptr %t382, !tbaa !24
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t385 = getelementptr %"compiler/eval:Machine", ptr %t383, i32 0, i32 54
  %t386 = load i64, ptr %l5, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l209, ptr %l7, i64 176, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t389, ptr %l209, i64 176, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %t385, i64 %t386, ptr %t389)
  br label %bb65
bb65:
  %t390 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2epopFrame(ptr %v0, ptr %t390)
  br label %bb66
bb66:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load %"compiler/eval:frame", ptr %l6
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereturned(ptr %v0, ptr %t392, %"compiler/eval:frame" %t393)
  br label %bb67
bb67:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2etagOf(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/eval:Ptr"
  %l5 = alloca i64
  %l8 = alloca ptr
  %l11 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/eval:Ptr" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %a2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/eval:Ptr", ptr %l1
  %t16 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t12, %"compiler/eval:Ptr" %t13, i64 4)
  store i64 %t16, ptr %l11
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t17 = load i32, ptr @G_2ecompiler_2fmir_2eI32T, !tbaa !23
  %t18 = load ptr, ptr %l8, !tbaa !29
  %t19 = load i64, ptr %l11, !tbaa !24
  %t21 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintValue(ptr %v0, ptr %t18, i64 %t19, i32 %t17)
  store i64 %t21, ptr %l13
  br label %bb5
bb5:
  %t22 = load i64, ptr %l13, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load %"compiler/eval:Ptr", ptr %l1
  %t27 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t23, %"compiler/eval:Ptr" %t24, i64 8)
  store i64 %t27, ptr %l16
  br label %bb7
bb7:
  %t28 = load i64, ptr %l16, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2etoTargets(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [4 x i64] } %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"compiler/eval:task"
  %l6 = alloca %"compiler/mir:Fn"
  %l7 = alloca %"compiler/mir:Task"
  %l8 = alloca { { i64, ptr }, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:Ptr"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/eval:Ptr"
  %l19 = alloca i32
  %l20 = alloca %"compiler/eval:Ptr"
  %l25 = alloca %"compiler/eval:task"
  %l29 = alloca %"compiler/mir:Fn"
  %l32 = alloca %"compiler/mir:Task"
  %l38 = alloca { { i64, ptr }, i64 }
  %l47 = alloca %"compiler/eval:Ptr"
  %l52 = alloca i64
  %l55 = alloca i64
  %l73 = alloca ptr
  %l79 = alloca %"compiler/eval:Ptr"
  %l80 = alloca %"compiler/eval:Ptr"
  %l83 = alloca i32
  %l88 = alloca i32
  %l91 = alloca %"compiler/eval:Ptr"
  %l93 = alloca i64
  %l94 = alloca i64
  %l98 = alloca i64
  %l100 = alloca %"compiler/eval:Ptr"
  %l105 = alloca i1
  %l107 = alloca ptr
  %l111 = alloca i32
  %l112 = alloca i32
  %l115 = alloca i1
  %l117 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca i32
  %l124 = alloca ptr
  %l142 = alloca %"compiler/eval:Ptr"
  %l143 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca %"compiler/eval:Ptr"
  %l151 = alloca %"compiler/eval:Ptr"
  %l154 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t14 = alloca %"compiler/mir:Fn", align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 47
  %t7 = call %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %t3, i64 %a2)
  store %"compiler/eval:task" %t7, ptr %l25
  br label %bb1
bb1:
  %t8 = load %"compiler/eval:task", ptr %l25
  store %"compiler/eval:task" %t8, ptr %l5
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/eval:Machine", ptr %t9, i32 0, i32 16
  %t12 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %t14, ptr %v0, ptr %v0, ptr %t11, i64 %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t14, i64 248, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l29, i64 248, i1 false)
  %t17 = getelementptr %"compiler/mir:Fn", ptr %l6, i32 0, i32 16
  %t18 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t22 = call %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %t17, i64 %t19)
  store %"compiler/mir:Task" %t22, ptr %l32
  br label %bb3
bb3:
  %t23 = load %"compiler/mir:Task", ptr %l32
  store %"compiler/mir:Task" %t23, ptr %l7
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load %"compiler/mir:Task", ptr %l7
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = sub i64 %t26, 1
  %t33 = call { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v0, ptr %s0, ptr %t24, ptr %l6, %"compiler/mir:Task" %t25, i64 %t28)
  store { { i64, ptr }, i64 } %t33, ptr %l38
  br label %bb4
bb4:
  %t34 = load { { i64, ptr }, i64 }, ptr %l38
  store { { i64, ptr }, i64 } %t34, ptr %l8
  %t35 = getelementptr { { i64, ptr }, i64 }, ptr %l8, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l9, !tbaa !24
  %t38 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 3
  %t39 = getelementptr %"compiler/mir:Range", ptr %t38, i32 0, i32 1
  %t40 = load i32, ptr %t39, !tbaa !23
  %t42 = sext i32 %t40 to i64
  store i64 %t42, ptr %l10, !tbaa !24
  %t44 = load i64, ptr %l10, !tbaa !24
  %t46 = icmp eq i64 %t44, 0
  br i1 %t46, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i64, ptr %l1, !tbaa !24
  %t54 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddr(ptr %v0, ptr %t48, i64 %t49, { i64, [4 x i64] } %a3, i64 1)
  store %"compiler/eval:Ptr" %t54, ptr %l47
  br label %bb8
bb8:
  %t55 = load %"compiler/eval:Ptr", ptr %l47
  store %"compiler/eval:Ptr" %t55, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t56 = load i64, ptr %l10, !tbaa !24
  store i64 %t56, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t58 = load i64, ptr %l13, !tbaa !24
  %t59 = load i64, ptr %l12, !tbaa !24
  %t62 = icmp sgt i64 %t58, %t59
  br i1 %t62, label %bb9, label %bb10
bb9:
  %t64 = load i64, ptr %l14, !tbaa !24
  %t66 = icmp sgt i64 %t64, 0
  br i1 %t66, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb14
bb11:
  %t68 = load i64, ptr %l13, !tbaa !24
  %t69 = load i64, ptr %l12, !tbaa !24
  %t72 = sub i64 %t68, %t69
  %t73 = load i64, ptr %l14, !tbaa !24
  %t76 = add i64 %t72, %t73
  %t78 = sub i64 %t76, 1
  %t79 = load i64, ptr %l14, !tbaa !24
  %t82 = sdiv i64 %t78, %t79
  store i64 %t82, ptr %l55, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb13
bb13:
  %t84 = load i64, ptr %l55, !tbaa !24
  store i64 %t84, ptr %l52, !tbaa !24
  br label %bb14
bb14:
  %t85 = load i64, ptr %l52, !tbaa !24
  store i64 %t85, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t86 = load i64, ptr %l16, !tbaa !24
  %t87 = load i64, ptr %l15, !tbaa !24
  %t90 = icmp slt i64 %t86, %t87
  %t92 = xor i1 %t90, true
  br i1 %t92, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb17:
  br label %bb18
bb18:
  %t94 = load i64, ptr %l12, !tbaa !24
  %t95 = load i64, ptr %l16, !tbaa !24
  %t96 = load i64, ptr %l14, !tbaa !24
  %t99 = mul i64 %t95, %t96
  %t102 = add i64 %t94, %t99
  store i64 %t102, ptr %l17, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l73, !tbaa !29
  %t105 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 2
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l17, !tbaa !24
  %t110 = mul i64 8, %t108
  %t113 = add i64 %t107, %t110
  %t116 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t106, i64 %t113)
  store %"compiler/eval:Ptr" %t116, ptr %l79
  br label %bb19
bb19:
  %t117 = load ptr, ptr %l73, !tbaa !29
  %t118 = load %"compiler/eval:Ptr", ptr %l79
  %t119 = call %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %t117, %"compiler/eval:Ptr" %t118)
  store %"compiler/eval:Ptr" %t119, ptr %l80
  br label %bb20
bb20:
  %t120 = load %"compiler/eval:Ptr", ptr %l80
  store %"compiler/eval:Ptr" %t120, ptr %l18
  %t121 = load i64, ptr %l10, !tbaa !24
  %t123 = icmp eq i64 %t121, 1
  br i1 %t123, label %bb21, label %bb22
bb21:
  %t125 = load i32, ptr %l4, !tbaa !23
  store i32 %t125, ptr %l83, !tbaa !23
  br label %bb24
bb22:
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l4, !tbaa !23
  %t129 = load i64, ptr %l17, !tbaa !24
  %t133 = call i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %t127, i32 %t128, i64 %t129)
  store i32 %t133, ptr %l88
  br label %bb23
bb23:
  %t134 = load i32, ptr %l88, !tbaa !23
  store i32 %t134, ptr %l83, !tbaa !23
  br label %bb24
bb24:
  %t135 = load i32, ptr %l83, !tbaa !23
  store i32 %t135, ptr %l19, !tbaa !23
  %t136 = load i64, ptr %l10, !tbaa !24
  %t138 = icmp eq i64 %t136, 1
  br i1 %t138, label %bb25, label %bb26
bb25:
  %t140 = load %"compiler/eval:Ptr", ptr %l11
  store %"compiler/eval:Ptr" %t140, ptr %l91
  br label %bb29
bb26:
  %t142 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 0
  %t143 = load i64, ptr %t142, !tbaa !24
  store i64 %t143, ptr %l93, !tbaa !24
  %t144 = getelementptr %"compiler/eval:Ptr", ptr %l11, i32 0, i32 1
  %t145 = load i64, ptr %t144, !tbaa !24
  store i64 %t145, ptr %l94, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l4, !tbaa !23
  %t148 = load i64, ptr %l17, !tbaa !24
  %t152 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %t146, i32 %t147, i64 %t148)
  store i64 %t152, ptr %l98
  br label %bb27
bb27:
  %t153 = load i64, ptr %l94, !tbaa !24
  %t154 = load i64, ptr %l98, !tbaa !24
  %t155 = add i64 %t153, %t154
  %t156 = load i64, ptr %l93, !tbaa !24
  %t158 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s3, i64 %t156, i64 %t155)
  store %"compiler/eval:Ptr" %t158, ptr %l100
  br label %bb28
bb28:
  %t159 = load %"compiler/eval:Ptr", ptr %l100
  store %"compiler/eval:Ptr" %t159, ptr %l91
  br label %bb29
bb29:
  %t160 = load %"compiler/eval:Ptr", ptr %l91
  store %"compiler/eval:Ptr" %t160, ptr %l20
  %t161 = load i64, ptr %l17, !tbaa !24
  %t162 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 7
  %t163 = getelementptr %"compiler/mir:Range", ptr %t162, i32 0, i32 1
  %t164 = load i32, ptr %t163, !tbaa !23
  %t166 = sext i32 %t164 to i64
  %t169 = icmp slt i64 %t161, %t166
  br i1 %t169, label %bb30, label %bb31
bb30:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/eval:Machine", ptr %t171, i32 0, i32 0
  %t174 = load ptr, ptr %t173, !tbaa !29
  store ptr %t174, ptr %l107, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/eval:Machine", ptr %t175, i32 0, i32 0
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i32, ptr %l19, !tbaa !23
  %t182 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t178, i32 %t179)
  store i32 %t182, ptr %l111
  br label %bb32
bb31:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb34
bb32:
  %t183 = load ptr, ptr %l107, !tbaa !29
  %t184 = load i32, ptr %l111, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t183, i32 %t184)
  store i32 %t185, ptr %l112
  br label %bb33
bb33:
  %t186 = load i32, ptr %l112
  %t188 = trunc i64 19 to i32
  %t189 = icmp eq i32 %t186, %t188
  store i1 %t189, ptr %l105, !tbaa !21
  br label %bb34
bb34:
  %t191 = load i1, ptr %l105, !tbaa !21
  br i1 %t191, label %bb35, label %bb36
bb35:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/eval:Machine", ptr %t192, i32 0, i32 0
  %t195 = load ptr, ptr %t194, !tbaa !29
  store ptr %t195, ptr %l117, !tbaa !29
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/eval:Machine", ptr %t196, i32 0, i32 0
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t200 = load i32, ptr %l19, !tbaa !23
  %t203 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t199, i32 %t200)
  store i32 %t203, ptr %l121
  br label %bb37
bb36:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb39
bb37:
  %t204 = load ptr, ptr %l117, !tbaa !29
  %t205 = load i32, ptr %l121, !tbaa !23
  %t206 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t206, ptr %l122
  br label %bb38
bb38:
  %t207 = load i32, ptr %l122, !tbaa !23
  %t208 = icmp eq i32 %t207, 0
  store i1 %t208, ptr %l115, !tbaa !21
  br label %bb39
bb39:
  %t210 = load i1, ptr %l115, !tbaa !21
  br i1 %t210, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l124, !tbaa !29
  %t212 = getelementptr %"compiler/eval:task", ptr %l5, i32 0, i32 2
  %t213 = load i64, ptr %t212, !tbaa !24
  %t214 = load i64, ptr %l9, !tbaa !24
  %t215 = load i64, ptr %l10, !tbaa !24
  %t217 = mul i64 8, %t215
  %t220 = add i64 %t214, %t217
  %t221 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 4
  %t222 = getelementptr %"compiler/mir:Range", ptr %t221, i32 0, i32 1
  %t223 = load i32, ptr %t222, !tbaa !23
  %t225 = sext i32 %t223 to i64
  %t227 = mul i64 16, %t225
  %t230 = add i64 %t220, %t227
  %t231 = getelementptr %"compiler/mir:Task", ptr %l7, i32 0, i32 2
  %t232 = getelementptr %"compiler/mir:Range", ptr %t231, i32 0, i32 1
  %t233 = load i32, ptr %t232, !tbaa !23
  %t235 = sext i32 %t233 to i64
  %t237 = mul i64 8, %t235
  %t240 = add i64 %t230, %t237
  %t242 = add i64 %t240, 16
  %t243 = load i64, ptr %l17, !tbaa !24
  %t245 = mul i64 8, %t243
  %t248 = add i64 %t242, %t245
  %t251 = call %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %s4, i64 %t213, i64 %t248)
  store %"compiler/eval:Ptr" %t251, ptr %l142
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t252 = load ptr, ptr %l124, !tbaa !29
  %t253 = load %"compiler/eval:Ptr", ptr %l142
  %t254 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %t252, %"compiler/eval:Ptr" %t253, i64 8)
  store i64 %t254, ptr %l143
  br label %bb43
bb43:
  %t255 = load i64, ptr %l143, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load %"compiler/eval:Ptr", ptr %l18
  %t258 = load %"compiler/eval:Ptr", ptr %l20
  %t259 = load i32, ptr %l19, !tbaa !23
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayTarget(ptr %v0, ptr %t256, %"compiler/eval:Ptr" %t257, %"compiler/eval:Ptr" %t258, i32 %t259, i64 %t255)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb45:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l149, !tbaa !29
  %t267 = load %"compiler/eval:Ptr", ptr %l18
  store %"compiler/eval:Ptr" %t267, ptr %l150
  %t268 = load %"compiler/eval:Ptr", ptr %l20
  store %"compiler/eval:Ptr" %t268, ptr %l151
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l19, !tbaa !23
  %t273 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %t269, i32 %t270)
  store i64 %t273, ptr %l154
  br label %bb46
bb46:
  %t274 = load ptr, ptr %l149, !tbaa !29
  %t275 = load %"compiler/eval:Ptr", ptr %l150
  %t276 = load %"compiler/eval:Ptr", ptr %l151
  %t277 = load i64, ptr %l154, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2ecopy(ptr %v0, ptr %t274, %"compiler/eval:Ptr" %t275, %"compiler/eval:Ptr" %t276, i64 %t277)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb48:
  %t278 = load i64, ptr %l16, !tbaa !24
  %t280 = add i64 %t278, 1
  store i64 %t280, ptr %l16, !tbaa !24
  br label %bb15
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunlinkReg(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"compiler/eval:reg"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca %"compiler/eval:reg"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/eval:scope"
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:reg"
  %l15 = alloca %"compiler/eval:reg"
  %l23 = alloca %"compiler/eval:reg"
  %l31 = alloca i1
  %l39 = alloca %"compiler/eval:scope"
  %l44 = alloca %"compiler/eval:scope"
  %l52 = alloca %"compiler/eval:reg"
  %t60 = alloca %"compiler/eval:scope", align 8
  %t72 = alloca %"compiler/eval:scope", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 45
  %t7 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t3, i64 %a1)
  store %"compiler/eval:reg" %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load %"compiler/eval:reg", ptr %l15
  store %"compiler/eval:reg" %t8, ptr %l2
  %t9 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 5
  %t10 = load i64, ptr %t9, !tbaa !24
  %t12 = icmp sge i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 5
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l3, !tbaa !24
  %t17 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/eval:Machine", ptr %t20, i32 0, i32 45
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t22, i64 %t23)
  store %"compiler/eval:reg" %t26, ptr %l23
  br label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 6
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elive(ptr %v0, ptr %t27, i64 %t29)
  store i1 %t32, ptr %l31
  br label %bb6
bb4:
  %t33 = load %"compiler/eval:reg", ptr %l23
  store %"compiler/eval:reg" %t33, ptr %l5
  %t34 = load i64, ptr %l4, !tbaa !24
  %t36 = getelementptr %"compiler/eval:reg", ptr %l5, i32 0, i32 4
  store i64 %t34, ptr %t36, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/eval:Machine", ptr %t37, i32 0, i32 45
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load %"compiler/eval:reg", ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eSetAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t39, i64 %t40, %"compiler/eval:reg" %t41)
  br label %bb5
bb5:
  br label %bb12
bb6:
  %t45 = load i1, ptr %l31, !tbaa !21
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t46 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  %t48 = load i64, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  %t51 = and i64 %t47, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l7, !tbaa !24
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 43
  %t59 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %t60, ptr %v0, ptr %t58, i64 %t59)
  call void @llvm.memmove.p0.p0.i64(ptr %l39, ptr %t60, i64 136, i1 false)
  br label %bb9
bb8:
  br label %bb11
bb9:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l39, i64 136, i1 false)
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr %"compiler/eval:scope", ptr %l8, i32 0, i32 4
  store i64 %t63, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/eval:Machine", ptr %t66, i32 0, i32 43
  %t69 = load i64, ptr %l6, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %l44, ptr %l8, i64 136, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %t72, ptr %l44, i64 136, i1 false)
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %t68, i64 %t69, ptr %t72)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t73 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t74 = load i64, ptr %t73, !tbaa !24
  %t76 = icmp sge i64 %t74, 0
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 4
  %t79 = load i64, ptr %t78, !tbaa !24
  store i64 %t79, ptr %l9, !tbaa !24
  %t81 = getelementptr %"compiler/eval:reg", ptr %l2, i32 0, i32 5
  %t82 = load i64, ptr %t81, !tbaa !24
  store i64 %t82, ptr %l10, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/eval:Machine", ptr %t84, i32 0, i32 45
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t86, i64 %t87)
  store %"compiler/eval:reg" %t90, ptr %l52
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t91 = load %"compiler/eval:reg", ptr %l52
  store %"compiler/eval:reg" %t91, ptr %l11
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = getelementptr %"compiler/eval:reg", ptr %l11, i32 0, i32 5
  store i64 %t92, ptr %t94, !tbaa !24
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/eval:Machine", ptr %t95, i32 0, i32 45
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load %"compiler/eval:reg", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eSetAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %t97, i64 %t98, %"compiler/eval:reg" %t99)
  br label %bb16
bb16:
  br label %bb17
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunmark(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l44 = alloca { i64, ptr }
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load i64, ptr %l1, !tbaa !24
  %t7 = sdiv i64 %t5, 8
  store i64 %t7, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = add i64 %t9, %t10
  %t15 = sub i64 %t13, 1
  %t17 = sdiv i64 %t15, 8
  %t19 = add i64 %t17, 1
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sgt i64 %t21, %t22
  br i1 %t25, label %bb4, label %bb5
bb4:
  %t27 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp sgt i64 %t27, 0
  br i1 %t29, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb9
bb6:
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = sub i64 %t31, %t32
  %t36 = load i64, ptr %l5, !tbaa !24
  %t39 = add i64 %t35, %t36
  %t41 = sub i64 %t39, 1
  %t42 = load i64, ptr %l5, !tbaa !24
  %t45 = sdiv i64 %t41, %t42
  store i64 %t45, ptr %l25, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l25, !tbaa !24
  store i64 %t47, ptr %l22, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l22, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l7, !tbaa !24
  %t50 = load i64, ptr %l6, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb11, label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb13
bb13:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t58 = load i64, ptr %l7, !tbaa !24
  %t59 = load i64, ptr %l5, !tbaa !24
  %t62 = mul i64 %t58, %t59
  %t65 = add i64 %t57, %t62
  %t69 = getelementptr %"compiler/eval:Machine", ptr %a0, i32 0, i32 37
  %t70 = load { i64, ptr }, ptr %t69, !tbaa !27
  store { i64, ptr } %t70, ptr %l44, !tbaa !27
  %t73 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr i64, ptr %t74, i64 %t65
  store i64 0, ptr %t75, !tbaa !34
  br label %bb14
bb14:
  %t76 = load i64, ptr %l7, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l7, !tbaa !24
  br label %bb10
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2ecompiler_2feval_3aMachine_2eunwind(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/eval:global"
  %l14 = alloca i1
  %l18 = alloca i1
  %l38 = alloca i1
  %l43 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i64
  %l71 = alloca %"compiler/eval:global"
  %l78 = alloca %"compiler/eval:global"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/eval:Machine", ptr %t1, i32 0, i32 13
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 1
  %t9 = load i32, ptr %t8
  %t11 = trunc i64 1 to i32
  %t12 = icmp eq i32 %t9, %t11
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/eval:Machine", ptr %t15, i32 0, i32 50
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  store i1 %t22, ptr %l18, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l18, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/eval:Machine", ptr %t25, i32 0, i32 12
  %t28 = load { i64, [5 x i64] }, ptr %t27
  %t32 = extractvalue { i64, [5 x i64] } %t28, 0
  %t33 = icmp eq i64 %t32, 3
  br i1 %t33, label %bb9, label %bb10
bb8:
  br label %bb19
bb9:
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2erunCleanups(ptr %v0, ptr %t35, i64 %t36)
  br label %bb12
bb12:
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_f4c8d7149bd44e26_572dd2a903112792)
  unreachable
bb18:
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/eval:Machine", ptr %t39, i32 0, i32 50
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = load i64, ptr %l1, !tbaa !24
  %t46 = icmp sgt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb21, label %bb22
bb21:
  br label %bb26
bb22:
  br label %bb23
bb23:
  %t50 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropFrame(ptr %v0, ptr %t50)
  br label %bb24
bb24:
  br label %bb25
bb25:
  br label %bb20
bb26:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/eval:Machine", ptr %t52, i32 0, i32 64
  %t55 = load i64, ptr %t54, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb27, label %bb28
bb27:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/eval:Machine", ptr %t59, i32 0, i32 13
  %t62 = load i1, ptr %t61, !tbaa !21
  store i1 %t62, ptr %l38, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb29
bb29:
  %t64 = load i1, ptr %l38, !tbaa !21
  br i1 %t64, label %bb30, label %bb31
bb30:
  store i64 0, ptr %l3, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/eval:Machine", ptr %t65, i32 0, i32 33
  %t69 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t67)
  store i64 %t69, ptr %l43
  br label %bb32
bb31:
  br label %bb51
bb32:
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t72 = load i64, ptr %l3, !tbaa !24
  %t75 = icmp sgt i64 %t71, %t72
  br i1 %t75, label %bb33, label %bb34
bb33:
  %t77 = load i64, ptr %l5, !tbaa !24
  %t79 = icmp sgt i64 %t77, 0
  br i1 %t79, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb38
bb35:
  %t81 = load i64, ptr %l4, !tbaa !24
  %t82 = load i64, ptr %l3, !tbaa !24
  %t85 = sub i64 %t81, %t82
  %t86 = load i64, ptr %l5, !tbaa !24
  %t89 = add i64 %t85, %t86
  %t91 = sub i64 %t89, 1
  %t92 = load i64, ptr %l5, !tbaa !24
  %t95 = sdiv i64 %t91, %t92
  store i64 %t95, ptr %l50, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb37
bb37:
  %t97 = load i64, ptr %l50, !tbaa !24
  store i64 %t97, ptr %l47, !tbaa !24
  br label %bb38
bb38:
  %t98 = load i64, ptr %l47, !tbaa !24
  store i64 %t98, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb39
bb39:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l6, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb40, label %bb41
bb40:
  br label %bb50
bb41:
  br label %bb42
bb42:
  %t107 = load i64, ptr %l3, !tbaa !24
  %t108 = load i64, ptr %l7, !tbaa !24
  %t109 = load i64, ptr %l5, !tbaa !24
  %t112 = mul i64 %t108, %t109
  %t115 = add i64 %t107, %t112
  store i64 %t115, ptr %l8, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/eval:Machine", ptr %t117, i32 0, i32 33
  %t120 = load i64, ptr %l8, !tbaa !24
  %t123 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t119, i64 %t120)
  store %"compiler/eval:global" %t123, ptr %l71
  br label %bb43
bb43:
  %t124 = getelementptr %"compiler/eval:global", ptr %l71, i32 0, i32 4
  %t125 = load i64, ptr %t124, !tbaa !24
  %t127 = icmp eq i64 %t125, 1
  br i1 %t127, label %bb44, label %bb45
bb44:
  %t129 = load i64, ptr %l8, !tbaa !24
  store i64 %t129, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/eval:Machine", ptr %t131, i32 0, i32 33
  %t134 = load i64, ptr %l9, !tbaa !24
  %t137 = call %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t133, i64 %t134)
  store %"compiler/eval:global" %t137, ptr %l78
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t138 = load %"compiler/eval:global", ptr %l78
  store %"compiler/eval:global" %t138, ptr %l11
  %t139 = load i64, ptr %l10, !tbaa !24
  %t141 = getelementptr %"compiler/eval:global", ptr %l11, i32 0, i32 4
  store i64 %t139, ptr %t141, !tbaa !24
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/eval:Machine", ptr %t142, i32 0, i32 33
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load %"compiler/eval:global", ptr %l11
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eSetAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %t144, i64 %t145, %"compiler/eval:global" %t146)
  br label %bb47
bb47:
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t150 = load i64, ptr %l7, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l7, !tbaa !24
  br label %bb39
bb50:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/eval:Machine", ptr %t154, i32 0, i32 64
  store i64 -1, ptr %t156, !tbaa !24
  br label %bb51
bb51:
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i64
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/eval:Machine", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/eval:Machine", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t9, i32 %a1)
  store i32 %t13, ptr %l9
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l5, !tbaa !29
  %t15 = load i32, ptr %l9, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t16, ptr %l10
  br label %bb2
bb2:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  store i64 0, ptr %l11, !tbaa !24
  br label %bb5
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t20 = ashr i64 %t18, 63
  store i64 %t20, ptr %l11, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = insertvalue { i64, i64 } undef, i64 %t22, 0
  %t24 = load i64, ptr %l11, !tbaa !24
  %t25 = insertvalue { i64, i64 } %t23, i64 %t24, 1
  store { i64, i64 } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideToFloat(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca { i64, i64 }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, i64 }
  %l14 = alloca double
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i1
  %l30 = alloca { i64, i64 }
  %l37 = alloca i64
  %l43 = alloca { i64, i64 }
  %l49 = alloca { i64, i64 }
  %l54 = alloca i1
  %l59 = alloca ptr
  %l63 = alloca i64
  %l65 = alloca double
  %l70 = alloca i64
  %l73 = alloca i64
  %l101 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a3, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp slt i64 %t3, 0
  store i1 %t5, ptr %l22, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t7 = load i1, ptr %l22, !tbaa !21
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i64, ptr %l1, !tbaa !24
  store i64 %t8, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l7, !tbaa !24
  %t12 = load i1, ptr %l5, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l2, !tbaa !24
  %t18 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t14, i64 %t15)
  store { i64, i64 } %t18, ptr %l30
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t19 = load { i64, i64 }, ptr %l30
  store { i64, i64 } %t19, ptr %l8
  %t20 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l6, !tbaa !24
  %t23 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t24 = load i64, ptr %t23, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store i64 0, ptr %l9, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  %t28 = icmp ne i64 %t26, 0
  br i1 %t28, label %bb8, label %bb9
bb8:
  %t30 = load i64, ptr %l6, !tbaa !24
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = call i64 @compiler_2feval_2elz128(i64 %t30, i64 %t31, i64 128)
  store i64 %t34, ptr %l37
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t35 = load i64, ptr %l37, !tbaa !24
  %t36 = sub i64 128, %t35
  %t38 = sub i64 %t36, 63
  store i64 %t38, ptr %l9, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l9, !tbaa !24
  %t46 = call { i64, i64 } @compiler_2feval_2eextend128(i64 %t40, i64 %t41, i64 %t42, i1 false)
  store { i64, i64 } %t46, ptr %l43
  br label %bb11
bb11:
  %t47 = load { i64, i64 }, ptr %l43
  store { i64, i64 } %t47, ptr %l10
  %t48 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l11, !tbaa !24
  %t51 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 1
  %t52 = load i64, ptr %t51, !tbaa !24
  store i64 %t52, ptr %l12, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t60 = call { i64, i64 } @compiler_2feval_2eshr128(i64 %t54, i64 %t55, i64 %t56, i1 false)
  store { i64, i64 } %t60, ptr %l49
  br label %bb12
bb12:
  %t61 = load { i64, i64 }, ptr %l49
  store { i64, i64 } %t61, ptr %l13
  %t62 = getelementptr { i64, i64 }, ptr %l13, i32 0, i32 0
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  %t65 = getelementptr { i64, i64 }, ptr %l13, i32 0, i32 1
  %t66 = load i64, ptr %t65, !tbaa !24
  store i64 %t66, ptr %l7, !tbaa !24
  %t68 = load i64, ptr %l11, !tbaa !24
  %t70 = icmp ne i64 %t68, 0
  br i1 %t70, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb15
bb14:
  %t72 = load i64, ptr %l12, !tbaa !24
  %t74 = icmp ne i64 %t72, 0
  store i1 %t74, ptr %l54, !tbaa !21
  br label %bb15
bb15:
  %t76 = load i1, ptr %l54, !tbaa !21
  br i1 %t76, label %bb16, label %bb17
bb16:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = or i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb18
bb17:
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l59, !tbaa !29
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i32, ptr %l4, !tbaa !23
  %t88 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eintToFloat(ptr %v0, ptr %t82, i64 %t83, i1 true, i32 %t84)
  store i64 %t88, ptr %l63
  br label %bb20
bb20:
  %t89 = load i32, ptr %l4, !tbaa !23
  %t90 = load ptr, ptr %l59, !tbaa !29
  %t91 = load i64, ptr %l63, !tbaa !24
  %t93 = call double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %t90, i64 %t91, i32 %t89)
  store double %t93, ptr %l65
  br label %bb21
bb21:
  %t94 = load double, ptr %l65, !tbaa !26
  store double %t94, ptr %l14, !tbaa !26
  store i64 0, ptr %l15, !tbaa !24
  %t95 = load i64, ptr %l9, !tbaa !24
  store i64 %t95, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t97 = load i64, ptr %l16, !tbaa !24
  %t98 = load i64, ptr %l15, !tbaa !24
  %t101 = icmp sgt i64 %t97, %t98
  br i1 %t101, label %bb22, label %bb23
bb22:
  %t103 = load i64, ptr %l17, !tbaa !24
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l70, !tbaa !24
  br label %bb27
bb24:
  %t107 = load i64, ptr %l16, !tbaa !24
  %t108 = load i64, ptr %l15, !tbaa !24
  %t111 = sub i64 %t107, %t108
  %t112 = load i64, ptr %l17, !tbaa !24
  %t115 = add i64 %t111, %t112
  %t117 = sub i64 %t115, 1
  %t118 = load i64, ptr %l17, !tbaa !24
  %t121 = sdiv i64 %t117, %t118
  store i64 %t121, ptr %l73, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb26
bb26:
  %t123 = load i64, ptr %l73, !tbaa !24
  store i64 %t123, ptr %l70, !tbaa !24
  br label %bb27
bb27:
  %t124 = load i64, ptr %l70, !tbaa !24
  store i64 %t124, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb28
bb28:
  %t125 = load i64, ptr %l19, !tbaa !24
  %t126 = load i64, ptr %l18, !tbaa !24
  %t129 = icmp slt i64 %t125, %t126
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t133 = load i64, ptr %l15, !tbaa !24
  %t134 = load i64, ptr %l19, !tbaa !24
  %t135 = load i64, ptr %l17, !tbaa !24
  %t138 = mul i64 %t134, %t135
  %t141 = add i64 %t133, %t138
  store i64 %t141, ptr %l20, !tbaa !24
  %t143 = load double, ptr %l14, !tbaa !26
  %t145 = fmul double %t143, 0x4000000000000000
  store double %t145, ptr %l14, !tbaa !26
  br label %bb32
bb32:
  %t147 = load i64, ptr %l19, !tbaa !24
  %t149 = add i64 %t147, 1
  store i64 %t149, ptr %l19, !tbaa !24
  br label %bb28
bb33:
  %t151 = load i1, ptr %l5, !tbaa !21
  br i1 %t151, label %bb34, label %bb35
bb34:
  %t153 = load double, ptr %l14, !tbaa !26
  %t155 = fneg double %t153
  store double %t155, ptr %l14, !tbaa !26
  br label %bb36
bb35:
  br label %bb36
bb36:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load double, ptr %l14, !tbaa !26
  %t159 = load i32, ptr %l4, !tbaa !23
  %t163 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %t157, double %t158, i32 %t159)
  store i64 %t163, ptr %l101
  br label %bb37
bb37:
  %t164 = load i64, ptr %l101, !tbaa !24
  store i64 %t164, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidthOf(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l5 = alloca i64
  %l19 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %l25 = alloca i64
  %l27 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca i64
  %l33 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr @G_2ecompiler_2feval_2evBool, !tbaa !24
  %t11 = icmp eq i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2feval_2evOrd, !tbaa !24
  %t18 = icmp eq i64 %t14, %t15
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i64 4, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr @G_2ecompiler_2feval_2evPtr, !tbaa !24
  %t25 = icmp eq i64 %t21, %t22
  br i1 %t25, label %bb8, label %bb9
bb8:
  store i64 8, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/eval:Machine", ptr %t28, i32 0, i32 0
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/eval:Machine", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i32, ptr %l1, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb11
bb11:
  %t40 = load ptr, ptr %l19, !tbaa !29
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l24
  br label %bb12
bb12:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/eval:Machine", ptr %t44, i32 0, i32 0
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l27, !tbaa !29
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/eval:Machine", ptr %t48, i32 0, i32 0
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i32, ptr %l1, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l31
  br label %bb15
bb14:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/eval:Machine", ptr %t56, i32 0, i32 0
  %t59 = load ptr, ptr %t58, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/eval:Machine", ptr %t60, i32 0, i32 0
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l39
  br label %bb18
bb15:
  %t68 = load ptr, ptr %l27, !tbaa !29
  %t69 = load i32, ptr %l31, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t70, ptr %l32
  br label %bb16
bb16:
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = call i64 @compiler_2ftypes_2eIntBytes(i64 %t71)
  store i64 %t72, ptr %l33
  br label %bb17
bb17:
  %t73 = load i64, ptr %l33, !tbaa !24
  store i64 %t73, ptr %l25, !tbaa !24
  br label %bb20
bb18:
  %t74 = load ptr, ptr %l35, !tbaa !29
  %t75 = load i32, ptr %l39, !tbaa !23
  %t76 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t74, i32 %t75)
  store i64 %t76, ptr %l40
  br label %bb19
bb19:
  %t77 = load i64, ptr %l40, !tbaa !24
  %t78 = sdiv i64 %t77, 8
  store i64 %t78, ptr %l25, !tbaa !24
  br label %bb20
bb20:
  %t80 = load i64, ptr %l25, !tbaa !24
  store i64 %t80, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eword(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr @G_2ecompiler_2feval_2evWide, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i64 8, ptr %l7, !tbaa !24
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i32, ptr %l1, !tbaa !23
  %t15 = call i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %t11, i32 %t12)
  store i64 %t15, ptr %l10
  br label %bb4
bb4:
  %t16 = load i64, ptr %l10, !tbaa !24
  store i64 %t16, ptr %l7, !tbaa !24
  br label %bb5
bb5:
  %t17 = load i64, ptr %l7, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesGlobal(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/mir:Lvalue"
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/mir:Lvalue" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Lvalue", ptr %l1, i32 0, i32 0
  %t2 = load { i64, [2 x i64] }, ptr %t1
  %t6 = extractvalue { i64, [2 x i64] } %t2, 0
  %t7 = icmp eq i64 %t6, 2
  br i1 %t7, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb9
bb4:
  br i1 true, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_eee052b68f79f6e4_de3952fe51604930)
  unreachable
bb9:
  %t9 = load i1, ptr %l4, !tbaa !21
  store i1 %t9, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2efBin_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2feval_2efBin, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2efConst_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2feval_2efConst, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2efUn_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2feval_2efUn, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2efibFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca ptr
  %l22 = alloca i32
  %l24 = alloca i32
  %l28 = alloca %"compiler/mir:Fn"
  %l32 = alloca i32
  %l36 = alloca i32
  %l40 = alloca i32
  %l44 = alloca i32
  %l48 = alloca i32
  %l52 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i32
  %l58 = alloca i32
  %l60 = alloca i32
  %l61 = alloca ptr
  %l62 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %l66 = alloca i32
  %l67 = alloca { i64, [4 x i64] }
  %l70 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca %"compiler/mir:Lvalue"
  %l84 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca { i64, [4 x i64] }
  %l89 = alloca ptr
  %l90 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i32
  %l94 = alloca i32
  %l95 = alloca { i64, [4 x i64] }
  %l98 = alloca ptr
  %l100 = alloca { i64, [2 x i64] }
  %l102 = alloca { i64, [7 x i64] }
  %l103 = alloca ptr
  %l105 = alloca %"compiler/mir:Lvalue"
  %l107 = alloca { i64, ptr }
  %l108 = alloca %"compiler/mir:Range"
  %l109 = alloca %"compiler/mir:Range"
  %l111 = alloca %"compiler/mir:Lvalue"
  %l115 = alloca %"compiler/mir:Call"
  %l116 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca i32
  %l125 = alloca i64
  %l126 = alloca i32
  %l127 = alloca i32
  %l128 = alloca { i64, [4 x i64] }
  %l131 = alloca ptr
  %l133 = alloca { i64, [2 x i64] }
  %l135 = alloca { i64, [7 x i64] }
  %l136 = alloca ptr
  %l138 = alloca %"compiler/mir:Lvalue"
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/mir:Range"
  %l142 = alloca %"compiler/mir:Range"
  %l144 = alloca %"compiler/mir:Lvalue"
  %l148 = alloca %"compiler/mir:Call"
  %l149 = alloca i32
  %l155 = alloca ptr
  %l156 = alloca i32
  %l158 = alloca i64
  %l159 = alloca i32
  %l160 = alloca i32
  %l162 = alloca %"compiler/mir:Lvalue"
  %l163 = alloca { i64, [4 x i64] }
  %l165 = alloca %"compiler/mir:Lvalue"
  %l173 = alloca ptr
  %l174 = alloca i32
  %l175 = alloca %"compiler/source:Span"
  %l177 = alloca %"compiler/mir:Lvalue"
  %l180 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t20 = alloca %"compiler/mir:Fn", align 8
  %t98 = alloca { i64, [4 x i64] }, align 8
  %t117 = alloca { i64, [4 x i64] }, align 8
  %t125 = alloca { i64, [8 x i64] }, align 8
  %t142 = alloca { i64, [21 x i64] }, align 8
  %t159 = alloca { i64, [8 x i64] }, align 8
  %t178 = alloca { i64, [4 x i64] }, align 8
  %t197 = alloca { i64, [7 x i64] }, align 8
  %t209 = alloca { i64, [4 x i64] }, align 8
  %t249 = alloca { i64, [8 x i64] }, align 8
  %t268 = alloca { i64, [4 x i64] }, align 8
  %t287 = alloca { i64, [7 x i64] }, align 8
  %t299 = alloca { i64, [4 x i64] }, align 8
  %t339 = alloca { i64, [8 x i64] }, align 8
  %t359 = alloca { i64, [4 x i64] }, align 8
  %t368 = alloca { i64, [4 x i64] }, align 8
  %t385 = alloca { i64, [21 x i64] }, align 8
  %t404 = alloca { i64, [4 x i64] }, align 8
  %t410 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i32 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i32, ptr %l18, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l19, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l22
  br label %bb2
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l19, !tbaa !29
  %t13 = load i32, ptr %l22, !tbaa !23
  %t15 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t12, i32 %t13, i32 %t11, i32 0, i32 0, i64 0)
  store i32 %t15, ptr %l24
  br label %bb3
bb3:
  %t16 = load i32, ptr %l24, !tbaa !23
  store i32 %t16, ptr %l3, !tbaa !23
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t20, ptr %v0, ptr %v1, ptr %t17, i64 %t18, i32 %t19)
  call void @llvm.memmove.p0.p0.i64(ptr %l28, ptr %t20, i64 248, i1 false)
  br label %bb4
bb4:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t24, ptr %lp4
  %t25 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %l28, i64 248, i1 false)
  %t26 = load ptr, ptr %lp4
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t28 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t32 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t26, i32 %t27, %"compiler/source:Span" %t28)
  store i32 %t32, ptr %l32
  br label %bb5
bb5:
  %t33 = load i32, ptr %l32, !tbaa !23
  store i32 %t33, ptr %l5, !tbaa !23
  %t34 = load ptr, ptr %lp4
  %t35 = load i32, ptr %l2, !tbaa !23
  %t36 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t40 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t34, i32 %t35, %"compiler/source:Span" %t36)
  store i32 %t40, ptr %l36
  br label %bb6
bb6:
  %t41 = load i32, ptr %l36, !tbaa !23
  store i32 %t41, ptr %l6, !tbaa !23
  %t42 = load ptr, ptr %lp4
  %t43 = load i32, ptr %l2, !tbaa !23
  %t44 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t48 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t42, i32 %t43, %"compiler/source:Span" %t44)
  store i32 %t48, ptr %l40
  br label %bb7
bb7:
  %t49 = load i32, ptr %l40, !tbaa !23
  store i32 %t49, ptr %l7, !tbaa !23
  %t50 = load ptr, ptr %lp4
  %t51 = load i32, ptr %l2, !tbaa !23
  %t52 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t56 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t50, i32 %t51, %"compiler/source:Span" %t52)
  store i32 %t56, ptr %l44
  br label %bb8
bb8:
  %t57 = load i32, ptr %l44, !tbaa !23
  store i32 %t57, ptr %l8, !tbaa !23
  %t58 = load ptr, ptr %lp4
  %t59 = load i32, ptr %l2, !tbaa !23
  %t60 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t64 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t58, i32 %t59, %"compiler/source:Span" %t60)
  store i32 %t64, ptr %l48
  br label %bb9
bb9:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l9, !tbaa !23
  %t66 = load ptr, ptr %lp4
  %t67 = load i32, ptr %l2, !tbaa !23
  %t68 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t72 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t66, i32 %t67, %"compiler/source:Span" %t68)
  store i32 %t72, ptr %l52
  br label %bb10
bb10:
  %t73 = load i32, ptr %l52, !tbaa !23
  store i32 %t73, ptr %l10, !tbaa !23
  %t74 = load ptr, ptr %lp4
  %t76 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t74)
  store i32 %t76, ptr %l54
  br label %bb11
bb11:
  %t77 = load i32, ptr %l54, !tbaa !23
  store i32 %t77, ptr %l11, !tbaa !23
  %t78 = load ptr, ptr %lp4
  %t80 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t78)
  store i32 %t80, ptr %l56
  br label %bb12
bb12:
  %t81 = load i32, ptr %l56, !tbaa !23
  store i32 %t81, ptr %l12, !tbaa !23
  %t82 = load ptr, ptr %lp4
  %t84 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t82)
  store i32 %t84, ptr %l58
  br label %bb13
bb13:
  %t85 = load i32, ptr %l58, !tbaa !23
  store i32 %t85, ptr %l13, !tbaa !23
  %t86 = load ptr, ptr %lp4
  %t88 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v1, ptr %t86)
  store i32 %t88, ptr %l60
  br label %bb14
bb14:
  %t89 = load i32, ptr %l60, !tbaa !23
  store i32 %t89, ptr %l14, !tbaa !23
  %t90 = load ptr, ptr %lp4
  store ptr %t90, ptr %l61, !tbaa !29
  %t91 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t91, ptr %l62, !tbaa !23
  %t92 = load i32, ptr %l5, !tbaa !23
  %t94 = sext i32 %t92 to i64
  store i64 %t94, ptr %l64, !tbaa !24
  store i32 15, ptr %l65
  %t95 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t95, ptr %l66, !tbaa !23
  %t96 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t96, ptr %l67
  br label %bb15
bb15:
  %t97 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 0
  store i64 2, ptr %t99
  %t101 = insertvalue { i32, i64 } undef, i32 %t97, 0
  %t102 = insertvalue { i32, i64 } %t101, i64 2, 1
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  store { i32, i64 } %t102, ptr %t103
  %t104 = load { i64, [4 x i64] }, ptr %t98
  %t105 = load ptr, ptr %l61, !tbaa !29
  %t106 = load i32, ptr %l62, !tbaa !23
  %t107 = load i64, ptr %l64, !tbaa !24
  %t108 = load i32, ptr %l65
  %t109 = load i32, ptr %l66, !tbaa !23
  %t110 = load { i64, [4 x i64] }, ptr %l67
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t105, i32 %t106, i64 %t107, i32 %t108, i32 %t109, { i64, [4 x i64] } %t110, { i64, [4 x i64] } %t104)
  br label %bb16
bb16:
  %t112 = load ptr, ptr %lp4
  store ptr %t112, ptr %l70, !tbaa !29
  %t113 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t113, ptr %l71, !tbaa !23
  %t114 = load i32, ptr %l5, !tbaa !23
  %t116 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t114)
  store %"compiler/mir:Lvalue" %t116, ptr %l73
  br label %bb17
bb17:
  store { i64, [4 x i64] } zeroinitializer, ptr %t117
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 0
  store i64 1, ptr %t118
  %t119 = load %"compiler/mir:Lvalue", ptr %l73
  %t120 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t119, 0
  %t121 = getelementptr { i64, [4 x i64] }, ptr %t117, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t120, ptr %t121
  %t122 = load { i64, [4 x i64] }, ptr %t117
  %t123 = load i32, ptr %l11, !tbaa !23
  %t124 = load i32, ptr %l12, !tbaa !23
  store { i64, [8 x i64] } zeroinitializer, ptr %t125
  %t126 = getelementptr { i64, [8 x i64] }, ptr %t125, i32 0, i32 0
  store i64 2, ptr %t126
  %t128 = insertvalue { { i64, [4 x i64] }, i32, i32 } undef, { i64, [4 x i64] } %t122, 0
  %t130 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t128, i32 %t123, 1
  %t132 = insertvalue { { i64, [4 x i64] }, i32, i32 } %t130, i32 %t124, 2
  %t133 = getelementptr { i64, [8 x i64] }, ptr %t125, i32 0, i32 1
  store { { i64, [4 x i64] }, i32, i32 } %t132, ptr %t133
  %t134 = load { i64, [8 x i64] }, ptr %t125
  %t135 = load ptr, ptr %l70, !tbaa !29
  %t136 = load i32, ptr %l71, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t135, i32 %t136, { i64, [8 x i64] } %t134)
  br label %bb18
bb18:
  %t138 = load ptr, ptr %lp4
  %t139 = load i32, ptr %l11, !tbaa !23
  %t140 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t141 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [21 x i64] }, ptr %t142, i32 0, i32 0
  store i64 4, ptr %t143
  %t145 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t140, 0
  %t147 = insertvalue { %"compiler/source:Span", i32 } %t145, i32 %t141, 1
  %t148 = getelementptr { i64, [21 x i64] }, ptr %t142, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t147, ptr %t148
  %t149 = load { i64, [21 x i64] }, ptr %t142
  %t151 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t149, ptr %t151
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t138, i32 %t139, ptr %t151)
  br label %bb19
bb19:
  %t155 = load ptr, ptr %lp4
  store ptr %t155, ptr %l84, !tbaa !29
  %t156 = load i32, ptr %l11, !tbaa !23
  store i32 %t156, ptr %l85, !tbaa !23
  %t157 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t157, ptr %l86
  %t158 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t158, ptr %l87
  br label %bb20
bb20:
  store { i64, [8 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [8 x i64] }, ptr %t159, i32 0, i32 0
  store i64 5, ptr %t160
  %t161 = load %"compiler/source:Span", ptr %l86
  %t162 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t161, 0
  %t163 = load { i64, [4 x i64] }, ptr %l87
  %t164 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t162, { i64, [4 x i64] } %t163, 1
  %t165 = getelementptr { i64, [8 x i64] }, ptr %t159, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t164, ptr %t165
  %t166 = load { i64, [8 x i64] }, ptr %t159
  %t167 = load ptr, ptr %l84, !tbaa !29
  %t168 = load i32, ptr %l85, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t167, i32 %t168, { i64, [8 x i64] } %t166)
  br label %bb21
bb21:
  %t170 = load ptr, ptr %lp4
  store ptr %t170, ptr %l89, !tbaa !29
  %t171 = load i32, ptr %l12, !tbaa !23
  store i32 %t171, ptr %l90, !tbaa !23
  %t172 = load i32, ptr %l6, !tbaa !23
  %t174 = sext i32 %t172 to i64
  store i64 %t174, ptr %l92, !tbaa !24
  store i32 4, ptr %l93
  %t175 = load i32, ptr %l2, !tbaa !23
  store i32 %t175, ptr %l94, !tbaa !23
  %t176 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t176, ptr %l95
  br label %bb22
bb22:
  %t177 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t178
  %t179 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 0
  store i64 2, ptr %t179
  %t181 = insertvalue { i32, i64 } undef, i32 %t177, 0
  %t182 = insertvalue { i32, i64 } %t181, i64 1, 1
  %t183 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  store { i32, i64 } %t182, ptr %t183
  %t184 = load { i64, [4 x i64] }, ptr %t178
  %t185 = load ptr, ptr %l89, !tbaa !29
  %t186 = load i32, ptr %l90, !tbaa !23
  %t187 = load i64, ptr %l92, !tbaa !24
  %t188 = load i32, ptr %l93
  %t189 = load i32, ptr %l94, !tbaa !23
  %t190 = load { i64, [4 x i64] }, ptr %l95
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t185, i32 %t186, i64 %t187, i32 %t188, i32 %t189, { i64, [4 x i64] } %t190, { i64, [4 x i64] } %t184)
  br label %bb23
bb23:
  %t192 = load ptr, ptr %lp4
  store ptr %t192, ptr %l98, !tbaa !29
  %t193 = load i64, ptr %l1, !tbaa !24
  %t195 = call { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %t193)
  store { i64, [2 x i64] } %t195, ptr %l100
  br label %bb24
bb24:
  %t196 = load i32, ptr %l3, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t197
  %t198 = getelementptr { i64, [7 x i64] }, ptr %t197, i32 0, i32 0
  store i64 0, ptr %t198
  %t199 = load { i64, [2 x i64] }, ptr %l100
  %t200 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t199, 0
  %t202 = insertvalue { { i64, [2 x i64] }, i32 } %t200, i32 %t196, 1
  %t203 = getelementptr { i64, [7 x i64] }, ptr %t197, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t202, ptr %t203
  %t204 = load { i64, [7 x i64] }, ptr %t197
  store { i64, [7 x i64] } %t204, ptr %l102
  %t205 = load ptr, ptr %lp4
  store ptr %t205, ptr %l103, !tbaa !29
  %t206 = load i32, ptr %l6, !tbaa !23
  %t208 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t206)
  store %"compiler/mir:Lvalue" %t208, ptr %l105
  br label %bb25
bb25:
  store { i64, [4 x i64] } zeroinitializer, ptr %t209
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 0
  store i64 1, ptr %t210
  %t211 = load %"compiler/mir:Lvalue", ptr %l105
  %t212 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t211, 0
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t212, ptr %t213
  %t214 = load { i64, [4 x i64] }, ptr %t209
  %t215 = mul i64 1, 40
  %t216 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t215)
  %t217 = insertvalue { i64, ptr } undef, i64 1, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  store { i64, ptr } %t218, ptr %l107, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t221, i64 0
  store { i64, [4 x i64] } %t214, ptr %t222
  %t223 = load ptr, ptr %l103, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t225 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t223, { i64, ptr } %t224)
  store %"compiler/mir:Range" %t225, ptr %l108
  br label %bb26
bb26:
  %t226 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t226, ptr %l109
  %t227 = load i32, ptr %l8, !tbaa !23
  %t229 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t227)
  store %"compiler/mir:Lvalue" %t229, ptr %l111
  br label %bb27
bb27:
  %t230 = load i32, ptr %l13, !tbaa !23
  %t231 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t232 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t233 = load { i64, [7 x i64] }, ptr %l102
  %t234 = load %"compiler/mir:Range", ptr %l108
  %t235 = load %"compiler/mir:Range", ptr %l109
  %t236 = load %"compiler/mir:Lvalue", ptr %l111
  %t240 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t233, %"compiler/mir:Range" %t234, %"compiler/mir:Range" %t235, %"compiler/mir:Lvalue" %t236, i1 true, i32 %t230, i32 %t231, i32 %t232)
  store %"compiler/mir:Call" %t240, ptr %l115
  br label %bb28
bb28:
  %t241 = load ptr, ptr %l98, !tbaa !29
  %t242 = load %"compiler/mir:Call", ptr %l115
  %t243 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t241, %"compiler/mir:Call" %t242)
  store i32 %t243, ptr %l116
  br label %bb29
bb29:
  %t244 = load i32, ptr %l116, !tbaa !23
  %t245 = load ptr, ptr %lp4
  %t246 = load i32, ptr %l12, !tbaa !23
  %t247 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [8 x i64] }, ptr %t249, i32 0, i32 0
  store i64 4, ptr %t250
  %t252 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t247, 0
  %t254 = insertvalue { %"compiler/source:Span", i32 } %t252, i32 %t244, 1
  %t255 = getelementptr { i64, [8 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t254, ptr %t255
  %t256 = load { i64, [8 x i64] }, ptr %t249
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t245, i32 %t246, { i64, [8 x i64] } %t256)
  br label %bb30
bb30:
  %t260 = load ptr, ptr %lp4
  store ptr %t260, ptr %l122, !tbaa !29
  %t261 = load i32, ptr %l13, !tbaa !23
  store i32 %t261, ptr %l123, !tbaa !23
  %t262 = load i32, ptr %l7, !tbaa !23
  %t264 = sext i32 %t262 to i64
  store i64 %t264, ptr %l125, !tbaa !24
  store i32 4, ptr %l126
  %t265 = load i32, ptr %l2, !tbaa !23
  store i32 %t265, ptr %l127, !tbaa !23
  %t266 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t266, ptr %l128
  br label %bb31
bb31:
  %t267 = load i32, ptr %l2, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t268
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 0
  store i64 2, ptr %t269
  %t271 = insertvalue { i32, i64 } undef, i32 %t267, 0
  %t272 = insertvalue { i32, i64 } %t271, i64 2, 1
  %t273 = getelementptr { i64, [4 x i64] }, ptr %t268, i32 0, i32 1
  store { i32, i64 } %t272, ptr %t273
  %t274 = load { i64, [4 x i64] }, ptr %t268
  %t275 = load ptr, ptr %l122, !tbaa !29
  %t276 = load i32, ptr %l123, !tbaa !23
  %t277 = load i64, ptr %l125, !tbaa !24
  %t278 = load i32, ptr %l126
  %t279 = load i32, ptr %l127, !tbaa !23
  %t280 = load { i64, [4 x i64] }, ptr %l128
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t275, i32 %t276, i64 %t277, i32 %t278, i32 %t279, { i64, [4 x i64] } %t280, { i64, [4 x i64] } %t274)
  br label %bb32
bb32:
  %t282 = load ptr, ptr %lp4
  store ptr %t282, ptr %l131, !tbaa !29
  %t283 = load i64, ptr %l1, !tbaa !24
  %t285 = call { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %t283)
  store { i64, [2 x i64] } %t285, ptr %l133
  br label %bb33
bb33:
  %t286 = load i32, ptr %l3, !tbaa !23
  store { i64, [7 x i64] } zeroinitializer, ptr %t287
  %t288 = getelementptr { i64, [7 x i64] }, ptr %t287, i32 0, i32 0
  store i64 0, ptr %t288
  %t289 = load { i64, [2 x i64] }, ptr %l133
  %t290 = insertvalue { { i64, [2 x i64] }, i32 } undef, { i64, [2 x i64] } %t289, 0
  %t292 = insertvalue { { i64, [2 x i64] }, i32 } %t290, i32 %t286, 1
  %t293 = getelementptr { i64, [7 x i64] }, ptr %t287, i32 0, i32 1
  store { { i64, [2 x i64] }, i32 } %t292, ptr %t293
  %t294 = load { i64, [7 x i64] }, ptr %t287
  store { i64, [7 x i64] } %t294, ptr %l135
  %t295 = load ptr, ptr %lp4
  store ptr %t295, ptr %l136, !tbaa !29
  %t296 = load i32, ptr %l7, !tbaa !23
  %t298 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t296)
  store %"compiler/mir:Lvalue" %t298, ptr %l138
  br label %bb34
bb34:
  store { i64, [4 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [4 x i64] }, ptr %t299, i32 0, i32 0
  store i64 1, ptr %t300
  %t301 = load %"compiler/mir:Lvalue", ptr %l138
  %t302 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t301, 0
  %t303 = getelementptr { i64, [4 x i64] }, ptr %t299, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t302, ptr %t303
  %t304 = load { i64, [4 x i64] }, ptr %t299
  %t305 = mul i64 1, 40
  %t306 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t305)
  %t307 = insertvalue { i64, ptr } undef, i64 1, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  store { i64, ptr } %t308, ptr %l140, !tbaa !27
  %t310 = getelementptr { i64, ptr }, ptr %l140, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr { i64, [4 x i64] }, ptr %t311, i64 0
  store { i64, [4 x i64] } %t304, ptr %t312
  %t313 = load ptr, ptr %l136, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t315 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t313, { i64, ptr } %t314)
  store %"compiler/mir:Range" %t315, ptr %l141
  br label %bb35
bb35:
  %t316 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  store %"compiler/mir:Range" %t316, ptr %l142
  %t317 = load i32, ptr %l9, !tbaa !23
  %t319 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t317)
  store %"compiler/mir:Lvalue" %t319, ptr %l144
  br label %bb36
bb36:
  %t320 = load i32, ptr %l14, !tbaa !23
  %t321 = load i32, ptr @G_2ecompiler_2fmir_2eNoLocal, !tbaa !23
  %t322 = load i32, ptr @G_2ecompiler_2fmir_2eNoBlock, !tbaa !23
  %t323 = load { i64, [7 x i64] }, ptr %l135
  %t324 = load %"compiler/mir:Range", ptr %l141
  %t325 = load %"compiler/mir:Range", ptr %l142
  %t326 = load %"compiler/mir:Lvalue", ptr %l144
  %t330 = call %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %s0, { i64, [7 x i64] } %t323, %"compiler/mir:Range" %t324, %"compiler/mir:Range" %t325, %"compiler/mir:Lvalue" %t326, i1 true, i32 %t320, i32 %t321, i32 %t322)
  store %"compiler/mir:Call" %t330, ptr %l148
  br label %bb37
bb37:
  %t331 = load ptr, ptr %l131, !tbaa !29
  %t332 = load %"compiler/mir:Call", ptr %l148
  %t333 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v1, ptr %t331, %"compiler/mir:Call" %t332)
  store i32 %t333, ptr %l149
  br label %bb38
bb38:
  %t334 = load i32, ptr %l149, !tbaa !23
  %t335 = load ptr, ptr %lp4
  %t336 = load i32, ptr %l13, !tbaa !23
  %t337 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store { i64, [8 x i64] } zeroinitializer, ptr %t339
  %t340 = getelementptr { i64, [8 x i64] }, ptr %t339, i32 0, i32 0
  store i64 4, ptr %t340
  %t342 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t337, 0
  %t344 = insertvalue { %"compiler/source:Span", i32 } %t342, i32 %t334, 1
  %t345 = getelementptr { i64, [8 x i64] }, ptr %t339, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t344, ptr %t345
  %t346 = load { i64, [8 x i64] }, ptr %t339
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t335, i32 %t336, { i64, [8 x i64] } %t346)
  br label %bb39
bb39:
  %t350 = load ptr, ptr %lp4
  store ptr %t350, ptr %l155, !tbaa !29
  %t351 = load i32, ptr %l14, !tbaa !23
  store i32 %t351, ptr %l156, !tbaa !23
  %t352 = load i32, ptr %l10, !tbaa !23
  %t354 = sext i32 %t352 to i64
  store i64 %t354, ptr %l158, !tbaa !24
  store i32 3, ptr %l159
  %t355 = load i32, ptr %l2, !tbaa !23
  store i32 %t355, ptr %l160, !tbaa !23
  %t356 = load i32, ptr %l8, !tbaa !23
  %t358 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t356)
  store %"compiler/mir:Lvalue" %t358, ptr %l162
  br label %bb40
bb40:
  store { i64, [4 x i64] } zeroinitializer, ptr %t359
  %t360 = getelementptr { i64, [4 x i64] }, ptr %t359, i32 0, i32 0
  store i64 1, ptr %t360
  %t361 = load %"compiler/mir:Lvalue", ptr %l162
  %t362 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t361, 0
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t359, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t362, ptr %t363
  %t364 = load { i64, [4 x i64] }, ptr %t359
  store { i64, [4 x i64] } %t364, ptr %l163
  %t365 = load i32, ptr %l9, !tbaa !23
  %t367 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t365)
  store %"compiler/mir:Lvalue" %t367, ptr %l165
  br label %bb41
bb41:
  store { i64, [4 x i64] } zeroinitializer, ptr %t368
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 0
  store i64 1, ptr %t369
  %t370 = load %"compiler/mir:Lvalue", ptr %l165
  %t371 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t370, 0
  %t372 = getelementptr { i64, [4 x i64] }, ptr %t368, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t371, ptr %t372
  %t373 = load { i64, [4 x i64] }, ptr %t368
  %t374 = load ptr, ptr %l155, !tbaa !29
  %t375 = load i32, ptr %l156, !tbaa !23
  %t376 = load i64, ptr %l158, !tbaa !24
  %t377 = load i32, ptr %l159
  %t378 = load i32, ptr %l160, !tbaa !23
  %t379 = load { i64, [4 x i64] }, ptr %l163
  call void @compiler_2feval_2etprim(ptr %v1, ptr %t374, i32 %t375, i64 %t376, i32 %t377, i32 %t378, { i64, [4 x i64] } %t379, { i64, [4 x i64] } %t373)
  br label %bb42
bb42:
  %t381 = load ptr, ptr %lp4
  %t382 = load i32, ptr %l14, !tbaa !23
  %t383 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t384 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t385
  %t386 = getelementptr { i64, [21 x i64] }, ptr %t385, i32 0, i32 0
  store i64 4, ptr %t386
  %t388 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t383, 0
  %t390 = insertvalue { %"compiler/source:Span", i32 } %t388, i32 %t384, 1
  %t391 = getelementptr { i64, [21 x i64] }, ptr %t385, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t390, ptr %t391
  %t392 = load { i64, [21 x i64] }, ptr %t385
  %t394 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t392, ptr %t394
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t381, i32 %t382, ptr %t394)
  br label %bb43
bb43:
  %t398 = load ptr, ptr %lp4
  store ptr %t398, ptr %l173, !tbaa !29
  %t399 = load i32, ptr %l14, !tbaa !23
  store i32 %t399, ptr %l174, !tbaa !23
  %t400 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t400, ptr %l175
  %t401 = load i32, ptr %l10, !tbaa !23
  %t403 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t401)
  store %"compiler/mir:Lvalue" %t403, ptr %l177
  br label %bb44
bb44:
  store { i64, [4 x i64] } zeroinitializer, ptr %t404
  %t405 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 0
  store i64 1, ptr %t405
  %t406 = load %"compiler/mir:Lvalue", ptr %l177
  %t407 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t406, 0
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t407, ptr %t408
  %t409 = load { i64, [4 x i64] }, ptr %t404
  store { i64, [8 x i64] } zeroinitializer, ptr %t410
  %t411 = getelementptr { i64, [8 x i64] }, ptr %t410, i32 0, i32 0
  store i64 5, ptr %t411
  %t412 = load %"compiler/source:Span", ptr %l175
  %t413 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t412, 0
  %t415 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t413, { i64, [4 x i64] } %t409, 1
  %t416 = getelementptr { i64, [8 x i64] }, ptr %t410, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t415, ptr %t416
  %t417 = load { i64, [8 x i64] }, ptr %t410
  %t418 = load ptr, ptr %l173, !tbaa !29
  %t419 = load i32, ptr %l174, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t418, i32 %t419, { i64, [8 x i64] } %t417)
  br label %bb45
bb45:
  %t421 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l180, ptr %t421, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l180, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2feval_2efibHost(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp slt i64 %t1, 2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb5
bb2:
  %t7 = load i64, ptr %l0, !tbaa !24
  %t9 = sub i64 %t7, 1
  %t11 = call i64 @compiler_2feval_2efibHost(i64 %t9)
  store i64 %t11, ptr %l7
  br label %bb3
bb3:
  %t12 = load i64, ptr %l0, !tbaa !24
  %t14 = sub i64 %t12, 2
  %t16 = call i64 @compiler_2feval_2efibHost(i64 %t14)
  store i64 %t16, ptr %l10
  br label %bb4
bb4:
  %t17 = load i64, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l10, !tbaa !24
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %l3, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2feval_2efitsBits(i64 %a0, i1 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l24 = alloca i64
  %l30 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i64
  %l36 = alloca i64
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a1, label %bb1, label %bb2
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 64
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb9
bb3:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb8
bb4:
  %t7 = load i1, ptr %l3, !tbaa !21
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb5, label %bb6
bb5:
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp eq i64 %t11, 64
  store i1 %t13, ptr %l10, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb7
bb7:
  %t15 = load i1, ptr %l10, !tbaa !21
  store i1 %t15, ptr %l7, !tbaa !21
  br label %bb8
bb8:
  %t16 = load i1, ptr %l7, !tbaa !21
  store i1 %t16, ptr %rv
  br label %ret
bb9:
  %t17 = load i1, ptr %l3, !tbaa !21
  br i1 %t17, label %bb10, label %bb11
bb10:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp sge i64 %t19, 64
  br i1 %t21, label %bb12, label %bb13
bb11:
  br label %bb20
bb12:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb19
bb13:
  %t23 = load i64, ptr %l0, !tbaa !24
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = call i64 @compiler_2feval_2eminBits(i64 %t24)
  store i64 %t26, ptr %l19
  br label %bb14
bb14:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = icmp sge i64 %t27, %t28
  br i1 %t29, label %bb15, label %bb16
bb15:
  %t31 = load i64, ptr %l0, !tbaa !24
  store i64 %t31, ptr %l22, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  %t34 = call i64 @compiler_2feval_2eminBits(i64 %t32)
  store i64 %t34, ptr %l24
  br label %bb17
bb16:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb18
bb17:
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = add i64 %t35, 1
  %t38 = sub i64 0, %t36
  %t39 = load i64, ptr %l22, !tbaa !24
  %t41 = icmp sle i64 %t39, %t38
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb18
bb18:
  %t43 = load i1, ptr %l21, !tbaa !21
  store i1 %t43, ptr %l16, !tbaa !21
  br label %bb19
bb19:
  %t44 = load i1, ptr %l16, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
bb20:
  %t45 = load i64, ptr %l0, !tbaa !24
  %t47 = icmp sge i64 %t45, 0
  br i1 %t47, label %bb21, label %bb22
bb21:
  %t49 = load i64, ptr %l2, !tbaa !24
  %t51 = icmp sge i64 %t49, 63
  br i1 %t51, label %bb23, label %bb24
bb22:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb27
bb23:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb26
bb24:
  %t53 = load i64, ptr %l0, !tbaa !24
  store i64 %t53, ptr %l34, !tbaa !24
  %t54 = load i64, ptr %l2, !tbaa !24
  %t56 = call i64 @compiler_2feval_2ebmask(i64 %t54)
  store i64 %t56, ptr %l36
  br label %bb25
bb25:
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = load i64, ptr %l36, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  store i1 %t59, ptr %l33, !tbaa !21
  br label %bb26
bb26:
  %t61 = load i1, ptr %l33, !tbaa !21
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb27
bb27:
  %t62 = load i1, ptr %l30, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2efloatToWide(double %a0) #0 {
entry:
  %l0 = alloca double
  %l1 = alloca i64
  %l2 = alloca i1
  %l4 = alloca i64
  %l7 = alloca { i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l24 = alloca double
  %l43 = alloca { i64, i64 }
  %l49 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store double %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load double, ptr %l0, !tbaa !26
  %t3 = fcmp ogt double %t1, 0xc3e0000000000000
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load double, ptr %l0, !tbaa !26
  %t7 = fcmp olt double %t5, 0x43e0000000000000
  store i1 %t7, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  %t10 = load double, ptr %l0, !tbaa !26
  %t12 = fptosi double %t10 to i64
  store i64 %t12, ptr %l1, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = ashr i64 %t15, 63
  %t19 = insertvalue { i64, i64 } undef, i64 %t14, 0
  %t21 = insertvalue { i64, i64 } %t19, i64 %t17, 1
  store { i64, i64 } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load double, ptr %l0, !tbaa !26
  %t25 = fcmp olt double %t23, 0x0000000000000000
  store i1 %t25, ptr %l2, !tbaa !21
  %t27 = load i1, ptr %l2, !tbaa !21
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load double, ptr %l0, !tbaa !26
  %t31 = fneg double %t29
  store double %t31, ptr %l24, !tbaa !26
  br label %bb9
bb8:
  %t33 = load double, ptr %l0, !tbaa !26
  store double %t33, ptr %l24, !tbaa !26
  br label %bb9
bb9:
  %t35 = load double, ptr %l24, !tbaa !26
  %t38 = bitcast double %t35 to i64
  store i64 %t38, ptr %l4, !tbaa !24
  %t41 = load i64, ptr %l4, !tbaa !24
  %t43 = ashr i64 %t41, 52
  %t45 = and i64 %t43, 2047
  %t47 = sub i64 %t45, 1075
  %t49 = load i64, ptr %l4, !tbaa !24
  %t50 = shl i64 1, 52
  %t52 = sub i64 %t50, 1
  %t55 = and i64 %t49, %t52
  %t56 = shl i64 1, 52
  %t59 = or i64 %t55, %t56
  %t65 = call { i64, i64 } @compiler_2feval_2eshl128(i64 %t59, i64 0, i64 %t47)
  store { i64, i64 } %t65, ptr %l43
  br label %bb10
bb10:
  %t66 = load { i64, i64 }, ptr %l43
  store { i64, i64 } %t66, ptr %l7
  %t67 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  %t70 = getelementptr { i64, i64 }, ptr %l7, i32 0, i32 1
  %t71 = load i64, ptr %t70, !tbaa !24
  store i64 %t71, ptr %l9, !tbaa !24
  %t73 = load i1, ptr %l2, !tbaa !21
  br i1 %t73, label %bb11, label %bb12
bb11:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t75, i64 %t76)
  store { i64, i64 } %t79, ptr %l49
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t80 = load { i64, i64 }, ptr %l49
  store { i64, i64 } %t80, ptr %rv
  br label %ret
bb14:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t84 = insertvalue { i64, i64 } undef, i64 %t81, 0
  %t86 = insertvalue { i64, i64 } %t84, i64 %t82, 1
  store { i64, i64 } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2feval_2egGen_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 2, ptr @G_2ecompiler_2feval_2egGen, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/mir:Lvalue" @compiler_2feval_2egplace(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i32
  %l7 = alloca %"compiler/mir:Lvalue"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/mir:Lvalue"
  %t5 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 %a1, ptr %l2, !tbaa !23
  %t4 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %a0, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i32 %t4, ptr %l4
  br label %bb1
bb1:
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 2, ptr %t6
  %t7 = insertvalue { i64, i32, i32 } undef, i64 7, 0
  %t8 = load i32, ptr %l2, !tbaa !23
  %t9 = insertvalue { i64, i32, i32 } %t7, i32 %t8, 1
  %t10 = load i32, ptr %l4, !tbaa !23
  %t11 = insertvalue { i64, i32, i32 } %t9, i32 %t10, 2
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i64, i32, i32 } %t11, ptr %t12
  %t13 = load { i64, [2 x i64] }, ptr %t5
  %t14 = load %"compiler/mir:Range", ptr @G_2ecompiler_2fmir_2eEmpty
  %t17 = call %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %s0, { i64, [2 x i64] } %t13, %"compiler/mir:Range" %t14)
  store %"compiler/mir:Lvalue" %t17, ptr %l7
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/mir:Lvalue", ptr %l7
  store %"compiler/mir:Lvalue" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local i64 @compiler_2feval_2eminBits(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sge i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -9223372036854775808, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = sub i64 %t5, 1
  store i64 %t7, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = shl i64 1, %t9
  %t12 = sub i64 0, %t10
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  %t14 = load i64, ptr %l3, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, i64 } @compiler_2feval_2emul128(i64 %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i64
  %l2 = alloca i64
  %l4 = alloca { i64, i64 }
  %l9 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call { i64, i64 } @compiler_2feval_2emul64(i64 %t1, i64 %t2)
  store { i64, i64 } %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load { i64, i64 }, ptr %l9
  store { i64, i64 } %t6, ptr %l4
  %t7 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = getelementptr { i64, i64 }, ptr %l4, i32 0, i32 1
  %t11 = load i64, ptr %t10, !tbaa !24
  %t15 = load i64, ptr %l0, !tbaa !24
  %t19 = mul i64 %t15, %a3
  %t22 = add i64 %t11, %t19
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = mul i64 %a1, %t24
  %t30 = add i64 %t22, %t27
  %t32 = insertvalue { i64, i64 } undef, i64 %t8, 0
  %t34 = insertvalue { i64, i64 } %t32, i64 %t30, 1
  store { i64, i64 } %t34, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2emul64(i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = and i64 %t1, 4294967295
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l0, !tbaa !24
  %t8 = lshr i64 %t5, 32
  store i64 %t8, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l1, !tbaa !24
  %t13 = and i64 %t11, 4294967295
  store i64 %t13, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = lshr i64 %t15, 32
  store i64 %t18, ptr %l5, !tbaa !24
  %t21 = load i64, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = mul i64 %t21, %t22
  store i64 %t25, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = mul i64 %t27, %t28
  store i64 %t31, ptr %l7, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  %t37 = mul i64 %t33, %t34
  store i64 %t37, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l3, !tbaa !24
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = mul i64 %t39, %t40
  %t45 = load i64, ptr %l6, !tbaa !24
  %t48 = lshr i64 %t45, 32
  %t50 = load i64, ptr %l7, !tbaa !24
  %t52 = and i64 %t50, 4294967295
  %t55 = add i64 %t48, %t52
  %t56 = load i64, ptr %l8, !tbaa !24
  %t58 = and i64 %t56, 4294967295
  %t61 = add i64 %t55, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l6, !tbaa !24
  %t65 = and i64 %t63, 4294967295
  %t66 = load i64, ptr %l10, !tbaa !24
  %t68 = shl i64 %t66, 32
  %t71 = or i64 %t65, %t68
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = lshr i64 %t74, 32
  %t81 = add i64 %t43, %t77
  %t82 = load i64, ptr %l8, !tbaa !24
  %t85 = lshr i64 %t82, 32
  %t89 = add i64 %t81, %t85
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = lshr i64 %t90, 32
  %t97 = add i64 %t89, %t93
  %t102 = insertvalue { i64, i64 } undef, i64 %t71, 0
  %t104 = insertvalue { i64, i64 } %t102, i64 %t97, 1
  store { i64, i64 } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local { i64, i64 } @compiler_2feval_2eneg128(i64 %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, i64 } @compiler_2feval_2esub128(i64 0, i64 0, i64 %a0, i64 %a1)
  store { i64, i64 } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, i64 }, ptr %l4
  store { i64, i64 } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2feval_2eovFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i32
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l15 = alloca i32
  %l16 = alloca %"compiler/mir:Fn"
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i32
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca %"compiler/mir:Lvalue"
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca { i64, [4 x i64] }
  %l30 = alloca { i64, [4 x i64] }
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"compiler/mir:Range"
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca %"compiler/source:Span"
  %l46 = alloca %"compiler/mir:Lvalue"
  %l49 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t27 = alloca %"compiler/mir:Fn", align 8
  %t67 = alloca { i64, [15 x i64] }, align 8
  %t77 = alloca { i64, [21 x i64] }, align 8
  %t96 = alloca { i64, [21 x i64] }, align 8
  %t115 = alloca { i64, [4 x i64] }, align 8
  %t121 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i64 %a1, ptr %l7, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = mul i64 2, 4
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 2, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l12, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i32, ptr %t13, i64 0
  store i32 %t5, ptr %t14, !tbaa !33
  %t16 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i32, ptr %t17, i64 1
  store i32 %t6, ptr %t18, !tbaa !33
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t4, { i64, ptr } %t20)
  store i32 %t21, ptr %l13
  br label %bb1
bb1:
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t23 = load ptr, ptr %l8, !tbaa !29
  %t24 = load i32, ptr %l13, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t23, i32 %t24, i32 %t22, i32 0, i32 0, i64 0)
  store i32 %t26, ptr %l15
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l6, !tbaa !29
  %t29 = load i64, ptr %l7, !tbaa !24
  %t30 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2feval_2etfn(ptr %t27, ptr %v0, ptr %v1, ptr %t28, i64 %t29, i32 %t30)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t27, i64 248, i1 false)
  br label %bb3
bb3:
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t31, ptr %lp4
  %t32 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %t32, ptr %l16, i64 248, i1 false)
  %t33 = load ptr, ptr %lp4
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t35 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t39 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t33, i32 %t34, %"compiler/source:Span" %t35)
  store i32 %t39, ptr %l20
  br label %bb4
bb4:
  %t40 = load i32, ptr %l20, !tbaa !23
  store i32 %t40, ptr %l5, !tbaa !23
  %t41 = load ptr, ptr %lp4
  store ptr %t41, ptr %l21, !tbaa !29
  %t42 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t42, ptr %l22, !tbaa !23
  %t43 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t43, ptr %l23
  %t44 = load i32, ptr %l5, !tbaa !23
  %t46 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t44)
  store %"compiler/mir:Lvalue" %t46, ptr %l25
  br label %bb5
bb5:
  store i32 %a2, ptr %l26
  %t48 = load i32, ptr %l3, !tbaa !23
  store i32 %t48, ptr %l27, !tbaa !23
  %t49 = load ptr, ptr %lp4
  store ptr %t49, ptr %l28, !tbaa !29
  %t50 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 0)
  store { i64, [4 x i64] } %t50, ptr %l29
  br label %bb6
bb6:
  %t51 = call { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 1)
  store { i64, [4 x i64] } %t51, ptr %l30
  br label %bb7
bb7:
  %t52 = mul i64 2, 40
  %t53 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t52)
  %t54 = insertvalue { i64, ptr } undef, i64 2, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l31, !tbaa !27
  %t56 = load { i64, [4 x i64] }, ptr %l29
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t58, i64 0
  store { i64, [4 x i64] } %t56, ptr %t59
  %t60 = load { i64, [4 x i64] }, ptr %l30
  %t61 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t62, i64 1
  store { i64, [4 x i64] } %t60, ptr %t63
  %t64 = load ptr, ptr %l28, !tbaa !29
  %t65 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t66 = call %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v1, ptr %s0, ptr %t64, { i64, ptr } %t65)
  store %"compiler/mir:Range" %t66, ptr %l32
  br label %bb8
bb8:
  store { i64, [15 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [15 x i64] }, ptr %t67, i32 0, i32 0
  store i64 4, ptr %t68
  %t69 = load i32, ptr %l26
  %t70 = insertvalue { i32, i32, %"compiler/mir:Range" } undef, i32 %t69, 0
  %t71 = load i32, ptr %l27, !tbaa !23
  %t72 = insertvalue { i32, i32, %"compiler/mir:Range" } %t70, i32 %t71, 1
  %t73 = load %"compiler/mir:Range", ptr %l32
  %t74 = insertvalue { i32, i32, %"compiler/mir:Range" } %t72, %"compiler/mir:Range" %t73, 2
  %t75 = getelementptr { i64, [15 x i64] }, ptr %t67, i32 0, i32 1
  store { i32, i32, %"compiler/mir:Range" } %t74, ptr %t75
  %t76 = load { i64, [15 x i64] }, ptr %t67
  store { i64, [21 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [21 x i64] }, ptr %t77, i32 0, i32 0
  store i64 0, ptr %t78
  %t79 = load %"compiler/source:Span", ptr %l23
  %t80 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t79, 0
  %t81 = load %"compiler/mir:Lvalue", ptr %l25
  %t82 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t80, %"compiler/mir:Lvalue" %t81, 1
  %t84 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t82, { i64, [15 x i64] } %t76, 2
  %t85 = getelementptr { i64, [21 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t84, ptr %t85
  %t86 = load { i64, [21 x i64] }, ptr %t77
  %t88 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t86, ptr %t88
  %t89 = load ptr, ptr %l21, !tbaa !29
  %t90 = load i32, ptr %l22, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t89, i32 %t90, ptr %t88)
  br label %bb9
bb9:
  %t92 = load ptr, ptr %lp4
  %t93 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t94 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t95 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t96
  %t97 = getelementptr { i64, [21 x i64] }, ptr %t96, i32 0, i32 0
  store i64 4, ptr %t97
  %t99 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t94, 0
  %t101 = insertvalue { %"compiler/source:Span", i32 } %t99, i32 %t95, 1
  %t102 = getelementptr { i64, [21 x i64] }, ptr %t96, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t101, ptr %t102
  %t103 = load { i64, [21 x i64] }, ptr %t96
  %t105 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t103, ptr %t105
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t92, i32 %t93, ptr %t105)
  br label %bb10
bb10:
  %t109 = load ptr, ptr %lp4
  store ptr %t109, ptr %l42, !tbaa !29
  %t110 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t110, ptr %l43, !tbaa !23
  %t111 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t111, ptr %l44
  %t112 = load i32, ptr %l5, !tbaa !23
  %t114 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t112)
  store %"compiler/mir:Lvalue" %t114, ptr %l46
  br label %bb11
bb11:
  store { i64, [4 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 0
  store i64 1, ptr %t116
  %t117 = load %"compiler/mir:Lvalue", ptr %l46
  %t118 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t117, 0
  %t119 = getelementptr { i64, [4 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t118, ptr %t119
  %t120 = load { i64, [4 x i64] }, ptr %t115
  store { i64, [8 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [8 x i64] }, ptr %t121, i32 0, i32 0
  store i64 5, ptr %t122
  %t123 = load %"compiler/source:Span", ptr %l44
  %t124 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t123, 0
  %t126 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t124, { i64, [4 x i64] } %t120, 1
  %t127 = getelementptr { i64, [8 x i64] }, ptr %t121, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t126, ptr %t127
  %t128 = load { i64, [8 x i64] }, ptr %t121
  %t129 = load ptr, ptr %l42, !tbaa !29
  %t130 = load i32, ptr %l43, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t129, i32 %t130, { i64, [8 x i64] } %t128)
  br label %bb12
bb12:
  %t132 = load ptr, ptr %lp4
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t132, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l49, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2eoverflows64(i32 %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l38 = alloca i1
  %l45 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  br i1 %a3, label %bb1, label %bb2
bb1:
  %t3 = load i32, ptr %l0
  %t5 = trunc i64 3 to i32
  %t6 = icmp eq i32 %t3, %t5
  br i1 %t6, label %bb3, label %bb4
bb2:
  br label %bb27
bb3:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t9 = load i64, ptr %l2, !tbaa !24
  %t12 = add i64 %t8, %t9
  store i64 %t12, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = xor i64 %t14, %t15
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = xor i64 %t19, %t20
  %t26 = and i64 %t18, %t23
  %t28 = icmp slt i64 %t26, 0
  store i1 %t28, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t30 = load i32, ptr %l0
  %t32 = trunc i64 4 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = sub i64 %t35, %t36
  %t41 = load i64, ptr %l1, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = xor i64 %t41, %t42
  %t46 = load i64, ptr %l1, !tbaa !24
  %t50 = xor i64 %t46, %t39
  %t53 = and i64 %t45, %t50
  %t55 = icmp slt i64 %t53, 0
  store i1 %t55, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t57 = load i64, ptr %l1, !tbaa !24
  %t59 = icmp eq i64 %t57, 0
  br i1 %t59, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb11
bb10:
  %t61 = load i64, ptr %l2, !tbaa !24
  %t63 = icmp eq i64 %t61, 0
  store i1 %t63, ptr %l38, !tbaa !21
  br label %bb11
bb11:
  %t65 = load i1, ptr %l38, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t67 = shl i64 1, 63
  store i64 %t67, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l1, !tbaa !24
  %t71 = icmp eq i64 %t69, -1
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t74 = load i64, ptr %l6, !tbaa !24
  %t77 = icmp eq i64 %t73, %t74
  store i1 %t77, ptr %l45, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb17
bb17:
  %t79 = load i1, ptr %l45, !tbaa !21
  br i1 %t79, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb19:
  %t80 = load i64, ptr %l2, !tbaa !24
  %t82 = icmp eq i64 %t80, -1
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load i64, ptr %l1, !tbaa !24
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = icmp eq i64 %t84, %t85
  store i1 %t88, ptr %l52, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t90 = load i1, ptr %l52, !tbaa !21
  store i1 %t90, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t91 = load i1, ptr %l49, !tbaa !21
  br i1 %t91, label %bb24, label %bb25
bb24:
  store i1 true, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t93 = load i64, ptr %l1, !tbaa !24
  %t94 = load i64, ptr %l2, !tbaa !24
  %t97 = mul i64 %t93, %t94
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = sdiv i64 %t97, %t98
  %t102 = load i64, ptr %l1, !tbaa !24
  %t105 = icmp ne i64 %t101, %t102
  store i1 %t105, ptr %rv
  br label %ret
bb27:
  %t107 = load i64, ptr %l1, !tbaa !24
  store i64 %t107, ptr %l7, !tbaa !65
  %t110 = load i64, ptr %l2, !tbaa !24
  store i64 %t110, ptr %l8, !tbaa !65
  %t113 = load i32, ptr %l0
  %t115 = trunc i64 3 to i32
  %t116 = icmp eq i32 %t113, %t115
  br i1 %t116, label %bb28, label %bb29
bb28:
  %t118 = load i64, ptr %l7, !tbaa !65
  %t119 = load i64, ptr %l8, !tbaa !65
  %t122 = add i64 %t118, %t119
  %t123 = load i64, ptr %l7, !tbaa !65
  %t126 = icmp ult i64 %t122, %t123
  store i1 %t126, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t128 = load i32, ptr %l0
  %t130 = trunc i64 4 to i32
  %t131 = icmp eq i32 %t128, %t130
  br i1 %t131, label %bb31, label %bb32
bb31:
  %t133 = load i64, ptr %l8, !tbaa !65
  %t134 = load i64, ptr %l7, !tbaa !65
  %t137 = icmp ugt i64 %t133, %t134
  store i1 %t137, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t139 = load i64, ptr %l7, !tbaa !65
  %t141 = icmp eq i64 %t139, 0
  br i1 %t141, label %bb34, label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t144 = load i64, ptr %l7, !tbaa !65
  %t145 = load i64, ptr %l8, !tbaa !65
  %t148 = mul i64 %t144, %t145
  %t149 = load i64, ptr %l7, !tbaa !65
  %t152 = udiv i64 %t148, %t149
  %t153 = load i64, ptr %l8, !tbaa !65
  %t156 = icmp ne i64 %t152, %t153
  store i1 %t156, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2erGlobal_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2feval_2erGlobal, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2erRequest_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2feval_2erRequest, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2eretFn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i32
  %l7 = alloca %"compiler/mir:Fn"
  %l8 = alloca ptr
  %l10 = alloca i32
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca %"compiler/mir:Lvalue"
  %l28 = alloca ptr
  %l29 = alloca i32
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/mir:Lvalue"
  %l35 = alloca %"compiler/mir:Fn"
  %s0 = alloca %olang.scope
  %t3 = alloca %"compiler/mir:Fn", align 8
  %t25 = alloca { i64, [15 x i64] }, align 8
  %t31 = alloca { i64, [21 x i64] }, align 8
  %t50 = alloca { i64, [21 x i64] }, align 8
  %t69 = alloca { i64, [4 x i64] }, align 8
  %t75 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2feval_2enfn(ptr %t3, ptr %v0, ptr %v1, ptr %t1, i64 %a1)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t3, i64 248, i1 false)
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 248, i64 8)
  store ptr %t6, ptr %lp3
  %t7 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %t7, ptr %l7, i64 248, i1 false)
  %t8 = load ptr, ptr %lp3
  store ptr %t8, ptr %l8, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i32 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = load i32, ptr %l10, !tbaa !23
  %t16 = call i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v1, ptr %t13, i32 %t14, %"compiler/source:Span" %t12)
  store i32 %t16, ptr %l12
  br label %bb3
bb3:
  %t17 = load i32, ptr %l12, !tbaa !23
  store i32 %t17, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %lp3
  store ptr %t18, ptr %l13, !tbaa !29
  %t19 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  %t20 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t20, ptr %l15
  %t21 = load i32, ptr %l4, !tbaa !23
  %t23 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t21)
  store %"compiler/mir:Lvalue" %t23, ptr %l17
  br label %bb4
bb4:
  store { i64, [15 x i64] } zeroinitializer, ptr %t25
  %t26 = getelementptr { i64, [15 x i64] }, ptr %t25, i32 0, i32 0
  store i64 0, ptr %t26
  %t28 = insertvalue { { i64, [4 x i64] } } undef, { i64, [4 x i64] } %a2, 0
  %t29 = getelementptr { i64, [15 x i64] }, ptr %t25, i32 0, i32 1
  store { { i64, [4 x i64] } } %t28, ptr %t29
  %t30 = load { i64, [15 x i64] }, ptr %t25
  store { i64, [21 x i64] } zeroinitializer, ptr %t31
  %t32 = getelementptr { i64, [21 x i64] }, ptr %t31, i32 0, i32 0
  store i64 0, ptr %t32
  %t33 = load %"compiler/source:Span", ptr %l15
  %t34 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } undef, %"compiler/source:Span" %t33, 0
  %t35 = load %"compiler/mir:Lvalue", ptr %l17
  %t36 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t34, %"compiler/mir:Lvalue" %t35, 1
  %t38 = insertvalue { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t36, { i64, [15 x i64] } %t30, 2
  %t39 = getelementptr { i64, [21 x i64] }, ptr %t31, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/mir:Lvalue", { i64, [15 x i64] } } %t38, ptr %t39
  %t40 = load { i64, [21 x i64] }, ptr %t31
  %t42 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t40, ptr %t42
  %t43 = load ptr, ptr %l13, !tbaa !29
  %t44 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t43, i32 %t44, ptr %t42)
  br label %bb5
bb5:
  %t46 = load ptr, ptr %lp3
  %t47 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  %t48 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  %t49 = load i32, ptr @G_2ecompiler_2feval_2eS0, !tbaa !23
  store { i64, [21 x i64] } zeroinitializer, ptr %t50
  %t51 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 0
  store i64 4, ptr %t51
  %t53 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t48, 0
  %t55 = insertvalue { %"compiler/source:Span", i32 } %t53, i32 %t49, 1
  %t56 = getelementptr { i64, [21 x i64] }, ptr %t50, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t55, ptr %t56
  %t57 = load { i64, [21 x i64] }, ptr %t50
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 176, i64 8)
  store { i64, [21 x i64] } %t57, ptr %t59
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v1, ptr %s0, ptr %t46, i32 %t47, ptr %t59)
  br label %bb6
bb6:
  %t63 = load ptr, ptr %lp3
  store ptr %t63, ptr %l28, !tbaa !29
  %t64 = load i32, ptr @G_2ecompiler_2feval_2eB0, !tbaa !23
  store i32 %t64, ptr %l29, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr @G_2ecompiler_2feval_2eSp0
  store %"compiler/source:Span" %t65, ptr %l30
  %t66 = load i32, ptr %l4, !tbaa !23
  %t68 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t66)
  store %"compiler/mir:Lvalue" %t68, ptr %l32
  br label %bb7
bb7:
  store { i64, [4 x i64] } zeroinitializer, ptr %t69
  %t70 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 0
  store i64 1, ptr %t70
  %t71 = load %"compiler/mir:Lvalue", ptr %l32
  %t72 = insertvalue { %"compiler/mir:Lvalue" } undef, %"compiler/mir:Lvalue" %t71, 0
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  store { %"compiler/mir:Lvalue" } %t72, ptr %t73
  %t74 = load { i64, [4 x i64] }, ptr %t69
  store { i64, [8 x i64] } zeroinitializer, ptr %t75
  %t76 = getelementptr { i64, [8 x i64] }, ptr %t75, i32 0, i32 0
  store i64 5, ptr %t76
  %t77 = load %"compiler/source:Span", ptr %l30
  %t78 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } undef, %"compiler/source:Span" %t77, 0
  %t80 = insertvalue { %"compiler/source:Span", { i64, [4 x i64] } } %t78, { i64, [4 x i64] } %t74, 1
  %t81 = getelementptr { i64, [8 x i64] }, ptr %t75, i32 0, i32 1
  store { %"compiler/source:Span", { i64, [4 x i64] } } %t80, ptr %t81
  %t82 = load { i64, [8 x i64] }, ptr %t75
  %t83 = load ptr, ptr %l28, !tbaa !29
  %t84 = load i32, ptr %l29, !tbaa !23
  call void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v1, ptr %t83, i32 %t84, { i64, [8 x i64] } %t82)
  br label %bb8
bb8:
  %t86 = load ptr, ptr %lp3
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t86, i64 248, i1 false)
  call void @__olang_scope_close(ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l35, i64 248, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2esBlock_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2feval_2esBlock, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2eshr128(i64 %a0, i64 %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l15 = alloca i64
  %l24 = alloca i64
  %l31 = alloca i64
  %l36 = alloca i64
  %l42 = alloca i64
  %l49 = alloca i64
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = insertvalue { i64, i64 } undef, i64 %t5, 0
  %t10 = insertvalue { i64, i64 } %t8, i64 %t6, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 64
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t16 = load i1, ptr %l3, !tbaa !21
  br i1 %t16, label %bb6, label %bb7
bb5:
  br label %bb9
bb6:
  %t18 = load i64, ptr %l1, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = sub i64 %t19, 64
  store i64 %t21, ptr %l15, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = load i64, ptr %l15, !tbaa !24
  %t25 = ashr i64 %t18, %t24
  %t26 = load i64, ptr %l1, !tbaa !24
  %t28 = ashr i64 %t26, 63
  %t30 = insertvalue { i64, i64 } undef, i64 %t25, 0
  %t32 = insertvalue { i64, i64 } %t30, i64 %t28, 1
  store { i64, i64 } %t32, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t34 = load i64, ptr %l1, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t38 = sub i64 %t36, 64
  store i64 %t38, ptr %l24, !tbaa !65
  %t41 = load i64, ptr %l24, !tbaa !65
  %t42 = load i64, ptr %l24, !tbaa !65
  %t43 = lshr i64 %t34, %t42
  %t46 = insertvalue { i64, i64 } undef, i64 %t43, 0
  %t47 = insertvalue { i64, i64 } %t46, i64 0, 1
  store { i64, i64 } %t47, ptr %rv
  br label %ret
bb9:
  %t49 = load i64, ptr %l0, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  store i64 %t51, ptr %l31, !tbaa !65
  %t54 = load i64, ptr %l31, !tbaa !65
  %t55 = load i64, ptr %l31, !tbaa !65
  %t56 = lshr i64 %t49, %t55
  %t58 = load i64, ptr %l1, !tbaa !24
  %t59 = load i64, ptr %l2, !tbaa !24
  %t61 = sub i64 64, %t59
  store i64 %t61, ptr %l36, !tbaa !24
  %t63 = load i64, ptr %l36, !tbaa !24
  %t64 = load i64, ptr %l36, !tbaa !24
  %t65 = shl i64 %t58, %t64
  %t68 = or i64 %t56, %t65
  store i64 %t68, ptr %l4, !tbaa !24
  %t70 = load i1, ptr %l3, !tbaa !21
  br i1 %t70, label %bb10, label %bb11
bb10:
  %t72 = load i64, ptr %l4, !tbaa !24
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load i64, ptr %l2, !tbaa !24
  store i64 %t74, ptr %l42, !tbaa !24
  %t76 = load i64, ptr %l42, !tbaa !24
  %t77 = load i64, ptr %l42, !tbaa !24
  %t78 = ashr i64 %t73, %t77
  %t80 = insertvalue { i64, i64 } undef, i64 %t72, 0
  %t82 = insertvalue { i64, i64 } %t80, i64 %t78, 1
  store { i64, i64 } %t82, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load i64, ptr %l1, !tbaa !24
  %t87 = load i64, ptr %l2, !tbaa !24
  store i64 %t87, ptr %l49, !tbaa !65
  %t90 = load i64, ptr %l49, !tbaa !65
  %t91 = load i64, ptr %l49, !tbaa !65
  %t92 = lshr i64 %t85, %t91
  %t95 = insertvalue { i64, i64 } undef, i64 %t84, 0
  %t97 = insertvalue { i64, i64 } %t95, i64 %t92, 1
  store { i64, i64 } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local void @compiler_2feval_2eslotMask_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 16777215, ptr @G_2ecompiler_2feval_2eslotMask, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2etdefine(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v0, ptr %s0, ptr %t1, ptr %a0)
  store { i64, ptr } %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load i1, ptr %l8, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t12 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2feval_2ecompiler_2feval_3aMachine_2eDefine(ptr %v1, ptr %v0, ptr %a1, ptr %t12)
  br label %bb5
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = extractvalue { i64, ptr } %t15, 0
  %t19 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t17, 1
  call void @__olang_check_failed_text(ptr @olang_loc_48f03219a23009f5_27a95ef9d9612249, { i64, ptr } %t20)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2feval_2etermNamesGlobal(ptr %v0, ptr %a0, { i64, [8 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [8 x i64] }
  %l2 = alloca { i64, [4 x i64] }
  %l3 = alloca { i64, [4 x i64] }
  %l4 = alloca { i64, [4 x i64] }
  %l5 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i1
  %l16 = alloca i1
  %l24 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca %"compiler/mir:Call"
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [8 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [8 x i64] }, ptr %l1
  %t3 = extractvalue { i64, [8 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 2
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, [4 x i64] }, i32, i32 }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, [4 x i64] }, ptr %t7
  store { i64, [4 x i64] } %t8, ptr %l2
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load { i64, [4 x i64] }, ptr %l2
  %t12 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t10)
  store i1 %t12, ptr %l11
  br label %bb4
bb4:
  %t13 = load i1, ptr %l11, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb30
bb5:
  %t14 = load { i64, [8 x i64] }, ptr %l1
  %t16 = extractvalue { i64, [8 x i64] } %t14, 0
  %t17 = icmp eq i64 %t16, 3
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t20 = getelementptr { { i64, [4 x i64] }, %"compiler/mir:Range", i32 }, ptr %t19, i32 0, i32 0
  %t21 = load { i64, [4 x i64] }, ptr %t20
  store { i64, [4 x i64] } %t21, ptr %l3
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t23 = load { i64, [4 x i64] }, ptr %l3
  %t25 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t23)
  store i1 %t25, ptr %l16
  br label %bb9
bb9:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l6, !tbaa !21
  br label %bb30
bb10:
  %t27 = load { i64, [8 x i64] }, ptr %l1
  %t29 = extractvalue { i64, [8 x i64] } %t27, 0
  %t30 = icmp eq i64 %t29, 5
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] } }, ptr %t32, i32 0, i32 1
  %t34 = load { i64, [4 x i64] }, ptr %t33
  store { i64, [4 x i64] } %t34, ptr %l4
  br label %bb15
bb12:
  %t36 = load { i64, [8 x i64] }, ptr %l1
  %t38 = extractvalue { i64, [8 x i64] } %t36, 0
  %t39 = icmp eq i64 %t38, 11
  br i1 %t39, label %bb13, label %bb14
bb13:
  %t41 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", { i64, [4 x i64] }, i32, %"compiler/mir:Range" }, ptr %t41, i32 0, i32 1
  %t43 = load { i64, [4 x i64] }, ptr %t42
  store { i64, [4 x i64] } %t43, ptr %l4
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t45 = load { i64, [4 x i64] }, ptr %l4
  %t47 = call i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %t45)
  store i1 %t47, ptr %l24
  br label %bb16
bb16:
  %t48 = load i1, ptr %l24, !tbaa !21
  store i1 %t48, ptr %l6, !tbaa !21
  br label %bb30
bb17:
  %t49 = load { i64, [8 x i64] }, ptr %l1
  %t51 = extractvalue { i64, [8 x i64] } %t49, 0
  %t52 = icmp eq i64 %t51, 4
  br i1 %t52, label %bb18, label %bb19
bb18:
  %t54 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t55 = getelementptr { %"compiler/source:Span", i32 }, ptr %t54, i32 0, i32 1
  %t56 = load i32, ptr %t55
  store i32 %t56, ptr %l5, !tbaa !23
  br label %bb22
bb19:
  %t58 = load { i64, [8 x i64] }, ptr %l1
  %t60 = extractvalue { i64, [8 x i64] } %t58, 0
  %t61 = icmp eq i64 %t60, 6
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t63 = getelementptr { i64, [8 x i64] }, ptr %l1, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32 }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l5, !tbaa !23
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l31, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/mir:Fn", ptr %t68, i32 0, i32 14
  %t71 = load i32, ptr %l5, !tbaa !23
  %t73 = sext i32 %t71 to i64
  %t76 = call %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %t70, i64 %t73)
  store %"compiler/mir:Call" %t76, ptr %l36
  br label %bb23
bb23:
  %t77 = getelementptr %"compiler/mir:Call", ptr %l36, i32 0, i32 1
  %t78 = load %"compiler/mir:Range", ptr %t77
  %t79 = load ptr, ptr %l31, !tbaa !29
  %t81 = call i1 @compiler_2feval_2erangeNamesGlobal(ptr %v0, ptr %t79, %"compiler/mir:Range" %t78)
  store i1 %t81, ptr %l38
  br label %bb24
bb24:
  %t82 = load i1, ptr %l38, !tbaa !21
  store i1 %t82, ptr %l6, !tbaa !21
  br label %bb30
bb25:
  br i1 true, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_70d3567da39f3a7a_be006e6544252cae)
  unreachable
bb30:
  %t83 = load i1, ptr %l6, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2feval_2etkey(i64 %a0) #0 {
entry:
  %rv = alloca { i64, [2 x i64] }
  %t5 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a0 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t8 = insertvalue { i32 } undef, i32 %t3, 0
  %t9 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 1
  store { i32 } %t8, ptr %t9
  %t10 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t10, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local %"compiler/mir:Lvalue" @compiler_2feval_2etl(i64 %a0) #0 {
entry:
  %l4 = alloca %"compiler/mir:Lvalue"
  %rv = alloca %"compiler/mir:Lvalue"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 %a0 to i32
  %t6 = call %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %t3)
  store %"compiler/mir:Lvalue" %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load %"compiler/mir:Lvalue", ptr %l4
  store %"compiler/mir:Lvalue" %t7, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/mir:Lvalue", ptr %rv
  ret %"compiler/mir:Lvalue" %rr
}

define dso_local i1 @compiler_2feval_2etrueOverflows(i32 %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l18 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l46 = alloca i1
  %l54 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i1 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp slt i64 %t1, 8
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i32, ptr %l0
  %t7 = trunc i64 3 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb3, label %bb4
bb2:
  br label %bb18
bb3:
  %t10 = load i64, ptr %l1, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  %t14 = add i64 %t10, %t11
  store i64 %t14, ptr %l12, !tbaa !24
  br label %bb8
bb4:
  %t16 = load i32, ptr %l0
  %t18 = trunc i64 4 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l1, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t21, %t22
  store i64 %t25, ptr %l18, !tbaa !24
  br label %bb7
bb6:
  %t27 = load i64, ptr %l1, !tbaa !24
  %t28 = load i64, ptr %l2, !tbaa !24
  %t31 = mul i64 %t27, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  br label %bb7
bb7:
  %t33 = load i64, ptr %l18, !tbaa !24
  store i64 %t33, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  %t34 = load i64, ptr %l12, !tbaa !24
  store i64 %t34, ptr %l5, !tbaa !24
  %t35 = load i1, ptr %l4, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l3, !tbaa !24
  %t39 = mul i64 8, %t37
  %t41 = sub i64 %t39, 1
  store i64 %t41, ptr %l29, !tbaa !24
  %t42 = load i64, ptr %l29, !tbaa !24
  %t43 = load i64, ptr %l29, !tbaa !24
  %t44 = shl i64 1, %t43
  %t46 = sub i64 0, %t44
  store i64 %t46, ptr %l26, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l6, !tbaa !24
  %t49 = load i1, ptr %l4, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load i64, ptr %l3, !tbaa !24
  %t53 = mul i64 8, %t51
  %t55 = sub i64 %t53, 1
  store i64 %t55, ptr %l36, !tbaa !24
  %t56 = load i64, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = shl i64 1, %t57
  %t60 = sub i64 %t58, 1
  store i64 %t60, ptr %l33, !tbaa !24
  br label %bb14
bb13:
  %t62 = load i64, ptr %l3, !tbaa !24
  %t64 = mul i64 8, %t62
  store i64 %t64, ptr %l40, !tbaa !24
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l40, !tbaa !24
  %t67 = shl i64 1, %t66
  %t69 = sub i64 %t67, 1
  store i64 %t69, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l33, !tbaa !24
  store i64 %t71, ptr %l7, !tbaa !24
  %t72 = load i64, ptr %l5, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  %t76 = icmp slt i64 %t72, %t73
  br i1 %t76, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t78 = load i64, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = icmp sgt i64 %t78, %t79
  store i1 %t82, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t84 = load i1, ptr %l46, !tbaa !21
  store i1 %t84, ptr %rv
  br label %ret
bb18:
  %t85 = load i32, ptr %l0
  %t86 = load i64, ptr %l1, !tbaa !24
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = load i1, ptr %l4, !tbaa !21
  %t93 = call i1 @compiler_2feval_2eoverflows64(i32 %t85, i64 %t86, i64 %t87, i1 %t88)
  store i1 %t93, ptr %l54
  br label %bb19
bb19:
  %t94 = load i1, ptr %l54, !tbaa !21
  store i1 %t94, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2feval_2etspan(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = trunc i64 %t1 to i32
  %t4 = load i64, ptr %l0, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = trunc i64 %t6 to i32
  %t11 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t3, i32 %t8)
  store %"compiler/source:Span" %t11, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t12 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2feval_2eult64(i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t7 = icmp ult i64 %a0, %a1
  store i1 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2feval_2evEnum_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8, ptr @G_2ecompiler_2feval_2evEnum, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2feval_2evPair_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 6, ptr @G_2ecompiler_2feval_2evPair, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, i64 } @compiler_2feval_2ewideMin(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, i64 }
  %l7 = alloca i64
  %l11 = alloca { i64, i64 }
  %l16 = alloca { i64, i64 }
  %rv = alloca { i64, i64 }
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l0, !tbaa !24
  %t3 = icmp sle i64 %t1, 64
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l0, !tbaa !24
  %t7 = call i64 @compiler_2feval_2eminBits(i64 %t5)
  store i64 %t7, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t8 = load i64, ptr %l7, !tbaa !24
  %t9 = insertvalue { i64, i64 } undef, i64 %t8, 0
  %t10 = insertvalue { i64, i64 } %t9, i64 -1, 1
  store { i64, i64 } %t10, ptr %rv
  br label %ret
bb4:
  %t12 = load i64, ptr %l0, !tbaa !24
  %t14 = sub i64 %t12, 1
  %t16 = call { i64, i64 } @compiler_2feval_2eshl128(i64 1, i64 0, i64 %t14)
  store { i64, i64 } %t16, ptr %l11
  br label %bb5
bb5:
  %t17 = load { i64, i64 }, ptr %l11
  store { i64, i64 } %t17, ptr %l1
  %t18 = getelementptr { i64, i64 }, ptr %l1, i32 0, i32 0
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = getelementptr { i64, i64 }, ptr %l1, i32 0, i32 1
  %t22 = load i64, ptr %t21, !tbaa !24
  %t28 = call { i64, i64 } @compiler_2feval_2eneg128(i64 %t19, i64 %t22)
  store { i64, i64 } %t28, ptr %l16
  br label %bb6
bb6:
  %t29 = load { i64, i64 }, ptr %l16
  store { i64, i64 } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local %"compiler/eval:Image" @compiler_2feval_3aImage_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/eval:Image"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t5 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t6 = insertvalue %"compiler/eval:Image" undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, 0
  %t8 = insertvalue %"compiler/eval:Image" %t6, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, 1
  store %"compiler/eval:Image" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Image", ptr %rv
  ret %"compiler/eval:Image" %rr
}

define dso_local %"compiler/eval:Ptr" @compiler_2feval_3aPtr_2ector(ptr %v0, i64 %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/eval:Ptr"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/eval:Ptr" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/eval:Ptr" %t6, i64 %a1, 1
  store %"compiler/eval:Ptr" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:Ptr", ptr %rv
  ret %"compiler/eval:Ptr" %rr
}

define dso_local %"compiler/eval:alloc" @compiler_2feval_3aalloc_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/eval:alloc"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/eval:alloc" undef, i64 0, 0
  %t4 = insertvalue %"compiler/eval:alloc" %t2, i64 0, 1
  %t6 = insertvalue %"compiler/eval:alloc" %t4, i64 0, 2
  %t8 = insertvalue %"compiler/eval:alloc" %t6, i64 0, 3
  %t10 = insertvalue %"compiler/eval:alloc" %t8, i64 0, 4
  %t12 = insertvalue %"compiler/eval:alloc" %t10, i64 0, 5
  %t14 = insertvalue %"compiler/eval:alloc" %t12, i64 0, 6
  %t16 = insertvalue %"compiler/eval:alloc" %t14, i64 0, 7
  %t18 = insertvalue %"compiler/eval:alloc" %t16, i64 -1, 8
  %t20 = insertvalue %"compiler/eval:alloc" %t18, i64 -1, 9
  %t22 = insertvalue %"compiler/eval:alloc" %t20, i1 false, 10
  %t24 = insertvalue %"compiler/eval:alloc" %t22, i64 -1, 11
  %t26 = insertvalue %"compiler/eval:alloc" %t24, i1 false, 12
  store %"compiler/eval:alloc" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:alloc", ptr %rv
  ret %"compiler/eval:alloc" %rr
}

define dso_local %"compiler/eval:dkey" @compiler_2feval_3adkey_2ector(ptr %v0, i64 %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %rv = alloca %"compiler/eval:dkey"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/eval:dkey" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/eval:dkey" %t14, i32 %a1, 1
  %t18 = insertvalue %"compiler/eval:dkey" %t16, i32 %a2, 2
  %t20 = insertvalue %"compiler/eval:dkey" %t18, i32 %a3, 3
  %t22 = insertvalue %"compiler/eval:dkey" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/eval:dkey" %t22, i64 %a5, 5
  store %"compiler/eval:dkey" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:dkey", ptr %rv
  ret %"compiler/eval:dkey" %rr
}

define dso_local void @compiler_2feval_3agenRec_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l7 = alloca %"compiler/eval:frame"
  %l8 = alloca %"compiler/eval:genRec"
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l0, !tbaa !24
  store i64 0, ptr %l1, !tbaa !24
  %t1 = call %"compiler/eval:frame" @compiler_2feval_3aframe_2ector(ptr %v0)
  store %"compiler/eval:frame" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"compiler/eval:frame", ptr %l7
  %t3 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 0
  %t4 = load i64, ptr %l0, !tbaa !24
  store i64 %t4, ptr %t3, !tbaa !24
  %t5 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 1
  %t6 = load i64, ptr %l1, !tbaa !24
  store i64 %t6, ptr %t5, !tbaa !24
  %t7 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 2
  store %"compiler/eval:frame" %t2, ptr %t7
  %t9 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 3
  store i64 -1, ptr %t9, !tbaa !24
  %t11 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 4
  store i64 0, ptr %t11, !tbaa !24
  %t13 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 5
  store i64 0, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/eval:genRec", ptr %l8, i32 0, i32 6
  store i64 -1, ptr %t15, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l8, i64 176, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/eval:gkey" @compiler_2feval_3agkey_2ector(ptr %v0, i64 %a0, i32 %a1) #0 {
entry:
  %rv = alloca %"compiler/eval:gkey"
  br label %start
start:
  br label %bb0
bb0:
  %t6 = insertvalue %"compiler/eval:gkey" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/eval:gkey" %t6, i32 %a1, 1
  store %"compiler/eval:gkey" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:gkey", ptr %rv
  ret %"compiler/eval:gkey" %rr
}

define dso_local %"compiler/eval:reg" @compiler_2feval_3areg_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/eval:reg"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/eval:reg" undef, i64 0, 0
  %t4 = insertvalue %"compiler/eval:reg" %t2, i64 0, 1
  %t6 = insertvalue %"compiler/eval:reg" %t4, i64 0, 2
  %t8 = insertvalue %"compiler/eval:reg" %t6, i64 0, 3
  %t10 = insertvalue %"compiler/eval:reg" %t8, i64 -1, 4
  %t12 = insertvalue %"compiler/eval:reg" %t10, i64 -1, 5
  %t14 = insertvalue %"compiler/eval:reg" %t12, i64 0, 6
  %t16 = insertvalue %"compiler/eval:reg" %t14, i64 -1, 7
  store %"compiler/eval:reg" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:reg", ptr %rv
  ret %"compiler/eval:reg" %rr
}

define dso_local %"compiler/eval:task" @compiler_2feval_3atask_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/eval:task"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/eval:task" undef, i64 0, 0
  %t4 = insertvalue %"compiler/eval:task" %t2, i64 0, 1
  %t6 = insertvalue %"compiler/eval:task" %t4, i64 0, 2
  %t8 = insertvalue %"compiler/eval:task" %t6, i64 -1, 3
  store %"compiler/eval:task" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:task", ptr %rv
  ret %"compiler/eval:task" %rr
}

define dso_local void @olang_2einit_2ecompiler_2feval() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2feval_2eWhyMutableGlobal_2einit()
  br label %bb1
bb1:
  call void @compiler_2feval_2eWhyChangeable_2einit()
  br label %bb2
bb2:
  call void @compiler_2feval_2eWhyWritesGlobal_2einit()
  br label %bb3
bb3:
  call void @compiler_2feval_2eWhyWritesGlobalVar_2einit()
  br label %bb4
bb4:
  call void @compiler_2feval_2eWhyCycle_2einit()
  br label %bb5
bb5:
  call void @compiler_2feval_2eWhyNoValue_2einit()
  br label %bb6
bb6:
  call void @compiler_2feval_2eWhyNoGlobal_2einit()
  br label %bb7
bb7:
  call void @compiler_2feval_2eWhyDestructor_2einit()
  br label %bb8
bb8:
  call void @compiler_2feval_2eWhyExtern_2einit()
  br label %bb9
bb9:
  call void @compiler_2feval_2eWhyEnds_2einit()
  br label %bb10
bb10:
  call void @compiler_2feval_2eWhySteps_2einit()
  br label %bb11
bb11:
  call void @compiler_2feval_2eWhyMemory_2einit()
  br label %bb12
bb12:
  call void @compiler_2feval_2eWhyDepth_2einit()
  br label %bb13
bb13:
  call void @compiler_2feval_2eWhyRunDepth_2einit()
  br label %bb14
bb14:
  call void @compiler_2feval_2eWhyEqDepth_2einit()
  br label %bb15
bb15:
  call void @compiler_2feval_2eWhyRunEqDepth_2einit()
  br label %bb16
bb16:
  call void @compiler_2feval_2eWhyNull_2einit()
  br label %bb17
bb17:
  call void @compiler_2feval_2eWhyNullCall_2einit()
  br label %bb18
bb18:
  call void @compiler_2feval_2eWhyClosed_2einit()
  br label %bb19
bb19:
  call void @compiler_2feval_2eWhyFreedEarly_2einit()
  br label %bb20
bb20:
  call void @compiler_2feval_2eWhyStale_2einit()
  br label %bb21
bb21:
  call void @compiler_2feval_2eWhyOutside_2einit()
  br label %bb22
bb22:
  call void @compiler_2feval_2eWhyBeyond_2einit()
  br label %bb23
bb23:
  call void @compiler_2feval_2eWhyReadOnly_2einit()
  br label %bb24
bb24:
  call void @compiler_2feval_2eWhyDivZero_2einit()
  br label %bb25
bb25:
  call void @compiler_2feval_2eWhyDivMin_2einit()
  br label %bb26
bb26:
  call void @compiler_2feval_2eWhyShift_2einit()
  br label %bb27
bb27:
  call void @compiler_2feval_2eWhyConvert_2einit()
  br label %bb28
bb28:
  call void @compiler_2feval_2eWhyNaNOp_2einit()
  br label %bb29
bb29:
  call void @compiler_2feval_2eWhyNaNSignal_2einit()
  br label %bb30
bb30:
  call void @compiler_2feval_2eWhyNoBody_2einit()
  br label %bb31
bb31:
  call void @compiler_2feval_2eWhyNotModelled_2einit()
  br label %bb32
bb32:
  call void @compiler_2feval_2eWhyPayload_2einit()
  br label %bb33
bb33:
  call void @compiler_2feval_2eWhyLong_2einit()
  br label %bb34
bb34:
  call void @compiler_2feval_2eWhyFfiFind_2einit()
  br label %bb35
bb35:
  call void @compiler_2feval_2eWhyFfiPass_2einit()
  br label %bb36
bb36:
  call void @compiler_2feval_2eWhyForeign_2einit()
  br label %bb37
bb37:
  call void @compiler_2feval_2eWhyNoClause_2einit()
  br label %bb38
bb38:
  call void @compiler_2feval_2eWhyWaits_2einit()
  br label %bb39
bb39:
  call void @compiler_2feval_2eNullPtr_2einit()
  br label %bb40
bb40:
  call void @compiler_2feval_2eslotBits_2einit()
  br label %bb41
bb41:
  call void @compiler_2feval_2eslotMask_2einit()
  br label %bb42
bb42:
  call void @compiler_2feval_2eaFree_2einit()
  br label %bb43
bb43:
  call void @compiler_2feval_2eaValue_2einit()
  br label %bb44
bb44:
  call void @compiler_2feval_2eaData_2einit()
  br label %bb45
bb45:
  call void @compiler_2feval_2eaGlobal_2einit()
  br label %bb46
bb46:
  call void @compiler_2feval_2eaCode_2einit()
  br label %bb47
bb47:
  call void @compiler_2feval_2esBlock_2einit()
  br label %bb48
bb48:
  call void @compiler_2feval_2esStore_2einit()
  br label %bb49
bb49:
  call void @compiler_2feval_2esProgram_2einit()
  br label %bb50
bb50:
  call void @compiler_2feval_2esInert_2einit()
  br label %bb51
bb51:
  call void @compiler_2feval_2esBuilder_2einit()
  br label %bb52
bb52:
  call void @compiler_2feval_2esRegion_2einit()
  br label %bb53
bb53:
  call void @compiler_2feval_2esJoin_2einit()
  br label %bb54
bb54:
  call void @compiler_2feval_2egDtor_2einit()
  br label %bb55
bb55:
  call void @compiler_2feval_2egOwner_2einit()
  br label %bb56
bb56:
  call void @compiler_2feval_2egGen_2einit()
  br label %bb57
bb57:
  call void @compiler_2feval_2erRequest_2einit()
  br label %bb58
bb58:
  call void @compiler_2feval_2erCall_2einit()
  br label %bb59
bb59:
  call void @compiler_2feval_2erDtor_2einit()
  br label %bb60
bb60:
  call void @compiler_2feval_2erTask_2einit()
  br label %bb61
bb61:
  call void @compiler_2feval_2erClause_2einit()
  br label %bb62
bb62:
  call void @compiler_2feval_2erGlobal_2einit()
  br label %bb63
bb63:
  call void @compiler_2feval_2etRaised_2einit()
  br label %bb64
bb64:
  call void @compiler_2feval_2etCall_2einit()
  br label %bb65
bb65:
  call void @compiler_2feval_2etJoin_2einit()
  br label %bb66
bb66:
  call void @compiler_2feval_2etraceKept_2einit()
  br label %bb67
bb67:
  call void @compiler_2feval_2evVoid_2einit()
  br label %bb68
bb68:
  call void @compiler_2feval_2evBool_2einit()
  br label %bb69
bb69:
  call void @compiler_2feval_2evInt_2einit()
  br label %bb70
bb70:
  call void @compiler_2feval_2evUint_2einit()
  br label %bb71
bb71:
  call void @compiler_2feval_2evFloat_2einit()
  br label %bb72
bb72:
  call void @compiler_2feval_2evPtr_2einit()
  br label %bb73
bb73:
  call void @compiler_2feval_2evPair_2einit()
  br label %bb74
bb74:
  call void @compiler_2feval_2evFunc_2einit()
  br label %bb75
bb75:
  call void @compiler_2feval_2evEnum_2einit()
  br label %bb76
bb76:
  call void @compiler_2feval_2evOrd_2einit()
  br label %bb77
bb77:
  call void @compiler_2feval_2evAgg_2einit()
  br label %bb78
bb78:
  call void @compiler_2feval_2evFixed_2einit()
  br label %bb79
bb79:
  call void @compiler_2feval_2evNone_2einit()
  br label %bb80
bb80:
  call void @compiler_2feval_2evWide_2einit()
  br label %bb81
bb81:
  call void @compiler_2feval_2efCopy_2einit()
  br label %bb82
bb82:
  call void @compiler_2feval_2efConst_2einit()
  br label %bb83
bb83:
  call void @compiler_2feval_2efBin_2einit()
  br label %bb84
bb84:
  call void @compiler_2feval_2efUn_2einit()
  br label %bb85
bb85:
  call void @compiler_2feval_2efLoad_2einit()
  br label %bb86
bb86:
  call void @compiler_2feval_2efStore_2einit()
  br label %bb87
bb87:
  call void @compiler_2feval_2efastStride_2einit()
  br label %bb88
bb88:
  call void @compiler_2feval_2eForeignId_2einit()
  br label %bb89
bb89:
  call void @compiler_2feval_2eInterpCrash_2einit()
  br label %bb90
bb90:
  call void @compiler_2feval_2eSp0_2einit()
  br label %bb91
bb91:
  call void @compiler_2feval_2eB0_2einit()
  br label %bb92
bb92:
  call void @compiler_2feval_2eS0_2einit()
  br label %bb93
bb93:
  call void @compiler_2feval_2eIntOps_2einit()
  br label %bb94
bb94:
  call void @compiler_2feval_2eCmpOps_2einit()
  br label %bb95
bb95:
  call void @compiler_2feval_2eFloatOps_2einit()
  br label %bb96
bb96:
  call void @compiler_2feval_2eNumNames_2einit()
  br label %bb97
bb97:
  br label %ret
ret:
  ret void
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d0 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"olang: internal compiler error: the compiler crashed while interpreting - in a foreign function the " }>, align 8
@.d1 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"program calls, if its extern declaration is wrong (X1a), or else a bug in the compiler\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [12 x { i64, ptr }] }> <{ i64 0, [12 x { i64, ptr }] [{ i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d56, i32 0, i32 1) }, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d58, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d59, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d60, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d61, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d63, i32 0, i32 1) }, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d64, i32 0, i32 1) }] }>, align 8
@.d3 = private constant <{ i64, [100 x i8] }> <{ i64 0, [100 x i8] c"it reads a global holding storage a writable reference reaches, which the running program can change" }>, align 8
@.d4 = private constant <{ i64, [53 x i8] }> <{ i64 0, [53 x i8] c"it uses storage after the scope it was made in closed" }>, align 8
@.d5 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"it converts a float the target type cannot represent" }>, align 8
@.d6 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c"the computation recurses deeper than compile-time evaluation allows" }>, align 8
@.d7 = private constant <{ i64, [61 x i8] }> <{ i64 0, [61 x i8] c"it builds a value whose destructor runs when its scope closes" }>, align 8
@.d8 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"it divides by zero" }>, align 8
@.d9 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c"it ends the test or the process" }>, align 8
@.d10 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"it calls an external function -i cannot find in this process" }>, align 8
@.d11 = private constant <{ i64, [152 x i8] }> <{ i64 0, [152 x i8] c"it calls an external function with a parameter or result interpret cannot pass - only numbers, Bools, arrays and structs of numbers, and pointers C gave" }>, align 8
@.d12 = private constant <{ i64, [56 x i8] }> <{ i64 0, [56 x i8] c"it reads through a pointer C gave, which only C may read" }>, align 8
@.d13 = private constant <{ i64, [69 x i8] }> <{ i64 0, [69 x i8] c"the computation takes more memory than compile-time evaluation allows" }>, align 8
@.d14 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"it reads a mutable global, whose value is the running program's" }>, align 8
@.d15 = private constant <{ i64, [71 x i8] }> <{ i64 0, [71 x i8] c"it reads the bits of a signalling NaN, which moving it may have quieted" }>, align 8
@.d16 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"it calls a function whose body is not available" }>, align 8
@.d17 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c"a task's error has no clause to take it" }>, align 8
@.d18 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"its initializer does not produce a value" }>, align 8
@.d19 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"it reads through a null reference" }>, align 8
@.d20 = private constant <{ i64, [54 x i8] }> <{ i64 0, [54 x i8] c"it reads the payload of a case the value does not hold" }>, align 8
@.d21 = private constant <{ i64, [33 x i8] }> <{ i64 0, [33 x i8] c"it recurses deeper than -i allows" }>, align 8
@.d22 = private constant <{ i64, [63 x i8] }> <{ i64 0, [63 x i8] c"the computation runs longer than compile-time evaluation allows" }>, align 8
@.d23 = private constant <{ i64, [72 x i8] }> <{ i64 0, [72 x i8] c"it writes a global, which the running program would then not see written" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
define linkonce_odr void @olang_2eHelperKind_2eZero_2ecompiler_2feval_3acfn(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"compiler/eval:cfn"
  %t1 = alloca %"compiler/eval:cfn", align 8
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2feval_3acfn_2ector(ptr %t1, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l0, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l0, i64 264, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_ert_req_clear()
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"__olang_" }>, align 8
declare i32 @__olang_err()
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_float(ptr, i64, double, i32)
declare void @__olang_sb_add(ptr, i64)
declare void @__olang_sb_done(ptr)
@.d27 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"olang: internal compiler error: file " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" at " }>, align 8
@.d29 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare double @llvm.arithmetic.fence.f64(double)
declare bfloat @__olang_int_bf16(i64, i1)
define linkonce_odr %"compiler/eval:alloc" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aalloc() #0 {
entry:
  %l0 = alloca %"compiler/eval:alloc"
  %rv = alloca %"compiler/eval:alloc"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/eval:alloc" @compiler_2feval_3aalloc_2ector(ptr %t1)
  store %"compiler/eval:alloc" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/eval:alloc", ptr %l0
  store %"compiler/eval:alloc" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:alloc", ptr %rv
  ret %"compiler/eval:alloc" %rr
}

define linkonce_odr %"compiler/eval:frame" @olang_2eHelperKind_2eZero_2ecompiler_2feval_3aframe() #0 {
entry:
  %l0 = alloca %"compiler/eval:frame"
  %rv = alloca %"compiler/eval:frame"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"compiler/eval:frame" @compiler_2feval_3aframe_2ector(ptr %t1)
  store %"compiler/eval:frame" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"compiler/eval:frame", ptr %l0
  store %"compiler/eval:frame" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/eval:frame", ptr %rv
  ret %"compiler/eval:frame" %rr
}

define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal { i64, [4 x i64] } @olang_lambda_31(ptr %env, i64 %a0) #0 {
entry:
  %l1 = alloca %"compiler/mir:Fn"
  %l2 = alloca %"compiler/mir:Range"
  %l8 = alloca { i64, [4 x i64] }
  %rv = alloca { i64, [4 x i64] }
  %cp0 = getelementptr { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, ptr %env, i32 0, i32 0
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %cp0, i64 248, i1 false)
  %cp1 = getelementptr { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, ptr %env, i32 0, i32 1
  %cv1 = load %"compiler/mir:Range", ptr %cp1, !tbaa !28
  store %"compiler/mir:Range" %cv1, ptr %l2
  %vq0 = getelementptr { %"compiler/mir:Fn", %"compiler/mir:Range", ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/mir:Fn", ptr %l1, i32 0, i32 11
  %t2 = getelementptr %"compiler/mir:Range", ptr %l2, i32 0, i32 0
  %t3 = load i32, ptr %t2, !tbaa !23
  %t5 = sext i32 %t3 to i64
  %t9 = add i64 %t5, %a0
  %t12 = call { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %vc0, ptr %t1, i64 %t9)
  store { i64, [4 x i64] } %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load { i64, [4 x i64] }, ptr %l8
  store { i64, [4 x i64] } %t13, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [4 x i64] }, ptr %rv
  ret { i64, [4 x i64] } %rr
}

@.d32 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_arg_count" }>, align 8
@.d33 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_arg" }>, align 8
@.d34 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_env" }>, align 8
declare i64 @__olang_env(ptr, ptr, i64)
@.d35 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_err" }>, align 8
@.d36 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_stat" }>, align 8
declare i32 @__olang_stat(ptr, ptr)
@.d37 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_dir" }>, align 8
@.d38 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_realpath" }>, align 8
@.d39 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_dir" }>, align 8
declare i64 @__olang_dir(ptr, ptr, i64)
declare i64 @__olang_realpath(ptr, ptr, i64)
@.d40 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"__olang_spawn" }>, align 8
declare i32 @__olang_spawn(ptr, i64, i32, i32, i32, ptr)
@.d41 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"__olang_exec" }>, align 8
declare i32 @__olang_exec(ptr, ptr, i64)
@.d42 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_mkdtemp" }>, align 8
declare i32 @__olang_mkdtemp(ptr)
@.d43 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"__olang_dyncall" }>, align 8
declare i64 @__olang_dyncall(ptr, ptr, ptr, i8 zeroext)
@.d44 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"__olang_dyncall_check" }>, align 8
declare i32 @__olang_dyncall_check(ptr, ptr, i8 zeroext)
@.d45 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"__olang_on_crash" }>, align 8
@.d46 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_err" }>, align 8
@.d47 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"__olang_arg_count" }>, align 8
@.d48 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"__olang_arg" }>, align 8
@.d49 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d50 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d52 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_check_failed_text(ptr, { i64, ptr }) cold noreturn
@.d53 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"I8" }>, align 8
@.d54 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I16" }>, align 8
@.d55 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d56 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I64" }>, align 8
@.d57 = private unnamed_addr constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"U8" }>, align 8
@.d58 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U16" }>, align 8
@.d59 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U32" }>, align 8
@.d60 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"U64" }>, align 8
@.d61 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F16" }>, align 8
@.d62 = private unnamed_addr constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"BF16" }>, align 8
@.d63 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F32" }>, align 8
@.d64 = private unnamed_addr constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"F64" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
@G_2ecompiler_2feval_2eFloatOps = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eInterpCrash = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eNumNames = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyChangeable = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyClosed = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyConvert = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyDestructor = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyDivZero = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyEnds = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyFfiFind = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyFfiPass = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyForeign = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyMemory = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyMutableGlobal = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNaNSignal = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNoBody = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNoClause = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNoValue = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyNull = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyPayload = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyRunDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhySteps = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyWritesGlobalVar = external constant <{ [8 x i8], ptr }>
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eLen_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eP_H79a97b7337c7adf08bdd37311af7e171(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2ePush_3ccompiler_2fmir_3aFn_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_8e30d4bcef98d937_821e6ec72834ca4b = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edecode(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20Bool_3e_2e_Hf0a5beca6f8aee4731a76bd327ae0a99(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
@olang_loc_8d25544d0bd70291_3d464b777e1774ad = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2elay(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/eval:global" @compiler_2feval_3aglobal_2ector(ptr %v0)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2esize(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2eaGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocate(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eLen_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eP_Hdbb1ec214f67f51e9ea8789b3bf075dc(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1, i64 %a2)
@G_2ecompiler_2feval_2eslotMask = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2ePush_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, %"compiler/eval:global" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eaFree = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erelease(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eNullPtr = available_externally constant <{ [16 x i8] }> <{ [16 x i8] c"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fmir_3aFnKey_2c_20I64_3e_2eG_H6ffe2eb17daa971b2c9d564ad72358b1(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2erefuse(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFn_3e_2eAt_3ccompiler_2fmir_3aFn_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2erRequest = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eLen_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocalId_3e_2eAt_3ccompiler_2fmir_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aLocal_3e_2eAt_3ccompiler_2fmir_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewidth(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i64 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eLen_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erd(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_6f754b89a33b6044_bbcfb7dbcaa58778 = external constant [0 x i8]
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2eopType(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2escratchFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eput(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3, { i64, [4 x i64] } %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eAt_3ccompiler_2feval_3ascope_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eSetAt_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ezero(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eshape(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [4 x i64] } @compiler_2feval_2ecompiler_2feval_3aMachine_2earg(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Range" %a2, i64 %a3)
@G_2ecompiler_2feval_2evFixed = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evEnum = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartOffset(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2epartType(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2feval_2evOrd = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eaValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efixedLen(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_561376b2ca02a7ba_25f299f9320c8ad6 = external constant [0 x i8]
@olang_loc_9c6d2d38b14ece16_85850a0ccdf8ec6a = external constant [0 x i8]
@olang_loc_3e93cd40ddf47e2b_3ba0afa8b25b773f = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_He9bc6cfad7ef603960b4717f3121b8e8(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2eMathExtern(ptr %v0, { i64, ptr } %a0, i64 %a1)
@G_2ecompiler_2feval_2eWhyExtern = external constant <{ [8 x i8], ptr }>
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewaitsForTask(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2eforeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiScalar(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_8455ed81fb66a668_e2c955a612231684 = external constant [0 x i8]
@olang_loc_e6f2fd943c115655_f5638f66c9629791 = external constant [0 x i8]
@olang_loc_24365dba12301136_85ae2e45ea64b572 = external constant [0 x i8]
@olang_loc_e79146937ca231cb_dd9a37031fe8e967 = external constant [0 x i8]
declare { i64, [4 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aOperand_3e_2eAt_3ccompiler_2fmir_3aOperand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2effiKind(ptr %v0, ptr %a0, i32 %a1)
declare i8 @std_2fffi_2eCode(i32 %a0)
@G_2ecompiler_2feval_2evInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evPair = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumbersOnly(ptr %v0, ptr %a0, i32 %a1)
declare i8 @std_2fffi_2eArrayOf(i32 %a0)
declare i64 @std_2fffi_2eWordsFor(i64 %a0)
@G_2ecompiler_2feval_2evPtr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2erdPtrOrBits(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1)
@G_2ecompiler_2feval_2eForeignId = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\00\00\00\00\00" }>, align 8
@olang_loc_84b043302e365534_8c4896c766887f8 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ekindWidth(ptr %v0, ptr %a0, i8 %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fffi_2eCall(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i8 %a3, i64 %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrPtr(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2)
@G_2ecompiler_2feval_2eWhyNullCall = external constant <{ [8 x i8], ptr }>
declare %"compiler/eval:alloc" @compiler_2feval_2ecompiler_2feval_3aMachine_2eallocOf(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eaCode = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eWhyNotModelled = external constant <{ [8 x i8], ptr }>
declare { i64, [2 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eAt_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eAnySlotBase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_bde43f50f3dd47_4bb44709ac02dbdb = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2eLen_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aFnKey_3e_2ePush_3ccompiler_2fmir_3aFnKey_3e(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eat(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i64 %a2, i1 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2emove(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropScope(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eTruncate_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eWhyOutside = external constant <{ [8 x i8], ptr }>
declare %"compiler/eval:task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eAt_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/mir:Task" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aTask_3e_2eAt_3ccompiler_2fmir_3aTask_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecalleeType(ptr %v0, ptr %a0, i64 %a1, { i64, [7 x i64] } %a2)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2egenIndex(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/eval:Ptr" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eAt_3ccompiler_2feval_3agenRec_3e(ptr %out, ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estop(ptr %v0, ptr %v1, ptr %a0, { i64, [5 x i64] } %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2egenOver(ptr %v0, ptr %a0, i64 %a1, i64 %a2, { i64, [7 x i64] } %a3, i64 %a4, i64 %a5)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2erestoreGen(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_11a19fcb84a16e6d_1ab7f06eb0f74619 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eownParams(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aVarKind_3e_2eAt_3ccompiler_2fmir_3aVarKind_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_e8d82fb02ccf62bc_44b724ba703ff148 = external constant [0 x i8]
@olang_loc_36e0ec838c111677_372a612bd7b0a623 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aScopeRef_3e_2eAt_3ccompiler_2fmir_3aScopeRef_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2escopeOf(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
@G_2ecompiler_2ftypes_2eResultVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eClosingVar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_5609b5c4ef82b256_83c053ae3d548522 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3agenRec_3e_2eSetAt_3ccompiler_2feval_3agenRec_3e(ptr %v0, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_94877e621914b8e2_5997ae45c40d186e = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumber(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ecanonBits(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2feval_2eplainLocal(%"compiler/mir:Lvalue" %a0)
@olang_loc_e07540d555d7dc03_f134256d7232b767 = external constant [0 x i8]
@olang_loc_9ff5c0c5c0f3031a_9845a0a415f7f056 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enotModelled(ptr %v0, ptr %a0)
@olang_loc_dc78e3ab17f01d1b_791cd762b2865477 = external constant [0 x i8]
@olang_loc_1a5820d8caa3da70_8ddb412d29c69c24 = external constant [0 x i8]
@G_2ecompiler_2feval_2eWhyFreedEarly = external constant <{ [8 x i8], ptr }>
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_c25616630356082_96e485ee4d1c8d36 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feval_3agkey_2c_20I64_3e_2eG_H841bd46d30f67641fdfac3080f15aea1(ptr %v0, ptr %a0, %"compiler/eval:gkey" %a1)
@olang_loc_cdcdbab6c5a00ca5_1566754bdc1f9529 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2erangeReady(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/mir:Range" %a3)
@olang_loc_d7d71e32b1402da8_19cce939fe39e26c = external constant [0 x i8]
@olang_loc_20cdf2bac11b5657_20b8fcdfbd19fb1b = external constant [0 x i8]
@olang_loc_3dd741f2ac40c2b6_e435d9fa661ce11a = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eibits(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ebmask(i64 %a0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edeliver(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereturned(ptr %v0, ptr %a0, %"compiler/eval:frame" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3ascope_3e_2eLen_3ccompiler_2feval_3ascope_3e(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eslotBits = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\18\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2estepClose(ptr %v0, ptr %a0)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eterm(ptr %v0, ptr %a0, i64 %a1, { i64, [8 x i64] } %a2, i1 %a3)
@G_2ecompiler_2feval_2efastStride = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eflat(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enewScopeSlot(ptr %v0, ptr %a0)
@olang_loc_1aa148087c58143e_12c49f79ebc6dae2 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2ePush_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0, %"compiler/eval:task" %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3atask_3e_2eLen_3ccompiler_2feval_3atask_3e(ptr %v0, ptr %a0)
@olang_loc_ad3bfe70499dbe21_2daaaf2a9e405db5 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evFloat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare double @compiler_2feval_2ecompiler_2feval_3aMachine_2etoF64(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2feval_2efloatFits(double %a0, i64 %a1, i1 %a2)
declare { i64, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2ewideOf(ptr %v0, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2)
@G_2ecompiler_2feval_2evUint = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2feval_2efits128(i64 %a0, i64 %a1, i1 %a2, i64 %a3, i1 %a4)
declare { i64, i64, i64, i64 } @compiler_2feval_2eudivmod128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare { i64, i64 } @compiler_2feval_2ewideMax(i64 %a0, i1 %a1)
declare { i64, i64 } @compiler_2feval_2eadd128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
declare i64 @compiler_2feval_2ecmp128(i64 %a0, i64 %a1, i64 %a2, i64 %a3, i1 %a4)
declare { i64, i64 } @compiler_2feval_2esub128(i64 %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_4df6f2ee185eb0d1_4c6469cdbf591dfd = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShapeCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/eval:global" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2eWhyNoGlobal = external constant <{ [8 x i8], ptr }>
@olang_loc_de6102181a77a536_5fca55a0d6277082 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ertArray(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_c157b2e02f5238d7_241c429033d52203 = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ewritesAfter(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2ereachesWritable(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2eWhyCycle = external constant <{ [8 x i8], ptr }>
@olang_loc_a7714af53687ff6b_1e8ca3031727412f = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropOwnDefers(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2econvert(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebitcast(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/eval:Ptr" @compiler_2feval_2ecompiler_2feval_3aMachine_2etypeid(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eretire(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:Ptr" %a2, i32 %a3)
declare i64 @compiler_2feval_2ebitOp(i32 %a0, i64 %a1, i64 %a2, i64 %a3)
@olang_loc_c5a1577ee3e22d75_549c323efc9636a1 = external constant [0 x i8]
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2eunary(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i64 %a4)
@G_2ecompiler_2feval_2evBool = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enumOp(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i64 %a3, i32 %a4, i32 %a5, i64 %a6)
declare %"compiler/mir:BasicBlock" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aBasicBlock_3e_2eAt_3ccompiler_2fmir_3aBasicBlock_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_f2c339cbb479452c_c316cd9120a44978 = external constant [0 x i8]
@G_2ecompiler_2feval_2eWhyEqDepth = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2feval_2eWhyRunEqDepth = external constant <{ [8 x i8], ptr }>
declare %"compiler/eval:frame" @compiler_2feval_3aframe_2ector(ptr %v0)
@G_2ecompiler_2feval_2esStore = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_d67750d3ea89b5a6_4cf132db9678b04a = external constant [0 x i8]
@olang_loc_84b7ba4c2a706fc5_7fbf5d3432269f09 = external constant [0 x i8]
declare { i64, [1 x i64] } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aConstNode_3e_2eAt_3ccompiler_2fmir_3aConstNode_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_12565802a2336670_a75db38aedd0e3fc = external constant [0 x i8]
declare { %"compiler/eval:Ptr", i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2edataFor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i32 %a3, i64 %a4, %"compiler/source:Span" %a5)
@olang_loc_1069159e4cdf0a01_3c7ea434b50ec3ad = external constant [0 x i8]
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2emutableGlobal(ptr %v0, ptr %a0, %"compiler/mir:Lvalue" %a1)
@olang_loc_4b87b113311cbcf6_8401054b0e12d93a = external constant [0 x i8]
@olang_loc_26a77dbb944b4c43_3cbd97c51474f5af = external constant [0 x i8]
declare { i32, { i64, [2 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20compile_Ha5986096190b27059e1b255ecbd90571(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2erDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
@olang_loc_7289625dc306da68_1bb592dfdbe27504 = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eputBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [4 x i64] } %a2, { i64, ptr } %a3, i64 %a4)
@olang_loc_d526727003b18a55_2e4fcca09321f611 = external constant [0 x i8]
@olang_loc_1269d295d9d04536_be9a6b7fb42413f2 = external constant [0 x i8]
@olang_loc_d5c4bb6f444265cb_1686743ce9a847e7 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fos_2eOnCrash(ptr %v0, { i64, ptr } %a0)
@olang_loc_de11af42111bcb9b_94efc9af890b5bc7 = external constant [0 x i8]
@olang_loc_1c104311c72af5f5_c45dcd645c687dc1 = external constant [0 x i8]
@olang_loc_eac386e3c6428a04_b108c34b7dde3e30 = external constant [0 x i8]
@G_2ecompiler_2feval_2evVoid = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evWide = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evFunc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2evAgg = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2enamedShape(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2feval_2evNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
@olang_loc_5b67d157b70117f_cddce93e80c09b93 = external constant [0 x i8]
@G_2ecompiler_2feval_2erGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aglobal_3e_2eSetAt_3ccompiler_2feval_3aglobal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:global" %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eatK(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eassign(ptr %v0, ptr %a0, i64 %a1, %"compiler/mir:Lvalue" %a2, { i64, [15 x i64] } %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2ebuildScope(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2)
@G_2ecompiler_2feval_2esInert = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esBuilder = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esRegion = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esJoin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2esBlock = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@olang_loc_fe5b662c8cf4b58_7006b7c636f2421c = external constant [0 x i8]
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2edropDefers(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2etraced(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fmir_2eNoBlock = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2feval_2ecompiler_2feval_3aMachine_2einitFrame(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2feval_2egDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2eaddReg(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/eval:Ptr" %a4)
@G_2ecompiler_2feval_2egOwner = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ereleaseHeld(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, i32 %a2)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2ewrite(ptr %v0, ptr %a0, i64 %a1, { i64, [1 x i64] } %a2, i32 %a3, { i64, [4 x i64] } %a4)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2espawn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i32 %a3)
@olang_loc_7f284a3be8281e29_2098fbd9ac092a4d = external constant [0 x i8]
@olang_loc_77ec49cd2ef2b53_f798fa63e9acfcff = external constant [0 x i8]
@G_2ecompiler_2fmir_2eI32T = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\05\00\00\00" }>, align 8
declare { { i64, ptr }, i64 } @compiler_2feval_2ecompiler_2feval_3aMachine_2etaskLayout(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/mir:Task" %a2, i64 %a3)
declare void @compiler_2feval_2ecompiler_2feval_3aMachine_2earrayTarget(ptr %v0, ptr %a0, %"compiler/eval:Ptr" %a1, %"compiler/eval:Ptr" %a2, i32 %a3, i64 %a4)
declare %"compiler/eval:reg" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feval_3areg_3e_2eSetAt_3ccompiler_2feval_3areg_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/eval:reg" %a2)
@olang_loc_f4c8d7149bd44e26_572dd2a903112792 = external constant [0 x i8]
declare i64 @compiler_2feval_2elz128(i64 %a0, i64 %a1, i64 %a2)
declare { i64, i64 } @compiler_2feval_2eextend128(i64 %a0, i64 %a1, i64 %a2, i1 %a3)
declare i64 @compiler_2feval_2ecompiler_2feval_3aMachine_2efromF64(ptr %v0, ptr %a0, double %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2eIntBytes(i64 %a0)
@olang_loc_eee052b68f79f6e4_de3952fe51604930 = external constant [0 x i8]
@G_2ecompiler_2feval_2efBin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efConst = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2feval_2efUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList1(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare void @compiler_2feval_2etfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2feval_2eSp0 = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddTemp(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eNewBlock(ptr %v0, ptr %a0)
@G_2ecompiler_2feval_2eB0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, [4 x i64] } @compiler_2feval_2etcopy(i64 %a0)
declare void @compiler_2feval_2etprim(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3, i32 %a4, { i64, [4 x i64] } %a5, { i64, [4 x i64] } %a6)
declare %"compiler/mir:Lvalue" @compiler_2fmir_2eL(i32 %a0)
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eEnd(ptr %v0, ptr %a0, i32 %a1, { i64, [8 x i64] } %a2)
@G_2ecompiler_2feval_2eS0 = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAdd(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"compiler/mir:Range" @compiler_2fmir_2ecompiler_2fmir_3aFn_2eArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fmir_2eEmpty = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fmir_2eNoLocal = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\FF\FF\FF\FF" }>, align 8
declare %"compiler/mir:Call" @compiler_2fmir_3aCall_2ector(ptr %v0, { i64, [7 x i64] } %a0, %"compiler/mir:Range" %a1, %"compiler/mir:Range" %a2, %"compiler/mir:Lvalue" %a3, i1 %a4, i32 %a5, i32 %a6, i32 %a7)
declare i32 @compiler_2fmir_2ecompiler_2fmir_3aFn_2eAddCall(ptr %v0, ptr %a0, %"compiler/mir:Call" %a1)
declare { i64, i64 } @compiler_2feval_2eshl128(i64 %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2feval_2egGen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/mir:Lvalue" @compiler_2fmir_3aLvalue_2ector(ptr %v0, { i64, [2 x i64] } %a0, %"compiler/mir:Range" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2feval_2enfn(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fmir_2ecompiler_2fmir_3aFn_2eVerify(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_48f03219a23009f5_27a95ef9d9612249 = external constant [0 x i8]
declare i1 @compiler_2feval_2eopNamesGlobal({ i64, [4 x i64] } %a0)
declare %"compiler/mir:Call" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fmir_3aCall_3e_2eAt_3ccompiler_2fmir_3aCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feval_2erangeNamesGlobal(ptr %v0, ptr %a0, %"compiler/mir:Range" %a1)
@olang_loc_70d3567da39f3a7a_be006e6544252cae = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2feval_3aBlob_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2feval_2eWhyWritesGlobal_2einit()
declare void @compiler_2feval_2eWhyCycle_2einit()
declare void @compiler_2feval_2eWhyNoGlobal_2einit()
declare void @compiler_2feval_2eWhyExtern_2einit()
declare void @compiler_2feval_2eWhyEqDepth_2einit()
declare void @compiler_2feval_2eWhyRunEqDepth_2einit()
declare void @compiler_2feval_2eWhyNullCall_2einit()
declare void @compiler_2feval_2eWhyFreedEarly_2einit()
declare void @compiler_2feval_2eWhyStale_2einit()
declare void @compiler_2feval_2eWhyOutside_2einit()
declare void @compiler_2feval_2eWhyBeyond_2einit()
declare void @compiler_2feval_2eWhyReadOnly_2einit()
declare void @compiler_2feval_2eWhyDivMin_2einit()
declare void @compiler_2feval_2eWhyShift_2einit()
declare void @compiler_2feval_2eWhyNaNOp_2einit()
declare void @compiler_2feval_2eWhyNotModelled_2einit()
declare void @compiler_2feval_2eWhyLong_2einit()
declare void @compiler_2feval_2eWhyWaits_2einit()
declare void @compiler_2feval_2eNullPtr_2einit()
declare void @compiler_2feval_2eslotBits_2einit()
declare void @compiler_2feval_2eaFree_2einit()
declare void @compiler_2feval_2eaValue_2einit()
declare void @compiler_2feval_2eaData_2einit()
declare void @compiler_2feval_2eaGlobal_2einit()
declare void @compiler_2feval_2eaCode_2einit()
declare void @compiler_2feval_2esStore_2einit()
declare void @compiler_2feval_2esProgram_2einit()
declare void @compiler_2feval_2esInert_2einit()
declare void @compiler_2feval_2esBuilder_2einit()
declare void @compiler_2feval_2esRegion_2einit()
declare void @compiler_2feval_2esJoin_2einit()
declare void @compiler_2feval_2egDtor_2einit()
declare void @compiler_2feval_2egOwner_2einit()
declare void @compiler_2feval_2erCall_2einit()
declare void @compiler_2feval_2erDtor_2einit()
declare void @compiler_2feval_2erTask_2einit()
declare void @compiler_2feval_2erClause_2einit()
declare void @compiler_2feval_2etRaised_2einit()
declare void @compiler_2feval_2etCall_2einit()
declare void @compiler_2feval_2etJoin_2einit()
declare void @compiler_2feval_2etraceKept_2einit()
declare void @compiler_2feval_2evVoid_2einit()
declare void @compiler_2feval_2evBool_2einit()
declare void @compiler_2feval_2evInt_2einit()
declare void @compiler_2feval_2evUint_2einit()
declare void @compiler_2feval_2evFloat_2einit()
declare void @compiler_2feval_2evPtr_2einit()
declare void @compiler_2feval_2evFunc_2einit()
declare void @compiler_2feval_2evOrd_2einit()
declare void @compiler_2feval_2evAgg_2einit()
declare void @compiler_2feval_2evFixed_2einit()
declare void @compiler_2feval_2evNone_2einit()
declare void @compiler_2feval_2evWide_2einit()
declare void @compiler_2feval_2efCopy_2einit()
declare void @compiler_2feval_2efLoad_2einit()
declare void @compiler_2feval_2efStore_2einit()
declare void @compiler_2feval_2efastStride_2einit()
declare void @compiler_2feval_2eForeignId_2einit()
declare void @compiler_2feval_2eSp0_2einit()
declare void @compiler_2feval_2eB0_2einit()
declare void @compiler_2feval_2eS0_2einit()
declare void @compiler_2feval_2eIntOps_2einit()
declare void @compiler_2feval_2eCmpOps_2einit()
declare void @compiler_2feval_3acfn_2ector(ptr %out, ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
