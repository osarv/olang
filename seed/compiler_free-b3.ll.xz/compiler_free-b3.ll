; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/free:leaf" = type { { i64, ptr }, i64 }
%"compiler/free:Free" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { ptr, ptr }, { ptr, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"compiler/mir:GenInfo", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/free:letGo" = type { i64, i64, i64, %"compiler/source:Span", %"compiler/source:Span", i64, %"compiler/source:Span", i64, i1 }
%"compiler/free:store" = type { i64, i64, i64, %"compiler/source:Span", i64, i64, i64, ptr, ptr }
%"compiler/free:orStore" = type { i64, i64, ptr, ptr }
%"compiler/free:orCall" = type { i64, i64, i64, i64, i64, ptr, ptr }
%"compiler/free:feedCall" = type { i64, i64, i64, i64, i64, i1 }
%"compiler/free:feed" = type { i64, i64, i64, i64, { i64, [2 x i64] }, { i64, [2 x i64] }, i64 }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/free:reason" = type { i64, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/typed:LocalUses" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i32, i1, i1 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64, i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, { i64, ptr }, i1, %"compiler/source:Span", { i64, ptr }, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/free:VecWalk" = type { { i64, ptr }, i64, i64, i64, i32, i64 }
%"compiler/free:walker" = type { ptr, i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i32, %"compiler/source:Span", { i64, ptr }, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/free:retire" = type { i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
define dso_local i64 @compiler_2ffree_2eborrowedLocal(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i64 @compiler_2ffree_2elocalOf(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i64, ptr %l10, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_501cc49742afc1b0_35a87f90516239c4)
  unreachable
bb12:
  %t20 = load i64, ptr %l2, !tbaa !24
  store i64 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReleaseLeaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/free:leaf"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/free:leaf"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/free:leaf"
  %l39 = alloca %"compiler/free:leaf"
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca %"compiler/free:leaf"
  %l54 = alloca %"compiler/free:leaf"
  %l58 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca %"compiler/free:leaf"
  %l63 = alloca %"compiler/free:leaf"
  %l64 = alloca ptr
  %l68 = alloca i32
  %l71 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i64
  %l75 = alloca i64
  %l80 = alloca %"compiler/free:leaf"
  %l81 = alloca %"compiler/free:leaf"
  %l82 = alloca i64
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l94 = alloca i64
  %l103 = alloca i64
  %l106 = alloca i64
  %l115 = alloca i64
  %l118 = alloca i1
  %l139 = alloca i64
  %l142 = alloca i64
  %l151 = alloca i64
  %l154 = alloca i1
  %l173 = alloca ptr
  %l176 = alloca %"compiler/free:leaf"
  %l178 = alloca %"compiler/free:leaf"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l23
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 8
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t9, i32 %a1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l29
  br label %bb5
bb5:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t15 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %t15
  store ptr %t15, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  %t17 = load i64, ptr %l5, !tbaa !24
  store i64 %t17, ptr %l31, !tbaa !24
  %t18 = load ptr, ptr %l4, !tbaa !29
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %t18)
  store i64 %t20, ptr %l33
  br label %bb7
bb7:
  %t21 = load i64, ptr %l31, !tbaa !24
  %t22 = load i64, ptr %l33, !tbaa !24
  %t23 = icmp slt i64 %t21, %t22
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb9:
  br label %bb10
bb10:
  %t27 = load ptr, ptr %l4, !tbaa !29
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s2, ptr %s2, ptr %t27, i64 %t28)
  store %"compiler/free:leaf" %t31, ptr %l38
  br label %bb11
bb11:
  %t32 = load %"compiler/free:leaf", ptr %l38
  store %"compiler/free:leaf" %t32, ptr %l39
  %t33 = call ptr @__olang_scope_hold(ptr %s3)
  %t34 = ptrtoint ptr %t33 to i64
  store i64 %t34, ptr %l40, !tbaa !24
  %t35 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t35, label %bb12, label %bb13
bb12:
  %t37 = call ptr @__olang_region_make_part(ptr %s3)
  %t38 = ptrtoint ptr %t37 to i64
  store i64 %t38, ptr %l40, !tbaa !24
  br label %bb13
bb13:
  %t39 = getelementptr %"compiler/free:leaf", ptr %l39, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  store { i64, ptr } %t40, ptr %l42, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  store i64 %t42, ptr %l43, !tbaa !24
  %t43 = load i64, ptr %l43, !tbaa !24
  %t44 = mul i64 %t43, 8
  %t45 = load i64, ptr %l40
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = call ptr @__olang_held_alloc(ptr %t46, i64 %t44)
  %t48 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l44, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = load i64, ptr %l43, !tbaa !24
  %t55 = mul i64 %t54, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t51, ptr %t53, i64 %t55, i1 false)
  %t56 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t57 = getelementptr %"compiler/free:leaf", ptr %l39, i32 0, i32 0
  store { i64, ptr } %t56, ptr %t57, !tbaa !27
  %t58 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t58, label %bb14, label %bb15
bb14:
  %t60 = getelementptr %"compiler/free:leaf", ptr %l39, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  %t64 = icmp eq i64 %t62, 0
  br i1 %t64, label %bb16, label %bb17
bb15:
  %t66 = load %"compiler/free:leaf", ptr %l39
  store %"compiler/free:leaf" %t66, ptr %l6
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 1
  %t69 = load i64, ptr %t68, !tbaa !24
  %t72 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t67, i64 %t69)
  store i1 %t72, ptr %l50
  br label %bb18
bb16:
  %t73 = getelementptr %"compiler/free:leaf", ptr %l39, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t73, !tbaa !27
  br label %bb17
bb17:
  %t74 = getelementptr %"compiler/free:leaf", ptr %l39, i32 0, i32 0
  %t75 = load i64, ptr %l40
  %t76 = inttoptr i64 %t75 to ptr
  %t77 = load { i64, ptr }, ptr %t74
  %t78 = extractvalue { i64, ptr } %t77, 1
  %t79 = call ptr @__olang_region_or(ptr %t78, ptr null)
  %t80 = icmp ne ptr %t79, null
  %t81 = select i1 %t80, ptr %t79, ptr null
  call void @__olang_region_settle_in(ptr %t76, ptr %t81)
  br label %bb15
bb18:
  %t82 = load i1, ptr %l50, !tbaa !21
  br i1 %t82, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %l3, ptr %l51, !tbaa !29
  %t83 = load %"compiler/free:leaf", ptr %l6
  store %"compiler/free:leaf" %t83, ptr %l52
  %t85 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s4, ptr %l52)
  store %"compiler/free:leaf" %t85, ptr %l54
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t86 = load ptr, ptr %l51, !tbaa !29
  %t87 = load %"compiler/free:leaf", ptr %l54
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s4, ptr %t86, %"compiler/free:leaf" %t87)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  br label %bb77
bb23:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/free:Free", ptr %t88, i32 0, i32 12
  %t91 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t95 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t90, i64 %t92)
  store i1 %t95, ptr %l58
  br label %bb24
bb24:
  %t96 = load i1, ptr %l58, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s3)
  br label %bb77
bb26:
  br label %bb27
bb27:
  store ptr %l3, ptr %l60, !tbaa !29
  %t99 = load %"compiler/free:leaf", ptr %l6
  store %"compiler/free:leaf" %t99, ptr %l61
  %t101 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s3, ptr %l61)
  store %"compiler/free:leaf" %t101, ptr %l63
  br label %bb28
bb28:
  %t102 = load ptr, ptr %l60, !tbaa !29
  %t103 = load %"compiler/free:leaf", ptr %l63
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s3, ptr %t102, %"compiler/free:leaf" %t103)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l64, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/free:Free", ptr %t105, i32 0, i32 15
  %t108 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 1
  %t109 = load i64, ptr %t108, !tbaa !24
  %t112 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t107, i64 %t109)
  store i32 %t112, ptr %l68
  br label %bb30
bb30:
  %t113 = load i64, ptr %l2, !tbaa !24
  %t115 = add i64 %t113, 1
  %t116 = load ptr, ptr %l64, !tbaa !29
  %t117 = load i32, ptr %l68, !tbaa !23
  %t119 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eReleaseLeaves(ptr %v0, ptr %s6, ptr %t116, i32 %t117, i64 %t115)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t119, ptr %l71
  br label %bb31
bb31:
  %t120 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l71
  %t121 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t120, ptr %t121
  store ptr %t121, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t123 = load i64, ptr %l8, !tbaa !24
  store i64 %t123, ptr %l73, !tbaa !24
  %t124 = load ptr, ptr %l7, !tbaa !29
  %t126 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s6, ptr %t124)
  store i64 %t126, ptr %l75
  br label %bb33
bb33:
  %t127 = load i64, ptr %l73, !tbaa !24
  %t128 = load i64, ptr %l75, !tbaa !24
  %t129 = icmp slt i64 %t127, %t128
  %t131 = xor i1 %t129, true
  br i1 %t131, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb76
bb35:
  br label %bb36
bb36:
  %t133 = load ptr, ptr %l7, !tbaa !29
  %t134 = load i64, ptr %l8, !tbaa !24
  %t137 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s6, ptr %s6, ptr %t133, i64 %t134)
  store %"compiler/free:leaf" %t137, ptr %l80
  br label %bb37
bb37:
  %t138 = load %"compiler/free:leaf", ptr %l80
  store %"compiler/free:leaf" %t138, ptr %l81
  %t139 = call ptr @__olang_scope_hold(ptr %s7)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l82, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t141, label %bb38, label %bb39
bb38:
  %t143 = call ptr @__olang_region_make_part(ptr %s7)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l82, !tbaa !24
  br label %bb39
bb39:
  %t145 = getelementptr %"compiler/free:leaf", ptr %l81, i32 0, i32 0
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  store { i64, ptr } %t146, ptr %l84, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l85, !tbaa !24
  %t149 = load i64, ptr %l85, !tbaa !24
  %t150 = mul i64 %t149, 8
  %t151 = load i64, ptr %l82
  %t152 = inttoptr i64 %t151 to ptr
  %t153 = call ptr @__olang_held_alloc(ptr %t152, i64 %t150)
  %t154 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l86, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = load i64, ptr %l85, !tbaa !24
  %t161 = mul i64 %t160, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t157, ptr %t159, i64 %t161, i1 false)
  %t162 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t163 = getelementptr %"compiler/free:leaf", ptr %l81, i32 0, i32 0
  store { i64, ptr } %t162, ptr %t163, !tbaa !27
  %t164 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t166 = getelementptr %"compiler/free:leaf", ptr %l81, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t170 = icmp eq i64 %t168, 0
  br i1 %t170, label %bb42, label %bb43
bb41:
  %t172 = load %"compiler/free:leaf", ptr %l81
  store %"compiler/free:leaf" %t172, ptr %l9
  %t173 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t174, 0
  %t177 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 0
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t183 = add i64 %t176, %t180
  store i64 %t183, ptr %l94, !tbaa !24
  %t184 = load i64, ptr %l94, !tbaa !24
  %t185 = icmp sge i64 %t184, 0
  br i1 %t185, label %bb44, label %bb45
bb42:
  %t187 = getelementptr %"compiler/free:leaf", ptr %l81, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t187, !tbaa !27
  br label %bb43
bb43:
  %t188 = getelementptr %"compiler/free:leaf", ptr %l81, i32 0, i32 0
  %t189 = load i64, ptr %l82
  %t190 = inttoptr i64 %t189 to ptr
  %t191 = load { i64, ptr }, ptr %t188
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = call ptr @__olang_region_or(ptr %t192, ptr null)
  %t194 = icmp ne ptr %t193, null
  %t195 = select i1 %t194, ptr %t193, ptr null
  call void @__olang_region_settle_in(ptr %t190, ptr %t195)
  br label %bb41
bb44:
  %t196 = load i64, ptr %l94, !tbaa !24
  %t197 = icmp sle i64 %t196, 1152921504606846975
  br i1 %t197, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_b1f6521422f181b6_5a182b34590183f2)
  unreachable
bb46:
  %t199 = load i64, ptr %l94, !tbaa !24
  %t200 = mul i64 %t199, 8
  %t201 = call ptr @__olang_scope_alloc_zeroed(ptr %s7, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t205 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  store i64 %t208, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t210 = load i64, ptr %l12, !tbaa !24
  %t211 = load i64, ptr %l11, !tbaa !24
  %t214 = icmp sgt i64 %t210, %t211
  br i1 %t214, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_b1f6521422f181b6_5a182b34590183f2)
  unreachable
bb48:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l103, !tbaa !24
  br label %bb53
bb50:
  %t220 = load i64, ptr %l12, !tbaa !24
  %t221 = load i64, ptr %l11, !tbaa !24
  %t224 = sub i64 %t220, %t221
  %t225 = load i64, ptr %l13, !tbaa !24
  %t228 = add i64 %t224, %t225
  %t230 = sub i64 %t228, 1
  %t231 = load i64, ptr %l13, !tbaa !24
  %t234 = sdiv i64 %t230, %t231
  store i64 %t234, ptr %l106, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l106, !tbaa !24
  br label %bb52
bb52:
  %t236 = load i64, ptr %l106, !tbaa !24
  store i64 %t236, ptr %l103, !tbaa !24
  br label %bb53
bb53:
  %t237 = load i64, ptr %l103, !tbaa !24
  store i64 %t237, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t238 = load i64, ptr %l14, !tbaa !24
  %t239 = sub i64 %t238, 1
  store i64 %t239, ptr %l115, !tbaa !24
  %t240 = load i64, ptr %l14, !tbaa !24
  %t241 = icmp slt i64 %t240, 2147483648
  %t242 = load i64, ptr %l15, !tbaa !24
  %t243 = icmp sge i64 %t242, 0
  %t246 = and i1 %t241, %t243
  store i1 %t246, ptr %l118, !tbaa !21
  br label %bb54
bb54:
  %t247 = load i64, ptr %l15, !tbaa !24
  %t248 = load i64, ptr %l14, !tbaa !24
  %t251 = icmp slt i64 %t247, %t248
  %t253 = xor i1 %t251, true
  br i1 %t253, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t255 = load i64, ptr %l11, !tbaa !24
  %t256 = load i64, ptr %l15, !tbaa !24
  %t257 = load i64, ptr %l13, !tbaa !24
  %t260 = mul i64 %t256, %t257
  %t263 = add i64 %t255, %t260
  store i64 %t263, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l16, !tbaa !24
  %t266 = load i64, ptr %l16, !tbaa !24
  %t267 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t269 = getelementptr { i64, ptr }, ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i64, ptr %t270, i64 %t266
  %t272 = load i64, ptr %t271, !tbaa !34
  %t275 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr i64, ptr %t276, i64 %t265
  store i64 %t272, ptr %t277, !tbaa !34
  br label %bb58
bb58:
  %t278 = load i64, ptr %l15, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l15, !tbaa !24
  br label %bb54
bb59:
  store i64 0, ptr %l17, !tbaa !24
  %t283 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 0
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  %t286 = extractvalue { i64, ptr } %t284, 0
  store i64 %t286, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t288 = load i64, ptr %l18, !tbaa !24
  %t289 = load i64, ptr %l17, !tbaa !24
  %t292 = icmp sgt i64 %t288, %t289
  br i1 %t292, label %bb60, label %bb61
bb60:
  %t294 = load i64, ptr %l19, !tbaa !24
  %t296 = icmp sgt i64 %t294, 0
  br i1 %t296, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l139, !tbaa !24
  br label %bb65
bb62:
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l17, !tbaa !24
  %t302 = sub i64 %t298, %t299
  %t303 = load i64, ptr %l19, !tbaa !24
  %t306 = add i64 %t302, %t303
  %t308 = sub i64 %t306, 1
  %t309 = load i64, ptr %l19, !tbaa !24
  %t312 = sdiv i64 %t308, %t309
  store i64 %t312, ptr %l142, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l142, !tbaa !24
  br label %bb64
bb64:
  %t314 = load i64, ptr %l142, !tbaa !24
  store i64 %t314, ptr %l139, !tbaa !24
  br label %bb65
bb65:
  %t315 = load i64, ptr %l139, !tbaa !24
  store i64 %t315, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  %t316 = load i64, ptr %l20, !tbaa !24
  %t317 = sub i64 %t316, 1
  store i64 %t317, ptr %l151, !tbaa !24
  %t318 = load i64, ptr %l20, !tbaa !24
  %t319 = icmp slt i64 %t318, 2147483648
  %t320 = load i64, ptr %l21, !tbaa !24
  %t321 = icmp sge i64 %t320, 0
  %t324 = and i1 %t319, %t321
  store i1 %t324, ptr %l154, !tbaa !21
  br label %bb66
bb66:
  %t325 = load i64, ptr %l21, !tbaa !24
  %t326 = load i64, ptr %l20, !tbaa !24
  %t329 = icmp slt i64 %t325, %t326
  %t331 = xor i1 %t329, true
  br i1 %t331, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  br label %bb69
bb69:
  %t333 = load i64, ptr %l17, !tbaa !24
  %t334 = load i64, ptr %l21, !tbaa !24
  %t335 = load i64, ptr %l19, !tbaa !24
  %t338 = mul i64 %t334, %t335
  %t341 = add i64 %t333, %t338
  store i64 %t341, ptr %l22, !tbaa !24
  %t343 = getelementptr %"compiler/free:leaf", ptr %l6, i32 0, i32 0
  %t344 = load { i64, ptr }, ptr %t343, !tbaa !27
  %t346 = extractvalue { i64, ptr } %t344, 0
  %t347 = load i64, ptr %l22, !tbaa !24
  %t350 = add i64 %t346, %t347
  %t351 = load i64, ptr %l22, !tbaa !24
  %t352 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 0
  %t354 = getelementptr { i64, ptr }, ptr %t352, i32 0, i32 1
  %t355 = load ptr, ptr %t354, !tbaa !27
  %t356 = getelementptr i64, ptr %t355, i64 %t351
  %t357 = load i64, ptr %t356, !tbaa !34
  %t360 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr i64, ptr %t361, i64 %t350
  store i64 %t357, ptr %t362, !tbaa !34
  br label %bb70
bb70:
  %t363 = load i64, ptr %l21, !tbaa !24
  %t366 = add i64 %t363, 1
  store i64 %t366, ptr %l21, !tbaa !24
  br label %bb66
bb71:
  store ptr %l3, ptr %l173, !tbaa !29
  %t368 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t369 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t370 = load i64, ptr %t369, !tbaa !24
  %t373 = call %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %s7, { i64, ptr } %t368, i64 %t370)
  store %"compiler/free:leaf" %t373, ptr %l176
  br label %bb72
bb72:
  %t375 = call %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %s7, ptr %l176)
  store %"compiler/free:leaf" %t375, ptr %l178
  br label %bb73
bb73:
  %t376 = load ptr, ptr %l173, !tbaa !29
  %t377 = load %"compiler/free:leaf", ptr %l178
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v1, ptr %s7, ptr %t376, %"compiler/free:leaf" %t377)
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s7)
  br label %bb75
bb75:
  %t378 = load i64, ptr %l8, !tbaa !24
  %t381 = add i64 %t378, 1
  store i64 %t381, ptr %l8, !tbaa !24
  br label %bb32
bb76:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  br label %bb77
bb77:
  %t383 = load i64, ptr %l5, !tbaa !24
  %t386 = add i64 %t383, 1
  store i64 %t386, ptr %l5, !tbaa !24
  br label %bb6
bb78:
  call void @__olang_scope_close(ptr %s2)
  %t388 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t388, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eaddBody(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l8 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca i1
  %l30 = alloca ptr
  %l33 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i64
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca ptr
  %l42 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca ptr
  %l54 = alloca i64
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca ptr
  %l60 = alloca i64
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca ptr
  %l66 = alloca i64
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l71 = alloca ptr
  %l72 = alloca i64
  %l74 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l77 = alloca ptr
  %l78 = alloca i64
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca ptr
  %l84 = alloca i64
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca ptr
  %l90 = alloca i64
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l99 = alloca ptr
  %l100 = alloca i64
  %l102 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca ptr
  %l108 = alloca i64
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca ptr
  %l131 = alloca ptr
  %l135 = alloca i64
  %l136 = alloca ptr
  %l139 = alloca i1
  %l142 = alloca i1
  %l147 = alloca ptr
  %l148 = alloca i64
  %l150 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l153 = alloca ptr
  %l154 = alloca i64
  %l156 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l159 = alloca ptr
  %l160 = alloca i64
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l165 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l171 = alloca ptr
  %l172 = alloca i64
  %l174 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l185 = alloca ptr
  %l186 = alloca i64
  %l192 = alloca ptr
  %l193 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/free:Free", ptr %t7, i32 0, i32 28
  %t10 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t9, i64 %t10)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:Free", ptr %t13, i32 0, i32 29
  store ptr %t15, ptr %l13, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/free:Free", ptr %t16, i32 0, i32 8
  %t19 = load i1, ptr %t18, !tbaa !21
  %t21 = xor i1 %t19, true
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp eq i64 %t23, -3
  br i1 %t25, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb5:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb7
bb6:
  %t27 = load i64, ptr %l3, !tbaa !24
  %t31 = icmp eq i64 %t27, %a2
  store i1 %t31, ptr %l20, !tbaa !21
  br label %bb7
bb7:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l13, !tbaa !29
  %t35 = load i1, ptr %l17, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t34, i1 %t35)
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 30
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %t39, i64 %t40)
  store i1 %t43, ptr %l28
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l25, !tbaa !29
  %t45 = load i1, ptr %l28, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t44, i1 %t45)
  br label %bb11
bb11:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 68
  store ptr %t48, ptr %l30, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i64, ptr %l1, !tbaa !24
  %t53 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %t49, i64 %t50)
  store i1 %t53, ptr %l33
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l30, !tbaa !29
  %t55 = load i1, ptr %l33, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t54, i1 %t55)
  br label %bb13
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/free:Free", ptr %t56, i32 0, i32 69
  store ptr %t58, ptr %l35, !tbaa !29
  %t59 = call ptr @__olang_scope_hold(ptr %v0)
  %t60 = ptrtoint ptr %t59 to i64
  store i64 %t60, ptr %l36, !tbaa !24
  %t61 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t61, label %bb14, label %bb15
bb14:
  %t63 = call ptr @__olang_region_make(ptr %v0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l36, !tbaa !24
  br label %bb15
bb15:
  %t65 = load i64, ptr %l36
  %t66 = inttoptr i64 %t65 to ptr
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t66, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l38
  br label %bb16
bb16:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t69 = load i64, ptr %l36
  %t70 = inttoptr i64 %t69 to ptr
  %t71 = call ptr @__olang_scope_alloc_a(ptr %t70, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %t71
  %t72 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t72, ptr %t71)
  br label %bb17
bb17:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 70
  store ptr %t76, ptr %l41, !tbaa !29
  %t77 = call ptr @__olang_scope_hold(ptr %v0)
  %t78 = ptrtoint ptr %t77 to i64
  store i64 %t78, ptr %l42, !tbaa !24
  %t79 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t81 = call ptr @__olang_region_make(ptr %v0)
  %t82 = ptrtoint ptr %t81 to i64
  store i64 %t82, ptr %l42, !tbaa !24
  br label %bb19
bb19:
  %t83 = load i64, ptr %l42
  %t84 = inttoptr i64 %t83 to ptr
  %t85 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t84, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t85, ptr %l44
  br label %bb20
bb20:
  %t86 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  %t87 = load i64, ptr %l42
  %t88 = inttoptr i64 %t87 to ptr
  %t89 = call ptr @__olang_scope_alloc_a(ptr %t88, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %t89
  %t90 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t90, ptr %t89)
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:Free", ptr %t92, i32 0, i32 71
  store ptr %t94, ptr %l47, !tbaa !29
  %t95 = call ptr @__olang_scope_hold(ptr %v0)
  %t96 = ptrtoint ptr %t95 to i64
  store i64 %t96, ptr %l48, !tbaa !24
  %t97 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t97, label %bb22, label %bb23
bb22:
  %t99 = call ptr @__olang_region_make(ptr %v0)
  %t100 = ptrtoint ptr %t99 to i64
  store i64 %t100, ptr %l48, !tbaa !24
  br label %bb23
bb23:
  %t101 = load i64, ptr %l48
  %t102 = inttoptr i64 %t101 to ptr
  %t103 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t102, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l50
  br label %bb24
bb24:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  %t105 = load i64, ptr %l48
  %t106 = inttoptr i64 %t105 to ptr
  %t107 = call ptr @__olang_scope_alloc_a(ptr %t106, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %t107
  %t108 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t108, ptr %t107)
  br label %bb25
bb25:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 72
  store ptr %t112, ptr %l53, !tbaa !29
  %t113 = call ptr @__olang_scope_hold(ptr %v0)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l54, !tbaa !24
  %t115 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t115, label %bb26, label %bb27
bb26:
  %t117 = call ptr @__olang_region_make(ptr %v0)
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l54, !tbaa !24
  br label %bb27
bb27:
  %t119 = load i64, ptr %l54
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t120, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l56
  br label %bb28
bb28:
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t123 = load i64, ptr %l54
  %t124 = inttoptr i64 %t123 to ptr
  %t125 = call ptr @__olang_scope_alloc_a(ptr %t124, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %t125
  %t126 = load ptr, ptr %l53, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t126, ptr %t125)
  br label %bb29
bb29:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/free:Free", ptr %t128, i32 0, i32 73
  store ptr %t130, ptr %l59, !tbaa !29
  %t131 = call ptr @__olang_scope_hold(ptr %v0)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l60, !tbaa !24
  %t133 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t133, label %bb30, label %bb31
bb30:
  %t135 = call ptr @__olang_region_make(ptr %v0)
  %t136 = ptrtoint ptr %t135 to i64
  store i64 %t136, ptr %l60, !tbaa !24
  br label %bb31
bb31:
  %t137 = load i64, ptr %l60
  %t138 = inttoptr i64 %t137 to ptr
  %t139 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t138, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l62
  br label %bb32
bb32:
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  %t141 = load i64, ptr %l60
  %t142 = inttoptr i64 %t141 to ptr
  %t143 = call ptr @__olang_scope_alloc_a(ptr %t142, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %t143
  %t144 = load ptr, ptr %l59, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t144, ptr %t143)
  br label %bb33
bb33:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/free:Free", ptr %t146, i32 0, i32 74
  store ptr %t148, ptr %l65, !tbaa !29
  %t149 = call ptr @__olang_scope_hold(ptr %v0)
  %t150 = ptrtoint ptr %t149 to i64
  store i64 %t150, ptr %l66, !tbaa !24
  %t151 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t151, label %bb34, label %bb35
bb34:
  %t153 = call ptr @__olang_region_make(ptr %v0)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l66, !tbaa !24
  br label %bb35
bb35:
  %t155 = load i64, ptr %l66
  %t156 = inttoptr i64 %t155 to ptr
  %t157 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t156, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l68
  br label %bb36
bb36:
  %t158 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  %t159 = load i64, ptr %l66
  %t160 = inttoptr i64 %t159 to ptr
  %t161 = call ptr @__olang_scope_alloc_a(ptr %t160, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %t161
  %t162 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t162, ptr %t161)
  br label %bb37
bb37:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/free:Free", ptr %t164, i32 0, i32 75
  store ptr %t166, ptr %l71, !tbaa !29
  %t167 = call ptr @__olang_scope_hold(ptr %v0)
  %t168 = ptrtoint ptr %t167 to i64
  store i64 %t168, ptr %l72, !tbaa !24
  %t169 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t169, label %bb38, label %bb39
bb38:
  %t171 = call ptr @__olang_region_make(ptr %v0)
  %t172 = ptrtoint ptr %t171 to i64
  store i64 %t172, ptr %l72, !tbaa !24
  br label %bb39
bb39:
  %t173 = load i64, ptr %l72
  %t174 = inttoptr i64 %t173 to ptr
  %t175 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t174, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t175, ptr %l74
  br label %bb40
bb40:
  %t176 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l74
  %t177 = load i64, ptr %l72
  %t178 = inttoptr i64 %t177 to ptr
  %t179 = call ptr @__olang_scope_alloc_a(ptr %t178, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %t179
  %t180 = load ptr, ptr %l71, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t180, ptr %t179)
  br label %bb41
bb41:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/free:Free", ptr %t182, i32 0, i32 79
  store ptr %t184, ptr %l77, !tbaa !29
  %t185 = call ptr @__olang_scope_hold(ptr %v0)
  %t186 = ptrtoint ptr %t185 to i64
  store i64 %t186, ptr %l78, !tbaa !24
  %t187 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t187, label %bb42, label %bb43
bb42:
  %t189 = call ptr @__olang_region_make(ptr %v0)
  %t190 = ptrtoint ptr %t189 to i64
  store i64 %t190, ptr %l78, !tbaa !24
  br label %bb43
bb43:
  %t191 = load i64, ptr %l78
  %t192 = inttoptr i64 %t191 to ptr
  %t193 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t192, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t193, ptr %l80
  br label %bb44
bb44:
  %t194 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  %t195 = load i64, ptr %l78
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = call ptr @__olang_scope_alloc_a(ptr %t196, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t194, ptr %t197
  %t198 = load ptr, ptr %l77, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t198, ptr %t197)
  br label %bb45
bb45:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/free:Free", ptr %t200, i32 0, i32 76
  store ptr %t202, ptr %l83, !tbaa !29
  %t203 = call ptr @__olang_scope_hold(ptr %v0)
  %t204 = ptrtoint ptr %t203 to i64
  store i64 %t204, ptr %l84, !tbaa !24
  %t205 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t205, label %bb46, label %bb47
bb46:
  %t207 = call ptr @__olang_region_make(ptr %v0)
  %t208 = ptrtoint ptr %t207 to i64
  store i64 %t208, ptr %l84, !tbaa !24
  br label %bb47
bb47:
  %t209 = load i64, ptr %l84
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t210, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t211, ptr %l86
  br label %bb48
bb48:
  %t212 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86
  %t213 = load i64, ptr %l84
  %t214 = inttoptr i64 %t213 to ptr
  %t215 = call ptr @__olang_scope_alloc_a(ptr %t214, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %t215
  %t216 = load ptr, ptr %l83, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t216, ptr %t215)
  br label %bb49
bb49:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/free:Free", ptr %t218, i32 0, i32 77
  store ptr %t220, ptr %l89, !tbaa !29
  %t221 = call ptr @__olang_scope_hold(ptr %v0)
  %t222 = ptrtoint ptr %t221 to i64
  store i64 %t222, ptr %l90, !tbaa !24
  %t223 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t223, label %bb50, label %bb51
bb50:
  %t225 = call ptr @__olang_region_make(ptr %v0)
  %t226 = ptrtoint ptr %t225 to i64
  store i64 %t226, ptr %l90, !tbaa !24
  br label %bb51
bb51:
  %t227 = load i64, ptr %l90
  %t228 = inttoptr i64 %t227 to ptr
  %t229 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t228, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t229, ptr %l92
  br label %bb52
bb52:
  %t230 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t231 = load i64, ptr %l90
  %t232 = inttoptr i64 %t231 to ptr
  %t233 = call ptr @__olang_scope_alloc_a(ptr %t232, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t230, ptr %t233
  %t234 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t234, ptr %t233)
  br label %bb53
bb53:
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/free:Free", ptr %t236, i32 0, i32 78
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t238, i1 false)
  br label %bb54
bb54:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/free:Free", ptr %t240, i32 0, i32 85
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t242, i64 0)
  br label %bb55
bb55:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr %"compiler/free:Free", ptr %t244, i32 0, i32 87
  store ptr %t246, ptr %l99, !tbaa !29
  %t247 = call ptr @__olang_scope_hold(ptr %v0)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l100, !tbaa !24
  %t249 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t249, label %bb56, label %bb57
bb56:
  %t251 = call ptr @__olang_region_make(ptr %v0)
  %t252 = ptrtoint ptr %t251 to i64
  store i64 %t252, ptr %l100, !tbaa !24
  br label %bb57
bb57:
  %t253 = load i64, ptr %l100
  %t254 = inttoptr i64 %t253 to ptr
  %t255 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t254, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t255, ptr %l102
  br label %bb58
bb58:
  %t256 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l102
  %t257 = load i64, ptr %l100
  %t258 = inttoptr i64 %t257 to ptr
  %t259 = call ptr @__olang_scope_alloc_a(ptr %t258, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t256, ptr %t259
  %t260 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t260, ptr %t259)
  br label %bb59
bb59:
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t264 = getelementptr %"compiler/free:Free", ptr %t262, i32 0, i32 86
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t264, i64 0)
  br label %bb60
bb60:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/free:Free", ptr %t266, i32 0, i32 88
  store ptr %t268, ptr %l107, !tbaa !29
  %t269 = call ptr @__olang_scope_hold(ptr %v0)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l108, !tbaa !24
  %t271 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t271, label %bb61, label %bb62
bb61:
  %t273 = call ptr @__olang_region_make(ptr %v0)
  %t274 = ptrtoint ptr %t273 to i64
  store i64 %t274, ptr %l108, !tbaa !24
  br label %bb62
bb62:
  %t275 = load i64, ptr %l108
  %t276 = inttoptr i64 %t275 to ptr
  %t277 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t276, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t277, ptr %l110
  br label %bb63
bb63:
  %t278 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  %t279 = load i64, ptr %l108
  %t280 = inttoptr i64 %t279 to ptr
  %t281 = call ptr @__olang_scope_alloc_a(ptr %t280, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t278, ptr %t281
  %t282 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t282, ptr %t281)
  br label %bb64
bb64:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t286 = getelementptr %"compiler/free:Free", ptr %t284, i32 0, i32 89
  %t287 = load i64, ptr @G_2ecompiler_2ffree_2eMustTop, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t286, i64 %t287)
  br label %bb65
bb65:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/free:Free", ptr %t290, i32 0, i32 90
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t292, i1 true)
  br label %bb66
bb66:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/free:Free", ptr %t294, i32 0, i32 91
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t296, i1 false)
  br label %bb67
bb67:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t300 = getelementptr %"compiler/free:Free", ptr %t298, i32 0, i32 93
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t300, i1 false)
  br label %bb68
bb68:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = getelementptr %"compiler/free:Free", ptr %t302, i32 0, i32 1
  %t305 = load i64, ptr %l1, !tbaa !24
  %t308 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t304, i64 %t305)
  store ptr %t308, ptr %l124
  br label %bb69
bb69:
  %t309 = load ptr, ptr %l124, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Body", ptr %t309, i32 0, i32 1
  %t312 = load { i64, [2 x i64] }, ptr %t311
  store { i64, [2 x i64] } %t312, ptr %l4
  %t314 = load { i64, [2 x i64] }, ptr %l4
  %t316 = extractvalue { i64, [2 x i64] } %t314, 0
  %t317 = icmp eq i64 %t316, 0
  br i1 %t317, label %bb70, label %bb71
bb70:
  %t319 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t320 = getelementptr { i64 }, ptr %t319, i32 0, i32 0
  %t321 = load i64, ptr %t320
  store i64 %t321, ptr %l5, !tbaa !24
  br label %bb72
bb71:
  br label %bb83
bb72:
  store %olang.scope zeroinitializer, ptr %s1
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = getelementptr %"compiler/free:Free", ptr %t323, i32 0, i32 0
  %t326 = load ptr, ptr %t325, !tbaa !29
  store ptr %t326, ptr %l131, !tbaa !29
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/free:Free", ptr %t327, i32 0, i32 0
  %t330 = load ptr, ptr %t329, !tbaa !29
  %t331 = load i64, ptr %l5, !tbaa !24
  %t334 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t330, i64 %t331)
  store i64 %t334, ptr %l135
  br label %bb73
bb73:
  %t335 = load ptr, ptr %l131, !tbaa !29
  %t336 = load i64, ptr %l135, !tbaa !24
  %t337 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s1, ptr %t335, i64 %t336)
  store ptr %t337, ptr %l136
  br label %bb74
bb74:
  %t338 = load ptr, ptr %l136, !tbaa !29
  %t340 = getelementptr %"compiler/ast:Func", ptr %t338, i32 0, i32 7
  %t341 = load i1, ptr %t340, !tbaa !21
  br i1 %t341, label %bb75, label %bb76
bb75:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i64, ptr %l5, !tbaa !24
  %t347 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandedToC(ptr %v0, ptr %t343, i64 %t344)
  store i1 %t347, ptr %l142
  br label %bb77
bb76:
  store i1 false, ptr %l139, !tbaa !21
  br label %bb78
bb77:
  %t348 = load i1, ptr %l142, !tbaa !21
  store i1 %t348, ptr %l139, !tbaa !21
  br label %bb78
bb78:
  %t349 = load i1, ptr %l139, !tbaa !21
  br i1 %t349, label %bb79, label %bb80
bb79:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/free:Free", ptr %t350, i32 0, i32 94
  %t353 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t352, i64 %t353)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s1)
  br label %bb88
bb83:
  br i1 true, label %bb84, label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_bdc560d7322c3213_e707f8f411fbb267)
  unreachable
bb88:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/free:Free", ptr %t356, i32 0, i32 113
  store ptr %t358, ptr %l147, !tbaa !29
  %t359 = call ptr @__olang_scope_hold(ptr %v0)
  %t360 = ptrtoint ptr %t359 to i64
  store i64 %t360, ptr %l148, !tbaa !24
  %t361 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t361, label %bb89, label %bb90
bb89:
  %t363 = call ptr @__olang_region_make(ptr %v0)
  %t364 = ptrtoint ptr %t363 to i64
  store i64 %t364, ptr %l148, !tbaa !24
  br label %bb90
bb90:
  %t365 = load i64, ptr %l148
  %t366 = inttoptr i64 %t365 to ptr
  %t367 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t366, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t367, ptr %l150
  br label %bb91
bb91:
  %t368 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l150
  %t369 = load i64, ptr %l148
  %t370 = inttoptr i64 %t369 to ptr
  %t371 = call ptr @__olang_scope_alloc_a(ptr %t370, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t368, ptr %t371
  %t372 = load ptr, ptr %l147, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t372, ptr %t371)
  br label %bb92
bb92:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/free:Free", ptr %t374, i32 0, i32 116
  store ptr %t376, ptr %l153, !tbaa !29
  %t377 = call ptr @__olang_scope_hold(ptr %v0)
  %t378 = ptrtoint ptr %t377 to i64
  store i64 %t378, ptr %l154, !tbaa !24
  %t379 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1
  br i1 %t379, label %bb93, label %bb94
bb93:
  %t381 = call ptr @__olang_region_make(ptr %v0)
  %t382 = ptrtoint ptr %t381 to i64
  store i64 %t382, ptr %l154, !tbaa !24
  br label %bb94
bb94:
  %t383 = load i64, ptr %l154
  %t384 = inttoptr i64 %t383 to ptr
  %t385 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t384, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t385, ptr %l156
  br label %bb95
bb95:
  %t386 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156
  %t387 = load i64, ptr %l154
  %t388 = inttoptr i64 %t387 to ptr
  %t389 = call ptr @__olang_scope_alloc_a(ptr %t388, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t386, ptr %t389
  %t390 = load ptr, ptr %l153, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_H788cd74f9c006611bc4bb459b5b22001(ptr %v0, ptr %v0, ptr %t390, ptr %t389)
  br label %bb96
bb96:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/free:Free", ptr %t392, i32 0, i32 114
  store ptr %t394, ptr %l159, !tbaa !29
  %t395 = call ptr @__olang_scope_hold(ptr %v0)
  %t396 = ptrtoint ptr %t395 to i64
  store i64 %t396, ptr %l160, !tbaa !24
  %t397 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t397, label %bb97, label %bb98
bb97:
  %t399 = call ptr @__olang_region_make(ptr %v0)
  %t400 = ptrtoint ptr %t399 to i64
  store i64 %t400, ptr %l160, !tbaa !24
  br label %bb98
bb98:
  %t401 = load i64, ptr %l160
  %t402 = inttoptr i64 %t401 to ptr
  %t403 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t402, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t403, ptr %l162
  br label %bb99
bb99:
  %t404 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162
  %t405 = load i64, ptr %l160
  %t406 = inttoptr i64 %t405 to ptr
  %t407 = call ptr @__olang_scope_alloc_a(ptr %t406, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t404, ptr %t407
  %t408 = load ptr, ptr %l159, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t408, ptr %t407)
  br label %bb100
bb100:
  %t410 = load ptr, ptr %l0, !tbaa !29
  %t412 = getelementptr %"compiler/free:Free", ptr %t410, i32 0, i32 115
  store ptr %t412, ptr %l165, !tbaa !29
  %t413 = call ptr @__olang_scope_hold(ptr %v0)
  %t414 = ptrtoint ptr %t413 to i64
  store i64 %t414, ptr %l166, !tbaa !24
  %t415 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1
  br i1 %t415, label %bb101, label %bb102
bb101:
  %t417 = call ptr @__olang_region_make(ptr %v0)
  %t418 = ptrtoint ptr %t417 to i64
  store i64 %t418, ptr %l166, !tbaa !24
  br label %bb102
bb102:
  %t419 = load i64, ptr %l166
  %t420 = inttoptr i64 %t419 to ptr
  %t421 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t420, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t421, ptr %l168
  br label %bb103
bb103:
  %t422 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168
  %t423 = load i64, ptr %l166
  %t424 = inttoptr i64 %t423 to ptr
  %t425 = call ptr @__olang_scope_alloc_a(ptr %t424, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t422, ptr %t425
  %t426 = load ptr, ptr %l165, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_H788cd74f9c006611bc4bb459b5b22001(ptr %v0, ptr %v0, ptr %t426, ptr %t425)
  br label %bb104
bb104:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/free:Free", ptr %t428, i32 0, i32 117
  store ptr %t430, ptr %l171, !tbaa !29
  %t431 = call ptr @__olang_scope_hold(ptr %v0)
  %t432 = ptrtoint ptr %t431 to i64
  store i64 %t432, ptr %l172, !tbaa !24
  %t433 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t433, label %bb105, label %bb106
bb105:
  %t435 = call ptr @__olang_region_make(ptr %v0)
  %t436 = ptrtoint ptr %t435 to i64
  store i64 %t436, ptr %l172, !tbaa !24
  br label %bb106
bb106:
  %t437 = load i64, ptr %l172
  %t438 = inttoptr i64 %t437 to ptr
  %t439 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t438, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t439, ptr %l174
  br label %bb107
bb107:
  %t440 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l174
  %t441 = load i64, ptr %l172
  %t442 = inttoptr i64 %t441 to ptr
  %t443 = call ptr @__olang_scope_alloc_a(ptr %t442, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t440, ptr %t443
  %t444 = load ptr, ptr %l171, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t444, ptr %t443)
  br label %bb108
bb108:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/free:Free", ptr %t446, i32 0, i32 97
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t448, i1 false)
  br label %bb109
bb109:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/free:Free", ptr %t450, i32 0, i32 125
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t452, i1 false)
  br label %bb110
bb110:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/free:Free", ptr %t454, i32 0, i32 126
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t456, i1 false)
  br label %bb111
bb111:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/free:Free", ptr %t458, i32 0, i32 98
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t460, i1 false)
  br label %bb112
bb112:
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/free:Free", ptr %t462, i32 0, i32 118
  store ptr %t464, ptr %l185, !tbaa !29
  %t465 = call ptr @__olang_scope_hold(ptr %v0)
  %t466 = ptrtoint ptr %t465 to i64
  store i64 %t466, ptr %l186, !tbaa !24
  %t467 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1
  br i1 %t467, label %bb113, label %bb114
bb113:
  %t469 = call ptr @__olang_region_make(ptr %v0)
  %t470 = ptrtoint ptr %t469 to i64
  store i64 %t470, ptr %l186, !tbaa !24
  br label %bb114
bb114:
  %t471 = icmp sge i64 0, 0
  br i1 %t471, label %bb115, label %bb116
bb115:
  %t473 = icmp sle i64 0, 1152921504606846975
  br i1 %t473, label %bb117, label %bb118
bb116:
  call void @__olang_check_failed(ptr @olang_loc_72902bac739aff89_2513c2e385693c05)
  unreachable
bb117:
  %t475 = mul i64 0, 8
  %t476 = load i64, ptr %l186
  %t477 = inttoptr i64 %t476 to ptr
  %t478 = insertvalue { i64, ptr } undef, i64 0, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t480 = load ptr, ptr %l185, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t480, { i64, ptr } %t479)
  br label %bb119
bb118:
  call void @__olang_check_failed(ptr @olang_loc_72902bac739aff89_2513c2e385693c05)
  unreachable
bb119:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = getelementptr %"compiler/free:Free", ptr %t482, i32 0, i32 119
  store ptr %t484, ptr %l192, !tbaa !29
  %t485 = call ptr @__olang_scope_hold(ptr %v0)
  %t486 = ptrtoint ptr %t485 to i64
  store i64 %t486, ptr %l193, !tbaa !24
  %t487 = load i1, ptr @olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1
  br i1 %t487, label %bb120, label %bb121
bb120:
  %t489 = call ptr @__olang_region_make(ptr %v0)
  %t490 = ptrtoint ptr %t489 to i64
  store i64 %t490, ptr %l193, !tbaa !24
  br label %bb121
bb121:
  %t491 = icmp sge i64 0, 0
  br i1 %t491, label %bb122, label %bb123
bb122:
  %t493 = icmp sle i64 0, 1152921504606846975
  br i1 %t493, label %bb124, label %bb125
bb123:
  call void @__olang_check_failed(ptr @olang_loc_3fc20153d7ed10ca_2c74aea1b5acbce6)
  unreachable
bb124:
  %t495 = mul i64 0, 8
  %t496 = load i64, ptr %l193
  %t497 = inttoptr i64 %t496 to ptr
  %t498 = insertvalue { i64, ptr } undef, i64 0, 0
  %t499 = insertvalue { i64, ptr } %t498, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t500 = load ptr, ptr %l192, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v0, ptr %t500, { i64, ptr } %t499)
  br label %bb126
bb125:
  call void @__olang_check_failed(ptr @olang_loc_3fc20153d7ed10ca_2c74aea1b5acbce6)
  unreachable
bb126:
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/free:Free", ptr %t502, i32 0, i32 156
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t504, i1 false)
  br label %bb127
bb127:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load i64, ptr %l1, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %t506, i64 %t507)
  br label %bb128
bb128:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l11 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t20 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i64 %t20, ptr %l11
  br label %bb6
bb6:
  %t21 = load i64, ptr %l11, !tbaa !24
  %t22 = icmp slt i64 %t21, 0
  br i1 %t22, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l2, !tbaa !23
  %t28 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s2, ptr %t24, i32 %t25)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %l15
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4cef24e7d17769b7_e2744f91577a9953)
  unreachable
bb16:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eclausesTake(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/typed:Item"
  %l13 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l41 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l13, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Spawn", ptr %a1, i32 0, i32 2
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l6, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb25
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t22, ptr %l22, !tbaa !27
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l7, !tbaa !29
  %t30 = load ptr, ptr %l7, !tbaa !29
  %t32 = getelementptr %"compiler/typed:TaskClause", ptr %t30, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l7, !tbaa !29
  %t38 = getelementptr %"compiler/typed:TaskClause", ptr %t36, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  store { i64, ptr } %t39, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l10, !tbaa !24
  br label %bb9
bb9:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l10, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb10, label %bb11
bb10:
  br label %bb23
bb11:
  br label %bb12
bb12:
  %t53 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t53, ptr %l36, !tbaa !27
  %t54 = load i64, ptr %l9, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr %"compiler/typed:Item", ptr %t57, i64 %t54
  %t59 = load %"compiler/typed:Item", ptr %t58
  store %"compiler/typed:Item" %t59, ptr %l11
  %t61 = getelementptr %"compiler/typed:Item", ptr %l11, i32 0, i32 1
  %t62 = load i64, ptr %t61, !tbaa !24
  %t64 = icmp slt i64 %t62, 0
  br i1 %t64, label %bb13, label %bb14
bb13:
  %t66 = load ptr, ptr %l3, !tbaa !29
  store ptr %t66, ptr %l42, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t68 = getelementptr %"compiler/typed:Item", ptr %l11, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t67, i32 %t69)
  store i32 %t72, ptr %l45
  br label %bb15
bb14:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb18
bb15:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t77 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t73, i32 %a2)
  store i32 %t77, ptr %l48
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l42, !tbaa !29
  %t79 = load i32, ptr %l45, !tbaa !23
  %t80 = load i32, ptr %l48, !tbaa !23
  %t81 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t78, i32 %t79, i32 %t80)
  store i1 %t81, ptr %l49
  br label %bb17
bb17:
  %t82 = load i1, ptr %l49, !tbaa !21
  store i1 %t82, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t83 = load i1, ptr %l41, !tbaa !21
  br i1 %t83, label %bb19, label %bb20
bb19:
  store i1 true, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  br label %bb22
bb22:
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t85, 1
  store i64 %t88, ptr %l9, !tbaa !24
  br label %bb9
bb23:
  br label %bb24
bb24:
  %t90 = load i64, ptr %l5, !tbaa !24
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %l5, !tbaa !24
  br label %bb2
bb25:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecopiedRet(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i64
  %l9 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/free:Free", ptr %t6, i32 0, i32 1
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l9
  br label %bb3
bb3:
  %t11 = load i64, ptr %l6, !tbaa !24
  %t12 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l5, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l5, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:Free", ptr %t17, i32 0, i32 152
  %t20 = load i64, ptr %l1, !tbaa !24
  %t23 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t19, i64 %t20)
  store i1 %t23, ptr %l15
  br label %bb8
bb8:
  %t24 = load i1, ptr %l15, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:Free", ptr %t25, i32 0, i32 152
  %t28 = load i64, ptr %l1, !tbaa !24
  %t31 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %t27, i64 %t28)
  %t32 = extractvalue { i32, i1 } %t31, 1
  %t33 = extractvalue { i32, i1 } %t31, 0
  store i32 %t33, ptr %l21
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb12, label %ok.35, !prof !99
ok.35:
  store i1 %t32, ptr %l20
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t36 = load i1, ptr %l20, !tbaa !21
  store i1 %t36, ptr %l16, !tbaa !21
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l16, !tbaa !21
  store i1 %t37, ptr %rv
  br label %ret
bb15:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  %t42 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eretCopies(ptr %v0, ptr %t38, i64 %t39)
  store i1 %t42, ptr %l24
  br label %bb16
bb16:
  %t43 = load i1, ptr %l24, !tbaa !21
  store i1 %t43, ptr %l2, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 152
  %t47 = load i64, ptr %l1, !tbaa !24
  %t48 = load i1, ptr %l2, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t46, i64 %t47, i1 %t48)
  br label %bb17
bb17:
  %t52 = load i1, ptr %l2, !tbaa !21
  store i1 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edecide(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/free:letGo"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca %"compiler/free:store"
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca %"compiler/free:orStore"
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca %"compiler/free:orCall"
  %l30 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca %"compiler/free:feedCall"
  %l33 = alloca %"compiler/free:feed"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca %"compiler/free:store"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca ptr
  %l39 = alloca i64
  %l41 = alloca %"compiler/free:store"
  %l42 = alloca i64
  %l43 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca %"compiler/free:store"
  %l72 = alloca i64
  %l77 = alloca i64
  %l80 = alloca i64
  %l103 = alloca i64
  %l108 = alloca i64
  %l110 = alloca i64
  %l115 = alloca %"compiler/free:letGo"
  %l119 = alloca i1
  %l122 = alloca i1
  %l126 = alloca i1
  %l130 = alloca i1
  %l131 = alloca i1
  %l134 = alloca i1
  %l143 = alloca i64
  %l145 = alloca i64
  %l150 = alloca i64
  %l160 = alloca i64
  %l163 = alloca i64
  %l183 = alloca i1
  %l187 = alloca i1
  %l188 = alloca ptr
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca %"compiler/source:Span"
  %l197 = alloca i64
  %l199 = alloca i64
  %l204 = alloca %"compiler/free:store"
  %l208 = alloca i1
  %l212 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l219 = alloca i1
  %l230 = alloca i64
  %l232 = alloca i64
  %l237 = alloca %"compiler/free:orStore"
  %l241 = alloca i1
  %l243 = alloca i1
  %l246 = alloca i1
  %l247 = alloca ptr
  %l248 = alloca i64
  %l249 = alloca i64
  %l250 = alloca %"compiler/source:Span"
  %l256 = alloca i64
  %l258 = alloca i64
  %l263 = alloca %"compiler/free:orCall"
  %l267 = alloca i1
  %l269 = alloca i1
  %l273 = alloca ptr
  %l277 = alloca i1
  %l281 = alloca i1
  %l282 = alloca ptr
  %l283 = alloca i64
  %l284 = alloca i64
  %l285 = alloca %"compiler/source:Span"
  %l291 = alloca i64
  %l293 = alloca i64
  %l298 = alloca %"compiler/free:feedCall"
  %l301 = alloca i1
  %l306 = alloca %"compiler/free:feed"
  %l307 = alloca ptr
  %l308 = alloca i64
  %l309 = alloca i64
  %l313 = alloca ptr
  %l315 = alloca i64
  %l319 = alloca ptr
  %l323 = alloca %"compiler/typed:Local"
  %l324 = alloca %"compiler/source:Span"
  %l325 = alloca i64
  %l330 = alloca ptr
  %l334 = alloca ptr
  %l338 = alloca %"compiler/typed:Local"
  %l340 = alloca { i64, ptr }
  %l348 = alloca i64
  %l350 = alloca i64
  %l355 = alloca %"compiler/free:store"
  %l359 = alloca i1
  %l362 = alloca i1
  %l364 = alloca i1
  %l365 = alloca ptr
  %l369 = alloca i64
  %l379 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l381 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l383 = alloca i64
  %l385 = alloca i64
  %l390 = alloca i64
  %l394 = alloca %"compiler/free:store"
  %l398 = alloca i1
  %l402 = alloca i1
  %l403 = alloca i1
  %l406 = alloca i1
  %l408 = alloca ptr
  %l412 = alloca i64
  %l415 = alloca i1
  %l416 = alloca ptr
  %l417 = alloca i64
  %l421 = alloca { i64, [2 x i64] }
  %l424 = alloca i1
  %l425 = alloca ptr
  %l426 = alloca i64
  %l430 = alloca { i64, [2 x i64] }
  %l435 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l436 = alloca i64
  %l439 = alloca i64
  %l440 = alloca i32
  %l461 = alloca i64
  %l464 = alloca i64
  %l485 = alloca i1
  %l486 = alloca ptr
  %l487 = alloca i64
  %l488 = alloca i64
  %l489 = alloca %"compiler/source:Span"
  %l497 = alloca i64
  %l500 = alloca i64
  %l519 = alloca ptr
  %l520 = alloca i64
  %l523 = alloca i1
  %l527 = alloca i64
  %l537 = alloca i64
  %l540 = alloca i64
  %l561 = alloca i1
  %l563 = alloca i1
  %l567 = alloca i1
  %l569 = alloca ptr
  %l573 = alloca i32
  %l574 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l576 = alloca i64
  %l578 = alloca i64
  %l583 = alloca i64
  %l587 = alloca i1
  %l588 = alloca i1
  %l592 = alloca i1
  %l593 = alloca i1
  %l596 = alloca i1
  %l598 = alloca i1
  %l601 = alloca i1
  %l602 = alloca i1
  %l603 = alloca ptr
  %l607 = alloca i32
  %l609 = alloca i1
  %l615 = alloca ptr
  %l616 = alloca i64
  %l617 = alloca i64
  %l618 = alloca %"compiler/source:Span"
  %l622 = alloca i64
  %l631 = alloca i64
  %l633 = alloca i64
  %l638 = alloca %"compiler/free:store"
  %l642 = alloca i1
  %l646 = alloca i1
  %l647 = alloca i1
  %l651 = alloca i1
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %s46 = alloca %olang.scope
  %s54 = alloca %olang.scope
  %s56 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 9
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l72
  br label %bb1
bb1:
  %t6 = load i64, ptr %l72, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  store i64 0, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l80, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l80, !tbaa !24
  store i64 %t35, ptr %l77, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l77, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 109
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t57, i1 false)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t62 = add i64 %t59, 1
  store i64 %t62, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t64 = load i64, ptr %l1, !tbaa !24
  store i64 %t64, ptr %l103, !tbaa !24
  %t65 = load i64, ptr %l103, !tbaa !24
  %t66 = icmp sge i64 %t65, 0
  br i1 %t66, label %bb15, label %bb16
bb15:
  %t68 = load i64, ptr %l103, !tbaa !24
  %t69 = mul i64 %t68, 1
  %t70 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t69)
  %t71 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l8, !tbaa !27
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 102
  store ptr %t76, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_77e2c420ac7907a9_804235f2ad53d)
  unreachable
bb17:
  %t78 = load i64, ptr %l10, !tbaa !24
  store i64 %t78, ptr %l108, !tbaa !24
  %t79 = load ptr, ptr %l9, !tbaa !29
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t79)
  store i64 %t81, ptr %l110
  br label %bb18
bb18:
  %t82 = load i64, ptr %l108, !tbaa !24
  %t83 = load i64, ptr %l110, !tbaa !24
  %t84 = icmp slt i64 %t82, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb19, label %bb20
bb19:
  br label %bb41
bb20:
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l9, !tbaa !29
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = call %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %t88, i64 %t89)
  store %"compiler/free:letGo" %t92, ptr %l115
  br label %bb22
bb22:
  %t93 = load %"compiler/free:letGo", ptr %l115
  store %"compiler/free:letGo" %t93, ptr %l11
  %t94 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 5
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  %t99 = icmp ne i64 %t95, %t96
  br i1 %t99, label %bb23, label %bb24
bb23:
  %t101 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 0
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = icmp sge i64 %t102, 0
  store i1 %t104, ptr %l119, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb25
bb25:
  %t106 = load i1, ptr %l119, !tbaa !21
  br i1 %t106, label %bb26, label %bb27
bb26:
  %t107 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 5
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load i64, ptr @G_2ecompiler_2ffree_2eLLeaf, !tbaa !24
  %t112 = icmp eq i64 %t108, %t109
  br i1 %t112, label %bb28, label %bb29
bb27:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb36
bb28:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/free:Free", ptr %t114, i32 0, i32 68
  %t117 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 1
  %t118 = load i64, ptr %t117, !tbaa !24
  %t121 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t116, i64 %t118)
  store i1 %t121, ptr %l130
  br label %bb30
bb29:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb31
bb30:
  %t122 = load i1, ptr %l130, !tbaa !21
  store i1 %t122, ptr %l126, !tbaa !21
  br label %bb31
bb31:
  %t123 = load i1, ptr %l126, !tbaa !21
  br i1 %t123, label %bb32, label %bb33
bb32:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 0
  %t126 = load i64, ptr %t125, !tbaa !24
  %t129 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t124, i64 %t126)
  store i1 %t129, ptr %l134
  br label %bb34
bb33:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb35
bb34:
  %t130 = load i1, ptr %l134, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l131, !tbaa !21
  br label %bb35
bb35:
  %t133 = load i1, ptr %l131, !tbaa !21
  %t134 = xor i1 %t133, true
  store i1 %t134, ptr %l122, !tbaa !21
  br label %bb36
bb36:
  %t136 = load i1, ptr %l122, !tbaa !21
  br i1 %t136, label %bb37, label %bb38
bb37:
  %t137 = getelementptr %"compiler/free:letGo", ptr %l11, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t140 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr i1, ptr %t141, i64 %t138
  store i1 true, ptr %t142, !tbaa !31
  br label %bb39
bb38:
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t143 = load i64, ptr %l10, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l10, !tbaa !24
  br label %bb17
bb41:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/free:Free", ptr %t148, i32 0, i32 80
  store ptr %t150, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb42
bb42:
  %t152 = load i64, ptr %l13, !tbaa !24
  store i64 %t152, ptr %l143, !tbaa !24
  %t153 = load ptr, ptr %l12, !tbaa !29
  %t155 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t153)
  store i64 %t155, ptr %l145
  br label %bb43
bb43:
  %t156 = load i64, ptr %l143, !tbaa !24
  %t157 = load i64, ptr %l145, !tbaa !24
  %t158 = icmp slt i64 %t156, %t157
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb44, label %bb45
bb44:
  br label %bb49
bb45:
  br label %bb46
bb46:
  %t162 = load ptr, ptr %l12, !tbaa !29
  %t163 = load i64, ptr %l13, !tbaa !24
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t162, i64 %t163)
  store i64 %t166, ptr %l150
  br label %bb47
bb47:
  %t167 = load i64, ptr %l150, !tbaa !24
  %t170 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !27
  %t172 = getelementptr i1, ptr %t171, i64 %t167
  store i1 true, ptr %t172, !tbaa !31
  br label %bb48
bb48:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t176 = add i64 %t173, 1
  store i64 %t176, ptr %l13, !tbaa !24
  br label %bb42
bb49:
  %t178 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2etaskKeeps(ptr %v0, ptr %t178)
  br label %bb50
bb50:
  store i64 0, ptr %l15, !tbaa !24
  %t180 = load i64, ptr %l1, !tbaa !24
  store i64 %t180, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t182 = load i64, ptr %l16, !tbaa !24
  %t183 = load i64, ptr %l15, !tbaa !24
  %t186 = icmp sgt i64 %t182, %t183
  br i1 %t186, label %bb51, label %bb52
bb51:
  %t188 = load i64, ptr %l17, !tbaa !24
  %t190 = icmp sgt i64 %t188, 0
  br i1 %t190, label %bb53, label %bb54
bb52:
  store i64 0, ptr %l160, !tbaa !24
  br label %bb56
bb53:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t193 = load i64, ptr %l15, !tbaa !24
  %t196 = sub i64 %t192, %t193
  %t197 = load i64, ptr %l17, !tbaa !24
  %t200 = add i64 %t196, %t197
  %t202 = sub i64 %t200, 1
  %t203 = load i64, ptr %l17, !tbaa !24
  %t206 = sdiv i64 %t202, %t203
  store i64 %t206, ptr %l163, !tbaa !24
  br label %bb55
bb54:
  store i64 0, ptr %l163, !tbaa !24
  br label %bb55
bb55:
  %t208 = load i64, ptr %l163, !tbaa !24
  store i64 %t208, ptr %l160, !tbaa !24
  br label %bb56
bb56:
  %t209 = load i64, ptr %l160, !tbaa !24
  store i64 %t209, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb57
bb57:
  %t210 = load i64, ptr %l19, !tbaa !24
  %t211 = load i64, ptr %l18, !tbaa !24
  %t214 = icmp slt i64 %t210, %t211
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb58, label %bb59
bb58:
  br label %bb71
bb59:
  br label %bb60
bb60:
  %t218 = load i64, ptr %l15, !tbaa !24
  %t219 = load i64, ptr %l19, !tbaa !24
  %t220 = load i64, ptr %l17, !tbaa !24
  %t223 = mul i64 %t219, %t220
  %t226 = add i64 %t218, %t223
  store i64 %t226, ptr %l20, !tbaa !24
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/free:Free", ptr %t228, i32 0, i32 99
  %t231 = load i1, ptr %t230, !tbaa !21
  br i1 %t231, label %bb61, label %bb62
bb61:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb64
bb62:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/free:Free", ptr %t233, i32 0, i32 100
  %t236 = load i64, ptr %l20, !tbaa !24
  %t239 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t235, i64 %t236)
  store i1 %t239, ptr %l187
  br label %bb63
bb63:
  %t240 = load i1, ptr %l187, !tbaa !21
  store i1 %t240, ptr %l183, !tbaa !21
  br label %bb64
bb64:
  %t241 = load i1, ptr %l183, !tbaa !21
  br i1 %t241, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s13
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l188, !tbaa !29
  %t243 = load i64, ptr %l20, !tbaa !24
  store i64 %t243, ptr %l189, !tbaa !24
  %t244 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t244, ptr %l190, !tbaa !24
  %t245 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s13, i32 0, i32 0)
  store %"compiler/source:Span" %t245, ptr %l191
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t246 = load ptr, ptr %l188, !tbaa !29
  %t247 = load i64, ptr %l189, !tbaa !24
  %t248 = load i64, ptr %l190, !tbaa !24
  %t249 = load %"compiler/source:Span", ptr %l191
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t246, i64 %t247, i64 %t248, i64 -1, %"compiler/source:Span" %t249, { i64, ptr } { i64 68, ptr getelementptr inbounds (<{ i64, [68 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s13)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t250 = load i64, ptr %l19, !tbaa !24
  %t253 = add i64 %t250, 1
  store i64 %t253, ptr %l19, !tbaa !24
  br label %bb57
bb71:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = getelementptr %"compiler/free:Free", ptr %t255, i32 0, i32 101
  store ptr %t257, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb72
bb72:
  %t259 = load i64, ptr %l22, !tbaa !24
  store i64 %t259, ptr %l197, !tbaa !24
  %t260 = load ptr, ptr %l21, !tbaa !29
  %t262 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t260)
  store i64 %t262, ptr %l199
  br label %bb73
bb73:
  %t263 = load i64, ptr %l197, !tbaa !24
  %t264 = load i64, ptr %l199, !tbaa !24
  %t265 = icmp slt i64 %t263, %t264
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb74, label %bb75
bb74:
  br label %bb94
bb75:
  br label %bb76
bb76:
  %t269 = load ptr, ptr %l21, !tbaa !29
  %t270 = load i64, ptr %l22, !tbaa !24
  %t273 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t269, i64 %t270)
  store %"compiler/free:store" %t273, ptr %l204
  br label %bb77
bb77:
  %t274 = load %"compiler/free:store", ptr %l204
  store %"compiler/free:store" %t274, ptr %l23
  %t275 = getelementptr %"compiler/free:store", ptr %l23, i32 0, i32 4
  %t276 = load i64, ptr %t275, !tbaa !24
  %t277 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t280 = icmp eq i64 %t276, %t277
  br i1 %t280, label %bb78, label %bb79
bb78:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/free:Free", ptr %t282, i32 0, i32 177
  %t285 = getelementptr %"compiler/free:store", ptr %l23, i32 0, i32 0
  %t286 = load i64, ptr %t285, !tbaa !24
  %t289 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t284, i64 %t286)
  store i1 %t289, ptr %l212
  br label %bb80
bb79:
  store i1 false, ptr %l208, !tbaa !21
  br label %bb81
bb80:
  %t290 = load i1, ptr %l212, !tbaa !21
  %t291 = xor i1 %t290, true
  store i1 %t291, ptr %l208, !tbaa !21
  br label %bb81
bb81:
  %t293 = load i1, ptr %l208, !tbaa !21
  br i1 %t293, label %bb82, label %bb83
bb82:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l215, !tbaa !29
  %t295 = getelementptr %"compiler/free:store", ptr %l23, i32 0, i32 7
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = icmp eq ptr %t296, null
  br i1 %t298, label %bb84, label %bb85
bb83:
  store i1 false, ptr %l214, !tbaa !21
  br label %bb88
bb84:
  call void @__olang_check_failed(ptr @olang_loc_834ee64634399a9c_46784e5d37862958)
  unreachable
bb85:
  br label %bb86
bb86:
  %t300 = getelementptr %"compiler/free:store", ptr %l23, i32 0, i32 7
  %t301 = load ptr, ptr %t300, !tbaa !29
  %t302 = load ptr, ptr %l215, !tbaa !29
  %t304 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t302, ptr %t301)
  store i1 %t304, ptr %l219
  br label %bb87
bb87:
  %t305 = load i1, ptr %l219, !tbaa !21
  store i1 %t305, ptr %l214, !tbaa !21
  br label %bb88
bb88:
  %t306 = load i1, ptr %l214, !tbaa !21
  br i1 %t306, label %bb89, label %bb90
bb89:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/free:store", ptr %l23, i32 0, i32 0
  %t309 = load i64, ptr %t308, !tbaa !24
  %t310 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  %t311 = getelementptr %"compiler/free:store", ptr %l23, i32 0, i32 2
  %t312 = load i64, ptr %t311, !tbaa !24
  %t313 = getelementptr %"compiler/free:store", ptr %l23, i32 0, i32 3
  %t314 = load %"compiler/source:Span", ptr %t313
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t307, i64 %t309, i64 %t310, i64 %t312, %"compiler/source:Span" %t314, { i64, ptr } { i64 144, ptr getelementptr inbounds (<{ i64, [144 x i8] }>, ptr @.d1, i32 0, i32 1) })
  br label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb92
bb92:
  br label %bb93
bb93:
  %t320 = load i64, ptr %l22, !tbaa !24
  %t323 = add i64 %t320, 1
  store i64 %t323, ptr %l22, !tbaa !24
  br label %bb72
bb94:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"compiler/free:Free", ptr %t325, i32 0, i32 108
  store ptr %t327, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb95
bb95:
  %t329 = load i64, ptr %l25, !tbaa !24
  store i64 %t329, ptr %l230, !tbaa !24
  %t330 = load ptr, ptr %l24, !tbaa !29
  %t332 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %t330)
  store i64 %t332, ptr %l232
  br label %bb96
bb96:
  %t333 = load i64, ptr %l230, !tbaa !24
  %t334 = load i64, ptr %l232, !tbaa !24
  %t335 = icmp slt i64 %t333, %t334
  %t337 = xor i1 %t335, true
  br i1 %t337, label %bb97, label %bb98
bb97:
  br label %bb112
bb98:
  br label %bb99
bb99:
  %t339 = load ptr, ptr %l24, !tbaa !29
  %t340 = load i64, ptr %l25, !tbaa !24
  %t343 = call %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v0, ptr %t339, i64 %t340)
  store %"compiler/free:orStore" %t343, ptr %l237
  br label %bb100
bb100:
  %t344 = load %"compiler/free:orStore", ptr %l237
  store %"compiler/free:orStore" %t344, ptr %l26
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/free:Free", ptr %t345, i32 0, i32 177
  %t348 = getelementptr %"compiler/free:orStore", ptr %l26, i32 0, i32 1
  %t349 = load i64, ptr %t348, !tbaa !24
  %t352 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t347, i64 %t349)
  store i1 %t352, ptr %l241
  br label %bb101
bb101:
  %t353 = load i1, ptr %l241, !tbaa !21
  %t354 = xor i1 %t353, true
  br i1 %t354, label %bb102, label %bb103
bb102:
  %t356 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/free:orStore", ptr %l26, i32 0, i32 2
  %t358 = load ptr, ptr %t357, !tbaa !29
  %t361 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v0, ptr %t356, ptr %t358)
  store i1 %t361, ptr %l246
  br label %bb104
bb103:
  store i1 false, ptr %l243, !tbaa !21
  br label %bb105
bb104:
  %t362 = load i1, ptr %l246, !tbaa !21
  store i1 %t362, ptr %l243, !tbaa !21
  br label %bb105
bb105:
  %t363 = load i1, ptr %l243, !tbaa !21
  br i1 %t363, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s21
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l247, !tbaa !29
  %t365 = getelementptr %"compiler/free:orStore", ptr %l26, i32 0, i32 1
  %t366 = load i64, ptr %t365, !tbaa !24
  store i64 %t366, ptr %l248, !tbaa !24
  %t367 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t367, ptr %l249, !tbaa !24
  %t368 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s21, i32 0, i32 0)
  store %"compiler/source:Span" %t368, ptr %l250
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t369 = load ptr, ptr %l247, !tbaa !29
  %t370 = load i64, ptr %l248, !tbaa !24
  %t371 = load i64, ptr %l249, !tbaa !24
  %t372 = load %"compiler/source:Span", ptr %l250
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t369, i64 %t370, i64 %t371, i64 -1, %"compiler/source:Span" %t372, { i64, ptr } { i64 92, ptr getelementptr inbounds (<{ i64, [92 x i8] }>, ptr @.d2, i32 0, i32 1) })
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s21)
  br label %bb110
bb110:
  br label %bb111
bb111:
  %t373 = load i64, ptr %l25, !tbaa !24
  %t376 = add i64 %t373, 1
  store i64 %t376, ptr %l25, !tbaa !24
  br label %bb95
bb112:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/free:Free", ptr %t378, i32 0, i32 107
  store ptr %t380, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb113
bb113:
  %t382 = load i64, ptr %l28, !tbaa !24
  store i64 %t382, ptr %l256, !tbaa !24
  %t383 = load ptr, ptr %l27, !tbaa !29
  %t385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %t383)
  store i64 %t385, ptr %l258
  br label %bb114
bb114:
  %t386 = load i64, ptr %l256, !tbaa !24
  %t387 = load i64, ptr %l258, !tbaa !24
  %t388 = icmp slt i64 %t386, %t387
  %t390 = xor i1 %t388, true
  br i1 %t390, label %bb115, label %bb116
bb115:
  br label %bb134
bb116:
  br label %bb117
bb117:
  %t392 = load ptr, ptr %l27, !tbaa !29
  %t393 = load i64, ptr %l28, !tbaa !24
  %t396 = call %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v0, ptr %t392, i64 %t393)
  store %"compiler/free:orCall" %t396, ptr %l263
  br label %bb118
bb118:
  %t397 = load %"compiler/free:orCall", ptr %l263
  store %"compiler/free:orCall" %t397, ptr %l29
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t400 = getelementptr %"compiler/free:Free", ptr %t398, i32 0, i32 177
  %t401 = getelementptr %"compiler/free:orCall", ptr %l29, i32 0, i32 4
  %t402 = load i64, ptr %t401, !tbaa !24
  %t405 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t400, i64 %t402)
  store i1 %t405, ptr %l267
  br label %bb119
bb119:
  %t406 = load i1, ptr %l267, !tbaa !21
  %t407 = xor i1 %t406, true
  br i1 %t407, label %bb120, label %bb121
bb120:
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/free:Free", ptr %t409, i32 0, i32 1
  %t412 = getelementptr %"compiler/free:orCall", ptr %l29, i32 0, i32 2
  %t413 = load i64, ptr %t412, !tbaa !24
  %t416 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t411, i64 %t413)
  store ptr %t416, ptr %l273
  br label %bb122
bb121:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb127
bb122:
  %t417 = load ptr, ptr %l273, !tbaa !29
  %t419 = getelementptr %"compiler/typed:Body", ptr %t417, i32 0, i32 11
  %t420 = load ptr, ptr %t419, !tbaa !29
  %t422 = icmp eq ptr %t420, null
  br i1 %t422, label %bb123, label %bb124
bb123:
  store i1 true, ptr %l277, !tbaa !21
  br label %bb126
bb124:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/free:Free", ptr %t424, i32 0, i32 93
  %t427 = getelementptr %"compiler/free:orCall", ptr %l29, i32 0, i32 2
  %t428 = load i64, ptr %t427, !tbaa !24
  %t431 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t426, i64 %t428)
  store i1 %t431, ptr %l281
  br label %bb125
bb125:
  %t432 = load i1, ptr %l281, !tbaa !21
  store i1 %t432, ptr %l277, !tbaa !21
  br label %bb126
bb126:
  %t433 = load i1, ptr %l277, !tbaa !21
  store i1 %t433, ptr %l269, !tbaa !21
  br label %bb127
bb127:
  %t434 = load i1, ptr %l269, !tbaa !21
  br i1 %t434, label %bb128, label %bb129
bb128:
  store %olang.scope zeroinitializer, ptr %s25
  %t435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t435, ptr %l282, !tbaa !29
  %t436 = getelementptr %"compiler/free:orCall", ptr %l29, i32 0, i32 4
  %t437 = load i64, ptr %t436, !tbaa !24
  store i64 %t437, ptr %l283, !tbaa !24
  %t438 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t438, ptr %l284, !tbaa !24
  %t439 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s25, i32 0, i32 0)
  store %"compiler/source:Span" %t439, ptr %l285
  br label %bb130
bb129:
  br label %bb132
bb130:
  %t440 = load ptr, ptr %l282, !tbaa !29
  %t441 = load i64, ptr %l283, !tbaa !24
  %t442 = load i64, ptr %l284, !tbaa !24
  %t443 = load %"compiler/source:Span", ptr %l285
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t440, i64 %t441, i64 %t442, i64 -1, %"compiler/source:Span" %t443, { i64, ptr } { i64 98, ptr getelementptr inbounds (<{ i64, [98 x i8] }>, ptr @.d3, i32 0, i32 1) })
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s25)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t444 = load i64, ptr %l28, !tbaa !24
  %t447 = add i64 %t444, 1
  store i64 %t447, ptr %l28, !tbaa !24
  br label %bb113
bb134:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/free:Free", ptr %t449, i32 0, i32 176
  store ptr %t451, ptr %l30, !tbaa !29
  store i64 0, ptr %l31, !tbaa !24
  br label %bb135
bb135:
  %t453 = load i64, ptr %l31, !tbaa !24
  store i64 %t453, ptr %l291, !tbaa !24
  %t454 = load ptr, ptr %l30, !tbaa !29
  %t456 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eLen_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t454)
  store i64 %t456, ptr %l293
  br label %bb136
bb136:
  %t457 = load i64, ptr %l291, !tbaa !24
  %t458 = load i64, ptr %l293, !tbaa !24
  %t459 = icmp slt i64 %t457, %t458
  %t461 = xor i1 %t459, true
  br i1 %t461, label %bb137, label %bb138
bb137:
  br label %bb156
bb138:
  br label %bb139
bb139:
  %t463 = load ptr, ptr %l30, !tbaa !29
  %t464 = load i64, ptr %l31, !tbaa !24
  %t467 = call %"compiler/free:feedCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eAt_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %t463, i64 %t464)
  store %"compiler/free:feedCall" %t467, ptr %l298
  br label %bb140
bb140:
  %t468 = load %"compiler/free:feedCall", ptr %l298
  store %"compiler/free:feedCall" %t468, ptr %l32
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t470 = load %"compiler/free:feedCall", ptr %l32
  %t473 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedFits(ptr %v0, ptr %t469, %"compiler/free:feedCall" %t470)
  store i1 %t473, ptr %l301
  br label %bb141
bb141:
  %t474 = load i1, ptr %l301, !tbaa !21
  %t475 = xor i1 %t474, true
  br i1 %t475, label %bb142, label %bb143
bb142:
  store %olang.scope zeroinitializer, ptr %s29
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/free:Free", ptr %t477, i32 0, i32 174
  %t480 = getelementptr %"compiler/free:feedCall", ptr %l32, i32 0, i32 4
  %t481 = load i64, ptr %t480, !tbaa !24
  %t484 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t479, i64 %t481)
  store %"compiler/free:feed" %t484, ptr %l306
  br label %bb144
bb143:
  br label %bb154
bb144:
  %t485 = load %"compiler/free:feed", ptr %l306
  store %"compiler/free:feed" %t485, ptr %l33
  %t486 = load ptr, ptr %l0, !tbaa !29
  store ptr %t486, ptr %l307, !tbaa !29
  %t487 = getelementptr %"compiler/free:feed", ptr %l33, i32 0, i32 2
  %t488 = load i64, ptr %t487, !tbaa !24
  store i64 %t488, ptr %l308, !tbaa !24
  %t489 = load i64, ptr @G_2ecompiler_2ffree_2eRInPlace, !tbaa !24
  store i64 %t489, ptr %l309, !tbaa !24
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/free:Free", ptr %t490, i32 0, i32 1
  %t493 = getelementptr %"compiler/free:feedCall", ptr %l32, i32 0, i32 0
  %t494 = load i64, ptr %t493, !tbaa !24
  %t497 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t492, i64 %t494)
  store ptr %t497, ptr %l313
  br label %bb145
bb145:
  %t498 = load ptr, ptr %l313, !tbaa !29
  %t500 = getelementptr %"compiler/typed:Body", ptr %t498, i32 0, i32 3
  %t501 = load i64, ptr %t500, !tbaa !24
  store i64 %t501, ptr %l315, !tbaa !24
  %t502 = load ptr, ptr %l0, !tbaa !29
  %t504 = getelementptr %"compiler/free:Free", ptr %t502, i32 0, i32 1
  %t505 = getelementptr %"compiler/free:feedCall", ptr %l32, i32 0, i32 0
  %t506 = load i64, ptr %t505, !tbaa !24
  %t509 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t504, i64 %t506)
  store ptr %t509, ptr %l319
  br label %bb146
bb146:
  %t510 = load ptr, ptr %l319, !tbaa !29
  %t512 = getelementptr %"compiler/typed:Body", ptr %t510, i32 0, i32 7
  %t513 = getelementptr %"compiler/free:feed", ptr %l33, i32 0, i32 1
  %t514 = load i64, ptr %t513, !tbaa !24
  %t517 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t512, i64 %t514)
  store %"compiler/typed:Local" %t517, ptr %l323
  br label %bb147
bb147:
  %t518 = getelementptr %"compiler/typed:Local", ptr %l323, i32 0, i32 1
  %t519 = load %"compiler/source:Span", ptr %t518
  store %"compiler/source:Span" %t519, ptr %l324
  %t520 = call ptr @__olang_scope_hold(ptr %v0)
  %t521 = ptrtoint ptr %t520 to i64
  store i64 %t521, ptr %l325, !tbaa !24
  %t522 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t522, label %bb148, label %bb149
bb148:
  %t524 = call ptr @__olang_region_make(ptr %v0)
  %t525 = ptrtoint ptr %t524 to i64
  store i64 %t525, ptr %l325, !tbaa !24
  br label %bb149
bb149:
  %t526 = load ptr, ptr %l0, !tbaa !29
  %t528 = getelementptr %"compiler/free:Free", ptr %t526, i32 0, i32 0
  %t529 = load ptr, ptr %t528, !tbaa !29
  %t531 = getelementptr %"compiler/generic:Program", ptr %t529, i32 0, i32 0
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t534 = getelementptr %"compiler/load:Loader", ptr %t532, i32 0, i32 3
  %t535 = load ptr, ptr %t534, !tbaa !29
  store ptr %t535, ptr %l330, !tbaa !29
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t538 = getelementptr %"compiler/free:Free", ptr %t536, i32 0, i32 1
  %t539 = getelementptr %"compiler/free:feedCall", ptr %l32, i32 0, i32 0
  %t540 = load i64, ptr %t539, !tbaa !24
  %t543 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t538, i64 %t540)
  store ptr %t543, ptr %l334
  br label %bb150
bb150:
  %t544 = load ptr, ptr %l334, !tbaa !29
  %t546 = getelementptr %"compiler/typed:Body", ptr %t544, i32 0, i32 7
  %t547 = getelementptr %"compiler/free:feed", ptr %l33, i32 0, i32 1
  %t548 = load i64, ptr %t547, !tbaa !24
  %t551 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t546, i64 %t548)
  store %"compiler/typed:Local" %t551, ptr %l338
  br label %bb151
bb151:
  %t552 = getelementptr %"compiler/typed:Local", ptr %l338, i32 0, i32 0
  %t553 = load i32, ptr %t552, !tbaa !23
  %t554 = load ptr, ptr %l330, !tbaa !29
  %t556 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s29, ptr %t554, i32 %t553)
  store { i64, ptr } %t556, ptr %l340
  br label %bb152
bb152:
  %t557 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t558 = extractvalue { i64, ptr } { i64 74, ptr getelementptr inbounds (<{ i64, [74 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t559 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t560 = extractvalue { i64, ptr } %t559, 1
  %t561 = extractvalue { i64, ptr } %t559, 0
  %t562 = add i64 %t558, %t561
  %t563 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t564 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t565 = add i64 %t562, %t564
  %t566 = load i64, ptr %l325
  %t567 = inttoptr i64 %t566 to ptr
  %t568 = call ptr @__olang_held_alloc(ptr %t567, i64 %t565)
  call void @olang_textcopy(ptr %t568, ptr %t557, i64 %t558)
  %t569 = getelementptr i8, ptr %t568, i64 %t558
  call void @olang_textcopy(ptr %t569, ptr %t560, i64 %t561)
  %t570 = getelementptr i8, ptr %t569, i64 %t561
  call void @olang_textcopy(ptr %t570, ptr %t563, i64 %t564)
  %t571 = insertvalue { i64, ptr } undef, i64 %t565, 0
  %t572 = insertvalue { i64, ptr } %t571, ptr %t568, 1
  %t574 = load ptr, ptr %l307, !tbaa !29
  %t575 = load i64, ptr %l308, !tbaa !24
  %t576 = load i64, ptr %l309, !tbaa !24
  %t577 = load i64, ptr %l315, !tbaa !24
  %t578 = load %"compiler/source:Span", ptr %l324
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t574, i64 %t575, i64 %t576, i64 %t577, %"compiler/source:Span" %t578, { i64, ptr } %t572)
  br label %bb153
bb153:
  call void @__olang_scope_close(ptr %s29)
  br label %bb154
bb154:
  br label %bb155
bb155:
  %t580 = load i64, ptr %l31, !tbaa !24
  %t583 = add i64 %t580, 1
  store i64 %t583, ptr %l31, !tbaa !24
  br label %bb135
bb156:
  %t585 = load ptr, ptr %l0, !tbaa !29
  %t587 = getelementptr %"compiler/free:Free", ptr %t585, i32 0, i32 101
  store ptr %t587, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb157
bb157:
  %t589 = load i64, ptr %l35, !tbaa !24
  store i64 %t589, ptr %l348, !tbaa !24
  %t590 = load ptr, ptr %l34, !tbaa !29
  %t592 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t590)
  store i64 %t592, ptr %l350
  br label %bb158
bb158:
  %t593 = load i64, ptr %l348, !tbaa !24
  %t594 = load i64, ptr %l350, !tbaa !24
  %t595 = icmp slt i64 %t593, %t594
  %t597 = xor i1 %t595, true
  br i1 %t597, label %bb159, label %bb160
bb159:
  br label %bb179
bb160:
  br label %bb161
bb161:
  %t599 = load ptr, ptr %l34, !tbaa !29
  %t600 = load i64, ptr %l35, !tbaa !24
  %t603 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t599, i64 %t600)
  store %"compiler/free:store" %t603, ptr %l355
  br label %bb162
bb162:
  %t604 = load %"compiler/free:store", ptr %l355
  store %"compiler/free:store" %t604, ptr %l36
  %t605 = getelementptr %"compiler/free:store", ptr %l36, i32 0, i32 4
  %t606 = load i64, ptr %t605, !tbaa !24
  %t607 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t610 = icmp eq i64 %t606, %t607
  br i1 %t610, label %bb163, label %bb164
bb163:
  %t612 = load ptr, ptr %l0, !tbaa !29
  %t613 = load %"compiler/free:store", ptr %l36
  %t616 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v0, ptr %t612, %"compiler/free:store" %t613)
  store i1 %t616, ptr %l362
  br label %bb165
bb164:
  store i1 false, ptr %l359, !tbaa !21
  br label %bb173
bb165:
  %t617 = load i1, ptr %l362, !tbaa !21
  %t618 = xor i1 %t617, true
  br i1 %t618, label %bb166, label %bb167
bb166:
  store i1 true, ptr %l364, !tbaa !21
  br label %bb172
bb167:
  %t620 = load ptr, ptr %l0, !tbaa !29
  store ptr %t620, ptr %l365, !tbaa !29
  %t621 = getelementptr %"compiler/free:store", ptr %l36, i32 0, i32 7
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t624 = icmp eq ptr %t622, null
  br i1 %t624, label %bb168, label %bb169
bb168:
  call void @__olang_check_failed(ptr @olang_loc_dcc3c6712d01991_ec14a6947a12b86d)
  unreachable
bb169:
  br label %bb170
bb170:
  %t626 = getelementptr %"compiler/free:store", ptr %l36, i32 0, i32 7
  %t627 = load ptr, ptr %t626, !tbaa !29
  %t628 = load ptr, ptr %l365, !tbaa !29
  %t630 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t628, ptr %t627)
  store i64 %t630, ptr %l369
  br label %bb171
bb171:
  %t631 = load i64, ptr %l369, !tbaa !24
  %t632 = icmp slt i64 %t631, 0
  store i1 %t632, ptr %l364, !tbaa !21
  br label %bb172
bb172:
  %t634 = load i1, ptr %l364, !tbaa !21
  store i1 %t634, ptr %l359, !tbaa !21
  br label %bb173
bb173:
  %t635 = load i1, ptr %l359, !tbaa !21
  br i1 %t635, label %bb174, label %bb175
bb174:
  %t636 = load ptr, ptr %l0, !tbaa !29
  %t637 = getelementptr %"compiler/free:store", ptr %l36, i32 0, i32 0
  %t638 = load i64, ptr %t637, !tbaa !24
  %t639 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t640 = getelementptr %"compiler/free:store", ptr %l36, i32 0, i32 2
  %t641 = load i64, ptr %t640, !tbaa !24
  %t642 = getelementptr %"compiler/free:store", ptr %l36, i32 0, i32 3
  %t643 = load %"compiler/source:Span", ptr %t642
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t636, i64 %t638, i64 %t639, i64 %t641, %"compiler/source:Span" %t643, { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d6, i32 0, i32 1) })
  br label %bb176
bb175:
  br label %bb177
bb176:
  br label %bb177
bb177:
  br label %bb178
bb178:
  %t649 = load i64, ptr %l35, !tbaa !24
  %t652 = add i64 %t649, 1
  store i64 %t652, ptr %l35, !tbaa !24
  br label %bb157
bb179:
  %t654 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t654, ptr %l379
  br label %bb180
bb180:
  %t655 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l379
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t655, ptr %l37
  store %olang.scope zeroinitializer, ptr %s36
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t658 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eouterFirst(ptr %v0, ptr %s36, ptr %t656)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t658, ptr %l381
  br label %bb181
bb181:
  %t659 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l381
  %t660 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t659, ptr %t660
  store ptr %t660, ptr %l38, !tbaa !29
  store i64 0, ptr %l39, !tbaa !24
  br label %bb182
bb182:
  store %olang.scope zeroinitializer, ptr %s37
  %t662 = load i64, ptr %l39, !tbaa !24
  store i64 %t662, ptr %l383, !tbaa !24
  %t663 = load ptr, ptr %l38, !tbaa !29
  %t665 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s36, ptr %t663)
  store i64 %t665, ptr %l385
  br label %bb183
bb183:
  %t666 = load i64, ptr %l383, !tbaa !24
  %t667 = load i64, ptr %l385, !tbaa !24
  %t668 = icmp slt i64 %t666, %t667
  %t670 = xor i1 %t668, true
  br i1 %t670, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s37)
  br label %bb235
bb185:
  br label %bb186
bb186:
  %t672 = load ptr, ptr %l38, !tbaa !29
  %t673 = load i64, ptr %l39, !tbaa !24
  %t676 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s36, ptr %t672, i64 %t673)
  store i64 %t676, ptr %l390
  br label %bb187
bb187:
  %t677 = load i64, ptr %l390, !tbaa !24
  %t678 = load ptr, ptr %l0, !tbaa !29
  %t680 = getelementptr %"compiler/free:Free", ptr %t678, i32 0, i32 101
  %t684 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t680, i64 %t677)
  store %"compiler/free:store" %t684, ptr %l394
  br label %bb188
bb188:
  %t685 = load %"compiler/free:store", ptr %l394
  store %"compiler/free:store" %t685, ptr %l41
  %t686 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 4
  %t687 = load i64, ptr %t686, !tbaa !24
  %t688 = load i64, ptr @G_2ecompiler_2ffree_2eSFresh, !tbaa !24
  %t691 = icmp ne i64 %t687, %t688
  br i1 %t691, label %bb189, label %bb190
bb189:
  store i1 true, ptr %l398, !tbaa !21
  br label %bb192
bb190:
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t695 = getelementptr %"compiler/free:Free", ptr %t693, i32 0, i32 29
  %t696 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 1
  %t697 = load i64, ptr %t696, !tbaa !24
  %t700 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t695, i64 %t697)
  store i1 %t700, ptr %l402
  br label %bb191
bb191:
  %t701 = load i1, ptr %l402, !tbaa !21
  store i1 %t701, ptr %l398, !tbaa !21
  br label %bb192
bb192:
  %t702 = load i1, ptr %l398, !tbaa !21
  br i1 %t702, label %bb193, label %bb194
bb193:
  store i1 true, ptr %l403, !tbaa !21
  br label %bb196
bb194:
  %t703 = load ptr, ptr %l0, !tbaa !29
  %t704 = load %"compiler/free:store", ptr %l41
  %t707 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v0, ptr %t703, %"compiler/free:store" %t704)
  store i1 %t707, ptr %l406
  br label %bb195
bb195:
  %t708 = load i1, ptr %l406, !tbaa !21
  %t709 = xor i1 %t708, true
  store i1 %t709, ptr %l403, !tbaa !21
  br label %bb196
bb196:
  %t711 = load i1, ptr %l403, !tbaa !21
  br i1 %t711, label %bb197, label %bb198
bb197:
  call void @__olang_scope_close(ptr %s37)
  br label %bb234
bb198:
  br label %bb199
bb199:
  %t712 = load ptr, ptr %l0, !tbaa !29
  store ptr %t712, ptr %l408, !tbaa !29
  %t713 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 7
  %t714 = load ptr, ptr %t713, !tbaa !29
  %t716 = icmp eq ptr %t714, null
  br i1 %t716, label %bb200, label %bb201
bb200:
  call void @__olang_check_failed(ptr @olang_loc_1c3c578240008a_e9f41163a0859586)
  unreachable
bb201:
  br label %bb202
bb202:
  %t718 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 7
  %t719 = load ptr, ptr %t718, !tbaa !29
  %t720 = load ptr, ptr %l408, !tbaa !29
  %t722 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v0, ptr %t720, ptr %t719)
  store i64 %t722, ptr %l412
  br label %bb203
bb203:
  %t723 = load i64, ptr %l412, !tbaa !24
  store i64 %t723, ptr %l42, !tbaa !24
  %t724 = load i64, ptr %l42, !tbaa !24
  %t726 = icmp slt i64 %t724, 0
  br i1 %t726, label %bb204, label %bb205
bb204:
  store i1 true, ptr %l415, !tbaa !21
  br label %bb210
bb205:
  %t728 = load ptr, ptr %l0, !tbaa !29
  store ptr %t728, ptr %l416, !tbaa !29
  %t729 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 1
  %t730 = load i64, ptr %t729, !tbaa !24
  store i64 %t730, ptr %l417, !tbaa !24
  %t731 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 7
  %t732 = load ptr, ptr %t731, !tbaa !29
  %t734 = icmp eq ptr %t732, null
  br i1 %t734, label %bb206, label %bb207
bb206:
  call void @__olang_check_failed(ptr @olang_loc_66d907e33dd98677_4991ee91581ac48b)
  unreachable
bb207:
  br label %bb208
bb208:
  %t736 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 7
  %t737 = load ptr, ptr %t736, !tbaa !29
  %t738 = load ptr, ptr %l416, !tbaa !29
  %t739 = load i64, ptr %l417, !tbaa !24
  %t741 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t738, i64 %t739, ptr %t737)
  store { i64, [2 x i64] } %t741, ptr %l421
  br label %bb209
bb209:
  %t742 = load { i64, [2 x i64] }, ptr %l421
  %t744 = extractvalue { i64, [2 x i64] } %t742, 0
  %t745 = icmp eq i64 %t744, 7
  store i1 %t745, ptr %l415, !tbaa !21
  br label %bb210
bb210:
  %t747 = load i1, ptr %l415, !tbaa !21
  br i1 %t747, label %bb211, label %bb212
bb211:
  store i1 true, ptr %l424, !tbaa !21
  br label %bb217
bb212:
  %t748 = load ptr, ptr %l0, !tbaa !29
  store ptr %t748, ptr %l425, !tbaa !29
  %t749 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 1
  %t750 = load i64, ptr %t749, !tbaa !24
  store i64 %t750, ptr %l426, !tbaa !24
  %t751 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 7
  %t752 = load ptr, ptr %t751, !tbaa !29
  %t754 = icmp eq ptr %t752, null
  br i1 %t754, label %bb213, label %bb214
bb213:
  call void @__olang_check_failed(ptr @olang_loc_66d907e33dd98677_4991ee91581ac48b)
  unreachable
bb214:
  br label %bb215
bb215:
  %t756 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 7
  %t757 = load ptr, ptr %t756, !tbaa !29
  %t758 = load ptr, ptr %l425, !tbaa !29
  %t759 = load i64, ptr %l426, !tbaa !24
  %t761 = call { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v0, ptr %t758, i64 %t759, ptr %t757)
  store { i64, [2 x i64] } %t761, ptr %l430
  br label %bb216
bb216:
  %t762 = load { i64, [2 x i64] }, ptr %l430
  %t764 = extractvalue { i64, [2 x i64] } %t762, 0
  %t765 = icmp eq i64 %t764, 8
  store i1 %t765, ptr %l424, !tbaa !21
  br label %bb217
bb217:
  %t767 = load i1, ptr %l424, !tbaa !21
  br i1 %t767, label %bb218, label %bb219
bb218:
  call void @__olang_scope_close(ptr %s37)
  br label %bb234
bb219:
  br label %bb220
bb220:
  %t768 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 1
  %t769 = load i64, ptr %t768, !tbaa !24
  %t770 = load i64, ptr %l42, !tbaa !24
  %t773 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s37, i64 %t769, i64 %t770)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t773, ptr %l435
  br label %bb221
bb221:
  %t774 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l435
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t774, ptr %l43
  %t775 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l43
  %t778 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %s0, ptr %l37, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t775)
  %t779 = extractvalue { i32, i64 } %t778, 1
  %t780 = extractvalue { i32, i64 } %t778, 0
  store i32 %t780, ptr %l440
  %t781 = icmp ne i32 %t780, 0
  br i1 %t781, label %bb223, label %ok.782, !prof !99
ok.782:
  store i64 %t779, ptr %l439
  br label %bb222
bb222:
  %t783 = load i64, ptr %l439, !tbaa !24
  store i64 %t783, ptr %l436, !tbaa !24
  br label %bb225
bb223:
  br label %bb224
bb224:
  store i64 -1, ptr %l436, !tbaa !24
  br label %bb225
bb225:
  %t784 = load i64, ptr %l436, !tbaa !24
  store i64 %t784, ptr %l44, !tbaa !24
  %t785 = load i64, ptr %l44, !tbaa !24
  %t787 = icmp slt i64 %t785, 0
  br i1 %t787, label %bb226, label %bb227
bb226:
  %t789 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l43
  %t790 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 0
  %t791 = load i64, ptr %t790, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %s0, ptr %l37, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t789, i64 %t791)
  br label %bb228
bb227:
  %t795 = load i64, ptr %l44, !tbaa !24
  %t796 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 0
  %t797 = load i64, ptr %t796, !tbaa !24
  %t800 = icmp ne i64 %t795, %t797
  br i1 %t800, label %bb229, label %bb230
bb228:
  br label %bb233
bb229:
  %t802 = load ptr, ptr %l0, !tbaa !29
  %t803 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 0
  %t804 = load i64, ptr %t803, !tbaa !24
  %t805 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t806 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 2
  %t807 = load i64, ptr %t806, !tbaa !24
  %t808 = getelementptr %"compiler/free:store", ptr %l41, i32 0, i32 3
  %t809 = load %"compiler/source:Span", ptr %t808
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t802, i64 %t804, i64 %t805, i64 %t807, %"compiler/source:Span" %t809, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d7, i32 0, i32 1) })
  br label %bb231
bb230:
  br label %bb232
bb231:
  br label %bb232
bb232:
  br label %bb233
bb233:
  call void @__olang_scope_close(ptr %s37)
  br label %bb234
bb234:
  %t815 = load i64, ptr %l39, !tbaa !24
  %t818 = add i64 %t815, 1
  store i64 %t818, ptr %l39, !tbaa !24
  br label %bb182
bb235:
  call void @__olang_scope_close(ptr %s36)
  store i64 0, ptr %l45, !tbaa !24
  %t820 = load i64, ptr %l1, !tbaa !24
  store i64 %t820, ptr %l46, !tbaa !24
  store i64 1, ptr %l47, !tbaa !24
  %t822 = load i64, ptr %l46, !tbaa !24
  %t823 = load i64, ptr %l45, !tbaa !24
  %t826 = icmp sgt i64 %t822, %t823
  br i1 %t826, label %bb236, label %bb237
bb236:
  %t828 = load i64, ptr %l47, !tbaa !24
  %t830 = icmp sgt i64 %t828, 0
  br i1 %t830, label %bb238, label %bb239
bb237:
  store i64 0, ptr %l461, !tbaa !24
  br label %bb241
bb238:
  %t832 = load i64, ptr %l46, !tbaa !24
  %t833 = load i64, ptr %l45, !tbaa !24
  %t836 = sub i64 %t832, %t833
  %t837 = load i64, ptr %l47, !tbaa !24
  %t840 = add i64 %t836, %t837
  %t842 = sub i64 %t840, 1
  %t843 = load i64, ptr %l47, !tbaa !24
  %t846 = sdiv i64 %t842, %t843
  store i64 %t846, ptr %l464, !tbaa !24
  br label %bb240
bb239:
  store i64 0, ptr %l464, !tbaa !24
  br label %bb240
bb240:
  %t848 = load i64, ptr %l464, !tbaa !24
  store i64 %t848, ptr %l461, !tbaa !24
  br label %bb241
bb241:
  %t849 = load i64, ptr %l461, !tbaa !24
  store i64 %t849, ptr %l48, !tbaa !24
  store i64 0, ptr %l49, !tbaa !24
  br label %bb242
bb242:
  %t850 = load i64, ptr %l49, !tbaa !24
  %t851 = load i64, ptr %l48, !tbaa !24
  %t854 = icmp slt i64 %t850, %t851
  %t856 = xor i1 %t854, true
  br i1 %t856, label %bb243, label %bb244
bb243:
  br label %bb253
bb244:
  br label %bb245
bb245:
  %t858 = load i64, ptr %l45, !tbaa !24
  %t859 = load i64, ptr %l49, !tbaa !24
  %t860 = load i64, ptr %l47, !tbaa !24
  %t863 = mul i64 %t859, %t860
  %t866 = add i64 %t858, %t863
  store i64 %t866, ptr %l50, !tbaa !24
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t870 = getelementptr %"compiler/free:Free", ptr %t868, i32 0, i32 177
  %t871 = load i64, ptr %l50, !tbaa !24
  %t874 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t870, i64 %t871)
  store i1 %t874, ptr %l485
  br label %bb246
bb246:
  %t875 = load i1, ptr %l485, !tbaa !21
  br i1 %t875, label %bb247, label %bb248
bb247:
  store %olang.scope zeroinitializer, ptr %s46
  %t876 = load ptr, ptr %l0, !tbaa !29
  store ptr %t876, ptr %l486, !tbaa !29
  %t877 = load i64, ptr %l50, !tbaa !24
  store i64 %t877, ptr %l487, !tbaa !24
  %t878 = load i64, ptr @G_2ecompiler_2ffree_2eRDtor, !tbaa !24
  store i64 %t878, ptr %l488, !tbaa !24
  %t879 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s46, i32 0, i32 0)
  store %"compiler/source:Span" %t879, ptr %l489
  br label %bb249
bb248:
  br label %bb251
bb249:
  %t880 = load ptr, ptr %l486, !tbaa !29
  %t881 = load i64, ptr %l487, !tbaa !24
  %t882 = load i64, ptr %l488, !tbaa !24
  %t883 = load %"compiler/source:Span", ptr %l489
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t880, i64 %t881, i64 %t882, i64 -1, %"compiler/source:Span" %t883, { i64, ptr } { i64 85, ptr getelementptr inbounds (<{ i64, [85 x i8] }>, ptr @.d8, i32 0, i32 1) })
  br label %bb250
bb250:
  call void @__olang_scope_close(ptr %s46)
  br label %bb251
bb251:
  br label %bb252
bb252:
  %t884 = load i64, ptr %l49, !tbaa !24
  %t887 = add i64 %t884, 1
  store i64 %t887, ptr %l49, !tbaa !24
  br label %bb242
bb253:
  store i64 0, ptr %l51, !tbaa !24
  %t889 = load i64, ptr %l1, !tbaa !24
  store i64 %t889, ptr %l52, !tbaa !24
  store i64 1, ptr %l53, !tbaa !24
  %t891 = load i64, ptr %l52, !tbaa !24
  %t892 = load i64, ptr %l51, !tbaa !24
  %t895 = icmp sgt i64 %t891, %t892
  br i1 %t895, label %bb254, label %bb255
bb254:
  %t897 = load i64, ptr %l53, !tbaa !24
  %t899 = icmp sgt i64 %t897, 0
  br i1 %t899, label %bb256, label %bb257
bb255:
  store i64 0, ptr %l497, !tbaa !24
  br label %bb259
bb256:
  %t901 = load i64, ptr %l52, !tbaa !24
  %t902 = load i64, ptr %l51, !tbaa !24
  %t905 = sub i64 %t901, %t902
  %t906 = load i64, ptr %l53, !tbaa !24
  %t909 = add i64 %t905, %t906
  %t911 = sub i64 %t909, 1
  %t912 = load i64, ptr %l53, !tbaa !24
  %t915 = sdiv i64 %t911, %t912
  store i64 %t915, ptr %l500, !tbaa !24
  br label %bb258
bb257:
  store i64 0, ptr %l500, !tbaa !24
  br label %bb258
bb258:
  %t917 = load i64, ptr %l500, !tbaa !24
  store i64 %t917, ptr %l497, !tbaa !24
  br label %bb259
bb259:
  %t918 = load i64, ptr %l497, !tbaa !24
  store i64 %t918, ptr %l54, !tbaa !24
  store i64 0, ptr %l55, !tbaa !24
  br label %bb260
bb260:
  %t919 = load i64, ptr %l55, !tbaa !24
  %t920 = load i64, ptr %l54, !tbaa !24
  %t923 = icmp slt i64 %t919, %t920
  %t925 = xor i1 %t923, true
  br i1 %t925, label %bb261, label %bb262
bb261:
  br label %bb270
bb262:
  br label %bb263
bb263:
  %t927 = load i64, ptr %l51, !tbaa !24
  %t928 = load i64, ptr %l55, !tbaa !24
  %t929 = load i64, ptr %l53, !tbaa !24
  %t932 = mul i64 %t928, %t929
  %t935 = add i64 %t927, %t932
  store i64 %t935, ptr %l56, !tbaa !24
  %t937 = load ptr, ptr %l0, !tbaa !29
  %t939 = getelementptr %"compiler/free:Free", ptr %t937, i32 0, i32 109
  store ptr %t939, ptr %l519, !tbaa !29
  %t940 = load i64, ptr %l56, !tbaa !24
  store i64 %t940, ptr %l520, !tbaa !24
  %t941 = load i64, ptr %l56, !tbaa !24
  %t943 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t944 = load ptr, ptr %t943, !tbaa !27
  %t945 = getelementptr i1, ptr %t944, i64 %t941
  %t946 = load i1, ptr %t945, !tbaa !31
  br i1 %t946, label %bb264, label %bb265
bb264:
  %t948 = load ptr, ptr %l0, !tbaa !29
  %t950 = getelementptr %"compiler/free:Free", ptr %t948, i32 0, i32 104
  %t951 = load i64, ptr %l56, !tbaa !24
  %t954 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t950, i64 %t951)
  store i64 %t954, ptr %l527
  br label %bb266
bb265:
  store i1 false, ptr %l523, !tbaa !21
  br label %bb267
bb266:
  %t955 = load i64, ptr @G_2ecompiler_2ffree_2eRNone, !tbaa !24
  %t956 = load i64, ptr %l527, !tbaa !24
  %t958 = icmp eq i64 %t956, %t955
  store i1 %t958, ptr %l523, !tbaa !21
  br label %bb267
bb267:
  %t960 = load ptr, ptr %l519, !tbaa !29
  %t961 = load i64, ptr %l520, !tbaa !24
  %t962 = load i1, ptr %l523, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t960, i64 %t961, i1 %t962)
  br label %bb268
bb268:
  br label %bb269
bb269:
  %t963 = load i64, ptr %l55, !tbaa !24
  %t966 = add i64 %t963, 1
  store i64 %t966, ptr %l55, !tbaa !24
  br label %bb260
bb270:
  store i64 0, ptr %l57, !tbaa !24
  %t968 = load i64, ptr %l1, !tbaa !24
  store i64 %t968, ptr %l58, !tbaa !24
  store i64 1, ptr %l59, !tbaa !24
  %t970 = load i64, ptr %l58, !tbaa !24
  %t971 = load i64, ptr %l57, !tbaa !24
  %t974 = icmp sgt i64 %t970, %t971
  br i1 %t974, label %bb271, label %bb272
bb271:
  %t976 = load i64, ptr %l59, !tbaa !24
  %t978 = icmp sgt i64 %t976, 0
  br i1 %t978, label %bb273, label %bb274
bb272:
  store i64 0, ptr %l537, !tbaa !24
  br label %bb276
bb273:
  %t980 = load i64, ptr %l58, !tbaa !24
  %t981 = load i64, ptr %l57, !tbaa !24
  %t984 = sub i64 %t980, %t981
  %t985 = load i64, ptr %l59, !tbaa !24
  %t988 = add i64 %t984, %t985
  %t990 = sub i64 %t988, 1
  %t991 = load i64, ptr %l59, !tbaa !24
  %t994 = sdiv i64 %t990, %t991
  store i64 %t994, ptr %l540, !tbaa !24
  br label %bb275
bb274:
  store i64 0, ptr %l540, !tbaa !24
  br label %bb275
bb275:
  %t996 = load i64, ptr %l540, !tbaa !24
  store i64 %t996, ptr %l537, !tbaa !24
  br label %bb276
bb276:
  %t997 = load i64, ptr %l537, !tbaa !24
  store i64 %t997, ptr %l60, !tbaa !24
  store i64 0, ptr %l61, !tbaa !24
  br label %bb277
bb277:
  %t998 = load i64, ptr %l61, !tbaa !24
  %t999 = load i64, ptr %l60, !tbaa !24
  %t1002 = icmp slt i64 %t998, %t999
  %t1004 = xor i1 %t1002, true
  br i1 %t1004, label %bb278, label %bb279
bb278:
  br label %bb325
bb279:
  br label %bb280
bb280:
  %t1006 = load i64, ptr %l57, !tbaa !24
  %t1007 = load i64, ptr %l61, !tbaa !24
  %t1008 = load i64, ptr %l59, !tbaa !24
  %t1011 = mul i64 %t1007, %t1008
  %t1014 = add i64 %t1006, %t1011
  store i64 %t1014, ptr %l62, !tbaa !24
  %t1016 = load ptr, ptr %l0, !tbaa !29
  %t1018 = getelementptr %"compiler/free:Free", ptr %t1016, i32 0, i32 109
  %t1019 = load i64, ptr %l62, !tbaa !24
  %t1022 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1018, i64 %t1019)
  store i1 %t1022, ptr %l561
  br label %bb281
bb281:
  %t1023 = load i1, ptr %l561, !tbaa !21
  %t1024 = xor i1 %t1023, true
  br i1 %t1024, label %bb282, label %bb283
bb282:
  store i1 true, ptr %l563, !tbaa !21
  br label %bb285
bb283:
  %t1026 = load ptr, ptr %l0, !tbaa !29
  %t1028 = getelementptr %"compiler/free:Free", ptr %t1026, i32 0, i32 12
  %t1029 = load i64, ptr %l62, !tbaa !24
  %t1032 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1028, i64 %t1029)
  store i1 %t1032, ptr %l567
  br label %bb284
bb284:
  %t1033 = load i1, ptr %l567, !tbaa !21
  %t1034 = xor i1 %t1033, true
  store i1 %t1034, ptr %l563, !tbaa !21
  br label %bb285
bb285:
  %t1036 = load i1, ptr %l563, !tbaa !21
  br i1 %t1036, label %bb286, label %bb287
bb286:
  br label %bb324
bb287:
  br label %bb288
bb288:
  store %olang.scope zeroinitializer, ptr %s54
  %t1037 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1037, ptr %l569, !tbaa !29
  %t1038 = load ptr, ptr %l0, !tbaa !29
  %t1040 = getelementptr %"compiler/free:Free", ptr %t1038, i32 0, i32 15
  %t1041 = load i64, ptr %l62, !tbaa !24
  %t1044 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t1040, i64 %t1041)
  store i32 %t1044, ptr %l573
  br label %bb289
bb289:
  %t1045 = load ptr, ptr %l569, !tbaa !29
  %t1046 = load i32, ptr %l573, !tbaa !23
  %t1047 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s54, ptr %t1045, i32 %t1046)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1047, ptr %l574
  br label %bb290
bb290:
  %t1048 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l574
  %t1049 = call ptr @__olang_scope_alloc_a(ptr %s54, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1048, ptr %t1049
  store ptr %t1049, ptr %l63, !tbaa !29
  store i64 0, ptr %l64, !tbaa !24
  br label %bb291
bb291:
  %t1051 = load i64, ptr %l64, !tbaa !24
  store i64 %t1051, ptr %l576, !tbaa !24
  %t1052 = load ptr, ptr %l63, !tbaa !29
  %t1054 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s54, ptr %t1052)
  store i64 %t1054, ptr %l578
  br label %bb292
bb292:
  %t1055 = load i64, ptr %l576, !tbaa !24
  %t1056 = load i64, ptr %l578, !tbaa !24
  %t1057 = icmp slt i64 %t1055, %t1056
  %t1059 = xor i1 %t1057, true
  br i1 %t1059, label %bb293, label %bb294
bb293:
  br label %bb323
bb294:
  br label %bb295
bb295:
  %t1061 = load ptr, ptr %l63, !tbaa !29
  %t1062 = load i64, ptr %l64, !tbaa !24
  %t1065 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s54, ptr %t1061, i64 %t1062)
  store i64 %t1065, ptr %l583
  br label %bb296
bb296:
  %t1066 = load i64, ptr %l583, !tbaa !24
  store i64 %t1066, ptr %l65, !tbaa !24
  %t1067 = load ptr, ptr %l0, !tbaa !29
  %t1069 = getelementptr %"compiler/free:Free", ptr %t1067, i32 0, i32 13
  %t1070 = load i64, ptr %l65, !tbaa !24
  %t1073 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1069, i64 %t1070)
  store i1 %t1073, ptr %l587
  br label %bb297
bb297:
  %t1074 = load i1, ptr %l587, !tbaa !21
  br i1 %t1074, label %bb298, label %bb299
bb298:
  %t1075 = load ptr, ptr %l0, !tbaa !29
  %t1077 = getelementptr %"compiler/free:Free", ptr %t1075, i32 0, i32 109
  %t1078 = load i64, ptr %l65, !tbaa !24
  %t1081 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1077, i64 %t1078)
  store i1 %t1081, ptr %l592
  br label %bb300
bb299:
  store i1 false, ptr %l588, !tbaa !21
  br label %bb301
bb300:
  %t1082 = load i1, ptr %l592, !tbaa !21
  store i1 %t1082, ptr %l588, !tbaa !21
  br label %bb301
bb301:
  %t1083 = load i1, ptr %l588, !tbaa !21
  br i1 %t1083, label %bb302, label %bb303
bb302:
  %t1084 = load ptr, ptr %l0, !tbaa !29
  %t1085 = load i64, ptr %l65, !tbaa !24
  %t1088 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t1084, i64 %t1085)
  store i1 %t1088, ptr %l596
  br label %bb304
bb303:
  store i1 false, ptr %l593, !tbaa !21
  br label %bb305
bb304:
  %t1089 = load i1, ptr %l596, !tbaa !21
  %t1090 = xor i1 %t1089, true
  store i1 %t1090, ptr %l593, !tbaa !21
  br label %bb305
bb305:
  %t1092 = load i1, ptr %l593, !tbaa !21
  br i1 %t1092, label %bb306, label %bb307
bb306:
  %t1093 = load ptr, ptr %l0, !tbaa !29
  %t1094 = load i64, ptr %l65, !tbaa !24
  %t1097 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %t1093, i64 %t1094)
  store i1 %t1097, ptr %l601
  br label %bb308
bb307:
  store i1 false, ptr %l598, !tbaa !21
  br label %bb314
bb308:
  %t1098 = load i1, ptr %l601, !tbaa !21
  br i1 %t1098, label %bb309, label %bb310
bb309:
  %t1099 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1099, ptr %l603, !tbaa !29
  %t1100 = load ptr, ptr %l0, !tbaa !29
  %t1102 = getelementptr %"compiler/free:Free", ptr %t1100, i32 0, i32 15
  %t1103 = load i64, ptr %l62, !tbaa !24
  %t1106 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t1102, i64 %t1103)
  store i32 %t1106, ptr %l607
  br label %bb311
bb310:
  store i1 false, ptr %l602, !tbaa !21
  br label %bb313
bb311:
  %t1107 = load i64, ptr %l65, !tbaa !24
  %t1108 = load ptr, ptr %l603, !tbaa !29
  %t1109 = load i32, ptr %l607, !tbaa !23
  %t1111 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eanchorPlace(ptr %v0, ptr %t1108, i32 %t1109, i64 %t1107)
  store i1 %t1111, ptr %l609
  br label %bb312
bb312:
  %t1112 = load i1, ptr %l609, !tbaa !21
  %t1113 = xor i1 %t1112, true
  store i1 %t1113, ptr %l602, !tbaa !21
  br label %bb313
bb313:
  %t1115 = load i1, ptr %l602, !tbaa !21
  %t1116 = xor i1 %t1115, true
  store i1 %t1116, ptr %l598, !tbaa !21
  br label %bb314
bb314:
  %t1118 = load i1, ptr %l598, !tbaa !21
  br i1 %t1118, label %bb315, label %bb316
bb315:
  store %olang.scope zeroinitializer, ptr %s56
  %t1119 = load ptr, ptr %l0, !tbaa !29
  %t1121 = getelementptr %"compiler/free:Free", ptr %t1119, i32 0, i32 109
  %t1122 = load i64, ptr %l65, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1121, i64 %t1122, i1 false)
  br label %bb317
bb316:
  br label %bb321
bb317:
  %t1125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1125, ptr %l615, !tbaa !29
  %t1126 = load i64, ptr %l65, !tbaa !24
  store i64 %t1126, ptr %l616, !tbaa !24
  %t1127 = load i64, ptr @G_2ecompiler_2ffree_2eRCopied, !tbaa !24
  store i64 %t1127, ptr %l617, !tbaa !24
  %t1128 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s56, i32 0, i32 0)
  store %"compiler/source:Span" %t1128, ptr %l618
  br label %bb318
bb318:
  %t1129 = load ptr, ptr %l615, !tbaa !29
  %t1130 = load i64, ptr %l616, !tbaa !24
  %t1131 = load i64, ptr %l617, !tbaa !24
  %t1132 = load %"compiler/source:Span", ptr %l618
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1129, i64 %t1130, i64 %t1131, i64 -1, %"compiler/source:Span" %t1132, { i64, ptr } { i64 87, ptr getelementptr inbounds (<{ i64, [87 x i8] }>, ptr @.d9, i32 0, i32 1) })
  br label %bb319
bb319:
  %t1133 = load ptr, ptr %l0, !tbaa !29
  %t1135 = getelementptr %"compiler/free:Free", ptr %t1133, i32 0, i32 81
  %t1136 = load i64, ptr %l65, !tbaa !24
  %t1139 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t1135, i64 %t1136)
  store i64 %t1139, ptr %l622
  br label %bb320
bb320:
  call void @__olang_scope_close(ptr %s56)
  br label %bb321
bb321:
  br label %bb322
bb322:
  %t1140 = load i64, ptr %l64, !tbaa !24
  %t1143 = add i64 %t1140, 1
  store i64 %t1143, ptr %l64, !tbaa !24
  br label %bb291
bb323:
  call void @__olang_scope_close(ptr %s54)
  br label %bb324
bb324:
  %t1145 = load i64, ptr %l61, !tbaa !24
  %t1148 = add i64 %t1145, 1
  store i64 %t1148, ptr %l61, !tbaa !24
  br label %bb277
bb325:
  br label %bb326
bb326:
  store i1 false, ptr %l66, !tbaa !21
  %t1150 = load ptr, ptr %l0, !tbaa !29
  %t1152 = getelementptr %"compiler/free:Free", ptr %t1150, i32 0, i32 101
  store ptr %t1152, ptr %l67, !tbaa !29
  store i64 0, ptr %l68, !tbaa !24
  br label %bb327
bb327:
  %t1154 = load i64, ptr %l68, !tbaa !24
  store i64 %t1154, ptr %l631, !tbaa !24
  %t1155 = load ptr, ptr %l67, !tbaa !29
  %t1157 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %t1155)
  store i64 %t1157, ptr %l633
  br label %bb328
bb328:
  %t1158 = load i64, ptr %l631, !tbaa !24
  %t1159 = load i64, ptr %l633, !tbaa !24
  %t1160 = icmp slt i64 %t1158, %t1159
  %t1162 = xor i1 %t1160, true
  br i1 %t1162, label %bb329, label %bb330
bb329:
  br label %bb347
bb330:
  br label %bb331
bb331:
  %t1164 = load ptr, ptr %l67, !tbaa !29
  %t1165 = load i64, ptr %l68, !tbaa !24
  %t1168 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t1164, i64 %t1165)
  store %"compiler/free:store" %t1168, ptr %l638
  br label %bb332
bb332:
  %t1169 = load %"compiler/free:store", ptr %l638
  store %"compiler/free:store" %t1169, ptr %l69
  %t1170 = getelementptr %"compiler/free:store", ptr %l69, i32 0, i32 4
  %t1171 = load i64, ptr %t1170, !tbaa !24
  %t1172 = load i64, ptr @G_2ecompiler_2ffree_2eSMove, !tbaa !24
  %t1175 = icmp eq i64 %t1171, %t1172
  br i1 %t1175, label %bb333, label %bb334
bb333:
  %t1177 = load ptr, ptr %l0, !tbaa !29
  %t1179 = getelementptr %"compiler/free:Free", ptr %t1177, i32 0, i32 109
  %t1180 = getelementptr %"compiler/free:store", ptr %l69, i32 0, i32 0
  %t1181 = load i64, ptr %t1180, !tbaa !24
  %t1184 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1179, i64 %t1181)
  store i1 %t1184, ptr %l646
  br label %bb335
bb334:
  store i1 false, ptr %l642, !tbaa !21
  br label %bb336
bb335:
  %t1185 = load i1, ptr %l646, !tbaa !21
  store i1 %t1185, ptr %l642, !tbaa !21
  br label %bb336
bb336:
  %t1186 = load i1, ptr %l642, !tbaa !21
  br i1 %t1186, label %bb337, label %bb338
bb337:
  %t1187 = load ptr, ptr %l0, !tbaa !29
  %t1189 = getelementptr %"compiler/free:Free", ptr %t1187, i32 0, i32 109
  %t1190 = getelementptr %"compiler/free:store", ptr %l69, i32 0, i32 5
  %t1191 = load i64, ptr %t1190, !tbaa !24
  %t1194 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t1189, i64 %t1191)
  store i1 %t1194, ptr %l651
  br label %bb339
bb338:
  store i1 false, ptr %l647, !tbaa !21
  br label %bb340
bb339:
  %t1195 = load i1, ptr %l651, !tbaa !21
  %t1196 = xor i1 %t1195, true
  store i1 %t1196, ptr %l647, !tbaa !21
  br label %bb340
bb340:
  %t1198 = load i1, ptr %l647, !tbaa !21
  br i1 %t1198, label %bb341, label %bb342
bb341:
  %t1199 = load ptr, ptr %l0, !tbaa !29
  %t1201 = getelementptr %"compiler/free:Free", ptr %t1199, i32 0, i32 109
  %t1202 = getelementptr %"compiler/free:store", ptr %l69, i32 0, i32 0
  %t1203 = load i64, ptr %t1202, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t1201, i64 %t1203, i1 false)
  br label %bb343
bb342:
  br label %bb345
bb343:
  %t1206 = load ptr, ptr %l0, !tbaa !29
  %t1207 = getelementptr %"compiler/free:store", ptr %l69, i32 0, i32 0
  %t1208 = load i64, ptr %t1207, !tbaa !24
  %t1209 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  %t1210 = getelementptr %"compiler/free:store", ptr %l69, i32 0, i32 2
  %t1211 = load i64, ptr %t1210, !tbaa !24
  %t1212 = getelementptr %"compiler/free:store", ptr %l69, i32 0, i32 3
  %t1213 = load %"compiler/source:Span", ptr %t1212
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t1206, i64 %t1208, i64 %t1209, i64 %t1211, %"compiler/source:Span" %t1213, { i64, ptr } { i64 48, ptr getelementptr inbounds (<{ i64, [48 x i8] }>, ptr @.d10, i32 0, i32 1) })
  br label %bb344
bb344:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb345
bb345:
  br label %bb346
bb346:
  %t1219 = load i64, ptr %l68, !tbaa !24
  %t1222 = add i64 %t1219, 1
  store i64 %t1222, ptr %l68, !tbaa !24
  br label %bb327
bb347:
  %t1224 = load i1, ptr %l66, !tbaa !21
  %t1226 = xor i1 %t1224, true
  br i1 %t1226, label %bb348, label %bb349
bb348:
  br label %bb352
bb349:
  br label %bb350
bb350:
  br label %bb351
bb351:
  br label %bb326
bb352:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edumpPlaces(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/free:reason"
  %l9 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca %"compiler/free:reason"
  %l47 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca i64
  %l59 = alloca ptr
  %l63 = alloca i32
  %l65 = alloca { i64, ptr }
  %l69 = alloca i64
  %l73 = alloca i1
  %l74 = alloca { i64, ptr }
  %l78 = alloca i64
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 4
  %t10 = load ptr, ptr %t9, !tbaa !29
  store ptr %t10, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 9
  %t16 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t14)
  store i64 %t16, ptr %l16
  br label %bb1
bb1:
  %t17 = load i64, ptr %l16, !tbaa !24
  store i64 %t17, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = icmp sgt i64 %t18, %t19
  br i1 %t22, label %bb2, label %bb3
bb2:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sgt i64 %t24, 0
  br i1 %t26, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t32 = sub i64 %t28, %t29
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = add i64 %t32, %t33
  %t38 = sub i64 %t36, 1
  %t39 = load i64, ptr %l4, !tbaa !24
  %t42 = sdiv i64 %t38, %t39
  store i64 %t42, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t44 = load i64, ptr %l23, !tbaa !24
  store i64 %t44, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t45 = load i64, ptr %l20, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l5, !tbaa !24
  %t50 = icmp slt i64 %t46, %t47
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb10:
  br label %bb11
bb11:
  %t54 = load i64, ptr %l2, !tbaa !24
  %t55 = load i64, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l4, !tbaa !24
  %t59 = mul i64 %t55, %t56
  %t62 = add i64 %t54, %t59
  store i64 %t62, ptr %l7, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/free:Free", ptr %t64, i32 0, i32 106
  %t67 = load i64, ptr %l7, !tbaa !24
  %t70 = call %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v0, ptr %t66, i64 %t67)
  store %"compiler/free:reason" %t70, ptr %l44
  br label %bb12
bb12:
  %t71 = load %"compiler/free:reason", ptr %l44
  store %"compiler/free:reason" %t71, ptr %l8
  %t72 = getelementptr %"compiler/free:reason", ptr %l8, i32 0, i32 1
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb13, label %bb14
bb13:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t78 = getelementptr %"compiler/free:reason", ptr %l8, i32 0, i32 1
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = getelementptr %"compiler/free:reason", ptr %l8, i32 0, i32 2
  %t81 = getelementptr %"compiler/source:Span", ptr %t80, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  %t84 = sext i32 %t82 to i64
  %t88 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t77, i64 %t79, i64 %t84)
  store { i64, ptr } %t88, ptr %l52
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l47, !tbaa !27
  br label %bb16
bb15:
  %t89 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t89, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t90, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l47, !tbaa !27
  br label %bb16
bb16:
  %t97 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t97, ptr %l9, !tbaa !27
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l55, !tbaa !29
  %t99 = load i64, ptr %l7, !tbaa !24
  store i64 %t99, ptr %l56, !tbaa !24
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:Free", ptr %t106, i32 0, i32 9
  %t109 = load i64, ptr %l7, !tbaa !24
  %t112 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t108, i64 %t109)
  store i32 %t112, ptr %l63
  br label %bb17
bb17:
  %t114 = inttoptr i64 0 to ptr
  %t115 = load ptr, ptr %l59, !tbaa !29
  %t116 = load i32, ptr %l63, !tbaa !23
  %t117 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t114, ptr %t115, i32 %t116)
  store { i64, ptr } %t117, ptr %l65
  br label %bb18
bb18:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/free:Free", ptr %t118, i32 0, i32 10
  %t121 = load i64, ptr %l7, !tbaa !24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t121)
  store i64 %t124, ptr %l69
  br label %bb19
bb19:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/free:Free", ptr %t125, i32 0, i32 109
  %t128 = load i64, ptr %l7, !tbaa !24
  %t131 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l73
  br label %bb20
bb20:
  %t132 = load i1, ptr %l73, !tbaa !21
  br i1 %t132, label %bb21, label %bb22
bb21:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l74, !tbaa !27
  br label %bb24
bb22:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/free:Free", ptr %t133, i32 0, i32 104
  %t136 = load i64, ptr %l7, !tbaa !24
  %t139 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t135, i64 %t136)
  store i64 %t139, ptr %l78
  br label %bb23
bb23:
  %t140 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t141 = getelementptr %"compiler/free:reason", ptr %l8, i32 0, i32 3
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  %t143 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t144 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t145 = load i64, ptr %l78, !tbaa !24
  %t146 = call i64 @__olang_fmt_i64(ptr null, i64 %t145)
  %t147 = add i64 %t144, %t146
  %t148 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t149 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t150 = add i64 %t147, %t149
  %t152 = extractvalue { i64, ptr } %t140, 1
  %t153 = extractvalue { i64, ptr } %t140, 0
  %t154 = add i64 %t150, %t153
  %t155 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t159 = extractvalue { i64, ptr } %t142, 1
  %t160 = extractvalue { i64, ptr } %t142, 0
  %t161 = add i64 %t157, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t143, i64 %t144)
  %t163 = getelementptr i8, ptr %t162, i64 %t144
  %t164 = call i64 @__olang_fmt_i64(ptr %t163, i64 %t145)
  %t165 = getelementptr i8, ptr %t163, i64 %t146
  call void @olang_textcopy(ptr %t165, ptr %t148, i64 %t149)
  %t166 = getelementptr i8, ptr %t165, i64 %t149
  call void @olang_textcopy(ptr %t166, ptr %t152, i64 %t153)
  %t167 = getelementptr i8, ptr %t166, i64 %t153
  call void @olang_textcopy(ptr %t167, ptr %t155, i64 %t156)
  %t168 = getelementptr i8, ptr %t167, i64 %t156
  call void @olang_textcopy(ptr %t168, ptr %t159, i64 %t160)
  %t169 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t162, 1
  store { i64, ptr } %t170, ptr %l74, !tbaa !27
  br label %bb24
bb24:
  %t173 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t175 = load i64, ptr %l56, !tbaa !24
  %t176 = call i64 @__olang_fmt_i64(ptr null, i64 %t175)
  %t177 = add i64 %t174, %t176
  %t178 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t179 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t180 = add i64 %t177, %t179
  %t181 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 1
  %t183 = extractvalue { i64, ptr } %t181, 0
  %t184 = add i64 %t180, %t183
  %t185 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t186 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t187 = add i64 %t184, %t186
  %t188 = load i64, ptr %l69, !tbaa !24
  %t189 = call i64 @__olang_fmt_i64(ptr null, i64 %t188)
  %t190 = add i64 %t187, %t189
  %t191 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  %t194 = add i64 %t190, %t193
  %t195 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t173, i64 %t174)
  %t199 = getelementptr i8, ptr %t198, i64 %t174
  %t200 = call i64 @__olang_fmt_i64(ptr %t199, i64 %t175)
  %t201 = getelementptr i8, ptr %t199, i64 %t176
  call void @olang_textcopy(ptr %t201, ptr %t178, i64 %t179)
  %t202 = getelementptr i8, ptr %t201, i64 %t179
  call void @olang_textcopy(ptr %t202, ptr %t182, i64 %t183)
  %t203 = getelementptr i8, ptr %t202, i64 %t183
  call void @olang_textcopy(ptr %t203, ptr %t185, i64 %t186)
  %t204 = getelementptr i8, ptr %t203, i64 %t186
  %t205 = call i64 @__olang_fmt_i64(ptr %t204, i64 %t188)
  %t206 = getelementptr i8, ptr %t204, i64 %t189
  call void @olang_textcopy(ptr %t206, ptr %t192, i64 %t193)
  %t207 = getelementptr i8, ptr %t206, i64 %t193
  call void @olang_textcopy(ptr %t207, ptr %t195, i64 %t196)
  %t208 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t198, 1
  %t211 = load ptr, ptr %l55, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %s2, ptr %t211, { i64, ptr } %t209)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t213 = load i64, ptr %l6, !tbaa !24
  %t216 = add i64 %t213, 1
  store i64 %t216, ptr %l6, !tbaa !24
  br label %bb8
bb27:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentry(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i64
  %l19 = alloca i1
  %l23 = alloca i1
  %l26 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  store i64 %t22, ptr %l12, !tbaa !24
  br label %bb10
bb5:
  br i1 true, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  store i64 -1, ptr %l12, !tbaa !24
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_1c505c1b55d06586_a0a7e4d6315dd1d2)
  unreachable
bb10:
  %t24 = load i64, ptr %l12, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = icmp slt i64 %t25, 0
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb14
bb12:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 98
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t35, ptr %l23
  br label %bb13
bb13:
  %t36 = load i1, ptr %l23, !tbaa !21
  store i1 %t36, ptr %l19, !tbaa !21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l19, !tbaa !21
  br i1 %t37, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 0
  %t42 = load ptr, ptr %t41, !tbaa !29
  store ptr %t42, ptr %l26, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:Free", ptr %t43, i32 0, i32 0
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t46, i64 %t47)
  store i64 %t50, ptr %l30
  br label %bb18
bb18:
  %t51 = load ptr, ptr %l26, !tbaa !29
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t51, i64 %t52)
  store ptr %t53, ptr %l31
  br label %bb19
bb19:
  %t54 = load ptr, ptr %l31, !tbaa !29
  store ptr %t54, ptr %l5, !tbaa !29
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = getelementptr %"compiler/ast:Func", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = icmp eq ptr %t58, null
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb22
bb21:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Func", ptr %t64, i32 0, i32 7
  %t67 = load i1, ptr %t66, !tbaa !21
  store i1 %t67, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb27
bb24:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = getelementptr %"compiler/free:Free", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/generic:Program", ptr %t73, i32 0, i32 0
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/load:Loader", ptr %t76, i32 0, i32 3
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %t82, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t79, i32 %t83)
  store { i64, ptr } %t86, ptr %l46
  br label %bb25
bb25:
  %t87 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t87, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store i1 %t88, ptr %l47
  br label %bb26
bb26:
  %t89 = load i1, ptr %l47, !tbaa !21
  store i1 %t89, ptr %l39, !tbaa !21
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load i1, ptr %l39, !tbaa !21
  store i1 %t90, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efailsIntoJoin(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l31 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l59 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Spawn", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t7 = load ptr, ptr %l13, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l13, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 18}
  %t13 = icmp eq i64 %t11, 14
  store i1 %t13, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t17, i32 0, i32 2
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = getelementptr %"compiler/typed:Try", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_a1073a599e491ba7_5bee4305fa184323)
  unreachable
bb14:
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Spawn", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = call ptr @compiler_2ffree_2etaskCall(ptr %v1, ptr %s0, ptr %t30)
  store ptr %t32, ptr %l24
  br label %bb15
bb15:
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t35 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %s0, ptr %s0, ptr %t33)
  store ptr %t35, ptr %l26
  br label %bb16
bb16:
  %t36 = load ptr, ptr %l26, !tbaa !29
  store ptr %t36, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %s0, ptr %t42)
  store i64 %t44, ptr %l31
  br label %bb20
bb20:
  %t45 = load i64, ptr %l31, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t46, 0
  br i1 %t48, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t51)
  store ptr %t53, ptr %l36
  br label %bb24
bb24:
  %t54 = load ptr, ptr %l36, !tbaa !29
  store ptr %t54, ptr %l6, !tbaa !29
  %t55 = load ptr, ptr %l6, !tbaa !29
  store ptr %t55, ptr %l37, !tbaa !29
  %t56 = load ptr, ptr %l6, !tbaa !29
  store ptr %t56, ptr %l38, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:Free", ptr %t57, i32 0, i32 1
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l42
  br label %bb25
bb25:
  %t64 = load ptr, ptr %l42, !tbaa !29
  %t66 = getelementptr %"compiler/typed:Body", ptr %t64, i32 0, i32 2
  %t67 = load i32, ptr %t66, !tbaa !23
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t68, i32 %t67)
  store i32 %t70, ptr %l45
  br label %bb26
bb26:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load i32, ptr %l45, !tbaa !23
  %t73 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t71, i32 %t72)
  store { i64, ptr } %t73, ptr %l46
  br label %bb27
bb27:
  %t74 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t74, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l9, !tbaa !24
  br label %bb28
bb28:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t87, ptr %l53, !tbaa !27
  %t88 = load i64, ptr %l8, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 %t88
  %t93 = load i32, ptr %t92, !tbaa !33
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t101 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eclausesTake(ptr %v0, ptr %v1, ptr %t95, ptr %t96, i32 %t93)
  store i1 %t101, ptr %l59
  br label %bb32
bb32:
  %t102 = load i1, ptr %l59, !tbaa !21
  %t103 = xor i1 %t102, true
  br i1 %t103, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t106, 1
  store i64 %t109, ptr %l8, !tbaa !24
  br label %bb28
bb37:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efeedFits(ptr %v0, ptr %a0, %"compiler/free:feedCall" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/free:feedCall"
  %l2 = alloca %"compiler/free:feed"
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca ptr
  %l9 = alloca %"compiler/free:feed"
  %l13 = alloca i64
  %l20 = alloca ptr
  %l25 = alloca { i64, [2 x i64] }
  %l26 = alloca { i64, [2 x i64] }
  %l28 = alloca { i64, [2 x i64] }
  %l30 = alloca i1
  %l37 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/free:feedCall" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 174
  %t4 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 4
  %t5 = load i64, ptr %t4, !tbaa !24
  %t8 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t3, i64 %t5)
  store %"compiler/free:feed" %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load %"compiler/free:feed", ptr %l9
  store %"compiler/free:feed" %t9, ptr %l2
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 2
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 3
  %t14 = load i64, ptr %t13, !tbaa !24
  %t18 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t10, i64 %t12, i64 %t14)
  store i64 %t18, ptr %l13
  br label %bb2
bb2:
  %t19 = load i64, ptr %l13, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = icmp slt i64 %t20, 0
  br i1 %t22, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/free:Free", ptr %t25, i32 0, i32 3
  %t28 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t27, i64 %t29)
  store ptr %t32, ptr %l20
  br label %bb6
bb6:
  %t33 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = trunc i64 %t34 to i32
  %t38 = load i64, ptr %l3, !tbaa !24
  %t39 = load ptr, ptr %l20, !tbaa !29
  %t42 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t39, i32 %t36, i64 %t38)
  store { i64, [2 x i64] } %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load { i64, [2 x i64] }, ptr %l25
  store { i64, [2 x i64] } %t43, ptr %l4
  %t44 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t44, ptr %l26
  %t45 = getelementptr %"compiler/free:feed", ptr %l2, i32 0, i32 4
  %t46 = load { i64, [2 x i64] }, ptr %t45
  store { i64, [2 x i64] } %t46, ptr %l28
  %t49 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l26, ptr %l28)
  store i1 %t49, ptr %l30
  br label %bb8
bb8:
  %t50 = load i1, ptr %l30, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb9, label %bb10
bb9:
  %t53 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 5
  %t54 = load i1, ptr %t53, !tbaa !21
  %t56 = xor i1 %t54, true
  store i1 %t56, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 0
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 1
  %t62 = load i64, ptr %t61, !tbaa !24
  %t66 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v0, ptr %t58, i64 %t60, i64 %t62)
  store ptr %t66, ptr %l37
  br label %bb12
bb12:
  %t67 = load ptr, ptr %l37, !tbaa !29
  store ptr %t67, ptr %l5, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = icmp eq ptr %t68, null
  br i1 %t70, label %bb13, label %bb14
bb13:
  %t72 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 5
  %t73 = load i1, ptr %t72, !tbaa !21
  %t75 = xor i1 %t73, true
  store i1 %t75, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t81 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 2
  %t82 = load i64, ptr %t81, !tbaa !24
  %t83 = load { i64, [2 x i64] }, ptr %l4
  %t84 = load i64, ptr %l3, !tbaa !24
  %t91 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v0, ptr %t77, i64 %t79, ptr %t80, i64 %t82, { i64, [2 x i64] } %t83, i64 %t84)
  store i64 %t91, ptr %l48
  br label %bb16
bb16:
  %t92 = load i64, ptr %l48, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb19
bb18:
  %t95 = getelementptr %"compiler/free:feedCall", ptr %l1, i32 0, i32 5
  %t96 = load i1, ptr %t95, !tbaa !21
  %t98 = xor i1 %t96, true
  store i1 %t98, ptr %l50, !tbaa !21
  br label %bb19
bb19:
  %t100 = load i1, ptr %l50, !tbaa !21
  store i1 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i32
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l37 = alloca ptr
  %l42 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l51 = alloca ptr
  %l52 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l91 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca i1
  %l105 = alloca ptr
  %l116 = alloca ptr
  %l120 = alloca ptr
  %l121 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l145 = alloca ptr
  %l146 = alloca i1
  %l151 = alloca ptr
  %l157 = alloca ptr
  %l161 = alloca ptr
  %l162 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l184 = alloca { i64, ptr }
  %l189 = alloca i64
  %l190 = alloca ptr
  %l191 = alloca i1
  %l201 = alloca i64
  %l202 = alloca i64
  %l206 = alloca i64
  %l207 = alloca i32
  %l213 = alloca i1
  %l214 = alloca i1
  %l217 = alloca i1
  %l220 = alloca ptr
  %l224 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s2 = alloca %olang.scope
  %s23 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t2 = load ptr, ptr %l22, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l22, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 17}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l23, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l23, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb23
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t23 = load ptr, ptr %l30, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l30, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 0
  store i1 %t29, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l31, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t33, i32 0, i32 2
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l4, !tbaa !23
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 142
  store ptr %t39, ptr %l37, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/free:Free", ptr %t40, i32 0, i32 178
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load i32, ptr %l4, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t49 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t43, i64 %t46)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t49, ptr %l42
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l37, !tbaa !29
  %t51 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l42
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t50, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51, i1 true)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_8b3278c9956239a9_33a2ffffb2331f15)
  unreachable
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecandTarget(ptr %v0, ptr %v1, ptr %t52, ptr %t53)
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownLocalCand(ptr %v0, ptr %v1, ptr %t56, ptr %t57)
  br label %bb20
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobalCand(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb21
bb21:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  br label %bb22
bb22:
  br label %bb151
bb23:
  %t68 = load ptr, ptr %l1, !tbaa !29
  store ptr %t68, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t69 = load ptr, ptr %l51, !tbaa !29
  %t70 = icmp ne ptr %t69, null
  br i1 %t70, label %bb24, label %bb25
bb24:
  %t72 = load ptr, ptr %l51, !tbaa !29
  %t73 = load i64, ptr %t72, !range !{i64 0, i64 17}
  %t75 = icmp eq i64 %t73, 0
  store i1 %t75, ptr %l52, !tbaa !21
  br label %bb25
bb25:
  %t76 = load i1, ptr %l52, !tbaa !21
  br i1 %t76, label %bb26, label %bb27
bb26:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr { i64, [3 x i64] }, ptr %t77, i32 0, i32 1
  %t80 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t79, i32 0, i32 1
  %t81 = load i32, ptr %t80
  store i32 %t81, ptr %l5, !tbaa !23
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr { i64, [3 x i64] }, ptr %t83, i32 0, i32 1
  %t86 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t85, i32 0, i32 2
  %t87 = load ptr, ptr %t86
  store ptr %t87, ptr %l6, !tbaa !29
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 141
  %t92 = load i32, ptr %l5, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/free:Free", ptr %t95, i32 0, i32 140
  %t98 = load i64, ptr %t97, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t91, i64 %t94, i64 %t98)
  br label %bb29
bb29:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t102, ptr %t103)
  br label %bb30
bb30:
  br label %bb151
bb31:
  %t106 = load ptr, ptr %l1, !tbaa !29
  store ptr %t106, ptr %l67, !tbaa !29
  store i1 false, ptr %l68, !tbaa !21
  %t107 = load ptr, ptr %l67, !tbaa !29
  %t108 = icmp ne ptr %t107, null
  br i1 %t108, label %bb32, label %bb33
bb32:
  %t110 = load ptr, ptr %l67, !tbaa !29
  %t111 = load i64, ptr %t110, !range !{i64 0, i64 17}
  %t113 = icmp eq i64 %t111, 2
  store i1 %t113, ptr %l68, !tbaa !21
  br label %bb33
bb33:
  %t114 = load i1, ptr %l68, !tbaa !21
  br i1 %t114, label %bb34, label %bb35
bb34:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr { i64, [3 x i64] }, ptr %t115, i32 0, i32 1
  %t118 = getelementptr { %"compiler/source:Span", ptr }, ptr %t117, i32 0, i32 1
  %t119 = load ptr, ptr %t118
  store ptr %t119, ptr %l7, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t121, ptr %t122)
  br label %bb37
bb37:
  br label %bb151
bb38:
  %t125 = load ptr, ptr %l1, !tbaa !29
  store ptr %t125, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t126 = load ptr, ptr %l75, !tbaa !29
  %t127 = icmp ne ptr %t126, null
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = load ptr, ptr %l75, !tbaa !29
  %t130 = load i64, ptr %t129, !range !{i64 0, i64 17}
  %t132 = icmp eq i64 %t130, 3
  store i1 %t132, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  %t133 = load i1, ptr %l76, !tbaa !21
  br i1 %t133, label %bb41, label %bb42
bb41:
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", ptr }, ptr %t136, i32 0, i32 1
  %t138 = load ptr, ptr %t137
  store ptr %t138, ptr %l8, !tbaa !29
  br label %bb43
bb42:
  br label %bb53
bb43:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t143 = getelementptr %"compiler/typed:If", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t140, ptr %t144)
  br label %bb44
bb44:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l8, !tbaa !29
  %t150 = getelementptr %"compiler/typed:If", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t147, ptr %t151)
  br label %bb45
bb45:
  %t154 = load ptr, ptr %l8, !tbaa !29
  %t156 = getelementptr %"compiler/typed:If", ptr %t154, i32 0, i32 2
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = icmp eq ptr %t157, null
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb46, label %bb47
bb46:
  %t163 = load ptr, ptr %l0, !tbaa !29
  store ptr %t163, ptr %l91, !tbaa !29
  %t164 = load ptr, ptr %l8, !tbaa !29
  %t166 = getelementptr %"compiler/typed:If", ptr %t164, i32 0, i32 2
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = icmp eq ptr %t167, null
  br i1 %t169, label %bb48, label %bb49
bb47:
  br label %bb52
bb48:
  call void @__olang_check_failed(ptr @olang_loc_cc35812cd80eb51_e2c8c2ff33ac75fd)
  unreachable
bb49:
  br label %bb50
bb50:
  %t171 = load ptr, ptr %l8, !tbaa !29
  %t173 = getelementptr %"compiler/typed:If", ptr %t171, i32 0, i32 2
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t175 = load ptr, ptr %l91, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t175, ptr %t174)
  br label %bb51
bb51:
  br label %bb52
bb52:
  br label %bb151
bb53:
  %t177 = load ptr, ptr %l1, !tbaa !29
  store ptr %t177, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t178 = load ptr, ptr %l97, !tbaa !29
  %t179 = icmp ne ptr %t178, null
  br i1 %t179, label %bb54, label %bb55
bb54:
  %t181 = load ptr, ptr %l97, !tbaa !29
  %t182 = load i64, ptr %t181, !range !{i64 0, i64 17}
  %t184 = icmp eq i64 %t182, 4
  store i1 %t184, ptr %l98, !tbaa !21
  br label %bb55
bb55:
  %t185 = load i1, ptr %l98, !tbaa !21
  br i1 %t185, label %bb56, label %bb57
bb56:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr { i64, [3 x i64] }, ptr %t186, i32 0, i32 1
  %t189 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t188, i32 0, i32 1
  %t190 = load ptr, ptr %t189
  store ptr %t190, ptr %l9, !tbaa !29
  %t192 = load ptr, ptr %l1, !tbaa !29
  %t194 = getelementptr { i64, [3 x i64] }, ptr %t192, i32 0, i32 1
  %t195 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t194, i32 0, i32 2
  %t196 = load ptr, ptr %t195
  store ptr %t196, ptr %l10, !tbaa !29
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l105, !tbaa !29
  %t199 = load ptr, ptr %l105, !tbaa !29
  %t200 = getelementptr %"compiler/free:Free", ptr %t199, i32 0, i32 140
  %t201 = load i64, ptr %t200, !tbaa !24
  %t204 = add i64 %t201, 1
  %t206 = load ptr, ptr %l105, !tbaa !29
  %t207 = getelementptr %"compiler/free:Free", ptr %t206, i32 0, i32 140
  store i64 %t204, ptr %t207, !tbaa !24
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t209 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t208, ptr %t209)
  br label %bb59
bb59:
  %t212 = load ptr, ptr %l10, !tbaa !29
  %t214 = icmp eq ptr %t212, null
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb60, label %bb61
bb60:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t218, ptr %t219)
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t222 = load ptr, ptr %l0, !tbaa !29
  store ptr %t222, ptr %l116, !tbaa !29
  %t223 = load ptr, ptr %l116, !tbaa !29
  %t224 = getelementptr %"compiler/free:Free", ptr %t223, i32 0, i32 140
  %t225 = load i64, ptr %t224, !tbaa !24
  %t228 = sub i64 %t225, 1
  %t230 = load ptr, ptr %l116, !tbaa !29
  %t231 = getelementptr %"compiler/free:Free", ptr %t230, i32 0, i32 140
  store i64 %t228, ptr %t231, !tbaa !24
  br label %bb151
bb64:
  %t232 = load ptr, ptr %l1, !tbaa !29
  store ptr %t232, ptr %l120, !tbaa !29
  store i1 false, ptr %l121, !tbaa !21
  %t233 = load ptr, ptr %l120, !tbaa !29
  %t234 = icmp ne ptr %t233, null
  br i1 %t234, label %bb65, label %bb66
bb65:
  %t236 = load ptr, ptr %l120, !tbaa !29
  %t237 = load i64, ptr %t236, !range !{i64 0, i64 17}
  %t239 = icmp eq i64 %t237, 6
  store i1 %t239, ptr %l121, !tbaa !21
  br label %bb66
bb66:
  %t240 = load i1, ptr %l121, !tbaa !21
  br i1 %t240, label %bb67, label %bb68
bb67:
  %t241 = load ptr, ptr %l1, !tbaa !29
  %t243 = getelementptr { i64, [3 x i64] }, ptr %t241, i32 0, i32 1
  %t244 = getelementptr { %"compiler/source:Span", ptr }, ptr %t243, i32 0, i32 1
  %t245 = load ptr, ptr %t244
  store ptr %t245, ptr %l11, !tbaa !29
  br label %bb73
bb68:
  %t247 = load ptr, ptr %l1, !tbaa !29
  store ptr %t247, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t248 = load ptr, ptr %l126, !tbaa !29
  %t249 = icmp ne ptr %t248, null
  br i1 %t249, label %bb69, label %bb70
bb69:
  %t251 = load ptr, ptr %l126, !tbaa !29
  %t252 = load i64, ptr %t251, !range !{i64 0, i64 17}
  %t254 = icmp eq i64 %t252, 16
  store i1 %t254, ptr %l127, !tbaa !21
  br label %bb70
bb70:
  %t255 = load i1, ptr %l127, !tbaa !21
  br i1 %t255, label %bb71, label %bb72
bb71:
  %t256 = load ptr, ptr %l1, !tbaa !29
  %t258 = getelementptr { i64, [3 x i64] }, ptr %t256, i32 0, i32 1
  %t259 = getelementptr { %"compiler/source:Span", ptr }, ptr %t258, i32 0, i32 1
  %t260 = load ptr, ptr %t259
  store ptr %t260, ptr %l11, !tbaa !29
  br label %bb73
bb72:
  br label %bb78
bb73:
  %t262 = load ptr, ptr %l11, !tbaa !29
  %t264 = icmp eq ptr %t262, null
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb74, label %bb75
bb74:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %t268, ptr %t269)
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  br label %bb151
bb78:
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t273 = load ptr, ptr %l137, !tbaa !29
  %t274 = icmp ne ptr %t273, null
  br i1 %t274, label %bb79, label %bb80
bb79:
  %t276 = load ptr, ptr %l137, !tbaa !29
  %t277 = load i64, ptr %t276, !range !{i64 0, i64 17}
  %t279 = icmp eq i64 %t277, 11
  store i1 %t279, ptr %l138, !tbaa !21
  br label %bb80
bb80:
  %t280 = load i1, ptr %l138, !tbaa !21
  br i1 %t280, label %bb81, label %bb82
bb81:
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr { i64, [3 x i64] }, ptr %t281, i32 0, i32 1
  %t284 = getelementptr { %"compiler/source:Span", ptr }, ptr %t283, i32 0, i32 1
  %t285 = load ptr, ptr %t284
  store ptr %t285, ptr %l12, !tbaa !29
  br label %bb83
bb82:
  br label %bb85
bb83:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = load ptr, ptr %l12, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t287, ptr %t288)
  br label %bb84
bb84:
  br label %bb151
bb85:
  %t291 = load ptr, ptr %l1, !tbaa !29
  store ptr %t291, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t292 = load ptr, ptr %l145, !tbaa !29
  %t293 = icmp ne ptr %t292, null
  br i1 %t293, label %bb86, label %bb87
bb86:
  %t295 = load ptr, ptr %l145, !tbaa !29
  %t296 = load i64, ptr %t295, !range !{i64 0, i64 17}
  %t298 = icmp eq i64 %t296, 12
  store i1 %t298, ptr %l146, !tbaa !21
  br label %bb87
bb87:
  %t299 = load i1, ptr %l146, !tbaa !21
  br i1 %t299, label %bb88, label %bb89
bb88:
  %t300 = load ptr, ptr %l1, !tbaa !29
  %t302 = getelementptr { i64, [3 x i64] }, ptr %t300, i32 0, i32 1
  %t303 = getelementptr { %"compiler/source:Span", ptr }, ptr %t302, i32 0, i32 1
  %t304 = load ptr, ptr %t303
  store ptr %t304, ptr %l13, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l151, !tbaa !29
  %t307 = load ptr, ptr %l151, !tbaa !29
  %t308 = getelementptr %"compiler/free:Free", ptr %t307, i32 0, i32 140
  %t309 = load i64, ptr %t308, !tbaa !24
  %t312 = add i64 %t309, 1
  %t314 = load ptr, ptr %l151, !tbaa !29
  %t315 = getelementptr %"compiler/free:Free", ptr %t314, i32 0, i32 140
  store i64 %t312, ptr %t315, !tbaa !24
  %t316 = load ptr, ptr %l0, !tbaa !29
  %t317 = load ptr, ptr %l13, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t316, ptr %t317)
  br label %bb91
bb91:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l157, !tbaa !29
  %t321 = load ptr, ptr %l157, !tbaa !29
  %t322 = getelementptr %"compiler/free:Free", ptr %t321, i32 0, i32 140
  %t323 = load i64, ptr %t322, !tbaa !24
  %t326 = sub i64 %t323, 1
  %t328 = load ptr, ptr %l157, !tbaa !29
  %t329 = getelementptr %"compiler/free:Free", ptr %t328, i32 0, i32 140
  store i64 %t326, ptr %t329, !tbaa !24
  br label %bb151
bb92:
  %t330 = load ptr, ptr %l1, !tbaa !29
  store ptr %t330, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t331 = load ptr, ptr %l161, !tbaa !29
  %t332 = icmp ne ptr %t331, null
  br i1 %t332, label %bb93, label %bb94
bb93:
  %t334 = load ptr, ptr %l161, !tbaa !29
  %t335 = load i64, ptr %t334, !range !{i64 0, i64 17}
  %t337 = icmp eq i64 %t335, 13
  store i1 %t337, ptr %l162, !tbaa !21
  br label %bb94
bb94:
  %t338 = load i1, ptr %l162, !tbaa !21
  br i1 %t338, label %bb95, label %bb96
bb95:
  %t339 = load ptr, ptr %l1, !tbaa !29
  %t341 = getelementptr { i64, [3 x i64] }, ptr %t339, i32 0, i32 1
  %t342 = getelementptr { %"compiler/source:Span", ptr }, ptr %t341, i32 0, i32 1
  %t343 = load ptr, ptr %t342
  store ptr %t343, ptr %l14, !tbaa !29
  br label %bb97
bb96:
  br label %bb99
bb97:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l14, !tbaa !29
  %t348 = getelementptr %"compiler/typed:Join", ptr %t346, i32 0, i32 0
  %t349 = load ptr, ptr %t348, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %t345, ptr %t349)
  br label %bb98
bb98:
  br label %bb151
bb99:
  %t352 = load ptr, ptr %l1, !tbaa !29
  store ptr %t352, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t353 = load ptr, ptr %l170, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb100, label %bb101
bb100:
  %t356 = load ptr, ptr %l170, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 17}
  %t359 = icmp eq i64 %t357, 14
  store i1 %t359, ptr %l171, !tbaa !21
  br label %bb101
bb101:
  %t360 = load i1, ptr %l171, !tbaa !21
  br i1 %t360, label %bb102, label %bb103
bb102:
  %t361 = load ptr, ptr %l1, !tbaa !29
  %t363 = getelementptr { i64, [3 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", ptr }, ptr %t363, i32 0, i32 1
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l15, !tbaa !29
  br label %bb104
bb103:
  br label %bb146
bb104:
  %t367 = load ptr, ptr %l15, !tbaa !29
  %t369 = getelementptr %"compiler/typed:Spawn", ptr %t367, i32 0, i32 0
  %t370 = load { i64, ptr }, ptr %t369, !tbaa !27
  store { i64, ptr } %t370, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t372 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  store i64 %t374, ptr %l18, !tbaa !24
  br label %bb105
bb105:
  %t376 = load i64, ptr %l17, !tbaa !24
  %t377 = load i64, ptr %l18, !tbaa !24
  %t380 = icmp slt i64 %t376, %t377
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb106, label %bb107
bb106:
  br label %bb145
bb107:
  br label %bb108
bb108:
  %t384 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t384, ptr %l184, !tbaa !27
  %t385 = load i64, ptr %l17, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr ptr, ptr %t388, i64 %t385
  %t390 = load ptr, ptr %t389, !tbaa !39
  store ptr %t390, ptr %l19, !tbaa !29
  %t392 = load ptr, ptr %l19, !tbaa !29
  %t394 = icmp eq ptr %t392, null
  br i1 %t394, label %bb109, label %bb110
bb109:
  br label %bb144
bb110:
  br label %bb111
bb111:
  %t396 = load ptr, ptr %l19, !tbaa !29
  store ptr %t396, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t397 = load ptr, ptr %l190, !tbaa !29
  %t398 = icmp ne ptr %t397, null
  br i1 %t398, label %bb112, label %bb113
bb112:
  %t400 = load ptr, ptr %l190, !tbaa !29
  %t401 = load i64, ptr %t400, !range !{i64 0, i64 8}
  %t403 = icmp eq i64 %t401, 0
  store i1 %t403, ptr %l191, !tbaa !21
  br label %bb113
bb113:
  %t404 = load i1, ptr %l191, !tbaa !21
  br i1 %t404, label %bb114, label %bb115
bb114:
  %t405 = load ptr, ptr %l19, !tbaa !29
  %t407 = getelementptr { i64, [4 x i64] }, ptr %t405, i32 0, i32 1
  %t408 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t407, i32 0, i32 2
  %t409 = load i32, ptr %t408
  store i32 %t409, ptr %l20, !tbaa !23
  br label %bb116
bb115:
  br label %bb117
bb116:
  %t411 = load i32, ptr %l20, !tbaa !23
  %t413 = sext i32 %t411 to i64
  store i64 %t413, ptr %l189, !tbaa !24
  br label %bb122
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  store i64 -1, ptr %l189, !tbaa !24
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_c8d50c31c10865f3_6990d5fc4ec4fa5f)
  unreachable
bb122:
  %t415 = load i64, ptr %l189, !tbaa !24
  store i64 %t415, ptr %l21, !tbaa !24
  %t416 = load i64, ptr %l21, !tbaa !24
  %t418 = icmp slt i64 %t416, 0
  br i1 %t418, label %bb123, label %bb124
bb123:
  br label %bb144
bb124:
  br label %bb125
bb125:
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = getelementptr %"compiler/free:Free", ptr %t420, i32 0, i32 140
  %t423 = load i64, ptr %t422, !tbaa !24
  store i64 %t423, ptr %l201, !tbaa !24
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/free:Free", ptr %t424, i32 0, i32 141
  %t427 = load i64, ptr %l21, !tbaa !24
  %t430 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t426, i64 %t427)
  %t431 = extractvalue { i32, i64 } %t430, 1
  %t432 = extractvalue { i32, i64 } %t430, 0
  store i32 %t432, ptr %l207
  %t433 = icmp ne i32 %t432, 0
  br i1 %t433, label %bb127, label %ok.434, !prof !99
ok.434:
  store i64 %t431, ptr %l206
  br label %bb126
bb126:
  %t435 = load i64, ptr %l206, !tbaa !24
  store i64 %t435, ptr %l202, !tbaa !24
  br label %bb129
bb127:
  br label %bb128
bb128:
  store i64 0, ptr %l202, !tbaa !24
  br label %bb129
bb129:
  %t436 = load i64, ptr %l201, !tbaa !24
  %t437 = load i64, ptr %l202, !tbaa !24
  %t438 = icmp sgt i64 %t436, %t437
  br i1 %t438, label %bb130, label %bb131
bb130:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load ptr, ptr %l19, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownLocalCand(ptr %v0, ptr %v1, ptr %t440, ptr %t441)
  br label %bb132
bb131:
  br label %bb133
bb132:
  br label %bb133
bb133:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load ptr, ptr %l15, !tbaa !29
  %t448 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2efailsIntoJoin(ptr %v0, ptr %v1, ptr %t444, ptr %t445)
  store i1 %t448, ptr %l213
  br label %bb134
bb134:
  %t449 = load i1, ptr %l213, !tbaa !21
  br i1 %t449, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l214, !tbaa !21
  br label %bb138
bb136:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l15, !tbaa !29
  %t454 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainClauses(ptr %v0, ptr %v1, ptr %t450, ptr %t451)
  store i1 %t454, ptr %l217
  br label %bb137
bb137:
  %t455 = load i1, ptr %l217, !tbaa !21
  %t456 = xor i1 %t455, true
  store i1 %t456, ptr %l214, !tbaa !21
  br label %bb138
bb138:
  %t458 = load i1, ptr %l214, !tbaa !21
  br i1 %t458, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s23
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/free:Free", ptr %t459, i32 0, i32 142
  store ptr %t461, ptr %l220, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/free:Free", ptr %t462, i32 0, i32 178
  %t465 = load i64, ptr %t464, !tbaa !24
  %t466 = load i64, ptr %l21, !tbaa !24
  %t469 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s23, i64 %t465, i64 %t466)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t469, ptr %l224
  br label %bb141
bb140:
  br label %bb143
bb141:
  %t470 = load ptr, ptr %l220, !tbaa !29
  %t471 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l224
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t470, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t471, i1 true)
  br label %bb142
bb142:
  call void @__olang_scope_close(ptr %s23)
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t472 = load i64, ptr %l17, !tbaa !24
  %t475 = add i64 %t472, 1
  store i64 %t475, ptr %l17, !tbaa !24
  br label %bb105
bb145:
  br label %bb151
bb146:
  br i1 true, label %bb147, label %bb148
bb147:
  br label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb151
bb150:
  call void @__olang_check_failed(ptr @olang_loc_686cabfba7367172_4d10bcb362872dde)
  unreachable
bb151:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobTy(ptr %v0, ptr %a0, i32 %a1, i1 %a2, i1 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i1
  %l26 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l45 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i1
  %l56 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca i64
  %l85 = alloca i64
  %l90 = alloca i32
  %l93 = alloca i1
  %l100 = alloca i1
  %l109 = alloca i1
  %l112 = alloca i1
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i1 %a2, ptr %l2
  store i1 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l14, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l18
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l15, !tbaa !29
  %t12 = load i32, ptr %l18, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l19
  br label %bb3
bb3:
  %t14 = load i32, ptr %l19, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load ptr, ptr %l5, !tbaa !29
  %t16 = load i32, ptr %l6, !tbaa !23
  %t19 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l22
  br label %bb4
bb4:
  %t20 = load i32, ptr %l22, !range !{i32 0, i32 33}
  store i32 %t20, ptr %l7
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t22 = load i32, ptr %l6, !tbaa !23
  %t25 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %t21, i32 %t22)
  store i1 %t25, ptr %l25
  br label %bb5
bb5:
  %t26 = load i1, ptr %l25, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb8
bb7:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp sgt i64 %t27, 64
  store i1 %t29, ptr %l26, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l26, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t34 = icmp sle i64 %t32, 64
  store i1 %t34, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t36 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t38 = trunc i64 21 to i32
  %t39 = icmp eq i32 %t36, %t38
  br i1 %t39, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb14
bb13:
  %t41 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t43 = trunc i64 25 to i32
  %t44 = icmp eq i32 %t41, %t43
  store i1 %t44, ptr %l33, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l33, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb17
bb16:
  %t47 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t49 = trunc i64 29 to i32
  %t50 = icmp eq i32 %t47, %t49
  store i1 %t50, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t52 = load i1, ptr %l36, !tbaa !21
  br i1 %t52, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb20
bb19:
  %t53 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t55 = trunc i64 0 to i32
  %t56 = icmp eq i32 %t53, %t55
  store i1 %t56, ptr %l39, !tbaa !21
  br label %bb20
bb20:
  %t58 = load i1, ptr %l39, !tbaa !21
  br i1 %t58, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t60 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t62 = trunc i64 20 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb24, label %bb25
bb24:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l45, !tbaa !29
  %t66 = load ptr, ptr %l5, !tbaa !29
  %t67 = load i32, ptr %l6, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t66, i32 %t67)
  store i32 %t70, ptr %l48
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t71 = load i1, ptr %l3, !tbaa !21
  %t72 = load i64, ptr %l4, !tbaa !24
  %t74 = add i64 %t72, 1
  %t75 = load ptr, ptr %l45, !tbaa !29
  %t76 = load i32, ptr %l48, !tbaa !23
  %t79 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobTy(ptr %v0, ptr %t75, i32 %t76, i1 true, i1 %t71, i64 %t74)
  store i1 %t79, ptr %l52
  br label %bb27
bb27:
  %t80 = load i1, ptr %l52, !tbaa !21
  store i1 %t80, ptr %rv
  br label %ret
bb28:
  %t81 = load i32, ptr %l6, !tbaa !23
  %t83 = sext i32 %t81 to i64
  store i64 %t83, ptr %l8, !tbaa !24
  %t85 = load i1, ptr %l2, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t87 = load i1, ptr %l3, !tbaa !21
  %t89 = xor i1 %t87, true
  store i1 %t89, ptr %l56, !tbaa !21
  br label %bb31
bb30:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb31
bb31:
  %t91 = load i1, ptr %l56, !tbaa !21
  store i1 %t91, ptr %l9, !tbaa !21
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/free:Free", ptr %t92, i32 0, i32 133
  %t95 = load i64, ptr %l8, !tbaa !24
  %t98 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t94, i64 %t95)
  store i1 %t98, ptr %l62
  br label %bb32
bb32:
  %t99 = load i1, ptr %l62, !tbaa !21
  br i1 %t99, label %bb33, label %bb34
bb33:
  %t100 = load i1, ptr %l9, !tbaa !21
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb39
bb35:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb38
bb36:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/free:Free", ptr %t104, i32 0, i32 134
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t106, i64 %t107)
  store i1 %t110, ptr %l70
  br label %bb37
bb37:
  %t111 = load i1, ptr %l70, !tbaa !21
  store i1 %t111, ptr %l66, !tbaa !21
  br label %bb38
bb38:
  %t112 = load i1, ptr %l66, !tbaa !21
  store i1 %t112, ptr %l63, !tbaa !21
  br label %bb39
bb39:
  %t113 = load i1, ptr %l63, !tbaa !21
  br i1 %t113, label %bb40, label %bb41
bb40:
  store i1 true, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/free:Free", ptr %t115, i32 0, i32 133
  %t118 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t117, i64 %t118, i1 true)
  br label %bb43
bb43:
  %t121 = load i1, ptr %l9, !tbaa !21
  br i1 %t121, label %bb44, label %bb45
bb44:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/free:Free", ptr %t123, i32 0, i32 134
  %t126 = load i64, ptr %l8, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t125, i64 %t126, i1 true)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l6, !tbaa !23
  %t133 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2epartsOf(ptr %v0, ptr %s6, ptr %t129, i32 %t130)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l81
  br label %bb48
bb48:
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  %t135 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %t135
  store ptr %t135, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb49
bb49:
  %t137 = load i64, ptr %l11, !tbaa !24
  store i64 %t137, ptr %l83, !tbaa !24
  %t138 = load ptr, ptr %l10, !tbaa !29
  %t140 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s6, ptr %t138)
  store i64 %t140, ptr %l85
  br label %bb50
bb50:
  %t141 = load i64, ptr %l83, !tbaa !24
  %t142 = load i64, ptr %l85, !tbaa !24
  %t143 = icmp slt i64 %t141, %t142
  %t145 = xor i1 %t143, true
  br i1 %t145, label %bb51, label %bb52
bb51:
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t147 = load ptr, ptr %l10, !tbaa !29
  %t148 = load i64, ptr %l11, !tbaa !24
  %t151 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s6, ptr %t147, i64 %t148)
  store i32 %t151, ptr %l90
  br label %bb54
bb54:
  %t152 = load i32, ptr %l90, !tbaa !23
  store i32 %t152, ptr %l12, !tbaa !23
  %t153 = load i32, ptr %l12, !tbaa !23
  %t155 = icmp ne i32 %t153, 0
  br i1 %t155, label %bb55, label %bb56
bb55:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i32, ptr %l12, !tbaa !23
  %t159 = load i1, ptr %l2, !tbaa !21
  %t160 = load i1, ptr %l3, !tbaa !21
  %t161 = load i64, ptr %l4, !tbaa !24
  %t163 = add i64 %t161, 1
  %t169 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobTy(ptr %v0, ptr %t157, i32 %t158, i1 %t159, i1 %t160, i64 %t163)
  store i1 %t169, ptr %l100
  br label %bb57
bb56:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb58
bb57:
  %t170 = load i1, ptr %l100, !tbaa !21
  %t171 = xor i1 %t170, true
  store i1 %t171, ptr %l93, !tbaa !21
  br label %bb58
bb58:
  %t173 = load i1, ptr %l93, !tbaa !21
  br i1 %t173, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s6)
  store i1 false, ptr %rv
  br label %ret
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t175 = load i64, ptr %l11, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l11, !tbaa !24
  br label %bb49
bb63:
  call void @__olang_scope_close(ptr %s6)
  %t180 = load i32, ptr %l7, !range !{i32 0, i32 33}
  %t182 = trunc i64 18 to i32
  %t183 = icmp eq i32 %t180, %t182
  %t185 = xor i1 %t183, true
  br i1 %t185, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l109, !tbaa !21
  br label %bb67
bb65:
  %t187 = load ptr, ptr %l5, !tbaa !29
  %t188 = load i32, ptr %l6, !tbaa !23
  %t191 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t187, i32 %t188)
  store i1 %t191, ptr %l112
  br label %bb66
bb66:
  %t192 = load i1, ptr %l112, !tbaa !21
  store i1 %t192, ptr %l109, !tbaa !21
  br label %bb67
bb67:
  %t193 = load i1, ptr %l109, !tbaa !21
  store i1 %t193, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eglobalCand(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i1
  %l24 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca i1
  %l33 = alloca ptr
  %l40 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l73 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t24, i32 0, i32 3
  %t26 = load i32, ptr %t25
  store i32 %t26, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb52
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t29 = load i32, ptr %l4, !tbaa !23
  %t31 = sext i32 %t29 to i64
  %t34 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t28, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l24
  br label %bb6
bb6:
  %t35 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l24
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t35, ptr %l5
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 157
  %t39 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t42 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t38, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t39)
  store i1 %t42, ptr %l28
  br label %bb7
bb7:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/free:Free", ptr %t47, i32 0, i32 178
  %t50 = load i64, ptr %t49, !tbaa !24
  %t53 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t50)
  store ptr %t53, ptr %l33
  br label %bb11
bb11:
  %t54 = load ptr, ptr %l33, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Body", ptr %t54, i32 0, i32 1
  %t57 = load { i64, [2 x i64] }, ptr %t56
  %t61 = extractvalue { i64, [2 x i64] } %t57, 0
  %t62 = icmp eq i64 %t61, 6
  br i1 %t62, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_bb5f0dfb007b1fe9_f99f55ed89f1afa5)
  unreachable
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i32, ptr %l2, !tbaa !23
  %t68 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %t64, i32 %t65)
  store i1 %t68, ptr %l40
  br label %bb21
bb21:
  %t69 = load i1, ptr %l40, !tbaa !21
  store i1 %t69, ptr %l7, !tbaa !21
  %t70 = load i1, ptr %l7, !tbaa !21
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load i32, ptr %l2, !tbaa !23
  %t78 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %t74, i32 %t75)
  store i1 %t78, ptr %l46
  br label %bb24
bb23:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  %t79 = load i1, ptr %l46, !tbaa !21
  store i1 %t79, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t80 = load i1, ptr %l43, !tbaa !21
  store i1 %t80, ptr %l8, !tbaa !21
  %t81 = load i1, ptr %l7, !tbaa !21
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb26, label %bb27
bb26:
  %t85 = load i1, ptr %l8, !tbaa !21
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l49, !tbaa !21
  br label %bb28
bb27:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb28
bb28:
  %t89 = load i1, ptr %l49, !tbaa !21
  br i1 %t89, label %bb29, label %bb30
bb29:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l2, !tbaa !23
  %t94 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayCand(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l55
  br label %bb31
bb30:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb32
bb31:
  %t95 = load i1, ptr %l55, !tbaa !21
  store i1 %t95, ptr %l52, !tbaa !21
  br label %bb32
bb32:
  %t96 = load i1, ptr %l52, !tbaa !21
  store i1 %t96, ptr %l9, !tbaa !21
  %t97 = load i1, ptr %l7, !tbaa !21
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb33, label %bb34
bb33:
  %t101 = load i1, ptr %l8, !tbaa !21
  %t103 = xor i1 %t101, true
  store i1 %t103, ptr %l58, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb35
bb35:
  %t105 = load i1, ptr %l58, !tbaa !21
  br i1 %t105, label %bb36, label %bb37
bb36:
  %t106 = load i1, ptr %l9, !tbaa !21
  %t108 = xor i1 %t106, true
  store i1 %t108, ptr %l61, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb38
bb38:
  %t110 = load i1, ptr %l61, !tbaa !21
  br i1 %t110, label %bb39, label %bb40
bb39:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l2, !tbaa !23
  %t115 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l67
  br label %bb41
bb40:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb42
bb41:
  %t116 = load i1, ptr %l67, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l64, !tbaa !21
  br label %bb42
bb42:
  %t119 = load i1, ptr %l64, !tbaa !21
  br i1 %t119, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb44:
  br label %bb45
bb45:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t122 = load i1, ptr %l8, !tbaa !21
  %t123 = load i32, ptr %l2, !tbaa !23
  %t128 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t120, i32 %t121, i64 -4, i1 %t122, i32 %t123, i1 false)
  store i64 %t128, ptr %l73
  br label %bb46
bb46:
  %t129 = load i64, ptr %l73, !tbaa !24
  store i64 %t129, ptr %l10, !tbaa !24
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/free:Free", ptr %t130, i32 0, i32 12
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i1, ptr %l7, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t132, i64 %t133, i1 %t134)
  br label %bb47
bb47:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:Free", ptr %t138, i32 0, i32 13
  %t141 = load i64, ptr %l10, !tbaa !24
  %t142 = load i1, ptr %l9, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t140, i64 %t141, i1 %t142)
  br label %bb48
bb48:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/free:Free", ptr %t146, i32 0, i32 158
  %t149 = load i64, ptr %l10, !tbaa !24
  %t150 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t148, i64 %t149, i64 %t150)
  br label %bb49
bb49:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/free:Free", ptr %t154, i32 0, i32 159
  %t157 = load i64, ptr %l10, !tbaa !24
  %t158 = load i32, ptr %l4, !tbaa !23
  %t160 = sext i32 %t158 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t156, i64 %t157, i64 %t160)
  br label %bb50
bb50:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/free:Free", ptr %t164, i32 0, i32 157
  %t167 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t168 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t166, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t167, i64 %t168)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_4607beb6ac2e2918_142733ac3129574)
  unreachable
bb57:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandedToC(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i1
  %l10 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 18
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb5
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 19
  store ptr %t20, ptr %l10, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 0
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t28 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t24, i64 %a1)
  store i64 %t28, ptr %l14
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l10, !tbaa !29
  %t30 = load i64, ptr %l14, !tbaa !24
  %t31 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t31, ptr %l15
  br label %bb4
bb4:
  %t32 = load i1, ptr %l15, !tbaa !21
  store i1 %t32, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l6, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb7:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:Free", ptr %t34, i32 0, i32 0
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = call i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinksOwnC(ptr %v0, ptr %t40)
  store i1 %t42, ptr %l20
  br label %bb8
bb8:
  %t43 = load i1, ptr %l20, !tbaa !21
  store i1 %t43, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t44 = load i1, ptr %l16, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholderIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"compiler/typed:Local"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca ptr
  %l31 = alloca %"compiler/typed:Local"
  %l35 = alloca i1
  %l42 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l77 = alloca i1
  %l78 = alloca i1
  %l82 = alloca i1
  %l86 = alloca i64
  %l90 = alloca i64
  %l93 = alloca i64
  %l114 = alloca i64
  %l117 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca ptr
  %l122 = alloca ptr
  %l126 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i1
  %l139 = alloca i64
  %l143 = alloca i64
  %l146 = alloca i64
  %l167 = alloca i64
  %l171 = alloca i64
  %l176 = alloca i1
  %l177 = alloca i64
  %l180 = alloca i64
  %l182 = alloca i1
  %l186 = alloca ptr
  %l188 = alloca i1
  %l192 = alloca ptr
  %l196 = alloca i64
  %l200 = alloca ptr
  %l204 = alloca %"compiler/typed:Local"
  %l205 = alloca i32
  %l209 = alloca %"compiler/typed:Local"
  %l211 = alloca i1
  %l213 = alloca i1
  %l220 = alloca i1
  %l230 = alloca i1
  %s9 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l23, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l2, !tbaa !24
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store ptr %t11, ptr %l27
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l27, !tbaa !29
  store ptr %t12, ptr %l6, !tbaa !29
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t15 = getelementptr %"compiler/typed:Body", ptr %t13, i32 0, i32 7
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/typed:Local" %t19, ptr %l31
  br label %bb3
bb3:
  %t20 = load %"compiler/typed:Local", ptr %l31
  store %"compiler/typed:Local" %t20, ptr %l7
  %t21 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 7}
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  %t29 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 4
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 7}
  %t32 = trunc i64 3 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  store i1 %t35, ptr %l35, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb6
bb6:
  %t37 = load i1, ptr %l35, !tbaa !21
  br i1 %t37, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = icmp sgt i64 %t39, 3
  br i1 %t41, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb12
bb11:
  %t43 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 6
  %t44 = load i1, ptr %t43, !tbaa !21
  store i1 %t44, ptr %l42, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l42, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb16
bb14:
  %t47 = load ptr, ptr %l5, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t49 = load i32, ptr %t48, !tbaa !23
  %t52 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t47, i32 %t49)
  store i1 %t52, ptr %l47
  br label %bb15
bb15:
  %t53 = load i1, ptr %l47, !tbaa !21
  store i1 %t53, ptr %l44, !tbaa !21
  br label %bb16
bb16:
  %t54 = load i1, ptr %l44, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb20
bb18:
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t56 = getelementptr %"compiler/typed:Local", ptr %l7, i32 0, i32 2
  %t57 = load i32, ptr %t56, !tbaa !23
  %t60 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t55, i32 %t57)
  store i1 %t60, ptr %l51
  br label %bb19
bb19:
  %t61 = load i1, ptr %l51, !tbaa !21
  %t62 = xor i1 %t61, true
  store i1 %t62, ptr %l48, !tbaa !21
  br label %bb20
bb20:
  %t64 = load i1, ptr %l48, !tbaa !21
  br i1 %t64, label %bb21, label %bb22
bb21:
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t68 = getelementptr %"compiler/typed:LocalUses", ptr %t66, i32 0, i32 8
  %t69 = load i64, ptr %l3, !tbaa !24
  %t72 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t68, i64 %t69)
  store i1 %t72, ptr %l57
  br label %bb24
bb24:
  %t73 = load i1, ptr %l57, !tbaa !21
  br i1 %t73, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb28
bb26:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr %"compiler/typed:LocalUses", ptr %t74, i32 0, i32 39
  %t77 = load i64, ptr %l3, !tbaa !24
  %t80 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t76, i64 %t77)
  store i1 %t80, ptr %l62
  br label %bb27
bb27:
  %t81 = load i1, ptr %l62, !tbaa !21
  store i1 %t81, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t82 = load i1, ptr %l58, !tbaa !21
  br i1 %t82, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb32
bb30:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/typed:LocalUses", ptr %t83, i32 0, i32 40
  %t86 = load i64, ptr %l3, !tbaa !24
  %t89 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t85, i64 %t86)
  store i1 %t89, ptr %l67
  br label %bb31
bb31:
  %t90 = load i1, ptr %l67, !tbaa !21
  store i1 %t90, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t91 = load i1, ptr %l63, !tbaa !21
  br i1 %t91, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb36
bb34:
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t94 = getelementptr %"compiler/typed:LocalUses", ptr %t92, i32 0, i32 42
  %t95 = load i64, ptr %l3, !tbaa !24
  %t98 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t94, i64 %t95)
  store i1 %t98, ptr %l72
  br label %bb35
bb35:
  %t99 = load i1, ptr %l72, !tbaa !21
  store i1 %t99, ptr %l68, !tbaa !21
  br label %bb36
bb36:
  %t100 = load i1, ptr %l68, !tbaa !21
  br i1 %t100, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb40
bb38:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/typed:LocalUses", ptr %t101, i32 0, i32 43
  %t104 = load i64, ptr %l3, !tbaa !24
  %t107 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v1, ptr %t103, i64 %t104)
  store i1 %t107, ptr %l77
  br label %bb39
bb39:
  %t108 = load i1, ptr %l77, !tbaa !21
  store i1 %t108, ptr %l73, !tbaa !21
  br label %bb40
bb40:
  %t109 = load i1, ptr %l73, !tbaa !21
  br i1 %t109, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l78, !tbaa !21
  br label %bb44
bb42:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/typed:LocalUses", ptr %t110, i32 0, i32 45
  %t113 = load i64, ptr %l3, !tbaa !24
  %t116 = call i1 @compiler_2ffree_2ehas(ptr %v1, ptr %t112, i64 %t113)
  store i1 %t116, ptr %l82
  br label %bb43
bb43:
  %t117 = load i1, ptr %l82, !tbaa !21
  store i1 %t117, ptr %l78, !tbaa !21
  br label %bb44
bb44:
  %t118 = load i1, ptr %l78, !tbaa !21
  br i1 %t118, label %bb45, label %bb46
bb45:
  store i1 false, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  store i64 0, ptr %l8, !tbaa !24
  %t120 = load ptr, ptr %l1, !tbaa !29
  %t122 = getelementptr %"compiler/typed:LocalUses", ptr %t120, i32 0, i32 24
  %t124 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t122)
  store i64 %t124, ptr %l86
  br label %bb48
bb48:
  %t125 = load i64, ptr %l86, !tbaa !24
  store i64 %t125, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l8, !tbaa !24
  %t130 = icmp sgt i64 %t126, %t127
  br i1 %t130, label %bb49, label %bb50
bb49:
  %t132 = load i64, ptr %l10, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb54
bb51:
  %t136 = load i64, ptr %l9, !tbaa !24
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l10, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l93, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb53
bb53:
  %t152 = load i64, ptr %l93, !tbaa !24
  store i64 %t152, ptr %l90, !tbaa !24
  br label %bb54
bb54:
  %t153 = load i64, ptr %l90, !tbaa !24
  store i64 %t153, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb55
bb55:
  %t154 = load i64, ptr %l12, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb56, label %bb57
bb56:
  br label %bb70
bb57:
  br label %bb58
bb58:
  %t162 = load i64, ptr %l8, !tbaa !24
  %t163 = load i64, ptr %l12, !tbaa !24
  %t164 = load i64, ptr %l10, !tbaa !24
  %t167 = mul i64 %t163, %t164
  %t170 = add i64 %t162, %t167
  store i64 %t170, ptr %l13, !tbaa !24
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t174 = getelementptr %"compiler/typed:LocalUses", ptr %t172, i32 0, i32 24
  %t175 = load i64, ptr %l13, !tbaa !24
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t174, i64 %t175)
  store i64 %t178, ptr %l114
  br label %bb59
bb59:
  %t179 = load i64, ptr %l3, !tbaa !24
  %t180 = load i64, ptr %l114, !tbaa !24
  %t182 = icmp eq i64 %t180, %t179
  br i1 %t182, label %bb60, label %bb61
bb60:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/free:Free", ptr %t184, i32 0, i32 27
  store ptr %t186, ptr %l119, !tbaa !29
  %t187 = load ptr, ptr %l5, !tbaa !29
  store ptr %t187, ptr %l120, !tbaa !29
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:Free", ptr %t188, i32 0, i32 1
  store ptr %t190, ptr %l122, !tbaa !29
  %t191 = load ptr, ptr %l1, !tbaa !29
  %t193 = getelementptr %"compiler/typed:LocalUses", ptr %t191, i32 0, i32 25
  %t194 = load i64, ptr %l13, !tbaa !24
  %t197 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t193, i64 %t194)
  store i64 %t197, ptr %l126
  br label %bb62
bb61:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb65
bb62:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr %"compiler/typed:LocalUses", ptr %t198, i32 0, i32 26
  %t201 = load i64, ptr %l13, !tbaa !24
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t200, i64 %t201)
  store i64 %t204, ptr %l130
  br label %bb63
bb63:
  %t205 = load ptr, ptr %l119, !tbaa !29
  %t206 = load ptr, ptr %l120, !tbaa !29
  %t207 = load ptr, ptr %l122, !tbaa !29
  %t208 = load i64, ptr %l126, !tbaa !24
  %t209 = load i64, ptr %l130, !tbaa !24
  %t210 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v0, ptr %v0, ptr %t205, ptr %t206, ptr %t207, i64 %t208, i64 %t209, i1 false)
  store i1 %t210, ptr %l131
  br label %bb64
bb64:
  %t211 = load i1, ptr %l131, !tbaa !21
  %t212 = xor i1 %t211, true
  store i1 %t212, ptr %l117, !tbaa !21
  br label %bb65
bb65:
  %t214 = load i1, ptr %l117, !tbaa !21
  br i1 %t214, label %bb66, label %bb67
bb66:
  store i1 false, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t216 = load i64, ptr %l12, !tbaa !24
  %t219 = add i64 %t216, 1
  store i64 %t219, ptr %l12, !tbaa !24
  br label %bb55
bb70:
  store i64 0, ptr %l14, !tbaa !24
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr %"compiler/typed:LocalUses", ptr %t221, i32 0, i32 50
  %t225 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t223)
  store i64 %t225, ptr %l139
  br label %bb71
bb71:
  %t226 = load i64, ptr %l139, !tbaa !24
  store i64 %t226, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t227 = load i64, ptr %l15, !tbaa !24
  %t228 = load i64, ptr %l14, !tbaa !24
  %t231 = icmp sgt i64 %t227, %t228
  br i1 %t231, label %bb72, label %bb73
bb72:
  %t233 = load i64, ptr %l16, !tbaa !24
  %t235 = icmp sgt i64 %t233, 0
  br i1 %t235, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l143, !tbaa !24
  br label %bb77
bb74:
  %t237 = load i64, ptr %l15, !tbaa !24
  %t238 = load i64, ptr %l14, !tbaa !24
  %t241 = sub i64 %t237, %t238
  %t242 = load i64, ptr %l16, !tbaa !24
  %t245 = add i64 %t241, %t242
  %t247 = sub i64 %t245, 1
  %t248 = load i64, ptr %l16, !tbaa !24
  %t251 = sdiv i64 %t247, %t248
  store i64 %t251, ptr %l146, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb76
bb76:
  %t253 = load i64, ptr %l146, !tbaa !24
  store i64 %t253, ptr %l143, !tbaa !24
  br label %bb77
bb77:
  %t254 = load i64, ptr %l143, !tbaa !24
  store i64 %t254, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s9
  %t255 = load i64, ptr %l18, !tbaa !24
  %t256 = load i64, ptr %l17, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s9)
  br label %bb117
bb80:
  br label %bb81
bb81:
  %t263 = load i64, ptr %l14, !tbaa !24
  %t264 = load i64, ptr %l18, !tbaa !24
  %t265 = load i64, ptr %l16, !tbaa !24
  %t268 = mul i64 %t264, %t265
  %t271 = add i64 %t263, %t268
  store i64 %t271, ptr %l19, !tbaa !24
  %t273 = load ptr, ptr %l1, !tbaa !29
  %t275 = getelementptr %"compiler/typed:LocalUses", ptr %t273, i32 0, i32 49
  %t276 = load i64, ptr %l19, !tbaa !24
  %t279 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t275, i64 %t276)
  store i64 %t279, ptr %l167
  br label %bb82
bb82:
  %t280 = load i64, ptr %l167, !tbaa !24
  store i64 %t280, ptr %l20, !tbaa !24
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr %"compiler/typed:LocalUses", ptr %t281, i32 0, i32 50
  %t284 = load i64, ptr %l19, !tbaa !24
  %t287 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t283, i64 %t284)
  store i64 %t287, ptr %l171
  br label %bb83
bb83:
  %t288 = load i64, ptr %l3, !tbaa !24
  %t289 = load i64, ptr %l171, !tbaa !24
  %t291 = icmp ne i64 %t289, %t288
  br i1 %t291, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s9)
  br label %bb116
bb85:
  br label %bb86
bb86:
  %t293 = load i64, ptr %l20, !tbaa !24
  %t295 = icmp slt i64 %t293, 0
  br i1 %t295, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb90
bb88:
  %t297 = load i64, ptr %l20, !tbaa !24
  store i64 %t297, ptr %l177, !tbaa !24
  %t298 = load ptr, ptr %l6, !tbaa !29
  %t300 = getelementptr %"compiler/typed:Body", ptr %t298, i32 0, i32 7
  %t302 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t300)
  store i64 %t302, ptr %l180
  br label %bb89
bb89:
  %t303 = load i64, ptr %l177, !tbaa !24
  %t304 = load i64, ptr %l180, !tbaa !24
  %t305 = icmp sge i64 %t303, %t304
  store i1 %t305, ptr %l176, !tbaa !21
  br label %bb90
bb90:
  %t307 = load i1, ptr %l176, !tbaa !21
  br i1 %t307, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb94
bb92:
  %t308 = load ptr, ptr %l1, !tbaa !29
  %t310 = getelementptr %"compiler/typed:LocalUses", ptr %t308, i32 0, i32 20
  %t311 = load i64, ptr %l20, !tbaa !24
  %t314 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %s9, ptr %t310, i64 %t311)
  store ptr %t314, ptr %l186
  br label %bb93
bb93:
  %t315 = load ptr, ptr %l186, !tbaa !29
  %t316 = icmp eq ptr %t315, null
  store i1 %t316, ptr %l182, !tbaa !21
  br label %bb94
bb94:
  %t318 = load i1, ptr %l182, !tbaa !21
  br i1 %t318, label %bb95, label %bb96
bb95:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb102
bb96:
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr %"compiler/typed:LocalUses", ptr %t319, i32 0, i32 20
  %t322 = load i64, ptr %l20, !tbaa !24
  %t325 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v1, ptr %v1, ptr %t321, i64 %t322)
  store ptr %t325, ptr %l192
  br label %bb97
bb97:
  %t326 = load ptr, ptr %l192, !tbaa !29
  store ptr %t326, ptr %l21, !tbaa !29
  %t327 = load ptr, ptr %l21, !tbaa !29
  %t329 = icmp eq ptr %t327, null
  br i1 %t329, label %bb98, label %bb99
bb98:
  call void @__olang_check_failed(ptr @olang_loc_9ed3d3979443b16_3c0955d42b886a3a)
  unreachable
bb99:
  br label %bb100
bb100:
  %t331 = load ptr, ptr %l21, !tbaa !29
  %t333 = call i64 @compiler_2ffree_2ereadsLocal(ptr %v1, ptr %t331)
  store i64 %t333, ptr %l196
  br label %bb101
bb101:
  %t334 = load i64, ptr %l3, !tbaa !24
  %t335 = load i64, ptr %l196, !tbaa !24
  %t337 = icmp ne i64 %t335, %t334
  store i1 %t337, ptr %l188, !tbaa !21
  br label %bb102
bb102:
  %t339 = load i1, ptr %l188, !tbaa !21
  br i1 %t339, label %bb103, label %bb104
bb103:
  call void @__olang_scope_close(ptr %s9)
  store i1 false, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  %t341 = load ptr, ptr %l6, !tbaa !29
  store ptr %t341, ptr %l200, !tbaa !29
  %t342 = load ptr, ptr %l6, !tbaa !29
  %t344 = getelementptr %"compiler/typed:Body", ptr %t342, i32 0, i32 7
  %t345 = load i64, ptr %l3, !tbaa !24
  %t348 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t344, i64 %t345)
  store %"compiler/typed:Local" %t348, ptr %l204
  br label %bb106
bb106:
  %t349 = getelementptr %"compiler/typed:Local", ptr %l204, i32 0, i32 3
  %t350 = load i32, ptr %t349, !tbaa !23
  store i32 %t350, ptr %l205, !tbaa !23
  %t351 = load ptr, ptr %l6, !tbaa !29
  %t353 = getelementptr %"compiler/typed:Body", ptr %t351, i32 0, i32 7
  %t354 = load i64, ptr %l20, !tbaa !24
  %t357 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t353, i64 %t354)
  store %"compiler/typed:Local" %t357, ptr %l209
  br label %bb107
bb107:
  %t358 = getelementptr %"compiler/typed:Local", ptr %l209, i32 0, i32 3
  %t359 = load i32, ptr %t358, !tbaa !23
  %t360 = load ptr, ptr %l200, !tbaa !29
  %t361 = load i32, ptr %l205, !tbaa !23
  %t363 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %t360, i32 %t361, i32 %t359)
  store i1 %t363, ptr %l211
  br label %bb108
bb108:
  %t364 = load i1, ptr %l211, !tbaa !21
  %t365 = xor i1 %t364, true
  br i1 %t365, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l213, !tbaa !21
  br label %bb112
bb110:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load ptr, ptr %l1, !tbaa !29
  %t369 = load i64, ptr %l2, !tbaa !24
  %t370 = load i64, ptr %l20, !tbaa !24
  %t371 = load i64, ptr %l4, !tbaa !24
  %t373 = add i64 %t371, 1
  %t379 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholderIn(ptr %v0, ptr %v1, ptr %t367, ptr %t368, i64 %t369, i64 %t370, i64 %t373)
  store i1 %t379, ptr %l220
  br label %bb111
bb111:
  %t380 = load i1, ptr %l220, !tbaa !21
  %t381 = xor i1 %t380, true
  store i1 %t381, ptr %l213, !tbaa !21
  br label %bb112
bb112:
  %t383 = load i1, ptr %l213, !tbaa !21
  br i1 %t383, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s9)
  store i1 false, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s9)
  br label %bb116
bb116:
  %t385 = load i64, ptr %l18, !tbaa !24
  %t388 = add i64 %t385, 1
  store i64 %t388, ptr %l18, !tbaa !24
  br label %bb78
bb117:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l1, !tbaa !29
  %t392 = load i64, ptr %l2, !tbaa !24
  %t393 = load i64, ptr %l3, !tbaa !24
  %t398 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepsNone(ptr %v0, ptr %v1, ptr %t390, ptr %t391, i64 %t392, i64 %t393, i64 0, i1 true)
  store i1 %t398, ptr %l230
  br label %bb118
bb118:
  %t399 = load i1, ptr %l230, !tbaa !21
  store i1 %t399, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholderRows(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca %"compiler/free:store"
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca i64
  %l49 = alloca i32
  %l53 = alloca %"compiler/free:store"
  %l54 = alloca ptr
  %l55 = alloca i64
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca i32
  %l87 = alloca { i64, ptr }
  %l89 = alloca i1
  %l105 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l14
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:Free", ptr %t3, i32 0, i32 0
  %t6 = load ptr, ptr %t5, !tbaa !29
  %t8 = getelementptr %"compiler/generic:Program", ptr %t6, i32 0, i32 0
  %t9 = load ptr, ptr %t8, !tbaa !29
  %t11 = getelementptr %"compiler/load:Loader", ptr %t9, i32 0, i32 4
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 32
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l21
  br label %bb2
bb2:
  %t19 = load i64, ptr %l21, !tbaa !24
  store i64 %t19, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = load i64, ptr %l3, !tbaa !24
  %t24 = icmp sgt i64 %t20, %t21
  br i1 %t24, label %bb3, label %bb4
bb3:
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = icmp sgt i64 %t26, 0
  br i1 %t28, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb8
bb5:
  %t30 = load i64, ptr %l4, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = sub i64 %t30, %t31
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = add i64 %t34, %t35
  %t40 = sub i64 %t38, 1
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = sdiv i64 %t40, %t41
  store i64 %t44, ptr %l28, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb7
bb7:
  %t46 = load i64, ptr %l28, !tbaa !24
  store i64 %t46, ptr %l25, !tbaa !24
  br label %bb8
bb8:
  %t47 = load i64, ptr %l25, !tbaa !24
  store i64 %t47, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb11:
  br label %bb12
bb12:
  %t56 = load i64, ptr %l3, !tbaa !24
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l5, !tbaa !24
  %t61 = mul i64 %t57, %t58
  %t64 = add i64 %t56, %t61
  store i64 %t64, ptr %l8, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:Free", ptr %t66, i32 0, i32 32
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t68, i64 %t69)
  store i32 %t72, ptr %l49
  br label %bb13
bb13:
  %t73 = load i32, ptr %l49, !tbaa !23
  store i32 %t73, ptr %l9, !tbaa !23
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 33
  %t77 = load i64, ptr %l8, !tbaa !24
  %t80 = call %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v0, ptr %t76, i64 %t77)
  store %"compiler/free:store" %t80, ptr %l53
  br label %bb14
bb14:
  %t81 = load %"compiler/free:store", ptr %l53
  store %"compiler/free:store" %t81, ptr %l10
  %t82 = load ptr, ptr %l2, !tbaa !29
  store ptr %t82, ptr %l54, !tbaa !29
  %t83 = getelementptr %"compiler/free:store", ptr %l10, i32 0, i32 2
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l55, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/free:store", ptr %l10, i32 0, i32 2
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = getelementptr %"compiler/free:store", ptr %l10, i32 0, i32 3
  %t89 = getelementptr %"compiler/source:Span", ptr %t88, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  %t92 = sext i32 %t90 to i64
  %t96 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %t85, i64 %t87, i64 %t92)
  store i64 %t96, ptr %l60
  br label %bb15
bb15:
  %t97 = load ptr, ptr %l54, !tbaa !29
  %t98 = load i64, ptr %l55, !tbaa !24
  %t99 = load i64, ptr %l60, !tbaa !24
  %t100 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %s2, ptr %t97, i64 %t98, i64 %t99)
  store { i64, ptr } %t100, ptr %l61
  br label %bb16
bb16:
  %t101 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 1
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t104 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t102, i64 %t103)
  %t105 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l11, !tbaa !27
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/free:Free", ptr %t108, i32 0, i32 31
  %t111 = load i32, ptr %l9, !tbaa !23
  %t114 = call { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hdc5ed4f57090b33f7a83fc7b2b1f05b3(ptr %v0, ptr %s2, ptr %t110, i32 %t111)
  %t115 = extractvalue { i32, { i64, ptr } } %t114, 1
  %t116 = extractvalue { i32, { i64, ptr } } %t114, 0
  store i32 %t116, ptr %l68
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb18, label %ok.118, !prof !99
ok.118:
  store { i64, ptr } %t115, ptr %l67
  br label %bb17
bb17:
  %t119 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 0
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load i64, ptr %l69, !tbaa !24
  %t122 = mul i64 %t121, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t122)
  %t124 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  store { i64, ptr } %t125, ptr %l70, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l69, !tbaa !24
  %t131 = mul i64 %t130, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t127, ptr %t129, i64 %t131, i1 false)
  %t132 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t132, ptr %l63, !tbaa !27
  br label %bb20
bb18:
  br label %bb19
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l71, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t133, ptr %l63, !tbaa !27
  br label %bb20
bb20:
  %t135 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l73, !tbaa !24
  %t137 = load i64, ptr %l73, !tbaa !24
  %t138 = mul i64 %t137, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  store { i64, ptr } %t141, ptr %l74, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = load i64, ptr %l73, !tbaa !24
  %t147 = mul i64 %t146, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t143, ptr %t145, i64 %t147, i1 false)
  %t148 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t148, ptr %l12, !tbaa !27
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t149)
  store ptr %t151, ptr %l76
  br label %bb21
bb21:
  %t152 = load ptr, ptr %l76, !tbaa !29
  %t154 = getelementptr %"compiler/types:Table", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  store ptr %t155, ptr %l78, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t156)
  store ptr %t158, ptr %l80
  br label %bb22
bb22:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t159)
  store ptr %t161, ptr %l82
  br label %bb23
bb23:
  %t162 = load i32, ptr %l9, !tbaa !23
  %t163 = load ptr, ptr %l82, !tbaa !29
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t163, i32 %t162)
  store i32 %t165, ptr %l84
  br label %bb24
bb24:
  %t166 = load ptr, ptr %l80, !tbaa !29
  %t167 = load i32, ptr %l84, !tbaa !23
  %t168 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t166, i32 %t167)
  store i32 %t168, ptr %l85
  br label %bb25
bb25:
  %t169 = load ptr, ptr %l78, !tbaa !29
  %t170 = call ptr @__olang_scope_of(ptr %t169, ptr null)
  %t171 = call ptr @__olang_scope_hold(ptr %t170)
  %t172 = ptrtoint ptr %t171 to i64
  %t174 = inttoptr i64 %t172 to ptr
  %t175 = load ptr, ptr %l78, !tbaa !29
  %t176 = load i32, ptr %l85, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t174, ptr %s2, ptr %t175, i32 %t176)
  store { i64, ptr } %t177, ptr %l87
  br label %bb26
bb26:
  %t178 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t178, ptr %l13, !tbaa !27
  %t179 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t181 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t179, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t181, ptr %l89
  br label %bb27
bb27:
  %t182 = load i1, ptr %l89, !tbaa !21
  br i1 %t182, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t183 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = extractvalue { i64, ptr } %t183, 0
  %t188 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t189 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t190 = add i64 %t187, %t189
  %t192 = extractvalue { i64, ptr } %t184, 1
  %t193 = extractvalue { i64, ptr } %t184, 0
  %t194 = add i64 %t190, %t193
  %t195 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t196 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t197 = add i64 %t194, %t196
  %t198 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t186, i64 %t187)
  %t199 = getelementptr i8, ptr %t198, i64 %t187
  call void @olang_textcopy(ptr %t199, ptr %t188, i64 %t189)
  %t200 = getelementptr i8, ptr %t199, i64 %t189
  call void @olang_textcopy(ptr %t200, ptr %t192, i64 %t193)
  %t201 = getelementptr i8, ptr %t200, i64 %t193
  call void @olang_textcopy(ptr %t201, ptr %t195, i64 %t196)
  %t202 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t198, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s4, ptr %l1, { i64, ptr } %t203)
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb31:
  %t207 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t207, 1
  %t212 = extractvalue { i64, ptr } %t207, 0
  %t213 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t217 = extractvalue { i64, ptr } %t208, 1
  %t218 = extractvalue { i64, ptr } %t208, 0
  %t219 = add i64 %t215, %t218
  %t220 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t221 = extractvalue { i64, ptr } { i64 67, ptr getelementptr inbounds (<{ i64, [67 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t222 = add i64 %t219, %t221
  %t224 = extractvalue { i64, ptr } %t209, 1
  %t225 = extractvalue { i64, ptr } %t209, 0
  %t226 = add i64 %t222, %t225
  %t227 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t228 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t229 = add i64 %t226, %t228
  %t230 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t211, i64 %t212)
  %t231 = getelementptr i8, ptr %t230, i64 %t212
  call void @olang_textcopy(ptr %t231, ptr %t213, i64 %t214)
  %t232 = getelementptr i8, ptr %t231, i64 %t214
  call void @olang_textcopy(ptr %t232, ptr %t217, i64 %t218)
  %t233 = getelementptr i8, ptr %t232, i64 %t218
  call void @olang_textcopy(ptr %t233, ptr %t220, i64 %t221)
  %t234 = getelementptr i8, ptr %t233, i64 %t221
  call void @olang_textcopy(ptr %t234, ptr %t224, i64 %t225)
  %t235 = getelementptr i8, ptr %t234, i64 %t225
  call void @olang_textcopy(ptr %t235, ptr %t227, i64 %t228)
  %t236 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t230, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l1, { i64, ptr } %t237)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t241 = load i64, ptr %l7, !tbaa !24
  %t244 = add i64 %t241, 1
  store i64 %t244, ptr %l7, !tbaa !24
  br label %bb9
bb34:
  %t247 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t247, ptr %l105
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t248 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t248, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca ptr
  %l28 = alloca i32
  %l31 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i32
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca i32
  %l62 = alloca i1
  %l63 = alloca ptr
  %l66 = alloca i32
  %l67 = alloca { i64, ptr }
  %l73 = alloca i64
  %l76 = alloca i64
  %l99 = alloca i1
  %l101 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca i32
  %l115 = alloca i1
  %l117 = alloca ptr
  %l120 = alloca i32
  %l121 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l133 = alloca ptr
  %l136 = alloca i32
  %l137 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l147 = alloca ptr
  %l150 = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l23, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp sgt i64 %t5, 32
  br i1 %t7, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l28
  br label %bb5
bb5:
  %t14 = load i32, ptr %l28, !range !{i32 0, i32 33}
  store i32 %t14, ptr %l5
  %t15 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t17 = trunc i64 20 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l4, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l34
  br label %bb8
bb7:
  br label %bb15
bb8:
  %t26 = load ptr, ptr %l31, !tbaa !29
  %t27 = load i32, ptr %l34, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t28, ptr %l35
  br label %bb9
bb9:
  %t29 = load i32, ptr %l35, !tbaa !23
  store i32 %t29, ptr %l6, !tbaa !23
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:Free", ptr %t30, i32 0, i32 35
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t34 = load i32, ptr %l6, !tbaa !23
  %t38 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v0, ptr %t32, ptr %t33, i32 %t34)
  store i1 %t38, ptr %l40
  br label %bb10
bb10:
  %t39 = load i1, ptr %l40, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t41 = load i32, ptr %l6, !tbaa !23
  %t43 = sext i32 %t41 to i64
  %t46 = call i64 @compiler_2ffree_2eaddTo(ptr %v1, ptr %t40, i64 %t43)
  store i64 %t46, ptr %l44
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %ret
bb15:
  %t47 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t49 = trunc i64 19 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb16, label %bb17
bb16:
  %t52 = load ptr, ptr %l4, !tbaa !29
  %t53 = load i32, ptr %l1, !tbaa !23
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t52, i32 %t53)
  store i32 %t56, ptr %l49
  br label %bb18
bb17:
  br label %bb25
bb18:
  %t57 = load i32, ptr %l49, !tbaa !23
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  store ptr %t60, ptr %l51, !tbaa !29
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %l52, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i32, ptr %l1, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l55
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t67 = load ptr, ptr %l52, !tbaa !29
  %t68 = load i32, ptr %l55, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t69, ptr %l56
  br label %bb22
bb22:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t73 = add i64 %t71, 1
  %t74 = load ptr, ptr %l51, !tbaa !29
  %t75 = load i32, ptr %l56, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %t74, i32 %t75, ptr %t70, i64 %t73)
  br label %bb23
bb23:
  br label %bb24
bb24:
  br label %ret
bb25:
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t79 = load i32, ptr %l1, !tbaa !23
  %t82 = call i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %t78, i32 %t79)
  store i1 %t82, ptr %l62
  br label %bb26
bb26:
  %t83 = load i1, ptr %l62, !tbaa !21
  br i1 %t83, label %bb27, label %bb28
bb27:
  %t84 = load ptr, ptr %l4, !tbaa !29
  store ptr %t84, ptr %l63, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t86 = load i32, ptr %l1, !tbaa !23
  %t89 = call i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %t85, i32 %t86)
  store i32 %t89, ptr %l66
  br label %bb29
bb28:
  br label %bb49
bb29:
  %t90 = load ptr, ptr %l63, !tbaa !29
  %t91 = load i32, ptr %l66, !tbaa !23
  %t92 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t90, i32 %t91)
  store { i64, ptr } %t92, ptr %l67
  br label %bb30
bb30:
  %t93 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t93, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l9, !tbaa !24
  %t99 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t98, %t99
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load i64, ptr %l10, !tbaa !24
  %t106 = icmp sgt i64 %t104, 0
  br i1 %t106, label %bb33, label %bb34
bb32:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb36
bb33:
  %t108 = load i64, ptr %l9, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  %t112 = sub i64 %t108, %t109
  %t113 = load i64, ptr %l10, !tbaa !24
  %t116 = add i64 %t112, %t113
  %t118 = sub i64 %t116, 1
  %t119 = load i64, ptr %l10, !tbaa !24
  %t122 = sdiv i64 %t118, %t119
  store i64 %t122, ptr %l76, !tbaa !24
  br label %bb35
bb34:
  store i64 0, ptr %l76, !tbaa !24
  br label %bb35
bb35:
  %t124 = load i64, ptr %l76, !tbaa !24
  store i64 %t124, ptr %l73, !tbaa !24
  br label %bb36
bb36:
  %t125 = load i64, ptr %l73, !tbaa !24
  store i64 %t125, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  %t126 = load i64, ptr %l12, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = icmp slt i64 %t126, %t127
  %t132 = xor i1 %t130, true
  br i1 %t132, label %bb38, label %bb39
bb38:
  br label %bb48
bb39:
  br label %bb40
bb40:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = load i64, ptr %l12, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t139 = mul i64 %t135, %t136
  %t142 = add i64 %t134, %t139
  store i64 %t142, ptr %l13, !tbaa !24
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/free:Free", ptr %t144, i32 0, i32 35
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t148 = load i32, ptr %l1, !tbaa !23
  %t149 = load i64, ptr %l13, !tbaa !24
  %t154 = call i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v0, ptr %t146, ptr %t147, i32 %t148, i64 %t149)
  store i1 %t154, ptr %l99
  br label %bb41
bb41:
  %t155 = load i1, ptr %l99, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb42, label %bb43
bb42:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l101, !tbaa !29
  %t159 = load ptr, ptr %l4, !tbaa !29
  %t160 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t160, ptr %l103, !tbaa !27
  %t161 = load i64, ptr %l13, !tbaa !24
  %t163 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i32, ptr %t164, i64 %t161
  %t166 = load i32, ptr %t165, !tbaa !33
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t159, i32 %t166)
  store i32 %t169, ptr %l106
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t170 = load ptr, ptr %l2, !tbaa !29
  %t171 = load i64, ptr %l3, !tbaa !24
  %t173 = add i64 %t171, 1
  %t174 = load ptr, ptr %l101, !tbaa !29
  %t175 = load i32, ptr %l106, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %t174, i32 %t175, ptr %t170, i64 %t173)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t178 = load i64, ptr %l12, !tbaa !24
  %t181 = add i64 %t178, 1
  store i64 %t181, ptr %l12, !tbaa !24
  br label %bb37
bb48:
  br label %ret
bb49:
  %t183 = load ptr, ptr %l4, !tbaa !29
  %t184 = load i32, ptr %l1, !tbaa !23
  %t187 = call i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %t183, i32 %t184)
  store i1 %t187, ptr %l115
  br label %bb50
bb50:
  %t188 = load i1, ptr %l115, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb51, label %bb52
bb51:
  br label %ret
bb52:
  br label %bb53
bb53:
  %t191 = load ptr, ptr %l4, !tbaa !29
  store ptr %t191, ptr %l117, !tbaa !29
  %t192 = load ptr, ptr %l4, !tbaa !29
  %t193 = load i32, ptr %l1, !tbaa !23
  %t196 = call i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %t192, i32 %t193)
  store i32 %t196, ptr %l120
  br label %bb54
bb54:
  %t197 = load ptr, ptr %l117, !tbaa !29
  %t198 = load i32, ptr %l120, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t197, i32 %t198)
  store { i64, ptr } %t199, ptr %l121
  br label %bb55
bb55:
  %t200 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t200, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t201 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t201, 0
  store i64 %t203, ptr %l16, !tbaa !24
  br label %bb56
bb56:
  %t205 = load i64, ptr %l15, !tbaa !24
  %t206 = load i64, ptr %l16, !tbaa !24
  %t209 = icmp slt i64 %t205, %t206
  %t211 = xor i1 %t209, true
  br i1 %t211, label %bb57, label %bb58
bb57:
  br label %bb74
bb58:
  br label %bb59
bb59:
  %t213 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t213, ptr %l128, !tbaa !27
  %t214 = load i64, ptr %l15, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr i32, ptr %t217, i64 %t214
  %t219 = load i32, ptr %t218, !tbaa !33
  store i32 %t219, ptr %l17, !tbaa !23
  %t221 = load i32, ptr %l17, !tbaa !23
  %t223 = icmp eq i32 %t221, 0
  br i1 %t223, label %bb60, label %bb61
bb60:
  br label %bb73
bb61:
  br label %bb62
bb62:
  %t225 = load ptr, ptr %l4, !tbaa !29
  store ptr %t225, ptr %l133, !tbaa !29
  %t226 = load ptr, ptr %l4, !tbaa !29
  %t227 = load i32, ptr %l17, !tbaa !23
  %t230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t226, i32 %t227)
  store i32 %t230, ptr %l136
  br label %bb63
bb63:
  %t231 = load ptr, ptr %l133, !tbaa !29
  %t232 = load i32, ptr %l136, !tbaa !23
  %t233 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t231, i32 %t232)
  store { i64, ptr } %t233, ptr %l137
  br label %bb64
bb64:
  %t234 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t234, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l20, !tbaa !24
  br label %bb65
bb65:
  %t239 = load i64, ptr %l19, !tbaa !24
  %t240 = load i64, ptr %l20, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb66, label %bb67
bb66:
  br label %bb72
bb67:
  br label %bb68
bb68:
  %t247 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t247, ptr %l144, !tbaa !27
  %t248 = load i64, ptr %l19, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l144, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr i32, ptr %t251, i64 %t248
  %t253 = load i32, ptr %t252, !tbaa !33
  %t255 = load ptr, ptr %l0, !tbaa !29
  store ptr %t255, ptr %l147, !tbaa !29
  %t256 = load ptr, ptr %l4, !tbaa !29
  %t260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t256, i32 %t253)
  store i32 %t260, ptr %l150
  br label %bb69
bb69:
  %t261 = load ptr, ptr %l2, !tbaa !29
  %t262 = load i64, ptr %l3, !tbaa !24
  %t264 = add i64 %t262, 1
  %t265 = load ptr, ptr %l147, !tbaa !29
  %t266 = load i32, ptr %l150, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eholdsTypes(ptr %v0, ptr %v1, ptr %t265, i32 %t266, ptr %t261, i64 %t264)
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t269 = load i64, ptr %l19, !tbaa !24
  %t272 = add i64 %t269, 1
  store i64 %t272, ptr %l19, !tbaa !24
  br label %bb65
bb72:
  br label %bb73
bb73:
  %t274 = load i64, ptr %l15, !tbaa !24
  %t277 = add i64 %t274, 1
  store i64 %t277, ptr %l15, !tbaa !24
  br label %bb56
bb74:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2enoteDtor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l11 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l26 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l37 = alloca i1
  %l40 = alloca i1
  %l41 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca i32
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/free:Free", ptr %t5, i32 0, i32 1
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t7, i64 %t8)
  store ptr %t11, ptr %l11
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t14 = getelementptr %"compiler/typed:Body", ptr %t12, i32 0, i32 1
  %t15 = load { i64, [2 x i64] }, ptr %t14
  store { i64, [2 x i64] } %t15, ptr %l3
  %t17 = load { i64, [2 x i64] }, ptr %l3
  %t19 = extractvalue { i64, [2 x i64] } %t17, 0
  %t20 = icmp eq i64 %t19, 3
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t23 = getelementptr { i32 }, ptr %t22, i32 0, i32 0
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:Free", ptr %t26, i32 0, i32 183
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t30 = load i32, ptr %l4, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l21
  br label %bb6
bb6:
  %t34 = load i32, ptr %l21, !tbaa !23
  %t35 = sext i32 %t34 to i64
  %t36 = load i64, ptr %l1, !tbaa !24
  %t37 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %t37, i64 %t35, i64 %t36)
  br label %bb7
bb7:
  br label %bb33
bb8:
  %t40 = load { i64, [2 x i64] }, ptr %l3
  %t42 = extractvalue { i64, [2 x i64] } %t40, 0
  %t43 = icmp eq i64 %t42, 1
  br i1 %t43, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb28
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l2, !tbaa !29
  store ptr %t45, ptr %l26, !tbaa !29
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/free:Free", ptr %t46, i32 0, i32 1
  %t49 = load i64, ptr %l1, !tbaa !24
  %t52 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store ptr %t52, ptr %l30
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %t55, !tbaa !23
  %t57 = load ptr, ptr %l26, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %s2, ptr %t57, i32 %t56)
  store { i64, ptr } %t59, ptr %l33
  br label %bb13
bb13:
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t60, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  %t65 = icmp eq i64 %t63, 1
  br i1 %t65, label %bb14, label %bb15
bb14:
  %t67 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i32, ptr %t69, i64 0
  %t71 = load i32, ptr %t70, !tbaa !33
  %t74 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t67, i32 %t71)
  store i1 %t74, ptr %l40
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb17
bb16:
  %t75 = load i1, ptr %l40, !tbaa !21
  store i1 %t75, ptr %l37, !tbaa !21
  br label %bb17
bb17:
  %t76 = load i1, ptr %l37, !tbaa !21
  br i1 %t76, label %bb18, label %bb19
bb18:
  %t77 = load ptr, ptr %l2, !tbaa !29
  store ptr %t77, ptr %l42, !tbaa !29
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t79 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 0
  %t82 = load i32, ptr %t81, !tbaa !33
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t78, i32 %t82)
  store i32 %t85, ptr %l45
  br label %bb20
bb19:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb22
bb20:
  %t86 = load ptr, ptr %l42, !tbaa !29
  %t87 = load i32, ptr %l45, !tbaa !23
  %t88 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t86, i32 %t87)
  store i1 %t88, ptr %l46
  br label %bb21
bb21:
  %t89 = load i1, ptr %l46, !tbaa !21
  store i1 %t89, ptr %l41, !tbaa !21
  br label %bb22
bb22:
  %t90 = load i1, ptr %l41, !tbaa !21
  br i1 %t90, label %bb23, label %bb24
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l47, !tbaa !29
  %t92 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 0
  %t96 = load i32, ptr %t95, !tbaa !33
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t92, i32 %t96)
  store i32 %t99, ptr %l50
  br label %bb25
bb24:
  br label %bb27
bb25:
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load i32, ptr %l50, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %t100, i32 %t101)
  br label %bb26
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_4e10a6e17fa9b999_b873e8c9bb06b2fd)
  unreachable
bb33:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l49 = alloca i64
  %l57 = alloca ptr
  %l60 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_997f49c366488af5_93d2651ee5683809)
  unreachable
bb25:
  br label %bb26
bb26:
  %t78 = load i64, ptr %l2, !tbaa !24
  %t80 = icmp slt i64 %t78, 0
  br i1 %t80, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb30
bb28:
  %t82 = load i64, ptr %l2, !tbaa !24
  store i64 %t82, ptr %l44, !tbaa !24
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 0
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/load:Loader", ptr %t89, i32 0, i32 10
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l49
  br label %bb29
bb29:
  %t94 = load i64, ptr %l44, !tbaa !24
  %t95 = load i64, ptr %l49, !tbaa !24
  %t96 = icmp sge i64 %t94, %t95
  store i1 %t96, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t98 = load i1, ptr %l43, !tbaa !21
  br i1 %t98, label %bb31, label %bb32
bb31:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/free:Free", ptr %t100, i32 0, i32 0
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/load:Loader", ptr %t106, i32 0, i32 10
  %t109 = load i64, ptr %l2, !tbaa !24
  %t112 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t108, i64 %t109)
  store ptr %t112, ptr %l57
  br label %bb34
bb34:
  %t113 = load ptr, ptr %l57, !tbaa !29
  %t115 = getelementptr %"compiler/load:Module", ptr %t113, i32 0, i32 2
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  %t118 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t118, ptr %l60
  br label %bb35
bb35:
  %t119 = load i1, ptr %l60, !tbaa !21
  %t120 = xor i1 %t119, true
  call void @__olang_scope_close(ptr %s0)
  store i1 %t120, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownLocalCand(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l5 = alloca %"compiler/typed:Local"
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %l20 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l25 = alloca ptr
  %l30 = alloca %"compiler/typed:Local"
  %l34 = alloca i1
  %l35 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l50 = alloca i1
  %l53 = alloca i1
  %l58 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t18, i32 0, i32 2
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb35
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:Free", ptr %t22, i32 0, i32 178
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l3, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l20
  br label %bb6
bb6:
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l20
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32, ptr %l4
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:Free", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 178
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t35, i64 %t39)
  store ptr %t42, ptr %l25
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l25, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Body", ptr %t43, i32 0, i32 7
  %t46 = load i32, ptr %l3, !tbaa !23
  %t48 = sext i32 %t46 to i64
  %t51 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t45, i64 %t48)
  store %"compiler/typed:Local" %t51, ptr %l30
  br label %bb8
bb8:
  %t52 = load %"compiler/typed:Local", ptr %l30
  store %"compiler/typed:Local" %t52, ptr %l5
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 121
  %t56 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t59 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %t55, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t56)
  store i1 %t59, ptr %l34
  br label %bb9
bb9:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb12
bb11:
  %t61 = getelementptr %"compiler/typed:Local", ptr %l5, i32 0, i32 4
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 7}
  %t64 = trunc i64 1 to i32
  %t65 = icmp eq i32 %t62, %t64
  %t67 = xor i1 %t65, true
  store i1 %t67, ptr %l35, !tbaa !21
  br label %bb12
bb12:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/free:Free", ptr %t71, i32 0, i32 178
  %t74 = load i64, ptr %t73, !tbaa !24
  %t75 = load i32, ptr %l3, !tbaa !23
  %t77 = sext i32 %t75 to i64
  %t81 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSetOnce(ptr %v0, ptr %t70, i64 %t74, i64 %t77)
  store i1 %t81, ptr %l44
  br label %bb16
bb16:
  %t82 = load i1, ptr %l44, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb18:
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l2, !tbaa !23
  %t87 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %t83, i32 %t84)
  store i1 %t87, ptr %l47
  br label %bb20
bb20:
  %t88 = load i1, ptr %l47, !tbaa !21
  store i1 %t88, ptr %l6, !tbaa !21
  %t89 = load i1, ptr %l6, !tbaa !21
  %t91 = xor i1 %t89, true
  br i1 %t91, label %bb21, label %bb22
bb21:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l2, !tbaa !23
  %t97 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayCand(ptr %v0, ptr %t93, i32 %t94)
  store i1 %t97, ptr %l53
  br label %bb23
bb22:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb24
bb23:
  %t98 = load i1, ptr %l53, !tbaa !21
  %t99 = xor i1 %t98, true
  store i1 %t99, ptr %l50, !tbaa !21
  br label %bb24
bb24:
  %t101 = load i1, ptr %l50, !tbaa !21
  br i1 %t101, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l2, !tbaa !23
  %t104 = load i32, ptr %l2, !tbaa !23
  %t108 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %t102, i32 %t103, i64 -3, i1 false, i32 %t104, i1 false)
  store i64 %t108, ptr %l58
  br label %bb28
bb28:
  %t109 = load i64, ptr %l58, !tbaa !24
  store i64 %t109, ptr %l7, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/free:Free", ptr %t110, i32 0, i32 12
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i1, ptr %l6, !tbaa !21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t112, i64 %t113, i1 %t114)
  br label %bb29
bb29:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/free:Free", ptr %t118, i32 0, i32 13
  %t121 = load i64, ptr %l7, !tbaa !24
  %t122 = load i1, ptr %l6, !tbaa !21
  %t124 = xor i1 %t122, true
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t120, i64 %t121, i1 %t124)
  br label %bb30
bb30:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/free:Free", ptr %t128, i32 0, i32 154
  %t131 = load i64, ptr %l7, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:Free", ptr %t132, i32 0, i32 178
  %t135 = load i64, ptr %t134, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t130, i64 %t131, i64 %t135)
  br label %bb31
bb31:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/free:Free", ptr %t139, i32 0, i32 155
  %t142 = load i64, ptr %l7, !tbaa !24
  %t143 = load i32, ptr %l3, !tbaa !23
  %t145 = sext i32 %t143 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t141, i64 %t142, i64 %t145)
  br label %bb32
bb32:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/free:Free", ptr %t149, i32 0, i32 121
  %t152 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l4
  %t153 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %t151, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t152, i64 %t153)
  br label %bb33
bb33:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/free:Free", ptr %t157, i32 0, i32 156
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"compiler/free:Free", ptr %t160, i32 0, i32 178
  %t163 = load i64, ptr %t162, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t159, i64 %t163, i1 true)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s1)
  br label %bb40
bb35:
  br i1 true, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_3f4c383e8983fca5_b7613254c9da681)
  unreachable
bb40:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainClauses(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca ptr
  %l28 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Spawn", ptr %a1, i32 0, i32 2
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t14 = icmp slt i64 %t10, %t11
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  br label %bb16
bb3:
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l14, !tbaa !27
  %t19 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 %t19
  %t24 = load ptr, ptr %t23, !tbaa !39
  store ptr %t24, ptr %l5, !tbaa !29
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = getelementptr %"compiler/typed:TaskClause", ptr %t26, i32 0, i32 3
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb5, label %bb6
bb5:
  store ptr %a0, ptr %l22, !tbaa !29
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = getelementptr %"compiler/typed:TaskClause", ptr %t36, i32 0, i32 3
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = icmp eq ptr %t39, null
  br i1 %t41, label %bb7, label %bb8
bb6:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f5b9ea518a7ff771_9825b362779fb495)
  unreachable
bb8:
  br label %bb9
bb9:
  %t43 = load ptr, ptr %l5, !tbaa !29
  %t45 = getelementptr %"compiler/typed:TaskClause", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load ptr, ptr %l22, !tbaa !29
  %t49 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainDefault(ptr %v0, ptr %v1, ptr %t47, ptr %t46)
  store i1 %t49, ptr %l28
  br label %bb10
bb10:
  %t50 = load i1, ptr %l28, !tbaa !21
  %t51 = xor i1 %t50, true
  store i1 %t51, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t53 = load i1, ptr %l21, !tbaa !21
  br i1 %t53, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t55, 1
  store i64 %t58, ptr %l3, !tbaa !24
  br label %bb1
bb16:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplainDefault(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/effects:Facts"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l23 = alloca i1
  %l27 = alloca i1
  %l29 = alloca i64
  %l32 = alloca i64
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"compiler/effects:Effects"
  %l54 = alloca %"compiler/effects:Facts"
  %l56 = alloca i1
  %l58 = alloca i1
  %l60 = alloca i1
  %l62 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  %t82 = alloca %"compiler/effects:Effects", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb57
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t17 = load ptr, ptr %l12, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 3}
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t27, i32 0, i32 0
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t33, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l4, !tbaa !27
  br label %bb10
bb9:
  br label %bb52
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t41 = icmp sgt i64 %t39, 0
  br i1 %t41, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t43 = load i32, ptr %l3, !tbaa !23
  %t45 = sext i32 %t43 to i64
  %t47 = icmp slt i64 %t45, 0
  store i1 %t47, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l23, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb17
bb15:
  %t50 = load i32, ptr %l3, !tbaa !23
  %t52 = sext i32 %t50 to i64
  store i64 %t52, ptr %l29, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:Free", ptr %t53, i32 0, i32 1
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t55)
  store i64 %t57, ptr %l32
  br label %bb16
bb16:
  %t58 = load i64, ptr %l29, !tbaa !24
  %t59 = load i64, ptr %l32, !tbaa !24
  %t60 = icmp sge i64 %t58, %t59
  store i1 %t60, ptr %l27, !tbaa !21
  br label %bb17
bb17:
  %t62 = load i1, ptr %l27, !tbaa !21
  br i1 %t62, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/free:Free", ptr %t64, i32 0, i32 150
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb21, label %bb22
bb21:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l38, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:Free", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l40, !tbaa !29
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/free:Free", ptr %t76, i32 0, i32 1
  %t79 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l42
  %t81 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %l42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t81, ptr %l44
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t83 = load ptr, ptr %l40, !tbaa !29
  %t84 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  call void @compiler_2feffects_3aEffects_2ector(ptr %t82, ptr %v0, ptr %v0, ptr %v0, ptr %t83, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t84)
  call void @llvm.memmove.p0.p0.i64(ptr %l45, ptr %t82, i64 3136, i1 false)
  br label %bb24
bb24:
  %t85 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 3136, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t85, ptr %l45, i64 3136, i1 false)
  %t87 = load ptr, ptr %l38, !tbaa !29
  %t88 = getelementptr %"compiler/free:Free", ptr %t87, i32 0, i32 150
  store ptr %t85, ptr %t88, !tbaa !29
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr %"compiler/free:Free", ptr %t89, i32 0, i32 150
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb26, label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_99e9ebfcbc8324ba_73e0a545fcd79b06)
  unreachable
bb27:
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:Free", ptr %t96, i32 0, i32 150
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load i32, ptr %l3, !tbaa !23
  %t102 = sext i32 %t100 to i64
  %t105 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %t99, i64 %t102)
  store %"compiler/effects:Facts" %t105, ptr %l54
  br label %bb29
bb29:
  %t106 = load %"compiler/effects:Facts", ptr %l54
  store %"compiler/effects:Facts" %t106, ptr %l5
  %t107 = getelementptr %"compiler/effects:Facts", ptr %l5, i32 0, i32 12
  %t108 = load i1, ptr %t107, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb32
bb31:
  %t110 = getelementptr %"compiler/effects:Facts", ptr %l5, i32 0, i32 13
  %t111 = load i1, ptr %t110, !tbaa !21
  store i1 %t111, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  %t113 = load i1, ptr %l56, !tbaa !21
  br i1 %t113, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb35
bb34:
  %t114 = getelementptr %"compiler/effects:Facts", ptr %l5, i32 0, i32 17
  %t115 = load i1, ptr %t114, !tbaa !21
  store i1 %t115, ptr %l58, !tbaa !21
  br label %bb35
bb35:
  %t117 = load i1, ptr %l58, !tbaa !21
  br i1 %t117, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb38
bb37:
  %t118 = getelementptr %"compiler/effects:Facts", ptr %l5, i32 0, i32 16
  %t119 = load i1, ptr %t118, !tbaa !21
  store i1 %t119, ptr %l60, !tbaa !21
  br label %bb38
bb38:
  %t121 = load i1, ptr %l60, !tbaa !21
  br i1 %t121, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb41
bb40:
  %t122 = getelementptr %"compiler/effects:Facts", ptr %l5, i32 0, i32 24
  %t123 = load i64, ptr %t122, !tbaa !24
  %t125 = icmp ne i64 %t123, 0
  store i1 %t125, ptr %l62, !tbaa !21
  br label %bb41
bb41:
  %t127 = load i1, ptr %l62, !tbaa !21
  br i1 %t127, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t131 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s2, ptr %l5, i32 0)
  store i1 %t131, ptr %l68
  br label %bb45
bb45:
  %t132 = load i1, ptr %l68, !tbaa !21
  br i1 %t132, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb48
bb47:
  %t133 = getelementptr %"compiler/effects:Facts", ptr %l5, i32 0, i32 4
  %t134 = load i1, ptr %t133, !tbaa !21
  store i1 %t134, ptr %l69, !tbaa !21
  br label %bb48
bb48:
  %t136 = load i1, ptr %l69, !tbaa !21
  br i1 %t136, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb51
bb50:
  %t137 = getelementptr %"compiler/effects:Facts", ptr %l5, i32 0, i32 5
  %t138 = load i1, ptr %t137, !tbaa !21
  store i1 %t138, ptr %l71, !tbaa !21
  br label %bb51
bb51:
  %t140 = load i1, ptr %l71, !tbaa !21
  %t141 = xor i1 %t140, true
  call void @__olang_scope_close(ptr %s2)
  store i1 %t141, ptr %rv
  br label %ret
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i1 false, ptr %rv
  br label %ret
bb56:
  call void @__olang_check_failed(ptr @olang_loc_f87f15bbd5de31c8_d5f250c09d3b1a94)
  unreachable
bb57:
  br i1 true, label %bb58, label %bb59
bb58:
  br label %bb60
bb59:
  br label %bb61
bb60:
  store i1 false, ptr %rv
  br label %ret
bb61:
  call void @__olang_check_failed(ptr @olang_loc_eaf2522d3d4ee6a3_d46883eace75bccf)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2epreludeCode(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l14 = alloca i64
  %l22 = alloca ptr
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 0
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 0
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t20 = getelementptr %"compiler/load:Loader", ptr %t18, i32 0, i32 10
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t20)
  store i64 %t22, ptr %l14
  br label %bb4
bb4:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = icmp sge i64 %t23, %t24
  store i1 %t25, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l8, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:Free", ptr %t29, i32 0, i32 0
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/load:Loader", ptr %t35, i32 0, i32 10
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store ptr %t41, ptr %l22
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l22, !tbaa !29
  %t44 = getelementptr %"compiler/load:Module", ptr %t42, i32 0, i32 2
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  %t47 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t45, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t47, ptr %l25
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i1, ptr %l25, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereachedTasks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %lp8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i64
  %l45 = alloca i1
  %l53 = alloca { i64, ptr }
  %l59 = alloca i64
  %l62 = alloca i64
  %l86 = alloca i1
  %l91 = alloca i1
  %l96 = alloca i1
  %l103 = alloca i64
  %l105 = alloca i1
  %l110 = alloca i1
  %l114 = alloca i1
  %l116 = alloca ptr
  %l117 = alloca i64
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l121 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:Free", ptr %t3, i32 0, i32 1
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l18
  br label %bb2
bb2:
  %t8 = load i64, ptr %l18, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l25, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l25, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l25, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l22, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb19
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i64, ptr %l7, !tbaa !24
  %t59 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentry(ptr %v0, ptr %t55, i64 %t56)
  store i1 %t59, ptr %l45
  br label %bb13
bb13:
  %t60 = load i1, ptr %l45, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t61 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l1, i64 %t61)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %l6, !tbaa !24
  br label %bb9
bb19:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t72 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereached(ptr %v0, ptr %s0, ptr %v0, ptr %t69, ptr %l1, i1 false)
  store { i64, ptr } %t72, ptr %l53
  br label %bb20
bb20:
  %t73 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t73, ptr %lp8
  %t74 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t75 = load ptr, ptr %lp8
  store { i64, ptr } %t74, ptr %t75, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t76 = load ptr, ptr %lp8
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  store i64 %t79, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t82 = load i64, ptr %l9, !tbaa !24
  %t85 = icmp sgt i64 %t81, %t82
  br i1 %t85, label %bb21, label %bb22
bb21:
  %t87 = load i64, ptr %l11, !tbaa !24
  %t89 = icmp sgt i64 %t87, 0
  br i1 %t89, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb26
bb23:
  %t91 = load i64, ptr %l10, !tbaa !24
  %t92 = load i64, ptr %l9, !tbaa !24
  %t95 = sub i64 %t91, %t92
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = add i64 %t95, %t96
  %t101 = sub i64 %t99, 1
  %t102 = load i64, ptr %l11, !tbaa !24
  %t105 = sdiv i64 %t101, %t102
  store i64 %t105, ptr %l62, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb25
bb25:
  %t107 = load i64, ptr %l62, !tbaa !24
  store i64 %t107, ptr %l59, !tbaa !24
  br label %bb26
bb26:
  %t108 = load i64, ptr %l59, !tbaa !24
  store i64 %t108, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb27
bb27:
  %t109 = load i64, ptr %l13, !tbaa !24
  %t110 = load i64, ptr %l12, !tbaa !24
  %t113 = icmp slt i64 %t109, %t110
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb28, label %bb29
bb28:
  br label %bb47
bb29:
  br label %bb30
bb30:
  %t117 = load i64, ptr %l9, !tbaa !24
  %t118 = load i64, ptr %l13, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = mul i64 %t118, %t119
  %t125 = add i64 %t117, %t122
  store i64 %t125, ptr %l14, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  %t128 = load ptr, ptr %lp8
  %t130 = getelementptr { i64, ptr }, ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr i1, ptr %t131, i64 %t127
  %t133 = load i1, ptr %t132, !tbaa !31
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb31, label %bb32
bb31:
  br label %bb46
bb32:
  br label %bb33
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/free:Free", ptr %t137, i32 0, i32 97
  %t140 = load i64, ptr %l14, !tbaa !24
  %t143 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t139, i64 %t140)
  store i1 %t143, ptr %l86
  br label %bb34
bb34:
  %t144 = load i1, ptr %l86, !tbaa !21
  br i1 %t144, label %bb35, label %bb36
bb35:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:Free", ptr %t145, i32 0, i32 96
  store i1 true, ptr %t147, !tbaa !21
  br label %bb37
bb36:
  br label %bb37
bb37:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/free:Free", ptr %t148, i32 0, i32 125
  %t151 = load i64, ptr %l14, !tbaa !24
  %t154 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t150, i64 %t151)
  store i1 %t154, ptr %l91
  br label %bb38
bb38:
  %t155 = load i1, ptr %l91, !tbaa !21
  br i1 %t155, label %bb39, label %bb40
bb39:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/free:Free", ptr %t156, i32 0, i32 127
  store i1 true, ptr %t158, !tbaa !21
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/free:Free", ptr %t159, i32 0, i32 126
  %t162 = load i64, ptr %l14, !tbaa !24
  %t165 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l96
  br label %bb42
bb42:
  %t166 = load i1, ptr %l96, !tbaa !21
  br i1 %t166, label %bb43, label %bb44
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/free:Free", ptr %t167, i32 0, i32 128
  store i1 true, ptr %t169, !tbaa !21
  br label %bb45
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t173 = add i64 %t170, 1
  store i64 %t173, ptr %l13, !tbaa !24
  br label %bb27
bb47:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 94
  %t179 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t177)
  store i64 %t179, ptr %l103
  br label %bb48
bb48:
  %t180 = load i64, ptr %l103, !tbaa !24
  %t181 = icmp sgt i64 %t180, 0
  br i1 %t181, label %bb49, label %bb50
bb49:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/free:Free", ptr %t183, i32 0, i32 0
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/load:Loader", ptr %t189, i32 0, i32 18
  %t192 = load i1, ptr %t191, !tbaa !21
  br i1 %t192, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb55
bb51:
  store i1 true, ptr %l110, !tbaa !21
  br label %bb54
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"compiler/free:Free", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/generic:Program", ptr %t197, i32 0, i32 0
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = call i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinksOwnC(ptr %v0, ptr %t200)
  store i1 %t202, ptr %l114
  br label %bb53
bb53:
  %t203 = load i1, ptr %l114, !tbaa !21
  store i1 %t203, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t204 = load i1, ptr %l110, !tbaa !21
  store i1 %t204, ptr %l105, !tbaa !21
  br label %bb55
bb55:
  %t205 = load i1, ptr %l105, !tbaa !21
  br i1 %t205, label %bb56, label %bb57
bb56:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"compiler/free:Free", ptr %t206, i32 0, i32 127
  store i1 true, ptr %t208, !tbaa !21
  br label %bb58
bb57:
  br label %bb58
bb58:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l116, !tbaa !29
  %t210 = call ptr @__olang_scope_hold(ptr %v0)
  %t211 = ptrtoint ptr %t210 to i64
  store i64 %t211, ptr %l117, !tbaa !24
  %t212 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e143
  br i1 %t212, label %bb59, label %bb60
bb59:
  %t214 = call ptr @__olang_region_make_part(ptr %v0)
  %t215 = ptrtoint ptr %t214 to i64
  store i64 %t215, ptr %l117, !tbaa !24
  br label %bb60
bb60:
  %t216 = load ptr, ptr %lp8
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l119, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 0
  store i64 %t219, ptr %l120, !tbaa !24
  %t220 = load i64, ptr %l120, !tbaa !24
  %t221 = mul i64 %t220, 1
  %t222 = load i64, ptr %l117
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = call ptr @__olang_held_alloc(ptr %t223, i64 %t221)
  %t225 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  store { i64, ptr } %t226, ptr %l121, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = load i64, ptr %l120, !tbaa !24
  %t232 = mul i64 %t231, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t228, ptr %t230, i64 %t232, i1 false)
  %t233 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e143
  br i1 %t233, label %bb61, label %bb62
bb61:
  %t235 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t238 = icmp eq i64 %t236, 0
  br i1 %t238, label %bb63, label %bb64
bb62:
  %t240 = load ptr, ptr %l116, !tbaa !29
  %t241 = getelementptr %"compiler/free:Free", ptr %t240, i32 0, i32 143
  %t242 = load { i64, ptr }, ptr %t241, !tbaa !27
  store { i64, ptr } %t242, ptr %l125, !tbaa !27
  %t243 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t244 = load ptr, ptr %l116, !tbaa !29
  %t245 = getelementptr %"compiler/free:Free", ptr %t244, i32 0, i32 143
  store { i64, ptr } %t243, ptr %t245, !tbaa !27
  %t246 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aFree_2e143
  br i1 %t246, label %bb65, label %bb66
bb63:
  store { i64, ptr } zeroinitializer, ptr %l121, !tbaa !27
  br label %bb64
bb64:
  %t248 = load i64, ptr %l117
  %t249 = inttoptr i64 %t248 to ptr
  %t250 = load { i64, ptr }, ptr %l121
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = call ptr @__olang_region_or(ptr %t251, ptr null)
  %t253 = icmp ne ptr %t252, null
  %t254 = select i1 %t253, ptr %t252, ptr null
  call void @__olang_region_settle_in(ptr %t249, ptr %t254)
  br label %bb62
bb65:
  %t255 = load { i64, ptr }, ptr %l125
  %t256 = extractvalue { i64, ptr } %t255, 0
  %t257 = extractvalue { i64, ptr } %t255, 1
  call void @__olang_region_release_part(ptr %t257, i64 %t256)
  store { i64, ptr } zeroinitializer, ptr %l125
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i1 %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca ptr
  %l49 = alloca i64
  %l52 = alloca i1
  %l55 = alloca i1
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l65 = alloca i1
  %l67 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l74 = alloca { i64, [2 x i64] }
  %l76 = alloca { i64, [2 x i64] }
  %l78 = alloca i1
  %l80 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca i1
  %l90 = alloca i1
  %l92 = alloca { i64, ptr }
  %l96 = alloca { i64, [2 x i64] }
  %l98 = alloca { i64, [2 x i64] }
  %l100 = alloca i1
  %l102 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca i1
  %l122 = alloca i1
  %l124 = alloca i1
  %l126 = alloca { i64, ptr }
  %l130 = alloca { i64, [2 x i64] }
  %l132 = alloca { i64, [2 x i64] }
  %l134 = alloca i1
  %l136 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l160 = alloca ptr
  %l161 = alloca i1
  %l167 = alloca i1
  %l169 = alloca { i64, ptr }
  %l173 = alloca { i64, [2 x i64] }
  %l175 = alloca { i64, [2 x i64] }
  %l177 = alloca i1
  %l179 = alloca { i64, ptr }
  %l184 = alloca ptr
  %l185 = alloca i1
  %l191 = alloca i1
  %l193 = alloca { i64, ptr }
  %l197 = alloca { i64, [2 x i64] }
  %l199 = alloca { i64, [2 x i64] }
  %l201 = alloca i1
  %l203 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l209 = alloca i1
  %l215 = alloca i64
  %l218 = alloca i1
  %l222 = alloca i1
  %l226 = alloca ptr
  %l232 = alloca i64
  %l234 = alloca ptr
  %l238 = alloca ptr
  %l241 = alloca i64
  %l246 = alloca i1
  %l249 = alloca i1
  %l254 = alloca i1
  %l259 = alloca { i64, [2 x i64] }
  %l261 = alloca { i64, [2 x i64] }
  %l263 = alloca i1
  %l271 = alloca i64
  %l277 = alloca i64
  %l280 = alloca i64
  %l299 = alloca i64
  %l317 = alloca i64
  %l320 = alloca i64
  %l341 = alloca i64
  %l344 = alloca i1
  %l347 = alloca i1
  %l349 = alloca i64
  %l356 = alloca { i64, ptr }
  %l364 = alloca ptr
  %l365 = alloca i1
  %l377 = alloca ptr
  %l378 = alloca i1
  %l387 = alloca i1
  %l393 = alloca ptr
  %l394 = alloca i1
  %l397 = alloca i1
  %l399 = alloca i1
  %l400 = alloca ptr
  %l401 = alloca i64
  %l411 = alloca ptr
  %l412 = alloca i1
  %l421 = alloca ptr
  %l422 = alloca i64
  %t13 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store { i64, [2 x i64] } %a4, ptr %l4
  store i1 %a5, ptr %l5
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v0, ptr %t3, i64 %t4)
  store ptr %t7, ptr %l42
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l42, !tbaa !29
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = trunc i64 %t9 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t13
  %t14 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 0
  store i64 4, ptr %t14
  %t16 = insertvalue { i32 } undef, i32 %t11, 0
  %t17 = getelementptr { i64, [2 x i64] }, ptr %t13, i32 0, i32 1
  store { i32 } %t16, ptr %t17
  %t18 = load { i64, [2 x i64] }, ptr %t13
  store { i64, [2 x i64] } %t18, ptr %l8
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t24 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %t20, ptr %t21)
  store i64 %t24, ptr %l49
  br label %bb2
bb2:
  %t25 = load i64, ptr %l49, !tbaa !24
  store i64 %t25, ptr %l9, !tbaa !24
  %t26 = load i1, ptr %l5, !tbaa !21
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb3, label %bb4
bb3:
  %t30 = load i64, ptr %l9, !tbaa !24
  %t32 = icmp sge i64 %t30, 0
  store i1 %t32, ptr %l52, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l52, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  %t35 = load i64, ptr %l9, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp ne i64 %t35, %t36
  store i1 %t39, ptr %l55, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb8
bb8:
  %t41 = load i1, ptr %l55, !tbaa !21
  br i1 %t41, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l7, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Plan", ptr %t42, i32 0, i32 6
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !27
  store { i64, ptr } %t45, ptr %l61, !tbaa !27
  %t46 = load i64, ptr %l9, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i64, ptr %t49, i64 %t46
  %t51 = load i64, ptr %t50, !tbaa !34
  %t53 = icmp eq i64 %t51, 1
  br i1 %t53, label %bb11, label %bb12
bb10:
  store i1 false, ptr %l59, !tbaa !21
  br label %bb14
bb11:
  store i1 true, ptr %l65, !tbaa !21
  br label %bb13
bb12:
  %t55 = load ptr, ptr %l7, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Plan", ptr %t55, i32 0, i32 6
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l67, !tbaa !27
  %t59 = load i64, ptr %l9, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t59
  %t64 = load i64, ptr %t63, !tbaa !34
  %t66 = icmp eq i64 %t64, 3
  store i1 %t66, ptr %l65, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l65, !tbaa !21
  store i1 %t68, ptr %l59, !tbaa !21
  br label %bb14
bb14:
  %t69 = load i1, ptr %l59, !tbaa !21
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l7, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Plan", ptr %t70, i32 0, i32 7
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  store { i64, ptr } %t73, ptr %l72, !tbaa !27
  %t74 = load i64, ptr %l9, !tbaa !24
  %t76 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr { i64, [2 x i64] }, ptr %t77, i64 %t74
  %t79 = load { i64, [2 x i64] }, ptr %t78
  store { i64, [2 x i64] } %t79, ptr %l74
  %t80 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t80, ptr %l76
  %t83 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l74, ptr %l76)
  store i1 %t83, ptr %l78
  br label %bb17
bb16:
  br label %bb21
bb17:
  %t84 = load i1, ptr %l78, !tbaa !21
  br i1 %t84, label %bb18, label %bb19
bb18:
  %t85 = load ptr, ptr %l7, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Plan", ptr %t85, i32 0, i32 7
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  store { i64, ptr } %t88, ptr %l80, !tbaa !27
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t93 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i64 %t89
  store { i64, [2 x i64] } %t90, ptr %t95
  br label %bb20
bb19:
  br label %bb20
bb20:
  br label %ret
bb21:
  %t96 = load ptr, ptr %l2, !tbaa !29
  store ptr %t96, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t97 = load ptr, ptr %l83, !tbaa !29
  %t98 = icmp ne ptr %t97, null
  br i1 %t98, label %bb22, label %bb23
bb22:
  %t100 = load ptr, ptr %l83, !tbaa !29
  %t101 = load i64, ptr %t100, !range !{i64 0, i64 18}
  %t103 = icmp eq i64 %t101, 5
  store i1 %t103, ptr %l84, !tbaa !21
  br label %bb23
bb23:
  %t104 = load i1, ptr %l84, !tbaa !21
  br i1 %t104, label %bb24, label %bb25
bb24:
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr { i64, [5 x i64] }, ptr %t105, i32 0, i32 1
  %t108 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t107, i32 0, i32 2
  %t109 = load ptr, ptr %t108
  store ptr %t109, ptr %l10, !tbaa !29
  br label %bb26
bb25:
  br label %bb35
bb26:
  %t111 = load i1, ptr %l5, !tbaa !21
  br i1 %t111, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l90, !tbaa !21
  br label %bb30
bb28:
  %t113 = load ptr, ptr %l7, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Plan", ptr %t113, i32 0, i32 0
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l92, !tbaa !27
  %t117 = load ptr, ptr %l10, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Promote", ptr %t117, i32 0, i32 1
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t124 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, [2 x i64] }, ptr %t125, i64 %t122
  %t127 = load { i64, [2 x i64] }, ptr %t126
  store { i64, [2 x i64] } %t127, ptr %l96
  %t128 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t128, ptr %l98
  %t131 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l96, ptr %l98)
  store i1 %t131, ptr %l100
  br label %bb29
bb29:
  %t132 = load i1, ptr %l100, !tbaa !21
  store i1 %t132, ptr %l90, !tbaa !21
  br label %bb30
bb30:
  %t133 = load i1, ptr %l90, !tbaa !21
  br i1 %t133, label %bb31, label %bb32
bb31:
  %t134 = load ptr, ptr %l7, !tbaa !29
  %t136 = getelementptr %"compiler/typed:Plan", ptr %t134, i32 0, i32 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l102, !tbaa !27
  %t138 = load ptr, ptr %l10, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Promote", ptr %t138, i32 0, i32 1
  %t141 = load i32, ptr %t140, !tbaa !23
  %t143 = sext i32 %t141 to i64
  %t144 = load { i64, [2 x i64] }, ptr %l8
  %t147 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr { i64, [2 x i64] }, ptr %t148, i64 %t143
  store { i64, [2 x i64] } %t144, ptr %t149
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i64, ptr %l1, !tbaa !24
  %t152 = load ptr, ptr %l10, !tbaa !29
  %t154 = getelementptr %"compiler/typed:Promote", ptr %t152, i32 0, i32 0
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l3, !tbaa !24
  %t157 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t150, i64 %t151, ptr %t155, i64 %t156, { i64, [2 x i64] } %t157, i1 false, i1 true)
  br label %bb34
bb34:
  br label %bb215
bb35:
  %t163 = load ptr, ptr %l2, !tbaa !29
  store ptr %t163, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t164 = load ptr, ptr %l113, !tbaa !29
  %t165 = icmp ne ptr %t164, null
  br i1 %t165, label %bb36, label %bb37
bb36:
  %t167 = load ptr, ptr %l113, !tbaa !29
  %t168 = load i64, ptr %t167, !range !{i64 0, i64 18}
  %t170 = icmp eq i64 %t168, 7
  store i1 %t170, ptr %l114, !tbaa !21
  br label %bb37
bb37:
  %t171 = load i1, ptr %l114, !tbaa !21
  br i1 %t171, label %bb38, label %bb39
bb38:
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  %t175 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t174, i32 0, i32 2
  %t176 = load ptr, ptr %t175
  store ptr %t176, ptr %l11, !tbaa !29
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t178 = load ptr, ptr %l11, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Make", ptr %t178, i32 0, i32 4
  %t181 = load i32, ptr %t180, !tbaa !23
  %t183 = icmp sge i32 %t181, 0
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load i1, ptr %l5, !tbaa !21
  br i1 %t185, label %bb43, label %bb44
bb42:
  store i1 false, ptr %l122, !tbaa !21
  br label %bb47
bb43:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb46
bb44:
  %t187 = load ptr, ptr %l7, !tbaa !29
  %t189 = getelementptr %"compiler/typed:Plan", ptr %t187, i32 0, i32 0
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l126, !tbaa !27
  %t191 = load ptr, ptr %l11, !tbaa !29
  %t193 = getelementptr %"compiler/typed:Make", ptr %t191, i32 0, i32 4
  %t194 = load i32, ptr %t193, !tbaa !23
  %t196 = sext i32 %t194 to i64
  %t198 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, [2 x i64] }, ptr %t199, i64 %t196
  %t201 = load { i64, [2 x i64] }, ptr %t200
  store { i64, [2 x i64] } %t201, ptr %l130
  %t202 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t202, ptr %l132
  %t205 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l130, ptr %l132)
  store i1 %t205, ptr %l134
  br label %bb45
bb45:
  %t206 = load i1, ptr %l134, !tbaa !21
  store i1 %t206, ptr %l124, !tbaa !21
  br label %bb46
bb46:
  %t207 = load i1, ptr %l124, !tbaa !21
  store i1 %t207, ptr %l122, !tbaa !21
  br label %bb47
bb47:
  %t208 = load i1, ptr %l122, !tbaa !21
  br i1 %t208, label %bb48, label %bb49
bb48:
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = getelementptr %"compiler/typed:Plan", ptr %t209, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  store { i64, ptr } %t212, ptr %l136, !tbaa !27
  %t213 = load ptr, ptr %l11, !tbaa !29
  %t215 = getelementptr %"compiler/typed:Make", ptr %t213, i32 0, i32 4
  %t216 = load i32, ptr %t215, !tbaa !23
  %t218 = sext i32 %t216 to i64
  %t219 = load { i64, [2 x i64] }, ptr %l8
  %t222 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = getelementptr { i64, [2 x i64] }, ptr %t223, i64 %t218
  store { i64, [2 x i64] } %t219, ptr %t224
  br label %bb50
bb49:
  br label %bb50
bb50:
  %t225 = load ptr, ptr %l11, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Make", ptr %t225, i32 0, i32 2
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l14, !tbaa !24
  br label %bb51
bb51:
  %t234 = load i64, ptr %l13, !tbaa !24
  %t235 = load i64, ptr %l14, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb52, label %bb53
bb52:
  br label %bb57
bb53:
  br label %bb54
bb54:
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t242, ptr %l149, !tbaa !27
  %t243 = load i64, ptr %l13, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr ptr, ptr %t246, i64 %t243
  %t248 = load ptr, ptr %t247, !tbaa !39
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load i64, ptr %l1, !tbaa !24
  %t253 = load i64, ptr %l3, !tbaa !24
  %t254 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t250, i64 %t251, ptr %t248, i64 %t253, { i64, [2 x i64] } %t254, i1 false, i1 false)
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t260 = load i64, ptr %l13, !tbaa !24
  %t263 = add i64 %t260, 1
  store i64 %t263, ptr %l13, !tbaa !24
  br label %bb51
bb57:
  br label %bb215
bb58:
  %t265 = load ptr, ptr %l2, !tbaa !29
  store ptr %t265, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t266 = load ptr, ptr %l160, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb59, label %bb60
bb59:
  %t269 = load ptr, ptr %l160, !tbaa !29
  %t270 = load i64, ptr %t269, !range !{i64 0, i64 18}
  %t272 = icmp eq i64 %t270, 16
  store i1 %t272, ptr %l161, !tbaa !21
  br label %bb60
bb60:
  %t273 = load i1, ptr %l161, !tbaa !21
  br i1 %t273, label %bb61, label %bb62
bb61:
  %t274 = load ptr, ptr %l2, !tbaa !29
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t276, i32 0, i32 2
  %t278 = load ptr, ptr %t277
  store ptr %t278, ptr %l16, !tbaa !29
  br label %bb63
bb62:
  br label %bb71
bb63:
  %t280 = load i1, ptr %l5, !tbaa !21
  br i1 %t280, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l167, !tbaa !21
  br label %bb67
bb65:
  %t282 = load ptr, ptr %l7, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Plan", ptr %t282, i32 0, i32 0
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  store { i64, ptr } %t285, ptr %l169, !tbaa !27
  %t286 = load ptr, ptr %l16, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Text", ptr %t286, i32 0, i32 1
  %t289 = load i32, ptr %t288, !tbaa !23
  %t291 = sext i32 %t289 to i64
  %t293 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr { i64, [2 x i64] }, ptr %t294, i64 %t291
  %t296 = load { i64, [2 x i64] }, ptr %t295
  store { i64, [2 x i64] } %t296, ptr %l173
  %t297 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t297, ptr %l175
  %t300 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l173, ptr %l175)
  store i1 %t300, ptr %l177
  br label %bb66
bb66:
  %t301 = load i1, ptr %l177, !tbaa !21
  store i1 %t301, ptr %l167, !tbaa !21
  br label %bb67
bb67:
  %t302 = load i1, ptr %l167, !tbaa !21
  br i1 %t302, label %bb68, label %bb69
bb68:
  %t303 = load ptr, ptr %l7, !tbaa !29
  %t305 = getelementptr %"compiler/typed:Plan", ptr %t303, i32 0, i32 0
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !27
  store { i64, ptr } %t306, ptr %l179, !tbaa !27
  %t307 = load ptr, ptr %l16, !tbaa !29
  %t309 = getelementptr %"compiler/typed:Text", ptr %t307, i32 0, i32 1
  %t310 = load i32, ptr %t309, !tbaa !23
  %t312 = sext i32 %t310 to i64
  %t313 = load { i64, [2 x i64] }, ptr %l8
  %t316 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t317 = load ptr, ptr %t316, !tbaa !27
  %t318 = getelementptr { i64, [2 x i64] }, ptr %t317, i64 %t312
  store { i64, [2 x i64] } %t313, ptr %t318
  br label %bb70
bb69:
  br label %bb70
bb70:
  br label %bb215
bb71:
  %t319 = load ptr, ptr %l2, !tbaa !29
  store ptr %t319, ptr %l184, !tbaa !29
  store i1 false, ptr %l185, !tbaa !21
  %t320 = load ptr, ptr %l184, !tbaa !29
  %t321 = icmp ne ptr %t320, null
  br i1 %t321, label %bb72, label %bb73
bb72:
  %t323 = load ptr, ptr %l184, !tbaa !29
  %t324 = load i64, ptr %t323, !range !{i64 0, i64 18}
  %t326 = icmp eq i64 %t324, 8
  store i1 %t326, ptr %l185, !tbaa !21
  br label %bb73
bb73:
  %t327 = load i1, ptr %l185, !tbaa !21
  br i1 %t327, label %bb74, label %bb75
bb74:
  %t328 = load ptr, ptr %l2, !tbaa !29
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t328, i32 0, i32 1
  %t331 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t330, i32 0, i32 2
  %t332 = load ptr, ptr %t331
  store ptr %t332, ptr %l17, !tbaa !29
  br label %bb76
bb75:
  br label %bb84
bb76:
  %t334 = load i1, ptr %l5, !tbaa !21
  br i1 %t334, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb80
bb78:
  %t336 = load ptr, ptr %l7, !tbaa !29
  %t338 = getelementptr %"compiler/typed:Plan", ptr %t336, i32 0, i32 0
  %t339 = load { i64, ptr }, ptr %t338, !tbaa !27
  store { i64, ptr } %t339, ptr %l193, !tbaa !27
  %t340 = load ptr, ptr %l17, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Collect", ptr %t340, i32 0, i32 2
  %t343 = load i32, ptr %t342, !tbaa !23
  %t345 = sext i32 %t343 to i64
  %t347 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr { i64, [2 x i64] }, ptr %t348, i64 %t345
  %t350 = load { i64, [2 x i64] }, ptr %t349
  store { i64, [2 x i64] } %t350, ptr %l197
  %t351 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t351, ptr %l199
  %t354 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l197, ptr %l199)
  store i1 %t354, ptr %l201
  br label %bb79
bb79:
  %t355 = load i1, ptr %l201, !tbaa !21
  store i1 %t355, ptr %l191, !tbaa !21
  br label %bb80
bb80:
  %t356 = load i1, ptr %l191, !tbaa !21
  br i1 %t356, label %bb81, label %bb82
bb81:
  %t357 = load ptr, ptr %l7, !tbaa !29
  %t359 = getelementptr %"compiler/typed:Plan", ptr %t357, i32 0, i32 0
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !27
  store { i64, ptr } %t360, ptr %l203, !tbaa !27
  %t361 = load ptr, ptr %l17, !tbaa !29
  %t363 = getelementptr %"compiler/typed:Collect", ptr %t361, i32 0, i32 2
  %t364 = load i32, ptr %t363, !tbaa !23
  %t366 = sext i32 %t364 to i64
  %t367 = load { i64, [2 x i64] }, ptr %l8
  %t370 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr { i64, [2 x i64] }, ptr %t371, i64 %t366
  store { i64, [2 x i64] } %t367, ptr %t372
  br label %bb83
bb82:
  br label %bb83
bb83:
  br label %bb215
bb84:
  %t373 = load ptr, ptr %l2, !tbaa !29
  store ptr %t373, ptr %l208, !tbaa !29
  store i1 false, ptr %l209, !tbaa !21
  %t374 = load ptr, ptr %l208, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb85, label %bb86
bb85:
  %t377 = load ptr, ptr %l208, !tbaa !29
  %t378 = load i64, ptr %t377, !range !{i64 0, i64 18}
  %t380 = icmp eq i64 %t378, 6
  store i1 %t380, ptr %l209, !tbaa !21
  br label %bb86
bb86:
  %t381 = load i1, ptr %l209, !tbaa !21
  br i1 %t381, label %bb87, label %bb88
bb87:
  %t382 = load ptr, ptr %l2, !tbaa !29
  %t384 = getelementptr { i64, [5 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t384, i32 0, i32 2
  %t386 = load ptr, ptr %t385
  store ptr %t386, ptr %l18, !tbaa !29
  br label %bb89
bb88:
  br label %bb165
bb89:
  %t388 = load ptr, ptr %l18, !tbaa !29
  %t390 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t388)
  store i64 %t390, ptr %l215
  br label %bb90
bb90:
  %t391 = load i64, ptr %l215, !tbaa !24
  store i64 %t391, ptr %l19, !tbaa !24
  %t392 = load i64, ptr %l19, !tbaa !24
  %t394 = icmp slt i64 %t392, 0
  br i1 %t394, label %bb91, label %bb92
bb91:
  store i1 true, ptr %l218, !tbaa !21
  br label %bb93
bb92:
  %t396 = load ptr, ptr %l18, !tbaa !29
  %t398 = getelementptr %"compiler/typed:Call", ptr %t396, i32 0, i32 2
  %t399 = load i32, ptr %t398, !tbaa !23
  %t401 = icmp slt i32 %t399, 0
  store i1 %t401, ptr %l218, !tbaa !21
  br label %bb93
bb93:
  %t403 = load i1, ptr %l218, !tbaa !21
  br i1 %t403, label %bb94, label %bb95
bb94:
  store i1 true, ptr %l222, !tbaa !21
  br label %bb97
bb95:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/free:Free", ptr %t404, i32 0, i32 1
  %t407 = load i64, ptr %l19, !tbaa !24
  %t410 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t406, i64 %t407)
  store ptr %t410, ptr %l226
  br label %bb96
bb96:
  %t411 = load ptr, ptr %l226, !tbaa !29
  %t413 = getelementptr %"compiler/typed:Body", ptr %t411, i32 0, i32 11
  %t414 = load ptr, ptr %t413, !tbaa !29
  %t416 = icmp eq ptr %t414, null
  store i1 %t416, ptr %l222, !tbaa !21
  br label %bb97
bb97:
  %t418 = load i1, ptr %l222, !tbaa !21
  br i1 %t418, label %bb98, label %bb99
bb98:
  br label %ret
bb99:
  br label %bb100
bb100:
  %t419 = load ptr, ptr %l0, !tbaa !29
  %t420 = load i64, ptr %l19, !tbaa !24
  %t423 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %t419, i64 %t420)
  store i64 %t423, ptr %l232
  br label %bb101
bb101:
  %t424 = load i64, ptr %l232, !tbaa !24
  store i64 %t424, ptr %l20, !tbaa !24
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t425)
  store ptr %t427, ptr %l234
  br label %bb102
bb102:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/free:Free", ptr %t428, i32 0, i32 1
  %t431 = load i64, ptr %l19, !tbaa !24
  %t434 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t430, i64 %t431)
  store ptr %t434, ptr %l238
  br label %bb103
bb103:
  %t435 = load ptr, ptr %l238, !tbaa !29
  %t437 = getelementptr %"compiler/typed:Body", ptr %t435, i32 0, i32 2
  %t438 = load i32, ptr %t437, !tbaa !23
  %t439 = load ptr, ptr %l234, !tbaa !29
  %t441 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t439, i32 %t438)
  store i64 %t441, ptr %l241
  br label %bb104
bb104:
  %t442 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t443 = load i64, ptr %l241, !tbaa !24
  %t445 = icmp eq i64 %t443, %t442
  store i1 %t445, ptr %l21, !tbaa !21
  %t447 = load i1, ptr %l5, !tbaa !21
  %t449 = xor i1 %t447, true
  br i1 %t449, label %bb105, label %bb106
bb105:
  %t451 = load i1, ptr %l21, !tbaa !21
  %t453 = xor i1 %t451, true
  store i1 %t453, ptr %l246, !tbaa !21
  br label %bb107
bb106:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb107
bb107:
  %t455 = load i1, ptr %l246, !tbaa !21
  br i1 %t455, label %bb108, label %bb109
bb108:
  %t456 = load i1, ptr %l6, !tbaa !21
  %t458 = xor i1 %t456, true
  store i1 %t458, ptr %l249, !tbaa !21
  br label %bb110
bb109:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb110
bb110:
  %t460 = load i1, ptr %l249, !tbaa !21
  br i1 %t460, label %bb111, label %bb112
bb111:
  br label %ret
bb112:
  br label %bb113
bb113:
  %t461 = load i1, ptr %l5, !tbaa !21
  %t463 = xor i1 %t461, true
  br i1 %t463, label %bb114, label %bb115
bb114:
  %t465 = load ptr, ptr %l7, !tbaa !29
  %t466 = load ptr, ptr %l18, !tbaa !29
  %t468 = getelementptr %"compiler/typed:Call", ptr %t466, i32 0, i32 2
  %t469 = load i32, ptr %t468, !tbaa !23
  %t470 = load i64, ptr %l20, !tbaa !24
  %t474 = call { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %t465, i32 %t469, i64 %t470)
  store { i64, [2 x i64] } %t474, ptr %l259
  br label %bb116
bb115:
  store i1 false, ptr %l254, !tbaa !21
  br label %bb118
bb116:
  %t475 = load { i64, [2 x i64] }, ptr %l4
  store { i64, [2 x i64] } %t475, ptr %l261
  %t478 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %l259, ptr %l261)
  store i1 %t478, ptr %l263
  br label %bb117
bb117:
  %t479 = load i1, ptr %l263, !tbaa !21
  %t480 = xor i1 %t479, true
  store i1 %t480, ptr %l254, !tbaa !21
  br label %bb118
bb118:
  %t482 = load i1, ptr %l254, !tbaa !21
  br i1 %t482, label %bb119, label %bb120
bb119:
  br label %ret
bb120:
  br label %bb121
bb121:
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i64, ptr %l1, !tbaa !24
  %t485 = load ptr, ptr %l18, !tbaa !29
  %t486 = load i64, ptr %l19, !tbaa !24
  %t487 = load { i64, [2 x i64] }, ptr %l4
  %t488 = load i64, ptr %l20, !tbaa !24
  %t495 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %t483, i64 %t484, ptr %t485, i64 %t486, { i64, [2 x i64] } %t487, i64 %t488)
  store i64 %t495, ptr %l271
  br label %bb122
bb122:
  %t496 = load i64, ptr %l271, !tbaa !24
  store i64 %t496, ptr %l22, !tbaa !24
  %t497 = load i64, ptr %l22, !tbaa !24
  %t499 = icmp slt i64 %t497, 0
  br i1 %t499, label %bb123, label %bb124
bb123:
  br label %ret
bb124:
  br label %bb125
bb125:
  store i64 0, ptr %l23, !tbaa !24
  store i64 63, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t501 = load i64, ptr %l24, !tbaa !24
  %t502 = load i64, ptr %l23, !tbaa !24
  %t505 = icmp sgt i64 %t501, %t502
  br i1 %t505, label %bb126, label %bb127
bb126:
  %t507 = load i64, ptr %l25, !tbaa !24
  %t509 = icmp sgt i64 %t507, 0
  br i1 %t509, label %bb128, label %bb129
bb127:
  store i64 0, ptr %l277, !tbaa !24
  br label %bb131
bb128:
  %t511 = load i64, ptr %l24, !tbaa !24
  %t512 = load i64, ptr %l23, !tbaa !24
  %t515 = sub i64 %t511, %t512
  %t516 = load i64, ptr %l25, !tbaa !24
  %t519 = add i64 %t515, %t516
  %t521 = sub i64 %t519, 1
  %t522 = load i64, ptr %l25, !tbaa !24
  %t525 = sdiv i64 %t521, %t522
  store i64 %t525, ptr %l280, !tbaa !24
  br label %bb130
bb129:
  store i64 0, ptr %l280, !tbaa !24
  br label %bb130
bb130:
  %t527 = load i64, ptr %l280, !tbaa !24
  store i64 %t527, ptr %l277, !tbaa !24
  br label %bb131
bb131:
  %t528 = load i64, ptr %l277, !tbaa !24
  store i64 %t528, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb132
bb132:
  %t529 = load i64, ptr %l27, !tbaa !24
  %t530 = load i64, ptr %l26, !tbaa !24
  %t533 = icmp slt i64 %t529, %t530
  %t535 = xor i1 %t533, true
  br i1 %t535, label %bb133, label %bb134
bb133:
  br label %bb141
bb134:
  br label %bb135
bb135:
  %t537 = load i64, ptr %l23, !tbaa !24
  %t538 = load i64, ptr %l27, !tbaa !24
  %t539 = load i64, ptr %l25, !tbaa !24
  %t542 = mul i64 %t538, %t539
  %t545 = add i64 %t537, %t542
  store i64 %t545, ptr %l28, !tbaa !24
  %t547 = load i64, ptr %l22, !tbaa !24
  %t548 = load i64, ptr %l28, !tbaa !24
  store i64 %t548, ptr %l299, !tbaa !24
  %t549 = load i64, ptr %l299, !tbaa !24
  %t550 = load i64, ptr %l299, !tbaa !24
  %t551 = shl i64 1, %t550
  %t554 = and i64 %t547, %t551
  %t556 = icmp ne i64 %t554, 0
  br i1 %t556, label %bb136, label %bb137
bb136:
  %t558 = load ptr, ptr %l7, !tbaa !29
  %t559 = load ptr, ptr %l18, !tbaa !29
  %t561 = getelementptr %"compiler/typed:Call", ptr %t559, i32 0, i32 2
  %t562 = load i32, ptr %t561, !tbaa !23
  %t563 = load i64, ptr %l28, !tbaa !24
  %t564 = load { i64, [2 x i64] }, ptr %l8
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %t558, i32 %t562, i64 %t563, { i64, [2 x i64] } %t564)
  br label %bb138
bb137:
  br label %bb139
bb138:
  br label %bb139
bb139:
  br label %bb140
bb140:
  %t569 = load i64, ptr %l27, !tbaa !24
  %t572 = add i64 %t569, 1
  store i64 %t572, ptr %l27, !tbaa !24
  br label %bb132
bb141:
  store i64 0, ptr %l29, !tbaa !24
  %t574 = load ptr, ptr %l18, !tbaa !29
  %t576 = getelementptr %"compiler/typed:Call", ptr %t574, i32 0, i32 1
  %t577 = load { i64, ptr }, ptr %t576, !tbaa !27
  %t579 = extractvalue { i64, ptr } %t577, 0
  store i64 %t579, ptr %l30, !tbaa !24
  store i64 1, ptr %l31, !tbaa !24
  %t581 = load i64, ptr %l30, !tbaa !24
  %t582 = load i64, ptr %l29, !tbaa !24
  %t585 = icmp sgt i64 %t581, %t582
  br i1 %t585, label %bb142, label %bb143
bb142:
  %t587 = load i64, ptr %l31, !tbaa !24
  %t589 = icmp sgt i64 %t587, 0
  br i1 %t589, label %bb144, label %bb145
bb143:
  store i64 0, ptr %l317, !tbaa !24
  br label %bb147
bb144:
  %t591 = load i64, ptr %l30, !tbaa !24
  %t592 = load i64, ptr %l29, !tbaa !24
  %t595 = sub i64 %t591, %t592
  %t596 = load i64, ptr %l31, !tbaa !24
  %t599 = add i64 %t595, %t596
  %t601 = sub i64 %t599, 1
  %t602 = load i64, ptr %l31, !tbaa !24
  %t605 = sdiv i64 %t601, %t602
  store i64 %t605, ptr %l320, !tbaa !24
  br label %bb146
bb145:
  store i64 0, ptr %l320, !tbaa !24
  br label %bb146
bb146:
  %t607 = load i64, ptr %l320, !tbaa !24
  store i64 %t607, ptr %l317, !tbaa !24
  br label %bb147
bb147:
  %t608 = load i64, ptr %l317, !tbaa !24
  store i64 %t608, ptr %l32, !tbaa !24
  store i64 0, ptr %l33, !tbaa !24
  br label %bb148
bb148:
  %t609 = load i64, ptr %l33, !tbaa !24
  %t610 = load i64, ptr %l32, !tbaa !24
  %t613 = icmp slt i64 %t609, %t610
  %t615 = xor i1 %t613, true
  br i1 %t615, label %bb149, label %bb150
bb149:
  br label %bb164
bb150:
  br label %bb151
bb151:
  %t617 = load i64, ptr %l29, !tbaa !24
  %t618 = load i64, ptr %l33, !tbaa !24
  %t619 = load i64, ptr %l31, !tbaa !24
  %t622 = mul i64 %t618, %t619
  %t625 = add i64 %t617, %t622
  store i64 %t625, ptr %l34, !tbaa !24
  %t627 = load ptr, ptr %l0, !tbaa !29
  %t628 = load i64, ptr %l19, !tbaa !24
  %t629 = load i64, ptr %l34, !tbaa !24
  %t633 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %t627, i64 %t628, i64 %t629)
  store i64 %t633, ptr %l341
  br label %bb152
bb152:
  %t634 = load i64, ptr %l341, !tbaa !24
  store i64 %t634, ptr %l35, !tbaa !24
  %t635 = load i64, ptr %l35, !tbaa !24
  %t637 = icmp sge i64 %t635, 0
  br i1 %t637, label %bb153, label %bb154
bb153:
  %t639 = load i64, ptr %l35, !tbaa !24
  %t641 = icmp slt i64 %t639, 63
  store i1 %t641, ptr %l344, !tbaa !21
  br label %bb155
bb154:
  store i1 false, ptr %l344, !tbaa !21
  br label %bb155
bb155:
  %t643 = load i1, ptr %l344, !tbaa !21
  br i1 %t643, label %bb156, label %bb157
bb156:
  %t644 = load i64, ptr %l22, !tbaa !24
  %t645 = load i64, ptr %l35, !tbaa !24
  store i64 %t645, ptr %l349, !tbaa !24
  %t646 = load i64, ptr %l349, !tbaa !24
  %t647 = load i64, ptr %l349, !tbaa !24
  %t648 = shl i64 1, %t647
  %t651 = and i64 %t644, %t648
  %t653 = icmp ne i64 %t651, 0
  store i1 %t653, ptr %l347, !tbaa !21
  br label %bb158
bb157:
  store i1 false, ptr %l347, !tbaa !21
  br label %bb158
bb158:
  %t655 = load i1, ptr %l347, !tbaa !21
  br i1 %t655, label %bb159, label %bb160
bb159:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t657 = load i64, ptr %l1, !tbaa !24
  %t658 = load ptr, ptr %l18, !tbaa !29
  %t660 = getelementptr %"compiler/typed:Call", ptr %t658, i32 0, i32 1
  %t661 = load { i64, ptr }, ptr %t660, !tbaa !27
  store { i64, ptr } %t661, ptr %l356, !tbaa !27
  %t662 = load i64, ptr %l34, !tbaa !24
  %t664 = getelementptr { i64, ptr }, ptr %l356, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !27
  %t666 = getelementptr ptr, ptr %t665, i64 %t662
  %t667 = load ptr, ptr %t666, !tbaa !39
  %t668 = load i64, ptr %l3, !tbaa !24
  %t669 = load { i64, [2 x i64] }, ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t656, i64 %t657, ptr %t667, i64 %t668, { i64, [2 x i64] } %t669, i1 false, i1 false)
  br label %bb161
bb160:
  br label %bb162
bb161:
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t675 = load i64, ptr %l33, !tbaa !24
  %t678 = add i64 %t675, 1
  store i64 %t678, ptr %l33, !tbaa !24
  br label %bb148
bb164:
  br label %bb215
bb165:
  %t680 = load ptr, ptr %l2, !tbaa !29
  store ptr %t680, ptr %l364, !tbaa !29
  store i1 false, ptr %l365, !tbaa !21
  %t681 = load ptr, ptr %l364, !tbaa !29
  %t682 = icmp ne ptr %t681, null
  br i1 %t682, label %bb166, label %bb167
bb166:
  %t684 = load ptr, ptr %l364, !tbaa !29
  %t685 = load i64, ptr %t684, !range !{i64 0, i64 18}
  %t687 = icmp eq i64 %t685, 17
  store i1 %t687, ptr %l365, !tbaa !21
  br label %bb167
bb167:
  %t688 = load i1, ptr %l365, !tbaa !21
  br i1 %t688, label %bb168, label %bb169
bb168:
  %t689 = load ptr, ptr %l2, !tbaa !29
  %t691 = getelementptr { i64, [5 x i64] }, ptr %t689, i32 0, i32 1
  %t692 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t691, i32 0, i32 2
  %t693 = load ptr, ptr %t692
  store ptr %t693, ptr %l36, !tbaa !29
  br label %bb170
bb169:
  br label %bb172
bb170:
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t696 = load i64, ptr %l1, !tbaa !24
  %t697 = load ptr, ptr %l36, !tbaa !29
  %t698 = load i64, ptr %l3, !tbaa !24
  %t699 = load { i64, [2 x i64] }, ptr %l4
  %t700 = load i1, ptr %l5, !tbaa !21
  %t701 = load i1, ptr %l6, !tbaa !21
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t695, i64 %t696, ptr %t697, i64 %t698, { i64, [2 x i64] } %t699, i1 %t700, i1 %t701)
  br label %bb171
bb171:
  br label %bb215
bb172:
  %t709 = load ptr, ptr %l2, !tbaa !29
  store ptr %t709, ptr %l377, !tbaa !29
  store i1 false, ptr %l378, !tbaa !21
  %t710 = load ptr, ptr %l377, !tbaa !29
  %t711 = icmp ne ptr %t710, null
  br i1 %t711, label %bb173, label %bb174
bb173:
  %t713 = load ptr, ptr %l377, !tbaa !29
  %t714 = load i64, ptr %t713, !range !{i64 0, i64 18}
  %t716 = icmp eq i64 %t714, 14
  store i1 %t716, ptr %l378, !tbaa !21
  br label %bb174
bb174:
  %t717 = load i1, ptr %l378, !tbaa !21
  br i1 %t717, label %bb175, label %bb176
bb175:
  %t718 = load ptr, ptr %l2, !tbaa !29
  %t720 = getelementptr { i64, [5 x i64] }, ptr %t718, i32 0, i32 1
  %t721 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t720, i32 0, i32 2
  %t722 = load ptr, ptr %t721
  store ptr %t722, ptr %l37, !tbaa !29
  br label %bb177
bb176:
  br label %bb197
bb177:
  %t724 = load ptr, ptr %l37, !tbaa !29
  %t726 = getelementptr %"compiler/typed:Try", ptr %t724, i32 0, i32 0
  %t727 = load ptr, ptr %t726, !tbaa !29
  %t729 = icmp eq ptr %t727, null
  %t731 = xor i1 %t729, true
  br i1 %t731, label %bb178, label %bb179
bb178:
  %t733 = load ptr, ptr %l37, !tbaa !29
  %t735 = getelementptr %"compiler/typed:Try", ptr %t733, i32 0, i32 0
  %t736 = load ptr, ptr %t735, !tbaa !29
  %t738 = icmp eq ptr %t736, null
  br i1 %t738, label %bb180, label %bb181
bb179:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb185
bb180:
  call void @__olang_check_failed(ptr @olang_loc_21335a5a6f6a0d23_1fb4d5f27249eebf)
  unreachable
bb181:
  br label %bb182
bb182:
  %t740 = load ptr, ptr %l37, !tbaa !29
  %t742 = getelementptr %"compiler/typed:Try", ptr %t740, i32 0, i32 0
  %t743 = load ptr, ptr %t742, !tbaa !29
  store ptr %t743, ptr %l393, !tbaa !29
  store i1 false, ptr %l394, !tbaa !21
  %t745 = load ptr, ptr %l393, !tbaa !29
  %t746 = icmp ne ptr %t745, null
  br i1 %t746, label %bb183, label %bb184
bb183:
  %t748 = load ptr, ptr %l393, !tbaa !29
  %t749 = load i64, ptr %t748, !range !{i64 0, i64 18}
  %t751 = icmp eq i64 %t749, 6
  store i1 %t751, ptr %l394, !tbaa !21
  br label %bb184
bb184:
  %t752 = load i1, ptr %l394, !tbaa !21
  store i1 %t752, ptr %l387, !tbaa !21
  br label %bb185
bb185:
  %t753 = load i1, ptr %l387, !tbaa !21
  br i1 %t753, label %bb186, label %bb187
bb186:
  %t754 = load ptr, ptr %l37, !tbaa !29
  %t756 = call i1 @compiler_2ffree_2enoDefaults(ptr %v1, ptr %t754)
  store i1 %t756, ptr %l399
  br label %bb188
bb187:
  store i1 false, ptr %l397, !tbaa !21
  br label %bb189
bb188:
  %t757 = load i1, ptr %l399, !tbaa !21
  store i1 %t757, ptr %l397, !tbaa !21
  br label %bb189
bb189:
  %t758 = load i1, ptr %l397, !tbaa !21
  br i1 %t758, label %bb190, label %bb191
bb190:
  %t759 = load ptr, ptr %l0, !tbaa !29
  store ptr %t759, ptr %l400, !tbaa !29
  %t760 = load i64, ptr %l1, !tbaa !24
  store i64 %t760, ptr %l401, !tbaa !24
  %t761 = load ptr, ptr %l37, !tbaa !29
  %t763 = getelementptr %"compiler/typed:Try", ptr %t761, i32 0, i32 0
  %t764 = load ptr, ptr %t763, !tbaa !29
  %t766 = icmp eq ptr %t764, null
  br i1 %t766, label %bb192, label %bb193
bb191:
  br label %bb196
bb192:
  call void @__olang_check_failed(ptr @olang_loc_21335a5a6f6a0d23_1fb4d5f27249eebf)
  unreachable
bb193:
  br label %bb194
bb194:
  %t768 = load ptr, ptr %l37, !tbaa !29
  %t770 = getelementptr %"compiler/typed:Try", ptr %t768, i32 0, i32 0
  %t771 = load ptr, ptr %t770, !tbaa !29
  %t772 = load i64, ptr %l3, !tbaa !24
  %t773 = load { i64, [2 x i64] }, ptr %l4
  %t774 = load i1, ptr %l5, !tbaa !21
  %t775 = load i1, ptr %l6, !tbaa !21
  %t776 = load ptr, ptr %l400, !tbaa !29
  %t777 = load i64, ptr %l401, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t776, i64 %t777, ptr %t771, i64 %t772, { i64, [2 x i64] } %t773, i1 %t774, i1 %t775)
  br label %bb195
bb195:
  br label %bb196
bb196:
  br label %bb215
bb197:
  %t783 = load ptr, ptr %l2, !tbaa !29
  store ptr %t783, ptr %l411, !tbaa !29
  store i1 false, ptr %l412, !tbaa !21
  %t784 = load ptr, ptr %l411, !tbaa !29
  %t785 = icmp ne ptr %t784, null
  br i1 %t785, label %bb198, label %bb199
bb198:
  %t787 = load ptr, ptr %l411, !tbaa !29
  %t788 = load i64, ptr %t787, !range !{i64 0, i64 18}
  %t790 = icmp eq i64 %t788, 12
  store i1 %t790, ptr %l412, !tbaa !21
  br label %bb199
bb199:
  %t791 = load i1, ptr %l412, !tbaa !21
  br i1 %t791, label %bb200, label %bb201
bb200:
  %t792 = load ptr, ptr %l2, !tbaa !29
  %t794 = getelementptr { i64, [5 x i64] }, ptr %t792, i32 0, i32 1
  %t795 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t794, i32 0, i32 2
  %t796 = load ptr, ptr %t795
  store ptr %t796, ptr %l38, !tbaa !29
  br label %bb202
bb201:
  br label %bb210
bb202:
  %t798 = load ptr, ptr %l38, !tbaa !29
  %t800 = getelementptr %"compiler/typed:Seq", ptr %t798, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = icmp eq ptr %t801, null
  %t805 = xor i1 %t803, true
  br i1 %t805, label %bb203, label %bb204
bb203:
  %t807 = load ptr, ptr %l0, !tbaa !29
  store ptr %t807, ptr %l421, !tbaa !29
  %t808 = load i64, ptr %l1, !tbaa !24
  store i64 %t808, ptr %l422, !tbaa !24
  %t809 = load ptr, ptr %l38, !tbaa !29
  %t811 = getelementptr %"compiler/typed:Seq", ptr %t809, i32 0, i32 1
  %t812 = load ptr, ptr %t811, !tbaa !29
  %t814 = icmp eq ptr %t812, null
  br i1 %t814, label %bb205, label %bb206
bb204:
  br label %bb209
bb205:
  call void @__olang_check_failed(ptr @olang_loc_653d83628bc1c214_23f3c62eb313bca0)
  unreachable
bb206:
  br label %bb207
bb207:
  %t816 = load ptr, ptr %l38, !tbaa !29
  %t818 = getelementptr %"compiler/typed:Seq", ptr %t816, i32 0, i32 1
  %t819 = load ptr, ptr %t818, !tbaa !29
  %t820 = load i64, ptr %l3, !tbaa !24
  %t821 = load { i64, [2 x i64] }, ptr %l4
  %t822 = load i1, ptr %l5, !tbaa !21
  %t823 = load i1, ptr %l6, !tbaa !21
  %t824 = load ptr, ptr %l421, !tbaa !29
  %t825 = load i64, ptr %l422, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eredirect(ptr %v0, ptr %v1, ptr %t824, i64 %t825, ptr %t819, i64 %t820, { i64, [2 x i64] } %t821, i1 %t822, i1 %t823)
  br label %bb208
bb208:
  br label %bb209
bb209:
  br label %bb215
bb210:
  br i1 true, label %bb211, label %bb212
bb211:
  br label %bb213
bb212:
  br label %bb214
bb213:
  br label %bb215
bb214:
  call void @__olang_check_failed(ptr @olang_loc_be157778634280c0_be41122d5d44a16c)
  unreachable
bb215:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esourceModule(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i64
  %l14 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp eq i64 %t7, -3
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t13, i64 %t14)
  store ptr %t17, ptr %l14
  br label %bb4
bb3:
  br label %bb26
bb4:
  %t18 = load ptr, ptr %l14, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Body", ptr %t18, i32 0, i32 1
  %t21 = load { i64, [2 x i64] }, ptr %t20
  store { i64, [2 x i64] } %t21, ptr %l3
  %t23 = load { i64, [2 x i64] }, ptr %l3
  %t25 = extractvalue { i64, [2 x i64] } %t23, 0
  %t26 = icmp eq i64 %t25, 0
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t29 = getelementptr { i64 }, ptr %t28, i32 0, i32 0
  %t30 = load i64, ptr %t29
  store i64 %t30, ptr %l4, !tbaa !24
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:Free", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  store ptr %t35, ptr %l21, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:Free", ptr %t36, i32 0, i32 0
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i64, ptr %l4, !tbaa !24
  %t43 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l25
  br label %bb8
bb8:
  %t44 = load ptr, ptr %l21, !tbaa !29
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t44, i64 %t45)
  store i64 %t46, ptr %l26
  br label %bb9
bb9:
  %t47 = load i64, ptr %l26, !tbaa !24
  store i64 %t47, ptr %l2, !tbaa !24
  br label %bb25
bb10:
  %t48 = load { i64, [2 x i64] }, ptr %l3
  %t50 = extractvalue { i64, [2 x i64] } %t48, 0
  %t51 = icmp eq i64 %t50, 1
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t54 = getelementptr { i32, i32 }, ptr %t53, i32 0, i32 0
  %t55 = load i32, ptr %t54
  store i32 %t55, ptr %l5, !tbaa !23
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t57)
  store ptr %t59, ptr %l31
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t60)
  store ptr %t62, ptr %l33
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l35
  br label %bb16
bb16:
  %t66 = load i32, ptr %l5, !tbaa !23
  %t67 = load ptr, ptr %l35, !tbaa !29
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t67, i32 %t66)
  store i32 %t69, ptr %l37
  br label %bb17
bb17:
  %t70 = load ptr, ptr %l33, !tbaa !29
  %t71 = load i32, ptr %l37, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l38
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load i32, ptr %l38, !tbaa !23
  %t75 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l39
  br label %bb19
bb19:
  %t76 = load i64, ptr %l39, !tbaa !24
  store i64 %t76, ptr %l2, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b4c0d703fa684531_272a8f4f39064c15)
  unreachable
bb25:
  br label %bb26
bb26:
  %t77 = load i64, ptr %l2, !tbaa !24
  store i64 %t77, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitOwner(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca %"compiler/free:leaf"
  %l8 = alloca i1
  %l11 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca ptr
  %l37 = alloca i32
  %l38 = alloca i1
  %l41 = alloca ptr
  %l45 = alloca i32
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca %"compiler/free:leaf"
  %l56 = alloca %"compiler/free:leaf"
  %l57 = alloca i64
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca { i64, ptr }
  %l67 = alloca i1
  %l69 = alloca i1
  %l74 = alloca i1
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp eq i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t5, i64 %t6)
  store i1 %t9, ptr %l11
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i1, ptr %l11, !tbaa !21
  store i1 %t10, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/free:Free", ptr %t12, i32 0, i32 12
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l16
  br label %bb7
bb6:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb8
bb7:
  %t19 = load i1, ptr %l16, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb9, label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t24 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t24, 8
  br i1 %t26, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb15
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 12
  %t31 = load i64, ptr %l1, !tbaa !24
  %t34 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t30, i64 %t31)
  store i1 %t34, ptr %l25
  br label %bb14
bb14:
  %t35 = load i1, ptr %l25, !tbaa !21
  %t36 = xor i1 %t35, true
  store i1 %t36, ptr %l21, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l21, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb19
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:Free", ptr %t39, i32 0, i32 11
  %t42 = load i64, ptr %l1, !tbaa !24
  %t45 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t41, i64 %t42)
  store i1 %t45, ptr %l31
  br label %bb18
bb18:
  %t46 = load i1, ptr %l31, !tbaa !21
  store i1 %t46, ptr %l27, !tbaa !21
  br label %bb19
bb19:
  %t47 = load i1, ptr %l27, !tbaa !21
  br i1 %t47, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb24
bb21:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l33, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/free:Free", ptr %t49, i32 0, i32 15
  %t52 = load i64, ptr %l1, !tbaa !24
  %t55 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t51, i64 %t52)
  store i32 %t55, ptr %l37
  br label %bb22
bb22:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load i32, ptr %l37, !tbaa !23
  %t58 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %t56, i32 %t57)
  store i1 %t58, ptr %l38
  br label %bb23
bb23:
  %t59 = load i1, ptr %l38, !tbaa !21
  %t60 = xor i1 %t59, true
  store i1 %t60, ptr %l32, !tbaa !21
  br label %bb24
bb24:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb25, label %bb26
bb25:
  store i1 false, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l41, !tbaa !29
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 15
  %t68 = load i64, ptr %l1, !tbaa !24
  %t71 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t67, i64 %t68)
  store i32 %t71, ptr %l45
  br label %bb28
bb28:
  %t72 = load ptr, ptr %l41, !tbaa !29
  %t73 = load i32, ptr %l45, !tbaa !23
  %t74 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s3, ptr %t72, i32 %t73)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t74, ptr %l46
  br label %bb29
bb29:
  %t75 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  %t76 = call ptr @__olang_scope_alloc_a(ptr %s3, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t75, ptr %t76
  store ptr %t76, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = load i64, ptr %l4, !tbaa !24
  store i64 %t78, ptr %l48, !tbaa !24
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s3, ptr %t79)
  store i64 %t81, ptr %l50
  br label %bb31
bb31:
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = load i64, ptr %l50, !tbaa !24
  %t84 = icmp slt i64 %t82, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb33:
  br label %bb34
bb34:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t89 = load i64, ptr %l4, !tbaa !24
  %t92 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s3, ptr %s3, ptr %t88, i64 %t89)
  store %"compiler/free:leaf" %t92, ptr %l55
  br label %bb35
bb35:
  %t93 = load %"compiler/free:leaf", ptr %l55
  store %"compiler/free:leaf" %t93, ptr %l56
  %t94 = call ptr @__olang_scope_hold(ptr %s4)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l57, !tbaa !24
  %t96 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t96, label %bb36, label %bb37
bb36:
  %t98 = call ptr @__olang_region_make_part(ptr %s4)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l57, !tbaa !24
  br label %bb37
bb37:
  %t100 = getelementptr %"compiler/free:leaf", ptr %l56, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l59, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 0
  store i64 %t103, ptr %l60, !tbaa !24
  %t104 = load i64, ptr %l60, !tbaa !24
  %t105 = mul i64 %t104, 8
  %t106 = load i64, ptr %l57
  %t107 = inttoptr i64 %t106 to ptr
  %t108 = call ptr @__olang_held_alloc(ptr %t107, i64 %t105)
  %t109 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l61, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l60, !tbaa !24
  %t116 = mul i64 %t115, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t118 = getelementptr %"compiler/free:leaf", ptr %l56, i32 0, i32 0
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  %t119 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t119, label %bb38, label %bb39
bb38:
  %t121 = getelementptr %"compiler/free:leaf", ptr %l56, i32 0, i32 0
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  %t125 = icmp eq i64 %t123, 0
  br i1 %t125, label %bb40, label %bb41
bb39:
  %t127 = load %"compiler/free:leaf", ptr %l56
  store %"compiler/free:leaf" %t127, ptr %l5
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/free:leaf", ptr %l5, i32 0, i32 1
  %t130 = load i64, ptr %t129, !tbaa !24
  %t133 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t128, i64 %t130)
  store i1 %t133, ptr %l67
  br label %bb42
bb40:
  %t134 = getelementptr %"compiler/free:leaf", ptr %l56, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t134, !tbaa !27
  br label %bb41
bb41:
  %t135 = getelementptr %"compiler/free:leaf", ptr %l56, i32 0, i32 0
  %t136 = load i64, ptr %l57
  %t137 = inttoptr i64 %t136 to ptr
  %t138 = load { i64, ptr }, ptr %t135
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = call ptr @__olang_region_or(ptr %t139, ptr null)
  %t141 = icmp ne ptr %t140, null
  %t142 = select i1 %t141, ptr %t140, ptr null
  call void @__olang_region_settle_in(ptr %t137, ptr %t142)
  br label %bb39
bb42:
  %t143 = load i1, ptr %l67, !tbaa !21
  %t144 = xor i1 %t143, true
  br i1 %t144, label %bb43, label %bb44
bb43:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:leaf", ptr %l5, i32 0, i32 1
  %t148 = load i64, ptr %t147, !tbaa !24
  %t149 = load i64, ptr %l2, !tbaa !24
  %t151 = add i64 %t149, 1
  %t155 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2esplitOwner(ptr %v0, ptr %t146, i64 %t148, i64 %t151)
  store i1 %t155, ptr %l74
  br label %bb45
bb44:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb46
bb45:
  %t156 = load i1, ptr %l74, !tbaa !21
  %t157 = xor i1 %t156, true
  store i1 %t157, ptr %l69, !tbaa !21
  br label %bb46
bb46:
  %t159 = load i1, ptr %l69, !tbaa !21
  br i1 %t159, label %bb47, label %bb48
bb47:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s4)
  br label %bb50
bb50:
  %t161 = load i64, ptr %l4, !tbaa !24
  %t164 = add i64 %t161, 1
  store i64 %t164, ptr %l4, !tbaa !24
  br label %bb30
bb51:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2etaskBodies(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i1
  %l39 = alloca i1
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca i64
  %l59 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l76 = alloca i1
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l93 = alloca i64
  %l95 = alloca i64
  %l100 = alloca i64
  %l103 = alloca i1
  %l107 = alloca i1
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:Free", ptr %t1, i32 0, i32 1
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  store i64 %t7, ptr %l20, !tbaa !24
  %t8 = load i64, ptr %l20, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l20, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l23
  br label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_66bc7a65ec09e50e_5d0a70b450b5d482)
  unreachable
bb4:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l4
  store ptr %a1, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  %t21 = load i64, ptr %l6, !tbaa !24
  store i64 %t21, ptr %l25, !tbaa !24
  %t22 = load ptr, ptr %l5, !tbaa !29
  %t24 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t22)
  store i64 %t24, ptr %l27
  br label %bb6
bb6:
  %t25 = load i64, ptr %l25, !tbaa !24
  %t26 = load i64, ptr %l27, !tbaa !24
  %t27 = icmp slt i64 %t25, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb7, label %bb8
bb7:
  br label %bb22
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l5, !tbaa !29
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t31, i64 %t32)
  store i64 %t35, ptr %l32
  br label %bb10
bb10:
  %t36 = load i64, ptr %l32, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t37, 0
  br i1 %t39, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb13
bb12:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = icmp sge i64 %t41, %t42
  store i1 %t45, ptr %l35, !tbaa !21
  br label %bb13
bb13:
  %t47 = load i1, ptr %l35, !tbaa !21
  br i1 %t47, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb16
bb15:
  %t48 = load i64, ptr %l7, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i1, ptr %t51, i64 %t48
  %t53 = load i1, ptr %t52, !tbaa !31
  store i1 %t53, ptr %l39, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l39, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  br label %bb21
bb18:
  br label %bb19
bb19:
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i1, ptr %t59, i64 %t56
  store i1 true, ptr %t60, !tbaa !31
  %t61 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t61)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t64 = load i64, ptr %l6, !tbaa !24
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %l6, !tbaa !24
  br label %bb5
bb22:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb23
bb23:
  %t69 = load i64, ptr %l8, !tbaa !24
  store i64 %t69, ptr %l48, !tbaa !24
  %t71 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l4)
  store i64 %t71, ptr %l50
  br label %bb24
bb24:
  %t72 = load i64, ptr %l48, !tbaa !24
  %t73 = load i64, ptr %l50, !tbaa !24
  %t74 = icmp slt i64 %t72, %t73
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb25, label %bb26
bb25:
  br label %bb69
bb26:
  br label %bb27
bb27:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l4, i64 %t78)
  store i64 %t81, ptr %l55
  br label %bb28
bb28:
  %t82 = load i64, ptr %l55, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s7
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:Free", ptr %t83, i32 0, i32 2
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load i64, ptr %l9, !tbaa !24
  %t90 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %s7, ptr %t86, i64 %t87)
  store { i64, ptr } %t90, ptr %l59
  br label %bb29
bb29:
  %t91 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t91, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t93 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l12, !tbaa !24
  br label %bb30
bb30:
  %t97 = load i64, ptr %l11, !tbaa !24
  %t98 = load i64, ptr %l12, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb31, label %bb32
bb31:
  br label %bb45
bb32:
  br label %bb33
bb33:
  %t105 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t105, ptr %l67, !tbaa !27
  %t106 = load i64, ptr %l11, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i64, ptr %t109, i64 %t106
  %t111 = load i64, ptr %t110, !tbaa !34
  store i64 %t111, ptr %l13, !tbaa !24
  %t113 = load i64, ptr %l13, !tbaa !24
  %t115 = icmp slt i64 %t113, 0
  br i1 %t115, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb36
bb35:
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l2, !tbaa !24
  %t121 = icmp sge i64 %t117, %t118
  store i1 %t121, ptr %l72, !tbaa !21
  br label %bb36
bb36:
  %t123 = load i1, ptr %l72, !tbaa !21
  br i1 %t123, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l76, !tbaa !21
  br label %bb39
bb38:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i1, ptr %t127, i64 %t124
  %t129 = load i1, ptr %t128, !tbaa !31
  store i1 %t129, ptr %l76, !tbaa !21
  br label %bb39
bb39:
  %t131 = load i1, ptr %l76, !tbaa !21
  br i1 %t131, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i1, ptr %t135, i64 %t132
  store i1 true, ptr %t136, !tbaa !31
  %t137 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t137)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = add i64 %t140, 1
  store i64 %t143, ptr %l11, !tbaa !24
  br label %bb30
bb45:
  call void @__olang_scope_close(ptr %s7)
  store %olang.scope zeroinitializer, ptr %s11
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/free:Free", ptr %t145, i32 0, i32 150
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  br i1 %t150, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_53f9fdc161a0de7d_c280e3866725f49)
  unreachable
bb47:
  br label %bb48
bb48:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t154 = getelementptr %"compiler/free:Free", ptr %t152, i32 0, i32 150
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t156 = load i64, ptr %l9, !tbaa !24
  %t159 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eCallsOf(ptr %v0, ptr %s11, ptr %t155, i64 %t156)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t159, ptr %l91
  br label %bb49
bb49:
  %t160 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l91
  %t161 = call ptr @__olang_scope_alloc_a(ptr %s11, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t160, ptr %t161
  store ptr %t161, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb50
bb50:
  %t163 = load i64, ptr %l15, !tbaa !24
  store i64 %t163, ptr %l93, !tbaa !24
  %t164 = load ptr, ptr %l14, !tbaa !29
  %t166 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s11, ptr %t164)
  store i64 %t166, ptr %l95
  br label %bb51
bb51:
  %t167 = load i64, ptr %l93, !tbaa !24
  %t168 = load i64, ptr %l95, !tbaa !24
  %t169 = icmp slt i64 %t167, %t168
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb52, label %bb53
bb52:
  br label %bb67
bb53:
  br label %bb54
bb54:
  %t173 = load ptr, ptr %l14, !tbaa !29
  %t174 = load i64, ptr %l15, !tbaa !24
  %t177 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s11, ptr %t173, i64 %t174)
  store i64 %t177, ptr %l100
  br label %bb55
bb55:
  %t178 = load i64, ptr %l100, !tbaa !24
  store i64 %t178, ptr %l16, !tbaa !24
  %t179 = load i64, ptr %l16, !tbaa !24
  %t181 = icmp slt i64 %t179, 0
  br i1 %t181, label %bb56, label %bb57
bb56:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb58
bb57:
  %t183 = load i64, ptr %l16, !tbaa !24
  %t184 = load i64, ptr %l2, !tbaa !24
  %t187 = icmp sge i64 %t183, %t184
  store i1 %t187, ptr %l103, !tbaa !21
  br label %bb58
bb58:
  %t189 = load i1, ptr %l103, !tbaa !21
  br i1 %t189, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l107, !tbaa !21
  br label %bb61
bb60:
  %t190 = load i64, ptr %l16, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i1, ptr %t193, i64 %t190
  %t195 = load i1, ptr %t194, !tbaa !31
  store i1 %t195, ptr %l107, !tbaa !21
  br label %bb61
bb61:
  %t197 = load i1, ptr %l107, !tbaa !21
  br i1 %t197, label %bb62, label %bb63
bb62:
  br label %bb66
bb63:
  br label %bb64
bb64:
  %t198 = load i64, ptr %l16, !tbaa !24
  %t200 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr i1, ptr %t201, i64 %t198
  store i1 true, ptr %t202, !tbaa !31
  %t203 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l4, i64 %t203)
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t206 = load i64, ptr %l15, !tbaa !24
  %t209 = add i64 %t206, 1
  store i64 %t209, ptr %l15, !tbaa !24
  br label %bb50
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb68:
  %t211 = load i64, ptr %l8, !tbaa !24
  %t214 = add i64 %t211, 1
  store i64 %t214, ptr %l8, !tbaa !24
  br label %bb23
bb69:
  %t216 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t216, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3aFree_2evecWalksAt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca { i64, i64 }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, i64, i64 }
  %l20 = alloca i64
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i1
  %l34 = alloca i32
  %l38 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i1
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca i32
  %l56 = alloca { i64, ptr }
  %l62 = alloca i64
  %l65 = alloca i64
  %l84 = alloca { i64, ptr }
  %l87 = alloca i1
  %l88 = alloca i1
  %l90 = alloca { i64, ptr }
  %l93 = alloca i1
  %l94 = alloca i1
  %l96 = alloca { i64, ptr }
  %l99 = alloca i1
  %l102 = alloca { i64, ptr }
  %l105 = alloca i1
  %l109 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca i64
  %l112 = alloca { i64, ptr }
  %l113 = alloca i64
  %l114 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l130 = alloca { i64, i64 }
  %l135 = alloca i64
  %l138 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l146 = alloca %"compiler/free:VecWalk"
  %l148 = alloca %"compiler/free:VecWalk"
  %l152 = alloca i1
  %l153 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca i64
  %l159 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l164 = alloca i32
  %l165 = alloca i32
  %l166 = alloca %"compiler/free:VecWalk"
  %l168 = alloca %"compiler/free:VecWalk"
  %l172 = alloca i1
  %l173 = alloca ptr
  %l175 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l182 = alloca %"compiler/free:VecWalk"
  %l184 = alloca %"compiler/free:VecWalk"
  %l185 = alloca ptr
  %l189 = alloca i64
  %l190 = alloca i1
  %l191 = alloca i1
  %l195 = alloca i1
  %l198 = alloca { i64, ptr }
  %l201 = alloca i64
  %l202 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l205 = alloca { i64, ptr }
  %l206 = alloca i64
  %l207 = alloca i64
  %l208 = alloca i64
  %l209 = alloca ptr
  %l211 = alloca { i64, ptr }
  %l214 = alloca i32
  %l215 = alloca i32
  %l216 = alloca %"compiler/free:VecWalk"
  %l218 = alloca %"compiler/free:VecWalk"
  %l222 = alloca i1
  %l226 = alloca { i64, i64, i64 }
  %l229 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca ptr
  %l237 = alloca { i64, ptr }
  %l240 = alloca i32
  %l241 = alloca i32
  %l243 = alloca %"compiler/free:VecWalk"
  %l245 = alloca %"compiler/free:VecWalk"
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l23, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  store ptr %t5, ptr %l24, !tbaa !29
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l27
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l24, !tbaa !29
  %t12 = load i32, ptr %l27, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t11, i32 %t12)
  store i32 %t13, ptr %l28
  br label %bb3
bb3:
  %t14 = load i32, ptr %l28, !tbaa !23
  store i32 %t14, ptr %l6, !tbaa !23
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 8
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb7
bb5:
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t20 = load i32, ptr %l6, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l34
  br label %bb6
bb6:
  %t24 = load i32, ptr %l34, !range !{i32 0, i32 33}
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  store i1 %t29, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l31, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb11
bb9:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t33 = load i32, ptr %l6, !tbaa !23
  %t36 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t32, i32 %t33)
  store i1 %t36, ptr %l41
  br label %bb10
bb10:
  %t37 = load i1, ptr %l41, !tbaa !21
  %t38 = xor i1 %t37, true
  store i1 %t38, ptr %l38, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l38, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb13:
  %t41 = load ptr, ptr %l5, !tbaa !29
  store ptr %t41, ptr %l44, !tbaa !29
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t43 = load i32, ptr %l6, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l47
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l44, !tbaa !29
  %t48 = load i32, ptr %l47, !tbaa !23
  %t49 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t49, ptr %l48
  br label %bb15
bb15:
  %t50 = load i32, ptr %l48, !range !{i32 0, i32 6}
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l43, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  br label %ret
bb18:
  br label %bb19
bb19:
  %t58 = load ptr, ptr %l5, !tbaa !29
  store ptr %t58, ptr %l52, !tbaa !29
  %t59 = load ptr, ptr %l5, !tbaa !29
  %t60 = load i32, ptr %l6, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l55
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l52, !tbaa !29
  %t65 = load i32, ptr %l55, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l56
  br label %bb21
bb21:
  %t67 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t67, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  store i64 %t70, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = icmp sgt i64 %t72, %t73
  br i1 %t76, label %bb22, label %bb23
bb22:
  %t78 = load i64, ptr %l10, !tbaa !24
  %t80 = icmp sgt i64 %t78, 0
  br i1 %t80, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb27
bb24:
  %t82 = load i64, ptr %l9, !tbaa !24
  %t83 = load i64, ptr %l8, !tbaa !24
  %t86 = sub i64 %t82, %t83
  %t87 = load i64, ptr %l10, !tbaa !24
  %t90 = add i64 %t86, %t87
  %t92 = sub i64 %t90, 1
  %t93 = load i64, ptr %l10, !tbaa !24
  %t96 = sdiv i64 %t92, %t93
  store i64 %t96, ptr %l65, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l65, !tbaa !24
  br label %bb26
bb26:
  %t98 = load i64, ptr %l65, !tbaa !24
  store i64 %t98, ptr %l62, !tbaa !24
  br label %bb27
bb27:
  %t99 = load i64, ptr %l62, !tbaa !24
  store i64 %t99, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t100 = load i64, ptr %l12, !tbaa !24
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = icmp slt i64 %t100, %t101
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb111
bb30:
  br label %bb31
bb31:
  %t108 = load i64, ptr %l8, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = mul i64 %t109, %t110
  %t116 = add i64 %t108, %t113
  store i64 %t116, ptr %l13, !tbaa !24
  %t118 = load ptr, ptr %l5, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t119, ptr %l84, !tbaa !27
  %t120 = load i64, ptr %l13, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t128 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t118, i32 %t125)
  store i1 %t128, ptr %l87
  br label %bb32
bb32:
  %t129 = load i1, ptr %l87, !tbaa !21
  br i1 %t129, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb40
bb34:
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t131, ptr %l90, !tbaa !27
  %t132 = load i64, ptr %l13, !tbaa !24
  %t134 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr i32, ptr %t135, i64 %t132
  %t137 = load i32, ptr %t136, !tbaa !33
  %t140 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t130, i32 %t137)
  store i1 %t140, ptr %l93
  br label %bb35
bb35:
  %t141 = load i1, ptr %l93, !tbaa !21
  br i1 %t141, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb39
bb37:
  %t142 = load ptr, ptr %l5, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t143, ptr %l96, !tbaa !27
  %t144 = load i64, ptr %l13, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  %t152 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t142, i32 %t149)
  store i1 %t152, ptr %l99
  br label %bb38
bb38:
  %t153 = load i1, ptr %l99, !tbaa !21
  store i1 %t153, ptr %l94, !tbaa !21
  br label %bb39
bb39:
  %t154 = load i1, ptr %l94, !tbaa !21
  %t155 = xor i1 %t154, true
  store i1 %t155, ptr %l88, !tbaa !21
  br label %bb40
bb40:
  %t157 = load i1, ptr %l88, !tbaa !21
  br i1 %t157, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s3)
  br label %bb110
bb42:
  br label %bb43
bb43:
  %t158 = load ptr, ptr %l5, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t159, ptr %l102, !tbaa !27
  %t160 = load i64, ptr %l13, !tbaa !24
  %t162 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 %t160
  %t165 = load i32, ptr %t164, !tbaa !33
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %t158, i32 %t165)
  store i1 %t168, ptr %l105
  br label %bb44
bb44:
  %t169 = load i1, ptr %l105, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s5
  %t172 = load ptr, ptr %l2, !tbaa !29
  %t174 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t172
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t174, ptr %l109
  %t176 = call ptr @__olang_scope_hold(ptr %s5)
  %t177 = ptrtoint ptr %t176 to i64
  store i64 %t177, ptr %l110, !tbaa !24
  %t178 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t178, label %bb47, label %bb48
bb46:
  br label %bb55
bb47:
  %t180 = call ptr @__olang_region_make_part(ptr %s5)
  %t181 = ptrtoint ptr %t180 to i64
  store i64 %t181, ptr %l110, !tbaa !24
  br label %bb48
bb48:
  %t182 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109, i32 0, i32 0
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, ptr } %t183, ptr %l112, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  store i64 %t185, ptr %l113, !tbaa !24
  %t186 = load i64, ptr %l113, !tbaa !24
  %t187 = mul i64 %t186, 8
  %t188 = load i64, ptr %l110
  %t189 = inttoptr i64 %t188 to ptr
  %t190 = call ptr @__olang_held_alloc(ptr %t189, i64 %t187)
  %t191 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l114, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !27
  %t197 = load i64, ptr %l113, !tbaa !24
  %t198 = mul i64 %t197, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t194, ptr %t196, i64 %t198, i1 false)
  %t199 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t200 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109, i32 0, i32 0
  store { i64, ptr } %t199, ptr %t200, !tbaa !27
  %t201 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t201, label %bb49, label %bb50
bb49:
  %t203 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109, i32 0, i32 0
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t207 = icmp eq i64 %t205, 0
  br i1 %t207, label %bb51, label %bb52
bb50:
  %t209 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l14
  %t210 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s5, ptr %l14, i64 %t210)
  br label %bb53
bb51:
  %t213 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t213, !tbaa !27
  br label %bb52
bb52:
  %t214 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109, i32 0, i32 0
  %t215 = load i64, ptr %l110
  %t216 = inttoptr i64 %t215 to ptr
  %t217 = load { i64, ptr }, ptr %t214
  %t218 = extractvalue { i64, ptr } %t217, 1
  %t219 = call ptr @__olang_region_or(ptr %t218, ptr null)
  %t220 = icmp ne ptr %t219, null
  %t221 = select i1 %t220, ptr %t219, ptr null
  call void @__olang_region_settle_in(ptr %t216, ptr %t221)
  br label %bb50
bb53:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t223, ptr %l121, !tbaa !27
  %t224 = load i64, ptr %l13, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i32, ptr %t227, i64 %t224
  %t229 = load i32, ptr %t228, !tbaa !33
  %t230 = load ptr, ptr %l3, !tbaa !29
  %t231 = load i64, ptr %l4, !tbaa !24
  %t233 = add i64 %t231, 1
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2evecWalksAt(ptr %v0, ptr %s5, ptr %v2, ptr %t222, i32 %t229, ptr %l14, ptr %t230, i64 %t233)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  br label %bb110
bb55:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load i32, ptr %l6, !tbaa !23
  %t243 = call { i64, i64 } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eVecFields(ptr %v0, ptr %t239, i32 %t240)
  store { i64, i64 } %t243, ptr %l130
  br label %bb56
bb56:
  %t244 = load { i64, i64 }, ptr %l130
  store { i64, i64 } %t244, ptr %l15
  %t245 = getelementptr { i64, i64 }, ptr %l15, i32 0, i32 1
  %t246 = load i64, ptr %t245, !tbaa !24
  store i64 %t246, ptr %l16, !tbaa !24
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l6, !tbaa !23
  %t250 = load i64, ptr %l13, !tbaa !24
  %t254 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextBuffer(ptr %v0, ptr %t248, i32 %t249, i64 %t250)
  store i64 %t254, ptr %l135
  br label %bb57
bb57:
  %t255 = load i64, ptr %l135, !tbaa !24
  store i64 %t255, ptr %l17, !tbaa !24
  %t256 = load i64, ptr %l17, !tbaa !24
  %t258 = icmp sge i64 %t256, 0
  br i1 %t258, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s6
  %t260 = load ptr, ptr %l3, !tbaa !29
  store ptr %t260, ptr %l138, !tbaa !29
  %t261 = load ptr, ptr %l2, !tbaa !29
  %t263 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s6, ptr %t261)
  store { i64, ptr } %t263, ptr %l140
  br label %bb60
bb59:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i32, ptr %l6, !tbaa !23
  %t266 = load i64, ptr %l13, !tbaa !24
  %t270 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enestedBuffer(ptr %v0, ptr %t264, i32 %t265, i64 %t266)
  store i1 %t270, ptr %l152
  br label %bb64
bb60:
  %t271 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t272 = load i64, ptr %l13, !tbaa !24
  %t273 = load i64, ptr %l16, !tbaa !24
  %t274 = load i64, ptr %l17, !tbaa !24
  %t275 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t281 = call %"compiler/free:VecWalk" @compiler_2ffree_3aVecWalk_2ector(ptr %s6, { i64, ptr } %t271, i64 %t272, i64 %t273, i64 %t274, i32 %t275, i64 -1)
  store %"compiler/free:VecWalk" %t281, ptr %l146
  br label %bb61
bb61:
  %t283 = call %"compiler/free:VecWalk" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aVecWalk(ptr %s6, ptr %l146)
  store %"compiler/free:VecWalk" %t283, ptr %l148
  br label %bb62
bb62:
  %t284 = load ptr, ptr %l138, !tbaa !29
  %t285 = load %"compiler/free:VecWalk", ptr %l148
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2ePush_3ccompiler_2ffree_3aVecWalk_3e(ptr %v2, ptr %s6, ptr %t284, %"compiler/free:VecWalk" %t285)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s6)
  br label %bb98
bb64:
  %t286 = load i1, ptr %l152, !tbaa !21
  br i1 %t286, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s8
  %t287 = load ptr, ptr %l3, !tbaa !29
  store ptr %t287, ptr %l153, !tbaa !29
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s8, ptr %t288)
  store { i64, ptr } %t290, ptr %l155
  br label %bb67
bb66:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load i32, ptr %l6, !tbaa !23
  %t293 = load i64, ptr %l13, !tbaa !24
  %t297 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayBuffer(ptr %v0, ptr %t291, i32 %t292, i64 %t293)
  store i1 %t297, ptr %l172
  br label %bb73
bb67:
  %t298 = load { i64, ptr }, ptr %l155, !tbaa !27
  store { i64, ptr } %t298, ptr %l156, !tbaa !27
  %t299 = load i64, ptr %l13, !tbaa !24
  store i64 %t299, ptr %l157, !tbaa !24
  %t300 = load i64, ptr %l16, !tbaa !24
  store i64 %t300, ptr %l158, !tbaa !24
  %t301 = load ptr, ptr %l5, !tbaa !29
  store ptr %t301, ptr %l159, !tbaa !29
  %t302 = load ptr, ptr %l5, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t303, ptr %l161, !tbaa !27
  %t304 = load i64, ptr %l13, !tbaa !24
  %t306 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t307 = load ptr, ptr %t306, !tbaa !27
  %t308 = getelementptr i32, ptr %t307, i64 %t304
  %t309 = load i32, ptr %t308, !tbaa !33
  %t312 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t302, i32 %t309)
  store i32 %t312, ptr %l164
  br label %bb68
bb68:
  %t313 = load ptr, ptr %l159, !tbaa !29
  %t314 = load i32, ptr %l164, !tbaa !23
  %t315 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t313, i32 %t314)
  store i32 %t315, ptr %l165
  br label %bb69
bb69:
  %t316 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t317 = load i64, ptr %l157, !tbaa !24
  %t318 = load i64, ptr %l158, !tbaa !24
  %t319 = load i32, ptr %l165, !tbaa !23
  %t320 = call %"compiler/free:VecWalk" @compiler_2ffree_3aVecWalk_2ector(ptr %s8, { i64, ptr } %t316, i64 %t317, i64 %t318, i64 -1, i32 %t319, i64 -1)
  store %"compiler/free:VecWalk" %t320, ptr %l166
  br label %bb70
bb70:
  %t322 = call %"compiler/free:VecWalk" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aVecWalk(ptr %s8, ptr %l166)
  store %"compiler/free:VecWalk" %t322, ptr %l168
  br label %bb71
bb71:
  %t323 = load ptr, ptr %l153, !tbaa !29
  %t324 = load %"compiler/free:VecWalk", ptr %l168
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2ePush_3ccompiler_2ffree_3aVecWalk_3e(ptr %v2, ptr %s8, ptr %t323, %"compiler/free:VecWalk" %t324)
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s8)
  br label %bb97
bb73:
  %t325 = load i1, ptr %l172, !tbaa !21
  br i1 %t325, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s10
  %t326 = load ptr, ptr %l3, !tbaa !29
  store ptr %t326, ptr %l173, !tbaa !29
  %t327 = load ptr, ptr %l2, !tbaa !29
  %t329 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s10, ptr %t327)
  store { i64, ptr } %t329, ptr %l175
  br label %bb76
bb75:
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l185, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l6, !tbaa !23
  %t333 = load i64, ptr %l13, !tbaa !24
  %t337 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t331, i32 %t332, i64 %t333)
  store i64 %t337, ptr %l189
  br label %bb80
bb76:
  %t338 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t339 = load i64, ptr %l13, !tbaa !24
  %t340 = load i64, ptr %l16, !tbaa !24
  %t341 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t341, ptr %l179, !tbaa !27
  %t342 = load i64, ptr %l13, !tbaa !24
  %t344 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr i32, ptr %t345, i64 %t342
  %t347 = load i32, ptr %t346, !tbaa !33
  %t352 = call %"compiler/free:VecWalk" @compiler_2ffree_3aVecWalk_2ector(ptr %s10, { i64, ptr } %t338, i64 %t339, i64 %t340, i64 -1, i32 %t347, i64 -1)
  store %"compiler/free:VecWalk" %t352, ptr %l182
  br label %bb77
bb77:
  %t354 = call %"compiler/free:VecWalk" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aVecWalk(ptr %s10, ptr %l182)
  store %"compiler/free:VecWalk" %t354, ptr %l184
  br label %bb78
bb78:
  %t355 = load ptr, ptr %l173, !tbaa !29
  %t356 = load %"compiler/free:VecWalk", ptr %l184
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2ePush_3ccompiler_2ffree_3aVecWalk_3e(ptr %v2, ptr %s10, ptr %t355, %"compiler/free:VecWalk" %t356)
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s10)
  br label %bb96
bb80:
  %t357 = load ptr, ptr %l185, !tbaa !29
  %t358 = load i64, ptr %l189, !tbaa !24
  %t359 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSplitField(ptr %v0, ptr %t357, i64 %t358)
  store i1 %t359, ptr %l190
  br label %bb81
bb81:
  %t360 = load i1, ptr %l190, !tbaa !21
  br i1 %t360, label %bb82, label %bb83
bb82:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load i32, ptr %l6, !tbaa !23
  %t363 = load i64, ptr %l13, !tbaa !24
  %t367 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentryBuffer(ptr %v0, ptr %t361, i32 %t362, i64 %t363)
  store i1 %t367, ptr %l195
  br label %bb84
bb83:
  store i1 false, ptr %l191, !tbaa !21
  br label %bb85
bb84:
  %t368 = load i1, ptr %l195, !tbaa !21
  %t369 = xor i1 %t368, true
  store i1 %t369, ptr %l191, !tbaa !21
  br label %bb85
bb85:
  %t371 = load i1, ptr %l191, !tbaa !21
  br i1 %t371, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s12
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t373 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t373, ptr %l198, !tbaa !27
  %t374 = load i64, ptr %l13, !tbaa !24
  %t376 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t377 = load ptr, ptr %t376, !tbaa !27
  %t378 = getelementptr i32, ptr %t377, i64 %t374
  %t379 = load i32, ptr %t378, !tbaa !33
  %t382 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eTextArray(ptr %v0, ptr %t372, i32 %t379)
  store i64 %t382, ptr %l201
  br label %bb88
bb87:
  br label %bb95
bb88:
  %t383 = load i64, ptr %l201, !tbaa !24
  store i64 %t383, ptr %l18, !tbaa !24
  %t384 = load ptr, ptr %l3, !tbaa !29
  store ptr %t384, ptr %l202, !tbaa !29
  %t385 = load ptr, ptr %l2, !tbaa !29
  %t387 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s12, ptr %t385)
  store { i64, ptr } %t387, ptr %l204
  br label %bb89
bb89:
  %t388 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t388, ptr %l205, !tbaa !27
  %t389 = load i64, ptr %l13, !tbaa !24
  store i64 %t389, ptr %l206, !tbaa !24
  %t390 = load i64, ptr @G_2ecompiler_2ffree_2eSplitCount, !tbaa !24
  store i64 %t390, ptr %l207, !tbaa !24
  %t391 = load i64, ptr %l18, !tbaa !24
  store i64 %t391, ptr %l208, !tbaa !24
  %t392 = load ptr, ptr %l5, !tbaa !29
  store ptr %t392, ptr %l209, !tbaa !29
  %t393 = load ptr, ptr %l5, !tbaa !29
  %t394 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t394, ptr %l211, !tbaa !27
  %t395 = load i64, ptr %l13, !tbaa !24
  %t397 = getelementptr { i64, ptr }, ptr %l211, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !27
  %t399 = getelementptr i32, ptr %t398, i64 %t395
  %t400 = load i32, ptr %t399, !tbaa !33
  %t403 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t393, i32 %t400)
  store i32 %t403, ptr %l214
  br label %bb90
bb90:
  %t404 = load ptr, ptr %l209, !tbaa !29
  %t405 = load i32, ptr %l214, !tbaa !23
  %t406 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t404, i32 %t405)
  store i32 %t406, ptr %l215
  br label %bb91
bb91:
  %t407 = load { i64, ptr }, ptr %l205, !tbaa !27
  %t408 = load i64, ptr %l206, !tbaa !24
  %t409 = load i64, ptr %l207, !tbaa !24
  %t410 = load i64, ptr %l208, !tbaa !24
  %t411 = load i32, ptr %l215, !tbaa !23
  %t412 = call %"compiler/free:VecWalk" @compiler_2ffree_3aVecWalk_2ector(ptr %s12, { i64, ptr } %t407, i64 %t408, i64 %t409, i64 %t410, i32 %t411, i64 -1)
  store %"compiler/free:VecWalk" %t412, ptr %l216
  br label %bb92
bb92:
  %t414 = call %"compiler/free:VecWalk" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aVecWalk(ptr %s12, ptr %l216)
  store %"compiler/free:VecWalk" %t414, ptr %l218
  br label %bb93
bb93:
  %t415 = load ptr, ptr %l202, !tbaa !29
  %t416 = load %"compiler/free:VecWalk", ptr %l218
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2ePush_3ccompiler_2ffree_3aVecWalk_3e(ptr %v2, ptr %s12, ptr %t415, %"compiler/free:VecWalk" %t416)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb95:
  br label %bb96
bb96:
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load i32, ptr %l6, !tbaa !23
  %t419 = load i64, ptr %l13, !tbaa !24
  %t423 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentryBuffer(ptr %v0, ptr %t417, i32 %t418, i64 %t419)
  store i1 %t423, ptr %l222
  br label %bb99
bb99:
  %t424 = load i1, ptr %l222, !tbaa !21
  %t425 = xor i1 %t424, true
  br i1 %t425, label %bb100, label %bb101
bb100:
  call void @__olang_scope_close(ptr %s3)
  br label %bb110
bb101:
  br label %bb102
bb102:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t428 = load i32, ptr %l6, !tbaa !23
  %t431 = call { i64, i64, i64 } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eMapFields(ptr %v0, ptr %t427, i32 %t428)
  store { i64, i64, i64 } %t431, ptr %l226
  br label %bb103
bb103:
  %t432 = load { i64, i64, i64 }, ptr %l226
  store { i64, i64, i64 } %t432, ptr %l19
  %t433 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 1
  %t434 = load i64, ptr %t433, !tbaa !24
  store i64 %t434, ptr %l20, !tbaa !24
  %t436 = getelementptr { i64, i64, i64 }, ptr %l19, i32 0, i32 2
  %t437 = load i64, ptr %t436, !tbaa !24
  store i64 %t437, ptr %l21, !tbaa !24
  %t439 = load ptr, ptr %l3, !tbaa !29
  store ptr %t439, ptr %l229, !tbaa !29
  %t440 = load ptr, ptr %l2, !tbaa !29
  %t442 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s3, ptr %t440)
  store { i64, ptr } %t442, ptr %l231
  br label %bb104
bb104:
  %t443 = load { i64, ptr }, ptr %l231, !tbaa !27
  store { i64, ptr } %t443, ptr %l232, !tbaa !27
  %t444 = load i64, ptr %l13, !tbaa !24
  store i64 %t444, ptr %l233, !tbaa !24
  %t445 = load i64, ptr %l20, !tbaa !24
  store i64 %t445, ptr %l234, !tbaa !24
  %t446 = load ptr, ptr %l5, !tbaa !29
  store ptr %t446, ptr %l235, !tbaa !29
  %t447 = load ptr, ptr %l5, !tbaa !29
  %t448 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t448, ptr %l237, !tbaa !27
  %t449 = load i64, ptr %l13, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr i32, ptr %t452, i64 %t449
  %t454 = load i32, ptr %t453, !tbaa !33
  %t457 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t447, i32 %t454)
  store i32 %t457, ptr %l240
  br label %bb105
bb105:
  %t458 = load ptr, ptr %l235, !tbaa !29
  %t459 = load i32, ptr %l240, !tbaa !23
  %t460 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t458, i32 %t459)
  store i32 %t460, ptr %l241
  br label %bb106
bb106:
  %t461 = load i64, ptr %l21, !tbaa !24
  %t462 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t463 = load i64, ptr %l233, !tbaa !24
  %t464 = load i64, ptr %l234, !tbaa !24
  %t465 = load i32, ptr %l241, !tbaa !23
  %t467 = call %"compiler/free:VecWalk" @compiler_2ffree_3aVecWalk_2ector(ptr %s3, { i64, ptr } %t462, i64 %t463, i64 %t464, i64 -1, i32 %t465, i64 %t461)
  store %"compiler/free:VecWalk" %t467, ptr %l243
  br label %bb107
bb107:
  %t469 = call %"compiler/free:VecWalk" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aVecWalk(ptr %s3, ptr %l243)
  store %"compiler/free:VecWalk" %t469, ptr %l245
  br label %bb108
bb108:
  %t470 = load ptr, ptr %l229, !tbaa !29
  %t471 = load %"compiler/free:VecWalk", ptr %l245
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2ePush_3ccompiler_2ffree_3aVecWalk_3e(ptr %v2, ptr %s3, ptr %t470, %"compiler/free:VecWalk" %t471)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s3)
  br label %bb110
bb110:
  %t472 = load i64, ptr %l12, !tbaa !24
  %t475 = add i64 %t472, 1
  store i64 %t475, ptr %l12, !tbaa !24
  br label %bb28
bb111:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ewhat(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca ptr
  %l16 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i1
  %l38 = alloca i1
  %l40 = alloca i1
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca i32
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca ptr
  %l56 = alloca i32
  %l57 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l84 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca i32
  %l90 = alloca i32
  %l91 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i64
  %l107 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l13
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l13, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i32, ptr %l1, !tbaa !23
  %t9 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i1, ptr %l16, !tbaa !21
  %t11 = xor i1 %t10, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t13, ptr %l19, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  store i64 %t15, ptr %l20, !tbaa !24
  %t16 = load i64, ptr %l20, !tbaa !24
  %t17 = mul i64 %t16, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l21, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !27
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = mul i64 %t25, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t22, ptr %t24, i64 %t26, i1 false)
  %t27 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t27, ptr %l19, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t28, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l2, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l23, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t32 = load i32, ptr %l1, !tbaa !23
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l26
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = load i32, ptr %l26, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t38, ptr %l27
  br label %bb7
bb7:
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load i32, ptr %l27, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t41, ptr %l28
  br label %bb8
bb8:
  %t42 = load i32, ptr %l28, !tbaa !23
  store i32 %t42, ptr %l3, !tbaa !23
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t44 = load i32, ptr %l3, !tbaa !23
  %t47 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t43, i32 %t44)
  store i32 %t47, ptr %l31
  br label %bb9
bb9:
  %t48 = load i32, ptr %l31, !range !{i32 0, i32 33}
  %t50 = trunc i64 18 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb13
bb11:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t56 = load i32, ptr %l3, !tbaa !23
  %t59 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l38
  br label %bb12
bb12:
  %t60 = load i1, ptr %l38, !tbaa !21
  %t61 = xor i1 %t60, true
  store i1 %t61, ptr %l35, !tbaa !21
  br label %bb13
bb13:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb18
bb15:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l41, !tbaa !29
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t66 = load i32, ptr %l3, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l44
  br label %bb16
bb16:
  %t70 = load ptr, ptr %l41, !tbaa !29
  %t71 = load i32, ptr %l44, !tbaa !23
  %t72 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t70, i32 %t71)
  store i32 %t72, ptr %l45
  br label %bb17
bb17:
  %t73 = load i32, ptr %l45, !range !{i32 0, i32 6}
  %t75 = trunc i64 1 to i32
  %t76 = icmp eq i32 %t73, %t75
  %t78 = xor i1 %t76, true
  store i1 %t78, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t80 = load i1, ptr %l40, !tbaa !21
  br i1 %t80, label %bb19, label %bb20
bb19:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l49, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  store i64 %t83, ptr %l51, !tbaa !24
  %t84 = load i64, ptr %l51, !tbaa !24
  %t85 = mul i64 %t84, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t85)
  %t87 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l52, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l51, !tbaa !24
  %t94 = mul i64 %t93, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t90, ptr %t92, i64 %t94, i1 false)
  %t95 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t95, ptr %l50, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t96, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l53, !tbaa !29
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t99 = load i32, ptr %l3, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l56
  br label %bb22
bb22:
  %t103 = load ptr, ptr %l53, !tbaa !29
  %t104 = load i32, ptr %l56, !tbaa !23
  %t105 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t103, i32 %t104)
  store { i64, ptr } %t105, ptr %l57
  br label %bb23
bb23:
  %t106 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t106, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 0
  store i64 %t109, ptr %l6, !tbaa !24
  br label %bb24
bb24:
  %t111 = load i64, ptr %l5, !tbaa !24
  %t112 = load i64, ptr %l6, !tbaa !24
  %t115 = icmp slt i64 %t111, %t112
  %t117 = xor i1 %t115, true
  br i1 %t117, label %bb25, label %bb26
bb25:
  br label %bb47
bb26:
  br label %bb27
bb27:
  %t119 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t119, ptr %l64, !tbaa !27
  %t120 = load i64, ptr %l5, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i32, ptr %t123, i64 %t120
  %t125 = load i32, ptr %t124, !tbaa !33
  %t127 = load ptr, ptr %l2, !tbaa !29
  store ptr %t127, ptr %l67, !tbaa !29
  %t128 = load ptr, ptr %l2, !tbaa !29
  %t132 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t128, i32 %t125)
  store i32 %t132, ptr %l70
  br label %bb28
bb28:
  %t133 = load ptr, ptr %l67, !tbaa !29
  %t134 = load i32, ptr %l70, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t133, i32 %t134)
  store { i64, ptr } %t135, ptr %l71
  br label %bb29
bb29:
  %t136 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t136, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l9, !tbaa !24
  %t142 = load i64, ptr %l10, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb31, label %bb32
bb31:
  br label %bb45
bb32:
  br label %bb33
bb33:
  %t149 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t149, ptr %l78, !tbaa !27
  %t150 = load i64, ptr %l9, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  store i32 %t155, ptr %l11, !tbaa !23
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t158 = load i32, ptr %l11, !tbaa !23
  %t161 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t157, i32 %t158)
  store i1 %t161, ptr %l83
  br label %bb34
bb34:
  %t162 = load i1, ptr %l83, !tbaa !21
  br i1 %t162, label %bb35, label %bb36
bb35:
  %t163 = load ptr, ptr %l2, !tbaa !29
  store ptr %t163, ptr %l85, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l86, !tbaa !29
  %t165 = load ptr, ptr %l2, !tbaa !29
  %t166 = load i32, ptr %l11, !tbaa !23
  %t169 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t165, i32 %t166)
  store i32 %t169, ptr %l89
  br label %bb37
bb36:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb40
bb37:
  %t170 = load ptr, ptr %l86, !tbaa !29
  %t171 = load i32, ptr %l89, !tbaa !23
  %t172 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t172, ptr %l90
  br label %bb38
bb38:
  %t173 = load ptr, ptr %l85, !tbaa !29
  %t174 = load i32, ptr %l90, !tbaa !23
  %t175 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t173, i32 %t174)
  store i32 %t175, ptr %l91
  br label %bb39
bb39:
  %t176 = load i32, ptr %l3, !tbaa !23
  %t177 = load i32, ptr %l91, !tbaa !23
  %t179 = icmp eq i32 %t177, %t176
  store i1 %t179, ptr %l84, !tbaa !21
  br label %bb40
bb40:
  %t181 = load i1, ptr %l84, !tbaa !21
  br i1 %t181, label %bb41, label %bb42
bb41:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l94, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t182, ptr %l95, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  store i64 %t184, ptr %l96, !tbaa !24
  %t185 = load i64, ptr %l96, !tbaa !24
  %t186 = mul i64 %t185, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t186)
  %t188 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  store { i64, ptr } %t189, ptr %l97, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = load i64, ptr %l96, !tbaa !24
  %t195 = mul i64 %t194, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t191, ptr %t193, i64 %t195, i1 false)
  %t196 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t196, ptr %l95, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l95, !tbaa !27
  store { i64, ptr } %t197, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t198 = load i64, ptr %l9, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l9, !tbaa !24
  br label %bb30
bb45:
  br label %bb46
bb46:
  %t203 = load i64, ptr %l5, !tbaa !24
  %t206 = add i64 %t203, 1
  store i64 %t206, ptr %l5, !tbaa !24
  br label %bb24
bb47:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l104, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t208, ptr %l105, !tbaa !27
  %t209 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l106, !tbaa !24
  %t211 = load i64, ptr %l106, !tbaa !24
  %t212 = mul i64 %t211, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t212)
  %t214 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  store { i64, ptr } %t215, ptr %l107, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = load i64, ptr %l106, !tbaa !24
  %t221 = mul i64 %t220, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t217, ptr %t219, i64 %t221, i1 false)
  %t222 = load { i64, ptr }, ptr %l107, !tbaa !27
  store { i64, ptr } %t222, ptr %l105, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t223, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2easRecord(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, %"compiler/source:Span" %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i64
  %l34 = alloca i64
  %l42 = alloca ptr
  %l45 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l63 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i64
  %l73 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca i64
  %l81 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l88 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca ptr
  %l98 = alloca i64
  %l99 = alloca ptr
  %l100 = alloca i64
  %l103 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca i64
  %l111 = alloca i64
  %l116 = alloca i1
  %l119 = alloca i64
  %l121 = alloca i64
  %l123 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca ptr
  %l146 = alloca i64
  %l147 = alloca ptr
  %l148 = alloca i64
  %l151 = alloca i64
  %l154 = alloca ptr
  %l155 = alloca i64
  %l159 = alloca i64
  %l164 = alloca i1
  %l167 = alloca i64
  %l169 = alloca i64
  %l171 = alloca ptr
  %l176 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l178 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l187 = alloca ptr
  %l188 = alloca i64
  %l189 = alloca ptr
  %l190 = alloca i64
  %l193 = alloca i64
  %l196 = alloca ptr
  %l197 = alloca i64
  %l201 = alloca i64
  %l206 = alloca i1
  %l209 = alloca i64
  %l211 = alloca i64
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l219 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l221 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l223 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l232 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i64
  %l242 = alloca ptr
  %l243 = alloca i64
  %l246 = alloca i64
  %l249 = alloca ptr
  %l250 = alloca i64
  %l254 = alloca i64
  %l255 = alloca ptr
  %l256 = alloca i64
  %l257 = alloca i64
  %l258 = alloca %"compiler/source:Span"
  %l260 = alloca %"compiler/source:Span"
  %l270 = alloca ptr
  %l271 = alloca i64
  %l272 = alloca ptr
  %l273 = alloca i64
  %l276 = alloca i64
  %l279 = alloca ptr
  %l280 = alloca i64
  %l284 = alloca i64
  %l285 = alloca ptr
  %l286 = alloca i64
  %l287 = alloca i64
  %l288 = alloca %"compiler/source:Span"
  %l290 = alloca %"compiler/source:Span"
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store %"compiler/source:Span" %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb4
bb2:
  %t10 = load i64, ptr %l2, !tbaa !24
  store i64 %t10, ptr %l31, !tbaa !24
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l34
  br label %bb3
bb3:
  %t16 = load i64, ptr %l31, !tbaa !24
  %t17 = load i64, ptr %l34, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l30, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l30, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/free:walker", ptr %t21, i32 0, i32 2
  %t24 = load i1, ptr %t23, !tbaa !21
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l6, !tbaa !29
  %t30 = getelementptr %"compiler/free:Free", ptr %t28, i32 0, i32 117
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l42
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/free:walker", ptr %t35, i32 0, i32 1
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = load ptr, ptr %l42, !tbaa !29
  %t41 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t39, i64 %t38)
  store i64 %t41, ptr %l45
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l6, !tbaa !29
  %t44 = getelementptr %"compiler/free:Free", ptr %t42, i32 0, i32 70
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t44, i64 %t45)
  store ptr %t48, ptr %l49
  br label %bb13
bb13:
  %t49 = load ptr, ptr %l49, !tbaa !29
  store ptr %t49, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t50 = load i64, ptr %l8, !tbaa !24
  store i64 %t50, ptr %l50, !tbaa !24
  %t51 = load ptr, ptr %l7, !tbaa !29
  store ptr %t51, ptr %l51, !tbaa !29
  %t52 = call ptr @__olang_scope_hold(ptr %v0)
  %t53 = ptrtoint ptr %t52 to i64
  store i64 %t53, ptr %l52, !tbaa !24
  %t54 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = load ptr, ptr %l51, !tbaa !29
  %t57 = call ptr @__olang_region_or(ptr %t56, ptr %v0)
  %t58 = call ptr @__olang_scope_hold(ptr %t57)
  %t59 = ptrtoint ptr %t58 to i64
  store i64 %t59, ptr %l52, !tbaa !24
  br label %bb16
bb16:
  %t60 = load ptr, ptr %l7, !tbaa !29
  %t61 = load i64, ptr %l52
  %t62 = inttoptr i64 %t61 to ptr
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t62, ptr %t60)
  store i64 %t64, ptr %l55
  br label %bb17
bb17:
  %t65 = load i64, ptr %l50, !tbaa !24
  %t66 = load i64, ptr %l55, !tbaa !24
  %t67 = icmp slt i64 %t65, %t66
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb18, label %bb19
bb18:
  br label %bb35
bb19:
  br label %bb20
bb20:
  %t71 = load ptr, ptr %l7, !tbaa !29
  store ptr %t71, ptr %l58, !tbaa !29
  %t72 = call ptr @__olang_scope_hold(ptr %v0)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l59, !tbaa !24
  %t74 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = load ptr, ptr %l58, !tbaa !29
  %t77 = call ptr @__olang_region_or(ptr %t76, ptr %v0)
  %t78 = call ptr @__olang_scope_hold(ptr %t77)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l59, !tbaa !24
  br label %bb22
bb22:
  %t80 = load ptr, ptr %l7, !tbaa !29
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load i64, ptr %l59
  %t83 = inttoptr i64 %t82 to ptr
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t83, ptr %t80, i64 %t81)
  store i64 %t86, ptr %l63
  br label %bb23
bb23:
  %t87 = load i64, ptr %l63, !tbaa !24
  store i64 %t87, ptr %l9, !tbaa !24
  %t88 = load i64, ptr %l9, !tbaa !24
  %t90 = ashr i64 %t88, 32
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = sub i64 %t90, %t91
  store i64 %t94, ptr %l10, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  %t98 = icmp sge i64 %t96, 0
  br i1 %t98, label %bb24, label %bb25
bb24:
  %t100 = load i64, ptr %l10, !tbaa !24
  store i64 %t100, ptr %l71, !tbaa !24
  %t101 = load ptr, ptr %l4, !tbaa !29
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t101)
  store i64 %t103, ptr %l73
  br label %bb26
bb25:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb27
bb26:
  %t104 = load i64, ptr %l71, !tbaa !24
  %t105 = load i64, ptr %l73, !tbaa !24
  %t106 = icmp slt i64 %t104, %t105
  store i1 %t106, ptr %l70, !tbaa !21
  br label %bb27
bb27:
  %t108 = load i1, ptr %l70, !tbaa !21
  br i1 %t108, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l75, !tbaa !29
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = shl i64 1, 32
  %t113 = sub i64 %t111, 1
  %t116 = and i64 %t110, %t113
  store i64 %t116, ptr %l79, !tbaa !24
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Call", ptr %t117, i32 0, i32 1
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l81, !tbaa !27
  %t121 = load i64, ptr %l10, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  store ptr %t126, ptr %l83, !tbaa !29
  %t127 = load ptr, ptr %l4, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t127, i64 %t128)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %l86
  br label %bb30
bb29:
  br label %bb33
bb30:
  %t133 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s5, ptr %l86)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l88
  br label %bb31
bb31:
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l88
  %t135 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %t135
  %t136 = load %"compiler/source:Span", ptr %l5
  %t137 = load ptr, ptr %l75, !tbaa !29
  %t138 = load i64, ptr %l79, !tbaa !24
  %t139 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %s5, ptr %t137, i64 %t138, ptr %t139, ptr %t135, %"compiler/source:Span" %t136, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, i1 true, i1 false)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t142 = load i64, ptr %l8, !tbaa !24
  %t145 = add i64 %t142, 1
  store i64 %t145, ptr %l8, !tbaa !24
  br label %bb14
bb35:
  %t147 = load ptr, ptr %l6, !tbaa !29
  %t149 = getelementptr %"compiler/free:Free", ptr %t147, i32 0, i32 74
  %t150 = load i64, ptr %l2, !tbaa !24
  %t153 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t149, i64 %t150)
  store ptr %t153, ptr %l97
  br label %bb36
bb36:
  %t154 = load ptr, ptr %l97, !tbaa !29
  store ptr %t154, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb37
bb37:
  %t155 = load i64, ptr %l12, !tbaa !24
  store i64 %t155, ptr %l98, !tbaa !24
  %t156 = load ptr, ptr %l11, !tbaa !29
  store ptr %t156, ptr %l99, !tbaa !29
  %t157 = call ptr @__olang_scope_hold(ptr %v0)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l100, !tbaa !24
  %t159 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t159, label %bb38, label %bb39
bb38:
  %t161 = load ptr, ptr %l99, !tbaa !29
  %t162 = call ptr @__olang_region_or(ptr %t161, ptr %v0)
  %t163 = call ptr @__olang_scope_hold(ptr %t162)
  %t164 = ptrtoint ptr %t163 to i64
  store i64 %t164, ptr %l100, !tbaa !24
  br label %bb39
bb39:
  %t165 = load ptr, ptr %l11, !tbaa !29
  %t166 = load i64, ptr %l100
  %t167 = inttoptr i64 %t166 to ptr
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t167, ptr %t165)
  store i64 %t169, ptr %l103
  br label %bb40
bb40:
  %t170 = load i64, ptr %l98, !tbaa !24
  %t171 = load i64, ptr %l103, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb41, label %bb42
bb41:
  br label %bb58
bb42:
  br label %bb43
bb43:
  %t176 = load ptr, ptr %l11, !tbaa !29
  store ptr %t176, ptr %l106, !tbaa !29
  %t177 = call ptr @__olang_scope_hold(ptr %v0)
  %t178 = ptrtoint ptr %t177 to i64
  store i64 %t178, ptr %l107, !tbaa !24
  %t179 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t179, label %bb44, label %bb45
bb44:
  %t181 = load ptr, ptr %l106, !tbaa !29
  %t182 = call ptr @__olang_region_or(ptr %t181, ptr %v0)
  %t183 = call ptr @__olang_scope_hold(ptr %t182)
  %t184 = ptrtoint ptr %t183 to i64
  store i64 %t184, ptr %l107, !tbaa !24
  br label %bb45
bb45:
  %t185 = load ptr, ptr %l11, !tbaa !29
  %t186 = load i64, ptr %l12, !tbaa !24
  %t187 = load i64, ptr %l107
  %t188 = inttoptr i64 %t187 to ptr
  %t191 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t188, ptr %t185, i64 %t186)
  store i64 %t191, ptr %l111
  br label %bb46
bb46:
  %t192 = load i64, ptr %l111, !tbaa !24
  store i64 %t192, ptr %l13, !tbaa !24
  %t193 = load i64, ptr %l13, !tbaa !24
  %t194 = load i64, ptr %l3, !tbaa !24
  %t197 = sub i64 %t193, %t194
  %t199 = icmp sge i64 %t197, 0
  br i1 %t199, label %bb47, label %bb48
bb47:
  %t201 = load i64, ptr %l13, !tbaa !24
  %t202 = load i64, ptr %l3, !tbaa !24
  %t205 = sub i64 %t201, %t202
  store i64 %t205, ptr %l119, !tbaa !24
  %t206 = load ptr, ptr %l4, !tbaa !29
  %t208 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t206)
  store i64 %t208, ptr %l121
  br label %bb49
bb48:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb50
bb49:
  %t209 = load i64, ptr %l119, !tbaa !24
  %t210 = load i64, ptr %l121, !tbaa !24
  %t211 = icmp slt i64 %t209, %t210
  store i1 %t211, ptr %l116, !tbaa !21
  br label %bb50
bb50:
  %t213 = load i1, ptr %l116, !tbaa !21
  br i1 %t213, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s9
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l123, !tbaa !29
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Call", ptr %t215, i32 0, i32 1
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  store { i64, ptr } %t218, ptr %l125, !tbaa !27
  %t219 = load i64, ptr %l13, !tbaa !24
  %t220 = load i64, ptr %l3, !tbaa !24
  %t223 = sub i64 %t219, %t220
  %t225 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr ptr, ptr %t226, i64 %t223
  %t228 = load ptr, ptr %t227, !tbaa !39
  store ptr %t228, ptr %l129, !tbaa !29
  %t229 = load ptr, ptr %l4, !tbaa !29
  %t230 = load i64, ptr %l13, !tbaa !24
  %t231 = load i64, ptr %l3, !tbaa !24
  %t234 = sub i64 %t230, %t231
  %t237 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t229, i64 %t234)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t237, ptr %l134
  br label %bb53
bb52:
  br label %bb56
bb53:
  %t239 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s9, ptr %l134)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l136
  br label %bb54
bb54:
  %t240 = load %"compiler/source:Span", ptr %l5
  %t241 = load ptr, ptr %l123, !tbaa !29
  %t242 = load ptr, ptr %l129, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeArg(ptr %v0, ptr %v1, ptr %v2, ptr %t241, ptr %t242, ptr %l136, %"compiler/source:Span" %t240)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t245 = load i64, ptr %l12, !tbaa !24
  %t248 = add i64 %t245, 1
  store i64 %t248, ptr %l12, !tbaa !24
  br label %bb37
bb58:
  %t250 = load ptr, ptr %l6, !tbaa !29
  %t252 = getelementptr %"compiler/free:Free", ptr %t250, i32 0, i32 71
  %t253 = load i64, ptr %l2, !tbaa !24
  %t256 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t252, i64 %t253)
  store ptr %t256, ptr %l145
  br label %bb59
bb59:
  %t257 = load ptr, ptr %l145, !tbaa !29
  store ptr %t257, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb60
bb60:
  %t258 = load i64, ptr %l15, !tbaa !24
  store i64 %t258, ptr %l146, !tbaa !24
  %t259 = load ptr, ptr %l14, !tbaa !29
  store ptr %t259, ptr %l147, !tbaa !29
  %t260 = call ptr @__olang_scope_hold(ptr %v0)
  %t261 = ptrtoint ptr %t260 to i64
  store i64 %t261, ptr %l148, !tbaa !24
  %t262 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t262, label %bb61, label %bb62
bb61:
  %t264 = load ptr, ptr %l147, !tbaa !29
  %t265 = call ptr @__olang_region_or(ptr %t264, ptr %v0)
  %t266 = call ptr @__olang_scope_hold(ptr %t265)
  %t267 = ptrtoint ptr %t266 to i64
  store i64 %t267, ptr %l148, !tbaa !24
  br label %bb62
bb62:
  %t268 = load ptr, ptr %l14, !tbaa !29
  %t269 = load i64, ptr %l148
  %t270 = inttoptr i64 %t269 to ptr
  %t272 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t270, ptr %t268)
  store i64 %t272, ptr %l151
  br label %bb63
bb63:
  %t273 = load i64, ptr %l146, !tbaa !24
  %t274 = load i64, ptr %l151, !tbaa !24
  %t275 = icmp slt i64 %t273, %t274
  %t277 = xor i1 %t275, true
  br i1 %t277, label %bb64, label %bb65
bb64:
  br label %bb81
bb65:
  br label %bb66
bb66:
  %t279 = load ptr, ptr %l14, !tbaa !29
  store ptr %t279, ptr %l154, !tbaa !29
  %t280 = call ptr @__olang_scope_hold(ptr %v0)
  %t281 = ptrtoint ptr %t280 to i64
  store i64 %t281, ptr %l155, !tbaa !24
  %t282 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t282, label %bb67, label %bb68
bb67:
  %t284 = load ptr, ptr %l154, !tbaa !29
  %t285 = call ptr @__olang_region_or(ptr %t284, ptr %v0)
  %t286 = call ptr @__olang_scope_hold(ptr %t285)
  %t287 = ptrtoint ptr %t286 to i64
  store i64 %t287, ptr %l155, !tbaa !24
  br label %bb68
bb68:
  %t288 = load ptr, ptr %l14, !tbaa !29
  %t289 = load i64, ptr %l15, !tbaa !24
  %t290 = load i64, ptr %l155
  %t291 = inttoptr i64 %t290 to ptr
  %t294 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t291, ptr %t288, i64 %t289)
  store i64 %t294, ptr %l159
  br label %bb69
bb69:
  %t295 = load i64, ptr %l159, !tbaa !24
  store i64 %t295, ptr %l16, !tbaa !24
  %t296 = load i64, ptr %l16, !tbaa !24
  %t297 = load i64, ptr %l3, !tbaa !24
  %t300 = sub i64 %t296, %t297
  %t302 = icmp sge i64 %t300, 0
  br i1 %t302, label %bb70, label %bb71
bb70:
  %t304 = load i64, ptr %l16, !tbaa !24
  %t305 = load i64, ptr %l3, !tbaa !24
  %t308 = sub i64 %t304, %t305
  store i64 %t308, ptr %l167, !tbaa !24
  %t309 = load ptr, ptr %l4, !tbaa !29
  %t311 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t309)
  store i64 %t311, ptr %l169
  br label %bb72
bb71:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb73
bb72:
  %t312 = load i64, ptr %l167, !tbaa !24
  %t313 = load i64, ptr %l169, !tbaa !24
  %t314 = icmp slt i64 %t312, %t313
  store i1 %t314, ptr %l164, !tbaa !21
  br label %bb73
bb73:
  %t316 = load i1, ptr %l164, !tbaa !21
  br i1 %t316, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l171, !tbaa !29
  %t318 = load ptr, ptr %l4, !tbaa !29
  %t319 = load i64, ptr %l16, !tbaa !24
  %t320 = load i64, ptr %l3, !tbaa !24
  %t323 = sub i64 %t319, %t320
  %t326 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t318, i64 %t323)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t326, ptr %l176
  br label %bb76
bb75:
  br label %bb79
bb76:
  %t328 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s13, ptr %l176)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t328, ptr %l178
  br label %bb77
bb77:
  %t329 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l178
  %t330 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t329, ptr %t330
  %t331 = load %"compiler/source:Span", ptr %l5
  %t332 = load ptr, ptr %l171, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v2, ptr %s13, ptr %t332, ptr %t330, %"compiler/source:Span" %t331, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t335 = load i64, ptr %l15, !tbaa !24
  %t338 = add i64 %t335, 1
  store i64 %t338, ptr %l15, !tbaa !24
  br label %bb60
bb81:
  %t340 = load ptr, ptr %l6, !tbaa !29
  %t342 = getelementptr %"compiler/free:Free", ptr %t340, i32 0, i32 72
  %t343 = load i64, ptr %l2, !tbaa !24
  %t346 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t342, i64 %t343)
  store ptr %t346, ptr %l187
  br label %bb82
bb82:
  %t347 = load ptr, ptr %l187, !tbaa !29
  store ptr %t347, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb83
bb83:
  %t348 = load i64, ptr %l18, !tbaa !24
  store i64 %t348, ptr %l188, !tbaa !24
  %t349 = load ptr, ptr %l17, !tbaa !29
  store ptr %t349, ptr %l189, !tbaa !29
  %t350 = call ptr @__olang_scope_hold(ptr %v0)
  %t351 = ptrtoint ptr %t350 to i64
  store i64 %t351, ptr %l190, !tbaa !24
  %t352 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t352, label %bb84, label %bb85
bb84:
  %t354 = load ptr, ptr %l189, !tbaa !29
  %t355 = call ptr @__olang_region_or(ptr %t354, ptr %v0)
  %t356 = call ptr @__olang_scope_hold(ptr %t355)
  %t357 = ptrtoint ptr %t356 to i64
  store i64 %t357, ptr %l190, !tbaa !24
  br label %bb85
bb85:
  %t358 = load ptr, ptr %l17, !tbaa !29
  %t359 = load i64, ptr %l190
  %t360 = inttoptr i64 %t359 to ptr
  %t362 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t360, ptr %t358)
  store i64 %t362, ptr %l193
  br label %bb86
bb86:
  %t363 = load i64, ptr %l188, !tbaa !24
  %t364 = load i64, ptr %l193, !tbaa !24
  %t365 = icmp slt i64 %t363, %t364
  %t367 = xor i1 %t365, true
  br i1 %t367, label %bb87, label %bb88
bb87:
  br label %bb105
bb88:
  br label %bb89
bb89:
  %t369 = load ptr, ptr %l17, !tbaa !29
  store ptr %t369, ptr %l196, !tbaa !29
  %t370 = call ptr @__olang_scope_hold(ptr %v0)
  %t371 = ptrtoint ptr %t370 to i64
  store i64 %t371, ptr %l197, !tbaa !24
  %t372 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t372, label %bb90, label %bb91
bb90:
  %t374 = load ptr, ptr %l196, !tbaa !29
  %t375 = call ptr @__olang_region_or(ptr %t374, ptr %v0)
  %t376 = call ptr @__olang_scope_hold(ptr %t375)
  %t377 = ptrtoint ptr %t376 to i64
  store i64 %t377, ptr %l197, !tbaa !24
  br label %bb91
bb91:
  %t378 = load ptr, ptr %l17, !tbaa !29
  %t379 = load i64, ptr %l18, !tbaa !24
  %t380 = load i64, ptr %l197
  %t381 = inttoptr i64 %t380 to ptr
  %t384 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t381, ptr %t378, i64 %t379)
  store i64 %t384, ptr %l201
  br label %bb92
bb92:
  %t385 = load i64, ptr %l201, !tbaa !24
  store i64 %t385, ptr %l19, !tbaa !24
  %t386 = load i64, ptr %l19, !tbaa !24
  %t387 = load i64, ptr %l3, !tbaa !24
  %t390 = sub i64 %t386, %t387
  %t392 = icmp sge i64 %t390, 0
  br i1 %t392, label %bb93, label %bb94
bb93:
  %t394 = load i64, ptr %l19, !tbaa !24
  %t395 = load i64, ptr %l3, !tbaa !24
  %t398 = sub i64 %t394, %t395
  store i64 %t398, ptr %l209, !tbaa !24
  %t399 = load ptr, ptr %l4, !tbaa !29
  %t401 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v2, ptr %t399)
  store i64 %t401, ptr %l211
  br label %bb95
bb94:
  store i1 false, ptr %l206, !tbaa !21
  br label %bb96
bb95:
  %t402 = load i64, ptr %l209, !tbaa !24
  %t403 = load i64, ptr %l211, !tbaa !24
  %t404 = icmp slt i64 %t402, %t403
  store i1 %t404, ptr %l206, !tbaa !21
  br label %bb96
bb96:
  %t406 = load i1, ptr %l206, !tbaa !21
  br i1 %t406, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s17
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l213, !tbaa !29
  %t408 = load ptr, ptr %l6, !tbaa !29
  store ptr %t408, ptr %l214, !tbaa !29
  %t409 = load ptr, ptr %l4, !tbaa !29
  %t410 = load i64, ptr %l19, !tbaa !24
  %t411 = load i64, ptr %l3, !tbaa !24
  %t414 = sub i64 %t410, %t411
  %t417 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v2, ptr %v2, ptr %t409, i64 %t414)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t417, ptr %l219
  br label %bb99
bb98:
  br label %bb103
bb99:
  %t419 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %s17, ptr %l219)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t419, ptr %l221
  br label %bb100
bb100:
  %t420 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221
  %t421 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t420, ptr %t421
  %t422 = load ptr, ptr %l214, !tbaa !29
  %t424 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v2, ptr %s17, ptr %t422, ptr %t421)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t424, ptr %l223
  br label %bb101
bb101:
  %t425 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l223
  %t426 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t425, ptr %t426
  %t427 = load %"compiler/source:Span", ptr %l5
  %t428 = load ptr, ptr %l213, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s17, ptr %s17, ptr %t428, ptr %t426, %"compiler/source:Span" %t427, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t431 = load i64, ptr %l18, !tbaa !24
  %t434 = add i64 %t431, 1
  store i64 %t434, ptr %l18, !tbaa !24
  br label %bb83
bb105:
  %t436 = load ptr, ptr %l6, !tbaa !29
  %t438 = getelementptr %"compiler/free:Free", ptr %t436, i32 0, i32 78
  %t439 = load i64, ptr %l2, !tbaa !24
  %t442 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t438, i64 %t439)
  store i1 %t442, ptr %l232
  br label %bb106
bb106:
  %t443 = load i1, ptr %l232, !tbaa !21
  br i1 %t443, label %bb107, label %bb108
bb107:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l5
  %t446 = load ptr, ptr %l1, !tbaa !29
  %t447 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t444, %"compiler/source:Span" %t445, ptr %t446, i64 %t447)
  br label %bb109
bb108:
  %t452 = load ptr, ptr %l6, !tbaa !29
  %t454 = getelementptr %"compiler/free:Free", ptr %t452, i32 0, i32 75
  %t455 = load i64, ptr %l2, !tbaa !24
  %t458 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t454, i64 %t455)
  store ptr %t458, ptr %l240
  br label %bb110
bb109:
  br label %bb140
bb110:
  %t459 = load ptr, ptr %l240, !tbaa !29
  store ptr %t459, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb111
bb111:
  %t460 = load i64, ptr %l21, !tbaa !24
  store i64 %t460, ptr %l241, !tbaa !24
  %t461 = load ptr, ptr %l20, !tbaa !29
  store ptr %t461, ptr %l242, !tbaa !29
  %t462 = call ptr @__olang_scope_hold(ptr %v0)
  %t463 = ptrtoint ptr %t462 to i64
  store i64 %t463, ptr %l243, !tbaa !24
  %t464 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t464, label %bb112, label %bb113
bb112:
  %t466 = load ptr, ptr %l242, !tbaa !29
  %t467 = call ptr @__olang_region_or(ptr %t466, ptr %v0)
  %t468 = call ptr @__olang_scope_hold(ptr %t467)
  %t469 = ptrtoint ptr %t468 to i64
  store i64 %t469, ptr %l243, !tbaa !24
  br label %bb113
bb113:
  %t470 = load ptr, ptr %l20, !tbaa !29
  %t471 = load i64, ptr %l243
  %t472 = inttoptr i64 %t471 to ptr
  %t474 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t472, ptr %t470)
  store i64 %t474, ptr %l246
  br label %bb114
bb114:
  %t475 = load i64, ptr %l241, !tbaa !24
  %t476 = load i64, ptr %l246, !tbaa !24
  %t477 = icmp slt i64 %t475, %t476
  %t479 = xor i1 %t477, true
  br i1 %t479, label %bb115, label %bb116
bb115:
  br label %bb124
bb116:
  br label %bb117
bb117:
  %t481 = load ptr, ptr %l20, !tbaa !29
  store ptr %t481, ptr %l249, !tbaa !29
  %t482 = call ptr @__olang_scope_hold(ptr %v0)
  %t483 = ptrtoint ptr %t482 to i64
  store i64 %t483, ptr %l250, !tbaa !24
  %t484 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t484, label %bb118, label %bb119
bb118:
  %t486 = load ptr, ptr %l249, !tbaa !29
  %t487 = call ptr @__olang_region_or(ptr %t486, ptr %v0)
  %t488 = call ptr @__olang_scope_hold(ptr %t487)
  %t489 = ptrtoint ptr %t488 to i64
  store i64 %t489, ptr %l250, !tbaa !24
  br label %bb119
bb119:
  %t490 = load ptr, ptr %l20, !tbaa !29
  %t491 = load i64, ptr %l21, !tbaa !24
  %t492 = load i64, ptr %l250
  %t493 = inttoptr i64 %t492 to ptr
  %t496 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t493, ptr %t490, i64 %t491)
  store i64 %t496, ptr %l254
  br label %bb120
bb120:
  %t497 = load i64, ptr %l254, !tbaa !24
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l255, !tbaa !29
  store i64 %t497, ptr %l256, !tbaa !24
  %t500 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t500, ptr %l257, !tbaa !24
  %t501 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t501, ptr %l258
  %t502 = load ptr, ptr %l1, !tbaa !29
  %t504 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t502)
  store %"compiler/source:Span" %t504, ptr %l260
  br label %bb121
bb121:
  %t505 = load i64, ptr %l2, !tbaa !24
  %t506 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t507 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t508 = load ptr, ptr %l255, !tbaa !29
  %t509 = load i64, ptr %l256, !tbaa !24
  %t510 = load i64, ptr %l257, !tbaa !24
  %t511 = load %"compiler/source:Span", ptr %l258
  %t512 = load %"compiler/source:Span", ptr %l260
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t508, i64 %t509, i64 %t510, %"compiler/source:Span" %t511, %"compiler/source:Span" %t512, i64 %t505, i1 false, i64 %t506, i32 %t507)
  br label %bb122
bb122:
  br label %bb123
bb123:
  %t516 = load i64, ptr %l21, !tbaa !24
  %t519 = add i64 %t516, 1
  store i64 %t519, ptr %l21, !tbaa !24
  br label %bb111
bb124:
  %t521 = load ptr, ptr %l6, !tbaa !29
  %t523 = getelementptr %"compiler/free:Free", ptr %t521, i32 0, i32 79
  %t524 = load i64, ptr %l2, !tbaa !24
  %t527 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t523, i64 %t524)
  store ptr %t527, ptr %l270
  br label %bb125
bb125:
  %t528 = load ptr, ptr %l270, !tbaa !29
  store ptr %t528, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb126
bb126:
  %t529 = load i64, ptr %l24, !tbaa !24
  store i64 %t529, ptr %l271, !tbaa !24
  %t530 = load ptr, ptr %l23, !tbaa !29
  store ptr %t530, ptr %l272, !tbaa !29
  %t531 = call ptr @__olang_scope_hold(ptr %v0)
  %t532 = ptrtoint ptr %t531 to i64
  store i64 %t532, ptr %l273, !tbaa !24
  %t533 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t533, label %bb127, label %bb128
bb127:
  %t535 = load ptr, ptr %l272, !tbaa !29
  %t536 = call ptr @__olang_region_or(ptr %t535, ptr %v0)
  %t537 = call ptr @__olang_scope_hold(ptr %t536)
  %t538 = ptrtoint ptr %t537 to i64
  store i64 %t538, ptr %l273, !tbaa !24
  br label %bb128
bb128:
  %t539 = load ptr, ptr %l23, !tbaa !29
  %t540 = load i64, ptr %l273
  %t541 = inttoptr i64 %t540 to ptr
  %t543 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %t541, ptr %t539)
  store i64 %t543, ptr %l276
  br label %bb129
bb129:
  %t544 = load i64, ptr %l271, !tbaa !24
  %t545 = load i64, ptr %l276, !tbaa !24
  %t546 = icmp slt i64 %t544, %t545
  %t548 = xor i1 %t546, true
  br i1 %t548, label %bb130, label %bb131
bb130:
  br label %bb139
bb131:
  br label %bb132
bb132:
  %t550 = load ptr, ptr %l23, !tbaa !29
  store ptr %t550, ptr %l279, !tbaa !29
  %t551 = call ptr @__olang_scope_hold(ptr %v0)
  %t552 = ptrtoint ptr %t551 to i64
  store i64 %t552, ptr %l280, !tbaa !24
  %t553 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t553, label %bb133, label %bb134
bb133:
  %t555 = load ptr, ptr %l279, !tbaa !29
  %t556 = call ptr @__olang_region_or(ptr %t555, ptr %v0)
  %t557 = call ptr @__olang_scope_hold(ptr %t556)
  %t558 = ptrtoint ptr %t557 to i64
  store i64 %t558, ptr %l280, !tbaa !24
  br label %bb134
bb134:
  %t559 = load ptr, ptr %l23, !tbaa !29
  %t560 = load i64, ptr %l24, !tbaa !24
  %t561 = load i64, ptr %l280
  %t562 = inttoptr i64 %t561 to ptr
  %t565 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %t562, ptr %t559, i64 %t560)
  store i64 %t565, ptr %l284
  br label %bb135
bb135:
  %t566 = load i64, ptr %l284, !tbaa !24
  %t567 = load ptr, ptr %l0, !tbaa !29
  store ptr %t567, ptr %l285, !tbaa !29
  store i64 %t566, ptr %l286, !tbaa !24
  %t569 = load i64, ptr @G_2ecompiler_2ffree_2eLCall, !tbaa !24
  store i64 %t569, ptr %l287, !tbaa !24
  %t570 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t570, ptr %l288
  %t571 = load ptr, ptr %l1, !tbaa !29
  %t573 = call %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v1, ptr %t571)
  store %"compiler/source:Span" %t573, ptr %l290
  br label %bb136
bb136:
  %t574 = load i64, ptr %l2, !tbaa !24
  %t575 = load i64, ptr @G_2ecompiler_2ffree_2eWalkCall, !tbaa !24
  %t576 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t577 = load ptr, ptr %l285, !tbaa !29
  %t578 = load i64, ptr %l286, !tbaa !24
  %t579 = load i64, ptr %l287, !tbaa !24
  %t580 = load %"compiler/source:Span", ptr %l288
  %t581 = load %"compiler/source:Span", ptr %l290
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t577, i64 %t578, i64 %t579, %"compiler/source:Span" %t580, %"compiler/source:Span" %t581, i64 %t574, i1 true, i64 %t575, i32 %t576)
  br label %bb137
bb137:
  br label %bb138
bb138:
  %t585 = load i64, ptr %l24, !tbaa !24
  %t588 = add i64 %t585, 1
  store i64 %t588, ptr %l24, !tbaa !24
  br label %bb126
bb139:
  br label %bb140
bb140:
  %t590 = load ptr, ptr %l0, !tbaa !29
  %t591 = load ptr, ptr %l1, !tbaa !29
  %t592 = load i64, ptr %l2, !tbaa !24
  %t593 = load i64, ptr %l3, !tbaa !24
  %t594 = load ptr, ptr %l4, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviaCall(ptr %v0, ptr %v1, ptr %v2, ptr %t590, ptr %t591, i64 %t592, i64 %t593, ptr %t594, %"compiler/source:Span" %t595)
  br label %bb141
bb141:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %lp5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca i1
  %l46 = alloca i64
  %l52 = alloca ptr
  %l54 = alloca i32
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca i32
  %l61 = alloca i1
  %l63 = alloca ptr
  %l65 = alloca i32
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l67 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l69 = alloca i64
  %l71 = alloca i64
  %l76 = alloca i64
  %l78 = alloca i64
  %l81 = alloca i1
  %l82 = alloca ptr
  %l84 = alloca i64
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca ptr
  %l89 = alloca i64
  %l90 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t6, ptr %t7)
  store i64 %t10, ptr %l15
  br label %bb1
bb1:
  %t11 = load i64, ptr %l15, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l16, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  store i64 %t16, ptr %l18, !tbaa !24
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i64 @compiler_2ffree_2etempPlaceCall(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l20
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l16, !tbaa !29
  %t21 = load i64, ptr %l18, !tbaa !24
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eBlockCopy(ptr %v0, ptr %t20, i64 %t21, i64 %t22)
  store i64 %t23, ptr %l21
  br label %bb3
bb3:
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  store i1 %t25, ptr %l4, !tbaa !21
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = icmp sge i64 %t27, 0
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t31 = load i1, ptr %l4, !tbaa !21
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l25, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t35 = load i1, ptr %l25, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l29, !tbaa !29
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t38)
  store i32 %t40, ptr %l31
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t41 = load ptr, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l29, !tbaa !29
  %t43 = load i32, ptr %l31, !tbaa !23
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t41, ptr %t42, i32 %t43)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l32
  br label %bb10
bb10:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %rv
  br label %ret
bb11:
  %t46 = load i1, ptr %l4, !tbaa !21
  br i1 %t46, label %bb12, label %bb13
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t52 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etempReach(ptr %v0, ptr %v1, ptr %v2, ptr %t48, ptr %t49)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t52, ptr %l37
  br label %bb14
bb13:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t53, ptr %t54)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l40
  br label %bb15
bb14:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l34
  br label %bb16
bb15:
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l34
  br label %bb16
bb16:
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t60, ptr %lp5
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t62 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %t62
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t63, i32 0, i32 55
  %t66 = load i64, ptr %t65, !tbaa !24
  %t68 = icmp sge i64 %t66, 0
  br i1 %t68, label %bb17, label %bb18
bb17:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = call i64 @compiler_2ffree_2ereadPlaceCall(ptr %v1, ptr %t70)
  store i64 %t72, ptr %l46
  br label %bb19
bb18:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb20
bb19:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/free:walker", ptr %t73, i32 0, i32 55
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = load i64, ptr %l46, !tbaa !24
  %t79 = icmp eq i64 %t77, %t76
  store i1 %t79, ptr %l44, !tbaa !21
  br label %bb20
bb20:
  %t81 = load i1, ptr %l44, !tbaa !21
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t82 = load ptr, ptr %lp5
  %t83 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t83, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t85)
  store ptr %t87, ptr %l52
  br label %bb24
bb24:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t88)
  store i32 %t90, ptr %l54
  br label %bb25
bb25:
  %t91 = load ptr, ptr %l52, !tbaa !29
  %t92 = load i32, ptr %l54, !tbaa !23
  %t93 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t93, ptr %l55
  br label %bb26
bb26:
  %t94 = load i1, ptr %l55, !tbaa !21
  %t95 = xor i1 %t94, true
  br i1 %t95, label %bb27, label %bb28
bb27:
  %t97 = load ptr, ptr %l2, !tbaa !29
  store ptr %t97, ptr %l58, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t98)
  store i32 %t100, ptr %l60
  br label %bb29
bb28:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb31
bb29:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t102 = load i32, ptr %l60, !tbaa !23
  %t103 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefsBeyondParts(ptr %v0, ptr %t101, i32 %t102)
  store i1 %t103, ptr %l61
  br label %bb30
bb30:
  %t104 = load i1, ptr %l61, !tbaa !21
  %t105 = xor i1 %t104, true
  store i1 %t105, ptr %l57, !tbaa !21
  br label %bb31
bb31:
  %t107 = load i1, ptr %l57, !tbaa !21
  br i1 %t107, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t108 = load ptr, ptr %l2, !tbaa !29
  store ptr %t108, ptr %l63, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t109)
  store i32 %t111, ptr %l65
  br label %bb34
bb33:
  br label %bb61
bb34:
  %t112 = load ptr, ptr %l63, !tbaa !29
  %t113 = load i32, ptr %l65, !tbaa !23
  %t114 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s3, ptr %t112, i32 %t113)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %l66
  br label %bb35
bb35:
  %t115 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t115, ptr %l6
  %t116 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t116, ptr %l67
  br label %bb36
bb36:
  %t117 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l67
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t117, ptr %l7
  %t118 = load ptr, ptr %lp5
  store ptr %t118, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t120 = load i64, ptr %l9, !tbaa !24
  store i64 %t120, ptr %l69, !tbaa !24
  %t121 = load ptr, ptr %l8, !tbaa !29
  %t123 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t121)
  store i64 %t123, ptr %l71
  br label %bb38
bb38:
  %t124 = load i64, ptr %l69, !tbaa !24
  %t125 = load i64, ptr %l71, !tbaa !24
  %t126 = icmp slt i64 %t124, %t125
  %t128 = xor i1 %t126, true
  br i1 %t128, label %bb39, label %bb40
bb39:
  br label %bb59
bb40:
  br label %bb41
bb41:
  %t130 = load ptr, ptr %l8, !tbaa !29
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t130, i64 %t131)
  store i64 %t134, ptr %l76
  br label %bb42
bb42:
  %t135 = load i64, ptr %l76, !tbaa !24
  store i64 %t135, ptr %l10, !tbaa !24
  %t136 = load i64, ptr %l10, !tbaa !24
  %t138 = call i64 @compiler_2ffree_2eokind(i64 %t136)
  store i64 %t138, ptr %l78
  br label %bb43
bb43:
  %t139 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t140 = load i64, ptr %l78, !tbaa !24
  %t142 = icmp eq i64 %t140, %t139
  br i1 %t142, label %bb44, label %bb45
bb44:
  %t144 = load ptr, ptr %l2, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = load i64, ptr %l10, !tbaa !24
  %t147 = call i64 @compiler_2ffree_2eoval(i64 %t145)
  store i64 %t147, ptr %l84
  br label %bb46
bb45:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb48
bb46:
  %t148 = load ptr, ptr %l82, !tbaa !29
  %t149 = load i64, ptr %l84, !tbaa !24
  %t150 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %t148, i64 %t149)
  store i1 %t150, ptr %l85
  br label %bb47
bb47:
  %t151 = load i1, ptr %l85, !tbaa !21
  store i1 %t151, ptr %l81, !tbaa !21
  br label %bb48
bb48:
  %t152 = load i1, ptr %l81, !tbaa !21
  br i1 %t152, label %bb49, label %bb50
bb49:
  store ptr %l6, ptr %l87, !tbaa !29
  %t153 = load i64, ptr %l10, !tbaa !24
  %t155 = call i64 @compiler_2ffree_2eoval(i64 %t153)
  store i64 %t155, ptr %l89
  br label %bb51
bb50:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb53
bb51:
  %t156 = load ptr, ptr %l87, !tbaa !29
  %t157 = load i64, ptr %l89, !tbaa !24
  %t158 = call i1 @compiler_2ffree_2ehas(ptr %s3, ptr %t156, i64 %t157)
  store i1 %t158, ptr %l90
  br label %bb52
bb52:
  %t159 = load i1, ptr %l90, !tbaa !21
  store i1 %t159, ptr %l86, !tbaa !21
  br label %bb53
bb53:
  %t160 = load i1, ptr %l86, !tbaa !21
  %t161 = xor i1 %t160, true
  br i1 %t161, label %bb54, label %bb55
bb54:
  %t163 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s3, ptr %l7, i64 %t163)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t166 = load i64, ptr %l9, !tbaa !24
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %l9, !tbaa !24
  br label %bb37
bb59:
  %t171 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %s3, ptr %t171, ptr %l7, i64 -1)
  br label %bb60
bb60:
  %t174 = load ptr, ptr %lp5
  %t175 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t174
  call void @__olang_scope_close(ptr %s3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t175, ptr %rv
  br label %ret
bb61:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load ptr, ptr %lp5
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v2, ptr %t177, ptr %t178, i64 -1)
  br label %bb62
bb62:
  %t181 = load ptr, ptr %lp5
  %t182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t181
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t182, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecapSplit(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca i32
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca i1
  %l25 = alloca i1
  %l35 = alloca ptr
  %l37 = alloca i1
  %l39 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca i1
  %l52 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i1
  %l75 = alloca ptr
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1)
  store i32 %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load i32, ptr %l20, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l21, !tbaa !29
  store i1 false, ptr %l22, !tbaa !21
  %t6 = load ptr, ptr %l21, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l21, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l22, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l22, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l3
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t22, i32 0, i32 1
  %t24 = load i32, ptr %t23
  store i32 %t24, ptr %l4, !tbaa !23
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t28, i32 0, i32 2
  %t30 = load ptr, ptr %t29
  store ptr %t30, ptr %l5, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t34, i32 0, i32 3
  %t36 = load i32, ptr %t35
  store i32 %t36, ptr %l6, !tbaa !23
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t38)
  store ptr %t40, ptr %l35
  br label %bb6
bb5:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t41 = load i32, ptr %l2, !tbaa !23
  %t42 = load ptr, ptr %l35, !tbaa !29
  %t44 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t42, i32 %t41)
  store i1 %t44, ptr %l37
  br label %bb7
bb7:
  %t45 = load i1, ptr %l37, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t48 = load i1, ptr %l25, !tbaa !21
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t51, i32 0, i32 0
  %t53 = load %"compiler/source:Span", ptr %t52
  store %"compiler/source:Span" %t53, ptr %l7
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t57, i32 0, i32 1
  %t59 = load i32, ptr %t58
  store i32 %t59, ptr %l8, !tbaa !23
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [5 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t63, i32 0, i32 2
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l9, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr { i64, [5 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t69, i32 0, i32 3
  %t71 = load i32, ptr %t70
  store i32 %t71, ptr %l10, !tbaa !23
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t73)
  store ptr %t75, ptr %l49
  br label %bb11
bb10:
  store i1 false, ptr %l39, !tbaa !21
  br label %bb13
bb11:
  %t76 = load i32, ptr %l2, !tbaa !23
  %t77 = load ptr, ptr %l49, !tbaa !29
  %t79 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %t77, i32 %t76)
  store i1 %t79, ptr %l51
  br label %bb12
bb12:
  %t80 = load i1, ptr %l51, !tbaa !21
  store i1 %t80, ptr %l39, !tbaa !21
  br label %bb13
bb13:
  %t81 = load i1, ptr %l39, !tbaa !21
  br i1 %t81, label %bb14, label %bb15
bb14:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr { i64, [5 x i64] }, ptr %t82, i32 0, i32 1
  %t85 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t84, i32 0, i32 0
  %t86 = load %"compiler/source:Span", ptr %t85
  store %"compiler/source:Span" %t86, ptr %l11
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr { i64, [5 x i64] }, ptr %t88, i32 0, i32 1
  %t91 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t90, i32 0, i32 1
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l12, !tbaa !23
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l13, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr { i64, [5 x i64] }, ptr %t100, i32 0, i32 1
  %t103 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t102, i32 0, i32 3
  %t104 = load i32, ptr %t103
  store i32 %t104, ptr %l14, !tbaa !23
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/free:walker", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i32, ptr %l2, !tbaa !23
  %t113 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %t109, i32 %t110)
  store i1 %t113, ptr %l64
  br label %bb16
bb15:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb17
bb16:
  %t114 = load i1, ptr %l64, !tbaa !21
  store i1 %t114, ptr %l52, !tbaa !21
  br label %bb17
bb17:
  %t115 = load i1, ptr %l52, !tbaa !21
  br i1 %t115, label %bb18, label %bb19
bb18:
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr { i64, [5 x i64] }, ptr %t116, i32 0, i32 1
  %t119 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t118, i32 0, i32 0
  %t120 = load %"compiler/source:Span", ptr %t119
  store %"compiler/source:Span" %t120, ptr %l15
  %t122 = load ptr, ptr %l1, !tbaa !29
  %t124 = getelementptr { i64, [5 x i64] }, ptr %t122, i32 0, i32 1
  %t125 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t124, i32 0, i32 1
  %t126 = load i32, ptr %t125
  store i32 %t126, ptr %l16, !tbaa !23
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr { i64, [5 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t130, i32 0, i32 2
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l17, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  %t137 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t136, i32 0, i32 3
  %t138 = load i32, ptr %t137
  store i32 %t138, ptr %l18, !tbaa !23
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t140)
  store ptr %t142, ptr %l75
  br label %bb20
bb19:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb22
bb20:
  %t143 = load i32, ptr %l2, !tbaa !23
  %t144 = load ptr, ptr %l75, !tbaa !29
  %t146 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %t144, i32 %t143)
  store i1 %t146, ptr %l77
  br label %bb21
bb21:
  %t147 = load i1, ptr %l77, !tbaa !21
  %t148 = xor i1 %t147, true
  store i1 %t148, ptr %l65, !tbaa !21
  br label %bb22
bb22:
  %t150 = load i1, ptr %l65, !tbaa !21
  store i1 %t150, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecaptured(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i1 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %lp5 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i1
  %l14 = alloca i1
  %l15 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca ptr
  %l28 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t6, ptr %lp5
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t8 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %t8
  %t11 = xor i1 %a4, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t17 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecapSplit(ptr %v0, ptr %v1, ptr %t13, ptr %t14)
  store i1 %t17, ptr %l14
  br label %bb4
bb3:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb5
bb4:
  %t18 = load i1, ptr %l14, !tbaa !21
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = call ptr @__olang_scope_hold(ptr %v2)
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l15, !tbaa !24
  %t22 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ecaptured_2elocal_2e5
  br i1 %t22, label %bb8, label %bb9
bb7:
  br label %bb19
bb8:
  %t24 = call ptr @__olang_region_make(ptr %v2)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l15, !tbaa !24
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:walker", ptr %t26, i32 0, i32 0
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t30 = load ptr, ptr %lp5
  %t31 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t30
  %t33 = load i64, ptr %l15
  %t34 = inttoptr i64 %t33 to ptr
  %t35 = call ptr @__olang_scope_alloc_a(ptr %t34, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t31, ptr %t35
  %t36 = load i64, ptr %l15
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = load i64, ptr %l15
  %t39 = inttoptr i64 %t38 to ptr
  %t42 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %t37, ptr %t39, ptr %t29, ptr %t35)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t42, ptr %l21
  br label %bb10
bb10:
  %t43 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ecaptured_2elocal_2e5
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load i64, ptr %l15
  %t46 = inttoptr i64 %t45 to ptr
  %t47 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = call ptr @__olang_region_or(ptr %t49, ptr null)
  %t51 = call ptr @__olang_region_home(ptr %t50)
  %t52 = icmp ne ptr %t51, null
  %t53 = select i1 %t52, ptr %t51, ptr null
  call void @__olang_region_settle_in(ptr %t46, ptr %t53)
  br label %bb12
bb12:
  %t54 = load ptr, ptr %lp5
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %l23
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t57 = load ptr, ptr %lp5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %t57
  %t58 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ecaptured_2elocal_2e5
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = call ptr @__olang_region_or(ptr %t62, ptr null)
  %t64 = call ptr @__olang_region_home(ptr %t63)
  %t65 = icmp ne ptr %t64, null
  %t66 = select i1 %t65, ptr %t64, ptr null
  call void @__olang_region_drop(ptr %t66)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l23
  br label %bb14
bb14:
  %t67 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t67, label %bb15, label %bb16
bb15:
  %t69 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23, i32 0, i32 0
  %t70 = load { i64, ptr }, ptr %t69
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  call void @__olang_region_release_part(ptr %t72, i64 %t71)
  store { i64, ptr } zeroinitializer, ptr %t69
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l26, !tbaa !29
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t74)
  store i32 %t76, ptr %l28
  br label %bb17
bb17:
  %t77 = load %"compiler/source:Span", ptr %l1
  %t79 = load ptr, ptr %l26, !tbaa !29
  %t80 = load i32, ptr %l28, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %v0, ptr %t79, i32 %t80, %"compiler/source:Span" %t77, { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d37, i32 0, i32 1) }, i1 true, i1 false, i1 false, i64 %a3, i1 false, i1 true)
  br label %bb18
bb18:
  br label %bb19
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %lp5
  %t85 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v2, ptr %s0, ptr %t83, ptr %t84, %"compiler/source:Span" %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb20
bb20:
  %t89 = load ptr, ptr %lp5
  %t90 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t89
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCalls(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l13 = alloca i1
  %l14 = alloca i32
  %l17 = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t7 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %a2)
  store i32 %t7, ptr %l8
  br label %bb2
bb2:
  %t8 = load i32, ptr %l8, !tbaa !23
  store i32 %t8, ptr %l4, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  store %"compiler/source:Span" %a1, ptr %l10
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t12 = load i32, ptr %l4, !tbaa !23
  %t15 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t11, i32 %t12)
  store i1 %t15, ptr %l13
  br label %bb3
bb3:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l17
  br label %bb6
bb5:
  %t22 = load i32, ptr %l4, !tbaa !23
  store i32 %t22, ptr %l14, !tbaa !23
  br label %bb7
bb6:
  %t24 = load i32, ptr %l17, !tbaa !23
  store i32 %t24, ptr %l14, !tbaa !23
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l9, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l10
  %t27 = load i32, ptr %l14, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %t25, %"compiler/source:Span" %t26, i32 %t27)
  br label %bb8
bb8:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexprOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i32
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca i32
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca %"compiler/free:leaf"
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca i64
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca i64
  %l64 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i1
  %l74 = alloca ptr
  %l75 = alloca i1
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l89 = alloca ptr
  %l90 = alloca i1
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca ptr
  %l102 = alloca i1
  %l112 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l113 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l116 = alloca ptr
  %l117 = alloca i1
  %l127 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca ptr
  %l132 = alloca i1
  %l141 = alloca i64
  %l147 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l149 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l152 = alloca ptr
  %l153 = alloca i1
  %l162 = alloca i64
  %l168 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l170 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca ptr
  %l174 = alloca i1
  %l185 = alloca ptr
  %l191 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l193 = alloca ptr
  %l195 = alloca ptr
  %l199 = alloca i32
  %l200 = alloca i64
  %l202 = alloca ptr
  %l203 = alloca i64
  %l205 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca i64
  %l213 = alloca i64
  %l214 = alloca i32
  %l215 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca i32
  %l220 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l224 = alloca i64
  %l225 = alloca ptr
  %l230 = alloca i64
  %l231 = alloca i64
  %l232 = alloca ptr
  %l233 = alloca i1
  %l244 = alloca i1
  %l248 = alloca i64
  %l249 = alloca { i64, ptr }
  %l251 = alloca i64
  %l255 = alloca i64
  %l260 = alloca { i64, ptr }
  %l263 = alloca ptr
  %l265 = alloca ptr
  %l269 = alloca %"compiler/typed:Local"
  %l271 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l273 = alloca i64
  %l275 = alloca i64
  %l280 = alloca %"compiler/free:leaf"
  %l281 = alloca %"compiler/free:leaf"
  %l282 = alloca i64
  %l284 = alloca { i64, ptr }
  %l285 = alloca i64
  %l286 = alloca { i64, ptr }
  %l290 = alloca ptr
  %l291 = alloca i64
  %l292 = alloca i64
  %l293 = alloca %"compiler/source:Span"
  %l294 = alloca %"compiler/source:Span"
  %l307 = alloca ptr
  %l309 = alloca i64
  %l310 = alloca %"compiler/source:Span"
  %l311 = alloca i64
  %l316 = alloca ptr
  %l318 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l319 = alloca i64
  %l321 = alloca { i64, ptr }
  %l322 = alloca i64
  %l323 = alloca { i64, ptr }
  %l328 = alloca %"compiler/free:retire"
  %l330 = alloca %"compiler/free:retire"
  %l335 = alloca i1
  %l336 = alloca i64
  %l337 = alloca { i64, ptr }
  %l339 = alloca i64
  %l351 = alloca { i64, ptr }
  %l354 = alloca ptr
  %l357 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l359 = alloca i64
  %l367 = alloca i1
  %l373 = alloca { i64, ptr }
  %l375 = alloca ptr
  %l376 = alloca i1
  %l381 = alloca ptr
  %l383 = alloca ptr
  %l386 = alloca i32
  %l387 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l388 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l394 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l398 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l399 = alloca ptr
  %l400 = alloca i1
  %l408 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l413 = alloca ptr
  %l414 = alloca ptr
  %l420 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l422 = alloca i64
  %l423 = alloca ptr
  %l427 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l429 = alloca i64
  %l430 = alloca ptr
  %l431 = alloca i1
  %l444 = alloca { i64, ptr }
  %l454 = alloca ptr
  %l462 = alloca ptr
  %l468 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l469 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l474 = alloca ptr
  %l478 = alloca ptr
  %l479 = alloca i1
  %l492 = alloca { i64, ptr }
  %l508 = alloca { i64, ptr }
  %l511 = alloca ptr
  %l514 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l516 = alloca i64
  %l524 = alloca ptr
  %l525 = alloca ptr
  %l531 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l533 = alloca i64
  %l534 = alloca ptr
  %l535 = alloca i1
  %l544 = alloca ptr
  %l550 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l551 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l562 = alloca { i64, ptr }
  %l569 = alloca ptr
  %l583 = alloca { i64, ptr }
  %l586 = alloca ptr
  %l589 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l591 = alloca i64
  %l598 = alloca ptr
  %l599 = alloca i1
  %l606 = alloca i64
  %l611 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l613 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l616 = alloca ptr
  %l617 = alloca i1
  %l622 = alloca i64
  %l626 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l628 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l631 = alloca ptr
  %l632 = alloca i1
  %l639 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l640 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l643 = alloca ptr
  %l645 = alloca i32
  %l646 = alloca i1
  %l648 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %s41 = alloca %olang.scope
  %s48 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call ptr @__olang_scope_hold(ptr %v2)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l62, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l62, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l62
  %t8 = inttoptr i64 %t7 to ptr
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t8, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l64
  br label %bb3
bb3:
  %t10 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t10, label %bb4, label %bb5
bb4:
  %t12 = load i64, ptr %l62
  %t13 = inttoptr i64 %t12 to ptr
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = call ptr @__olang_region_or(ptr %t16, ptr null)
  %t18 = call ptr @__olang_region_home(ptr %t17)
  %t19 = icmp ne ptr %t18, null
  %t20 = select i1 %t19, ptr %t18, ptr null
  call void @__olang_region_settle_in(ptr %t13, ptr %t20)
  br label %bb5
bb5:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l64
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 2
  %t25 = load i1, ptr %t24, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/free:walker", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/free:Free", ptr %t30, i32 0, i32 34
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l68, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l68, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2enoteReach(ptr %v0, ptr %v1, ptr %t36, ptr %t37)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l1, !tbaa !29
  store ptr %t40, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t41 = load ptr, ptr %l74, !tbaa !29
  %t42 = icmp ne ptr %t41, null
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l74, !tbaa !29
  %t45 = load i64, ptr %t44, !range !{i64 0, i64 18}
  %t47 = icmp eq i64 %t45, 2
  store i1 %t47, ptr %l75, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l75, !tbaa !21
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t51, i32 0, i32 1
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l3, !tbaa !23
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l4, !tbaa !29
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l4, !tbaa !29
  %t63 = load i32, ptr %l3, !tbaa !23
  %t67 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t61, ptr %t62, i32 %t63)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t67, ptr %l85
  br label %bb18
bb18:
  %t68 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l86
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l2
  %t70 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t70, label %bb19, label %bb20
bb19:
  %t72 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86, i32 0, i32 0
  %t73 = load { i64, ptr }, ptr %t72
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = call ptr @__olang_region_or(ptr %t74, ptr null)
  %t76 = call ptr @__olang_region_home(ptr %t75)
  %t77 = icmp ne ptr %t76, null
  %t78 = select i1 %t77, ptr %t76, ptr null
  call void @__olang_region_drop(ptr %t78)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l86
  br label %bb20
bb20:
  %t79 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l86, i32 0, i32 0
  %t82 = load { i64, ptr }, ptr %t81
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  call void @__olang_region_release_part(ptr %t84, i64 %t83)
  store { i64, ptr } zeroinitializer, ptr %t81
  br label %bb22
bb22:
  br label %bb373
bb23:
  %t85 = load ptr, ptr %l1, !tbaa !29
  store ptr %t85, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t86 = load ptr, ptr %l89, !tbaa !29
  %t87 = icmp ne ptr %t86, null
  br i1 %t87, label %bb24, label %bb25
bb24:
  %t89 = load ptr, ptr %l89, !tbaa !29
  %t90 = load i64, ptr %t89, !range !{i64 0, i64 18}
  %t92 = icmp eq i64 %t90, 3
  store i1 %t92, ptr %l90, !tbaa !21
  br label %bb25
bb25:
  %t93 = load i1, ptr %l90, !tbaa !21
  br i1 %t93, label %bb26, label %bb27
bb26:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  %t97 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t96, i32 0, i32 2
  %t98 = load ptr, ptr %t97
  store ptr %t98, ptr %l5, !tbaa !29
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eborrowOf(ptr %v0, ptr %v1, ptr %v2, ptr %t100, ptr %t101)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l97
  br label %bb29
bb29:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l98
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l2
  %t107 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t107, label %bb30, label %bb31
bb30:
  %t109 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109
  %t111 = extractvalue { i64, ptr } %t110, 1
  %t112 = call ptr @__olang_region_or(ptr %t111, ptr null)
  %t113 = call ptr @__olang_region_home(ptr %t112)
  %t114 = icmp ne ptr %t113, null
  %t115 = select i1 %t114, ptr %t113, ptr null
  call void @__olang_region_drop(ptr %t115)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l98
  br label %bb31
bb31:
  %t116 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t116, label %bb32, label %bb33
bb32:
  %t118 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98, i32 0, i32 0
  %t119 = load { i64, ptr }, ptr %t118
  %t120 = extractvalue { i64, ptr } %t119, 0
  %t121 = extractvalue { i64, ptr } %t119, 1
  call void @__olang_region_release_part(ptr %t121, i64 %t120)
  store { i64, ptr } zeroinitializer, ptr %t118
  br label %bb33
bb33:
  br label %bb373
bb34:
  %t122 = load ptr, ptr %l1, !tbaa !29
  store ptr %t122, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t123 = load ptr, ptr %l101, !tbaa !29
  %t124 = icmp ne ptr %t123, null
  br i1 %t124, label %bb35, label %bb36
bb35:
  %t126 = load ptr, ptr %l101, !tbaa !29
  %t127 = load i64, ptr %t126, !range !{i64 0, i64 18}
  %t129 = icmp eq i64 %t127, 4
  store i1 %t129, ptr %l102, !tbaa !21
  br label %bb36
bb36:
  %t130 = load i1, ptr %l102, !tbaa !21
  br i1 %t130, label %bb37, label %bb38
bb37:
  %t131 = load ptr, ptr %l1, !tbaa !29
  %t133 = getelementptr { i64, [5 x i64] }, ptr %t131, i32 0, i32 1
  %t134 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t133, i32 0, i32 1
  %t135 = load i32, ptr %t134
  store i32 %t135, ptr %l6, !tbaa !23
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t139 = getelementptr { i64, [5 x i64] }, ptr %t137, i32 0, i32 1
  %t140 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t139, i32 0, i32 2
  %t141 = load ptr, ptr %t140
  store ptr %t141, ptr %l7, !tbaa !29
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load ptr, ptr %l7, !tbaa !29
  %t145 = load i32, ptr %l6, !tbaa !23
  %t149 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %t143, ptr %t144, i32 %t145)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %l112
  br label %bb40
bb40:
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %l113
  %t151 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l112
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t151, ptr %l2
  %t152 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t152, label %bb41, label %bb42
bb41:
  %t154 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr null)
  %t158 = call ptr @__olang_region_home(ptr %t157)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr null
  call void @__olang_region_drop(ptr %t160)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l113
  br label %bb42
bb42:
  %t161 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t161, label %bb43, label %bb44
bb43:
  %t163 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l113, i32 0, i32 0
  %t164 = load { i64, ptr }, ptr %t163
  %t165 = extractvalue { i64, ptr } %t164, 0
  %t166 = extractvalue { i64, ptr } %t164, 1
  call void @__olang_region_release_part(ptr %t166, i64 %t165)
  store { i64, ptr } zeroinitializer, ptr %t163
  br label %bb44
bb44:
  br label %bb373
bb45:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l116, !tbaa !29
  store i1 false, ptr %l117, !tbaa !21
  %t168 = load ptr, ptr %l116, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb46, label %bb47
bb46:
  %t171 = load ptr, ptr %l116, !tbaa !29
  %t172 = load i64, ptr %t171, !range !{i64 0, i64 18}
  %t174 = icmp eq i64 %t172, 5
  store i1 %t174, ptr %l117, !tbaa !21
  br label %bb47
bb47:
  %t175 = load i1, ptr %l117, !tbaa !21
  br i1 %t175, label %bb48, label %bb49
bb48:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 1
  %t180 = load i32, ptr %t179
  store i32 %t180, ptr %l8, !tbaa !23
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l9, !tbaa !29
  br label %bb50
bb49:
  br label %bb56
bb50:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i32, ptr %l8, !tbaa !23
  %t190 = load ptr, ptr %l9, !tbaa !29
  %t194 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2epromoteOf(ptr %v0, ptr %v1, ptr %v2, ptr %t188, i32 %t189, ptr %t190)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t194, ptr %l127
  br label %bb51
bb51:
  %t195 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t195, ptr %l128
  %t196 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l127
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l2
  %t197 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t197, label %bb52, label %bb53
bb52:
  %t199 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l128, i32 0, i32 0
  %t200 = load { i64, ptr }, ptr %t199
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = call ptr @__olang_region_or(ptr %t201, ptr null)
  %t203 = call ptr @__olang_region_home(ptr %t202)
  %t204 = icmp ne ptr %t203, null
  %t205 = select i1 %t204, ptr %t203, ptr null
  call void @__olang_region_drop(ptr %t205)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l128
  br label %bb53
bb53:
  %t206 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t206, label %bb54, label %bb55
bb54:
  %t208 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l128, i32 0, i32 0
  %t209 = load { i64, ptr }, ptr %t208
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  call void @__olang_region_release_part(ptr %t211, i64 %t210)
  store { i64, ptr } zeroinitializer, ptr %t208
  br label %bb55
bb55:
  br label %bb373
bb56:
  %t212 = load ptr, ptr %l1, !tbaa !29
  store ptr %t212, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t213 = load ptr, ptr %l131, !tbaa !29
  %t214 = icmp ne ptr %t213, null
  br i1 %t214, label %bb57, label %bb58
bb57:
  %t216 = load ptr, ptr %l131, !tbaa !29
  %t217 = load i64, ptr %t216, !range !{i64 0, i64 18}
  %t219 = icmp eq i64 %t217, 6
  store i1 %t219, ptr %l132, !tbaa !21
  br label %bb58
bb58:
  %t220 = load i1, ptr %l132, !tbaa !21
  br i1 %t220, label %bb59, label %bb60
bb59:
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 0
  %t225 = load %"compiler/source:Span", ptr %t224
  store %"compiler/source:Span" %t225, ptr %l10
  %t227 = load ptr, ptr %l1, !tbaa !29
  %t229 = getelementptr { i64, [5 x i64] }, ptr %t227, i32 0, i32 1
  %t230 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t229, i32 0, i32 1
  %t231 = load i32, ptr %t230
  store i32 %t231, ptr %l11, !tbaa !23
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [5 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t235, i32 0, i32 2
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l12, !tbaa !29
  br label %bb61
bb60:
  br label %bb71
bb61:
  %t239 = call ptr @__olang_scope_hold(ptr %v2)
  %t240 = ptrtoint ptr %t239 to i64
  store i64 %t240, ptr %l141, !tbaa !24
  %t241 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t241, label %bb62, label %bb63
bb62:
  %t243 = call ptr @__olang_region_make(ptr %v2)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l141, !tbaa !24
  br label %bb63
bb63:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l12, !tbaa !29
  %t247 = load i32, ptr %l11, !tbaa !23
  %t248 = load %"compiler/source:Span", ptr %l10
  %t249 = load i64, ptr %l141
  %t250 = inttoptr i64 %t249 to ptr
  %t255 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %t250, ptr %t245, ptr %t246, i32 %t247, %"compiler/source:Span" %t248)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t255, ptr %l147
  br label %bb64
bb64:
  %t256 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t256, label %bb65, label %bb66
bb65:
  %t258 = load i64, ptr %l141
  %t259 = inttoptr i64 %t258 to ptr
  %t260 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l147, i32 0, i32 0
  %t261 = load { i64, ptr }, ptr %t260
  %t262 = extractvalue { i64, ptr } %t261, 1
  %t263 = call ptr @__olang_region_or(ptr %t262, ptr null)
  %t264 = call ptr @__olang_region_home(ptr %t263)
  %t265 = icmp ne ptr %t264, null
  %t266 = select i1 %t265, ptr %t264, ptr null
  call void @__olang_region_settle_in(ptr %t259, ptr %t266)
  br label %bb66
bb66:
  %t267 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t267, ptr %l149
  %t268 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l147
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t268, ptr %l2
  %t269 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t269, label %bb67, label %bb68
bb67:
  %t271 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149, i32 0, i32 0
  %t272 = load { i64, ptr }, ptr %t271
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = call ptr @__olang_region_or(ptr %t273, ptr null)
  %t275 = call ptr @__olang_region_home(ptr %t274)
  %t276 = icmp ne ptr %t275, null
  %t277 = select i1 %t276, ptr %t275, ptr null
  call void @__olang_region_drop(ptr %t277)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l149
  br label %bb68
bb68:
  %t278 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t278, label %bb69, label %bb70
bb69:
  %t280 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l149, i32 0, i32 0
  %t281 = load { i64, ptr }, ptr %t280
  %t282 = extractvalue { i64, ptr } %t281, 0
  %t283 = extractvalue { i64, ptr } %t281, 1
  call void @__olang_region_release_part(ptr %t283, i64 %t282)
  store { i64, ptr } zeroinitializer, ptr %t280
  br label %bb70
bb70:
  br label %bb373
bb71:
  %t284 = load ptr, ptr %l1, !tbaa !29
  store ptr %t284, ptr %l152, !tbaa !29
  store i1 false, ptr %l153, !tbaa !21
  %t285 = load ptr, ptr %l152, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb72, label %bb73
bb72:
  %t288 = load ptr, ptr %l152, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 18}
  %t291 = icmp eq i64 %t289, 7
  store i1 %t291, ptr %l153, !tbaa !21
  br label %bb73
bb73:
  %t292 = load i1, ptr %l153, !tbaa !21
  br i1 %t292, label %bb74, label %bb75
bb74:
  %t293 = load ptr, ptr %l1, !tbaa !29
  %t295 = getelementptr { i64, [5 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t295, i32 0, i32 0
  %t297 = load %"compiler/source:Span", ptr %t296
  store %"compiler/source:Span" %t297, ptr %l13
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t301 = getelementptr { i64, [5 x i64] }, ptr %t299, i32 0, i32 1
  %t302 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t301, i32 0, i32 1
  %t303 = load i32, ptr %t302
  store i32 %t303, ptr %l14, !tbaa !23
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t307, i32 0, i32 2
  %t309 = load ptr, ptr %t308
  store ptr %t309, ptr %l15, !tbaa !29
  br label %bb76
bb75:
  br label %bb86
bb76:
  %t311 = call ptr @__olang_scope_hold(ptr %v2)
  %t312 = ptrtoint ptr %t311 to i64
  store i64 %t312, ptr %l162, !tbaa !24
  %t313 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t313, label %bb77, label %bb78
bb77:
  %t315 = call ptr @__olang_region_make(ptr %v2)
  %t316 = ptrtoint ptr %t315 to i64
  store i64 %t316, ptr %l162, !tbaa !24
  br label %bb78
bb78:
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l13
  %t319 = load i32, ptr %l14, !tbaa !23
  %t320 = load ptr, ptr %l15, !tbaa !29
  %t321 = load i64, ptr %l162
  %t322 = inttoptr i64 %t321 to ptr
  %t327 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeOf(ptr %v0, ptr %v1, ptr %t322, ptr %t317, %"compiler/source:Span" %t318, i32 %t319, ptr %t320)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t327, ptr %l168
  br label %bb79
bb79:
  %t328 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t328, label %bb80, label %bb81
bb80:
  %t330 = load i64, ptr %l162
  %t331 = inttoptr i64 %t330 to ptr
  %t332 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168, i32 0, i32 0
  %t333 = load { i64, ptr }, ptr %t332
  %t334 = extractvalue { i64, ptr } %t333, 1
  %t335 = call ptr @__olang_region_or(ptr %t334, ptr null)
  %t336 = call ptr @__olang_region_home(ptr %t335)
  %t337 = icmp ne ptr %t336, null
  %t338 = select i1 %t337, ptr %t336, ptr null
  call void @__olang_region_settle_in(ptr %t331, ptr %t338)
  br label %bb81
bb81:
  %t339 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t339, ptr %l170
  %t340 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l168
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t340, ptr %l2
  %t341 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t341, label %bb82, label %bb83
bb82:
  %t343 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170, i32 0, i32 0
  %t344 = load { i64, ptr }, ptr %t343
  %t345 = extractvalue { i64, ptr } %t344, 1
  %t346 = call ptr @__olang_region_or(ptr %t345, ptr null)
  %t347 = call ptr @__olang_region_home(ptr %t346)
  %t348 = icmp ne ptr %t347, null
  %t349 = select i1 %t348, ptr %t347, ptr null
  call void @__olang_region_drop(ptr %t349)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l170
  br label %bb83
bb83:
  %t350 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t350, label %bb84, label %bb85
bb84:
  %t352 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l170, i32 0, i32 0
  %t353 = load { i64, ptr }, ptr %t352
  %t354 = extractvalue { i64, ptr } %t353, 0
  %t355 = extractvalue { i64, ptr } %t353, 1
  call void @__olang_region_release_part(ptr %t355, i64 %t354)
  store { i64, ptr } zeroinitializer, ptr %t352
  br label %bb85
bb85:
  br label %bb373
bb86:
  %t356 = load ptr, ptr %l1, !tbaa !29
  store ptr %t356, ptr %l173, !tbaa !29
  store i1 false, ptr %l174, !tbaa !21
  %t357 = load ptr, ptr %l173, !tbaa !29
  %t358 = icmp ne ptr %t357, null
  br i1 %t358, label %bb87, label %bb88
bb87:
  %t360 = load ptr, ptr %l173, !tbaa !29
  %t361 = load i64, ptr %t360, !range !{i64 0, i64 18}
  %t363 = icmp eq i64 %t361, 8
  store i1 %t363, ptr %l174, !tbaa !21
  br label %bb88
bb88:
  %t364 = load i1, ptr %l174, !tbaa !21
  br i1 %t364, label %bb89, label %bb90
bb89:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  %t368 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t367, i32 0, i32 1
  %t369 = load i32, ptr %t368
  store i32 %t369, ptr %l16, !tbaa !23
  %t371 = load ptr, ptr %l1, !tbaa !29
  %t373 = getelementptr { i64, [5 x i64] }, ptr %t371, i32 0, i32 1
  %t374 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t373, i32 0, i32 2
  %t375 = load ptr, ptr %t374
  store ptr %t375, ptr %l17, !tbaa !29
  br label %bb91
bb90:
  br label %bb119
bb91:
  %t377 = load ptr, ptr %l17, !tbaa !29
  %t379 = getelementptr %"compiler/typed:Collect", ptr %t377, i32 0, i32 0
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = icmp eq ptr %t380, null
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s9
  %t386 = load ptr, ptr %l0, !tbaa !29
  store ptr %t386, ptr %l185, !tbaa !29
  %t387 = load ptr, ptr %l17, !tbaa !29
  %t389 = getelementptr %"compiler/typed:Collect", ptr %t387, i32 0, i32 0
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = icmp eq ptr %t390, null
  br i1 %t392, label %bb94, label %bb95
bb93:
  br label %bb98
bb94:
  call void @__olang_check_failed(ptr @olang_loc_ea9e22c8e98b9315_4f35472d48da7b89)
  unreachable
bb95:
  br label %bb96
bb96:
  %t394 = load ptr, ptr %l17, !tbaa !29
  %t396 = getelementptr %"compiler/typed:Collect", ptr %t394, i32 0, i32 0
  %t397 = load ptr, ptr %t396, !tbaa !29
  %t398 = load ptr, ptr %l185, !tbaa !29
  %t400 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t398, ptr %t397)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t400, ptr %l191
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s9)
  br label %bb98
bb98:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/free:walker", ptr %t401, i32 0, i32 13
  store ptr %t403, ptr %l193, !tbaa !29
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/free:walker", ptr %t404, i32 0, i32 0
  %t407 = load ptr, ptr %t406, !tbaa !29
  store ptr %t407, ptr %l195, !tbaa !29
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = getelementptr %"compiler/free:walker", ptr %t408, i32 0, i32 0
  %t411 = load ptr, ptr %t410, !tbaa !29
  %t412 = load i32, ptr %l16, !tbaa !23
  %t415 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t411, i32 %t412)
  store i32 %t415, ptr %l199
  br label %bb99
bb99:
  %t416 = load ptr, ptr %l195, !tbaa !29
  %t417 = load i32, ptr %l199, !tbaa !23
  %t418 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t416, i32 %t417, i64 -1)
  store i64 %t418, ptr %l200
  br label %bb100
bb100:
  %t419 = load ptr, ptr %l193, !tbaa !29
  %t420 = load i64, ptr %l200, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t419, i64 %t420)
  br label %bb101
bb101:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/free:walker", ptr %t421, i32 0, i32 64
  store ptr %t423, ptr %l202, !tbaa !29
  %t424 = call ptr @__olang_scope_hold(ptr %v0)
  %t425 = ptrtoint ptr %t424 to i64
  store i64 %t425, ptr %l203, !tbaa !24
  %t426 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t426, label %bb102, label %bb103
bb102:
  %t428 = call ptr @__olang_region_make(ptr %v0)
  %t429 = ptrtoint ptr %t428 to i64
  store i64 %t429, ptr %l203, !tbaa !24
  br label %bb103
bb103:
  %t430 = load i64, ptr %l203
  %t431 = inttoptr i64 %t430 to ptr
  %t432 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t431, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t432, ptr %l205
  br label %bb104
bb104:
  %t433 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l205
  %t434 = load i64, ptr %l203
  %t435 = inttoptr i64 %t434 to ptr
  %t436 = call ptr @__olang_scope_alloc_a(ptr %t435, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t433, ptr %t436
  %t437 = load ptr, ptr %l202, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t437, ptr %t436)
  br label %bb105
bb105:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load ptr, ptr %l17, !tbaa !29
  %t442 = getelementptr %"compiler/typed:Collect", ptr %t440, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t439, ptr %t443)
  br label %bb106
bb106:
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = getelementptr %"compiler/free:walker", ptr %t446, i32 0, i32 13
  %t450 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t448)
  %t451 = extractvalue { i32, i64 } %t450, 1
  %t452 = extractvalue { i32, i64 } %t450, 0
  store i32 %t452, ptr %l214
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb108, label %ok.454, !prof !99
ok.454:
  store i64 %t451, ptr %l213
  br label %bb107
bb107:
  %t455 = load i64, ptr %l213, !tbaa !24
  store i64 %t455, ptr %l210, !tbaa !24
  br label %bb110
bb108:
  br label %bb109
bb109:
  br label %bb110
bb110:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/free:walker", ptr %t456, i32 0, i32 64
  %t460 = call { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H5927ce9e0c48ffa4d9cf1c64f8f12c1b(ptr %v0, ptr %v0, ptr %t458)
  %t461 = extractvalue { i32, ptr } %t460, 1
  %t462 = extractvalue { i32, ptr } %t460, 0
  store i32 %t462, ptr %l219
  %t463 = icmp ne i32 %t462, 0
  br i1 %t463, label %bb112, label %ok.464, !prof !99
ok.464:
  store ptr %t461, ptr %l218
  br label %bb111
bb111:
  %t465 = load ptr, ptr %l218, !tbaa !29
  store ptr %t465, ptr %l215, !tbaa !29
  br label %bb115
bb112:
  br label %bb113
bb113:
  %t466 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t466, ptr %l220
  br label %bb114
bb114:
  %t467 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l220
  %t468 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t467, ptr %t468
  store ptr %t468, ptr %l215, !tbaa !29
  br label %bb115
bb115:
  %t470 = load ptr, ptr %l215, !tbaa !29
  %t474 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %l2, ptr %t470)
  store i64 %t474, ptr %l224
  br label %bb116
bb116:
  store ptr %l2, ptr %l225, !tbaa !29
  %t475 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t476 = load ptr, ptr %l17, !tbaa !29
  %t478 = getelementptr %"compiler/typed:Collect", ptr %t476, i32 0, i32 2
  %t479 = load i32, ptr %t478, !tbaa !23
  %t481 = sext i32 %t479 to i64
  %t484 = call i64 @compiler_2ffree_2eorig(i64 %t475, i64 %t481)
  store i64 %t484, ptr %l230
  br label %bb117
bb117:
  %t485 = load ptr, ptr %l225, !tbaa !29
  %t486 = load i64, ptr %l230, !tbaa !24
  %t487 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t485, i64 %t486)
  store i64 %t487, ptr %l231
  br label %bb118
bb118:
  br label %bb373
bb119:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t489 = load ptr, ptr %l232, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb120, label %bb121
bb120:
  %t492 = load ptr, ptr %l232, !tbaa !29
  %t493 = load i64, ptr %t492, !range !{i64 0, i64 18}
  %t495 = icmp eq i64 %t493, 9
  store i1 %t495, ptr %l233, !tbaa !21
  br label %bb121
bb121:
  %t496 = load i1, ptr %l233, !tbaa !21
  br i1 %t496, label %bb122, label %bb123
bb122:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t499, i32 0, i32 0
  %t501 = load %"compiler/source:Span", ptr %t500
  store %"compiler/source:Span" %t501, ptr %l19
  %t503 = load ptr, ptr %l1, !tbaa !29
  %t505 = getelementptr { i64, [5 x i64] }, ptr %t503, i32 0, i32 1
  %t506 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t505, i32 0, i32 2
  %t507 = load i32, ptr %t506, !range !{i32 0, i32 54}
  store i32 %t507, ptr %l20
  %t509 = load ptr, ptr %l1, !tbaa !29
  %t511 = getelementptr { i64, [5 x i64] }, ptr %t509, i32 0, i32 1
  %t512 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t511, i32 0, i32 4
  %t513 = load { i64, ptr }, ptr %t512
  store { i64, ptr } %t513, ptr %l21, !tbaa !27
  br label %bb124
bb123:
  br label %bb199
bb124:
  %t515 = load i32, ptr %l20, !range !{i32 0, i32 54}
  %t517 = trunc i64 29 to i32
  %t518 = icmp eq i32 %t515, %t517
  br i1 %t518, label %bb125, label %bb126
bb125:
  %t520 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t522 = extractvalue { i64, ptr } %t520, 0
  %t524 = icmp eq i64 %t522, 1
  store i1 %t524, ptr %l244, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb127
bb127:
  %t526 = load i1, ptr %l244, !tbaa !21
  br i1 %t526, label %bb128, label %bb129
bb128:
  %t527 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t527, ptr %l249, !tbaa !27
  %t528 = getelementptr { i64, ptr }, ptr %l249, i32 0, i32 1
  %t529 = load ptr, ptr %t528, !tbaa !27
  %t530 = getelementptr ptr, ptr %t529, i64 0
  %t531 = load ptr, ptr %t530, !tbaa !39
  %t533 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v1, ptr %t531)
  store i64 %t533, ptr %l251
  br label %bb130
bb129:
  store i64 -1, ptr %l248, !tbaa !24
  br label %bb131
bb130:
  %t534 = load i64, ptr %l251, !tbaa !24
  store i64 %t534, ptr %l248, !tbaa !24
  br label %bb131
bb131:
  %t535 = load i64, ptr %l248, !tbaa !24
  store i64 %t535, ptr %l22, !tbaa !24
  %t536 = load ptr, ptr %l0, !tbaa !29
  %t537 = load i32, ptr %l20, !range !{i32 0, i32 54}
  %t538 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t542 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eheldDrop(ptr %v0, ptr %v1, ptr %t536, i32 %t537, { i64, ptr } %t538)
  store i64 %t542, ptr %l255
  br label %bb132
bb132:
  %t543 = load i64, ptr %l255, !tbaa !24
  store i64 %t543, ptr %l23, !tbaa !24
  %t544 = load i64, ptr %l23, !tbaa !24
  %t546 = icmp sge i64 %t544, 0
  br i1 %t546, label %bb133, label %bb134
bb133:
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t549 = load %"compiler/source:Span", ptr %l19
  %t550 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t550, ptr %l260, !tbaa !27
  %t551 = getelementptr { i64, ptr }, ptr %l260, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr ptr, ptr %t552, i64 0
  %t554 = load ptr, ptr %t553, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCalls(ptr %v0, ptr %v1, ptr %t548, %"compiler/source:Span" %t549, ptr %t554)
  br label %bb135
bb134:
  br label %bb155
bb135:
  store %olang.scope zeroinitializer, ptr %s13
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t560 = getelementptr %"compiler/free:walker", ptr %t558, i32 0, i32 0
  %t561 = load ptr, ptr %t560, !tbaa !29
  store ptr %t561, ptr %l263, !tbaa !29
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t562)
  store ptr %t564, ptr %l265
  br label %bb136
bb136:
  %t565 = load ptr, ptr %l265, !tbaa !29
  %t567 = getelementptr %"compiler/typed:Body", ptr %t565, i32 0, i32 7
  %t568 = load i64, ptr %l23, !tbaa !24
  %t571 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t567, i64 %t568)
  store %"compiler/typed:Local" %t571, ptr %l269
  br label %bb137
bb137:
  %t572 = getelementptr %"compiler/typed:Local", ptr %l269, i32 0, i32 2
  %t573 = load i32, ptr %t572, !tbaa !23
  %t574 = load ptr, ptr %l263, !tbaa !29
  %t576 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s13, ptr %t574, i32 %t573)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t576, ptr %l271
  br label %bb138
bb138:
  %t577 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l271
  %t578 = call ptr @__olang_scope_alloc_a(ptr %s13, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t577, ptr %t578
  store ptr %t578, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb139
bb139:
  store %olang.scope zeroinitializer, ptr %s14
  %t580 = load i64, ptr %l25, !tbaa !24
  store i64 %t580, ptr %l273, !tbaa !24
  %t581 = load ptr, ptr %l24, !tbaa !29
  %t583 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s13, ptr %t581)
  store i64 %t583, ptr %l275
  br label %bb140
bb140:
  %t584 = load i64, ptr %l273, !tbaa !24
  %t585 = load i64, ptr %l275, !tbaa !24
  %t586 = icmp slt i64 %t584, %t585
  %t588 = xor i1 %t586, true
  br i1 %t588, label %bb141, label %bb142
bb141:
  call void @__olang_scope_close(ptr %s14)
  br label %bb154
bb142:
  br label %bb143
bb143:
  %t590 = load ptr, ptr %l24, !tbaa !29
  %t591 = load i64, ptr %l25, !tbaa !24
  %t594 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s13, ptr %s13, ptr %t590, i64 %t591)
  store %"compiler/free:leaf" %t594, ptr %l280
  br label %bb144
bb144:
  %t595 = load %"compiler/free:leaf", ptr %l280
  store %"compiler/free:leaf" %t595, ptr %l281
  %t596 = call ptr @__olang_scope_hold(ptr %s14)
  %t597 = ptrtoint ptr %t596 to i64
  store i64 %t597, ptr %l282, !tbaa !24
  %t598 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t598, label %bb145, label %bb146
bb145:
  %t600 = call ptr @__olang_region_make_part(ptr %s14)
  %t601 = ptrtoint ptr %t600 to i64
  store i64 %t601, ptr %l282, !tbaa !24
  br label %bb146
bb146:
  %t602 = getelementptr %"compiler/free:leaf", ptr %l281, i32 0, i32 0
  %t603 = load { i64, ptr }, ptr %t602, !tbaa !27
  store { i64, ptr } %t603, ptr %l284, !tbaa !27
  %t604 = load { i64, ptr }, ptr %l284, !tbaa !27
  %t605 = extractvalue { i64, ptr } %t604, 0
  store i64 %t605, ptr %l285, !tbaa !24
  %t606 = load i64, ptr %l285, !tbaa !24
  %t607 = mul i64 %t606, 8
  %t608 = load i64, ptr %l282
  %t609 = inttoptr i64 %t608 to ptr
  %t610 = call ptr @__olang_held_alloc(ptr %t609, i64 %t607)
  %t611 = insertvalue { i64, ptr } undef, i64 %t606, 0
  %t612 = insertvalue { i64, ptr } %t611, ptr %t610, 1
  store { i64, ptr } %t612, ptr %l286, !tbaa !27
  %t613 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t614 = load ptr, ptr %t613, !tbaa !27
  %t615 = getelementptr { i64, ptr }, ptr %l284, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !27
  %t617 = load i64, ptr %l285, !tbaa !24
  %t618 = mul i64 %t617, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t614, ptr %t616, i64 %t618, i1 false)
  %t619 = load { i64, ptr }, ptr %l286, !tbaa !27
  %t620 = getelementptr %"compiler/free:leaf", ptr %l281, i32 0, i32 0
  store { i64, ptr } %t619, ptr %t620, !tbaa !27
  %t621 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aleaf_2e0
  br i1 %t621, label %bb147, label %bb148
bb147:
  %t623 = getelementptr %"compiler/free:leaf", ptr %l281, i32 0, i32 0
  %t624 = load { i64, ptr }, ptr %t623, !tbaa !27
  %t625 = extractvalue { i64, ptr } %t624, 0
  %t627 = icmp eq i64 %t625, 0
  br i1 %t627, label %bb149, label %bb150
bb148:
  %t629 = load %"compiler/free:leaf", ptr %l281
  store %"compiler/free:leaf" %t629, ptr %l26
  %t630 = load ptr, ptr %l0, !tbaa !29
  store ptr %t630, ptr %l290, !tbaa !29
  %t631 = getelementptr %"compiler/free:leaf", ptr %l26, i32 0, i32 1
  %t632 = load i64, ptr %t631, !tbaa !24
  store i64 %t632, ptr %l291, !tbaa !24
  %t633 = load i64, ptr @G_2ecompiler_2ffree_2eLHeld, !tbaa !24
  store i64 %t633, ptr %l292, !tbaa !24
  %t634 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t634, ptr %l293
  %t635 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s14, i32 0, i32 0)
  store %"compiler/source:Span" %t635, ptr %l294
  br label %bb151
bb149:
  %t636 = getelementptr %"compiler/free:leaf", ptr %l281, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t636, !tbaa !27
  br label %bb150
bb150:
  %t637 = getelementptr %"compiler/free:leaf", ptr %l281, i32 0, i32 0
  %t638 = load i64, ptr %l282
  %t639 = inttoptr i64 %t638 to ptr
  %t640 = load { i64, ptr }, ptr %t637
  %t641 = extractvalue { i64, ptr } %t640, 1
  %t642 = call ptr @__olang_region_or(ptr %t641, ptr null)
  %t643 = icmp ne ptr %t642, null
  %t644 = select i1 %t643, ptr %t642, ptr null
  call void @__olang_region_settle_in(ptr %t639, ptr %t644)
  br label %bb148
bb151:
  %t645 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t646 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t647 = load ptr, ptr %l290, !tbaa !29
  %t648 = load i64, ptr %l291, !tbaa !24
  %t649 = load i64, ptr %l292, !tbaa !24
  %t650 = load %"compiler/source:Span", ptr %l293
  %t651 = load %"compiler/source:Span", ptr %l294
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t647, i64 %t648, i64 %t649, %"compiler/source:Span" %t650, %"compiler/source:Span" %t651, i64 -1, i1 false, i64 %t645, i32 %t646)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s14)
  br label %bb153
bb153:
  %t654 = load i64, ptr %l25, !tbaa !24
  %t657 = add i64 %t654, 1
  store i64 %t657, ptr %l25, !tbaa !24
  br label %bb139
bb154:
  call void @__olang_scope_close(ptr %s13)
  %t659 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t659, ptr %rv
  br label %ret
bb155:
  %t661 = load i64, ptr %l22, !tbaa !24
  %t663 = icmp sge i64 %t661, 0
  br i1 %t663, label %bb156, label %bb157
bb156:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = getelementptr %"compiler/free:walker", ptr %t665, i32 0, i32 2
  %t668 = load i1, ptr %t667, !tbaa !21
  br i1 %t668, label %bb158, label %bb159
bb157:
  %t670 = load ptr, ptr %l0, !tbaa !29
  %t672 = getelementptr %"compiler/free:walker", ptr %t670, i32 0, i32 55
  %t673 = load i64, ptr %t672, !tbaa !24
  store i64 %t673, ptr %l27, !tbaa !24
  %t675 = load i32, ptr %l20, !range !{i32 0, i32 54}
  %t676 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t679 = call i1 @compiler_2ffree_2eisLen(ptr %v1, i32 %t675, { i64, ptr } %t676)
  store i1 %t679, ptr %l335
  br label %bb175
bb158:
  store %olang.scope zeroinitializer, ptr %s17
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = getelementptr %"compiler/free:walker", ptr %t680, i32 0, i32 0
  %t683 = load ptr, ptr %t682, !tbaa !29
  %t685 = getelementptr %"compiler/free:Free", ptr %t683, i32 0, i32 14
  store ptr %t685, ptr %l307, !tbaa !29
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/free:walker", ptr %t686, i32 0, i32 1
  %t689 = load i64, ptr %t688, !tbaa !24
  store i64 %t689, ptr %l309, !tbaa !24
  %t690 = load %"compiler/source:Span", ptr %l19
  store %"compiler/source:Span" %t690, ptr %l310
  %t691 = call ptr @__olang_scope_hold(ptr %s17)
  %t692 = ptrtoint ptr %t691 to i64
  store i64 %t692, ptr %l311, !tbaa !24
  %t693 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aretire_2e2
  br i1 %t693, label %bb160, label %bb161
bb159:
  br label %bb174
bb160:
  %t695 = call ptr @__olang_region_make(ptr %s17)
  %t696 = ptrtoint ptr %t695 to i64
  store i64 %t696, ptr %l311, !tbaa !24
  br label %bb161
bb161:
  %t697 = load ptr, ptr %l0, !tbaa !29
  %t699 = getelementptr %"compiler/free:walker", ptr %t697, i32 0, i32 3
  %t700 = load i64, ptr %l22, !tbaa !24
  %t703 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t699, i64 %t700)
  store ptr %t703, ptr %l316
  br label %bb162
bb162:
  %t704 = load ptr, ptr %l316, !tbaa !29
  %t705 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t704
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t705, ptr %l318
  %t707 = load i64, ptr %l311
  %t708 = inttoptr i64 %t707 to ptr
  %t709 = call ptr @__olang_scope_hold(ptr %t708)
  %t710 = ptrtoint ptr %t709 to i64
  store i64 %t710, ptr %l319, !tbaa !24
  %t711 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t711, label %bb163, label %bb164
bb163:
  %t713 = load i64, ptr %l311
  %t714 = inttoptr i64 %t713 to ptr
  %t715 = call ptr @__olang_region_make_part(ptr %t714)
  %t716 = ptrtoint ptr %t715 to i64
  store i64 %t716, ptr %l319, !tbaa !24
  br label %bb164
bb164:
  %t717 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318, i32 0, i32 0
  %t718 = load { i64, ptr }, ptr %t717, !tbaa !27
  store { i64, ptr } %t718, ptr %l321, !tbaa !27
  %t719 = load { i64, ptr }, ptr %l321, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t719, 0
  store i64 %t720, ptr %l322, !tbaa !24
  %t721 = load i64, ptr %l322, !tbaa !24
  %t722 = mul i64 %t721, 8
  %t723 = load i64, ptr %l319
  %t724 = inttoptr i64 %t723 to ptr
  %t725 = call ptr @__olang_held_alloc(ptr %t724, i64 %t722)
  %t726 = insertvalue { i64, ptr } undef, i64 %t721, 0
  %t727 = insertvalue { i64, ptr } %t726, ptr %t725, 1
  store { i64, ptr } %t727, ptr %l323, !tbaa !27
  %t728 = getelementptr { i64, ptr }, ptr %l323, i32 0, i32 1
  %t729 = load ptr, ptr %t728, !tbaa !27
  %t730 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t731 = load ptr, ptr %t730, !tbaa !27
  %t732 = load i64, ptr %l322, !tbaa !24
  %t733 = mul i64 %t732, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t729, ptr %t731, i64 %t733, i1 false)
  %t734 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t735 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318, i32 0, i32 0
  store { i64, ptr } %t734, ptr %t735, !tbaa !27
  %t736 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t736, label %bb165, label %bb166
bb165:
  %t738 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318, i32 0, i32 0
  %t739 = load { i64, ptr }, ptr %t738, !tbaa !27
  %t740 = extractvalue { i64, ptr } %t739, 0
  %t742 = icmp eq i64 %t740, 0
  br i1 %t742, label %bb167, label %bb168
bb166:
  %t744 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3aretire_2e2
  br i1 %t744, label %bb169, label %bb170
bb167:
  %t746 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t746, !tbaa !27
  br label %bb168
bb168:
  %t747 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318, i32 0, i32 0
  %t748 = load i64, ptr %l319
  %t749 = inttoptr i64 %t748 to ptr
  %t750 = load { i64, ptr }, ptr %t747
  %t751 = extractvalue { i64, ptr } %t750, 1
  %t752 = call ptr @__olang_region_or(ptr %t751, ptr null)
  %t753 = icmp ne ptr %t752, null
  %t754 = select i1 %t753, ptr %t752, ptr null
  call void @__olang_region_settle_in(ptr %t749, ptr %t754)
  br label %bb166
bb169:
  %t755 = load i64, ptr %l311
  %t756 = inttoptr i64 %t755 to ptr
  %t757 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318, i32 0, i32 0
  %t758 = load { i64, ptr }, ptr %t757
  %t759 = extractvalue { i64, ptr } %t758, 1
  %t760 = call ptr @__olang_region_or(ptr %t759, ptr null)
  %t761 = call ptr @__olang_region_home(ptr %t760)
  %t762 = icmp ne ptr %t761, null
  %t763 = select i1 %t762, ptr %t761, ptr null
  call void @__olang_region_settle_in(ptr %t756, ptr %t763)
  br label %bb170
bb170:
  %t764 = load i64, ptr %l309, !tbaa !24
  %t765 = load %"compiler/source:Span", ptr %l310
  %t766 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l318
  %t767 = call %"compiler/free:retire" @compiler_2ffree_3aretire_2ector(ptr %s17, ptr %s17, i64 %t764, %"compiler/source:Span" %t765, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t766)
  store %"compiler/free:retire" %t767, ptr %l328
  br label %bb171
bb171:
  %t769 = call %"compiler/free:retire" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aretire(ptr %s17, ptr %l328)
  store %"compiler/free:retire" %t769, ptr %l330
  br label %bb172
bb172:
  %t770 = load ptr, ptr %l307, !tbaa !29
  %t771 = load %"compiler/free:retire", ptr %l330
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2ePush_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %s17, ptr %t770, %"compiler/free:retire" %t771)
  br label %bb173
bb173:
  call void @__olang_scope_close(ptr %s17)
  br label %bb174
bb174:
  br label %bb191
bb175:
  %t772 = load i1, ptr %l335, !tbaa !21
  br i1 %t772, label %bb176, label %bb177
bb176:
  %t773 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t773, ptr %l337, !tbaa !27
  %t774 = getelementptr { i64, ptr }, ptr %l337, i32 0, i32 1
  %t775 = load ptr, ptr %t774, !tbaa !27
  %t776 = getelementptr ptr, ptr %t775, i64 0
  %t777 = load ptr, ptr %t776, !tbaa !39
  %t779 = call i64 @compiler_2ffree_2ereadCall(ptr %v1, ptr %t777)
  store i64 %t779, ptr %l339
  br label %bb178
bb177:
  store i64 -1, ptr %l336, !tbaa !24
  br label %bb179
bb178:
  %t780 = load i64, ptr %l339, !tbaa !24
  store i64 %t780, ptr %l336, !tbaa !24
  br label %bb179
bb179:
  %t781 = load i64, ptr %l336, !tbaa !24
  store i64 %t781, ptr %l28, !tbaa !24
  %t782 = load i64, ptr %l28, !tbaa !24
  %t784 = icmp sge i64 %t782, 0
  br i1 %t784, label %bb180, label %bb181
bb180:
  %t786 = load ptr, ptr %l0, !tbaa !29
  %t787 = load i64, ptr %l28, !tbaa !24
  %t790 = getelementptr %"compiler/free:walker", ptr %t786, i32 0, i32 55
  store i64 %t787, ptr %t790, !tbaa !24
  br label %bb182
bb181:
  br label %bb182
bb182:
  %t791 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t791, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t793 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t795 = extractvalue { i64, ptr } %t793, 0
  store i64 %t795, ptr %l31, !tbaa !24
  br label %bb183
bb183:
  store %olang.scope zeroinitializer, ptr %s21
  %t797 = load i64, ptr %l30, !tbaa !24
  %t798 = load i64, ptr %l31, !tbaa !24
  %t801 = icmp slt i64 %t797, %t798
  %t803 = xor i1 %t801, true
  br i1 %t803, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s21)
  br label %bb190
bb185:
  br label %bb186
bb186:
  %t805 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t805, ptr %l351, !tbaa !27
  %t806 = load i64, ptr %l30, !tbaa !24
  %t808 = getelementptr { i64, ptr }, ptr %l351, i32 0, i32 1
  %t809 = load ptr, ptr %t808, !tbaa !27
  %t810 = getelementptr ptr, ptr %t809, i64 %t806
  %t811 = load ptr, ptr %t810, !tbaa !39
  store ptr %l2, ptr %l354, !tbaa !29
  %t813 = load ptr, ptr %l0, !tbaa !29
  %t817 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s21, ptr %t813, ptr %t811)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t817, ptr %l357
  br label %bb187
bb187:
  %t818 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l357
  %t819 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t818, ptr %t819
  %t820 = load ptr, ptr %l354, !tbaa !29
  %t822 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s21, ptr %t820, ptr %t819)
  store i64 %t822, ptr %l359
  br label %bb188
bb188:
  call void @__olang_scope_close(ptr %s21)
  br label %bb189
bb189:
  %t823 = load i64, ptr %l30, !tbaa !24
  %t826 = add i64 %t823, 1
  store i64 %t826, ptr %l30, !tbaa !24
  br label %bb183
bb190:
  %t828 = load ptr, ptr %l0, !tbaa !29
  %t829 = load i64, ptr %l27, !tbaa !24
  %t832 = getelementptr %"compiler/free:walker", ptr %t828, i32 0, i32 55
  store i64 %t829, ptr %t832, !tbaa !24
  br label %bb191
bb191:
  %t833 = load i32, ptr %l20, !range !{i32 0, i32 54}
  %t835 = trunc i64 31 to i32
  %t836 = icmp eq i32 %t833, %t835
  br i1 %t836, label %bb192, label %bb193
bb192:
  %t838 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t840 = extractvalue { i64, ptr } %t838, 0
  %t842 = icmp eq i64 %t840, 1
  store i1 %t842, ptr %l367, !tbaa !21
  br label %bb194
bb193:
  store i1 false, ptr %l367, !tbaa !21
  br label %bb194
bb194:
  %t844 = load i1, ptr %l367, !tbaa !21
  br i1 %t844, label %bb195, label %bb196
bb195:
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t846 = load %"compiler/source:Span", ptr %l19
  %t847 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t847, ptr %l373, !tbaa !27
  %t848 = getelementptr { i64, ptr }, ptr %l373, i32 0, i32 1
  %t849 = load ptr, ptr %t848, !tbaa !27
  %t850 = getelementptr ptr, ptr %t849, i64 0
  %t851 = load ptr, ptr %t850, !tbaa !39
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCalls(ptr %v0, ptr %v1, ptr %t845, %"compiler/source:Span" %t846, ptr %t851)
  br label %bb197
bb196:
  br label %bb198
bb197:
  br label %bb198
bb198:
  br label %bb373
bb199:
  %t855 = load ptr, ptr %l1, !tbaa !29
  store ptr %t855, ptr %l375, !tbaa !29
  store i1 false, ptr %l376, !tbaa !21
  %t856 = load ptr, ptr %l375, !tbaa !29
  %t857 = icmp ne ptr %t856, null
  br i1 %t857, label %bb200, label %bb201
bb200:
  %t859 = load ptr, ptr %l375, !tbaa !29
  %t860 = load i64, ptr %t859, !range !{i64 0, i64 18}
  %t862 = icmp eq i64 %t860, 10
  store i1 %t862, ptr %l376, !tbaa !21
  br label %bb201
bb201:
  %t863 = load i1, ptr %l376, !tbaa !21
  br i1 %t863, label %bb202, label %bb203
bb202:
  %t864 = load ptr, ptr %l1, !tbaa !29
  %t866 = getelementptr { i64, [5 x i64] }, ptr %t864, i32 0, i32 1
  %t867 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t866, i32 0, i32 2
  %t868 = load ptr, ptr %t867
  store ptr %t868, ptr %l33, !tbaa !29
  br label %bb204
bb203:
  br label %bb213
bb204:
  store %olang.scope zeroinitializer, ptr %s24
  %t870 = load ptr, ptr %l0, !tbaa !29
  store ptr %t870, ptr %l381, !tbaa !29
  %t871 = load ptr, ptr %l33, !tbaa !29
  %t873 = getelementptr %"compiler/typed:Slice", ptr %t871, i32 0, i32 0
  %t874 = load ptr, ptr %t873, !tbaa !29
  store ptr %t874, ptr %l383, !tbaa !29
  %t875 = load ptr, ptr %l33, !tbaa !29
  %t877 = getelementptr %"compiler/typed:Slice", ptr %t875, i32 0, i32 0
  %t878 = load ptr, ptr %t877, !tbaa !29
  %t880 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t878)
  store i32 %t880, ptr %l386
  br label %bb205
bb205:
  %t881 = load ptr, ptr %l381, !tbaa !29
  %t882 = load ptr, ptr %l383, !tbaa !29
  %t883 = load i32, ptr %l386, !tbaa !23
  %t884 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %t881, ptr %t882, i32 %t883)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t884, ptr %l387
  br label %bb206
bb206:
  %t885 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t885, ptr %l388
  %t886 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l387
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t886, ptr %l2
  %t887 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t887, label %bb207, label %bb208
bb207:
  %t889 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l388, i32 0, i32 0
  %t890 = load { i64, ptr }, ptr %t889
  %t891 = extractvalue { i64, ptr } %t890, 1
  %t892 = call ptr @__olang_region_or(ptr %t891, ptr null)
  %t893 = call ptr @__olang_region_home(ptr %t892)
  %t894 = icmp ne ptr %t893, null
  %t895 = select i1 %t894, ptr %t893, ptr null
  call void @__olang_region_drop(ptr %t895)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l388
  br label %bb208
bb208:
  %t896 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t896, label %bb209, label %bb210
bb209:
  %t898 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l388, i32 0, i32 0
  %t899 = load { i64, ptr }, ptr %t898
  %t900 = extractvalue { i64, ptr } %t899, 0
  %t901 = extractvalue { i64, ptr } %t899, 1
  call void @__olang_region_release_part(ptr %t901, i64 %t900)
  store { i64, ptr } zeroinitializer, ptr %t898
  br label %bb210
bb210:
  %t902 = load ptr, ptr %l0, !tbaa !29
  %t903 = load ptr, ptr %l33, !tbaa !29
  %t905 = getelementptr %"compiler/typed:Slice", ptr %t903, i32 0, i32 1
  %t906 = load ptr, ptr %t905, !tbaa !29
  %t909 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s24, ptr %t902, ptr %t906)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t909, ptr %l394
  br label %bb211
bb211:
  %t910 = load ptr, ptr %l0, !tbaa !29
  %t911 = load ptr, ptr %l33, !tbaa !29
  %t913 = getelementptr %"compiler/typed:Slice", ptr %t911, i32 0, i32 2
  %t914 = load ptr, ptr %t913, !tbaa !29
  %t917 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s24, ptr %t910, ptr %t914)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t917, ptr %l398
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s24)
  br label %bb373
bb213:
  %t918 = load ptr, ptr %l1, !tbaa !29
  store ptr %t918, ptr %l399, !tbaa !29
  store i1 false, ptr %l400, !tbaa !21
  %t919 = load ptr, ptr %l399, !tbaa !29
  %t920 = icmp ne ptr %t919, null
  br i1 %t920, label %bb214, label %bb215
bb214:
  %t922 = load ptr, ptr %l399, !tbaa !29
  %t923 = load i64, ptr %t922, !range !{i64 0, i64 18}
  %t925 = icmp eq i64 %t923, 11
  store i1 %t925, ptr %l400, !tbaa !21
  br label %bb215
bb215:
  %t926 = load i1, ptr %l400, !tbaa !21
  br i1 %t926, label %bb216, label %bb217
bb216:
  %t927 = load ptr, ptr %l1, !tbaa !29
  %t929 = getelementptr { i64, [5 x i64] }, ptr %t927, i32 0, i32 1
  %t930 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t929, i32 0, i32 2
  %t931 = load ptr, ptr %t930
  store ptr %t931, ptr %l34, !tbaa !29
  br label %bb218
bb217:
  br label %bb230
bb218:
  store %olang.scope zeroinitializer, ptr %s25
  %t933 = load ptr, ptr %l0, !tbaa !29
  %t934 = load ptr, ptr %l34, !tbaa !29
  %t936 = getelementptr %"compiler/typed:Cond", ptr %t934, i32 0, i32 0
  %t937 = load ptr, ptr %t936, !tbaa !29
  %t940 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s25, ptr %t933, ptr %t937)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t940, ptr %l408
  br label %bb219
bb219:
  %t941 = load ptr, ptr %l34, !tbaa !29
  %t943 = getelementptr %"compiler/typed:Cond", ptr %t941, i32 0, i32 1
  %t944 = load ptr, ptr %t943, !tbaa !29
  %t946 = icmp eq ptr %t944, null
  %t948 = xor i1 %t946, true
  br i1 %t948, label %bb220, label %bb221
bb220:
  store %olang.scope zeroinitializer, ptr %s26
  store ptr %l2, ptr %l413, !tbaa !29
  %t950 = load ptr, ptr %l0, !tbaa !29
  store ptr %t950, ptr %l414, !tbaa !29
  %t951 = load ptr, ptr %l34, !tbaa !29
  %t953 = getelementptr %"compiler/typed:Cond", ptr %t951, i32 0, i32 1
  %t954 = load ptr, ptr %t953, !tbaa !29
  %t956 = icmp eq ptr %t954, null
  br i1 %t956, label %bb222, label %bb223
bb221:
  br label %bb227
bb222:
  call void @__olang_check_failed(ptr @olang_loc_dfb3465ca167576e_8d0cb6499ce7122)
  unreachable
bb223:
  br label %bb224
bb224:
  %t958 = load ptr, ptr %l34, !tbaa !29
  %t960 = getelementptr %"compiler/typed:Cond", ptr %t958, i32 0, i32 1
  %t961 = load ptr, ptr %t960, !tbaa !29
  %t962 = load ptr, ptr %l414, !tbaa !29
  %t964 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s26, ptr %t962, ptr %t961)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t964, ptr %l420
  br label %bb225
bb225:
  %t965 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l420
  %t966 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t965, ptr %t966
  %t967 = load ptr, ptr %l413, !tbaa !29
  %t969 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s26, ptr %t967, ptr %t966)
  store i64 %t969, ptr %l422
  br label %bb226
bb226:
  call void @__olang_scope_close(ptr %s26)
  br label %bb227
bb227:
  store ptr %l2, ptr %l423, !tbaa !29
  %t970 = load ptr, ptr %l0, !tbaa !29
  %t971 = load ptr, ptr %l34, !tbaa !29
  %t973 = getelementptr %"compiler/typed:Cond", ptr %t971, i32 0, i32 2
  %t974 = load ptr, ptr %t973, !tbaa !29
  %t977 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s25, ptr %t970, ptr %t974)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t977, ptr %l427
  br label %bb228
bb228:
  %t978 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l427
  %t979 = call ptr @__olang_scope_alloc_a(ptr %s25, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t978, ptr %t979
  %t980 = load ptr, ptr %l423, !tbaa !29
  %t982 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s25, ptr %t980, ptr %t979)
  store i64 %t982, ptr %l429
  br label %bb229
bb229:
  call void @__olang_scope_close(ptr %s25)
  br label %bb373
bb230:
  %t983 = load ptr, ptr %l1, !tbaa !29
  store ptr %t983, ptr %l430, !tbaa !29
  store i1 false, ptr %l431, !tbaa !21
  %t984 = load ptr, ptr %l430, !tbaa !29
  %t985 = icmp ne ptr %t984, null
  br i1 %t985, label %bb231, label %bb232
bb231:
  %t987 = load ptr, ptr %l430, !tbaa !29
  %t988 = load i64, ptr %t987, !range !{i64 0, i64 18}
  %t990 = icmp eq i64 %t988, 12
  store i1 %t990, ptr %l431, !tbaa !21
  br label %bb232
bb232:
  %t991 = load i1, ptr %l431, !tbaa !21
  br i1 %t991, label %bb233, label %bb234
bb233:
  %t992 = load ptr, ptr %l1, !tbaa !29
  %t994 = getelementptr { i64, [5 x i64] }, ptr %t992, i32 0, i32 1
  %t995 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t994, i32 0, i32 2
  %t996 = load ptr, ptr %t995
  store ptr %t996, ptr %l35, !tbaa !29
  br label %bb235
bb234:
  br label %bb260
bb235:
  %t998 = load ptr, ptr %l35, !tbaa !29
  %t1000 = getelementptr %"compiler/typed:Seq", ptr %t998, i32 0, i32 0
  %t1001 = load { i64, ptr }, ptr %t1000, !tbaa !27
  store { i64, ptr } %t1001, ptr %l36, !tbaa !27
  store i64 0, ptr %l37, !tbaa !24
  %t1003 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t1005 = extractvalue { i64, ptr } %t1003, 0
  store i64 %t1005, ptr %l38, !tbaa !24
  br label %bb236
bb236:
  %t1007 = load i64, ptr %l37, !tbaa !24
  %t1008 = load i64, ptr %l38, !tbaa !24
  %t1011 = icmp slt i64 %t1007, %t1008
  %t1013 = xor i1 %t1011, true
  br i1 %t1013, label %bb237, label %bb238
bb237:
  br label %bb242
bb238:
  br label %bb239
bb239:
  %t1015 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t1015, ptr %l444, !tbaa !27
  %t1016 = load i64, ptr %l37, !tbaa !24
  %t1018 = getelementptr { i64, ptr }, ptr %l444, i32 0, i32 1
  %t1019 = load ptr, ptr %t1018, !tbaa !27
  %t1020 = getelementptr ptr, ptr %t1019, i64 %t1016
  %t1021 = load ptr, ptr %t1020, !tbaa !39
  %t1023 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t1023, ptr %t1021)
  br label %bb240
bb240:
  br label %bb241
bb241:
  %t1027 = load i64, ptr %l37, !tbaa !24
  %t1030 = add i64 %t1027, 1
  store i64 %t1030, ptr %l37, !tbaa !24
  br label %bb236
bb242:
  %t1032 = load ptr, ptr %l35, !tbaa !29
  %t1034 = getelementptr %"compiler/typed:Seq", ptr %t1032, i32 0, i32 2
  %t1035 = load i1, ptr %t1034, !tbaa !21
  br i1 %t1035, label %bb243, label %bb244
bb243:
  %t1037 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1037, ptr %l454, !tbaa !29
  %t1038 = load ptr, ptr %l454, !tbaa !29
  %t1039 = getelementptr %"compiler/free:walker", ptr %t1038, i32 0, i32 59
  %t1040 = load i64, ptr %t1039, !tbaa !24
  %t1043 = add i64 %t1040, 1
  %t1045 = load ptr, ptr %l454, !tbaa !29
  %t1046 = getelementptr %"compiler/free:walker", ptr %t1045, i32 0, i32 59
  store i64 %t1043, ptr %t1046, !tbaa !24
  br label %bb245
bb244:
  br label %bb245
bb245:
  %t1047 = load ptr, ptr %l35, !tbaa !29
  %t1049 = getelementptr %"compiler/typed:Seq", ptr %t1047, i32 0, i32 1
  %t1050 = load ptr, ptr %t1049, !tbaa !29
  %t1052 = icmp eq ptr %t1050, null
  %t1054 = xor i1 %t1052, true
  br i1 %t1054, label %bb246, label %bb247
bb246:
  %t1056 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1056, ptr %l462, !tbaa !29
  %t1057 = load ptr, ptr %l35, !tbaa !29
  %t1059 = getelementptr %"compiler/typed:Seq", ptr %t1057, i32 0, i32 1
  %t1060 = load ptr, ptr %t1059, !tbaa !29
  %t1062 = icmp eq ptr %t1060, null
  br i1 %t1062, label %bb248, label %bb249
bb247:
  br label %bb256
bb248:
  call void @__olang_check_failed(ptr @olang_loc_dba6c8d02c3d079f_ccc870ae213a95a3)
  unreachable
bb249:
  br label %bb250
bb250:
  %t1064 = load ptr, ptr %l35, !tbaa !29
  %t1066 = getelementptr %"compiler/typed:Seq", ptr %t1064, i32 0, i32 1
  %t1067 = load ptr, ptr %t1066, !tbaa !29
  %t1068 = load ptr, ptr %l462, !tbaa !29
  %t1070 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1068, ptr %t1067)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1070, ptr %l468
  br label %bb251
bb251:
  %t1071 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1071, ptr %l469
  %t1072 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l468
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1072, ptr %l2
  %t1073 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1073, label %bb252, label %bb253
bb252:
  %t1075 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l469, i32 0, i32 0
  %t1076 = load { i64, ptr }, ptr %t1075
  %t1077 = extractvalue { i64, ptr } %t1076, 1
  %t1078 = call ptr @__olang_region_or(ptr %t1077, ptr null)
  %t1079 = call ptr @__olang_region_home(ptr %t1078)
  %t1080 = icmp ne ptr %t1079, null
  %t1081 = select i1 %t1080, ptr %t1079, ptr null
  call void @__olang_region_drop(ptr %t1081)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l469
  br label %bb253
bb253:
  %t1082 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1082, label %bb254, label %bb255
bb254:
  %t1084 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l469, i32 0, i32 0
  %t1085 = load { i64, ptr }, ptr %t1084
  %t1086 = extractvalue { i64, ptr } %t1085, 0
  %t1087 = extractvalue { i64, ptr } %t1085, 1
  call void @__olang_region_release_part(ptr %t1087, i64 %t1086)
  store { i64, ptr } zeroinitializer, ptr %t1084
  br label %bb255
bb255:
  br label %bb256
bb256:
  %t1088 = load ptr, ptr %l35, !tbaa !29
  %t1090 = getelementptr %"compiler/typed:Seq", ptr %t1088, i32 0, i32 2
  %t1091 = load i1, ptr %t1090, !tbaa !21
  br i1 %t1091, label %bb257, label %bb258
bb257:
  %t1093 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1093, ptr %l474, !tbaa !29
  %t1094 = load ptr, ptr %l474, !tbaa !29
  %t1095 = getelementptr %"compiler/free:walker", ptr %t1094, i32 0, i32 59
  %t1096 = load i64, ptr %t1095, !tbaa !24
  %t1099 = sub i64 %t1096, 1
  %t1101 = load ptr, ptr %l474, !tbaa !29
  %t1102 = getelementptr %"compiler/free:walker", ptr %t1101, i32 0, i32 59
  store i64 %t1099, ptr %t1102, !tbaa !24
  br label %bb259
bb258:
  br label %bb259
bb259:
  br label %bb373
bb260:
  %t1103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1103, ptr %l478, !tbaa !29
  store i1 false, ptr %l479, !tbaa !21
  %t1104 = load ptr, ptr %l478, !tbaa !29
  %t1105 = icmp ne ptr %t1104, null
  br i1 %t1105, label %bb261, label %bb262
bb261:
  %t1107 = load ptr, ptr %l478, !tbaa !29
  %t1108 = load i64, ptr %t1107, !range !{i64 0, i64 18}
  %t1110 = icmp eq i64 %t1108, 13
  store i1 %t1110, ptr %l479, !tbaa !21
  br label %bb262
bb262:
  %t1111 = load i1, ptr %l479, !tbaa !21
  br i1 %t1111, label %bb263, label %bb264
bb263:
  %t1112 = load ptr, ptr %l1, !tbaa !29
  %t1114 = getelementptr { i64, [5 x i64] }, ptr %t1112, i32 0, i32 1
  %t1115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1114, i32 0, i32 2
  %t1116 = load ptr, ptr %t1115
  store ptr %t1116, ptr %l40, !tbaa !29
  br label %bb265
bb264:
  br label %bb289
bb265:
  %t1118 = load ptr, ptr %l40, !tbaa !29
  %t1120 = getelementptr %"compiler/typed:Match", ptr %t1118, i32 0, i32 0
  %t1121 = load { i64, ptr }, ptr %t1120, !tbaa !27
  store { i64, ptr } %t1121, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t1123 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t1125 = extractvalue { i64, ptr } %t1123, 0
  store i64 %t1125, ptr %l43, !tbaa !24
  br label %bb266
bb266:
  %t1127 = load i64, ptr %l42, !tbaa !24
  %t1128 = load i64, ptr %l43, !tbaa !24
  %t1131 = icmp slt i64 %t1127, %t1128
  %t1133 = xor i1 %t1131, true
  br i1 %t1133, label %bb267, label %bb268
bb267:
  br label %bb272
bb268:
  br label %bb269
bb269:
  %t1135 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t1135, ptr %l492, !tbaa !27
  %t1136 = load i64, ptr %l42, !tbaa !24
  %t1138 = getelementptr { i64, ptr }, ptr %l492, i32 0, i32 1
  %t1139 = load ptr, ptr %t1138, !tbaa !27
  %t1140 = getelementptr ptr, ptr %t1139, i64 %t1136
  %t1141 = load ptr, ptr %t1140, !tbaa !39
  %t1143 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %t1143, ptr %t1141)
  br label %bb270
bb270:
  br label %bb271
bb271:
  %t1147 = load i64, ptr %l42, !tbaa !24
  %t1150 = add i64 %t1147, 1
  store i64 %t1150, ptr %l42, !tbaa !24
  br label %bb266
bb272:
  %t1152 = load ptr, ptr %l40, !tbaa !29
  %t1154 = getelementptr %"compiler/typed:Match", ptr %t1152, i32 0, i32 1
  %t1155 = load { i64, ptr }, ptr %t1154, !tbaa !27
  store { i64, ptr } %t1155, ptr %l45, !tbaa !27
  store i64 0, ptr %l46, !tbaa !24
  %t1157 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1159 = extractvalue { i64, ptr } %t1157, 0
  store i64 %t1159, ptr %l47, !tbaa !24
  br label %bb273
bb273:
  store %olang.scope zeroinitializer, ptr %s39
  %t1161 = load i64, ptr %l46, !tbaa !24
  %t1162 = load i64, ptr %l47, !tbaa !24
  %t1165 = icmp slt i64 %t1161, %t1162
  %t1167 = xor i1 %t1165, true
  br i1 %t1167, label %bb274, label %bb275
bb274:
  call void @__olang_scope_close(ptr %s39)
  br label %bb280
bb275:
  br label %bb276
bb276:
  %t1169 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t1169, ptr %l508, !tbaa !27
  %t1170 = load i64, ptr %l46, !tbaa !24
  %t1172 = getelementptr { i64, ptr }, ptr %l508, i32 0, i32 1
  %t1173 = load ptr, ptr %t1172, !tbaa !27
  %t1174 = getelementptr ptr, ptr %t1173, i64 %t1170
  %t1175 = load ptr, ptr %t1174, !tbaa !39
  store ptr %l2, ptr %l511, !tbaa !29
  %t1177 = load ptr, ptr %l0, !tbaa !29
  %t1181 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s39, ptr %t1177, ptr %t1175)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1181, ptr %l514
  br label %bb277
bb277:
  %t1182 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l514
  %t1183 = call ptr @__olang_scope_alloc_a(ptr %s39, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1182, ptr %t1183
  %t1184 = load ptr, ptr %l511, !tbaa !29
  %t1186 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s39, ptr %t1184, ptr %t1183)
  store i64 %t1186, ptr %l516
  br label %bb278
bb278:
  call void @__olang_scope_close(ptr %s39)
  br label %bb279
bb279:
  %t1187 = load i64, ptr %l46, !tbaa !24
  %t1190 = add i64 %t1187, 1
  store i64 %t1190, ptr %l46, !tbaa !24
  br label %bb273
bb280:
  %t1192 = load ptr, ptr %l40, !tbaa !29
  %t1194 = getelementptr %"compiler/typed:Match", ptr %t1192, i32 0, i32 2
  %t1195 = load ptr, ptr %t1194, !tbaa !29
  %t1197 = icmp eq ptr %t1195, null
  %t1199 = xor i1 %t1197, true
  br i1 %t1199, label %bb281, label %bb282
bb281:
  store %olang.scope zeroinitializer, ptr %s41
  store ptr %l2, ptr %l524, !tbaa !29
  %t1201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1201, ptr %l525, !tbaa !29
  %t1202 = load ptr, ptr %l40, !tbaa !29
  %t1204 = getelementptr %"compiler/typed:Match", ptr %t1202, i32 0, i32 2
  %t1205 = load ptr, ptr %t1204, !tbaa !29
  %t1207 = icmp eq ptr %t1205, null
  br i1 %t1207, label %bb283, label %bb284
bb282:
  br label %bb288
bb283:
  call void @__olang_check_failed(ptr @olang_loc_399af2e67a3feb00_10d299b63d924a94)
  unreachable
bb284:
  br label %bb285
bb285:
  %t1209 = load ptr, ptr %l40, !tbaa !29
  %t1211 = getelementptr %"compiler/typed:Match", ptr %t1209, i32 0, i32 2
  %t1212 = load ptr, ptr %t1211, !tbaa !29
  %t1213 = load ptr, ptr %l525, !tbaa !29
  %t1215 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %s41, ptr %t1213, ptr %t1212)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1215, ptr %l531
  br label %bb286
bb286:
  %t1216 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l531
  %t1217 = call ptr @__olang_scope_alloc_a(ptr %s41, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1216, ptr %t1217
  %t1218 = load ptr, ptr %l524, !tbaa !29
  %t1220 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s41, ptr %t1218, ptr %t1217)
  store i64 %t1220, ptr %l533
  br label %bb287
bb287:
  call void @__olang_scope_close(ptr %s41)
  br label %bb288
bb288:
  br label %bb373
bb289:
  %t1221 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1221, ptr %l534, !tbaa !29
  store i1 false, ptr %l535, !tbaa !21
  %t1222 = load ptr, ptr %l534, !tbaa !29
  %t1223 = icmp ne ptr %t1222, null
  br i1 %t1223, label %bb290, label %bb291
bb290:
  %t1225 = load ptr, ptr %l534, !tbaa !29
  %t1226 = load i64, ptr %t1225, !range !{i64 0, i64 18}
  %t1228 = icmp eq i64 %t1226, 14
  store i1 %t1228, ptr %l535, !tbaa !21
  br label %bb291
bb291:
  %t1229 = load i1, ptr %l535, !tbaa !21
  br i1 %t1229, label %bb292, label %bb293
bb292:
  %t1230 = load ptr, ptr %l1, !tbaa !29
  %t1232 = getelementptr { i64, [5 x i64] }, ptr %t1230, i32 0, i32 1
  %t1233 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1232, i32 0, i32 2
  %t1234 = load ptr, ptr %t1233
  store ptr %t1234, ptr %l49, !tbaa !29
  br label %bb294
bb293:
  br label %bb327
bb294:
  %t1236 = load ptr, ptr %l49, !tbaa !29
  %t1238 = getelementptr %"compiler/typed:Try", ptr %t1236, i32 0, i32 0
  %t1239 = load ptr, ptr %t1238, !tbaa !29
  %t1241 = icmp eq ptr %t1239, null
  %t1243 = xor i1 %t1241, true
  br i1 %t1243, label %bb295, label %bb296
bb295:
  %t1245 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1245, ptr %l544, !tbaa !29
  %t1246 = load ptr, ptr %l49, !tbaa !29
  %t1248 = getelementptr %"compiler/typed:Try", ptr %t1246, i32 0, i32 0
  %t1249 = load ptr, ptr %t1248, !tbaa !29
  %t1251 = icmp eq ptr %t1249, null
  br i1 %t1251, label %bb297, label %bb298
bb296:
  br label %bb305
bb297:
  call void @__olang_check_failed(ptr @olang_loc_9fb993e2bf346d79_40fc6d70dd039d65)
  unreachable
bb298:
  br label %bb299
bb299:
  %t1253 = load ptr, ptr %l49, !tbaa !29
  %t1255 = getelementptr %"compiler/typed:Try", ptr %t1253, i32 0, i32 0
  %t1256 = load ptr, ptr %t1255, !tbaa !29
  %t1257 = load ptr, ptr %l544, !tbaa !29
  %t1259 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1257, ptr %t1256)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1259, ptr %l550
  br label %bb300
bb300:
  %t1260 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1260, ptr %l551
  %t1261 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l550
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1261, ptr %l2
  %t1262 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1262, label %bb301, label %bb302
bb301:
  %t1264 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l551, i32 0, i32 0
  %t1265 = load { i64, ptr }, ptr %t1264
  %t1266 = extractvalue { i64, ptr } %t1265, 1
  %t1267 = call ptr @__olang_region_or(ptr %t1266, ptr null)
  %t1268 = call ptr @__olang_region_home(ptr %t1267)
  %t1269 = icmp ne ptr %t1268, null
  %t1270 = select i1 %t1269, ptr %t1268, ptr null
  call void @__olang_region_drop(ptr %t1270)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l551
  br label %bb302
bb302:
  %t1271 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1271, label %bb303, label %bb304
bb303:
  %t1273 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l551, i32 0, i32 0
  %t1274 = load { i64, ptr }, ptr %t1273
  %t1275 = extractvalue { i64, ptr } %t1274, 0
  %t1276 = extractvalue { i64, ptr } %t1274, 1
  call void @__olang_region_release_part(ptr %t1276, i64 %t1275)
  store { i64, ptr } zeroinitializer, ptr %t1273
  br label %bb304
bb304:
  br label %bb305
bb305:
  %t1277 = load ptr, ptr %l49, !tbaa !29
  %t1279 = getelementptr %"compiler/typed:Try", ptr %t1277, i32 0, i32 1
  %t1280 = load { i64, ptr }, ptr %t1279, !tbaa !27
  store { i64, ptr } %t1280, ptr %l50, !tbaa !27
  store i64 0, ptr %l51, !tbaa !24
  %t1282 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t1284 = extractvalue { i64, ptr } %t1282, 0
  store i64 %t1284, ptr %l52, !tbaa !24
  br label %bb306
bb306:
  %t1286 = load i64, ptr %l51, !tbaa !24
  %t1287 = load i64, ptr %l52, !tbaa !24
  %t1290 = icmp slt i64 %t1286, %t1287
  %t1292 = xor i1 %t1290, true
  br i1 %t1292, label %bb307, label %bb308
bb307:
  br label %bb326
bb308:
  br label %bb309
bb309:
  %t1294 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t1294, ptr %l562, !tbaa !27
  %t1295 = load i64, ptr %l51, !tbaa !24
  %t1297 = getelementptr { i64, ptr }, ptr %l562, i32 0, i32 1
  %t1298 = load ptr, ptr %t1297, !tbaa !27
  %t1299 = getelementptr ptr, ptr %t1298, i64 %t1295
  %t1300 = load ptr, ptr %t1299, !tbaa !39
  store ptr %t1300, ptr %l53, !tbaa !29
  %t1302 = load ptr, ptr %l53, !tbaa !29
  %t1304 = getelementptr %"compiler/typed:Clause", ptr %t1302, i32 0, i32 3
  %t1305 = load ptr, ptr %t1304, !tbaa !29
  %t1307 = icmp eq ptr %t1305, null
  %t1309 = xor i1 %t1307, true
  br i1 %t1309, label %bb310, label %bb311
bb310:
  %t1311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1311, ptr %l569, !tbaa !29
  %t1312 = load ptr, ptr %l53, !tbaa !29
  %t1314 = getelementptr %"compiler/typed:Clause", ptr %t1312, i32 0, i32 3
  %t1315 = load ptr, ptr %t1314, !tbaa !29
  %t1317 = icmp eq ptr %t1315, null
  br i1 %t1317, label %bb312, label %bb313
bb311:
  br label %bb316
bb312:
  call void @__olang_check_failed(ptr @olang_loc_e7b8bfc98130e352_7e3653312711fbbe)
  unreachable
bb313:
  br label %bb314
bb314:
  %t1319 = load ptr, ptr %l53, !tbaa !29
  %t1321 = getelementptr %"compiler/typed:Clause", ptr %t1319, i32 0, i32 3
  %t1322 = load ptr, ptr %t1321, !tbaa !29
  %t1323 = load ptr, ptr %l569, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %t1323, ptr %t1322)
  br label %bb315
bb315:
  br label %bb316
bb316:
  %t1325 = load ptr, ptr %l53, !tbaa !29
  %t1327 = getelementptr %"compiler/typed:Clause", ptr %t1325, i32 0, i32 4
  %t1328 = load { i64, ptr }, ptr %t1327, !tbaa !27
  store { i64, ptr } %t1328, ptr %l54, !tbaa !27
  store i64 0, ptr %l55, !tbaa !24
  %t1330 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t1332 = extractvalue { i64, ptr } %t1330, 0
  store i64 %t1332, ptr %l56, !tbaa !24
  br label %bb317
bb317:
  store %olang.scope zeroinitializer, ptr %s48
  %t1334 = load i64, ptr %l55, !tbaa !24
  %t1335 = load i64, ptr %l56, !tbaa !24
  %t1338 = icmp slt i64 %t1334, %t1335
  %t1340 = xor i1 %t1338, true
  br i1 %t1340, label %bb318, label %bb319
bb318:
  call void @__olang_scope_close(ptr %s48)
  br label %bb324
bb319:
  br label %bb320
bb320:
  %t1342 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t1342, ptr %l583, !tbaa !27
  %t1343 = load i64, ptr %l55, !tbaa !24
  %t1345 = getelementptr { i64, ptr }, ptr %l583, i32 0, i32 1
  %t1346 = load ptr, ptr %t1345, !tbaa !27
  %t1347 = getelementptr ptr, ptr %t1346, i64 %t1343
  %t1348 = load ptr, ptr %t1347, !tbaa !39
  store ptr %l2, ptr %l586, !tbaa !29
  %t1350 = load ptr, ptr %l0, !tbaa !29
  %t1354 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s48, ptr %t1350, ptr %t1348)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1354, ptr %l589
  br label %bb321
bb321:
  %t1355 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l589
  %t1356 = call ptr @__olang_scope_alloc_a(ptr %s48, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1355, ptr %t1356
  %t1357 = load ptr, ptr %l586, !tbaa !29
  %t1359 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s48, ptr %t1357, ptr %t1356)
  store i64 %t1359, ptr %l591
  br label %bb322
bb322:
  call void @__olang_scope_close(ptr %s48)
  br label %bb323
bb323:
  %t1360 = load i64, ptr %l55, !tbaa !24
  %t1363 = add i64 %t1360, 1
  store i64 %t1363, ptr %l55, !tbaa !24
  br label %bb317
bb324:
  br label %bb325
bb325:
  %t1365 = load i64, ptr %l51, !tbaa !24
  %t1368 = add i64 %t1365, 1
  store i64 %t1368, ptr %l51, !tbaa !24
  br label %bb306
bb326:
  br label %bb373
bb327:
  %t1370 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1370, ptr %l598, !tbaa !29
  store i1 false, ptr %l599, !tbaa !21
  %t1371 = load ptr, ptr %l598, !tbaa !29
  %t1372 = icmp ne ptr %t1371, null
  br i1 %t1372, label %bb328, label %bb329
bb328:
  %t1374 = load ptr, ptr %l598, !tbaa !29
  %t1375 = load i64, ptr %t1374, !range !{i64 0, i64 18}
  %t1377 = icmp eq i64 %t1375, 15
  store i1 %t1377, ptr %l599, !tbaa !21
  br label %bb329
bb329:
  %t1378 = load i1, ptr %l599, !tbaa !21
  br i1 %t1378, label %bb330, label %bb331
bb330:
  %t1379 = load ptr, ptr %l1, !tbaa !29
  %t1381 = getelementptr { i64, [5 x i64] }, ptr %t1379, i32 0, i32 1
  %t1382 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1381, i32 0, i32 0
  %t1383 = load %"compiler/source:Span", ptr %t1382
  store %"compiler/source:Span" %t1383, ptr %l58
  %t1385 = load ptr, ptr %l1, !tbaa !29
  %t1387 = getelementptr { i64, [5 x i64] }, ptr %t1385, i32 0, i32 1
  %t1388 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1387, i32 0, i32 2
  %t1389 = load ptr, ptr %t1388
  store ptr %t1389, ptr %l59, !tbaa !29
  br label %bb332
bb331:
  br label %bb342
bb332:
  %t1391 = call ptr @__olang_scope_hold(ptr %v2)
  %t1392 = ptrtoint ptr %t1391 to i64
  store i64 %t1392, ptr %l606, !tbaa !24
  %t1393 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1393, label %bb333, label %bb334
bb333:
  %t1395 = call ptr @__olang_region_make(ptr %v2)
  %t1396 = ptrtoint ptr %t1395 to i64
  store i64 %t1396, ptr %l606, !tbaa !24
  br label %bb334
bb334:
  %t1397 = load ptr, ptr %l0, !tbaa !29
  %t1398 = load %"compiler/source:Span", ptr %l58
  %t1399 = load ptr, ptr %l59, !tbaa !29
  %t1400 = load i64, ptr %l606
  %t1401 = inttoptr i64 %t1400 to ptr
  %t1405 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2efnValOf(ptr %v0, ptr %v1, ptr %t1401, ptr %t1397, %"compiler/source:Span" %t1398, ptr %t1399)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1405, ptr %l611
  br label %bb335
bb335:
  %t1406 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1406, label %bb336, label %bb337
bb336:
  %t1408 = load i64, ptr %l606
  %t1409 = inttoptr i64 %t1408 to ptr
  %t1410 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l611, i32 0, i32 0
  %t1411 = load { i64, ptr }, ptr %t1410
  %t1412 = extractvalue { i64, ptr } %t1411, 1
  %t1413 = call ptr @__olang_region_or(ptr %t1412, ptr null)
  %t1414 = call ptr @__olang_region_home(ptr %t1413)
  %t1415 = icmp ne ptr %t1414, null
  %t1416 = select i1 %t1415, ptr %t1414, ptr null
  call void @__olang_region_settle_in(ptr %t1409, ptr %t1416)
  br label %bb337
bb337:
  %t1417 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1417, ptr %l613
  %t1418 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l611
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1418, ptr %l2
  %t1419 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1419, label %bb338, label %bb339
bb338:
  %t1421 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l613, i32 0, i32 0
  %t1422 = load { i64, ptr }, ptr %t1421
  %t1423 = extractvalue { i64, ptr } %t1422, 1
  %t1424 = call ptr @__olang_region_or(ptr %t1423, ptr null)
  %t1425 = call ptr @__olang_region_home(ptr %t1424)
  %t1426 = icmp ne ptr %t1425, null
  %t1427 = select i1 %t1426, ptr %t1425, ptr null
  call void @__olang_region_drop(ptr %t1427)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l613
  br label %bb339
bb339:
  %t1428 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1428, label %bb340, label %bb341
bb340:
  %t1430 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l613, i32 0, i32 0
  %t1431 = load { i64, ptr }, ptr %t1430
  %t1432 = extractvalue { i64, ptr } %t1431, 0
  %t1433 = extractvalue { i64, ptr } %t1431, 1
  call void @__olang_region_release_part(ptr %t1433, i64 %t1432)
  store { i64, ptr } zeroinitializer, ptr %t1430
  br label %bb341
bb341:
  br label %bb373
bb342:
  %t1434 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1434, ptr %l616, !tbaa !29
  store i1 false, ptr %l617, !tbaa !21
  %t1435 = load ptr, ptr %l616, !tbaa !29
  %t1436 = icmp ne ptr %t1435, null
  br i1 %t1436, label %bb343, label %bb344
bb343:
  %t1438 = load ptr, ptr %l616, !tbaa !29
  %t1439 = load i64, ptr %t1438, !range !{i64 0, i64 18}
  %t1441 = icmp eq i64 %t1439, 16
  store i1 %t1441, ptr %l617, !tbaa !21
  br label %bb344
bb344:
  %t1442 = load i1, ptr %l617, !tbaa !21
  br i1 %t1442, label %bb345, label %bb346
bb345:
  %t1443 = load ptr, ptr %l1, !tbaa !29
  %t1445 = getelementptr { i64, [5 x i64] }, ptr %t1443, i32 0, i32 1
  %t1446 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t1445, i32 0, i32 2
  %t1447 = load ptr, ptr %t1446
  store ptr %t1447, ptr %l60, !tbaa !29
  br label %bb347
bb346:
  br label %bb357
bb347:
  %t1449 = call ptr @__olang_scope_hold(ptr %v2)
  %t1450 = ptrtoint ptr %t1449 to i64
  store i64 %t1450, ptr %l622, !tbaa !24
  %t1451 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1451, label %bb348, label %bb349
bb348:
  %t1453 = call ptr @__olang_region_make(ptr %v2)
  %t1454 = ptrtoint ptr %t1453 to i64
  store i64 %t1454, ptr %l622, !tbaa !24
  br label %bb349
bb349:
  %t1455 = load ptr, ptr %l0, !tbaa !29
  %t1456 = load ptr, ptr %l60, !tbaa !29
  %t1457 = load i64, ptr %l622
  %t1458 = inttoptr i64 %t1457 to ptr
  %t1461 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etextOf(ptr %v0, ptr %v1, ptr %t1458, ptr %t1455, ptr %t1456)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1461, ptr %l626
  br label %bb350
bb350:
  %t1462 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1462, label %bb351, label %bb352
bb351:
  %t1464 = load i64, ptr %l622
  %t1465 = inttoptr i64 %t1464 to ptr
  %t1466 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l626, i32 0, i32 0
  %t1467 = load { i64, ptr }, ptr %t1466
  %t1468 = extractvalue { i64, ptr } %t1467, 1
  %t1469 = call ptr @__olang_region_or(ptr %t1468, ptr null)
  %t1470 = call ptr @__olang_region_home(ptr %t1469)
  %t1471 = icmp ne ptr %t1470, null
  %t1472 = select i1 %t1471, ptr %t1470, ptr null
  call void @__olang_region_settle_in(ptr %t1465, ptr %t1472)
  br label %bb352
bb352:
  %t1473 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1473, ptr %l628
  %t1474 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l626
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1474, ptr %l2
  %t1475 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1475, label %bb353, label %bb354
bb353:
  %t1477 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l628, i32 0, i32 0
  %t1478 = load { i64, ptr }, ptr %t1477
  %t1479 = extractvalue { i64, ptr } %t1478, 1
  %t1480 = call ptr @__olang_region_or(ptr %t1479, ptr null)
  %t1481 = call ptr @__olang_region_home(ptr %t1480)
  %t1482 = icmp ne ptr %t1481, null
  %t1483 = select i1 %t1482, ptr %t1481, ptr null
  call void @__olang_region_drop(ptr %t1483)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l628
  br label %bb354
bb354:
  %t1484 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1484, label %bb355, label %bb356
bb355:
  %t1486 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l628, i32 0, i32 0
  %t1487 = load { i64, ptr }, ptr %t1486
  %t1488 = extractvalue { i64, ptr } %t1487, 0
  %t1489 = extractvalue { i64, ptr } %t1487, 1
  call void @__olang_region_release_part(ptr %t1489, i64 %t1488)
  store { i64, ptr } zeroinitializer, ptr %t1486
  br label %bb356
bb356:
  br label %bb373
bb357:
  %t1490 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1490, ptr %l631, !tbaa !29
  store i1 false, ptr %l632, !tbaa !21
  %t1491 = load ptr, ptr %l631, !tbaa !29
  %t1492 = icmp ne ptr %t1491, null
  br i1 %t1492, label %bb358, label %bb359
bb358:
  %t1494 = load ptr, ptr %l631, !tbaa !29
  %t1495 = load i64, ptr %t1494, !range !{i64 0, i64 18}
  %t1497 = icmp eq i64 %t1495, 17
  store i1 %t1497, ptr %l632, !tbaa !21
  br label %bb359
bb359:
  %t1498 = load i1, ptr %l632, !tbaa !21
  br i1 %t1498, label %bb360, label %bb361
bb360:
  %t1499 = load ptr, ptr %l1, !tbaa !29
  %t1501 = getelementptr { i64, [5 x i64] }, ptr %t1499, i32 0, i32 1
  %t1502 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t1501, i32 0, i32 2
  %t1503 = load ptr, ptr %t1502
  store ptr %t1503, ptr %l61, !tbaa !29
  br label %bb362
bb361:
  br label %bb368
bb362:
  %t1505 = load ptr, ptr %l0, !tbaa !29
  %t1506 = load ptr, ptr %l61, !tbaa !29
  %t1509 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t1505, ptr %t1506)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1509, ptr %l639
  br label %bb363
bb363:
  %t1510 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1510, ptr %l640
  %t1511 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l639
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1511, ptr %l2
  %t1512 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2
  br i1 %t1512, label %bb364, label %bb365
bb364:
  %t1514 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l640, i32 0, i32 0
  %t1515 = load { i64, ptr }, ptr %t1514
  %t1516 = extractvalue { i64, ptr } %t1515, 1
  %t1517 = call ptr @__olang_region_or(ptr %t1516, ptr null)
  %t1518 = call ptr @__olang_region_home(ptr %t1517)
  %t1519 = icmp ne ptr %t1518, null
  %t1520 = select i1 %t1519, ptr %t1518, ptr null
  call void @__olang_region_drop(ptr %t1520)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l640
  br label %bb365
bb365:
  %t1521 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t1521, label %bb366, label %bb367
bb366:
  %t1523 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l640, i32 0, i32 0
  %t1524 = load { i64, ptr }, ptr %t1523
  %t1525 = extractvalue { i64, ptr } %t1524, 0
  %t1526 = extractvalue { i64, ptr } %t1524, 1
  call void @__olang_region_release_part(ptr %t1526, i64 %t1525)
  store { i64, ptr } zeroinitializer, ptr %t1523
  br label %bb367
bb367:
  br label %bb373
bb368:
  br i1 true, label %bb369, label %bb370
bb369:
  br label %bb371
bb370:
  br label %bb372
bb371:
  br label %bb373
bb372:
  call void @__olang_check_failed(ptr @olang_loc_cced39b51eedc52a_7a31888a1cea4cb6)
  unreachable
bb373:
  %t1527 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1527, ptr %l643, !tbaa !29
  %t1528 = load ptr, ptr %l1, !tbaa !29
  %t1530 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t1528)
  store i32 %t1530, ptr %l645
  br label %bb374
bb374:
  %t1531 = load ptr, ptr %l643, !tbaa !29
  %t1532 = load i32, ptr %l645, !tbaa !23
  %t1533 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %t1531, i32 %t1532)
  store i1 %t1533, ptr %l646
  br label %bb375
bb375:
  %t1534 = load i1, ptr %l646, !tbaa !21
  %t1535 = xor i1 %t1534, true
  br i1 %t1535, label %bb376, label %bb377
bb376:
  %t1537 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1537, ptr %l648
  br label %bb378
bb377:
  br label %bb379
bb378:
  %t1538 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l648
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1538, ptr %rv
  br label %ret
bb379:
  %t1539 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1539, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeederPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/free:feed"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %t1, i64 %a1)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/free:walker", ptr %t11, i32 0, i32 0
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 174
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t16, i64 %t17)
  store %"compiler/free:feed" %t20, ptr %l13
  br label %bb4
bb3:
  store i64 -1, ptr %l8, !tbaa !24
  br label %bb5
bb4:
  %t21 = getelementptr %"compiler/free:feed", ptr %l13, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t24 = load i64, ptr %l8, !tbaa !24
  store i64 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2efnValOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca ptr
  %l18 = alloca i1
  %l37 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca i64
  %l64 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l104 = alloca i64
  %l105 = alloca ptr
  %l109 = alloca i64
  %l110 = alloca i64
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l16
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load ptr, ptr %l2, !tbaa !29
  store ptr %t3, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t4 = load ptr, ptr %l17, !tbaa !29
  %t5 = icmp ne ptr %t4, null
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l17, !tbaa !29
  %t8 = load i64, ptr %t7, !range !{i64 0, i64 3}
  %t10 = icmp eq i64 %t8, 1
  store i1 %t10, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l18, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = getelementptr { i64, [4 x i64] }, ptr %t12, i32 0, i32 1
  %t15 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t14, i32 0, i32 0
  %t16 = load i32, ptr %t15
  store i32 %t16, ptr %l4, !tbaa !23
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t20, i32 0, i32 1
  %t22 = load { i64, ptr }, ptr %t21
  store { i64, ptr } %t22, ptr %l5, !tbaa !27
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l6, !tbaa !23
  br label %bb6
bb5:
  br label %bb22
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/free:walker", ptr %t30, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l4, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2elambdaMade(ptr %v0, ptr %t37, i32 %t38)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/free:walker", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/free:Free", ptr %t44, i32 0, i32 1
  %t47 = load i32, ptr %l4, !tbaa !23
  %t49 = sext i32 %t47 to i64
  %t52 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t46, i64 %t49)
  store ptr %t52, ptr %l37
  br label %bb11
bb11:
  %t53 = load ptr, ptr %l37, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 14
  %t56 = load i1, ptr %t55, !tbaa !21
  store i1 %t56, ptr %l7, !tbaa !21
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t58, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l10, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t64 = load i64, ptr %l9, !tbaa !24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = icmp slt i64 %t64, %t65
  %t70 = xor i1 %t68, true
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s4)
  br label %bb19
bb14:
  br label %bb15
bb15:
  %t72 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t72, ptr %l47, !tbaa !27
  %t73 = load i64, ptr %l9, !tbaa !24
  %t75 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = getelementptr ptr, ptr %t76, i64 %t73
  %t78 = load ptr, ptr %t77, !tbaa !39
  store ptr %l3, ptr %l50, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load %"compiler/source:Span", ptr %l1
  %t84 = getelementptr %"compiler/typed:Capture", ptr %t78, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t86 = load i32, ptr %l6, !tbaa !23
  %t88 = sext i32 %t86 to i64
  %t89 = load i1, ptr %l7, !tbaa !21
  %t95 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecaptured(ptr %v0, ptr %v1, ptr %s4, ptr %t80, %"compiler/source:Span" %t81, ptr %t85, i64 %t88, i1 %t89)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t95, ptr %l58
  br label %bb16
bb16:
  %t96 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  %t97 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t96, ptr %t97
  %t98 = load ptr, ptr %l50, !tbaa !29
  %t100 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s4, ptr %t98, ptr %t97)
  store i64 %t100, ptr %l60
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb18
bb18:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = add i64 %t101, 1
  store i64 %t104, ptr %l9, !tbaa !24
  br label %bb12
bb19:
  store ptr %l3, ptr %l64, !tbaa !29
  %t106 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t107 = load i32, ptr %l6, !tbaa !23
  %t109 = sext i32 %t107 to i64
  %t112 = call i64 @compiler_2ffree_2eorig(i64 %t106, i64 %t109)
  store i64 %t112, ptr %l68
  br label %bb20
bb20:
  %t113 = load ptr, ptr %l64, !tbaa !29
  %t114 = load i64, ptr %l68, !tbaa !24
  %t115 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t113, i64 %t114)
  store i64 %t115, ptr %l69
  br label %bb21
bb21:
  br label %bb49
bb22:
  %t116 = load ptr, ptr %l2, !tbaa !29
  store ptr %t116, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t117 = load ptr, ptr %l70, !tbaa !29
  %t118 = icmp ne ptr %t117, null
  br i1 %t118, label %bb23, label %bb24
bb23:
  %t120 = load ptr, ptr %l70, !tbaa !29
  %t121 = load i64, ptr %t120, !range !{i64 0, i64 3}
  %t123 = icmp eq i64 %t121, 0
  store i1 %t123, ptr %l71, !tbaa !21
  br label %bb24
bb24:
  %t124 = load i1, ptr %l71, !tbaa !21
  br i1 %t124, label %bb25, label %bb26
bb25:
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr { i64, [4 x i64] }, ptr %t125, i32 0, i32 1
  %t128 = getelementptr { i32 }, ptr %t127, i32 0, i32 0
  %t129 = load i32, ptr %t128
  store i32 %t129, ptr %l12, !tbaa !23
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/free:walker", ptr %t131, i32 0, i32 0
  %t134 = load ptr, ptr %t133, !tbaa !29
  %t136 = getelementptr %"compiler/free:Free", ptr %t134, i32 0, i32 98
  %t137 = load i32, ptr %l12, !tbaa !23
  %t139 = sext i32 %t137 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t136, i64 %t139, i1 true)
  br label %bb28
bb28:
  br label %bb49
bb29:
  %t142 = load ptr, ptr %l2, !tbaa !29
  store ptr %t142, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t143 = load ptr, ptr %l81, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb30, label %bb31
bb30:
  %t146 = load ptr, ptr %l81, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 3}
  %t149 = icmp eq i64 %t147, 2
  store i1 %t149, ptr %l82, !tbaa !21
  br label %bb31
bb31:
  %t150 = load i1, ptr %l82, !tbaa !21
  br i1 %t150, label %bb32, label %bb33
bb32:
  %t151 = load ptr, ptr %l2, !tbaa !29
  %t153 = getelementptr { i64, [4 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { i32, ptr, i32 }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l13, !tbaa !29
  %t157 = load ptr, ptr %l2, !tbaa !29
  %t159 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  %t160 = getelementptr { i32, ptr, i32 }, ptr %t159, i32 0, i32 2
  %t161 = load i32, ptr %t160
  store i32 %t161, ptr %l14, !tbaa !23
  br label %bb34
bb33:
  br label %bb44
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/free:walker", ptr %t163, i32 0, i32 2
  %t166 = load i1, ptr %t165, !tbaa !21
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb35, label %bb36
bb35:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/free:walker", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/free:walker", ptr %t174, i32 0, i32 1
  %t177 = load i64, ptr %t176, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t173, i64 %t177)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load ptr, ptr %l13, !tbaa !29
  %t184 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s7, ptr %t180, ptr %t181)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t184, ptr %l98
  br label %bb39
bb39:
  %t185 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t185, ptr %l15
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s7, ptr %s7, ptr %t186, ptr %l15, %"compiler/source:Span" %t187, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb40
bb40:
  %t193 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s7, ptr %l3, ptr %l15)
  store i64 %t193, ptr %l104
  br label %bb41
bb41:
  store ptr %l3, ptr %l105, !tbaa !29
  %t194 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t195 = load i32, ptr %l14, !tbaa !23
  %t197 = sext i32 %t195 to i64
  %t200 = call i64 @compiler_2ffree_2eorig(i64 %t194, i64 %t197)
  store i64 %t200, ptr %l109
  br label %bb42
bb42:
  %t201 = load ptr, ptr %l105, !tbaa !29
  %t202 = load i64, ptr %l109, !tbaa !24
  %t203 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t201, i64 %t202)
  store i64 %t203, ptr %l110
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb49
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_958920a902c28464_5f3c4db0e7df1ea8)
  unreachable
bb49:
  %t204 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t204, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eheldDrop(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l14 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %rv = alloca i64
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t3 = trunc i64 31 to i32
  %t4 = icmp eq i32 %a1, %t3
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb3
bb2:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp ne i64 %t10, 1
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l14, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb5:
  %t17 = getelementptr %"compiler/free:walker", ptr %a0, i32 0, i32 100
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l21
  br label %bb6
bb6:
  %t20 = load i64, ptr %l21, !tbaa !24
  %t21 = icmp eq i64 %t20, 0
  store i1 %t21, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l18, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i64 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t25, ptr %l24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = getelementptr ptr, ptr %t27, i64 0
  %t29 = load ptr, ptr %t28, !tbaa !39
  store ptr %t29, ptr %l3, !tbaa !29
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t32 = load ptr, ptr %l26, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = load i64, ptr %t35, !range !{i64 0, i64 18}
  %t38 = icmp eq i64 %t36, 3
  store i1 %t38, ptr %l27, !tbaa !21
  br label %bb12
bb12:
  %t39 = load i1, ptr %l27, !tbaa !21
  %t40 = xor i1 %t39, true
  br i1 %t40, label %bb13, label %bb14
bb13:
  store i64 -1, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l3, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t45, i32 0, i32 0
  %t47 = load %"compiler/source:Span", ptr %t46
  store %"compiler/source:Span" %t47, ptr %l4
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t51 = getelementptr { i64, [5 x i64] }, ptr %t49, i32 0, i32 1
  %t52 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t51, i32 0, i32 1
  %t53 = load i32, ptr %t52
  store i32 %t53, ptr %l5, !tbaa !23
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr { i64, [5 x i64] }, ptr %t55, i32 0, i32 1
  %t58 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t57, i32 0, i32 2
  %t59 = load ptr, ptr %t58
  store ptr %t59, ptr %l7, !tbaa !29
  %t63 = load ptr, ptr %l7, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t67 = load ptr, ptr %l39, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 8}
  %t70 = icmp eq i64 %t68, 0
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb17
bb17:
  %t71 = load i1, ptr %l40, !tbaa !21
  %t72 = xor i1 %t71, true
  br i1 %t72, label %bb18, label %bb19
bb18:
  store i64 -1, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t77, i32 0, i32 0
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l8
  %t81 = load ptr, ptr %l7, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l9, !tbaa !23
  %t87 = load ptr, ptr %l7, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t89, i32 0, i32 2
  %t91 = load i32, ptr %t90
  %t95 = sext i32 %t91 to i64
  store i64 %t95, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2einOwner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l12 = alloca i1
  %l17 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i1
  %l33 = alloca i64
  %l36 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca %"compiler/source:Span"
  %l54 = alloca i64
  %l56 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 2
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 36
  %t11 = load i64, ptr %t10, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  store i1 %t13, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l12, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  store ptr %a1, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb7
bb7:
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l17, !tbaa !24
  %t19 = load ptr, ptr %l5, !tbaa !29
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = load i64, ptr %l19, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb9, label %bb10
bb9:
  br label %bb35
bb10:
  br label %bb11
bb11:
  %t28 = load ptr, ptr %l5, !tbaa !29
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l24
  br label %bb12
bb12:
  %t33 = load i64, ptr %l24, !tbaa !24
  store i64 %t33, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l7, !tbaa !24
  %t36 = call i64 @compiler_2ffree_2eoval(i64 %t34)
  store i64 %t36, ptr %l26
  br label %bb13
bb13:
  %t37 = load i64, ptr %l26, !tbaa !24
  store i64 %t37, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = call i64 @compiler_2ffree_2eokind(i64 %t38)
  store i64 %t40, ptr %l28
  br label %bb14
bb14:
  %t41 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t44 = icmp eq i64 %t42, %t41
  br i1 %t44, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb18
bb16:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = call i64 @compiler_2ffree_2eokind(i64 %t46)
  store i64 %t48, ptr %l33
  br label %bb17
bb17:
  %t49 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t50 = load i64, ptr %l33, !tbaa !24
  %t52 = icmp eq i64 %t50, %t49
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t59 = icmp ne i64 %t55, %a2
  store i1 %t59, ptr %l36, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb21
bb21:
  %t61 = load i1, ptr %l36, !tbaa !21
  br i1 %t61, label %bb22, label %bb23
bb22:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/free:walker", ptr %t62, i32 0, i32 0
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %t65, i64 %t66)
  store i1 %t69, ptr %l44
  br label %bb24
bb23:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb25
bb24:
  %t70 = load i1, ptr %l44, !tbaa !21
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb25
bb25:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/free:walker", ptr %t72, i32 0, i32 0
  %t75 = load ptr, ptr %t74, !tbaa !29
  store ptr %t75, ptr %l46, !tbaa !29
  %t76 = load i64, ptr %l8, !tbaa !24
  store i64 %t76, ptr %l47, !tbaa !24
  %t77 = load i64, ptr @G_2ecompiler_2ffree_2eRInPlace, !tbaa !24
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t78)
  store ptr %t80, ptr %l50
  br label %bb28
bb27:
  br label %bb33
bb28:
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Body", ptr %t81, i32 0, i32 3
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l52, !tbaa !24
  %t85 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t85, ptr %l53
  %t86 = call ptr @__olang_scope_hold(ptr %v0)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l54, !tbaa !24
  %t88 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t88, label %bb29, label %bb30
bb29:
  %t90 = call ptr @__olang_region_make(ptr %v0)
  %t91 = ptrtoint ptr %t90 to i64
  store i64 %t91, ptr %l54, !tbaa !24
  br label %bb30
bb30:
  store { i64, ptr } %a4, ptr %l56, !tbaa !27
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l3
  %t97 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s4, ptr %t93, %"compiler/source:Span" %t94)
  store { i64, ptr } %t97, ptr %l59
  br label %bb31
bb31:
  %t98 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t99 = extractvalue { i64, ptr } { i64 34, ptr getelementptr inbounds (<{ i64, [34 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t100 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = add i64 %t99, %t102
  %t104 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t105 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t106 = add i64 %t103, %t105
  %t107 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 1
  %t109 = extractvalue { i64, ptr } %t107, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = load i64, ptr %l54
  %t115 = inttoptr i64 %t114 to ptr
  %t116 = call ptr @__olang_held_alloc(ptr %t115, i64 %t113)
  call void @olang_textcopy(ptr %t116, ptr %t98, i64 %t99)
  %t117 = getelementptr i8, ptr %t116, i64 %t99
  call void @olang_textcopy(ptr %t117, ptr %t101, i64 %t102)
  %t118 = getelementptr i8, ptr %t117, i64 %t102
  call void @olang_textcopy(ptr %t118, ptr %t104, i64 %t105)
  %t119 = getelementptr i8, ptr %t118, i64 %t105
  call void @olang_textcopy(ptr %t119, ptr %t108, i64 %t109)
  %t120 = getelementptr i8, ptr %t119, i64 %t109
  call void @olang_textcopy(ptr %t120, ptr %t111, i64 %t112)
  %t121 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t116, 1
  %t124 = load ptr, ptr %l46, !tbaa !29
  %t125 = load i64, ptr %l47, !tbaa !24
  %t126 = load i64, ptr %l48, !tbaa !24
  %t127 = load i64, ptr %l52, !tbaa !24
  %t128 = load %"compiler/source:Span", ptr %l53
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t124, i64 %t125, i64 %t126, i64 %t127, %"compiler/source:Span" %t128, { i64, ptr } %t122)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t133 = add i64 %t130, 1
  store i64 %t133, ptr %l6, !tbaa !24
  br label %bb7
bb35:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einUseAcross(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l29 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l43 = alloca i64
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i64
  %l58 = alloca i64
  %l65 = alloca i64
  %l68 = alloca i1
  %l72 = alloca %"compiler/source:Span"
  %l74 = alloca i1
  %l82 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l110 = alloca i64
  %l114 = alloca i1
  %l115 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i1
  %l126 = alloca i64
  %l130 = alloca i64
  %l132 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l142 = alloca i64
  %l144 = alloca i1
  %l148 = alloca i64
  %l152 = alloca i64
  %l164 = alloca i1
  %l165 = alloca i1
  %l167 = alloca i64
  %l170 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l22
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l22, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 24
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t16, i64 %t17)
  store i64 %t20, ptr %l29
  br label %bb5
bb5:
  %t21 = load i64, ptr %l29, !tbaa !24
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 25
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t24, i64 %t25)
  store i1 %t28, ptr %l33
  br label %bb6
bb6:
  %t29 = load i1, ptr %l33, !tbaa !21
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t34 = icmp sle i64 %t30, %t31
  store i1 %t34, ptr %l34, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l34, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load i64, ptr %l2, !tbaa !24
  store i64 %t37, ptr %l39, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:walker", ptr %t38, i32 0, i32 16
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t40, i64 %t41)
  store i64 %t44, ptr %l43
  br label %bb12
bb11:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb13
bb12:
  %t45 = load i64, ptr %l39, !tbaa !24
  %t46 = load i64, ptr %l43, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  store i1 %t47, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l38, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  store i64 -1, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l4, !tbaa !29
  store ptr %t51, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb17
bb17:
  %t53 = load i64, ptr %l7, !tbaa !24
  store i64 %t53, ptr %l47, !tbaa !24
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t56 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t54)
  store i64 %t56, ptr %l49
  br label %bb18
bb18:
  %t57 = load i64, ptr %l47, !tbaa !24
  %t58 = load i64, ptr %l49, !tbaa !24
  %t59 = icmp slt i64 %t57, %t58
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb19, label %bb20
bb19:
  br label %bb37
bb20:
  br label %bb21
bb21:
  %t63 = load ptr, ptr %l6, !tbaa !29
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t63, i64 %t64)
  store i64 %t67, ptr %l54
  br label %bb22
bb22:
  %t68 = load i64, ptr %l54, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/free:walker", ptr %t69, i32 0, i32 32
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l58
  br label %bb23
bb23:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l58, !tbaa !24
  %t79 = icmp sgt i64 %t77, %t76
  br i1 %t79, label %bb24, label %bb25
bb24:
  %t81 = load i64, ptr %l8, !tbaa !24
  store i64 %t81, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 32
  %t86 = load i64, ptr %l8, !tbaa !24
  %t89 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t85, i64 %t86)
  store i64 %t89, ptr %l65
  br label %bb27
bb27:
  %t90 = load i64, ptr %l2, !tbaa !24
  %t91 = load i64, ptr %l65, !tbaa !24
  %t93 = icmp eq i64 %t91, %t90
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/free:walker", ptr %t95, i32 0, i32 33
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t97, i64 %t98)
  store %"compiler/source:Span" %t101, ptr %l72
  br label %bb30
bb29:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb32
bb30:
  %t103 = load %"compiler/source:Span", ptr %l72
  %t105 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t103, %"compiler/source:Span" %a3)
  store i1 %t105, ptr %l74
  br label %bb31
bb31:
  %t106 = load i1, ptr %l74, !tbaa !21
  %t107 = xor i1 %t106, true
  store i1 %t107, ptr %l68, !tbaa !21
  br label %bb32
bb32:
  %t109 = load i1, ptr %l68, !tbaa !21
  br i1 %t109, label %bb33, label %bb34
bb33:
  %t110 = load i64, ptr %l8, !tbaa !24
  store i64 %t110, ptr %rv
  br label %ret
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = add i64 %t112, 1
  store i64 %t115, ptr %l7, !tbaa !24
  br label %bb17
bb37:
  store i64 0, ptr %l9, !tbaa !24
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 17
  %t121 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t119)
  store i64 %t121, ptr %l82
  br label %bb38
bb38:
  %t122 = load i64, ptr %l82, !tbaa !24
  store i64 %t122, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = icmp sgt i64 %t123, %t124
  br i1 %t127, label %bb39, label %bb40
bb39:
  %t129 = load i64, ptr %l11, !tbaa !24
  %t131 = icmp sgt i64 %t129, 0
  br i1 %t131, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l86, !tbaa !24
  br label %bb44
bb41:
  %t133 = load i64, ptr %l10, !tbaa !24
  %t134 = load i64, ptr %l9, !tbaa !24
  %t137 = sub i64 %t133, %t134
  %t138 = load i64, ptr %l11, !tbaa !24
  %t141 = add i64 %t137, %t138
  %t143 = sub i64 %t141, 1
  %t144 = load i64, ptr %l11, !tbaa !24
  %t147 = sdiv i64 %t143, %t144
  store i64 %t147, ptr %l89, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb43
bb43:
  %t149 = load i64, ptr %l89, !tbaa !24
  store i64 %t149, ptr %l86, !tbaa !24
  br label %bb44
bb44:
  %t150 = load i64, ptr %l86, !tbaa !24
  store i64 %t150, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t152 = load i64, ptr %l12, !tbaa !24
  %t155 = icmp slt i64 %t151, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb46, label %bb47
bb46:
  br label %bb79
bb47:
  br label %bb48
bb48:
  %t159 = load i64, ptr %l9, !tbaa !24
  %t160 = load i64, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l11, !tbaa !24
  %t164 = mul i64 %t160, %t161
  %t167 = add i64 %t159, %t164
  store i64 %t167, ptr %l14, !tbaa !24
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/free:walker", ptr %t169, i32 0, i32 17
  %t172 = load i64, ptr %l14, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l110
  br label %bb49
bb49:
  %t176 = load i64, ptr %l110, !tbaa !24
  store i64 %t176, ptr %l15, !tbaa !24
  %t177 = load i64, ptr %l15, !tbaa !24
  %t178 = load i64, ptr %l2, !tbaa !24
  %t181 = icmp slt i64 %t177, %t178
  br i1 %t181, label %bb50, label %bb51
bb50:
  %t183 = load i64, ptr %l2, !tbaa !24
  store i64 %t183, ptr %l115, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/free:walker", ptr %t184, i32 0, i32 19
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t186, i64 %t187)
  store i64 %t190, ptr %l119
  br label %bb52
bb51:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb53
bb52:
  %t191 = load i64, ptr %l115, !tbaa !24
  %t192 = load i64, ptr %l119, !tbaa !24
  %t193 = icmp sle i64 %t191, %t192
  store i1 %t193, ptr %l114, !tbaa !21
  br label %bb53
bb53:
  %t195 = load i1, ptr %l114, !tbaa !21
  %t196 = xor i1 %t195, true
  br i1 %t196, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb57
bb55:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/free:walker", ptr %t198, i32 0, i32 24
  %t201 = load i64, ptr %l1, !tbaa !24
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t200, i64 %t201)
  store i64 %t204, ptr %l126
  br label %bb56
bb56:
  %t205 = load i64, ptr %l15, !tbaa !24
  %t206 = load i64, ptr %l126, !tbaa !24
  %t208 = icmp sgt i64 %t206, %t205
  store i1 %t208, ptr %l122, !tbaa !21
  br label %bb57
bb57:
  %t210 = load i1, ptr %l122, !tbaa !21
  br i1 %t210, label %bb58, label %bb59
bb58:
  br label %bb78
bb59:
  br label %bb60
bb60:
  %t211 = load ptr, ptr %l4, !tbaa !29
  store ptr %t211, ptr %l16, !tbaa !29
  store i64 0, ptr %l17, !tbaa !24
  br label %bb61
bb61:
  %t213 = load i64, ptr %l17, !tbaa !24
  store i64 %t213, ptr %l130, !tbaa !24
  %t214 = load ptr, ptr %l16, !tbaa !29
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t214)
  store i64 %t216, ptr %l132
  br label %bb62
bb62:
  %t217 = load i64, ptr %l130, !tbaa !24
  %t218 = load i64, ptr %l132, !tbaa !24
  %t219 = icmp slt i64 %t217, %t218
  %t221 = xor i1 %t219, true
  br i1 %t221, label %bb63, label %bb64
bb63:
  br label %bb77
bb64:
  br label %bb65
bb65:
  %t223 = load ptr, ptr %l16, !tbaa !29
  %t224 = load i64, ptr %l17, !tbaa !24
  %t227 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t223, i64 %t224)
  store i64 %t227, ptr %l137
  br label %bb66
bb66:
  %t228 = load i64, ptr %l137, !tbaa !24
  store i64 %t228, ptr %l18, !tbaa !24
  %t229 = load i64, ptr %l15, !tbaa !24
  store i64 %t229, ptr %l138, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = getelementptr %"compiler/free:walker", ptr %t230, i32 0, i32 32
  %t233 = load i64, ptr %l18, !tbaa !24
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t232, i64 %t233)
  store i64 %t236, ptr %l142
  br label %bb67
bb67:
  %t237 = load i64, ptr %l138, !tbaa !24
  %t238 = load i64, ptr %l142, !tbaa !24
  %t239 = icmp slt i64 %t237, %t238
  br i1 %t239, label %bb68, label %bb69
bb68:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/free:walker", ptr %t241, i32 0, i32 32
  %t244 = load i64, ptr %l18, !tbaa !24
  %t247 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t243, i64 %t244)
  store i64 %t247, ptr %l148
  br label %bb70
bb69:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb72
bb70:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/free:walker", ptr %t248, i32 0, i32 19
  %t251 = load i64, ptr %l14, !tbaa !24
  %t254 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t250, i64 %t251)
  store i64 %t254, ptr %l152
  br label %bb71
bb71:
  %t255 = load i64, ptr %l148, !tbaa !24
  %t256 = load i64, ptr %l152, !tbaa !24
  %t257 = icmp sle i64 %t255, %t256
  store i1 %t257, ptr %l144, !tbaa !21
  br label %bb72
bb72:
  %t259 = load i1, ptr %l144, !tbaa !21
  br i1 %t259, label %bb73, label %bb74
bb73:
  %t260 = load i64, ptr %l18, !tbaa !24
  store i64 %t260, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t262 = load i64, ptr %l17, !tbaa !24
  %t265 = add i64 %t262, 1
  store i64 %t265, ptr %l17, !tbaa !24
  br label %bb61
bb77:
  br label %bb78
bb78:
  %t267 = load i64, ptr %l13, !tbaa !24
  %t270 = add i64 %t267, 1
  store i64 %t270, ptr %l13, !tbaa !24
  br label %bb45
bb79:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/free:walker", ptr %t272, i32 0, i32 34
  %t275 = load i64, ptr %l1, !tbaa !24
  %t278 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t274, i64 %t275)
  store i1 %t278, ptr %l164
  br label %bb80
bb80:
  %t279 = load i1, ptr %l164, !tbaa !21
  br i1 %t279, label %bb81, label %bb82
bb81:
  %t280 = load ptr, ptr %l4, !tbaa !29
  %t282 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t280)
  store i64 %t282, ptr %l167
  br label %bb83
bb82:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb84
bb83:
  %t283 = load i64, ptr %l167, !tbaa !24
  %t284 = icmp sgt i64 %t283, 0
  store i1 %t284, ptr %l165, !tbaa !21
  br label %bb84
bb84:
  %t286 = load i1, ptr %l165, !tbaa !21
  br i1 %t286, label %bb85, label %bb86
bb85:
  %t287 = load ptr, ptr %l4, !tbaa !29
  %t289 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t287, i64 0)
  store i64 %t289, ptr %l170
  br label %bb87
bb86:
  br label %bb88
bb87:
  %t290 = load i64, ptr %l170, !tbaa !24
  store i64 %t290, ptr %rv
  br label %ret
bb88:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstKept(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l32 = alloca ptr
  %l35 = alloca i64
  %l39 = alloca i64
  %l42 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l75 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i1
  %l88 = alloca i64
  %l92 = alloca i64
  %l95 = alloca i64
  %l116 = alloca i64
  %l119 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca ptr
  %l124 = alloca ptr
  %l128 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i1
  %l141 = alloca i64
  %l145 = alloca i64
  %l148 = alloca i64
  %l169 = alloca i64
  %l172 = alloca i1
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l177 = alloca ptr
  %l181 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i1
  %l194 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %l222 = alloca i64
  %l225 = alloca i1
  %l229 = alloca i64
  %l238 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l32
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l32, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr %"compiler/typed:LocalUses", ptr %t10, i32 0, i32 24
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t12)
  store i64 %t14, ptr %l35
  br label %bb2
bb2:
  %t15 = load i64, ptr %l35, !tbaa !24
  store i64 %t15, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  %t22 = load i64, ptr %l7, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb8
bb5:
  %t26 = load i64, ptr %l6, !tbaa !24
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l7, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l42, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l42, !tbaa !24
  store i64 %t42, ptr %l39, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l39, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l9, !tbaa !24
  %t45 = load i64, ptr %l8, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb10, label %bb11
bb10:
  br label %bb24
bb11:
  br label %bb12
bb12:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l10, !tbaa !24
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t64 = getelementptr %"compiler/typed:LocalUses", ptr %t62, i32 0, i32 24
  %t65 = load i64, ptr %l10, !tbaa !24
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t64, i64 %t65)
  store i64 %t68, ptr %l63
  br label %bb13
bb13:
  %t69 = load i64, ptr %l2, !tbaa !24
  %t70 = load i64, ptr %l63, !tbaa !24
  %t72 = icmp eq i64 %t70, %t69
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/free:Free", ptr %t74, i32 0, i32 27
  store ptr %t76, ptr %l68, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  store ptr %t77, ptr %l69, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/free:Free", ptr %t78, i32 0, i32 1
  store ptr %t80, ptr %l71, !tbaa !29
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/typed:LocalUses", ptr %t81, i32 0, i32 25
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t83, i64 %t84)
  store i64 %t87, ptr %l75
  br label %bb16
bb15:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb19
bb16:
  %t88 = load ptr, ptr %l1, !tbaa !29
  %t90 = getelementptr %"compiler/typed:LocalUses", ptr %t88, i32 0, i32 26
  %t91 = load i64, ptr %l10, !tbaa !24
  %t94 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t90, i64 %t91)
  store i64 %t94, ptr %l79
  br label %bb17
bb17:
  %t95 = load ptr, ptr %l68, !tbaa !29
  %t96 = load ptr, ptr %l69, !tbaa !29
  %t97 = load ptr, ptr %l71, !tbaa !29
  %t98 = load i64, ptr %l75, !tbaa !24
  %t99 = load i64, ptr %l79, !tbaa !24
  %t100 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v0, ptr %v0, ptr %t95, ptr %t96, ptr %t97, i64 %t98, i64 %t99, i1 false)
  store i1 %t100, ptr %l80
  br label %bb18
bb18:
  %t101 = load i1, ptr %l80, !tbaa !21
  %t102 = xor i1 %t101, true
  store i1 %t102, ptr %l66, !tbaa !21
  br label %bb19
bb19:
  %t104 = load i1, ptr %l66, !tbaa !21
  br i1 %t104, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t106 = load i64, ptr %l9, !tbaa !24
  %t109 = add i64 %t106, 1
  store i64 %t109, ptr %l9, !tbaa !24
  br label %bb9
bb24:
  store i64 0, ptr %l11, !tbaa !24
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/typed:LocalUses", ptr %t111, i32 0, i32 27
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t113)
  store i64 %t115, ptr %l88
  br label %bb25
bb25:
  %t116 = load i64, ptr %l88, !tbaa !24
  store i64 %t116, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l12, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = icmp sgt i64 %t117, %t118
  br i1 %t121, label %bb26, label %bb27
bb26:
  %t123 = load i64, ptr %l13, !tbaa !24
  %t125 = icmp sgt i64 %t123, 0
  br i1 %t125, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb31
bb28:
  %t127 = load i64, ptr %l12, !tbaa !24
  %t128 = load i64, ptr %l11, !tbaa !24
  %t131 = sub i64 %t127, %t128
  %t132 = load i64, ptr %l13, !tbaa !24
  %t135 = add i64 %t131, %t132
  %t137 = sub i64 %t135, 1
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = sdiv i64 %t137, %t138
  store i64 %t141, ptr %l95, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb30
bb30:
  %t143 = load i64, ptr %l95, !tbaa !24
  store i64 %t143, ptr %l92, !tbaa !24
  br label %bb31
bb31:
  %t144 = load i64, ptr %l92, !tbaa !24
  store i64 %t144, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb32
bb32:
  %t145 = load i64, ptr %l15, !tbaa !24
  %t146 = load i64, ptr %l14, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb33, label %bb34
bb33:
  br label %bb47
bb34:
  br label %bb35
bb35:
  %t153 = load i64, ptr %l11, !tbaa !24
  %t154 = load i64, ptr %l15, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t158 = mul i64 %t154, %t155
  %t161 = add i64 %t153, %t158
  store i64 %t161, ptr %l16, !tbaa !24
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr %"compiler/typed:LocalUses", ptr %t163, i32 0, i32 27
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t165, i64 %t166)
  store i64 %t169, ptr %l116
  br label %bb36
bb36:
  %t170 = load i64, ptr %l2, !tbaa !24
  %t171 = load i64, ptr %l116, !tbaa !24
  %t173 = icmp eq i64 %t171, %t170
  br i1 %t173, label %bb37, label %bb38
bb37:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = getelementptr %"compiler/free:Free", ptr %t175, i32 0, i32 27
  store ptr %t177, ptr %l121, !tbaa !29
  %t178 = load ptr, ptr %l4, !tbaa !29
  store ptr %t178, ptr %l122, !tbaa !29
  %t179 = load ptr, ptr %l3, !tbaa !29
  %t181 = getelementptr %"compiler/free:Free", ptr %t179, i32 0, i32 1
  store ptr %t181, ptr %l124, !tbaa !29
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr %"compiler/typed:LocalUses", ptr %t182, i32 0, i32 28
  %t185 = load i64, ptr %l16, !tbaa !24
  %t188 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t184, i64 %t185)
  store i64 %t188, ptr %l128
  br label %bb39
bb38:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb42
bb39:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t191 = getelementptr %"compiler/typed:LocalUses", ptr %t189, i32 0, i32 29
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l132
  br label %bb40
bb40:
  %t196 = load ptr, ptr %l121, !tbaa !29
  %t197 = load ptr, ptr %l122, !tbaa !29
  %t198 = load ptr, ptr %l124, !tbaa !29
  %t199 = load i64, ptr %l128, !tbaa !24
  %t200 = load i64, ptr %l132, !tbaa !24
  %t201 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v0, ptr %v0, ptr %t196, ptr %t197, ptr %t198, i64 %t199, i64 %t200, i1 false)
  store i1 %t201, ptr %l133
  br label %bb41
bb41:
  %t202 = load i1, ptr %l133, !tbaa !21
  %t203 = xor i1 %t202, true
  store i1 %t203, ptr %l119, !tbaa !21
  br label %bb42
bb42:
  %t205 = load i1, ptr %l119, !tbaa !21
  br i1 %t205, label %bb43, label %bb44
bb43:
  store i1 false, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb46
bb46:
  %t207 = load i64, ptr %l15, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l15, !tbaa !24
  br label %bb32
bb47:
  store i64 0, ptr %l17, !tbaa !24
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/typed:LocalUses", ptr %t212, i32 0, i32 45
  %t216 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t214)
  store i64 %t216, ptr %l141
  br label %bb48
bb48:
  %t217 = load i64, ptr %l141, !tbaa !24
  store i64 %t217, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t218 = load i64, ptr %l18, !tbaa !24
  %t219 = load i64, ptr %l17, !tbaa !24
  %t222 = icmp sgt i64 %t218, %t219
  br i1 %t222, label %bb49, label %bb50
bb49:
  %t224 = load i64, ptr %l19, !tbaa !24
  %t226 = icmp sgt i64 %t224, 0
  br i1 %t226, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l145, !tbaa !24
  br label %bb54
bb51:
  %t228 = load i64, ptr %l18, !tbaa !24
  %t229 = load i64, ptr %l17, !tbaa !24
  %t232 = sub i64 %t228, %t229
  %t233 = load i64, ptr %l19, !tbaa !24
  %t236 = add i64 %t232, %t233
  %t238 = sub i64 %t236, 1
  %t239 = load i64, ptr %l19, !tbaa !24
  %t242 = sdiv i64 %t238, %t239
  store i64 %t242, ptr %l148, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l148, !tbaa !24
  br label %bb53
bb53:
  %t244 = load i64, ptr %l148, !tbaa !24
  store i64 %t244, ptr %l145, !tbaa !24
  br label %bb54
bb54:
  %t245 = load i64, ptr %l145, !tbaa !24
  store i64 %t245, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb55
bb55:
  %t246 = load i64, ptr %l21, !tbaa !24
  %t247 = load i64, ptr %l20, !tbaa !24
  %t250 = icmp slt i64 %t246, %t247
  %t252 = xor i1 %t250, true
  br i1 %t252, label %bb56, label %bb57
bb56:
  br label %bb70
bb57:
  br label %bb58
bb58:
  %t254 = load i64, ptr %l17, !tbaa !24
  %t255 = load i64, ptr %l21, !tbaa !24
  %t256 = load i64, ptr %l19, !tbaa !24
  %t259 = mul i64 %t255, %t256
  %t262 = add i64 %t254, %t259
  store i64 %t262, ptr %l22, !tbaa !24
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr %"compiler/typed:LocalUses", ptr %t264, i32 0, i32 45
  %t267 = load i64, ptr %l22, !tbaa !24
  %t270 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t266, i64 %t267)
  store i64 %t270, ptr %l169
  br label %bb59
bb59:
  %t271 = load i64, ptr %l2, !tbaa !24
  %t272 = load i64, ptr %l169, !tbaa !24
  %t274 = icmp eq i64 %t272, %t271
  br i1 %t274, label %bb60, label %bb61
bb60:
  %t276 = load ptr, ptr %l3, !tbaa !29
  %t278 = getelementptr %"compiler/free:Free", ptr %t276, i32 0, i32 27
  store ptr %t278, ptr %l174, !tbaa !29
  %t279 = load ptr, ptr %l4, !tbaa !29
  store ptr %t279, ptr %l175, !tbaa !29
  %t280 = load ptr, ptr %l3, !tbaa !29
  %t282 = getelementptr %"compiler/free:Free", ptr %t280, i32 0, i32 1
  store ptr %t282, ptr %l177, !tbaa !29
  %t283 = load ptr, ptr %l1, !tbaa !29
  %t285 = getelementptr %"compiler/typed:LocalUses", ptr %t283, i32 0, i32 46
  %t286 = load i64, ptr %l22, !tbaa !24
  %t289 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t285, i64 %t286)
  store i64 %t289, ptr %l181
  br label %bb62
bb61:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb65
bb62:
  %t290 = load ptr, ptr %l1, !tbaa !29
  %t292 = getelementptr %"compiler/typed:LocalUses", ptr %t290, i32 0, i32 47
  %t293 = load i64, ptr %l22, !tbaa !24
  %t296 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t292, i64 %t293)
  store i64 %t296, ptr %l185
  br label %bb63
bb63:
  %t297 = load ptr, ptr %l174, !tbaa !29
  %t298 = load ptr, ptr %l175, !tbaa !29
  %t299 = load ptr, ptr %l177, !tbaa !29
  %t300 = load i64, ptr %l181, !tbaa !24
  %t301 = load i64, ptr %l185, !tbaa !24
  %t302 = call i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v0, ptr %v0, ptr %t297, ptr %t298, ptr %t299, i64 %t300, i64 %t301, i1 false)
  store i1 %t302, ptr %l186
  br label %bb64
bb64:
  %t303 = load i1, ptr %l186, !tbaa !21
  %t304 = xor i1 %t303, true
  store i1 %t304, ptr %l172, !tbaa !21
  br label %bb65
bb65:
  %t306 = load i1, ptr %l172, !tbaa !21
  br i1 %t306, label %bb66, label %bb67
bb66:
  store i1 false, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t308 = load i64, ptr %l21, !tbaa !24
  %t311 = add i64 %t308, 1
  store i64 %t311, ptr %l21, !tbaa !24
  br label %bb55
bb70:
  store i64 0, ptr %l23, !tbaa !24
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr %"compiler/typed:LocalUses", ptr %t313, i32 0, i32 50
  %t317 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t315)
  store i64 %t317, ptr %l194
  br label %bb71
bb71:
  %t318 = load i64, ptr %l194, !tbaa !24
  store i64 %t318, ptr %l24, !tbaa !24
  store i64 1, ptr %l25, !tbaa !24
  %t319 = load i64, ptr %l24, !tbaa !24
  %t320 = load i64, ptr %l23, !tbaa !24
  %t323 = icmp sgt i64 %t319, %t320
  br i1 %t323, label %bb72, label %bb73
bb72:
  %t325 = load i64, ptr %l25, !tbaa !24
  %t327 = icmp sgt i64 %t325, 0
  br i1 %t327, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb77
bb74:
  %t329 = load i64, ptr %l24, !tbaa !24
  %t330 = load i64, ptr %l23, !tbaa !24
  %t333 = sub i64 %t329, %t330
  %t334 = load i64, ptr %l25, !tbaa !24
  %t337 = add i64 %t333, %t334
  %t339 = sub i64 %t337, 1
  %t340 = load i64, ptr %l25, !tbaa !24
  %t343 = sdiv i64 %t339, %t340
  store i64 %t343, ptr %l201, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb76
bb76:
  %t345 = load i64, ptr %l201, !tbaa !24
  store i64 %t345, ptr %l198, !tbaa !24
  br label %bb77
bb77:
  %t346 = load i64, ptr %l198, !tbaa !24
  store i64 %t346, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb78
bb78:
  %t347 = load i64, ptr %l27, !tbaa !24
  %t348 = load i64, ptr %l26, !tbaa !24
  %t351 = icmp slt i64 %t347, %t348
  %t353 = xor i1 %t351, true
  br i1 %t353, label %bb79, label %bb80
bb79:
  br label %bb91
bb80:
  br label %bb81
bb81:
  %t355 = load i64, ptr %l23, !tbaa !24
  %t356 = load i64, ptr %l27, !tbaa !24
  %t357 = load i64, ptr %l25, !tbaa !24
  %t360 = mul i64 %t356, %t357
  %t363 = add i64 %t355, %t360
  store i64 %t363, ptr %l28, !tbaa !24
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t367 = getelementptr %"compiler/typed:LocalUses", ptr %t365, i32 0, i32 50
  %t368 = load i64, ptr %l28, !tbaa !24
  %t371 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t367, i64 %t368)
  store i64 %t371, ptr %l222
  br label %bb82
bb82:
  %t372 = load i64, ptr %l2, !tbaa !24
  %t373 = load i64, ptr %l222, !tbaa !24
  %t375 = icmp eq i64 %t373, %t372
  br i1 %t375, label %bb83, label %bb84
bb83:
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr %"compiler/typed:LocalUses", ptr %t377, i32 0, i32 49
  %t380 = load i64, ptr %l28, !tbaa !24
  %t383 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t379, i64 %t380)
  store i64 %t383, ptr %l229
  br label %bb85
bb84:
  store i1 false, ptr %l225, !tbaa !21
  br label %bb86
bb85:
  %t384 = load i64, ptr %l229, !tbaa !24
  %t385 = icmp slt i64 %t384, 0
  store i1 %t385, ptr %l225, !tbaa !21
  br label %bb86
bb86:
  %t387 = load i1, ptr %l225, !tbaa !21
  br i1 %t387, label %bb87, label %bb88
bb87:
  store i1 false, ptr %rv
  br label %ret
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t389 = load i64, ptr %l27, !tbaa !24
  %t392 = add i64 %t389, 1
  store i64 %t392, ptr %l27, !tbaa !24
  br label %bb78
bb91:
  %t394 = load ptr, ptr %l1, !tbaa !29
  %t396 = getelementptr %"compiler/typed:LocalUses", ptr %t394, i32 0, i32 10
  %t397 = load i64, ptr %l2, !tbaa !24
  %t400 = call i1 @compiler_2ffree_2ehas(ptr %v1, ptr %t396, i64 %t397)
  store i1 %t400, ptr %l238
  br label %bb92
bb92:
  %t401 = load i1, ptr %l238, !tbaa !21
  %t402 = xor i1 %t401, true
  store i1 %t402, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstRoots(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/typed:LocalUses"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l14 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l24 = alloca i64
  %l26 = alloca i1
  %l29 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca %"compiler/typed:LocalUses"
  %l37 = alloca i64
  %l38 = alloca i64
  %l42 = alloca i64
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i64
  %l59 = alloca i64
  %l63 = alloca i64
  %l65 = alloca i64
  %l68 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca i64
  %l78 = alloca i1
  %l80 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i32
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l95 = alloca i32
  %l96 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca i64
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t22 = alloca i64
  %t56 = alloca %"compiler/typed:LocalUses", align 8
  %t71 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l14
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l14, !tbaa !29
  %t6 = getelementptr %"compiler/typed:Body", ptr %t4, i32 0, i32 7
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l17
  br label %bb2
bb2:
  %t9 = load i64, ptr %l17, !tbaa !24
  store i64 %t9, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  store i64 %t10, ptr %l18, !tbaa !24
  %t11 = load i64, ptr @G_2ecompiler_2ffree_2eInstNone, !tbaa !24
  store i64 %t11, ptr %l19, !tbaa !24
  %t12 = load i64, ptr %l18, !tbaa !24
  %t13 = icmp sge i64 %t12, 0
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l18, !tbaa !24
  %t16 = icmp sle i64 %t15, 1152921504606846975
  br i1 %t16, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_89e3eb0f8d54068a_873e152f561fcee)
  unreachable
bb5:
  %t18 = load i64, ptr %l18, !tbaa !24
  %t19 = mul i64 %t18, 8
  %t20 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t19)
  %t21 = load i64, ptr %l19, !tbaa !24
  store i64 0, ptr %t22
  br label %fill.23
fill.23:
  %t26 = load i64, ptr %t22
  %t27 = icmp slt i64 %t26, %t18
  br i1 %t27, label %fillb.24, label %filld.25
fillb.24:
  %t28 = getelementptr i64, ptr %t20, i64 %t26
  store i64 %t21, ptr %t28
  %t29 = add i64 %t26, 1
  store i64 %t29, ptr %t22
  br label %fill.23
filld.25:
  %t30 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t20, 1
  store { i64, ptr } %t31, ptr %l4, !tbaa !27
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t33)
  store i64 %t35, ptr %l24
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_89e3eb0f8d54068a_873e152f561fcee)
  unreachable
bb7:
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb11
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 71
  %t43 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t41)
  store i64 %t43, ptr %l29
  br label %bb10
bb10:
  %t44 = load i64, ptr %l29, !tbaa !24
  %t45 = icmp eq i64 %t44, 0
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l26, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t50)
  store ptr %t52, ptr %l33
  br label %bb15
bb15:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t53)
  store ptr %t55, ptr %l35
  br label %bb16
bb16:
  %t57 = load ptr, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l35, !tbaa !29
  call void @compiler_2ftyped_2eLocalUses_2eUses(ptr %t56, ptr %v0, ptr %v0, ptr %s0, ptr %t57, ptr %t58)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t56, i64 1640, i1 false)
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l36, i64 1640, i1 false)
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l37, !tbaa !24
  %t60 = load i64, ptr @G_2ecompiler_2ffree_2eInstAsk, !tbaa !24
  store i64 %t60, ptr %l38, !tbaa !24
  %t61 = load i64, ptr %l37, !tbaa !24
  %t62 = icmp sge i64 %t61, 0
  br i1 %t62, label %bb18, label %bb19
bb18:
  %t64 = load i64, ptr %l37, !tbaa !24
  %t65 = icmp sle i64 %t64, 1152921504606846975
  br i1 %t65, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_ecba82c0cda3145f_2530efc2d93afc63)
  unreachable
bb20:
  %t67 = load i64, ptr %l37, !tbaa !24
  %t68 = mul i64 %t67, 8
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  %t70 = load i64, ptr %l38, !tbaa !24
  store i64 0, ptr %t71
  br label %fill.72
fill.72:
  %t75 = load i64, ptr %t71
  %t76 = icmp slt i64 %t75, %t67
  br i1 %t76, label %fillb.73, label %filld.74
fillb.73:
  %t77 = getelementptr i64, ptr %t69, i64 %t75
  store i64 %t70, ptr %t77
  %t78 = add i64 %t75, 1
  store i64 %t78, ptr %t71
  br label %fill.72
filld.74:
  %t79 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t69, 1
  store { i64, ptr } %t80, ptr %l6, !tbaa !27
  %t82 = call ptr @__olang_scope_hold(ptr %s0)
  %t83 = ptrtoint ptr %t82 to i64
  store i64 %t83, ptr %l42, !tbaa !24
  %t84 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2einstRoots_2elocal_2e7
  br i1 %t84, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_ecba82c0cda3145f_2530efc2d93afc63)
  unreachable
bb22:
  %t86 = call ptr @__olang_region_make(ptr %s0)
  %t87 = ptrtoint ptr %t86 to i64
  store i64 %t87, ptr %l42, !tbaa !24
  br label %bb23
bb23:
  %t88 = load i64, ptr %l42
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %t89, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l44
  br label %bb24
bb24:
  %t91 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2einstRoots_2elocal_2e7
  br i1 %t91, label %bb25, label %bb26
bb25:
  %t93 = load i64, ptr %l42
  %t94 = inttoptr i64 %t93 to ptr
  %t95 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44, i32 0, i32 0
  %t96 = load { i64, ptr }, ptr %t95
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = call ptr @__olang_region_or(ptr %t97, ptr null)
  %t99 = call ptr @__olang_region_home(ptr %t98)
  %t100 = icmp ne ptr %t99, null
  %t101 = select i1 %t100, ptr %t99, ptr null
  call void @__olang_region_settle_in(ptr %t94, ptr %t101)
  br label %bb26
bb26:
  %t102 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %l7
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb27
bb27:
  %t105 = load i64, ptr %l9, !tbaa !24
  store i64 %t105, ptr %l47, !tbaa !24
  %t106 = load ptr, ptr %l8, !tbaa !29
  %t108 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t106)
  store i64 %t108, ptr %l49
  br label %bb28
bb28:
  %t109 = load i64, ptr %l47, !tbaa !24
  %t110 = load i64, ptr %l49, !tbaa !24
  %t111 = icmp slt i64 %t109, %t110
  %t113 = xor i1 %t111, true
  br i1 %t113, label %bb29, label %bb30
bb29:
  br label %bb75
bb30:
  br label %bb31
bb31:
  %t115 = load ptr, ptr %l8, !tbaa !29
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t115, i64 %t116)
  store i64 %t119, ptr %l54
  br label %bb32
bb32:
  %t120 = load i64, ptr %l54, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t123 = load i64, ptr %l10, !tbaa !24
  %t128 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstOf(ptr %v0, ptr %s0, ptr %s0, ptr %t121, ptr %l5, { i64, ptr } %t122, i64 %t123, i64 0)
  store i64 %t128, ptr %l59
  br label %bb33
bb33:
  %t129 = load i64, ptr %l59, !tbaa !24
  store i64 %t129, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t132 = icmp slt i64 %t130, 0
  br i1 %t132, label %bb34, label %bb35
bb34:
  br label %bb74
bb35:
  br label %bb36
bb36:
  %t135 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eLen_H327daf8a5f05e7deba4c08807621a9fe(ptr %s0, ptr %l7)
  store i64 %t135, ptr %l63
  br label %bb37
bb37:
  %t136 = load i64, ptr %l63, !tbaa !24
  %t137 = icmp eq i64 %t136, 0
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t139 = call ptr @__olang_scope_hold(ptr %s0)
  %t140 = ptrtoint ptr %t139 to i64
  store i64 %t140, ptr %l65, !tbaa !24
  %t141 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2einstRoots_2elocal_2e7
  br i1 %t141, label %bb40, label %bb41
bb39:
  br label %bb54
bb40:
  %t143 = call ptr @__olang_region_make(ptr %s0)
  %t144 = ptrtoint ptr %t143 to i64
  store i64 %t144, ptr %l65, !tbaa !24
  br label %bb41
bb41:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l65
  %t147 = inttoptr i64 %t146 to ptr
  %t149 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstGiven(ptr %v0, ptr %t147, ptr %t145)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t149, ptr %l68
  br label %bb42
bb42:
  %t150 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2einstRoots_2elocal_2e7
  br i1 %t150, label %bb43, label %bb44
bb43:
  %t152 = load i64, ptr %l65
  %t153 = inttoptr i64 %t152 to ptr
  %t154 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68, i32 0, i32 0
  %t155 = load { i64, ptr }, ptr %t154
  %t156 = extractvalue { i64, ptr } %t155, 1
  %t157 = call ptr @__olang_region_or(ptr %t156, ptr null)
  %t158 = call ptr @__olang_region_home(ptr %t157)
  %t159 = icmp ne ptr %t158, null
  %t160 = select i1 %t159, ptr %t158, ptr null
  call void @__olang_region_settle_in(ptr %t153, ptr %t160)
  br label %bb44
bb44:
  %t161 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l70
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l68
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %l7
  %t163 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2einstRoots_2elocal_2e7
  br i1 %t163, label %bb45, label %bb46
bb45:
  %t165 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = call ptr @__olang_region_or(ptr %t167, ptr null)
  %t169 = call ptr @__olang_region_home(ptr %t168)
  %t170 = icmp ne ptr %t169, null
  %t171 = select i1 %t170, ptr %t169, ptr null
  call void @__olang_region_drop(ptr %t171)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l70
  br label %bb46
bb46:
  %t172 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1
  br i1 %t172, label %bb47, label %bb48
bb47:
  store i64 0, ptr %l73, !tbaa !24
  br label %bb49
bb48:
  %t174 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2e0
  br i1 %t174, label %bb52, label %bb53
bb49:
  %t176 = load i64, ptr %l73, !tbaa !24
  %t177 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70, i32 0, i32 1
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = icmp slt i64 %t176, %t178
  br i1 %t179, label %bb50, label %bb51
bb50:
  %t181 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70, i32 0, i32 0
  %t182 = load i64, ptr %l73, !tbaa !24
  %t183 = getelementptr { i64, ptr }, ptr %t181, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr { i64, ptr }, ptr %t184, i64 %t182
  %t186 = load { i64, ptr }, ptr %t185
  %t187 = extractvalue { i64, ptr } %t186, 1
  call void @__olang_slot_release(ptr %t187)
  store { i64, ptr } zeroinitializer, ptr %t185
  %t188 = load i64, ptr %l73, !tbaa !24
  %t189 = add i64 %t188, 1
  store i64 %t189, ptr %l73, !tbaa !24
  br label %bb49
bb51:
  br label %bb48
bb52:
  %t190 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l70, i32 0, i32 0
  %t191 = load { i64, ptr }, ptr %t190
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  call void @__olang_region_release_part(ptr %t193, i64 %t192)
  store { i64, ptr } zeroinitializer, ptr %t190
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t195 = load i64, ptr %l11, !tbaa !24
  %t198 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_Hf6e62a5a68166ed9aaf0549ae9176a35(ptr %v2, ptr %t194, i64 %t195)
  store i1 %t198, ptr %l78
  br label %bb55
bb55:
  %t199 = load i1, ptr %l78, !tbaa !21
  %t200 = xor i1 %t199, true
  br i1 %t200, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s6
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l11, !tbaa !24
  %t208 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstNames(ptr %v0, ptr %s0, ptr %s0, ptr %s6, ptr %t202, ptr %l5, i64 %t203, ptr %l7)
  %t209 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t208, 1
  %t210 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t208, 0
  store i32 %t210, ptr %l86
  %t211 = icmp ne i32 %t210, 0
  br i1 %t211, label %bb59, label %ok.212, !prof !99
ok.212:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l85
  br label %bb58
bb57:
  br label %bb64
bb58:
  %t213 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %l80
  br label %bb62
bb59:
  br label %bb60
bb60:
  %t214 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t214, ptr %l87
  br label %bb61
bb61:
  %t215 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t215, ptr %l80
  br label %bb62
bb62:
  %t216 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l80
  %t217 = load ptr, ptr %l2, !tbaa !29
  %t218 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H3dfb9bb75f225052e7117bc23a678a05(ptr %v2, ptr %s6, ptr %t217, i64 %t218, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s6)
  br label %bb64
bb64:
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t224 = load i64, ptr %l11, !tbaa !24
  %t227 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H70e429947547277d4792686f6c52db1a(ptr %v2, ptr %v2, ptr %t223, i64 %t224)
  %t228 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t227, 1
  %t229 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t227, 0
  store i32 %t229, ptr %l95
  %t230 = icmp ne i32 %t229, 0
  br i1 %t230, label %bb66, label %ok.231, !prof !99
ok.231:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %l94
  br label %bb65
bb65:
  %t232 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t232, ptr %l91
  br label %bb69
bb66:
  br label %bb67
bb67:
  %t233 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t233, ptr %l96
  br label %bb68
bb68:
  %t234 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t234, ptr %l91
  br label %bb69
bb69:
  %t236 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eLen_H327daf8a5f05e7deba4c08807621a9fe(ptr %v2, ptr %l91)
  store i64 %t236, ptr %l98
  br label %bb70
bb70:
  %t237 = load i64, ptr %l98, !tbaa !24
  %t238 = icmp sgt i64 %t237, 0
  br i1 %t238, label %bb71, label %bb72
bb71:
  %t240 = load i64, ptr %l10, !tbaa !24
  %t241 = load i64, ptr %l11, !tbaa !24
  %t244 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr i64, ptr %t245, i64 %t240
  store i64 %t241, ptr %t246, !tbaa !34
  br label %bb73
bb72:
  br label %bb73
bb73:
  br label %bb74
bb74:
  %t247 = load i64, ptr %l9, !tbaa !24
  %t250 = add i64 %t247, 1
  store i64 %t250, ptr %l9, !tbaa !24
  br label %bb27
bb75:
  %t252 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t252, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2elambdaMade(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l7 = alloca ptr
  %l10 = alloca i64
  %l16 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/free:Free", ptr %t4, i32 0, i32 117
  %t7 = load i32, ptr %l1, !tbaa !23
  %t9 = sext i32 %t7 to i64
  %t12 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t6, i64 %t9)
  store ptr %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t19 = call i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %t17, i64 %t16)
  store i64 %t19, ptr %l10
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/free:walker", ptr %t20, i32 0, i32 0
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 93
  %t26 = load i32, ptr %l1, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t25, i64 %t28)
  store i1 %t31, ptr %l16
  br label %bb3
bb3:
  %t32 = load i1, ptr %l16, !tbaa !21
  br i1 %t32, label %bb4, label %bb5
bb4:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/free:walker", ptr %t33, i32 0, i32 0
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t36, i64 %t40)
  br label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eplainCtor(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca i64
  %l19 = alloca i64
  %l21 = alloca i1
  %l25 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca i64
  %l60 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca i1
  %l75 = alloca i1
  %l78 = alloca ptr
  %l83 = alloca %"compiler/typed:Local"
  %l85 = alloca i1
  %l86 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca i64
  %l92 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t8 = icmp slt i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb4
bb2:
  %t10 = load i64, ptr %l1, !tbaa !24
  store i64 %t10, ptr %l16, !tbaa !24
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t13 = getelementptr %"compiler/free:Free", ptr %t11, i32 0, i32 1
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l19
  br label %bb3
bb3:
  %t16 = load i64, ptr %l16, !tbaa !24
  %t17 = load i64, ptr %l19, !tbaa !24
  %t18 = icmp sge i64 %t16, %t17
  store i1 %t18, ptr %l15, !tbaa !21
  br label %bb4
bb4:
  %t20 = load i1, ptr %l15, !tbaa !21
  br i1 %t20, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb8
bb6:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/free:Free", ptr %t21, i32 0, i32 1
  %t24 = load i64, ptr %l1, !tbaa !24
  %t27 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t24)
  store ptr %t27, ptr %l25
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l25, !tbaa !29
  %t30 = getelementptr %"compiler/typed:Body", ptr %t28, i32 0, i32 11
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  store i1 %t33, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l21, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/free:Free", ptr %t37, i32 0, i32 1
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t39, i64 %t40)
  store ptr %t43, ptr %l33
  br label %bb12
bb12:
  %t44 = load ptr, ptr %l33, !tbaa !29
  store ptr %t44, ptr %l3, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t45)
  store ptr %t47, ptr %l35
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l3, !tbaa !29
  %t50 = getelementptr %"compiler/typed:Body", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %t50, !tbaa !23
  %t52 = load ptr, ptr %l35, !tbaa !29
  %t54 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %t52, i32 %t51)
  store i64 %t54, ptr %l38
  br label %bb14
bb14:
  %t55 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleCtor, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  %t58 = icmp ne i64 %t56, %t55
  br i1 %t58, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr %"compiler/typed:Body", ptr %t61, i32 0, i32 1
  %t64 = load { i64, [2 x i64] }, ptr %t63
  %t68 = extractvalue { i64, [2 x i64] } %t64, 0
  %t69 = icmp eq i64 %t68, 1
  br i1 %t69, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  store i1 false, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2e913fd7c6d2d6ac_b85e5f87b55bb900)
  unreachable
bb26:
  %t72 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/typed:Body", ptr %t72, i32 0, i32 11
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = icmp eq ptr %t75, null
  br i1 %t77, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_b635439c476fea4e_d136026e66bf3e2)
  unreachable
bb28:
  br label %bb29
bb29:
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Body", ptr %t79, i32 0, i32 11
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Block", ptr %t82, i32 0, i32 1
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  store { i64, ptr } %t86, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t88 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t90 = extractvalue { i64, ptr } %t88, 0
  store i64 %t90, ptr %l7, !tbaa !24
  br label %bb30
bb30:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l7, !tbaa !24
  %t96 = icmp slt i64 %t92, %t93
  %t98 = xor i1 %t96, true
  br i1 %t98, label %bb31, label %bb32
bb31:
  br label %bb61
bb32:
  br label %bb33
bb33:
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t100, ptr %l60, !tbaa !27
  %t101 = load i64, ptr %l6, !tbaa !24
  %t103 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr ptr, ptr %t104, i64 %t101
  %t106 = load ptr, ptr %t105, !tbaa !39
  store ptr %t106, ptr %l8, !tbaa !29
  %t108 = load ptr, ptr %l8, !tbaa !29
  store ptr %t108, ptr %l63, !tbaa !29
  store i1 false, ptr %l64, !tbaa !21
  %t109 = load ptr, ptr %l63, !tbaa !29
  %t110 = icmp ne ptr %t109, null
  br i1 %t110, label %bb34, label %bb35
bb34:
  %t112 = load ptr, ptr %l63, !tbaa !29
  %t113 = load i64, ptr %t112, !range !{i64 0, i64 17}
  %t115 = icmp eq i64 %t113, 0
  store i1 %t115, ptr %l64, !tbaa !21
  br label %bb35
bb35:
  %t116 = load i1, ptr %l64, !tbaa !21
  br i1 %t116, label %bb36, label %bb37
bb36:
  %t117 = load ptr, ptr %l8, !tbaa !29
  %t119 = getelementptr { i64, [3 x i64] }, ptr %t117, i32 0, i32 1
  %t120 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t119, i32 0, i32 1
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l9, !tbaa !23
  %t123 = load ptr, ptr %l8, !tbaa !29
  %t125 = getelementptr { i64, [3 x i64] }, ptr %t123, i32 0, i32 1
  %t126 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t125, i32 0, i32 2
  %t127 = load ptr, ptr %t126
  store ptr %t127, ptr %l10, !tbaa !29
  br label %bb38
bb37:
  br label %bb54
bb38:
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/typed:Body", ptr %t129, i32 0, i32 10
  %t132 = load i32, ptr %l9, !tbaa !23
  %t134 = sext i32 %t132 to i64
  %t137 = call i1 @compiler_2ffree_2ehasLocal(ptr %v0, ptr %t131, i64 %t134)
  store i1 %t137, ptr %l75
  br label %bb39
bb39:
  %t138 = load i1, ptr %l75, !tbaa !21
  %t139 = xor i1 %t138, true
  br i1 %t139, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t142 = load ptr, ptr %l2, !tbaa !29
  store ptr %t142, ptr %l78, !tbaa !29
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr %"compiler/typed:Body", ptr %t143, i32 0, i32 7
  %t146 = load i32, ptr %l9, !tbaa !23
  %t148 = sext i32 %t146 to i64
  %t151 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t145, i64 %t148)
  store %"compiler/typed:Local" %t151, ptr %l83
  br label %bb43
bb43:
  %t152 = getelementptr %"compiler/typed:Local", ptr %l83, i32 0, i32 2
  %t153 = load i32, ptr %t152, !tbaa !23
  %t154 = load ptr, ptr %l78, !tbaa !29
  %t156 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefsBeyondParts(ptr %v0, ptr %t154, i32 %t153)
  store i1 %t156, ptr %l85
  br label %bb44
bb44:
  %t157 = load i1, ptr %l85, !tbaa !21
  br i1 %t157, label %bb45, label %bb46
bb45:
  %t158 = load ptr, ptr %l3, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Body", ptr %t158, i32 0, i32 5
  store ptr %t160, ptr %l88, !tbaa !29
  %t161 = load ptr, ptr %l10, !tbaa !29
  %t163 = call ptr @compiler_2ffree_2eunaway(ptr %v0, ptr %v0, ptr %t161)
  store ptr %t163, ptr %l90
  br label %bb47
bb46:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb50
bb47:
  %t164 = load ptr, ptr %l90, !tbaa !29
  %t165 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %t164)
  store i64 %t165, ptr %l91
  br label %bb48
bb48:
  %t166 = load ptr, ptr %l88, !tbaa !29
  %t167 = load i64, ptr %l91, !tbaa !24
  %t168 = call i1 @compiler_2ffree_2ehasLocal(ptr %v0, ptr %t166, i64 %t167)
  store i1 %t168, ptr %l92
  br label %bb49
bb49:
  %t169 = load i1, ptr %l92, !tbaa !21
  %t170 = xor i1 %t169, true
  store i1 %t170, ptr %l86, !tbaa !21
  br label %bb50
bb50:
  %t172 = load i1, ptr %l86, !tbaa !21
  br i1 %t172, label %bb51, label %bb52
bb51:
  store i1 false, ptr %rv
  br label %ret
bb52:
  br label %bb53
bb53:
  br label %bb59
bb54:
  br i1 true, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb58
bb57:
  store i1 false, ptr %rv
  br label %ret
bb58:
  call void @__olang_check_failed(ptr @olang_loc_7de1741991f26e46_8ca4854755ab7fa)
  unreachable
bb59:
  br label %bb60
bb60:
  %t175 = load i64, ptr %l6, !tbaa !24
  %t178 = add i64 %t175, 1
  store i64 %t178, ptr %l6, !tbaa !24
  br label %bb30
bb61:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2epromoteOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca i32
  %l25 = alloca ptr
  %l27 = alloca i32
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca i1
  %l37 = alloca i64
  %l39 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i64
  %l50 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %l55 = alloca ptr
  %l57 = alloca i64
  %l60 = alloca %"compiler/source:Span"
  %l61 = alloca i64
  %l63 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca i64
  %l83 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l94 = alloca %"compiler/typed:Plan"
  %l95 = alloca { i64, ptr }
  %l100 = alloca i1
  %s5 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %t188 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load i32, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t7 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t5, i32 %t4)
  store i1 %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load i1, ptr %l11, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t9)
  store ptr %t11, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb9
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t12)
  store ptr %t14, ptr %l16
  br label %bb6
bb6:
  %t15 = load i32, ptr %l1, !tbaa !23
  %t16 = load ptr, ptr %l16, !tbaa !29
  %t18 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t16, i32 %t15)
  store i32 %t18, ptr %l18
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l14, !tbaa !29
  %t20 = load i32, ptr %l18, !tbaa !23
  %t21 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t19, i32 %t20)
  store i1 %t21, ptr %l19
  br label %bb8
bb8:
  %t22 = load i1, ptr %l19, !tbaa !21
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %l3, !tbaa !21
  %t24 = load i1, ptr %l3, !tbaa !21
  br i1 %t24, label %bb10, label %bb11
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l21, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Promote", ptr %t27, i32 0, i32 1
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l23, !tbaa !23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t31)
  store ptr %t33, ptr %l25
  br label %bb12
bb11:
  br label %bb15
bb12:
  %t34 = load i32, ptr %l1, !tbaa !23
  %t35 = load ptr, ptr %l25, !tbaa !29
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t35, i32 %t34)
  store i32 %t37, ptr %l27
  br label %bb13
bb13:
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = load i32, ptr %l23, !tbaa !23
  %t40 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eregisteredAt(ptr %v0, ptr %t38, i32 %t39, i32 %t40)
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/typed:Promote", ptr %t42, i32 0, i32 0
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t48 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t41, ptr %t45)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t48, ptr %l31
  br label %bb16
bb16:
  %t49 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l4
  %t50 = load i1, ptr %l3, !tbaa !21
  br i1 %t50, label %bb17, label %bb18
bb17:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/free:walker", ptr %t52, i32 0, i32 2
  %t55 = load i1, ptr %t54, !tbaa !21
  store i1 %t55, ptr %l33, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l33, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  store ptr %l4, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb22
bb21:
  br label %bb42
bb22:
  %t59 = load i64, ptr %l6, !tbaa !24
  store i64 %t59, ptr %l37, !tbaa !24
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t62 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v2, ptr %t60)
  store i64 %t62, ptr %l39
  br label %bb23
bb23:
  %t63 = load i64, ptr %l37, !tbaa !24
  %t64 = load i64, ptr %l39, !tbaa !24
  %t65 = icmp slt i64 %t63, %t64
  %t67 = xor i1 %t65, true
  br i1 %t67, label %bb24, label %bb25
bb24:
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t70 = load i64, ptr %l6, !tbaa !24
  %t73 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v2, ptr %t69, i64 %t70)
  store i64 %t73, ptr %l44
  br label %bb27
bb27:
  %t74 = load i64, ptr %l44, !tbaa !24
  store i64 %t74, ptr %l7, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t77 = call i64 @compiler_2ffree_2eokind(i64 %t75)
  store i64 %t77, ptr %l46
  br label %bb28
bb28:
  %t78 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t79 = load i64, ptr %l46, !tbaa !24
  %t81 = icmp eq i64 %t79, %t78
  br i1 %t81, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s5
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/free:walker", ptr %t83, i32 0, i32 0
  %t86 = load ptr, ptr %t85, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = call i64 @compiler_2ffree_2eoval(i64 %t87)
  store i64 %t89, ptr %l52
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t90 = load i64, ptr @G_2ecompiler_2ffree_2eRMade, !tbaa !24
  store i64 %t90, ptr %l53, !tbaa !24
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t91)
  store ptr %t93, ptr %l55
  br label %bb32
bb32:
  %t94 = load ptr, ptr %l55, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Body", ptr %t94, i32 0, i32 3
  %t97 = load i64, ptr %t96, !tbaa !24
  store i64 %t97, ptr %l57, !tbaa !24
  %t98 = load ptr, ptr %l2, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Promote", ptr %t98, i32 0, i32 0
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t101)
  store %"compiler/source:Span" %t103, ptr %l60
  br label %bb33
bb33:
  %t104 = call ptr @__olang_scope_hold(ptr %v0)
  %t105 = ptrtoint ptr %t104 to i64
  store i64 %t105, ptr %l61, !tbaa !24
  %t106 = load i1, ptr @olang_2esole_2ecompiler_2ffree_3areason_2e3
  br i1 %t106, label %bb34, label %bb35
bb34:
  %t108 = call ptr @__olang_region_make(ptr %v0)
  %t109 = ptrtoint ptr %t108 to i64
  store i64 %t109, ptr %l61, !tbaa !24
  br label %bb35
bb35:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l63, !tbaa !29
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t113 = getelementptr %"compiler/typed:Promote", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t114)
  store %"compiler/source:Span" %t116, ptr %l66
  br label %bb36
bb36:
  %t117 = load ptr, ptr %l63, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l66
  %t119 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %s5, ptr %t117, %"compiler/source:Span" %t118)
  store { i64, ptr } %t119, ptr %l67
  br label %bb37
bb37:
  %t120 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 88, ptr getelementptr inbounds (<{ i64, [88 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t122 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = add i64 %t121, %t124
  %t126 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t127 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t128 = add i64 %t125, %t127
  %t129 = load i64, ptr %l61
  %t130 = inttoptr i64 %t129 to ptr
  %t131 = call ptr @__olang_held_alloc(ptr %t130, i64 %t128)
  call void @olang_textcopy(ptr %t131, ptr %t120, i64 %t121)
  %t132 = getelementptr i8, ptr %t131, i64 %t121
  call void @olang_textcopy(ptr %t132, ptr %t123, i64 %t124)
  %t133 = getelementptr i8, ptr %t132, i64 %t124
  call void @olang_textcopy(ptr %t133, ptr %t126, i64 %t127)
  %t134 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t131, 1
  %t137 = load ptr, ptr %l50, !tbaa !29
  %t138 = load i64, ptr %l52, !tbaa !24
  %t139 = load i64, ptr %l53, !tbaa !24
  %t140 = load i64, ptr %l57, !tbaa !24
  %t141 = load %"compiler/source:Span", ptr %l60
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v0, ptr %t137, i64 %t138, i64 %t139, i64 %t140, %"compiler/source:Span" %t141, { i64, ptr } %t135)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t143 = load i64, ptr %l6, !tbaa !24
  %t146 = add i64 %t143, 1
  store i64 %t146, ptr %l6, !tbaa !24
  br label %bb22
bb41:
  br label %bb42
bb42:
  store ptr %l4, ptr %l73, !tbaa !29
  %t148 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = getelementptr %"compiler/typed:Promote", ptr %t149, i32 0, i32 1
  %t152 = load i32, ptr %t151, !tbaa !23
  %t154 = sext i32 %t152 to i64
  %t157 = call i64 @compiler_2ffree_2eorig(i64 %t148, i64 %t154)
  store i64 %t157, ptr %l78
  br label %bb43
bb43:
  %t158 = load ptr, ptr %l73, !tbaa !29
  %t159 = load i64, ptr %l78, !tbaa !24
  %t160 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t158, i64 %t159)
  store i64 %t160, ptr %l79
  br label %bb44
bb44:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/free:walker", ptr %t161, i32 0, i32 2
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb45, label %bb46
bb45:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t170 = getelementptr %"compiler/free:walker", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t172 = load i32, ptr %l1, !tbaa !23
  %t175 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %t171, i32 %t172)
  store i1 %t175, ptr %l87
  br label %bb47
bb46:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb48
bb47:
  %t176 = load i1, ptr %l87, !tbaa !21
  store i1 %t176, ptr %l83, !tbaa !21
  br label %bb48
bb48:
  %t177 = load i1, ptr %l83, !tbaa !21
  br i1 %t177, label %bb49, label %bb50
bb49:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/free:walker", ptr %t178, i32 0, i32 0
  %t181 = load ptr, ptr %t180, !tbaa !29
  %t183 = getelementptr %"compiler/free:Free", ptr %t181, i32 0, i32 3
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/free:walker", ptr %t184, i32 0, i32 1
  %t187 = load i64, ptr %t186, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t188, ptr %v0, ptr %v0, ptr %t183, i64 %t187)
  call void @llvm.memmove.p0.p0.i64(ptr %l94, ptr %t188, i64 584, i1 false)
  br label %bb51
bb50:
  store i1 false, ptr %l88, !tbaa !21
  br label %bb53
bb51:
  %t191 = getelementptr %"compiler/typed:Plan", ptr %l94, i32 0, i32 0
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  store { i64, ptr } %t192, ptr %l95, !tbaa !27
  %t193 = load ptr, ptr %l2, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Promote", ptr %t193, i32 0, i32 1
  %t196 = load i32, ptr %t195, !tbaa !23
  %t198 = sext i32 %t196 to i64
  %t200 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = getelementptr { i64, [2 x i64] }, ptr %t201, i64 %t198
  %t203 = load { i64, [2 x i64] }, ptr %t202
  %t205 = call i1 @compiler_2ffree_2eisVar({ i64, [2 x i64] } %t203)
  store i1 %t205, ptr %l100
  br label %bb52
bb52:
  %t206 = load i1, ptr %l100, !tbaa !21
  store i1 %t206, ptr %l88, !tbaa !21
  br label %bb53
bb53:
  %t207 = load i1, ptr %l88, !tbaa !21
  br i1 %t207, label %bb54, label %bb55
bb54:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:walker", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/free:walker", ptr %t212, i32 0, i32 1
  %t215 = load i64, ptr %t214, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %t211, i64 %t215)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t218 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca i32
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca ptr
  %l26 = alloca i1
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i32
  %l62 = alloca i64
  %l65 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l73 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l84 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca i64
  %l93 = alloca %"compiler/free:feed"
  %l95 = alloca i64
  %l96 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca i1
  %l106 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l107 = alloca ptr
  %l108 = alloca i1
  %l117 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l118 = alloca ptr
  %l120 = alloca i32
  %l122 = alloca i64
  %l125 = alloca ptr
  %l128 = alloca i64
  %l129 = alloca i64
  %l131 = alloca ptr
  %l132 = alloca i1
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l144 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l145 = alloca ptr
  %l146 = alloca ptr
  %l149 = alloca i32
  %l150 = alloca i32
  %l151 = alloca i64
  %l154 = alloca ptr
  %l157 = alloca i64
  %l158 = alloca i64
  %l160 = alloca ptr
  %l161 = alloca i1
  %l169 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l170 = alloca ptr
  %l171 = alloca i1
  %l178 = alloca ptr
  %l181 = alloca i64
  %l184 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l188 = alloca ptr
  %l189 = alloca i1
  %l192 = alloca i64
  %l194 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l198 = alloca i64
  %l200 = alloca ptr
  %l204 = alloca ptr
  %l206 = alloca ptr
  %l209 = alloca i64
  %l211 = alloca ptr
  %l212 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l213 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l216 = alloca ptr
  %l221 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t7 = load ptr, ptr %l25, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l25, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l26, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l26, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l3
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t23, i32 0, i32 2
  %t25 = load i32, ptr %t24
  store i32 %t25, ptr %l4, !tbaa !23
  br label %bb5
bb4:
  br label %bb37
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load i32, ptr %l4, !tbaa !23
  %t30 = sext i32 %t28 to i64
  %t31 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %t27, i64 %t30, %"compiler/source:Span" %t31)
  br label %bb6
bb6:
  %t35 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l37
  br label %bb7
bb7:
  %t36 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t36, ptr %l5
  store ptr %l5, ptr %l38, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/free:walker", ptr %t37, i32 0, i32 3
  %t40 = load i32, ptr %l4, !tbaa !23
  %t42 = sext i32 %t40 to i64
  %t45 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t39, i64 %t42)
  store ptr %t45, ptr %l43
  br label %bb8
bb8:
  %t46 = load ptr, ptr %l38, !tbaa !29
  %t47 = load ptr, ptr %l43, !tbaa !29
  %t48 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t46, ptr %t47)
  store i64 %t48, ptr %l44
  br label %bb9
bb9:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/free:walker", ptr %t49, i32 0, i32 7
  %t52 = load i32, ptr %l4, !tbaa !23
  %t54 = sext i32 %t52 to i64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t51, i64 %t54, i1 true)
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 10
  %t60 = load i32, ptr %l4, !tbaa !23
  %t62 = sext i32 %t60 to i64
  %t65 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t59, i64 %t62)
  %t66 = extractvalue { i32, i64 } %t65, 1
  %t67 = extractvalue { i32, i64 } %t65, 0
  store i32 %t67, ptr %l55
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb12, label %ok.69, !prof !99
ok.69:
  store i64 %t66, ptr %l54
  br label %bb11
bb11:
  %t70 = load i64, ptr %l54, !tbaa !24
  store i64 %t70, ptr %l49, !tbaa !24
  br label %bb14
bb12:
  br label %bb13
bb13:
  store i64 -1, ptr %l49, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l49, !tbaa !24
  store i64 %t71, ptr %l6, !tbaa !24
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sge i64 %t72, 0
  br i1 %t74, label %bb15, label %bb16
bb15:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/free:walker", ptr %t77, i32 0, i32 11
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load i64, ptr %l6, !tbaa !24
  %t85 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t76, i32 %t80, i64 %t81)
  store i64 %t85, ptr %l62
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t86 = load i64, ptr %l62, !tbaa !24
  store i64 %t86, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = icmp sge i64 %t87, 0
  br i1 %t89, label %bb18, label %bb19
bb18:
  store ptr %l5, ptr %l65, !tbaa !29
  %t91 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t92 = load i64, ptr %l7, !tbaa !24
  %t95 = call i64 @compiler_2ffree_2eorig(i64 %t91, i64 %t92)
  store i64 %t95, ptr %l68
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t96 = load ptr, ptr %l65, !tbaa !29
  %t97 = load i64, ptr %l68, !tbaa !24
  %t98 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t96, i64 %t97)
  store i64 %t98, ptr %l69
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l4, !tbaa !23
  %t102 = sext i32 %t100 to i64
  %t105 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t99, i64 %t102)
  store i64 %t105, ptr %l73
  br label %bb24
bb24:
  %t106 = load i64, ptr %l73, !tbaa !24
  store i64 %t106, ptr %l8, !tbaa !24
  %t107 = load i64, ptr %l8, !tbaa !24
  %t109 = icmp sge i64 %t107, 0
  br i1 %t109, label %bb25, label %bb26
bb25:
  store ptr %l5, ptr %l76, !tbaa !29
  %t111 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = call i64 @compiler_2ffree_2eorig(i64 %t111, i64 %t112)
  store i64 %t115, ptr %l79
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t116 = load ptr, ptr %l76, !tbaa !29
  %t117 = load i64, ptr %l79, !tbaa !24
  %t118 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t116, i64 %t117)
  store i64 %t118, ptr %l80
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t120 = load i32, ptr %l4, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t125 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %t119, i64 %t122)
  store i64 %t125, ptr %l84
  br label %bb30
bb30:
  %t126 = load i64, ptr %l84, !tbaa !24
  store i64 %t126, ptr %l9, !tbaa !24
  %t127 = load i64, ptr %l9, !tbaa !24
  %t129 = icmp sge i64 %t127, 0
  br i1 %t129, label %bb31, label %bb32
bb31:
  store ptr %l5, ptr %l87, !tbaa !29
  %t131 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  store i64 %t131, ptr %l88, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/free:walker", ptr %t132, i32 0, i32 0
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/free:Free", ptr %t135, i32 0, i32 174
  %t138 = load i64, ptr %l9, !tbaa !24
  %t141 = call %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %t137, i64 %t138)
  store %"compiler/free:feed" %t141, ptr %l93
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t142 = getelementptr %"compiler/free:feed", ptr %l93, i32 0, i32 2
  %t143 = load i64, ptr %t142, !tbaa !24
  %t144 = load i64, ptr %l88, !tbaa !24
  %t146 = call i64 @compiler_2ffree_2eorig(i64 %t144, i64 %t143)
  store i64 %t146, ptr %l95
  br label %bb34
bb34:
  %t147 = load ptr, ptr %l87, !tbaa !29
  %t148 = load i64, ptr %l95, !tbaa !24
  %t149 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t147, i64 %t148)
  store i64 %t149, ptr %l96
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t150 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t150, ptr %rv
  br label %ret
bb37:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l98, !tbaa !29
  store i1 false, ptr %l99, !tbaa !21
  %t153 = load ptr, ptr %l98, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb38, label %bb39
bb38:
  %t156 = load ptr, ptr %l98, !tbaa !29
  %t157 = load i64, ptr %t156, !range !{i64 0, i64 8}
  %t159 = icmp eq i64 %t157, 2
  store i1 %t159, ptr %l99, !tbaa !21
  br label %bb39
bb39:
  %t160 = load i1, ptr %l99, !tbaa !21
  br i1 %t160, label %bb40, label %bb41
bb40:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [4 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l10, !tbaa !29
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load ptr, ptr %l10, !tbaa !29
  %t171 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t167, ptr %t168)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t171, ptr %l106
  br label %bb43
bb43:
  %t172 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l106
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t172, ptr %rv
  br label %ret
bb44:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t174 = load ptr, ptr %l107, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb45, label %bb46
bb45:
  %t177 = load ptr, ptr %l107, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 8}
  %t180 = icmp eq i64 %t178, 3
  store i1 %t180, ptr %l108, !tbaa !21
  br label %bb46
bb46:
  %t181 = load i1, ptr %l108, !tbaa !21
  br i1 %t181, label %bb47, label %bb48
bb47:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [4 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t184, i32 0, i32 2
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l11, !tbaa !29
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [4 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t190, i32 0, i32 3
  %t192 = load i64, ptr %t191
  store i64 %t192, ptr %l12, !tbaa !24
  br label %bb49
bb48:
  br label %bb58
bb49:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l11, !tbaa !29
  %t198 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t194, ptr %t195)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %l117
  br label %bb50
bb50:
  %t199 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l117
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t199, ptr %l13
  %t200 = load ptr, ptr %l2, !tbaa !29
  store ptr %t200, ptr %l118, !tbaa !29
  %t201 = load ptr, ptr %l11, !tbaa !29
  %t203 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t201)
  store i32 %t203, ptr %l120
  br label %bb51
bb51:
  %t204 = load i64, ptr %l12, !tbaa !24
  %t205 = load ptr, ptr %l118, !tbaa !29
  %t206 = load i32, ptr %l120, !tbaa !23
  %t208 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t205, i32 %t206, i64 %t204)
  store i64 %t208, ptr %l122
  br label %bb52
bb52:
  %t209 = load i64, ptr %l122, !tbaa !24
  store i64 %t209, ptr %l14, !tbaa !24
  %t210 = load i64, ptr %l14, !tbaa !24
  %t212 = icmp sge i64 %t210, 0
  br i1 %t212, label %bb53, label %bb54
bb53:
  store ptr %l13, ptr %l125, !tbaa !29
  %t214 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t215 = load i64, ptr %l14, !tbaa !24
  %t218 = call i64 @compiler_2ffree_2eorig(i64 %t214, i64 %t215)
  store i64 %t218, ptr %l128
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t219 = load ptr, ptr %l125, !tbaa !29
  %t220 = load i64, ptr %l128, !tbaa !24
  %t221 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t219, i64 %t220)
  store i64 %t221, ptr %l129
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t222 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t222, ptr %rv
  br label %ret
bb58:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t225 = load ptr, ptr %l131, !tbaa !29
  %t226 = icmp ne ptr %t225, null
  br i1 %t226, label %bb59, label %bb60
bb59:
  %t228 = load ptr, ptr %l131, !tbaa !29
  %t229 = load i64, ptr %t228, !range !{i64 0, i64 8}
  %t231 = icmp eq i64 %t229, 4
  store i1 %t231, ptr %l132, !tbaa !21
  br label %bb60
bb60:
  %t232 = load i1, ptr %l132, !tbaa !21
  br i1 %t232, label %bb61, label %bb62
bb61:
  %t233 = load ptr, ptr %l1, !tbaa !29
  %t235 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  %t236 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t235, i32 0, i32 2
  %t237 = load ptr, ptr %t236
  store ptr %t237, ptr %l15, !tbaa !29
  br label %bb63
bb62:
  br label %bb74
bb63:
  store %olang.scope zeroinitializer, ptr %s9
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t240 = load ptr, ptr %l15, !tbaa !29
  %t242 = getelementptr %"compiler/typed:Elem", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t246 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t239, ptr %t243)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t246, ptr %l140
  br label %bb64
bb64:
  %t247 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t247, ptr %l16
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l15, !tbaa !29
  %t251 = getelementptr %"compiler/typed:Elem", ptr %t249, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t255 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s9, ptr %t248, ptr %t252)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t255, ptr %l144
  br label %bb65
bb65:
  %t256 = load ptr, ptr %l2, !tbaa !29
  store ptr %t256, ptr %l145, !tbaa !29
  %t257 = load ptr, ptr %l2, !tbaa !29
  store ptr %t257, ptr %l146, !tbaa !29
  %t258 = load ptr, ptr %l15, !tbaa !29
  %t260 = getelementptr %"compiler/typed:Elem", ptr %t258, i32 0, i32 0
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t261)
  store i32 %t263, ptr %l149
  br label %bb66
bb66:
  %t264 = load ptr, ptr %l146, !tbaa !29
  %t265 = load i32, ptr %l149, !tbaa !23
  %t266 = call i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %t264, i32 %t265)
  store i32 %t266, ptr %l150
  br label %bb67
bb67:
  %t267 = load ptr, ptr %l145, !tbaa !29
  %t268 = load i32, ptr %l150, !tbaa !23
  %t269 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %t267, i32 %t268, i64 -1)
  store i64 %t269, ptr %l151
  br label %bb68
bb68:
  %t270 = load i64, ptr %l151, !tbaa !24
  store i64 %t270, ptr %l17, !tbaa !24
  %t271 = load i64, ptr %l17, !tbaa !24
  %t273 = icmp sge i64 %t271, 0
  br i1 %t273, label %bb69, label %bb70
bb69:
  store ptr %l16, ptr %l154, !tbaa !29
  %t275 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t276 = load i64, ptr %l17, !tbaa !24
  %t279 = call i64 @compiler_2ffree_2eorig(i64 %t275, i64 %t276)
  store i64 %t279, ptr %l157
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t280 = load ptr, ptr %l154, !tbaa !29
  %t281 = load i64, ptr %l157, !tbaa !24
  %t282 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t280, i64 %t281)
  store i64 %t282, ptr %l158
  br label %bb72
bb72:
  br label %bb73
bb73:
  %t283 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  call void @__olang_scope_close(ptr %s9)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t283, ptr %rv
  br label %ret
bb74:
  %t285 = load ptr, ptr %l1, !tbaa !29
  store ptr %t285, ptr %l160, !tbaa !29
  store i1 false, ptr %l161, !tbaa !21
  %t286 = load ptr, ptr %l160, !tbaa !29
  %t287 = icmp ne ptr %t286, null
  br i1 %t287, label %bb75, label %bb76
bb75:
  %t289 = load ptr, ptr %l160, !tbaa !29
  %t290 = load i64, ptr %t289, !range !{i64 0, i64 8}
  %t292 = icmp eq i64 %t290, 5
  store i1 %t292, ptr %l161, !tbaa !21
  br label %bb76
bb76:
  %t293 = load i1, ptr %l161, !tbaa !21
  br i1 %t293, label %bb77, label %bb78
bb77:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = getelementptr { i64, [4 x i64] }, ptr %t294, i32 0, i32 1
  %t297 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t296, i32 0, i32 2
  %t298 = load ptr, ptr %t297
  store ptr %t298, ptr %l18, !tbaa !29
  br label %bb79
bb78:
  br label %bb81
bb79:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l18, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Payload", ptr %t301, i32 0, i32 0
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t307 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t300, ptr %t304)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t307, ptr %l169
  br label %bb80
bb80:
  %t308 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l169
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t308, ptr %rv
  br label %ret
bb81:
  %t309 = load ptr, ptr %l1, !tbaa !29
  store ptr %t309, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t310 = load ptr, ptr %l170, !tbaa !29
  %t311 = icmp ne ptr %t310, null
  br i1 %t311, label %bb82, label %bb83
bb82:
  %t313 = load ptr, ptr %l170, !tbaa !29
  %t314 = load i64, ptr %t313, !range !{i64 0, i64 8}
  %t316 = icmp eq i64 %t314, 6
  store i1 %t316, ptr %l171, !tbaa !21
  br label %bb83
bb83:
  %t317 = load i1, ptr %l171, !tbaa !21
  br i1 %t317, label %bb84, label %bb85
bb84:
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr { i64, [4 x i64] }, ptr %t318, i32 0, i32 1
  %t321 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t320, i32 0, i32 2
  %t322 = load ptr, ptr %t321
  store ptr %t322, ptr %l19, !tbaa !29
  br label %bb86
bb85:
  br label %bb89
bb86:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/free:walker", ptr %t324, i32 0, i32 60
  %t327 = load i64, ptr %t326, !tbaa !24
  store i64 %t327, ptr %l20, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  store ptr %t329, ptr %l178, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t334 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblockFillOf(ptr %v0, ptr %v1, ptr %t330, ptr %t331)
  store i64 %t334, ptr %l181
  br label %bb87
bb87:
  %t335 = load i64, ptr %l181, !tbaa !24
  %t336 = load ptr, ptr %l178, !tbaa !29
  %t337 = getelementptr %"compiler/free:walker", ptr %t336, i32 0, i32 60
  store i64 %t335, ptr %t337, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l19, !tbaa !29
  %t342 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %t338, ptr %t339)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t342, ptr %l184
  br label %bb88
bb88:
  %t343 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l184
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load i64, ptr %l20, !tbaa !24
  %t348 = getelementptr %"compiler/free:walker", ptr %t344, i32 0, i32 60
  store i64 %t345, ptr %t348, !tbaa !24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t343, ptr %rv
  br label %ret
bb89:
  %t351 = load ptr, ptr %l1, !tbaa !29
  store ptr %t351, ptr %l188, !tbaa !29
  store i1 false, ptr %l189, !tbaa !21
  %t352 = load ptr, ptr %l188, !tbaa !29
  %t353 = icmp ne ptr %t352, null
  br i1 %t353, label %bb90, label %bb91
bb90:
  %t355 = load ptr, ptr %l188, !tbaa !29
  %t356 = load i64, ptr %t355, !range !{i64 0, i64 8}
  %t358 = icmp eq i64 %t356, 7
  store i1 %t358, ptr %l189, !tbaa !21
  br label %bb91
bb91:
  %t359 = load i1, ptr %l189, !tbaa !21
  br i1 %t359, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb111
bb94:
  %t360 = call ptr @__olang_scope_hold(ptr %v2)
  %t361 = ptrtoint ptr %t360 to i64
  store i64 %t361, ptr %l192, !tbaa !24
  %t362 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e22
  br i1 %t362, label %bb95, label %bb96
bb95:
  %t364 = call ptr @__olang_region_make(ptr %v2)
  %t365 = ptrtoint ptr %t364 to i64
  store i64 %t365, ptr %l192, !tbaa !24
  br label %bb96
bb96:
  %t366 = load i64, ptr %l192
  %t367 = inttoptr i64 %t366 to ptr
  %t368 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t367, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t368, ptr %l194
  br label %bb97
bb97:
  %t369 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e22
  br i1 %t369, label %bb98, label %bb99
bb98:
  %t371 = load i64, ptr %l192
  %t372 = inttoptr i64 %t371 to ptr
  %t373 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l194, i32 0, i32 0
  %t374 = load { i64, ptr }, ptr %t373
  %t375 = extractvalue { i64, ptr } %t374, 1
  %t376 = call ptr @__olang_region_or(ptr %t375, ptr null)
  %t377 = call ptr @__olang_region_home(ptr %t376)
  %t378 = icmp ne ptr %t377, null
  %t379 = select i1 %t378, ptr %t377, ptr null
  call void @__olang_region_settle_in(ptr %t372, ptr %t379)
  br label %bb99
bb99:
  %t380 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l194
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t380, ptr %l22
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t383 = getelementptr %"compiler/free:walker", ptr %t381, i32 0, i32 12
  %t385 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t383)
  store i64 %t385, ptr %l198
  br label %bb100
bb100:
  %t386 = load i64, ptr %l198, !tbaa !24
  %t387 = icmp sgt i64 %t386, 0
  br i1 %t387, label %bb101, label %bb102
bb101:
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l200, !tbaa !29
  %t390 = load ptr, ptr %l200, !tbaa !29
  %t391 = getelementptr %"compiler/free:walker", ptr %t390, i32 0, i32 36
  %t392 = load i64, ptr %t391, !tbaa !24
  %t395 = add i64 %t392, 1
  %t397 = load ptr, ptr %l200, !tbaa !29
  %t398 = getelementptr %"compiler/free:walker", ptr %t397, i32 0, i32 36
  store i64 %t395, ptr %t398, !tbaa !24
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l204, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/free:walker", ptr %t400, i32 0, i32 12
  store ptr %t402, ptr %l206, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/free:walker", ptr %t403, i32 0, i32 12
  %t407 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %t405)
  store i64 %t407, ptr %l209
  br label %bb103
bb102:
  br label %bb110
bb103:
  %t408 = load i64, ptr %l209, !tbaa !24
  %t409 = sub i64 %t408, 1
  %t410 = load ptr, ptr %l206, !tbaa !29
  %t412 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v0, ptr %t410, i64 %t409)
  store ptr %t412, ptr %l211
  br label %bb104
bb104:
  %t413 = load ptr, ptr %l204, !tbaa !29
  %t414 = load ptr, ptr %l211, !tbaa !29
  %t415 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v0, ptr %v2, ptr %t413, ptr %t414)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t415, ptr %l212
  br label %bb105
bb105:
  %t416 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t416, ptr %l213
  %t417 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l212
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t417, ptr %l22
  %t418 = load i1, ptr @olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e22
  br i1 %t418, label %bb106, label %bb107
bb106:
  %t420 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l213, i32 0, i32 0
  %t421 = load { i64, ptr }, ptr %t420
  %t422 = extractvalue { i64, ptr } %t421, 1
  %t423 = call ptr @__olang_region_or(ptr %t422, ptr null)
  %t424 = call ptr @__olang_region_home(ptr %t423)
  %t425 = icmp ne ptr %t424, null
  %t426 = select i1 %t425, ptr %t424, ptr null
  call void @__olang_region_drop(ptr %t426)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" zeroinitializer, ptr %l213
  br label %bb107
bb107:
  %t427 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t427, label %bb108, label %bb109
bb108:
  %t429 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l213, i32 0, i32 0
  %t430 = load { i64, ptr }, ptr %t429
  %t431 = extractvalue { i64, ptr } %t430, 0
  %t432 = extractvalue { i64, ptr } %t430, 1
  call void @__olang_region_release_part(ptr %t432, i64 %t431)
  store { i64, ptr } zeroinitializer, ptr %t429
  br label %bb109
bb109:
  %t433 = load ptr, ptr %l0, !tbaa !29
  store ptr %t433, ptr %l216, !tbaa !29
  %t434 = load ptr, ptr %l216, !tbaa !29
  %t435 = getelementptr %"compiler/free:walker", ptr %t434, i32 0, i32 36
  %t436 = load i64, ptr %t435, !tbaa !24
  %t439 = sub i64 %t436, 1
  %t441 = load ptr, ptr %l216, !tbaa !29
  %t442 = getelementptr %"compiler/free:walker", ptr %t441, i32 0, i32 36
  store i64 %t439, ptr %t442, !tbaa !24
  br label %bb110
bb110:
  %t443 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t443, ptr %rv
  br label %ret
bb111:
  br i1 true, label %bb112, label %bb113
bb112:
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t445 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t445, ptr %l221
  br label %bb115
bb115:
  %t446 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l221
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t446, ptr %rv
  br label %ret
bb116:
  call void @__olang_check_failed(ptr @olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3)
  unreachable
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i1
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l14, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 8}
  %t29 = icmp eq i64 %t27, 4
  store i1 %t29, ptr %l15, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l15, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 2
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb15
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t40 = getelementptr %"compiler/typed:Elem", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t37, ptr %t41)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l23
  br label %bb13
bb13:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %l4
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load ptr, ptr %l3, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Elem", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t46, ptr %t50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l27
  br label %bb14
bb14:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  call void @__olang_scope_close(ptr %s2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %rv
  br label %ret
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t60 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t56, ptr %t57)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %l31
  br label %bb19
bb19:
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l31
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_71c754545de4040c_468b95bb5168a5f8)
  unreachable
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ecompiler_2ffree_3awalker_2erefsIn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l24 = alloca ptr
  %l26 = alloca i32
  %l27 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca i1
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i64
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca ptr
  %l60 = alloca ptr
  %l64 = alloca %"compiler/typed:Local"
  %l66 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l68 = alloca i64
  %l70 = alloca i64
  %l75 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca i64
  %l86 = alloca i64
  %l89 = alloca i64
  %l103 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca i64
  %l116 = alloca i1
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca i64
  %l128 = alloca ptr
  %l131 = alloca i1
  %l132 = alloca ptr
  %l134 = alloca i64
  %l135 = alloca i1
  %l146 = alloca { i64, ptr }
  %l149 = alloca ptr
  %l150 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l153 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca i32
  %l157 = alloca i64
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t6)
  store ptr %t8, ptr %l22
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l22, !tbaa !29
  store ptr %t9, ptr %l3, !tbaa !29
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l23
  br label %bb2
bb2:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l4
  %t12 = load ptr, ptr %l2, !tbaa !29
  store ptr %t12, ptr %l24, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t13)
  store i32 %t15, ptr %l26
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t17 = load i32, ptr %l26, !tbaa !23
  %t18 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefsBeyondParts(ptr %v0, ptr %t16, i32 %t17)
  store i1 %t18, ptr %l27
  br label %bb4
bb4:
  %t19 = load i1, ptr %l27, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t24 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t24, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call ptr @compiler_2ffree_2eunaway(ptr %v1, ptr %v1, ptr %t25)
  store ptr %t27, ptr %l31
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l31, !tbaa !29
  %t29 = call i64 @compiler_2ffree_2ereadLocalOf(ptr %v1, ptr %t28)
  store i64 %t29, ptr %l32
  br label %bb9
bb9:
  %t30 = load i64, ptr %l32, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  %t31 = load ptr, ptr %l3, !tbaa !29
  store ptr %t31, ptr %l33, !tbaa !29
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t32)
  store i32 %t34, ptr %l35
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = load i32, ptr %l35, !tbaa !23
  %t37 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t37, ptr %l36
  br label %bb11
bb11:
  %t38 = load i1, ptr %l36, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sge i64 %t39, 0
  br i1 %t41, label %bb14, label %bb15
bb13:
  br label %bb52
bb14:
  store ptr %l4, ptr %l39, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/free:walker", ptr %t43, i32 0, i32 3
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t45, i64 %t46)
  store ptr %t49, ptr %l43
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l39, !tbaa !29
  %t51 = load ptr, ptr %l43, !tbaa !29
  %t52 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t50, ptr %t51)
  store i64 %t52, ptr %l44
  br label %bb17
bb17:
  %t53 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t55 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t55, ptr %rv
  br label %ret
bb18:
  %t56 = load ptr, ptr %l1, !tbaa !29
  %t58 = call ptr @compiler_2ffree_2eunaway(ptr %v1, ptr %v1, ptr %t56)
  store ptr %t58, ptr %l47
  br label %bb19
bb19:
  %t59 = load ptr, ptr %l47, !tbaa !29
  %t60 = call i64 @compiler_2ffree_2eborrowedLocal(ptr %v1, ptr %t59)
  store i64 %t60, ptr %l48
  br label %bb20
bb20:
  %t61 = load i64, ptr %l48, !tbaa !24
  store i64 %t61, ptr %l6, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  %t64 = icmp slt i64 %t62, 0
  br i1 %t64, label %bb21, label %bb22
bb21:
  %t67 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t67, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store ptr %l4, ptr %l52, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/free:walker", ptr %t68, i32 0, i32 3
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t70, i64 %t71)
  store ptr %t74, ptr %l56
  br label %bb24
bb24:
  %t75 = load ptr, ptr %l52, !tbaa !29
  %t76 = load ptr, ptr %l56, !tbaa !29
  %t77 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t75, ptr %t76)
  store i64 %t77, ptr %l57
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l58, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v0, ptr %t79)
  store ptr %t81, ptr %l60
  br label %bb26
bb26:
  %t82 = load ptr, ptr %l60, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 7
  %t85 = load i64, ptr %l6, !tbaa !24
  %t88 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t84, i64 %t85)
  store %"compiler/typed:Local" %t88, ptr %l64
  br label %bb27
bb27:
  %t89 = getelementptr %"compiler/typed:Local", ptr %l64, i32 0, i32 2
  %t90 = load i32, ptr %t89, !tbaa !23
  %t91 = load ptr, ptr %l58, !tbaa !29
  %t93 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %s5, ptr %t91, i32 %t90)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t93, ptr %l66
  br label %bb28
bb28:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l66
  %t95 = call ptr @__olang_scope_alloc_a(ptr %s5, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %t95
  store ptr %t95, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb29
bb29:
  %t97 = load i64, ptr %l8, !tbaa !24
  store i64 %t97, ptr %l68, !tbaa !24
  %t98 = load ptr, ptr %l7, !tbaa !29
  %t100 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s5, ptr %t98)
  store i64 %t100, ptr %l70
  br label %bb30
bb30:
  %t101 = load i64, ptr %l68, !tbaa !24
  %t102 = load i64, ptr %l70, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  %t105 = xor i1 %t103, true
  br i1 %t105, label %bb31, label %bb32
bb31:
  br label %bb38
bb32:
  br label %bb33
bb33:
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t108 = load i64, ptr %l8, !tbaa !24
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s5, ptr %t107, i64 %t108)
  store i64 %t111, ptr %l75
  br label %bb34
bb34:
  %t112 = load i64, ptr %l75, !tbaa !24
  store ptr %l4, ptr %l76, !tbaa !29
  %t113 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t117 = call i64 @compiler_2ffree_2eorig(i64 %t113, i64 %t112)
  store i64 %t117, ptr %l79
  br label %bb35
bb35:
  %t118 = load ptr, ptr %l76, !tbaa !29
  %t119 = load i64, ptr %l79, !tbaa !24
  %t120 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t118, i64 %t119)
  store i64 %t120, ptr %l80
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = add i64 %t121, 1
  store i64 %t124, ptr %l8, !tbaa !24
  br label %bb29
bb38:
  call void @__olang_scope_close(ptr %s5)
  store %olang.scope zeroinitializer, ptr %s8
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load i64, ptr %l6, !tbaa !24
  %t130 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t126, i64 %t127)
  store i64 %t130, ptr %l86
  br label %bb39
bb39:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeederPlace(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l89
  br label %bb40
bb40:
  %t136 = load i64, ptr %l86, !tbaa !24
  %t137 = insertvalue [2 x i64] undef, i64 %t136, 0
  %t138 = load i64, ptr %l89, !tbaa !24
  %t139 = insertvalue [2 x i64] %t137, i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 16, i64 8)
  store [2 x i64] %t139, ptr %t141
  store ptr %t141, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t143 = load ptr, ptr %l10
  store i64 2, ptr %l12, !tbaa !24
  br label %bb41
bb41:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb42, label %bb43
bb42:
  br label %bb51
bb43:
  br label %bb44
bb44:
  %t154 = load ptr, ptr %l10
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = getelementptr [2 x i64], ptr %t154, i64 0, i64 %t155
  %t159 = load i64, ptr %t158, !tbaa !34
  store i64 %t159, ptr %l13, !tbaa !24
  %t161 = load i64, ptr %l13, !tbaa !24
  %t163 = icmp sge i64 %t161, 0
  br i1 %t163, label %bb45, label %bb46
bb45:
  store ptr %l4, ptr %l103, !tbaa !29
  %t165 = load i64, ptr @G_2ecompiler_2ffree_2eOPl, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = call i64 @compiler_2ffree_2eorig(i64 %t165, i64 %t166)
  store i64 %t169, ptr %l106
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t170 = load ptr, ptr %l103, !tbaa !29
  %t171 = load i64, ptr %l106, !tbaa !24
  %t172 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t170, i64 %t171)
  store i64 %t172, ptr %l107
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t173 = load i64, ptr %l11, !tbaa !24
  %t176 = add i64 %t173, 1
  store i64 %t176, ptr %l11, !tbaa !24
  br label %bb41
bb51:
  call void @__olang_scope_close(ptr %s8)
  %t178 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t180 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t178, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t180, ptr %rv
  br label %ret
bb52:
  %t181 = load i64, ptr %l5, !tbaa !24
  %t183 = icmp sge i64 %t181, 0
  br i1 %t183, label %bb53, label %bb54
bb53:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i64, ptr %l5, !tbaa !24
  %t189 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2epathsKnown(ptr %v0, ptr %t185, i64 %t186)
  store i1 %t189, ptr %l116
  br label %bb55
bb54:
  br label %bb61
bb55:
  %t190 = load i1, ptr %l116, !tbaa !21
  %t191 = xor i1 %t190, true
  br i1 %t191, label %bb56, label %bb57
bb56:
  %t194 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t194, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  store ptr %l4, ptr %l119, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/free:walker", ptr %t195, i32 0, i32 4
  %t198 = load i64, ptr %l5, !tbaa !24
  %t201 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t197, i64 %t198)
  store ptr %t201, ptr %l123
  br label %bb59
bb59:
  %t202 = load ptr, ptr %l119, !tbaa !29
  %t203 = load ptr, ptr %l123, !tbaa !29
  %t204 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %v0, ptr %t202, ptr %t203)
  store i64 %t204, ptr %l124
  br label %bb60
bb60:
  %t205 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t207 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t207, ptr %rv
  br label %ret
bb61:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t211 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v1, ptr %v1, ptr %t208)
  store ptr %t211, ptr %l128
  br label %bb62
bb62:
  %t212 = load ptr, ptr %l128, !tbaa !29
  store ptr %t212, ptr %l14, !tbaa !29
  %t213 = load ptr, ptr %l14, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l131, !tbaa !21
  br label %bb67
bb64:
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l132, !tbaa !29
  %t218 = load ptr, ptr %l14, !tbaa !29
  %t220 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v1, ptr %t218)
  store i64 %t220, ptr %l134
  br label %bb65
bb65:
  %t221 = load ptr, ptr %l132, !tbaa !29
  %t222 = load i64, ptr %l134, !tbaa !24
  %t223 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eplainCtor(ptr %v0, ptr %t221, i64 %t222)
  store i1 %t223, ptr %l135
  br label %bb66
bb66:
  %t224 = load i1, ptr %l135, !tbaa !21
  %t225 = xor i1 %t224, true
  store i1 %t225, ptr %l131, !tbaa !21
  br label %bb67
bb67:
  %t227 = load i1, ptr %l131, !tbaa !21
  br i1 %t227, label %bb68, label %bb69
bb68:
  %t229 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t229, ptr %rv
  br label %ret
bb69:
  br label %bb70
bb70:
  %t230 = load ptr, ptr %l14, !tbaa !29
  %t232 = getelementptr %"compiler/typed:Call", ptr %t230, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t235 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t235, 0
  store i64 %t237, ptr %l17, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s16
  %t239 = load i64, ptr %l16, !tbaa !24
  %t240 = load i64, ptr %l17, !tbaa !24
  %t243 = icmp slt i64 %t239, %t240
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s16)
  br label %bb80
bb73:
  br label %bb74
bb74:
  %t247 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t247, ptr %l146, !tbaa !27
  %t248 = load i64, ptr %l16, !tbaa !24
  %t250 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !27
  %t252 = getelementptr ptr, ptr %t251, i64 %t248
  %t253 = load ptr, ptr %t252, !tbaa !39
  store ptr %l4, ptr %l149, !tbaa !29
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t259 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ecompiler_2ffree_3awalker_2erefsIn(ptr %v0, ptr %v1, ptr %s16, ptr %t255, ptr %t253)
  %t260 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t259, 1
  %t261 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t259, 0
  store i32 %t261, ptr %l154
  %t262 = icmp ne i32 %t261, 0
  br i1 %t262, label %bb76, label %ok.263, !prof !99
ok.263:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %l153
  br label %bb75
bb75:
  %t264 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l153
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t264, ptr %l150
  br label %bb77
bb76:
  %t265 = load i32, ptr %l154, !tbaa !23
  %t266 = lshr i32 %t265, 16
  %t267 = and i32 %t265, 65535
  %t268 = icmp eq i32 %t266, 1
  %t269 = select i1 %t268, i32 1, i32 0
  %t270 = icmp eq i32 %t265, 0
  %t271 = shl i32 %t269, 16
  %t272 = or i32 %t271, %t267
  %t273 = select i1 %t270, i32 0, i32 %t272
  call void @__olang_scope_close(ptr %s16)
  %t275 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t273, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t275, ptr %rv
  br label %ret
bb77:
  %t276 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l150
  %t277 = call ptr @__olang_scope_alloc_a(ptr %s16, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t276, ptr %t277
  %t278 = load ptr, ptr %l149, !tbaa !29
  %t280 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v2, ptr %s16, ptr %t278, ptr %t277)
  store i64 %t280, ptr %l157
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s16)
  br label %bb79
bb79:
  %t281 = load i64, ptr %l16, !tbaa !24
  %t284 = add i64 %t281, 1
  store i64 %t284, ptr %l16, !tbaa !24
  br label %bb71
bb80:
  %t286 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t288 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t286, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t288, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eregisteredAt(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, [2 x i64] }
  %l6 = alloca i64
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i64
  %l27 = alloca %"compiler/typed:Plan"
  %l35 = alloca %"compiler/typed:Plan"
  %l36 = alloca { i64, ptr }
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca i32
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i1
  %s0 = alloca %olang.scope
  %t6 = alloca { i64, [2 x i64] }, align 8
  %t38 = alloca %"compiler/typed:Plan", align 8
  %t57 = alloca %"compiler/typed:Plan", align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [2 x i64] }, ptr %t6, i32 0, i32 0
  store i64 0, ptr %t7
  %t8 = load { i64, [2 x i64] }, ptr %t6
  store { i64, [2 x i64] } %t8, ptr %l4
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/free:walker", ptr %t10, i32 0, i32 1
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l12, !tbaa !24
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = getelementptr %"compiler/free:Free", ptr %t14, i32 0, i32 3
  %t18 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l15
  br label %bb1
bb1:
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = load i64, ptr %l15, !tbaa !24
  %t21 = icmp slt i64 %t19, %t20
  br i1 %t21, label %bb2, label %bb3
bb2:
  %t23 = load i32, ptr %l1, !tbaa !23
  %t25 = icmp sge i32 %t23, 0
  store i1 %t25, ptr %l17, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb4
bb4:
  %t27 = load i1, ptr %l17, !tbaa !21
  br i1 %t27, label %bb5, label %bb6
bb5:
  %t28 = load i32, ptr %l1, !tbaa !23
  %t30 = sext i32 %t28 to i64
  store i64 %t30, ptr %l22, !tbaa !24
  %t31 = load ptr, ptr %l3, !tbaa !29
  %t33 = getelementptr %"compiler/free:Free", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/free:walker", ptr %t34, i32 0, i32 1
  %t37 = load i64, ptr %t36, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t38, ptr %v0, ptr %v0, ptr %t33, i64 %t37)
  call void @llvm.memmove.p0.p0.i64(ptr %l27, ptr %t38, i64 584, i1 false)
  br label %bb7
bb6:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb8
bb7:
  %t41 = getelementptr %"compiler/typed:Plan", ptr %l27, i32 0, i32 0
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = load i64, ptr %l22, !tbaa !24
  %t47 = icmp slt i64 %t45, %t44
  store i1 %t47, ptr %l20, !tbaa !21
  br label %bb8
bb8:
  %t49 = load i1, ptr %l20, !tbaa !21
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/free:Free", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/free:walker", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %t57, ptr %v0, ptr %v0, ptr %t52, i64 %t56)
  call void @llvm.memmove.p0.p0.i64(ptr %l35, ptr %t57, i64 584, i1 false)
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t60 = getelementptr %"compiler/typed:Plan", ptr %l35, i32 0, i32 0
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l36, !tbaa !27
  %t62 = load i32, ptr %l1, !tbaa !23
  %t64 = sext i32 %t62 to i64
  %t66 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, [2 x i64] }, ptr %t67, i64 %t64
  %t69 = load { i64, [2 x i64] }, ptr %t68
  store { i64, [2 x i64] } %t69, ptr %l4
  br label %bb12
bb12:
  %t71 = load { i64, [2 x i64] }, ptr %l4
  %t73 = extractvalue { i64, [2 x i64] } %t71, 0
  %t74 = icmp eq i64 %t73, 1
  %t76 = xor i1 %t74, true
  br i1 %t76, label %bb13, label %bb14
bb13:
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t79 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %t78, i32 %t79)
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t82 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t83 = getelementptr { i32 }, ptr %t82, i32 0, i32 0
  %t84 = load i32, ptr %t83
  %t88 = sext i32 %t84 to i64
  store i64 %t88, ptr %l6, !tbaa !24
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/free:walker", ptr %t90, i32 0, i32 58
  %t93 = load i64, ptr %l6, !tbaa !24
  %t96 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v0, ptr %t92, i64 %t93)
  %t97 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t96, 1
  %t98 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t96, 0
  store i32 %t98, ptr %l53
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb18, label %ok.100, !prof !99
ok.100:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t97, ptr %l52
  br label %bb17
bb17:
  %t102 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t102, ptr %l55
  br label %bb20
bb18:
  br label %bb19
bb19:
  %t103 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l56
  br label %bb21
bb20:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l48
  br label %bb22
bb21:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %l48
  br label %bb22
bb22:
  %t106 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t106, ptr %l7
  %t107 = load i32, ptr %l2, !tbaa !23
  %t110 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %t107)
  store i1 %t110, ptr %l59
  br label %bb23
bb23:
  %t111 = load i1, ptr %l59, !tbaa !21
  %t112 = xor i1 %t111, true
  br i1 %t112, label %bb24, label %bb25
bb24:
  %t114 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l7, i32 %t114)
  br label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb27
bb27:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/free:walker", ptr %t117, i32 0, i32 58
  %t120 = load i64, ptr %l6, !tbaa !24
  %t121 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4057097bf127937e673a7f89a723e29a(ptr %v0, ptr %s0, ptr %t119, i64 %t120, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/free:leaf"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l25 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i64
  %l44 = alloca i64
  %l49 = alloca %"compiler/free:leaf"
  %l50 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i64
  %s4 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereachTo(ptr %v0, ptr %v1, ptr %v2, ptr %t6, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l14
  br label %bb1
bb1:
  %t11 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l4
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %t12, ptr %t13, ptr %l4)
  br label %bb2
bb2:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t21 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t17, ptr %t18)
  store i64 %t21, ptr %l20
  br label %bb3
bb3:
  %t22 = load i64, ptr %l20, !tbaa !24
  store i64 %t22, ptr %l5, !tbaa !24
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/free:Free", ptr %t23, i32 0, i32 30
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/free:walker", ptr %t26, i32 0, i32 1
  %t29 = load i64, ptr %t28, !tbaa !24
  %t32 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t25, i64 %t29)
  store i1 %t32, ptr %l25
  br label %bb4
bb4:
  %t33 = load i1, ptr %l25, !tbaa !21
  %t34 = xor i1 %t33, true
  store i1 %t34, ptr %l6, !tbaa !21
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sge i64 %t36, 0
  br i1 %t38, label %bb5, label %bb6
bb5:
  store ptr %l4, ptr %l29, !tbaa !29
  %t40 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = call i64 @compiler_2ffree_2eorig(i64 %t40, i64 %t41)
  store i64 %t44, ptr %l32
  br label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %s4, ptr %t45, i32 %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l40
  br label %bb13
bb7:
  %t50 = load ptr, ptr %l29, !tbaa !29
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t50, i64 %t51)
  store i64 %t52, ptr %l33
  br label %bb8
bb8:
  %t53 = load i1, ptr %l6, !tbaa !21
  br i1 %t53, label %bb9, label %bb10
bb9:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/free:Free", ptr %t55, i32 0, i32 105
  %t58 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t57, i64 %t58, i1 true)
  br label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb12
bb12:
  br label %bb28
bb13:
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  %t62 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %t62
  store ptr %t62, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb14
bb14:
  %t64 = load i64, ptr %l8, !tbaa !24
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load ptr, ptr %l7, !tbaa !29
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %s4, ptr %t65)
  store i64 %t67, ptr %l44
  br label %bb15
bb15:
  %t68 = load i64, ptr %l42, !tbaa !24
  %t69 = load i64, ptr %l44, !tbaa !24
  %t70 = icmp slt i64 %t68, %t69
  %t72 = xor i1 %t70, true
  br i1 %t72, label %bb16, label %bb17
bb16:
  br label %bb27
bb17:
  br label %bb18
bb18:
  %t74 = load ptr, ptr %l7, !tbaa !29
  %t75 = load i64, ptr %l8, !tbaa !24
  %t78 = call %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %s4, ptr %s4, ptr %t74, i64 %t75)
  store %"compiler/free:leaf" %t78, ptr %l49
  br label %bb19
bb19:
  %t79 = load %"compiler/free:leaf", ptr %l49
  store %"compiler/free:leaf" %t79, ptr %l9
  store ptr %l4, ptr %l50, !tbaa !29
  %t80 = load i64, ptr @G_2ecompiler_2ffree_2eOMov, !tbaa !24
  %t81 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t82 = load i64, ptr %t81, !tbaa !24
  %t85 = call i64 @compiler_2ffree_2eorig(i64 %t80, i64 %t82)
  store i64 %t85, ptr %l53
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l50, !tbaa !29
  %t87 = load i64, ptr %l53, !tbaa !24
  %t88 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t86, i64 %t87)
  store i64 %t88, ptr %l54
  br label %bb21
bb21:
  %t89 = load i1, ptr %l6, !tbaa !21
  br i1 %t89, label %bb22, label %bb23
bb22:
  %t91 = load ptr, ptr %l3, !tbaa !29
  %t93 = getelementptr %"compiler/free:Free", ptr %t91, i32 0, i32 105
  %t94 = getelementptr %"compiler/free:leaf", ptr %l9, i32 0, i32 1
  %t95 = load i64, ptr %t94, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t93, i64 %t95, i1 true)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t98 = load i64, ptr %l8, !tbaa !24
  %t101 = add i64 %t98, 1
  store i64 %t101, ptr %l8, !tbaa !24
  br label %bb14
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb28:
  %t103 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etempReach(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etempReach(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %l3
  br label %bb13
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t26 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereach(ptr %v0, ptr %v1, ptr %v2, ptr %t22, ptr %t23)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %l15
  br label %bb11
bb11:
  %t27 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t27, ptr %l3
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_a67b53fc36e221cd_398fd42a3021f5f1)
  unreachable
bb13:
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2etextOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca i1
  %l32 = alloca i64
  %l33 = alloca ptr
  %l36 = alloca i64
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca ptr
  %l52 = alloca i64
  %l53 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/free:walker", ptr %t3, i32 0, i32 55
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Text", ptr %t8, i32 0, i32 0
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load i64, ptr %l5, !tbaa !24
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = icmp slt i64 %t17, %t18
  %t23 = xor i1 %t21, true
  br i1 %t23, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb4:
  br label %bb5
bb5:
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t25, ptr %l21, !tbaa !27
  %t26 = load i64, ptr %l5, !tbaa !24
  %t28 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr ptr, ptr %t29, i64 %t26
  %t31 = load ptr, ptr %t30, !tbaa !39
  store ptr %t31, ptr %l7, !tbaa !29
  %t33 = load ptr, ptr %l7, !tbaa !29
  store ptr %t33, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t34 = load ptr, ptr %l24, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb6, label %bb7
bb6:
  %t37 = load ptr, ptr %l24, !tbaa !29
  %t38 = load i64, ptr %t37, !range !{i64 0, i64 2}
  %t40 = icmp eq i64 %t38, 1
  store i1 %t40, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l25, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb9:
  br label %bb10
bb10:
  %t44 = load ptr, ptr %l7, !tbaa !29
  %t46 = getelementptr { i64, [2 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { ptr }, ptr %t46, i32 0, i32 0
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l8, !tbaa !29
  %t50 = load ptr, ptr %l8, !tbaa !29
  %t52 = call i64 @compiler_2ffree_2ereadCall(ptr %v1, ptr %t50)
  store i64 %t52, ptr %l32
  br label %bb11
bb11:
  %t53 = load i64, ptr %l32, !tbaa !24
  store i64 %t53, ptr %l9, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l33, !tbaa !29
  %t55 = load i64, ptr %l9, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  br i1 %t57, label %bb12, label %bb13
bb12:
  %t59 = load i64, ptr %l9, !tbaa !24
  store i64 %t59, ptr %l36, !tbaa !24
  br label %bb14
bb13:
  %t61 = load i64, ptr %l3, !tbaa !24
  store i64 %t61, ptr %l36, !tbaa !24
  br label %bb14
bb14:
  %t63 = load i64, ptr %l36, !tbaa !24
  %t64 = load ptr, ptr %l33, !tbaa !29
  %t65 = getelementptr %"compiler/free:walker", ptr %t64, i32 0, i32 55
  store i64 %t63, ptr %t65, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l8, !tbaa !29
  %t70 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %s2, ptr %t66, ptr %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %l41
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb16:
  %t71 = load i64, ptr %l5, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l5, !tbaa !24
  br label %bb2
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load i64, ptr %l3, !tbaa !24
  %t80 = getelementptr %"compiler/free:walker", ptr %t76, i32 0, i32 55
  store i64 %t77, ptr %t80, !tbaa !24
  store ptr %l2, ptr %l47, !tbaa !29
  %t81 = load i64, ptr @G_2ecompiler_2ffree_2eONew, !tbaa !24
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/typed:Text", ptr %t82, i32 0, i32 1
  %t85 = load i32, ptr %t84, !tbaa !23
  %t87 = sext i32 %t85 to i64
  %t90 = call i64 @compiler_2ffree_2eorig(i64 %t81, i64 %t87)
  store i64 %t90, ptr %l52
  br label %bb18
bb18:
  %t91 = load ptr, ptr %l47, !tbaa !29
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = call i64 @compiler_2ffree_2eaddTo(ptr %v2, ptr %t91, i64 %t92)
  store i64 %t93, ptr %l53
  br label %bb19
bb19:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eturnLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 18
  %t7 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %t3, i64 %a1)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l7
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l6
  br label %bb1
bb1:
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %l2, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/free:walker", ptr %t13, i32 0, i32 30
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sge i64 %t17, %t16
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eunfollowed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i1
  %l16 = alloca ptr
  %l20 = alloca i1
  %l22 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i64
  %l43 = alloca i1
  %l47 = alloca i64
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca i64
  %l61 = alloca i64
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca %"compiler/source:Span"
  %l69 = alloca i1
  %l73 = alloca i1
  %l75 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l90 = alloca i64
  %l92 = alloca i1
  %l96 = alloca i1
  %l98 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l101 = alloca ptr
  %l102 = alloca i1
  %l108 = alloca i64
  %l110 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca ptr
  %l114 = alloca i1
  %l122 = alloca i64
  %l124 = alloca i1
  %l128 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca i64
  %l132 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca ptr
  %l136 = alloca i1
  %l142 = alloca i64
  %l145 = alloca i1
  %l150 = alloca i1
  %l152 = alloca i1
  %l154 = alloca ptr
  %l156 = alloca i32
  %l157 = alloca i1
  %l159 = alloca ptr
  %l161 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t2)
  store i32 %t4, ptr %l11
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i32, ptr %l11, !tbaa !23
  %t7 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownsStorage(ptr %v0, ptr %t5, i32 %t6)
  store i1 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i1, ptr %l12, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %ret
bb4:
  br label %bb5
bb5:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t14 = call ptr @compiler_2ftyped_2eCall_2eOf(ptr %v2, ptr %v2, ptr %t11)
  store ptr %t14, ptr %l16
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l16, !tbaa !29
  store ptr %t15, ptr %l4, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/free:walker", ptr %t22, i32 0, i32 0
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t26)
  store i64 %t28, ptr %l24
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb11
bb9:
  %t29 = load ptr, ptr %l22, !tbaa !29
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecopiedRet(ptr %v0, ptr %t29, i64 %t30)
  store i1 %t31, ptr %l25
  br label %bb10
bb10:
  %t32 = load i1, ptr %l25, !tbaa !21
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t35)
  store %"compiler/source:Span" %t37, ptr %l28
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/free:walker", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  store ptr %t41, ptr %l30, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = call i64 @compiler_2ftyped_2eCalleeBody(ptr %v2, ptr %t42)
  store i64 %t44, ptr %l32
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l30, !tbaa !29
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = call { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %s2, ptr %t45, i64 %t46)
  store { i64, ptr } %t47, ptr %l33
  br label %bb16
bb16:
  %t48 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t50 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 57, ptr getelementptr inbounds (<{ i64, [57 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t48, i64 %t49)
  %t58 = getelementptr i8, ptr %t57, i64 %t49
  call void @olang_textcopy(ptr %t58, ptr %t51, i64 %t52)
  %t59 = getelementptr i8, ptr %t58, i64 %t52
  call void @olang_textcopy(ptr %t59, ptr %t54, i64 %t55)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t57, 1
  %t63 = load ptr, ptr %l26, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l28
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egap(ptr %v0, ptr %s2, ptr %t63, %"compiler/source:Span" %t64, { i64, ptr } %t61)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/free:walker", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l37, !tbaa !29
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t72 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t70)
  store i32 %t72, ptr %l39
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l37, !tbaa !29
  %t74 = load i32, ptr %l39, !tbaa !23
  %t75 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFixedText(ptr %v0, ptr %t73, i32 %t74)
  store i64 %t75, ptr %l40
  br label %bb20
bb20:
  %t76 = load i64, ptr %l40, !tbaa !24
  store i64 %t76, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  br i1 %t79, label %bb21, label %bb22
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/free:walker", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t88 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t84, ptr %t85)
  store i64 %t88, ptr %l47
  br label %bb23
bb22:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb23:
  %t89 = load i64, ptr %l47, !tbaa !24
  %t90 = icmp slt i64 %t89, 0
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t92 = load i1, ptr %l43, !tbaa !21
  br i1 %t92, label %bb25, label %bb26
bb25:
  %t93 = load ptr, ptr %l2, !tbaa !29
  store ptr %t93, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t94 = load ptr, ptr %l50, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l49, !tbaa !21
  br label %bb34
bb27:
  %t97 = load ptr, ptr %l50, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 8}
  %t100 = icmp eq i64 %t98, 4
  store i1 %t100, ptr %l51, !tbaa !21
  br label %bb28
bb28:
  %t101 = load i1, ptr %l51, !tbaa !21
  br i1 %t101, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb33
bb30:
  %t102 = load ptr, ptr %l2, !tbaa !29
  store ptr %t102, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t103 = load ptr, ptr %l55, !tbaa !29
  %t104 = icmp ne ptr %t103, null
  br i1 %t104, label %bb31, label %bb32
bb31:
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = load i64, ptr %t106, !range !{i64 0, i64 8}
  %t109 = icmp eq i64 %t107, 3
  store i1 %t109, ptr %l56, !tbaa !21
  br label %bb32
bb32:
  %t110 = load i1, ptr %l56, !tbaa !21
  store i1 %t110, ptr %l54, !tbaa !21
  br label %bb33
bb33:
  %t111 = load i1, ptr %l54, !tbaa !21
  store i1 %t111, ptr %l49, !tbaa !21
  br label %bb34
bb34:
  %t112 = load i1, ptr %l49, !tbaa !21
  br i1 %t112, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l59, !tbaa !29
  %t114 = load i64, ptr %l5, !tbaa !24
  store i64 %t114, ptr %l60, !tbaa !24
  %t115 = load i64, ptr @G_2ecompiler_2ffree_2eLAssign, !tbaa !24
  store i64 %t115, ptr %l61, !tbaa !24
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t116)
  store %"compiler/source:Span" %t118, ptr %l63
  br label %bb37
bb36:
  br label %bb51
bb37:
  %t119 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 0, i32 0)
  store %"compiler/source:Span" %t119, ptr %l64
  br label %bb38
bb38:
  %t120 = load i64, ptr @G_2ecompiler_2ffree_2eWalkNone, !tbaa !24
  %t121 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t122 = load ptr, ptr %l59, !tbaa !29
  %t123 = load i64, ptr %l60, !tbaa !24
  %t124 = load i64, ptr %l61, !tbaa !24
  %t125 = load %"compiler/source:Span", ptr %l63
  %t126 = load %"compiler/source:Span", ptr %l64
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %t122, i64 %t123, i64 %t124, %"compiler/source:Span" %t125, %"compiler/source:Span" %t126, i64 -1, i1 false, i64 %t120, i32 %t121)
  br label %bb39
bb39:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/free:walker", ptr %t129, i32 0, i32 2
  %t132 = load i1, ptr %t131, !tbaa !21
  br i1 %t132, label %bb40, label %bb41
bb40:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/free:walker", ptr %t134, i32 0, i32 36
  %t137 = load i64, ptr %t136, !tbaa !24
  %t139 = icmp eq i64 %t137, 0
  store i1 %t139, ptr %l69, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb42
bb42:
  %t141 = load i1, ptr %l69, !tbaa !21
  br i1 %t141, label %bb43, label %bb44
bb43:
  %t142 = load ptr, ptr %l3, !tbaa !29
  %t144 = call i1 @compiler_2ffree_2efillOf(ptr %v2, ptr %t142)
  store i1 %t144, ptr %l75
  br label %bb45
bb44:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb46
bb45:
  %t145 = load i1, ptr %l75, !tbaa !21
  %t146 = xor i1 %t145, true
  store i1 %t146, ptr %l73, !tbaa !21
  br label %bb46
bb46:
  %t148 = load i1, ptr %l73, !tbaa !21
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i64, ptr %l5, !tbaa !24
  %t151 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v2, ptr %t149, i64 %t150, ptr %t151, %"compiler/source:Span" %a1, i1 false)
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb51:
  %t157 = load ptr, ptr %l2, !tbaa !29
  store ptr %t157, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t158 = load ptr, ptr %l81, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb52, label %bb53
bb52:
  %t161 = load ptr, ptr %l81, !tbaa !29
  %t162 = load i64, ptr %t161, !range !{i64 0, i64 8}
  %t164 = icmp eq i64 %t162, 0
  store i1 %t164, ptr %l82, !tbaa !21
  br label %bb53
bb53:
  %t165 = load i1, ptr %l82, !tbaa !21
  br i1 %t165, label %bb54, label %bb55
bb54:
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t168, i32 0, i32 2
  %t170 = load i32, ptr %t169
  store i32 %t170, ptr %l6, !tbaa !23
  br label %bb56
bb55:
  br label %bb67
bb56:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l6, !tbaa !23
  %t175 = sext i32 %t173 to i64
  %t178 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %t172, i64 %t175)
  store i64 %t178, ptr %l90
  br label %bb57
bb57:
  %t179 = load i64, ptr %l90, !tbaa !24
  %t180 = icmp slt i64 %t179, 0
  br i1 %t180, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l6, !tbaa !23
  %t185 = sext i32 %t183 to i64
  %t188 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eturnLocal(ptr %v0, ptr %t182, i64 %t185)
  store i1 %t188, ptr %l96
  br label %bb60
bb59:
  store i1 false, ptr %l92, !tbaa !21
  br label %bb61
bb60:
  %t189 = load i1, ptr %l96, !tbaa !21
  %t190 = xor i1 %t189, true
  store i1 %t190, ptr %l92, !tbaa !21
  br label %bb61
bb61:
  %t192 = load i1, ptr %l92, !tbaa !21
  br i1 %t192, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s7
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l98, !tbaa !29
  %t194 = load ptr, ptr %l2, !tbaa !29
  %t196 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t194)
  store %"compiler/source:Span" %t196, ptr %l100
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t197 = load ptr, ptr %l98, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l100
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egap(ptr %v0, ptr %s7, ptr %t197, %"compiler/source:Span" %t198, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s7)
  br label %bb66
bb66:
  br label %bb122
bb67:
  %t199 = load ptr, ptr %l2, !tbaa !29
  store ptr %t199, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t200 = load ptr, ptr %l101, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb68, label %bb69
bb68:
  %t203 = load ptr, ptr %l101, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 8}
  %t206 = icmp eq i64 %t204, 1
  store i1 %t206, ptr %l102, !tbaa !21
  br label %bb69
bb69:
  %t207 = load i1, ptr %l102, !tbaa !21
  br i1 %t207, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb79
bb72:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/free:walker", ptr %t208, i32 0, i32 0
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t212 = load ptr, ptr %l2, !tbaa !29
  %t215 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t211, ptr %t212)
  store i64 %t215, ptr %l108
  br label %bb73
bb73:
  %t216 = load i64, ptr %l108, !tbaa !24
  %t217 = icmp slt i64 %t216, 0
  br i1 %t217, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s9
  %t219 = load ptr, ptr %l0, !tbaa !29
  store ptr %t219, ptr %l110, !tbaa !29
  %t220 = load ptr, ptr %l2, !tbaa !29
  %t222 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t220)
  store %"compiler/source:Span" %t222, ptr %l112
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t223 = load ptr, ptr %l110, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l112
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egap(ptr %v0, ptr %s9, ptr %t223, %"compiler/source:Span" %t224, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s9)
  br label %bb78
bb78:
  br label %bb122
bb79:
  %t225 = load ptr, ptr %l2, !tbaa !29
  store ptr %t225, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t226 = load ptr, ptr %l113, !tbaa !29
  %t227 = icmp ne ptr %t226, null
  br i1 %t227, label %bb80, label %bb81
bb80:
  %t229 = load ptr, ptr %l113, !tbaa !29
  %t230 = load i64, ptr %t229, !range !{i64 0, i64 8}
  %t232 = icmp eq i64 %t230, 3
  store i1 %t232, ptr %l114, !tbaa !21
  br label %bb81
bb81:
  %t233 = load i1, ptr %l114, !tbaa !21
  br i1 %t233, label %bb82, label %bb83
bb82:
  %t234 = load ptr, ptr %l2, !tbaa !29
  %t236 = getelementptr { i64, [4 x i64] }, ptr %t234, i32 0, i32 1
  %t237 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t236, i32 0, i32 1
  %t238 = load i32, ptr %t237
  store i32 %t238, ptr %l7, !tbaa !23
  br label %bb84
bb83:
  br label %bb96
bb84:
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/free:walker", ptr %t240, i32 0, i32 0
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t244 = load ptr, ptr %l2, !tbaa !29
  %t247 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t243, ptr %t244)
  store i64 %t247, ptr %l122
  br label %bb85
bb85:
  %t248 = load i64, ptr %l122, !tbaa !24
  %t249 = icmp slt i64 %t248, 0
  br i1 %t249, label %bb86, label %bb87
bb86:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr %"compiler/free:walker", ptr %t251, i32 0, i32 0
  %t254 = load ptr, ptr %t253, !tbaa !29
  %t255 = load i32, ptr %l7, !tbaa !23
  %t258 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v0, ptr %t254, i32 %t255)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t258, ptr %l128
  br label %bb88
bb87:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb90
bb88:
  %t260 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %l128)
  store i64 %t260, ptr %l130
  br label %bb89
bb89:
  %t261 = load i64, ptr %l130, !tbaa !24
  %t262 = icmp eq i64 %t261, 0
  store i1 %t262, ptr %l124, !tbaa !21
  br label %bb90
bb90:
  %t264 = load i1, ptr %l124, !tbaa !21
  br i1 %t264, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s11
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l132, !tbaa !29
  %t266 = load ptr, ptr %l2, !tbaa !29
  %t268 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t266)
  store %"compiler/source:Span" %t268, ptr %l134
  br label %bb93
bb92:
  br label %bb95
bb93:
  %t269 = load ptr, ptr %l132, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l134
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egap(ptr %v0, ptr %s11, ptr %t269, %"compiler/source:Span" %t270, { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s11)
  br label %bb95
bb95:
  br label %bb122
bb96:
  %t271 = load ptr, ptr %l2, !tbaa !29
  store ptr %t271, ptr %l135, !tbaa !29
  store i1 false, ptr %l136, !tbaa !21
  %t272 = load ptr, ptr %l135, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb97, label %bb98
bb97:
  %t275 = load ptr, ptr %l135, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 8}
  %t278 = icmp eq i64 %t276, 4
  store i1 %t278, ptr %l136, !tbaa !21
  br label %bb98
bb98:
  %t279 = load i1, ptr %l136, !tbaa !21
  br i1 %t279, label %bb99, label %bb100
bb99:
  br label %bb101
bb100:
  br label %bb117
bb101:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr %"compiler/free:walker", ptr %t280, i32 0, i32 0
  %t283 = load ptr, ptr %t282, !tbaa !29
  %t284 = load ptr, ptr %l2, !tbaa !29
  %t287 = call i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %t283, ptr %t284)
  store i64 %t287, ptr %l142
  br label %bb102
bb102:
  %t288 = load i64, ptr %l142, !tbaa !24
  store i64 %t288, ptr %l8, !tbaa !24
  %t289 = load i64, ptr %l8, !tbaa !24
  %t291 = icmp slt i64 %t289, 0
  br i1 %t291, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb106
bb104:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr %"compiler/free:walker", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/free:Free", ptr %t296, i32 0, i32 13
  %t299 = load i64, ptr %l8, !tbaa !24
  %t302 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t298, i64 %t299)
  store i1 %t302, ptr %l150
  br label %bb105
bb105:
  %t303 = load i1, ptr %l150, !tbaa !21
  %t304 = xor i1 %t303, true
  store i1 %t304, ptr %l145, !tbaa !21
  br label %bb106
bb106:
  %t306 = load i1, ptr %l145, !tbaa !21
  br i1 %t306, label %bb107, label %bb108
bb107:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/free:walker", ptr %t307, i32 0, i32 0
  %t310 = load ptr, ptr %t309, !tbaa !29
  store ptr %t310, ptr %l154, !tbaa !29
  %t311 = load ptr, ptr %l2, !tbaa !29
  %t313 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t311)
  store i32 %t313, ptr %l156
  br label %bb109
bb108:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb111
bb109:
  %t314 = load ptr, ptr %l154, !tbaa !29
  %t315 = load i32, ptr %l156, !tbaa !23
  %t316 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %t314, i32 %t315)
  store i1 %t316, ptr %l157
  br label %bb110
bb110:
  %t317 = load i1, ptr %l157, !tbaa !21
  %t318 = xor i1 %t317, true
  store i1 %t318, ptr %l152, !tbaa !21
  br label %bb111
bb111:
  %t320 = load i1, ptr %l152, !tbaa !21
  br i1 %t320, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s13
  %t321 = load ptr, ptr %l0, !tbaa !29
  store ptr %t321, ptr %l159, !tbaa !29
  %t322 = load ptr, ptr %l2, !tbaa !29
  %t324 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v1, ptr %t322)
  store %"compiler/source:Span" %t324, ptr %l161
  br label %bb114
bb113:
  br label %bb116
bb114:
  %t325 = load ptr, ptr %l159, !tbaa !29
  %t326 = load %"compiler/source:Span", ptr %l161
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egap(ptr %v0, ptr %s13, ptr %t325, %"compiler/source:Span" %t326, { i64, ptr } { i64 32, ptr getelementptr inbounds (<{ i64, [32 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb115
bb115:
  call void @__olang_scope_close(ptr %s13)
  br label %bb116
bb116:
  br label %bb122
bb117:
  br i1 true, label %bb118, label %bb119
bb118:
  br label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_be89b37fd0a92d53_2c5aa2623b5da4df)
  unreachable
bb122:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euse(ptr %v0, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 36
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/free:walker", ptr %t8, i32 0, i32 31
  %t11 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t10, i64 %t11)
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/free:walker", ptr %t14, i32 0, i32 32
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/free:walker", ptr %t17, i32 0, i32 15
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t16, i64 %t20)
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/free:walker", ptr %t23, i32 0, i32 33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t25, %"compiler/source:Span" %a2)
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/free:walker", ptr %t29, i32 0, i32 35
  %t32 = load i64, ptr %t31, !tbaa !24
  %t34 = icmp sgt i64 %t32, 0
  br i1 %t34, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/free:walker", ptr %t36, i32 0, i32 34
  %t39 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t38, i64 %t39)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eusedAfter(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca i64
  %l40 = alloca i64
  %l48 = alloca i64
  %l52 = alloca i64
  %l55 = alloca i64
  %l76 = alloca i64
  %l80 = alloca i1
  %l81 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i1
  %l92 = alloca i64
  %l96 = alloca i64
  %l98 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l108 = alloca i64
  %l110 = alloca i1
  %l114 = alloca i64
  %l118 = alloca i64
  %l130 = alloca i1
  %l131 = alloca i1
  %l133 = alloca i64
  %l136 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 24
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t3, i64 %t4)
  store i64 %t7, ptr %l20
  br label %bb1
bb1:
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l20, !tbaa !24
  %t11 = icmp sgt i64 %t9, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l3, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l5, !tbaa !24
  store i64 %t16, ptr %l25, !tbaa !24
  %t17 = load ptr, ptr %l4, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t17)
  store i64 %t19, ptr %l27
  br label %bb6
bb6:
  %t20 = load i64, ptr %l25, !tbaa !24
  %t21 = load i64, ptr %l27, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  br label %bb17
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i64, ptr %l5, !tbaa !24
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l32
  br label %bb10
bb10:
  %t31 = load i64, ptr %l32, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/free:walker", ptr %t32, i32 0, i32 32
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  store i64 %t38, ptr %l36
  br label %bb11
bb11:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/free:walker", ptr %t39, i32 0, i32 16
  %t42 = load i64, ptr %l2, !tbaa !24
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t41, i64 %t42)
  store i64 %t45, ptr %l40
  br label %bb12
bb12:
  %t46 = load i64, ptr %l36, !tbaa !24
  %t47 = load i64, ptr %l40, !tbaa !24
  %t48 = icmp sgt i64 %t46, %t47
  br i1 %t48, label %bb13, label %bb14
bb13:
  %t50 = load i64, ptr %l6, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = add i64 %t52, 1
  store i64 %t55, ptr %l5, !tbaa !24
  br label %bb5
bb17:
  store i64 0, ptr %l7, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/free:walker", ptr %t57, i32 0, i32 17
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t59)
  store i64 %t61, ptr %l48
  br label %bb18
bb18:
  %t62 = load i64, ptr %l48, !tbaa !24
  store i64 %t62, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t67 = icmp sgt i64 %t63, %t64
  br i1 %t67, label %bb19, label %bb20
bb19:
  %t69 = load i64, ptr %l9, !tbaa !24
  %t71 = icmp sgt i64 %t69, 0
  br i1 %t71, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb24
bb21:
  %t73 = load i64, ptr %l8, !tbaa !24
  %t74 = load i64, ptr %l7, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t78 = load i64, ptr %l9, !tbaa !24
  %t81 = add i64 %t77, %t78
  %t83 = sub i64 %t81, 1
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = sdiv i64 %t83, %t84
  store i64 %t87, ptr %l55, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb23
bb23:
  %t89 = load i64, ptr %l55, !tbaa !24
  store i64 %t89, ptr %l52, !tbaa !24
  br label %bb24
bb24:
  %t90 = load i64, ptr %l52, !tbaa !24
  store i64 %t90, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb25
bb25:
  %t91 = load i64, ptr %l11, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t95 = icmp slt i64 %t91, %t92
  %t97 = xor i1 %t95, true
  br i1 %t97, label %bb26, label %bb27
bb26:
  br label %bb59
bb27:
  br label %bb28
bb28:
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load i64, ptr %l11, !tbaa !24
  %t101 = load i64, ptr %l9, !tbaa !24
  %t104 = mul i64 %t100, %t101
  %t107 = add i64 %t99, %t104
  store i64 %t107, ptr %l12, !tbaa !24
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/free:walker", ptr %t109, i32 0, i32 17
  %t112 = load i64, ptr %l12, !tbaa !24
  %t115 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t111, i64 %t112)
  store i64 %t115, ptr %l76
  br label %bb29
bb29:
  %t116 = load i64, ptr %l76, !tbaa !24
  store i64 %t116, ptr %l13, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l2, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  br i1 %t121, label %bb30, label %bb31
bb30:
  %t123 = load i64, ptr %l2, !tbaa !24
  store i64 %t123, ptr %l81, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/free:walker", ptr %t124, i32 0, i32 19
  %t127 = load i64, ptr %l12, !tbaa !24
  %t130 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t126, i64 %t127)
  store i64 %t130, ptr %l85
  br label %bb32
bb31:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb33
bb32:
  %t131 = load i64, ptr %l81, !tbaa !24
  %t132 = load i64, ptr %l85, !tbaa !24
  %t133 = icmp sle i64 %t131, %t132
  store i1 %t133, ptr %l80, !tbaa !21
  br label %bb33
bb33:
  %t135 = load i1, ptr %l80, !tbaa !21
  %t136 = xor i1 %t135, true
  br i1 %t136, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb37
bb35:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/free:walker", ptr %t138, i32 0, i32 24
  %t141 = load i64, ptr %l1, !tbaa !24
  %t144 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t140, i64 %t141)
  store i64 %t144, ptr %l92
  br label %bb36
bb36:
  %t145 = load i64, ptr %l13, !tbaa !24
  %t146 = load i64, ptr %l92, !tbaa !24
  %t148 = icmp sgt i64 %t146, %t145
  store i1 %t148, ptr %l88, !tbaa !21
  br label %bb37
bb37:
  %t150 = load i1, ptr %l88, !tbaa !21
  br i1 %t150, label %bb38, label %bb39
bb38:
  br label %bb58
bb39:
  br label %bb40
bb40:
  %t151 = load ptr, ptr %l3, !tbaa !29
  store ptr %t151, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb41
bb41:
  %t153 = load i64, ptr %l15, !tbaa !24
  store i64 %t153, ptr %l96, !tbaa !24
  %t154 = load ptr, ptr %l14, !tbaa !29
  %t156 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t154)
  store i64 %t156, ptr %l98
  br label %bb42
bb42:
  %t157 = load i64, ptr %l96, !tbaa !24
  %t158 = load i64, ptr %l98, !tbaa !24
  %t159 = icmp slt i64 %t157, %t158
  %t161 = xor i1 %t159, true
  br i1 %t161, label %bb43, label %bb44
bb43:
  br label %bb57
bb44:
  br label %bb45
bb45:
  %t163 = load ptr, ptr %l14, !tbaa !29
  %t164 = load i64, ptr %l15, !tbaa !24
  %t167 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t163, i64 %t164)
  store i64 %t167, ptr %l103
  br label %bb46
bb46:
  %t168 = load i64, ptr %l103, !tbaa !24
  store i64 %t168, ptr %l16, !tbaa !24
  %t169 = load i64, ptr %l13, !tbaa !24
  store i64 %t169, ptr %l104, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/free:walker", ptr %t170, i32 0, i32 32
  %t173 = load i64, ptr %l16, !tbaa !24
  %t176 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t172, i64 %t173)
  store i64 %t176, ptr %l108
  br label %bb47
bb47:
  %t177 = load i64, ptr %l104, !tbaa !24
  %t178 = load i64, ptr %l108, !tbaa !24
  %t179 = icmp slt i64 %t177, %t178
  br i1 %t179, label %bb48, label %bb49
bb48:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = getelementptr %"compiler/free:walker", ptr %t181, i32 0, i32 32
  %t184 = load i64, ptr %l16, !tbaa !24
  %t187 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t183, i64 %t184)
  store i64 %t187, ptr %l114
  br label %bb50
bb49:
  store i1 false, ptr %l110, !tbaa !21
  br label %bb52
bb50:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:walker", ptr %t188, i32 0, i32 19
  %t191 = load i64, ptr %l12, !tbaa !24
  %t194 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t190, i64 %t191)
  store i64 %t194, ptr %l118
  br label %bb51
bb51:
  %t195 = load i64, ptr %l114, !tbaa !24
  %t196 = load i64, ptr %l118, !tbaa !24
  %t197 = icmp sle i64 %t195, %t196
  store i1 %t197, ptr %l110, !tbaa !21
  br label %bb52
bb52:
  %t199 = load i1, ptr %l110, !tbaa !21
  br i1 %t199, label %bb53, label %bb54
bb53:
  %t200 = load i64, ptr %l16, !tbaa !24
  store i64 %t200, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  br label %bb56
bb56:
  %t202 = load i64, ptr %l15, !tbaa !24
  %t205 = add i64 %t202, 1
  store i64 %t205, ptr %l15, !tbaa !24
  br label %bb41
bb57:
  br label %bb58
bb58:
  %t207 = load i64, ptr %l11, !tbaa !24
  %t210 = add i64 %t207, 1
  store i64 %t210, ptr %l11, !tbaa !24
  br label %bb25
bb59:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/free:walker", ptr %t212, i32 0, i32 34
  %t215 = load i64, ptr %l1, !tbaa !24
  %t218 = call i1 @compiler_2ffree_2ehas(ptr %v0, ptr %t214, i64 %t215)
  store i1 %t218, ptr %l130
  br label %bb60
bb60:
  %t219 = load i1, ptr %l130, !tbaa !21
  br i1 %t219, label %bb61, label %bb62
bb61:
  %t220 = load ptr, ptr %l3, !tbaa !29
  %t222 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t220)
  store i64 %t222, ptr %l133
  br label %bb63
bb62:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb64
bb63:
  %t223 = load i64, ptr %l133, !tbaa !24
  %t224 = icmp sgt i64 %t223, 0
  store i1 %t224, ptr %l131, !tbaa !21
  br label %bb64
bb64:
  %t226 = load i1, ptr %l131, !tbaa !21
  br i1 %t226, label %bb65, label %bb66
bb65:
  %t227 = load ptr, ptr %l3, !tbaa !29
  %t229 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t227, i64 0)
  store i64 %t229, ptr %l136
  br label %bb67
bb66:
  br label %bb68
bb67:
  %t230 = load i64, ptr %l136, !tbaa !24
  store i64 %t230, ptr %rv
  br label %ret
bb68:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2evalueCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l21 = alloca i1
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l44 = alloca i64
  %l48 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i64
  %l55 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca i32
  %l102 = alloca i64
  %l112 = alloca i64
  %l114 = alloca i64
  %l119 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l120 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l121 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l137 = alloca i64
  %l142 = alloca i1
  %l144 = alloca ptr
  %l146 = alloca i1
  %l147 = alloca i1
  %l156 = alloca ptr
  %l158 = alloca i1
  %l159 = alloca i1
  %l162 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store %"compiler/source:Span" %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l25, !tbaa !24
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v3, ptr %t9)
  store i64 %t11, ptr %l27
  br label %bb2
bb2:
  %t12 = load i64, ptr %l25, !tbaa !24
  %t13 = load i64, ptr %l27, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = load i64, ptr %l8, !tbaa !24
  %t22 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v3, ptr %v3, ptr %t18, i64 %t19)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %l32
  br label %bb6
bb6:
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l33
  %t24 = call ptr @__olang_scope_hold(ptr %s2)
  %t25 = ptrtoint ptr %t24 to i64
  store i64 %t25, ptr %l34, !tbaa !24
  %t26 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = call ptr @__olang_region_make_part(ptr %s2)
  %t29 = ptrtoint ptr %t28 to i64
  store i64 %t29, ptr %l34, !tbaa !24
  br label %bb8
bb8:
  %t30 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l36, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l37, !tbaa !24
  %t34 = load i64, ptr %l37, !tbaa !24
  %t35 = mul i64 %t34, 8
  %t36 = load i64, ptr %l34
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = call ptr @__olang_held_alloc(ptr %t37, i64 %t35)
  %t39 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l38, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l37, !tbaa !24
  %t46 = mul i64 %t45, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t48 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  store { i64, ptr } %t47, ptr %t48, !tbaa !27
  %t49 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t55 = icmp eq i64 %t53, 0
  br i1 %t55, label %bb11, label %bb12
bb10:
  %t57 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l9
  %t58 = load ptr, ptr %l5, !tbaa !29
  %t61 = call i64 @compiler_2ffree_2eaddAllTo(ptr %v4, ptr %s2, ptr %t58, ptr %l9)
  store i64 %t61, ptr %l44
  br label %bb13
bb11:
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t62, !tbaa !27
  br label %bb12
bb12:
  %t63 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l33, i32 0, i32 0
  %t64 = load i64, ptr %l34
  %t65 = inttoptr i64 %t64 to ptr
  %t66 = load { i64, ptr }, ptr %t63
  %t67 = extractvalue { i64, ptr } %t66, 1
  %t68 = call ptr @__olang_region_or(ptr %t67, ptr null)
  %t69 = icmp ne ptr %t68, null
  %t70 = select i1 %t69, ptr %t68, ptr null
  call void @__olang_region_settle_in(ptr %t65, ptr %t70)
  br label %bb10
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t74 = add i64 %t71, 1
  store i64 %t74, ptr %l8, !tbaa !24
  br label %bb1
bb15:
  %t76 = load ptr, ptr %l5, !tbaa !29
  store ptr %t76, ptr %l48, !tbaa !29
  %t77 = load i64, ptr @G_2ecompiler_2ffree_2eOUnk, !tbaa !24
  %t79 = call i64 @compiler_2ffree_2eorig(i64 %t77, i64 0)
  store i64 %t79, ptr %l50
  br label %bb16
bb16:
  %t80 = load ptr, ptr %l48, !tbaa !29
  %t81 = load i64, ptr %l50, !tbaa !24
  %t82 = call i64 @compiler_2ffree_2eaddTo(ptr %v4, ptr %t80, i64 %t81)
  store i64 %t82, ptr %l51
  br label %bb17
bb17:
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/typed:Call", ptr %t83, i32 0, i32 2
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = icmp sge i32 %t86, 0
  br i1 %t88, label %bb18, label %bb19
bb18:
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t92 = getelementptr %"compiler/free:Free", ptr %t90, i32 0, i32 2
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/free:walker", ptr %t94, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !24
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/typed:Call", ptr %t98, i32 0, i32 2
  %t101 = load i32, ptr %t100, !tbaa !23
  %t103 = sext i32 %t101 to i64
  %t107 = call { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueRecsAt(ptr %v0, ptr %s0, ptr %t93, i64 %t97, i64 %t103)
  store { i64, ptr } %t107, ptr %l63
  br label %bb20
bb19:
  %t108 = icmp sge i64 0, 0
  br i1 %t108, label %bb21, label %bb22
bb20:
  %t110 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l64, !tbaa !24
  %t112 = load i64, ptr %l64, !tbaa !24
  %t113 = mul i64 %t112, 8
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  %t115 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l65, !tbaa !27
  %t117 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = load i64, ptr %l64, !tbaa !24
  %t122 = mul i64 %t121, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t118, ptr %t120, i64 %t122, i1 false)
  %t123 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t123, ptr %l55, !tbaa !27
  br label %bb25
bb21:
  %t124 = icmp sle i64 0, 1152921504606846975
  br i1 %t124, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_afd3b4561806d30e_4841abb84b9127fa)
  unreachable
bb23:
  %t126 = mul i64 0, 8
  %t127 = insertvalue { i64, ptr } undef, i64 0, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t128, ptr %l55, !tbaa !27
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_afd3b4561806d30e_4841abb84b9127fa)
  unreachable
bb25:
  %t130 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 0
  store i64 %t131, ptr %l69, !tbaa !24
  %t132 = load i64, ptr %l69, !tbaa !24
  %t133 = mul i64 %t132, 8
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  %t135 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t136 = insertvalue { i64, ptr } %t135, ptr %t134, 1
  store { i64, ptr } %t136, ptr %l70, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = load i64, ptr %l69, !tbaa !24
  %t142 = mul i64 %t141, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t138, ptr %t140, i64 %t142, i1 false)
  %t143 = load { i64, ptr }, ptr %l70, !tbaa !27
  store { i64, ptr } %t143, ptr %l10, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t144, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  store i64 %t148, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t151 = load i64, ptr %l13, !tbaa !24
  %t154 = icmp slt i64 %t150, %t151
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t158, ptr %l78, !tbaa !27
  %t159 = load i64, ptr %l12, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr i64, ptr %t162, i64 %t159
  %t164 = load i64, ptr %t163, !tbaa !34
  store i64 %t164, ptr %l14, !tbaa !24
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load i64, ptr %l14, !tbaa !24
  %t170 = ashr i64 %t168, 1
  %t171 = load i64, ptr %l14, !tbaa !24
  %t173 = and i64 %t171, 1
  %t174 = load ptr, ptr %l3, !tbaa !29
  %t175 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2easRecord(ptr %v0, ptr %v1, ptr %v3, ptr %t166, ptr %t167, i64 %t170, i64 %t173, ptr %t174, %"compiler/source:Span" %t175)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l12, !tbaa !24
  br label %bb26
bb32:
  %t187 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t191 = icmp sgt i64 %t189, 0
  br i1 %t191, label %bb33, label %bb34
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb34:
  br label %bb35
bb35:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t193)
  store ptr %t195, ptr %l96
  br label %bb36
bb36:
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t198 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t196)
  store i32 %t198, ptr %l98
  br label %bb37
bb37:
  %t199 = load ptr, ptr %l96, !tbaa !29
  %t200 = load i32, ptr %l98, !tbaa !23
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t199, i32 %t200)
  store i32 %t201, ptr %l99
  br label %bb38
bb38:
  %t202 = load i32, ptr %l99, !tbaa !23
  store i32 %t202, ptr %l15, !tbaa !23
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t207 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedParam(ptr %v0, ptr %v2, ptr %t203, ptr %t204)
  store i64 %t207, ptr %l102
  br label %bb39
bb39:
  %t208 = load i64, ptr %l102, !tbaa !24
  store i64 %t208, ptr %l16, !tbaa !24
  %t209 = load i64, ptr %l16, !tbaa !24
  %t211 = icmp sge i64 %t209, 0
  br i1 %t211, label %bb40, label %bb41
bb40:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t215 = load i32, ptr %l15, !tbaa !23
  %t216 = load i64, ptr %l16, !tbaa !24
  %t217 = load ptr, ptr %l3, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ethroughParam(ptr %v0, ptr %v1, ptr %v3, ptr %t213, ptr %t214, i32 %t215, i64 %t216, ptr %t217, %"compiler/source:Span" %t218)
  br label %bb42
bb41:
  br label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb43:
  %t225 = load ptr, ptr %l3, !tbaa !29
  store ptr %t225, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t227 = load i64, ptr %l18, !tbaa !24
  store i64 %t227, ptr %l112, !tbaa !24
  %t228 = load ptr, ptr %l17, !tbaa !29
  %t230 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v3, ptr %t228)
  store i64 %t230, ptr %l114
  br label %bb45
bb45:
  %t231 = load i64, ptr %l112, !tbaa !24
  %t232 = load i64, ptr %l114, !tbaa !24
  %t233 = icmp slt i64 %t231, %t232
  %t235 = xor i1 %t233, true
  br i1 %t235, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s10)
  br label %bb58
bb47:
  br label %bb48
bb48:
  %t237 = load ptr, ptr %l17, !tbaa !29
  %t238 = load i64, ptr %l18, !tbaa !24
  %t241 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v3, ptr %v3, ptr %t237, i64 %t238)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t241, ptr %l119
  br label %bb49
bb49:
  %t242 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l119
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t242, ptr %l120
  %t243 = call ptr @__olang_scope_hold(ptr %s10)
  %t244 = ptrtoint ptr %t243 to i64
  store i64 %t244, ptr %l121, !tbaa !24
  %t245 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t245, label %bb50, label %bb51
bb50:
  %t247 = call ptr @__olang_region_make_part(ptr %s10)
  %t248 = ptrtoint ptr %t247 to i64
  store i64 %t248, ptr %l121, !tbaa !24
  br label %bb51
bb51:
  %t249 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120, i32 0, i32 0
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !27
  store { i64, ptr } %t250, ptr %l123, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  store i64 %t252, ptr %l124, !tbaa !24
  %t253 = load i64, ptr %l124, !tbaa !24
  %t254 = mul i64 %t253, 8
  %t255 = load i64, ptr %l121
  %t256 = inttoptr i64 %t255 to ptr
  %t257 = call ptr @__olang_held_alloc(ptr %t256, i64 %t254)
  %t258 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t257, 1
  store { i64, ptr } %t259, ptr %l125, !tbaa !27
  %t260 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = load i64, ptr %l124, !tbaa !24
  %t265 = mul i64 %t264, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t261, ptr %t263, i64 %t265, i1 false)
  %t266 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t267 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120, i32 0, i32 0
  store { i64, ptr } %t266, ptr %t267, !tbaa !27
  %t268 = load i1, ptr @olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0
  br i1 %t268, label %bb52, label %bb53
bb52:
  %t270 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120, i32 0, i32 0
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  %t274 = icmp eq i64 %t272, 0
  br i1 %t274, label %bb54, label %bb55
bb53:
  %t276 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t276, ptr %l19
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %s10, ptr %s10, ptr %t277, ptr %l19, %"compiler/source:Span" %t278, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d51, i32 0, i32 1) }, i1 false, i64 -1, i64 -1)
  br label %bb56
bb54:
  %t282 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t282, !tbaa !27
  br label %bb55
bb55:
  %t283 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120, i32 0, i32 0
  %t284 = load i64, ptr %l121
  %t285 = inttoptr i64 %t284 to ptr
  %t286 = load { i64, ptr }, ptr %t283
  %t287 = extractvalue { i64, ptr } %t286, 1
  %t288 = call ptr @__olang_region_or(ptr %t287, ptr null)
  %t289 = icmp ne ptr %t288, null
  %t290 = select i1 %t289, ptr %t288, ptr null
  call void @__olang_region_settle_in(ptr %t285, ptr %t290)
  br label %bb53
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  %t291 = load i64, ptr %l18, !tbaa !24
  %t294 = add i64 %t291, 1
  store i64 %t294, ptr %l18, !tbaa !24
  br label %bb44
bb58:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load ptr, ptr %l2, !tbaa !29
  %t300 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedCapture(ptr %v0, ptr %v2, ptr %t296, ptr %t297)
  store i64 %t300, ptr %l137
  br label %bb59
bb59:
  %t301 = load i64, ptr %l137, !tbaa !24
  store i64 %t301, ptr %l20, !tbaa !24
  %t302 = load i64, ptr %l20, !tbaa !24
  %t304 = icmp sge i64 %t302, 0
  br i1 %t304, label %bb60, label %bb61
bb60:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t310 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emayWrite(ptr %v0, ptr %v1, ptr %t306, ptr %t307)
  store i1 %t310, ptr %l142
  br label %bb62
bb61:
  br label %bb72
bb62:
  %t311 = load i1, ptr %l142, !tbaa !21
  store i1 %t311, ptr %l21, !tbaa !21
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t312)
  store ptr %t314, ptr %l144
  br label %bb63
bb63:
  %t315 = load i32, ptr %l15, !tbaa !23
  %t316 = load ptr, ptr %l144, !tbaa !29
  %t318 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %t316, i32 %t315)
  store i1 %t318, ptr %l146
  br label %bb64
bb64:
  %t319 = load i1, ptr %l146, !tbaa !21
  br i1 %t319, label %bb65, label %bb66
bb65:
  %t320 = load i1, ptr %l21, !tbaa !21
  %t322 = xor i1 %t320, true
  store i1 %t322, ptr %l147, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb67
bb67:
  %t324 = load i1, ptr %l147, !tbaa !21
  %t325 = xor i1 %t324, true
  br i1 %t325, label %bb68, label %bb69
bb68:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i64, ptr %l20, !tbaa !24
  %t329 = load i1, ptr %l21, !tbaa !21
  %t330 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ethroughCapture(ptr %v0, ptr %t327, i64 %t328, i1 %t329, %"compiler/source:Span" %t330)
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb72:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = call ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v0, ptr %t335)
  store ptr %t337, ptr %l156
  br label %bb73
bb73:
  %t338 = load i32, ptr %l15, !tbaa !23
  %t339 = load ptr, ptr %l156, !tbaa !29
  %t341 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %t339, i32 %t338)
  store i1 %t341, ptr %l158
  br label %bb74
bb74:
  %t342 = load i1, ptr %l158, !tbaa !21
  br i1 %t342, label %bb75, label %bb76
bb75:
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l1, !tbaa !29
  %t347 = call i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emayWrite(ptr %v0, ptr %v1, ptr %t343, ptr %t344)
  store i1 %t347, ptr %l162
  br label %bb77
bb76:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb78
bb77:
  %t348 = load i1, ptr %l162, !tbaa !21
  %t349 = xor i1 %t348, true
  store i1 %t349, ptr %l159, !tbaa !21
  br label %bb78
bb78:
  %t351 = load i1, ptr %l159, !tbaa !21
  %t352 = xor i1 %t351, true
  br i1 %t352, label %bb79, label %bb80
bb79:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t355 = load %"compiler/source:Span", ptr %l4
  %t356 = load ptr, ptr %l1, !tbaa !29
  %t357 = load i64, ptr @G_2ecompiler_2ffree_2eCalleeValue, !tbaa !24
  call void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %t354, %"compiler/source:Span" %t355, ptr %t356, i64 %t357)
  br label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewsAcross(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca i1
  %l39 = alloca ptr
  %l43 = alloca ptr
  %l44 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca ptr
  %l64 = alloca %"compiler/source:Span"
  %l70 = alloca i64
  %l74 = alloca i64
  %l77 = alloca i64
  %l98 = alloca i64
  %l101 = alloca i1
  %l105 = alloca %"compiler/source:Span"
  %l107 = alloca i1
  %l108 = alloca i1
  %l109 = alloca %"compiler/source:Span"
  %l113 = alloca %"compiler/source:Span"
  %l114 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i64
  %l125 = alloca ptr
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l129 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/free:walker", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l6, !tbaa !29
  store ptr %a4, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l8, !tbaa !24
  store i64 %t8, ptr %l20, !tbaa !24
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t9)
  store i64 %t11, ptr %l22
  br label %bb2
bb2:
  %t12 = load i64, ptr %l20, !tbaa !24
  %t13 = load i64, ptr %l22, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb26
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l7, !tbaa !29
  %t19 = load i64, ptr %l8, !tbaa !24
  %t22 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l27
  br label %bb6
bb6:
  %t23 = load i64, ptr %l27, !tbaa !24
  store i64 %t23, ptr %l9, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l28, !tbaa !29
  %t25 = load i64, ptr %l9, !tbaa !24
  store i64 %t25, ptr %l29, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  store i64 %t26, ptr %l30, !tbaa !24
  %t27 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t27, ptr %l31
  %t29 = load i64, ptr %l9, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v2, ptr %v2, ptr %a5, i64 %t29)
  store ptr %t32, ptr %l34
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l28, !tbaa !29
  %t34 = load i64, ptr %l29, !tbaa !24
  %t35 = load i64, ptr %l30, !tbaa !24
  %t36 = load %"compiler/source:Span", ptr %l31
  %t37 = load ptr, ptr %l34, !tbaa !29
  %t38 = call i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einUseAcross(ptr %v0, ptr %v2, ptr %t33, i64 %t34, i64 %t35, %"compiler/source:Span" %t36, ptr %t37)
  store i64 %t38, ptr %l35
  br label %bb8
bb8:
  %t39 = load i64, ptr %l35, !tbaa !24
  store i64 %t39, ptr %l10, !tbaa !24
  %t40 = load i64, ptr %l10, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb13
bb10:
  %t44 = load ptr, ptr %l6, !tbaa !29
  store ptr %t44, ptr %l39, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/free:walker", ptr %t45, i32 0, i32 3
  %t48 = load i64, ptr %l9, !tbaa !24
  %t51 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l43
  br label %bb11
bb11:
  %t52 = load ptr, ptr %l39, !tbaa !29
  %t53 = load ptr, ptr %l43, !tbaa !29
  %t54 = call i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v0, ptr %t52, ptr %t53)
  store i1 %t54, ptr %l44
  br label %bb12
bb12:
  %t55 = load i1, ptr %l44, !tbaa !21
  %t56 = xor i1 %t55, true
  store i1 %t56, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb14, label %bb15
bb14:
  br label %bb25
bb15:
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l6, !tbaa !29
  %t61 = getelementptr %"compiler/free:Free", ptr %t59, i32 0, i32 60
  %t62 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l6, !tbaa !29
  %t67 = getelementptr %"compiler/free:Free", ptr %t65, i32 0, i32 61
  store ptr %t67, ptr %l50, !tbaa !29
  %t68 = call ptr @__olang_scope_hold(ptr %v0)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l51, !tbaa !24
  %t70 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t70, label %bb18, label %bb19
bb18:
  %t72 = call ptr @__olang_region_make(ptr %v0)
  %t73 = ptrtoint ptr %t72 to i64
  store i64 %t73, ptr %l51, !tbaa !24
  br label %bb19
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/free:walker", ptr %t74, i32 0, i32 3
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t76, i64 %t77)
  store ptr %t80, ptr %l56
  br label %bb20
bb20:
  %t81 = load i64, ptr %l51
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = load i64, ptr %l51
  %t84 = inttoptr i64 %t83 to ptr
  %t85 = load ptr, ptr %l56, !tbaa !29
  %t86 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %t82, ptr %t84, ptr %t85)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t86, ptr %l57
  br label %bb21
bb21:
  %t87 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t88 = load i64, ptr %l51
  %t89 = inttoptr i64 %t88 to ptr
  %t90 = call ptr @__olang_scope_alloc_a(ptr %t89, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t87, ptr %t90
  %t91 = load ptr, ptr %l50, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t91, ptr %t90)
  br label %bb22
bb22:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = getelementptr %"compiler/free:Free", ptr %t93, i32 0, i32 62
  store ptr %t95, ptr %l60, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/free:walker", ptr %t96, i32 0, i32 33
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t98, i64 %t99)
  store %"compiler/source:Span" %t102, ptr %l64
  br label %bb23
bb23:
  %t103 = load ptr, ptr %l60, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l64
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t103, %"compiler/source:Span" %t104)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t105 = load i64, ptr %l8, !tbaa !24
  %t108 = add i64 %t105, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb1
bb26:
  store i64 0, ptr %l11, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/free:walker", ptr %t110, i32 0, i32 97
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l70
  br label %bb27
bb27:
  %t115 = load i64, ptr %l70, !tbaa !24
  store i64 %t115, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t116 = load i64, ptr %l12, !tbaa !24
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = icmp sgt i64 %t116, %t117
  br i1 %t120, label %bb28, label %bb29
bb28:
  %t122 = load i64, ptr %l13, !tbaa !24
  %t124 = icmp sgt i64 %t122, 0
  br i1 %t124, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb33
bb30:
  %t126 = load i64, ptr %l12, !tbaa !24
  %t127 = load i64, ptr %l11, !tbaa !24
  %t130 = sub i64 %t126, %t127
  %t131 = load i64, ptr %l13, !tbaa !24
  %t134 = add i64 %t130, %t131
  %t136 = sub i64 %t134, 1
  %t137 = load i64, ptr %l13, !tbaa !24
  %t140 = sdiv i64 %t136, %t137
  store i64 %t140, ptr %l77, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb32
bb32:
  %t142 = load i64, ptr %l77, !tbaa !24
  store i64 %t142, ptr %l74, !tbaa !24
  br label %bb33
bb33:
  %t143 = load i64, ptr %l74, !tbaa !24
  store i64 %t143, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb34
bb34:
  %t144 = load i64, ptr %l15, !tbaa !24
  %t145 = load i64, ptr %l14, !tbaa !24
  %t148 = icmp slt i64 %t144, %t145
  %t150 = xor i1 %t148, true
  br i1 %t150, label %bb35, label %bb36
bb35:
  br label %bb61
bb36:
  br label %bb37
bb37:
  %t152 = load i64, ptr %l11, !tbaa !24
  %t153 = load i64, ptr %l15, !tbaa !24
  %t154 = load i64, ptr %l13, !tbaa !24
  %t157 = mul i64 %t153, %t154
  %t160 = add i64 %t152, %t157
  store i64 %t160, ptr %l16, !tbaa !24
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/free:walker", ptr %t162, i32 0, i32 97
  %t165 = load i64, ptr %l16, !tbaa !24
  %t168 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t164, i64 %t165)
  store i64 %t168, ptr %l98
  br label %bb38
bb38:
  %t169 = load i64, ptr %l2, !tbaa !24
  %t170 = load i64, ptr %l98, !tbaa !24
  %t172 = icmp ne i64 %t170, %t169
  br i1 %t172, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb43
bb40:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/free:walker", ptr %t174, i32 0, i32 98
  %t177 = load i64, ptr %l16, !tbaa !24
  %t180 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t176, i64 %t177)
  store %"compiler/source:Span" %t180, ptr %l105
  br label %bb41
bb41:
  %t181 = load %"compiler/source:Span", ptr %l3
  %t182 = load %"compiler/source:Span", ptr %l105
  %t184 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t182, %"compiler/source:Span" %t181)
  store i1 %t184, ptr %l107
  br label %bb42
bb42:
  %t185 = load i1, ptr %l107, !tbaa !21
  store i1 %t185, ptr %l101, !tbaa !21
  br label %bb43
bb43:
  %t186 = load i1, ptr %l101, !tbaa !21
  br i1 %t186, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb48
bb45:
  %t187 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t187, ptr %l109
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/free:walker", ptr %t188, i32 0, i32 98
  %t191 = load i64, ptr %l16, !tbaa !24
  %t194 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t190, i64 %t191)
  store %"compiler/source:Span" %t194, ptr %l113
  br label %bb46
bb46:
  %t195 = load %"compiler/source:Span", ptr %l109
  %t196 = load %"compiler/source:Span", ptr %l113
  %t197 = call i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %t195, %"compiler/source:Span" %t196)
  store i1 %t197, ptr %l114
  br label %bb47
bb47:
  %t198 = load i1, ptr %l114, !tbaa !21
  store i1 %t198, ptr %l108, !tbaa !21
  br label %bb48
bb48:
  %t199 = load i1, ptr %l108, !tbaa !21
  br i1 %t199, label %bb49, label %bb50
bb49:
  br label %bb60
bb50:
  br label %bb51
bb51:
  %t200 = load ptr, ptr %l6, !tbaa !29
  %t202 = getelementptr %"compiler/free:Free", ptr %t200, i32 0, i32 60
  %t203 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t202, i64 %t203)
  br label %bb52
bb52:
  %t206 = load ptr, ptr %l6, !tbaa !29
  %t208 = getelementptr %"compiler/free:Free", ptr %t206, i32 0, i32 61
  store ptr %t208, ptr %l119, !tbaa !29
  %t209 = call ptr @__olang_scope_hold(ptr %v0)
  %t210 = ptrtoint ptr %t209 to i64
  store i64 %t210, ptr %l120, !tbaa !24
  %t211 = load i1, ptr @olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1
  br i1 %t211, label %bb53, label %bb54
bb53:
  %t213 = call ptr @__olang_region_make(ptr %v0)
  %t214 = ptrtoint ptr %t213 to i64
  store i64 %t214, ptr %l120, !tbaa !24
  br label %bb54
bb54:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/free:walker", ptr %t215, i32 0, i32 99
  %t218 = load i64, ptr %l16, !tbaa !24
  %t221 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v0, ptr %t217, i64 %t218)
  store ptr %t221, ptr %l125
  br label %bb55
bb55:
  %t222 = load i64, ptr %l120
  %t223 = inttoptr i64 %t222 to ptr
  %t224 = load i64, ptr %l120
  %t225 = inttoptr i64 %t224 to ptr
  %t226 = load ptr, ptr %l125, !tbaa !29
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %t223, ptr %t225, ptr %t226)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l126
  br label %bb56
bb56:
  %t228 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  %t229 = load i64, ptr %l120
  %t230 = inttoptr i64 %t229 to ptr
  %t231 = call ptr @__olang_scope_alloc_a(ptr %t230, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t228, ptr %t231
  %t232 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v0, ptr %t232, ptr %t231)
  br label %bb57
bb57:
  %t234 = load ptr, ptr %l6, !tbaa !29
  %t236 = getelementptr %"compiler/free:Free", ptr %t234, i32 0, i32 62
  store ptr %t236, ptr %l129, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr %"compiler/free:walker", ptr %t237, i32 0, i32 98
  %t240 = load i64, ptr %l16, !tbaa !24
  %t243 = call %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t239, i64 %t240)
  store %"compiler/source:Span" %t243, ptr %l133
  br label %bb58
bb58:
  %t244 = load ptr, ptr %l129, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l133
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t244, %"compiler/source:Span" %t245)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t246 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t246, 1
  store i64 %t249, ptr %l15, !tbaa !24
  br label %bb34
bb61:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2ffree_2efillOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 7
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Make", ptr %t16, i32 0, i32 0
  %t19 = load i32, ptr %t18, !range !{i32 0, i32 5}
  %t21 = trunc i64 3 to i32
  %t22 = icmp eq i32 %t19, %t21
  store i1 %t22, ptr %l3, !tbaa !21
  br label %bb18
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t25 = load ptr, ptr %l13, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l13, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 18}
  %t31 = icmp eq i64 %t29, 17
  store i1 %t31, ptr %l14, !tbaa !21
  br label %bb8
bb8:
  %t32 = load i1, ptr %l14, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [5 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i64, ptr }, ptr %t35, i32 0, i32 2
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = call i1 @compiler_2ffree_2efillOf(ptr %v0, ptr %t39)
  store i1 %t41, ptr %l20
  br label %bb12
bb12:
  %t42 = load i1, ptr %l20, !tbaa !21
  store i1 %t42, ptr %l3, !tbaa !21
  br label %bb18
bb13:
  br i1 true, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_286a8c932e0e8907_923f29d398efb30b)
  unreachable
bb18:
  %t43 = load i1, ptr %l3, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2ehasLocal(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  br label %bb11
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load i32, ptr %l13, !tbaa !23
  %t21 = sext i32 %t18 to i64
  %t25 = icmp eq i64 %t21, %a1
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2ffree_2enoDefaults(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i1
  %l17 = alloca { i64, ptr }
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Try", ptr %a0, i32 0, i32 1
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = sub i64 %t10, 1
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = icmp slt i64 %t12, 2147483648
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sge i64 %t14, 0
  %t18 = and i1 %t13, %t15
  store i1 %t18, ptr %l12, !tbaa !21
  br label %bb1
bb1:
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = icmp slt i64 %t19, %t20
  %t25 = xor i1 %t23, true
  br i1 %t25, label %bb2, label %bb3
bb2:
  br label %bb9
bb3:
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  %t30 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr ptr, ptr %t31, i64 %t28
  %t33 = load ptr, ptr %t32, !tbaa !39
  %t37 = getelementptr %"compiler/typed:Clause", ptr %t33, i32 0, i32 4
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb5, label %bb6
bb5:
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t48 = add i64 %t45, 1
  store i64 %t48, ptr %l2, !tbaa !24
  br label %bb1
bb9:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/free:VecWalk" @compiler_2ffree_3aVecWalk_2ector(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2, i64 %a3, i32 %a4, i64 %a5) #0 {
entry:
  %rv = alloca %"compiler/free:VecWalk"
  br label %start
start:
  br label %bb0
bb0:
  %t14 = insertvalue %"compiler/free:VecWalk" undef, { i64, ptr } %a0, 0
  %t16 = insertvalue %"compiler/free:VecWalk" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/free:VecWalk" %t16, i64 %a2, 2
  %t20 = insertvalue %"compiler/free:VecWalk" %t18, i64 %a3, 3
  %t22 = insertvalue %"compiler/free:VecWalk" %t20, i32 %a4, 4
  %t24 = insertvalue %"compiler/free:VecWalk" %t22, i64 %a5, 5
  store %"compiler/free:VecWalk" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:VecWalk", ptr %rv
  ret %"compiler/free:VecWalk" %rr
}

define dso_local %"compiler/free:retire" @compiler_2ffree_3aretire_2ector(ptr %v0, ptr %v1, i64 %a0, %"compiler/source:Span" %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2) #0 {
entry:
  %rv = alloca %"compiler/free:retire"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/free:retire" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/free:retire" %t8, %"compiler/source:Span" %a1, 1
  %t12 = insertvalue %"compiler/free:retire" %t10, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2, 2
  store %"compiler/free:retire" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:retire", ptr %rv
  ret %"compiler/free:retire" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2ffree_3aleaf_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
define linkonce_odr %"compiler/free:leaf" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aleaf(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:leaf"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:leaf"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:leaf", ptr %a0
  store %"compiler/free:leaf" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:leaf", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:leaf", ptr %l1
  store %"compiler/free:leaf" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:leaf", ptr %rv
  ret %"compiler/free:leaf" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@olang_2esole_2eArray_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@olang_2esole_2eArray_3cArray_3cI64_3e_26_3e_2e_2d1 = weak hidden constant i1 false
@__olang_empty_array = external constant [16 x i64]
@.d0 = private constant <{ i64, [68 x i8] }> <{ i64 0, [68 x i8] c"a destructor, Str, Eq or Hash lets go of it where no call is written" }>, align 8
@.d1 = private constant <{ i64, [144 x i8] }> <{ i64 0, [144 x i8] c"its new value may hold an instance whose destructor is still to run (O16), which a let-go would run early: build that instance outside the value" }>, align 8
@.d2 = private constant <{ i64, [92 x i8] }> <{ i64 0, [92 x i8] c"a value built into what it holds may hold an instance whose destructor is still to run (O16)" }>, align 8
@.d3 = private constant <{ i64, [98 x i8] }> <{ i64 0, [98 x i8] c"a call building into what it holds may register an instance whose destructor is still to run (O16)" }>, align 8
@olang_2esole_2ecompiler_2ffree_3areason_2e3 = weak hidden constant i1 false
@.d4 = private constant <{ i64, [74 x i8] }> <{ i64 0, [74 x i8] c"what is built for it is changed by a call that cannot build where it is: '" }>, align 8
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d6 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"its new value cannot be built in a region of its own here" }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@.d7 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"its new value is built where another place's is" }>, align 8
@.d8 = private constant <{ i64, [85 x i8] }> <{ i64 0, [85 x i8] c"what it holds has a destructor still to run when it lets go (O15): its holder ends it" }>, align 8
@.d9 = private constant <{ i64, [87 x i8] }> <{ i64 0, [87 x i8] c"what holds it is an owner held in a place of early freeing, whose storage is one region" }>, align 8
@.d10 = private constant <{ i64, [48 x i8] }> <{ i64 0, [48 x i8] c"its new value is moved out of a place that keeps" }>, align 8
@.d11 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d12 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" sole" }>, align 8
@.d13 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" keeps (" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d14 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c") " }>, align 8
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d16 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"place " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c" field " }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d20 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"main" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aScope(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 9}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 9}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb15
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 1, label %bb4 i64 2, label %bb5 i64 4, label %bb6 i64 7, label %bb7 i64 8, label %bb8 ]
bb3:
  br label %bb15
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb9, label %bb1
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr { i64, [2 x i64] }, ptr %t22, i32 0, i32 1
  %t24 = getelementptr { i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  %t28 = getelementptr { i64 }, ptr %t27, i32 0, i32 0
  %t29 = load i64, ptr %t28
  %t32 = icmp eq i64 %t25, %t29
  br i1 %t32, label %bb10, label %bb1
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 1
  %t36 = getelementptr { i32 }, ptr %t35, i32 0, i32 0
  %t37 = load i32, ptr %t36
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [2 x i64] }, ptr %t38, i32 0, i32 1
  %t40 = getelementptr { i32 }, ptr %t39, i32 0, i32 0
  %t41 = load i32, ptr %t40
  %t44 = icmp eq i32 %t37, %t41
  br i1 %t44, label %bb11, label %bb1
bb7:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr { i64, [2 x i64] }, ptr %t46, i32 0, i32 1
  %t48 = getelementptr { i64 }, ptr %t47, i32 0, i32 0
  %t49 = load i64, ptr %t48
  %t50 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr { i64, [2 x i64] }, ptr %t50, i32 0, i32 1
  %t52 = getelementptr { i64 }, ptr %t51, i32 0, i32 0
  %t53 = load i64, ptr %t52
  %t56 = icmp eq i64 %t49, %t53
  br i1 %t56, label %bb12, label %bb1
bb8:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [2 x i64] }, ptr %t58, i32 0, i32 1
  %t60 = getelementptr { i64, i64 }, ptr %t59, i32 0, i32 0
  %t61 = load i64, ptr %t60
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr { i64, [2 x i64] }, ptr %t62, i32 0, i32 1
  %t64 = getelementptr { i64, i64 }, ptr %t63, i32 0, i32 0
  %t65 = load i64, ptr %t64
  %t68 = icmp eq i64 %t61, %t65
  br i1 %t68, label %bb13, label %bb1
bb9:
  br label %bb3
bb10:
  br label %bb3
bb11:
  br label %bb3
bb12:
  br label %bb3
bb13:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  %t72 = getelementptr { i64, i64 }, ptr %t71, i32 0, i32 1
  %t73 = load i64, ptr %t72
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [2 x i64] }, ptr %t74, i32 0, i32 1
  %t76 = getelementptr { i64, i64 }, ptr %t75, i32 0, i32 1
  %t77 = load i64, ptr %t76
  %t80 = icmp eq i64 %t73, %t77
  br i1 %t80, label %bb14, label %bb1
bb14:
  br label %bb3
bb15:
  %t82 = load i1, ptr %l2, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d24 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c" has one holder: every instance stored into an owning place is a new one\0A" }>, align 8
@.d25 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c": memory: " }>, align 8
@.d26 = private constant <{ i64, [67 x i8] }> <{ i64 0, [67 x i8] c" may be held by two owning places at once, so it has no one holder\0A" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d29 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"std/prelude" }>, align 8
@olang_2esole_2ecompiler_2ffree_3aFree_2e143 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2e0 = weak hidden constant i1 false
define linkonce_odr %"compiler/free:VecWalk" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aVecWalk(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:VecWalk"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"compiler/free:VecWalk"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:VecWalk", ptr %a0
  store %"compiler/free:VecWalk" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:VecWalk", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"compiler/free:VecWalk", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"compiler/free:VecWalk", ptr %l1
  store %"compiler/free:VecWalk" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:VecWalk", ptr %rv
  ret %"compiler/free:VecWalk" %rr
}

@.d30 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d31 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"tree" }>, align 8
@.d33 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"value" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ecaptured_2elocal_2e5 = weak hidden constant i1 false
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_drop(ptr) noinline
@.d37 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"a lambda's copy of what it captures" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2eexprOf_2elocal_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffree_3aretire_2e2 = weak hidden constant i1 false
define linkonce_odr %"compiler/free:retire" @olang_2emir_2eHelperKind_2eCopy_2ecompiler_2ffree_3aretire(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/free:retire"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/free:retire"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"compiler/free:retire", ptr %a0
  store %"compiler/free:retire" %t2, ptr %l1
  %t3 = getelementptr %"compiler/free:retire", ptr %l1, i32 0, i32 2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t3)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t7 = getelementptr %"compiler/free:retire", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %t7
  %t8 = load %"compiler/free:retire", ptr %l1
  store %"compiler/free:retire" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/free:retire", ptr %rv
  ret %"compiler/free:retire" %rr
}

@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [34 x i8] }> <{ i64 0, [34 x i8] c"its value is changed in place, by " }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c": '" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2einstRoots_2elocal_2e7 = weak hidden constant i1 false
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_3e_2e_2d1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2e0 = weak hidden constant i1 false
declare void @__olang_slot_release(ptr) noinline
@.d43 = private constant <{ i64, [88 x i8] }> <{ i64 0, [88 x i8] c"a value moved out of it is held where its call lands (O16), where nothing releases it: '" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@olang_2esole_2ecompiler__2ffree__2ecompiler__2ffree__3awalker__2ereach_2elocal_2e22 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 4
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d45 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"keeps the copy '" }>, align 8
@.d46 = private constant <{ i64, [57 x i8] }> <{ i64 0, [57 x i8] c"' makes of the value it returns, which no let-go releases" }>, align 8
@.d47 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"lets go of what it held" }>, align 8
@.d48 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"lets go of what it held" }>, align 8
@.d49 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c"lets go of what it held" }>, align 8
@.d50 = private constant <{ i64, [32 x i8] }> <{ i64 0, [32 x i8] c"lets go of what the element held" }>, align 8
@.d51 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i64 @compiler_2ffree_2elocalOf(ptr %v0, ptr %a0)
@olang_loc_501cc49742afc1b0_35a87f90516239c4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eleaves(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eLen_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %a0)
declare %"compiler/free:leaf" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2eAt_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartPlace(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aleaf_3e_2ePush_3ccompiler_2ffree_3aleaf_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:leaf" %a1)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_b1f6521422f181b6_5a182b34590183f2 = external constant [0 x i8]
declare %"compiler/free:leaf" @compiler_2ffree_3aleaf_2ector(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ebodyModule(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__He5d25769b393ce65c1b3f30021d9348f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eMustTop = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bdc560d7322c3213_e707f8f411fbb267 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cBool_H788cd74f9c006611bc4bb459b5b22001(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_72902bac739aff89_2513c2e385693c05 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cI64_3e_26_3e_2ePush_3cArray_3cI64_3e_26_3e(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_3fc20153d7ed10ca_2c74aea1b5acbce6 = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceOfPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_4cef24e7d17769b7_e2744f91577a9953 = external constant [0 x i8]
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eGet_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eretCopies(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
@olang_loc_77e2c420ac7907a9_804235f2ad53d = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eLen_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0)
declare %"compiler/free:letGo" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aletGo_3e_2eAt_3ccompiler_2ffree_3aletGo_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eLCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ffree_2eLLeaf = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2etaskKeeps(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ehas(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRDtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeep(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eLen_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:store" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3astore_3e_2eAt_3ccompiler_2ffree_3astore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eSFresh = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_834ee64634399a9c_46784e5d37862958 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayRegister(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eLen_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orStore" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorStore_3e_2eAt_3ccompiler_2ffree_3aorStore_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eLen_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:orCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aorCall_3e_2eAt_3ccompiler_2ffree_3aorCall_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eLen_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %a0)
declare %"compiler/free:feedCall" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeedCall_3e_2eAt_3ccompiler_2ffree_3afeedCall_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/free:feed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3afeed_3e_2eAt_3ccompiler_2ffree_3afeed_3e(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eRInPlace = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceable(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:store" %a1)
@olang_loc_dcc3c6712d01991_ec14a6947a12b86d = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etopSite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eRMade = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eouterFirst(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_1c3c578240008a_e9f41163a0859586 = external constant [0 x i8]
@olang_loc_66d907e33dd98677_4991ee91581ac48b = external constant [0 x i8]
declare { i64, [2 x i64] } @compiler_2ffree_2ecompiler_2ffree_3aFree_2esiteScope(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H5696e1a008d256bf9453cde2b49c6c45(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H31314c4e7281f5029d6d8eb3044cef10(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i64 %a2)
@G_2ecompiler_2ffree_2eRNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eheldPlaces(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSlotPlace(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eanchorPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ffree_2eRCopied = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eaddTo(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ffree_2eSMove = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/free:reason" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3areason_3e_2eAt_3ccompiler_2ffree_3areason_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2edebugOut(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_1c505c1b55d06586_a0a7e4d6315dd1d2 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_a1073a599e491ba7_5bee4305fa184323 = external constant [0 x i8]
declare ptr @compiler_2ffree_2etaskCall(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2ftyped_2eCall_2eOf(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ftyped_2eCalleeBody(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eparamVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRef_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, [2 x i64] } @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2ePassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3aFree_2ecallAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eorVars(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_8b3278c9956239a9_33a2ffffb2331f15 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2efindCands(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_cc35812cd80eb51_e2c8c2ff33ac75fd = external constant [0 x i8]
@olang_loc_c8d50c31c10865f3_6990d5fc4ec4fa5f = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_686cabfba7367172_4d10bcb362872dde = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eForeignRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2epartsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H874ab6ecb906549bc54547c0392d06e9(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
@olang_loc_bb5f0dfb007b1fe9_f99f55ed89f1afa5 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eownerCand(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ehandleCand(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayCand(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefCand(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enewPlace(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i1 %a3, i32 %a4, i1 %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_4607beb6ac2e2918_142733ac3129574 = external constant [0 x i8]
declare i1 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLinksOwnC(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsRef(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aRefsKept_2eNoneKept(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i64 %a4, i1 %a5)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aExpr_3f_26_3e_2eAt__H2e4a6474e10b73ca754517844b8d7700(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_9ed3d3979443b16_3c0955d42b886a3a = external constant [0 x i8]
declare i64 @compiler_2ffree_2ereadsLocal(ptr %v0, ptr %a0)
declare i1 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eEncloses(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ekeepsNone(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3, i64 %a4, i1 %a5)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2elineStart(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare { i32, { i64, ptr } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20std_2fp_Hdc5ed4f57090b33f7a83fc7b2b1f05b3(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eIsGen(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2eHasFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eFieldsOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fmir_2ecompiler_2fmir_3aGenInfo_2eWeakField(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2fmir_2eHasCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fmir_2eCasesOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResults(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2eregister(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4e10a6e17fa9b999_b873e8c9bb06b2fd = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_997f49c366488af5_93d2651ee5683809 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSetOnce(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_3f4c383e8983fca5_b7613254c9da681 = external constant [0 x i8]
@olang_loc_f5b9ea518a7ff771_9825b362779fb495 = external constant [0 x i8]
declare void @compiler_2feffects_3aEffects_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
@olang_loc_99e9ebfcbc8324ba_73e0a545fcd79b06 = external constant [0 x i8]
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_f87f15bbd5de31c8_d5f250c09d3b1a94 = external constant [0 x i8]
@olang_loc_eaf2522d3d4ee6a3_d46883eace75bccf = external constant [0 x i8]
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2ereached(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eRefMut_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eresultVar(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRole(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eRoleCtor = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2evarsFit(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, { i64, [2 x i64] } %a4, i64 %a5)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aPlan_2eSetPassed(ptr %v0, ptr %a0, i32 %a1, i64 %a2, { i64, [2 x i64] } %a3)
@olang_loc_21335a5a6f6a0d23_1fb4d5f27249eebf = external constant [0 x i8]
@olang_loc_653d83628bc1c214_23f3c62eb313bca0 = external constant [0 x i8]
@olang_loc_be157778634280c0_be41122d5d44a16c = external constant [0 x i8]
@olang_loc_b4c0d703fa684531_272a8f4f39064c15 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2ePartsOnly(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_66bc7a65ec09e50e_5d0a70b450b5d482 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eCalleesOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_53f9fdc161a0de7d_c280e3866725f49 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eCallsOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnedPart(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOwnsParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i64 } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eVecFields(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2etextBuffer(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2enestedBuffer(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aVecWalk_3e_2ePush_3ccompiler_2ffree_3aVecWalk_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:VecWalk" %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayBuffer(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eplaceKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eSplitField(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eentryBuffer(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eTextArray(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eSplitCount = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare { i64, i64, i64 } @compiler_2ffree_2ecompiler_2ffree_3aFree_2eMapFields(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H72f5eb830a5b95ea4064fb79c9339d29(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__Hb802ce24a60c51fc8ca388b849854e24(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e__H7b6d4eff6fc9c3821aae8b284e12e095(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estoreAs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, i1 %a6, i1 %a7)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ewholeArg(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, %"compiler/source:Span" %a3)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eescape(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i64 %a5, i64 %a6)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3aFree_2eunowned(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egoAll(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare %"compiler/source:Span" @compiler_2ffree_2ereceiverSpan(ptr %v0, ptr %a0)
@G_2ecompiler_2ffree_2eWalkNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ego(ptr %v0, ptr %a0, i64 %a1, i64 %a2, %"compiler/source:Span" %a3, %"compiler/source:Span" %a4, i64 %a5, i1 %a6, i64 %a7, i32 %a8)
@G_2ecompiler_2ffree_2eWalkCall = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviaCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, %"compiler/source:Span" %a5)
declare i64 @compiler_2ffree_2etempPlaceCall(ptr %v0, ptr %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eBlockCopy(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ereadOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2ffree_2ereadPlaceCall(ptr %v0, ptr %a0)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2eT(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2erefsBeyondParts(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2eokind(i64 %a0)
@G_2ecompiler_2ffree_2eOPl = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eoval(i64 %a0)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eviewRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRunsCopy(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2euntracked(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i1 %a4, i1 %a5, i1 %a6, i64 %a7, i1 %a8, i1 %a9)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2edtorCallsOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2enoteReach(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2ecall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2emakeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
@olang_loc_ea9e22c8e98b9315_4f35472d48da7b89 = external constant [0 x i8]
declare i32 @compiler_2ffree_2ecompiler_2ffree_3aFree_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20std_2fprelude_2fvec_3aVec_3cI64__H5927ce9e0c48ffa4d9cf1c64f8f12c1b(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2ffree_2eaddAllTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eONew = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2ffree_2eorig(i64 %a0, i64 %a1)
declare i64 @compiler_2ffree_2ereadLocalOf(ptr %v0, ptr %a0)
declare ptr @compiler_2ffree_2ecompiler_2ffree_3awalker_2ebody(ptr %v0, ptr %v1, ptr %a0)
@G_2ecompiler_2ffree_2eLHeld = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2eisLen(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ffree_3aretire_3e_2ePush_3ccompiler_2ffree_3aretire_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/free:retire" %a1)
declare i64 @compiler_2ffree_2ereadCall(ptr %v0, ptr %a0)
@olang_loc_dfb3465ca167576e_8d0cb6499ce7122 = external constant [0 x i8]
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dba6c8d02c3d079f_ccc870ae213a95a3 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2earm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_399af2e67a3feb00_10d299b63d924a94 = external constant [0 x i8]
@olang_loc_9fb993e2bf346d79_40fc6d70dd039d65 = external constant [0 x i8]
@olang_loc_e7b8bfc98130e352_7e3653312711fbbe = external constant [0 x i8]
@olang_loc_cced39b51eedc52a_7a31888a1cea4cb6 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eholds(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efeeder(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3aFree_2esetRegOut(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_958920a902c28464_5f3c4db0e7df1ea8 = external constant [0 x i8]
@G_2ecompiler_2ffree_2eOMov = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eIsOwner(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3awalker_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/source:Span" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eAt_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2espanIn(%"compiler/source:Span" %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ffree_2eInstNone = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_89e3eb0f8d54068a_873e152f561fcee = external constant [0 x i8]
declare void @compiler_2ftyped_2eLocalUses_2eUses(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2ffree_2eInstAsk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@olang_loc_ecba82c0cda3145f_2530efc2d93afc63 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_3e_2eLen_H327daf8a5f05e7deba4c08807621a9fe(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstGiven(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_Hf6e62a5a68166ed9aaf0549ae9176a35(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2ffree_2ecompiler_2ffree_3awalker_2einstNames(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H3dfb9bb75f225052e7117bc23a678a05(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cs_H70e429947547277d4792686f6c52db1a(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_2e913fd7c6d2d6ac_b85e5f87b55bb900 = external constant [0 x i8]
@olang_loc_b635439c476fea4e_d136026e66bf3e2 = external constant [0 x i8]
declare ptr @compiler_2ffree_2eunaway(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_7de1741991f26e46_8ca4854755ab7fa = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2edestructs(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eAt_3ccompiler_2ftyped_3aPlan_3e(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @compiler_2ffree_2eisVar({ i64, [2 x i64] } %a0)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownLocal(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eblockFillOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eLen__H22c160154c8542d83ffe3c77c98973d0(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_26_3e_2eAt_3ccompiler_2ftyped_3aLvalue_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_bfa96af29dec6ca7_6eacd8161d4b79f3 = external constant [0 x i8]
@olang_loc_71c754545de4040c_468b95bb5168a5f8 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2epathsKnown(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aPlan_3e_2eLen_3ccompiler_2ftyped_3aPlan_3e(ptr %v0, ptr %a0)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H1c6ff733ce949281236b08418b935189(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eHas_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2fvec_3aVec_3cc_H4057097bf127937e673a7f89a723e29a(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a2)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2eelemRead(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_a67b53fc36e221cd_398fd42a3021f5f1 = external constant [0 x i8]
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2eownsStorage(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ffree_2ecompiler_2ffree_3aFree_2efnName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3aFree_2eFixedText(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ffree_2eLAssign = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2emade(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, %"compiler/source:Span" %a3, i1 %a4)
@olang_loc_be89b37fd0a92d53_2c5aa2623b5da4df = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ffree_2eOUnk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eValueRecsAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_afd3b4561806d30e_4841abb84b9127fa = external constant [0 x i8]
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ethroughParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, ptr %a4, %"compiler/source:Span" %a5)
declare i64 @compiler_2ffree_2ecompiler_2ffree_3awalker_2efixedCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ffree_2ecompiler_2ffree_3awalker_2emayWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePromisesPure(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2ffree_2ecompiler_2ffree_3awalker_2ethroughCapture(ptr %v0, ptr %a0, i64 %a1, i1 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2ffree_2eCalleeValue = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i1 @compiler_2ffree_2ecompiler_2ffree_3aFree_2emayView(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2ffree_2ecopyOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_286a8c932e0e8907_923f29d398efb30b = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
